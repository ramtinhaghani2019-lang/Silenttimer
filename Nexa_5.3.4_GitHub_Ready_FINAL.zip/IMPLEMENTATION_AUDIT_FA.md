# ممیزی Nexa 5.3.4

مبنای این نسخه Nexa 5.3.3 است و اصلاحات 5.2، 5.3، 5.3.1، 5.3.2 و 5.3.3 حفظ شده‌اند.

## Closure 5.3.4
- [x] Bills: پیش‌فرض Alert Repeat = 5 دقیقه
- [x] Case: پیش‌فرض Alert Repeat = 5 دقیقه
- [x] Docs: پیش‌فرض Alert Repeat = 5 دقیقه
- [x] Home: پیش‌فرض Alert Repeat = 5 دقیقه
- [x] Reminder Ring fallback = 5 دقیقه
- [x] Medicine Ring: Back نمی‌تواند Alarm را بدون اکشن کاربر ببندد
- [x] Reminder Ring: Back نمی‌تواند Alarm را بدون اکشن کاربر ببندد
- [x] Alarm تا تأیید کاربر به‌عنوان حالت پیش‌فرض 5.3.3 حفظ شده
- [x] مدت قابل تنظیم ۳۰ ثانیه / ۱ / ۲ / ۵ دقیقه حفظ شده
- [x] تکرار ۵ دقیقه‌ای در صورت عدم تأیید حفظ شده
- [x] versionName = 5.3.4
- [x] versionCode = 19
- [x] Workflow = Build Nexa 5.3.4 APK
- [x] Artifact = Nexa-5.3.4-APK

## کنترل بازگشت اصلاحات قبلی
- [x] منطق فاصلهٔ دارو و محاسبهٔ دوز بعدی حفظ شده
- [x] «سر وقت خوردم / الان خوردم / یادآوری بعداً» حفظ شده
- [x] Alarm Full Screen و TYPE_ALARM حفظ شده
- [x] Today notification حفظ شده
- [x] Focus ساعت/دقیقه و Silent پیش‌فرض حفظ شده
- [x] Shopping list / item / seller / payment / receipts حفظ شده
- [x] ذخیره مستقل تصاویر Nexa و مدیریت تصاویر حفظ شده
- [x] اصلاحات UI و تاریخ/ساعت/فرمت عددی نسخه‌های قبلی حفظ شده

## محدودیت تأیید
این ممیزی روی سورس انجام شده است. محیط حاضر Gradle نصب‌شده ندارد؛ بنابراین Build واقعی APK در این محیط اجرا نشده است. Workflow GitHub Actions برای Java 17 و Gradle 8.9 داخل پروژه قرار دارد و Build موفق آن + تست روی گوشی معیار تأیید نهایی runtime است.
