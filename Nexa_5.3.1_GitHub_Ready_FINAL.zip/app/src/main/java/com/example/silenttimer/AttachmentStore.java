package com.example.silenttimer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Locale;

public final class AttachmentStore {
    private AttachmentStore(){}

    public static final class ImportResult {
        public String path="";
        public String sha256="";
        public boolean duplicate=false;
    }

    public static File mediaDir(Context c){
        File d=new File(c.getFilesDir(),"nexa_media");
        if(!d.exists())d.mkdirs();
        return d;
    }

    public static ImportResult importImage(Context c, Uri uri) throws Exception {
        ImportResult out=new ImportResult();
        File temp=File.createTempFile("nexa_",".img",mediaDir(c));
        MessageDigest md=MessageDigest.getInstance("SHA-256");
        try(InputStream in=c.getContentResolver().openInputStream(uri);FileOutputStream fos=new FileOutputStream(temp)){
            if(in==null)throw new IllegalStateException("فایل قابل خواندن نیست");
            byte[] buf=new byte[8192];int n;
            while((n=in.read(buf))>0){fos.write(buf,0,n);md.update(buf,0,n);}
        }
        StringBuilder sb=new StringBuilder();for(byte b:md.digest())sb.append(String.format(Locale.US,"%02x",b));
        out.sha256=sb.toString();
        File target=new File(mediaDir(c),out.sha256+".img");
        if(target.exists()){
            out.duplicate=true;temp.delete();
        }else if(!temp.renameTo(target)){
            try(FileInputStream in=new FileInputStream(temp);FileOutputStream fos=new FileOutputStream(target)){
                byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)fos.write(buf,0,n);
            }
            temp.delete();
        }
        out.path=target.getAbsolutePath();return out;
    }

    public static long totalBytes(Context c){long n=0;File[]fs=mediaDir(c).listFiles();if(fs!=null)for(File f:fs)if(f.isFile())n+=f.length();return n;}
    public static int count(Context c){File[]fs=mediaDir(c).listFiles();return fs==null?0:fs.length;}
    public static String humanSize(long bytes){double mb=bytes/1024.0/1024.0;if(mb>=1)return String.format(Locale.US,"%.1f MB",mb);double kb=bytes/1024.0;return String.format(Locale.US,"%.0f KB",kb);}
    public static void deletePath(String path){if(path==null||path.isEmpty())return;try{new File(path).delete();}catch(Exception ignored){}}
    public static void deleteAll(Context c){File[]fs=mediaDir(c).listFiles();if(fs!=null)for(File f:fs)if(f.isFile())f.delete();}

    public static boolean rotate90(String path){
        try{Bitmap src=BitmapFactory.decodeFile(path);if(src==null)return false;Matrix m=new Matrix();m.postRotate(90f);Bitmap out=Bitmap.createBitmap(src,0,0,src.getWidth(),src.getHeight(),m,true);boolean ok=saveBitmap(path,out);if(out!=src)out.recycle();src.recycle();return ok;}catch(Exception e){return false;}
    }

    /** Simple receipt crop: removes 7% from every edge; intended to trim surrounding table/background. */
    public static boolean cropMargins(String path){
        try{Bitmap src=BitmapFactory.decodeFile(path);if(src==null)return false;int dx=Math.max(1,Math.round(src.getWidth()*0.07f)),dy=Math.max(1,Math.round(src.getHeight()*0.07f));int w=src.getWidth()-2*dx,h=src.getHeight()-2*dy;if(w<100||h<100){src.recycle();return false;}Bitmap out=Bitmap.createBitmap(src,dx,dy,w,h);boolean ok=saveBitmap(path,out);if(out!=src)out.recycle();src.recycle();return ok;}catch(Exception e){return false;}
    }

    private static boolean saveBitmap(String path,Bitmap b)throws Exception{try(FileOutputStream fos=new FileOutputStream(path,false)){return b.compress(Bitmap.CompressFormat.JPEG,94,fos);}}
}
