import java.nio.file.*;
public class HomeContentAttachmentSmokeTest {
 public static void main(String[] args) throws Exception {
 String s=Files.readString(Path.of("app/src/main/java/com/example/silenttimer/MainActivity.java"));
 int a=s.indexOf("screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));"),b=s.indexOf("screen.addView(bottom,bp);"),c=s.indexOf("setContentView(screen);");
 if(a<0||b<a||c<b)throw new AssertionError("Home content is not attached");
 System.out.println("PASS: home content attached before navigation");
 }
}
