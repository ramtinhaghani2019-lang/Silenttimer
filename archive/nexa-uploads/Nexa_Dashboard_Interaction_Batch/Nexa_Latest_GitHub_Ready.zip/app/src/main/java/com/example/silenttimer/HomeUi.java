package com.example.silenttimer;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Native, concise dashboard components; no network or persistence side effects. */
final class HomeUi {
    private HomeUi(){}
    private static final int CARD=0xFF192436;
    private static final int CARD_FOCUS=0xFF172D4B;
    private static final int BORDER=0xFF344257;
    private static final int WHITE=0xFFF5F7FC;
    private static final int SUB=0xFFAFBED1;
    static boolean shouldStack(Context c){
        float density=c.getResources().getDisplayMetrics().density;
        float width=c.getResources().getDisplayMetrics().widthPixels/density;
        return width<420f||c.getResources().getConfiguration().fontScale>1.12f;
    }
    private static GradientDrawable shape(Context c,int fill,int stroke,int radius){
        GradientDrawable bg=new GradientDrawable();
        // Subtle directional light gives native cards depth without bitmaps.
        int upper=fill==CARD_FOCUS?0xFF223B5A:(fill==CARD?0xFF213249:fill);
        bg.setOrientation(GradientDrawable.Orientation.TL_BR);
        bg.setColors(new int[]{upper,fill});
        bg.setCornerRadius(UiKit.dp(c,radius));
        bg.setStroke(UiKit.dp(c,1),stroke);
        return bg;
    }
    static LinearLayout panel(Context c,boolean focus){
        LinearLayout p=new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        p.setPadding(UiKit.dp(c,16),UiKit.dp(c,15),UiKit.dp(c,16),UiKit.dp(c,15));
        p.setBackground(shape(c,focus?CARD_FOCUS:CARD,focus?0xFF9B7B48:BORDER,20));
        // Prevent tiny targets when the system font is enlarged.
        p.setMinimumHeight(UiKit.dp(c,48));
        return p;
    }
    static TextView secondary(Context c,String s){
        TextView t=new TextView(c);
        t.setText(s);t.setTextColor(SUB);t.setTextSize(13);
        t.setGravity(Gravity.RIGHT);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        t.setIncludeFontPadding(false);t.setLineSpacing(UiKit.dp(c,2),1.05f);
        return t;
    }
    static TextView heading(Context c,String s){
        TextView t=new TextView(c);
        t.setText(s);t.setTextColor(WHITE);t.setTextSize(16);
        t.setTypeface(UiKit.appFace(c,true));
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);
        // Semantic heading improves navigation for screen readers (API 28+).
        if(android.os.Build.VERSION.SDK_INT>=28)t.setAccessibilityHeading(true);
        return t;
    }
    static TextView sectionLabel(Context c,String s){
        TextView v=heading(c,s);
        v.setTextSize(15f);v.setTextColor(0xFFE7C37C);v.setPadding(UiKit.dp(c,2),UiKit.dp(c,3),UiKit.dp(c,2),UiKit.dp(c,3));
        return v;
    }
    static TextView badge(Context c,String s,int color){
        TextView v=secondary(c,s);v.setTextSize(12f);v.setTextColor(0xFFF4F6F1);
        v.setGravity(Gravity.CENTER);v.setPadding(UiKit.dp(c,11),UiKit.dp(c,7),UiKit.dp(c,11),UiKit.dp(c,7));
        v.setBackground(shape(c,0xFF2A3850,color,100));
        return v;
    }
    static LinearLayout headerRow(Context c,String s,String action){
        LinearLayout line=new LinearLayout(c);line.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=heading(c,s);line.addView(t,new LinearLayout.LayoutParams(0,-2,1f));
        TextView a=secondary(c,action);a.setTextColor(UiKit.GOLD);a.setTextSize(12);
        line.addView(a);
        return line;
    }
    /** Consistent 48dp+ touch feedback and TalkBack names for dashboard destinations. */
    static void destination(Context c,View view,String description,int rippleColor){
        view.setClickable(true);
        view.setFocusable(true);
        view.setContentDescription(description);
        UiKit.touchFeedback(c,view,rippleColor,20);
    }
    static LinearLayout balanceCard(Context c,String title,int color){
        LinearLayout card=panel(c,false);
        TextView titleView=secondary(c,"●  "+title);
        titleView.setTextColor(color);titleView.setTextSize(13f);
        card.addView(titleView);
        card.setMinimumHeight(UiKit.dp(c,96));
        return card;
    }
    static TextView money(Context c,String s,int color){
        TextView v=heading(c,s);
        v.setTextSize(16f);v.setTextColor(color);v.setMaxLines(3);
        v.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
        return v;
    }
    static LinearLayout shortcut(Context c,String icon,String title,String subtitle){
        LinearLayout line=panel(c,false);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setMinimumHeight(UiKit.dp(c,72));
        // A dedicated icon surface gives each destination a clear visual anchor.
        TextView pict=heading(c,UiKit.symbolFor(icon));
        pict.setTextSize(22f);pict.setIncludeFontPadding(false);
        pict.setTextColor(UiKit.GOLD);
        pict.setGravity(Gravity.CENTER);
        pict.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        pict.setBackground(shape(c,0xFF233C5C,0xFF977B50,14));
        LinearLayout.LayoutParams pictParams=new LinearLayout.LayoutParams(UiKit.dp(c,46),UiKit.dp(c,46));
        pictParams.setMargins(0,0,UiKit.dp(c,4),0);
        line.addView(pict,pictParams);
        LinearLayout texts=new LinearLayout(c);texts.setOrientation(LinearLayout.VERTICAL);
        TextView label=heading(c,title);label.setTextSize(15f);
        label.setMaxLines(2);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        TextView desc=secondary(c,subtitle);desc.setTextSize(12f);desc.setMaxLines(2);
        desc.setEllipsize(android.text.TextUtils.TruncateAt.END);
        texts.addView(label);texts.addView(desc,UiKit.matchWrap(c,4,0));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1f);
        tp.setMargins(UiKit.dp(c,5),0,0,0);
        line.addView(texts,tp);
        texts.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        // A directional cue makes navigation affordance obvious in the RTL layout.
        TextView arrow=heading(c,"‹");
        arrow.setTextColor(UiKit.GOLD);
        arrow.setTextSize(23f);
        arrow.setGravity(Gravity.CENTER);
        arrow.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        line.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(c,20),UiKit.dp(c,44)));
        destination(c,line,title+"؛ "+subtitle,UiKit.GOLD);
        return line;
    }
    static TextView directoryLink(Context c,String label){
        TextView t=heading(c,label);t.setGravity(Gravity.CENTER);
        t.setTextColor(0xFFDBE6F7);t.setTextSize(14f);
        t.setMinHeight(UiKit.dp(c,52));t.setFocusable(true);
        t.setBackground(shape(c,0xFF263D60,0xFF557FB9,16));
        UiKit.touchFeedback(c,t,UiKit.PURPLE,16);
        t.setContentDescription("باز کردن فهرست همه بخش‌ها و ابزارهای Nexa");
        return t;
    }
}
