package com.example.silenttimer;
import android.provider.Settings;
import android.os.PowerManager;
import android.app.NotificationManager;
import android.app.AlarmManager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.Manifest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_APP_UNLOCK=810;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean startupDone=false;
    private boolean permissionRepairShown=false;
    private boolean awaitingUnlock=false;
    private RingTimerView ring;
    private TextView heroTime,heroState,heroSub,todaySummary,attentionSummary,nextReminderSummary,nextOccasionSummary;
    private LinearLayout attentionCard;
    private android.widget.ProgressBar focusProgress;
    private TextView financeDebtValue,financeCreditValue;
    private Button stopTimerButton;
    private long lastOverviewRefresh=0L;
    private long lastFinanceRefresh=0L;

    private final Runnable ticker=new Runnable(){
        @Override public void run(){
            refresh();
            handler.postDelayed(this,1000);
        }
    };

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        AppPrefs.applyLaunchSafetyMigration(this);
        continueStartup();
    }

    private void continueStartup(){
        if(startupDone||isFinishing())return;
        if(NexaStore.lockEnabled(this)&&!SecurityGate.isUnlocked()){
            if(!awaitingUnlock){
                awaitingUnlock=true;
                startActivityForResult(new Intent(this,UnlockActivity.class),REQ_APP_UNLOCK);
            }
            return;
        }
        startupDone=true;
        boolean first=!AppPrefs.isSetupCompleted(this);
        if(!first)ensureMonitor();
        build();
        if(!NexaStore.accountConfigured(this)){
            startActivityForResult(new Intent(this,AccountSetupActivity.class),811);
        }else if(first){
            startPermissionSetup();
        }
    }

    private void startPermissionSetup(){
        Intent i=new Intent(this,SettingsActivity.class);
        i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
        startActivity(i);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==REQ_APP_UNLOCK){
            awaitingUnlock=false;
            if(result==RESULT_OK&&SecurityGate.isUnlocked()) continueStartup();
            else finish();
            return;
        }
        if(request==811){
            if(!NexaStore.accountConfigured(this)){
                // Keep setup mandatory without saving an incomplete/invalid profile.
                finish();return;
            }
            if(!AppPrefs.isSetupCompleted(this))startPermissionSetup();
        }
    }

    @Override protected void onResume(){
        super.onResume();
        lastFinanceRefresh=0;
        lastOverviewRefresh=0;
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        TodayNotificationManager.refresh(this);
        handler.postDelayed(this::checkCriticalPermissions,450);
    }

    /**
     * Special Android permissions cannot legally be made permanent by an app.
     * Nexa therefore verifies the real OS state on every foreground entry and,
     * if Android/One UI has revoked one, opens the existing guided repair flow.
     */
    private void checkCriticalPermissions(){
        if(isFinishing()||!AppPrefs.isSetupCompleted(this)||permissionRepairShown)return;
        NotificationManager nm=(NotificationManager)getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        AlarmManager am=(AlarmManager)getSystemService(android.content.Context.ALARM_SERVICE);
        PowerManager pm=(PowerManager)getSystemService(android.content.Context.POWER_SERVICE);
        boolean notifications=Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED;
        boolean exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms();
        boolean full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent();
        boolean battery=pm.isIgnoringBatteryOptimizations(getPackageName());
        boolean dnd=nm.isNotificationPolicyAccessGranted();
        if(notifications&&exact&&full&&battery&&dnd)return;
        permissionRepairShown=true;
        new android.app.AlertDialog.Builder(this)
            .setTitle("یک دسترسی Nexa غیرفعال شده")
            .setMessage("Android یا One UI یکی از دسترسی‌های ضروری هشدارها را غیرفعال کرده است. Nexa خودش هیچ دسترسی تأییدشده‌ای را حذف نمی‌کند. برای حفظ هشدار دارو، یادآورها و Lock Screen، وضعیت واقعی سیستم را دوباره تأیید کن.")
            .setPositiveButton("بررسی و فعال‌سازی",(d,w)->{Intent i=new Intent(this,SettingsActivity.class);i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);startActivity(i);})
            .setNegativeButton("بعداً",null)
            .show();
    }

    @Override protected void onPause(){
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    /** Build 188: information-first home screen. All destinations and data sources are preserved.
     * Native layouts reflow for small screens and large Android font scales. */
    private void build(){
        LinearLayout screen=new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        screen.setBackground(UiKit.screenBackground(this));

        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);
        sc.setVerticalScrollBarEnabled(false);
        sc.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,12),UiKit.dp(this,10),UiKit.dp(this,12),UiKit.dp(this,16));
        sc.addView(root);

        // One compact header, clear branding, no duplicate quick-add action.
        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand=new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo=UiKit.title(this,"Nexa");
        logo.setTextSize(25);logo.setTextColor(UiKit.GOLD);
        brand.addView(logo);
        TextView brandCaption=HomeUi.secondary(this,"دستیار هوشمند شخصی");
        brandCaption.setTextSize(12f);
        brand.addView(brandCaption);
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1f));
        Button mic=UiKit.iconButton(this,"🎙️","ثبت با صدا",UiKit.TEAL);
        mic.setOnClickListener(v->startActivity(new Intent(this,VoiceQuickAddActivity.class)));
        head.addView(mic,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        // One-tap global search. The directory and all existing modules stay available.
        Button globalSearch=UiKit.iconButton(this,"🔎","جست‌وجوی سراسری",UiKit.TEAL);
        globalSearch.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        LinearLayout.LayoutParams searchParams=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        searchParams.setMargins(UiKit.dp(this,6),0,0,0);
        head.addView(globalSearch,searchParams);
        Button settings=UiKit.iconButton(this,"⚙️","تنظیمات",UiKit.GOLD);
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        LinearLayout.LayoutParams settingParams=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        settingParams.setMargins(UiKit.dp(this,8),0,0,0);
        head.addView(settings,settingParams);
        root.addView(head,UiKit.matchWrap(this,0,10));

        // Premium dashboard: never show invented balances or budget figures.
        LinearLayout overview=HomeUi.panel(this,true);
        TextView overviewTitle=UiKit.title(this,"داشبورد Nexa");
        overviewTitle.setTextSize(18f);
        overview.addView(overviewTitle,UiKit.matchWrap(this,0,3));
        TextView overviewCaption=HomeUi.secondary(this,"مدیریت هوشمند زمان، برنامه‌ها و امور مالی");
        overviewCaption.setTextSize(12.5f);
        overview.addView(overviewCaption,UiKit.matchWrap(this,0,8));
        root.addView(overview,UiKit.matchWrap(this,0,8));

        // Timer is a single complete interaction, not a giant empty status card.
        LinearLayout focus=HomeUi.panel(this,true);
        LinearLayout focusHeader=new LinearLayout(this);
        focusHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView focusTitle=HomeUi.heading(this,"◉  تمرکز و سکوت");
        focusHeader.addView(focusTitle,new LinearLayout.LayoutParams(0,-2,1f));
        heroState=HomeUi.badge(this,"آماده",UiKit.TEAL);
        focusHeader.addView(heroState);
        focus.addView(focusHeader,UiKit.matchWrap(this,0,5));
        heroTime=UiKit.title(this,"برای شروع یک زمان انتخاب کن");
        heroTime.setTextSize(19f);
        heroTime.setGravity(Gravity.RIGHT);
        heroTime.setMaxLines(2);
        focus.addView(heroTime,UiKit.matchWrap(this,3,4));
        heroSub=HomeUi.secondary(this,"انتخاب زمان، حالت بی‌صدا را فعال می‌کند");
        heroSub.setTextSize(12.5f);
        focus.addView(heroSub,UiKit.matchWrap(this,0,8));
        focusProgress=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        focusProgress.setMax(1000);
        focusProgress.setVisibility(View.GONE);
        focusProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(UiKit.GOLD));
        focus.addView(focusProgress,new LinearLayout.LayoutParams(-1,UiKit.dp(this,3)));
        ring=new RingTimerView(this);
        ring.setVisibility(View.GONE);
        LinearLayout quickTimers=new LinearLayout(this);
        float screenWidthDp=getResources().getDisplayMetrics().widthPixels/
                getResources().getDisplayMetrics().density;
        float contentWidthDp=screenWidthDp-64f; // page and focus-card horizontal insets
        float fontScale=getResources().getConfiguration().fontScale;
        boolean verticalPresets=HomeTimerLayoutPolicy.stackPresets(contentWidthDp,fontScale);
        quickTimers.setOrientation(verticalPresets?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        quickTimers.setGravity(Gravity.CENTER_VERTICAL);
        quickTimers.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addQuick(quickTimers,"۱۵ دقیقه",15);
        addQuick(quickTimers,"۳۰ دقیقه",30);
        addQuick(quickTimers,"۱ ساعت",60);
        focus.addView(quickTimers,UiKit.matchWrap(this,11,0));

        // Stop is only presented for a running timer, and never stops silently.
        stopTimerButton=UiKit.secondaryButton(this,"■ توقف تایمر فعال");
        stopTimerButton.setTextColor(UiKit.RED);
        stopTimerButton.setContentDescription("توقف تایمر فعال و بازگرداندن حالت صدای قبلی");
        stopTimerButton.setVisibility(View.GONE);
        stopTimerButton.setOnClickListener(v->confirmStopTimer());
        focus.addView(stopTimerButton,UiKit.matchWrap(this,10,0));
        root.addView(focus,UiKit.matchWrap(this,0,12));

        // Today's overview: one tap to a complete, existing timeline.
        LinearLayout today=HomeUi.panel(this,false);
        LinearLayout todayHeader=HomeUi.headerRow(this,"✨  امروز در Nexa","مشاهده  ‹");
        today.addView(todayHeader);
        todaySummary=HomeUi.secondary(this,"");
        todaySummary.setTextSize(14f);
        todaySummary.setMaxLines(3);
        today.addView(todaySummary,UiKit.matchWrap(this,8,2));
        nextReminderSummary=HomeUi.secondary(this,"");
        nextReminderSummary.setTextSize(12f);
        nextReminderSummary.setMaxLines(2);
        nextReminderSummary.setVisibility(View.GONE);
        today.addView(nextReminderSummary,UiKit.matchWrap(this,3,0));
        // A tappable, unobtrusive link only when an active occasion exists.
        nextOccasionSummary=HomeUi.secondary(this,"");
        nextOccasionSummary.setTextSize(12.5f);
        nextOccasionSummary.setTextColor(UiKit.GOLD);
        nextOccasionSummary.setMaxLines(2);
        nextOccasionSummary.setMinHeight(UiKit.dp(this,48));
        nextOccasionSummary.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        nextOccasionSummary.setVisibility(View.GONE);
        nextOccasionSummary.setContentDescription("مشاهده نزدیک‌ترین مناسبت سالانه");
        nextOccasionSummary.setFocusable(true);
        UiKit.touchFeedback(this,nextOccasionSummary,UiKit.GOLD,12);
        nextOccasionSummary.setOnClickListener(v->startActivity(new Intent(this,AnnualOccasionsActivity.class)));
        today.addView(nextOccasionSummary,UiKit.matchWrap(this,2,0));
        HomeUi.destination(this,today,"خلاصه امروز؛ مشاهده جزئیات",UiKit.BLUE);
        today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        // Keep the occasion shortcut independently reachable by accessibility services.
        nextOccasionSummary.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_YES);
        root.addView(today,UiKit.matchWrap(this,0,12));

        // Financial balances respect exact amount rendering and original debt/credit colors.
        TextView financeHeading=HomeUi.sectionLabel(this,"وضعیت مالی");
        if(android.os.Build.VERSION.SDK_INT>=28)financeHeading.setAccessibilityHeading(true);
        root.addView(financeHeading,UiKit.matchWrap(this,0,7));
        LinearLayout financeRow=new LinearLayout(this);
        financeRow.setOrientation(LinearLayout.HORIZONTAL);
        financeRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout debtCard=HomeUi.balanceCard(this,"بدهی من",UiKit.RED);
        financeDebtValue=HomeUi.money(this,"۰ تومان",UiKit.RED);
        debtCard.addView(financeDebtValue,UiKit.matchWrap(this,7,0));
        HomeUi.destination(this,debtCard,"بدهی من؛ مشاهده جزئیات در حسابداری",UiKit.RED);
        debtCard.setOnClickListener(v->startActivity(new Intent(this,LedgerActivity.class)));
        LinearLayout creditCard=HomeUi.balanceCard(this,"طلب من",UiKit.GOLD);
        financeCreditValue=HomeUi.money(this,"۰ تومان",UiKit.GOLD);
        creditCard.addView(financeCreditValue,UiKit.matchWrap(this,7,0));
        HomeUi.destination(this,creditCard,"طلب من؛ مشاهده جزئیات در حسابداری",UiKit.GOLD);
        creditCard.setOnClickListener(v->startActivity(new Intent(this,LedgerActivity.class)));
        boolean stackCards=HomeUi.shouldStack(this);
        if(stackCards){
            financeRow.setOrientation(LinearLayout.VERTICAL);
            financeRow.addView(debtCard,UiKit.matchWrap(this,0,8));
            financeRow.addView(creditCard,UiKit.matchWrap(this));
        }else{
            LinearLayout.LayoutParams debitParams=new LinearLayout.LayoutParams(0,-2,1f);
            debitParams.setMargins(0,0,UiKit.dp(this,5),0);
            financeRow.addView(debtCard,debitParams);
            LinearLayout.LayoutParams creditParams=new LinearLayout.LayoutParams(0,-2,1f);
            creditParams.setMargins(UiKit.dp(this,5),0,0,0);
            financeRow.addView(creditCard,creditParams);
        }
        root.addView(financeRow,UiKit.matchWrap(this,0,12));

        // An empty alert block should never waste space on the main screen.
        attentionCard=HomeUi.panel(this,false);
        attentionCard.addView(HomeUi.heading(this,"⚡  نیازمند توجه"));
        attentionSummary=HomeUi.secondary(this,"");
        attentionSummary.setTextSize(13f);
        attentionCard.addView(attentionSummary,UiKit.matchWrap(this,6,0));
        HomeUi.destination(this,attentionCard,"موارد نیازمند توجه؛ مشاهده در صفحه امروز",UiKit.RED);
        attentionCard.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        root.addView(attentionCard,UiKit.matchWrap(this,0,12));

        LinearLayout shortcutsHeading=HomeUi.headerRow(this,"دسترسی سریع","ابزارهای پرکاربرد");
        shortcutsHeading.setContentDescription("دسترسی سریع به ابزارهای پرکاربرد");
        root.addView(shortcutsHeading,UiKit.matchWrap(this,1,9));
        addFeatureRow(root,
                new Feature("📅","یادآورها","هشدارها و برنامه‌ها",RemindersActivity.class,1),
                new Feature("🎂","مناسبت‌ها","تولد، ازدواج و سالگردها",AnnualOccasionsActivity.class,1));
        addFeatureRow(root,
                new Feature("💳","حسابداری","بدهی، طلب و پرداخت",LedgerActivity.class,1),
                new Feature("📋","فهرست‌ها","کارها و لیست‌ها",NexaListActivity.class,1));
        // Keep the most useful daily destinations directly accessible.
        // These open existing screens and do not change stored data.
        addFeatureRow(root,
                new Feature("🔎","جست‌وجو","پیدا کردن اطلاعات و موارد",SearchActivity.class,1),
                new Feature("🕒","خط زمان","رویدادها و فعالیت‌های ثبت‌شده",TimelineActivity.class,1));
        TextView all=HomeUi.directoryLink(this,"☷  مشاهده همه بخش‌ها و ابزارها");
        all.setContentDescription("نمایش فهرست کامل ابزارها و بخش‌های Nexa");
        all.setClickable(true);
        all.setFocusable(true);
        all.setMinimumHeight(UiKit.dp(this,48));
        all.setOnClickListener(v->showAllFeatures());
        root.addView(all,UiKit.matchWrap(this,2,1));

        LinearLayout bottom=UiKit.bottomNav(this,0,
                v->{},
                v->startActivity(new Intent(this,TodayActivity.class)),
                v->startActivity(new Intent(this,QuickAddActivity.class)),
                v->startActivity(new Intent(this,TimelineActivity.class)));
        LinearLayout.LayoutParams bp=UiKit.matchWrap(this);
        bp.setMargins(UiKit.dp(this,16),0,UiKit.dp(this,16),UiKit.dp(this,9));
        attachHomeContent(screen,sc,bottom,bp);
        setContentView(screen);
        refresh();
    }

    // Package-private for an Android instrumentation regression test.  The
    // content MUST be added before navigation, otherwise the app opens empty.
    static void attachHomeContent(LinearLayout screen, ScrollView sc, View bottom,
                                  LinearLayout.LayoutParams bottomParams){
        if(screen==null || sc==null || bottom==null || bottomParams==null)
            throw new IllegalArgumentException("Home layout is incomplete");
        if(screen.getOrientation()!=LinearLayout.VERTICAL)
            throw new IllegalArgumentException("Home needs vertical layout");
        if(sc.getChildCount()==0)
            throw new IllegalArgumentException("Home dashboard has no content");
        screen.addView(sc,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,0,1f));
        screen.addView(bottom,bottomParams);
    }

    /** Full-screen directory replaces the cramped nested popup; all 22 entries remain reachable. */
    private void showAllFeatures(){
        startActivity(new Intent(this,ModulesActivity.class));
    }

    private static final class Feature{
        String icon,title,sub;
        Class<?> cls;
        int v;
        Feature(String i,String t,String s,Class<?>c,int x){
            icon=i;title=t;sub=s;cls=c;v=x;
        }
    }

    private void addFeatureRow(LinearLayout root,Feature a,Feature b){
        if(a==null&&b==null)return;
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(HomeUi.shouldStack(this)?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if(HomeUi.shouldStack(this)){
            if(a!=null)row.addView(tile(a),UiKit.matchWrap(this,0,8));
            if(b!=null)row.addView(tile(b),UiKit.matchWrap(this));
        }else{
            if(a!=null){
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
                p.setMargins(0,0,UiKit.dp(this,5),0);
                row.addView(tile(a),p);
            }
            if(b!=null){
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
                p.setMargins(UiKit.dp(this,5),0,0,0);
                row.addView(tile(b),p);
            }
        }
        root.addView(row,UiKit.matchWrap(this,0,9));
    }

    private View tile(Feature f){
        LinearLayout tile=HomeUi.shortcut(this,f.icon,f.title,f.sub);
        // Make dashboard shortcuts accessible with TalkBack and keyboard navigation.
        tile.setContentDescription("باز کردن "+f.title+"، "+f.sub);
        tile.setClickable(true);
        tile.setFocusable(true);
        tile.setMinimumHeight(UiKit.dp(this,76));
        tile.setOnClickListener(v->startActivity(new Intent(this,f.cls)));
        return tile;
    }

    private void addQuick(LinearLayout row,String text,int min){
        TextView chip=UiKit.chip(this,text,false);
        chip.setMinHeight(UiKit.dp(this,46));
        chip.setTextSize(13.5f);
        chip.setContentDescription("شروع تایمر "+text);
        chip.setMinimumHeight(UiKit.dp(this,48));
        chip.setClickable(true);
        chip.setFocusable(true);
        UiKit.touchFeedback(this,chip,UiKit.TEAL,18);
        LinearLayout.LayoutParams p;
        if(row.getOrientation()==LinearLayout.VERTICAL){
            p=new LinearLayout.LayoutParams(-1,UiKit.dp(this,48));
            p.setMargins(0,row.getChildCount()==0?0:UiKit.dp(this,6),0,0);
        }else{
            p=new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f);
            p.setMargins(UiKit.dp(this,4),0,UiKit.dp(this,4),0);
        }
        row.addView(chip,p);

        chip.setOnClickListener(v->{
            if(!AppPrefs.isSetupCompleted(this)){
                Intent i=new Intent(this,SettingsActivity.class);
                i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
                startActivity(i);
                return;
            }

            Intent i=new Intent(this,SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_START);
            i.putExtra(SilentTimerService.EXTRA_MINUTES,min);
            i.putExtra(SilentTimerService.EXTRA_TARGET_MODE,AudioManager.RINGER_MODE_SILENT);

            try{
                if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
                else startService(i);
                // Starting a service is asynchronous: never claim it is active until refresh confirms it.
                Toast.makeText(this,"درخواست شروع تایمر ارسال شد.",Toast.LENGTH_SHORT).show();
            }catch(Exception startError){
                Toast.makeText(this,"شروع تایمر انجام نشد؛ دسترسی‌های برنامه را بررسی کن.",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void confirmStopTimer(){
        if(AppPrefs.getEndAt(this)<=System.currentTimeMillis())return;
        new AlertDialog.Builder(this)
                .setTitle("توقف تایمر؟")
                .setMessage("تایمر فعال متوقف می‌شود و Nexa برای بازگرداندن حالت صدای قبلی تلاش می‌کند.")
                .setNegativeButton("انصراف",null)
                .setPositiveButton("توقف تایمر",(dialog,which)->{
                    if(AppPrefs.getEndAt(this)<=System.currentTimeMillis())return;
                    Intent stop=new Intent(this,SilentTimerService.class);
                    stop.setAction(SilentTimerService.ACTION_STOP);
                    stop.putExtra(SilentTimerService.EXTRA_RESTORE_PREVIOUS,true);
                    try{
                        // Foreground Activity: dispatch to the existing service, which
                        // remains solely responsible for restoring the audio state.
                        startService(stop);
                        Toast.makeText(this,"درخواست توقف تایمر ارسال شد.",Toast.LENGTH_SHORT).show();
                        handler.postDelayed(this::refresh,650);
                    }catch(RuntimeException e){
                        Toast.makeText(this,"توقف تایمر انجام نشد؛ دوباره تلاش کن.",Toast.LENGTH_LONG).show();
                    }
                }).show();
    }

    private void refresh(){
        if(heroTime==null)return;

        long now=System.currentTimeMillis();
        long end=AppPrefs.getEndAt(this);
        long start=AppPrefs.getStartAt(this);

        if(stopTimerButton!=null)
            stopTimerButton.setVisibility(end>now?View.VISIBLE:View.GONE);
        if(end>now){
            long rem=end-now,sec=rem/1000,h=sec/3600,m=(sec%3600)/60,s=sec%60;
            heroState.setText("● فعال");
            heroTime.setTextDirection(View.TEXT_DIRECTION_LTR);
            heroTime.setTypeface(android.graphics.Typeface.MONOSPACE,android.graphics.Typeface.BOLD);
            heroTime.setTextSize(27f);
            heroTime.setText(h>0
                    ?String.format(Locale.US,"%02d:%02d:%02d",h,m,s)
                    :String.format(Locale.US,"%02d:%02d",m,s));
            heroSub.setText(
                    (AppPrefs.getTargetRingerMode(this)==AudioManager.RINGER_MODE_VIBRATE?"لرزش":"بی‌صدا")+
                            " • پایان "+
                            new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(end))
            );
            float prog=0;
            if(start>0&&end>start)prog=1f-(float)rem/(float)(end-start);
            ring.setProgress(prog);
            if(focusProgress!=null){focusProgress.setVisibility(View.VISIBLE);focusProgress.setProgress(Math.round(Math.max(0,Math.min(1,prog))*1000));}
        }else{
            if(!"آماده".contentEquals(heroState.getText()))heroState.setText("آماده");
            if(!"برای شروع یک زمان انتخاب کن".contentEquals(heroTime.getText()))
                heroTime.setText("برای شروع یک زمان انتخاب کن");
            heroTime.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
            heroTime.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
            heroTime.setTextSize(19f);
            if(!"انتخاب زمان، حالت بی‌صدا را فعال می‌کند".contentEquals(heroSub.getText()))
                heroSub.setText("انتخاب زمان، حالت بی‌صدا را فعال می‌کند");
            if(focusProgress!=null)focusProgress.setVisibility(View.GONE);
            ring.setProgress(0);
        }

        // Timer changes every second, but the dashboard's stored collections do not.
        // Re-read them on foreground entry and at a modest interval to avoid jank.
        if(!HomeRefreshGate.due(now,lastOverviewRefresh,HomeRefreshGate.OVERVIEW_MS))return;
        lastOverviewRefresh=now;
        int upcoming=0;
        NexaStore.Reminder closest=null;
        long closestDue=Long.MAX_VALUE;
        List<NexaStore.Reminder> storedReminders=NexaStore.reminders(this);
        for(NexaStore.Reminder r:storedReminders){
            if(!r.active || r.done || r.whenMillis<=0)continue;
            // Recurring reminders with a historical original date can have
            // future occurrences even before their original record is advanced.
            long due=r.whenMillis;
            if(due<=now && ReminderRecurrence.isRecurring(r.recurrence))
                due=ReminderRecurrence.after(r.whenMillis,r.recurrence,now);
            if(due>now){
                if(due<=now+24L*60L*60L*1000L)upcoming++;
                if(due<closestDue){closest=r;closestDue=due;}
            }
        }
        // Preview is calculated from original annual dates; the preview never
        // re-schedules alarms and never edits any stored records.
        if(nextOccasionSummary!=null){
            HomeOccasionPolicy.Match next=HomeOccasionPolicy.closest(OccasionStore.all(this),now);
            if(next==null){
                nextOccasionSummary.setVisibility(View.GONE);
            }else{
                nextOccasionSummary.setText(next.occasion.icon()+" مناسبت بعدی: "+next.occasion.title+
                        " • "+PersianDateUtil.pretty(next.due)+"   ›");
                nextOccasionSummary.setVisibility(View.VISIBLE);
            }
        }
        if(nextReminderSummary!=null){
            if(closest==null){
                nextReminderSummary.setVisibility(View.GONE);
            }else{
                nextReminderSummary.setText("نوبت بعدی: "+closest.title+" • "+PersianDateUtil.pretty(closestDue));
                nextReminderSummary.setVisibility(View.VISIBLE);
            }
        }

        int meds=0;
        for(NexaStore.Medicine m:NexaStore.medicines(this))if(m.active)meds++;

        int tasks=0;
        for(NexaStore.TodoItem t:NexaStore.todos(this))if(!t.done)tasks++;

        int bills=0;
        for(NexaStore.BillItem b:NexaStore.bills(this))if(!b.paid)bills++;

        todaySummary.setText(translateDigits(upcoming)+" یادآور   •   "+translateDigits(meds)+" دارو\n"+
                translateDigits(tasks)+" کار   •   "+translateDigits(bills)+" پرداخت");
        if(financeDebtValue!=null && financeCreditValue!=null
                && HomeRefreshGate.due(now,lastFinanceRefresh,HomeRefreshGate.FINANCE_MS)){
            lastFinanceRefresh=now;
            long owed=0,receivable=0;
            for(NexaStore.LedgerParty p:NexaStore.ledgerParties(this)){
                long balance=NexaStore.ledgerBalance(this,p.id);
                if(balance<0)owed+=balance==Long.MIN_VALUE?Long.MAX_VALUE:-balance;
                else if(balance>0)receivable+=balance;
            }
            financeDebtValue.setText(PersianFinancialDisplay.amount(owed)+" تومان");
            financeCreditValue.setText(PersianFinancialDisplay.amount(receivable)+" تومان");
        }

        if(attentionSummary!=null){
            int overdueReminders=0, overdueBills=0, expiringDocs=0, dueHome=0, dueTodos=0;
            long next30=now+30L*24L*60L*60L*1000L;
            for(NexaStore.Reminder r:storedReminders)
                if(r.active&&!r.done&&AgendaDuePolicy.overdueForAttention(
                        r.whenMillis,r.recurrence,now))overdueReminders++;
            for(NexaStore.BillItem b:NexaStore.bills(this))
                if(!b.paid&&b.dueDate>0&&b.dueDate<now)overdueBills++;
            for(NexaStore.DocumentItem d:NexaStore.documents(this))
                if(d.expiryDate>0&&d.expiryDate<=next30)expiringDocs++;
            for(NexaStore.HomeItem h:NexaStore.homeItems(this))
                if(h.nextDueDate>0&&h.nextDueDate<=next30)dueHome++;
            for(NexaStore.TodoItem t:NexaStore.todos(this))
                if(!t.done&&t.dueMillis>0&&t.dueMillis<now)dueTodos++;
            int total=overdueReminders+overdueBills+expiringDocs+dueHome+dueTodos;
            // No empty warning card on a healthy dashboard; save vertical space.
            if(attentionCard!=null)attentionCard.setVisibility(total==0?View.GONE:View.VISIBLE);
            if(total==0) attentionSummary.setText("✓ مورد فوری یا نزدیک به سررسید وجود ندارد.");
            else attentionSummary.setText(
                    "🔴 "+overdueReminders+" یادآور معوق  •  💳 "+overdueBills+" پرداخت معوق\n"+
                    "📄 "+expiringDocs+" مدرک منقضی/۳۰روزه  •  🏠 "+dueHome+" سرویس خانه\n"+
                    "✓ "+dueTodos+" کار عقب‌افتاده  •  مجموع: "+total
            );
        }
    }

    private static String translateDigits(int value){
        return String.valueOf(value).replace('0','۰').replace('1','۱').replace('2','۲')
                .replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶')
                .replace('7','۷').replace('8','۸').replace('9','۹');
    }

    private void ensureMonitor(){
        if(!AppPrefs.isMonitoringEnabled(this))return;

        Intent i=new Intent(this,SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_MONITOR);

        try{
            if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
            else startService(i);
        }catch(Exception ignored){}

        ReminderScheduler.rescheduleAll(this);
        EmergencyCardManager.refresh(this);
    }
}
