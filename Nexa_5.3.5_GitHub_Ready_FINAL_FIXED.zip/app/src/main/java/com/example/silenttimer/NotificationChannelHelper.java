package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public final class NotificationChannelHelper {
    private NotificationChannelHelper(){}
    public static void ensureMedicine(Context c){
        if(Build.VERSION.SDK_INT<26)return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch=new NotificationChannel(MedicineAlarmReceiver.CHANNEL,"Nexa Medicine Alarm",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("هشدار زنگ‌دار دارو؛ تا تأیید کاربر هر ۵ دقیقه تکرار می‌شود");
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,700,350,700,350,1000});
        Uri sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        ch.setSound(sound,attrs);ch.setBypassDnd(false);nm.createNotificationChannel(ch);
    }
}
