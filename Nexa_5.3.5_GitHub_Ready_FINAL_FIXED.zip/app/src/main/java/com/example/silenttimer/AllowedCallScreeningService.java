package com.example.silenttimer;

import android.content.Context;
import android.media.AudioManager;
import android.telecom.Call;
import android.telecom.CallScreeningService;

public class AllowedCallScreeningService extends CallScreeningService {
    @Override
    public void onScreenCall(Call.Details callDetails) {
        String number = "";

        if (callDetails.getHandle() != null) {
            number = callDetails.getHandle().getSchemeSpecificPart();
        }

        if (AppPrefs.isAllowedNumber(this, number)) {
            AudioManager am =
                    (AudioManager) getSystemService(Context.AUDIO_SERVICE);

            int restoreMode;

            if (AppPrefs.isTimerActive(this)) {
                restoreMode = AppPrefs.getTargetRingerMode(this);
            } else {
                restoreMode = am.getRingerMode();
            }

            if (restoreMode == AudioManager.RINGER_MODE_SILENT ||
                    restoreMode == AudioManager.RINGER_MODE_VIBRATE) {
                AppPrefs.setBypassRestoreMode(this, restoreMode);
                AppPrefs.setBypassActive(this, true);
                AppPrefs.setIgnoreManualUntil(
                        this,
                        System.currentTimeMillis() + 5000L
                );

                try {
                    am.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                } catch (SecurityException ignored) {}
            }
        }

        respondToCall(
                callDetails,
                new CallResponse.Builder().build()
        );
    }
}
