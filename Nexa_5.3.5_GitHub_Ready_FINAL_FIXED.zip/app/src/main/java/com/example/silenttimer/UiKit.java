package com.example.silenttimer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class UiKit {
    private UiKit() {}

    public static final int THEME_OBSIDIAN = 0;

    // Core Obsidian palette
    public static final int BG_1 = 0xFF04050A;
    public static final int BG_2 = 0xFF090A12;
    public static final int BG_3 = 0xFF0D101A;
    public static final int CARD_1 = 0xFF12141D;
    public static final int CARD_2 = 0xFF181A25;
    public static final int TEXT = 0xFFF8F9FF;
    public static final int MUTED = 0xFF9DA3B5;
    public static final int FIELD = 0xFF1E202B;

    public static final int PURPLE = 0xFF8B5CF6;
    public static final int VIOLET = 0xFF6D5DFB;
    public static final int CYAN = 0xFF22D3EE;
    public static final int TEAL = 0xFF2DD4BF;
    public static final int PINK = 0xFFF472B6;
    public static final int BLUE = 0xFF60A5FA;
    public static final int GOLD = 0xFFFBBF24;
    public static final int ORANGE = 0xFFFB923C;
    public static final int RED = 0xFFFB7185;
    public static final int GREEN = 0xFF34D399;
    public static final int INDIGO = 0xFF818CF8;

    // Compatibility with existing callers:
    // bgTop, bgBottom, card, text, accent, muted, field, accent2
    private static final int[] OBSIDIAN = new int[]{
            BG_1, BG_2, CARD_1, TEXT, PURPLE, MUTED, FIELD, TEAL
    };

    public static int[] palette(Context c) {
        return OBSIDIAN;
    }

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static GradientDrawable screenBackground(Context c) {
        return new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{BG_1, 0xFF090B14, 0xFF100A18, BG_2}
        );
    }

    public static GradientDrawable rounded(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    private static Drawable layeredPanel(
            Context c,
            int[] borderColors,
            int[] fillColors,
            int radiusDp,
            int borderDp
    ) {
        GradientDrawable outer = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                borderColors
        );
        outer.setCornerRadius(dp(c, radiusDp));

        GradientDrawable inner = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                fillColors
        );
        inner.setCornerRadius(dp(c, Math.max(1, radiusDp - 2)));

        LayerDrawable layers = new LayerDrawable(
                new Drawable[]{outer, inner}
        );

        int inset = dp(c, borderDp);
        layers.setLayerInset(1, inset, inset, inset, inset);
        return layers;
    }

    public static Drawable card(Context c) {
        return layeredPanel(
                c,
                new int[]{
                        withAlpha(PURPLE, 0xB0),
                        withAlpha(BLUE, 0x80),
                        withAlpha(CYAN, 0x70),
                        withAlpha(TEAL, 0x90)
                },
                new int[]{CARD_2, CARD_1, 0xFF10121A},
                27,
                1
        );
    }

    public static Drawable colorfulCard(Context c, int variant) {
        int[] border;
        int[] fill;

        // Each module/card family gets a visibly different surface as well as a different border.
        // This avoids the "same black card with another outline" look and reduces eye fatigue.
        switch (Math.floorMod(variant, 8)) {
            case 1:
                border = new int[]{withAlpha(CYAN,0xD0),withAlpha(BLUE,0xB0),withAlpha(INDIGO,0xA0)};
                fill = new int[]{0xFF10202A,0xFF101827,0xFF11121D};
                break;
            case 2:
                border = new int[]{withAlpha(TEAL,0xD0),withAlpha(GREEN,0xA0),withAlpha(CYAN,0x80)};
                fill = new int[]{0xFF10231F,0xFF11201C,0xFF10171A};
                break;
            case 3:
                border = new int[]{withAlpha(PINK,0xC0),withAlpha(PURPLE,0xB0),withAlpha(RED,0x80)};
                fill = new int[]{0xFF231421,0xFF1D1425,0xFF15131D};
                break;
            case 4:
                border = new int[]{withAlpha(GOLD,0xD0),withAlpha(ORANGE,0xB0),withAlpha(PINK,0x70)};
                fill = new int[]{0xFF241D12,0xFF201713,0xFF17141A};
                break;
            case 5:
                border = new int[]{withAlpha(RED,0xD0),withAlpha(ORANGE,0xA0),withAlpha(GOLD,0x80)};
                fill = new int[]{0xFF271518,0xFF211714,0xFF171418};
                break;
            case 6:
                border = new int[]{withAlpha(INDIGO,0xD0),withAlpha(PURPLE,0xA0),withAlpha(BLUE,0x90)};
                fill = new int[]{0xFF17172A,0xFF171323,0xFF12151E};
                break;
            case 7:
                border = new int[]{withAlpha(GREEN,0xC0),withAlpha(TEAL,0xB0),withAlpha(GOLD,0x70)};
                fill = new int[]{0xFF162319,0xFF11211D,0xFF171812};
                break;
            default:
                border = new int[]{withAlpha(PURPLE,0xD0),withAlpha(VIOLET,0xB0),withAlpha(TEAL,0xA0)};
                fill = new int[]{0xFF201629,0xFF171528,0xFF10181C};
                break;
        }

        return layeredPanel(c,border,fill,27,1);
    }

    public static Drawable field(Context c) {
        return layeredPanel(
                c,
                new int[]{
                        withAlpha(PURPLE, 0x60),
                        withAlpha(CYAN, 0x55)
                },
                new int[]{FIELD, 0xFF191B25},
                18,
                1
        );
    }

    public static Drawable accentCard(Context c) {
        return layeredPanel(
                c,
                new int[]{
                        PURPLE,
                        VIOLET,
                        BLUE,
                        CYAN,
                        TEAL,
                        PINK
                },
                new int[]{
                        0xFF171321,
                        0xFF111725,
                        0xFF0E171B
                },
                31,
                2
        );
    }

    public static Drawable bottomNavBackground(Context c) {
        return layeredPanel(
                c,
                new int[]{
                        withAlpha(PURPLE, 0xB0),
                        withAlpha(CYAN, 0x80),
                        withAlpha(TEAL, 0x90)
                },
                new int[]{0xFA14161F, 0xFA0E1017},
                25,
                1
        );
    }

    public static TextView title(Context c, String text) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(TEXT);
        tv.setTextSize(30f);
        tv.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        tv.setGravity(Gravity.RIGHT);
        tv.setLetterSpacing(0.01f);
        return tv;
    }

    public static TextView sectionTitle(Context c, String text) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(TEXT);
        tv.setTextSize(17f);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static TextView muted(Context c, String text) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(MUTED);
        tv.setTextSize(13f);
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static LinearLayout cardLayout(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        card.setBackground(card(c));
        card.setElevation(dp(c, 4));
        return card;
    }

    public static LinearLayout colorfulCardLayout(Context c, int variant) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        card.setBackground(colorfulCard(c, variant));
        card.setElevation(dp(c, 4));
        return card;
    }

    public static Button primaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15f);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setMinHeight(dp(c, 50));

        String t=text==null?"":text.trim();
        int[] colors;
        if(t.contains("باز") || t.contains("مشاهده") || t.contains("دفترچه"))
            colors=new int[]{0xFF0E7490, BLUE, CYAN};
        else if(t.contains("افزود") || t.contains("جدید") || t.startsWith("＋") || t.startsWith("➕"))
            colors=new int[]{0xFF047857, GREEN, TEAL};
        else if(t.contains("حذف") || t.contains("پاک") || t.contains("خاموش"))
            colors=new int[]{0xFF9F1239, RED, ORANGE};
        else if(t.contains("ذخیره") || t.contains("تأیید") || t.contains("ثبت"))
            colors=new int[]{PURPLE, INDIGO, BLUE};
        else colors=new int[]{PURPLE, VIOLET, BLUE, CYAN};

        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);
        g.setCornerRadius(dp(c, 17));
        b.setBackground(g);
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        b.setElevation(dp(c, 4));
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(TEXT);
        b.setTextSize(14f);
        b.setMinHeight(dp(c, 46));
        b.setPadding(dp(c, 12), dp(c, 9), dp(c, 12), dp(c, 9));
        b.setElevation(dp(c, 1));

        String t=text==null?"":text.trim();
        int fill=FIELD, stroke=withAlpha(CYAN,0x45);
        if(t.contains("حذف") || t.contains("پاک") || t.contains("⛔") || t.contains("🗑")){
            fill=0xFF2A1419; stroke=withAlpha(RED,0xC0);
        }else if(t.contains("ویرایش") || t.contains("✎") || t.contains("✏")){
            fill=0xFF1B1830; stroke=withAlpha(INDIGO,0xB0);
        }else if(t.contains("باز") || t.contains("مشاهده") || t.contains("دفترچه") || t.contains("👁")){
            fill=0xFF102633; stroke=withAlpha(CYAN,0xC0);
        }else if(t.contains("افزود") || t.contains("جدید") || t.equals("+") || t.equals("＋") || t.startsWith("➕")){
            fill=0xFF13291F; stroke=withAlpha(GREEN,0xC0);
        }else if(t.contains("ذخیره") || t.contains("تأیید") || t.contains("انجام شد") || t.contains("خریدم")){
            fill=0xFF122821; stroke=withAlpha(TEAL,0xC0);
        }

        GradientDrawable g=new GradientDrawable();
        g.setColor(fill);g.setStroke(dp(c,1),stroke);g.setCornerRadius(dp(c,16));
        b.setBackground(g);
        return b;
    }

    public static Button iconButton(Context c,String icon,String contentDescription,int accent){
        Button b=new Button(c);
        b.setAllCaps(false);b.setText(icon);b.setContentDescription(contentDescription);
        b.setTextColor(TEXT);b.setTextSize(18f);b.setGravity(Gravity.CENTER);
        b.setMinWidth(dp(c,40));b.setMinimumWidth(dp(c,40));
        b.setMinHeight(dp(c,40));b.setMinimumHeight(dp(c,40));
        GradientDrawable g=new GradientDrawable();
        g.setColor(withAlpha(CARD_2,0xF0));g.setStroke(dp(c,1),withAlpha(accent,0xA0));g.setCornerRadius(dp(c,13));
        b.setBackground(g);b.setPadding(0,0,0,0);b.setElevation(dp(c,1));
        return b;
    }

    public static Button editIconButton(Context c){return iconButton(c,"✎","ویرایش",INDIGO);}
    public static Button deleteIconButton(Context c){return iconButton(c,"🗑","حذف",RED);}
    public static Button addIconButton(Context c){return iconButton(c,"＋","افزودن",GREEN);}
    public static Button openIconButton(Context c){return iconButton(c,"›","باز کردن",CYAN);}


    public static Button backButton(Context c) {
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText("‹");
        b.setTextColor(TEXT);
        b.setTextSize(28f);
        b.setGravity(Gravity.CENTER);
        b.setMinWidth(dp(c, 40));
        b.setMinimumWidth(dp(c, 40));
        b.setMinHeight(dp(c, 40));
        b.setMinimumHeight(dp(c, 40));
        GradientDrawable g = new GradientDrawable();
        g.setColor(withAlpha(CARD_2, 0xE8));
        g.setStroke(dp(c,1), withAlpha(CYAN,0x55));
        g.setCornerRadius(dp(c,14));
        b.setBackground(g);
        b.setPadding(0,0,0,dp(c,2));
        b.setElevation(dp(c,2));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(c,42),dp(c,42));
        b.setLayoutParams(lp);
        return b;
    }

    public static EditText styleField(Context c, EditText e, String hint) {
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setBackground(field(c));
        e.setPadding(dp(c,14),dp(c,13),dp(c,14),dp(c,13));
        e.setTextSize(16f);
        return e;
    }

    public static LinearLayout dialogPanel(Context c) {
        LinearLayout box=new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(c,18),dp(c,14),dp(c,18),dp(c,8));
        box.setBackground(colorfulCard(c,6));
        return box;
    }
    public static TextView navCard(Context c, String icon, String title, String subtitle) {
        TextView tv = new TextView(c);
        tv.setText(icon + "   " + title + "\n      " + subtitle);
        tv.setTextColor(TEXT);
        tv.setTextSize(16f);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        tv.setLineSpacing(0f, 1.30f);
        tv.setPadding(dp(c, 18), dp(c, 20), dp(c, 18), dp(c, 20));

        int variant = title.contains("تماس") ? 2 : 0;
        tv.setBackground(colorfulCard(c, variant));
        tv.setElevation(dp(c, 4));
        return tv;
    }

    public static TextView chip(Context c, String text, boolean active) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextSize(13f);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));

        if (active) {
            tv.setTextColor(Color.WHITE);
            GradientDrawable g = new GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    new int[]{PURPLE, BLUE, CYAN}
            );
            g.setCornerRadius(dp(c, 100));
            tv.setBackground(g);
        } else {
            tv.setTextColor(TEXT);
            tv.setBackground(field(c));
        }
        return tv;
    }

    public static LinearLayout bottomNav(
            Context c,
            int selected,
            final View.OnClickListener home,
            final View.OnClickListener smart,
            final View.OnClickListener calls
    ) {
        LinearLayout nav = new LinearLayout(c);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(c, 8), dp(c, 8), dp(c, 8), dp(c, 8));
        nav.setBackground(bottomNavBackground(c));
        nav.setElevation(dp(c, 6));

        TextView homeTab = navTab(c, "⌂\nخانه", selected == 0, PURPLE);
        TextView smartTab = navTab(c, "◷\nسایلنت", selected == 1, CYAN);
        TextView callsTab = navTab(c, "☎\nتماس‌ها", selected == 2, TEAL);

        homeTab.setOnClickListener(home);
        smartTab.setOnClickListener(smart);
        callsTab.setOnClickListener(calls);

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);

        nav.addView(homeTab, lp);
        nav.addView(smartTab, lp);
        nav.addView(callsTab, lp);
        return nav;
    }

    private static TextView navTab(
            Context c,
            String text,
            boolean selected,
            int accent
    ) {
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(12f);
        tv.setTextColor(selected ? accent : MUTED);
        tv.setTypeface(
                Typeface.create(
                        "sans-serif-medium",
                        selected ? Typeface.BOLD : Typeface.NORMAL
                )
        );
        tv.setPadding(dp(c, 8), dp(c, 6), dp(c, 8), dp(c, 6));
        return tv;
    }

    public static void applyWindow(Activity a) {
        a.getWindow().setStatusBarColor(BG_1);
        a.getWindow().setNavigationBarColor(BG_1);
        a.getWindow().getDecorView().setBackgroundColor(BG_1);
        if (Build.VERSION.SDK_INT >= 29) a.getWindow().setNavigationBarContrastEnforced(false);

        if (Build.VERSION.SDK_INT >= 23) {
            int flags = a.getWindow().getDecorView().getSystemUiVisibility();
            flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            a.getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    public static LinearLayout.LayoutParams matchWrap(Context c) {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    public static LinearLayout.LayoutParams matchWrap(Context c, int top, int bottom) {
        LinearLayout.LayoutParams p = matchWrap(c);
        p.setMargins(0, dp(c, top), 0, dp(c, bottom));
        return p;
    }
}
