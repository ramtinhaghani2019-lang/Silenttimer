package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TimelineActivity extends Activity {
    private static final class Event {
        long time;
        String icon;
        String title;
        String sub;
        Event(long t,String i,String ti,String s){time=t;icon=i;title=ti;sub=s;}
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Timeline"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"یک خط زمانی از اتفاق‌ها و موعدهای مهم Nexa"),UiKit.matchWrap(this,0,14));

        List<Event> future=new ArrayList<>();
        List<Event> past=new ArrayList<>();
        long now=System.currentTimeMillis();

        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            if(!r.active || r.whenMillis<=0)continue;
            Event e=new Event(r.whenMillis,r.icon,r.title,r.category);
            (r.whenMillis>now?future:past).add(e);
        }

        for(NexaStore.Medicine m:NexaStore.medicines(this)){
            if(m.active && m.nextDoseMillis>0){
                Event e=new Event(m.nextDoseMillis,"💊",m.name,m.dose);
                (m.nextDoseMillis>now?future:past).add(e);
            }
        }

        for(NexaStore.CaseItem x:NexaStore.cases(this)){
            if(x.whenMillis<=0)continue;
            Event e=new Event(x.whenMillis,"⚖️",x.title,"دادگاه • "+x.caseNumber);
            (x.whenMillis>now?future:past).add(e);
        }

        for(NexaStore.BillItem x:NexaStore.bills(this)){
            if(x.paid||x.dueDate<=0)continue;
            Event e=new Event(x.dueDate,"💳",x.title,x.type);
            (x.dueDate>now?future:past).add(e);
        }

        for(NexaStore.DocumentItem x:NexaStore.documents(this)){
            if(x.expiryDate<=0)continue;
            Event e=new Event(x.expiryDate,"📄","انقضای "+x.title,x.type);
            (x.expiryDate>now?future:past).add(e);
        }

        for(NexaStore.HomeItem x:NexaStore.homeItems(this)){
            if(x.nextDueDate<=0)continue;
            Event e=new Event(x.nextDueDate,"🏠",x.title,x.category);
            (x.nextDueDate>now?future:past).add(e);
        }

        for(NexaStore.TodoItem x:NexaStore.todos(this)){
            if(x.done||x.dueMillis<=0)continue;
            Event e=new Event(x.dueMillis,"✅",x.title,x.category);
            (x.dueMillis>now?future:past).add(e);
        }

        for(NexaStore.ServiceRecord x:NexaStore.services(this)){
            past.add(new Event(x.dateMillis,"🔧",x.category,x.km+" km • "+x.note));
        }

        for(NexaStore.HistoryItem x:NexaStore.history(this)){
            past.add(new Event(x.time,"◷",x.type,x.text));
        }

        future.sort(Comparator.comparingLong(a->a.time));
        past.sort((a,b)->Long.compare(b.time,a.time));

        LinearLayout futureCard=UiKit.colorfulCardLayout(this,1);
        futureCard.addView(UiKit.sectionTitle(this,"پیش رو"));
        if(future.isEmpty())futureCard.addView(UiKit.muted(this,"موردی در آینده ثبت نشده."),UiKit.matchWrap(this,8,0));
        for(int i=0;i<Math.min(30,future.size());i++)addEvent(futureCard,future.get(i));
        root.addView(futureCard,UiKit.matchWrap(this,0,14));

        LinearLayout pastCard=UiKit.cardLayout(this);
        pastCard.addView(UiKit.sectionTitle(this,"اخیر"));
        if(past.isEmpty())pastCard.addView(UiKit.muted(this,"هنوز سابقه‌ای وجود ندارد."),UiKit.matchWrap(this,8,0));
        for(int i=0;i<Math.min(50,past.size());i++)addEvent(pastCard,past.get(i));
        root.addView(pastCard);

        setContentView(sc);
    }

    @Override protected void onResume(){super.onResume(); if(getWindow().getDecorView()!=null)build();}

    private void addEvent(LinearLayout parent,Event e){
        TextView title=UiKit.sectionTitle(this,e.icon+"  "+e.title);
        title.setTextSize(15);
        parent.addView(title,UiKit.matchWrap(this,10,2));
        parent.addView(UiKit.muted(this,PersianDateUtil.pretty(e.time)+(e.sub==null||e.sub.isEmpty()?"":" • "+e.sub)));
    }
}
