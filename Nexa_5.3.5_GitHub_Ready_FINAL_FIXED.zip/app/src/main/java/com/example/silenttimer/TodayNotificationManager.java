package com.example.silenttimer;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public final class TodayNotificationManager {
    private static final String CHANNEL="nexa_today_summary_v2";
    private static final int ID=9310;
    private TodayNotificationManager(){}
    private static final class Row{long at;String text;Row(long a,String t){at=a;text=t;}}

    public static void refresh(Context c){
        createChannel(c);long now=System.currentTimeMillis();long[] range=dayRange(now);long start=range[0],end=range[1];List<Row> rows=new ArrayList<>();
        for(NexaStore.Reminder r:NexaStore.reminders(c))if(r.active&&r.whenMillis>=start&&r.whenMillis<end&&r.sourceKey.isEmpty())rows.add(new Row(r.whenMillis,r.icon+" "+time(r.whenMillis)+"  "+r.title));
        for(NexaStore.Medicine m:NexaStore.medicines(c))addMedicineRows(c,rows,m,start,end,now);
        for(NexaStore.CaseItem x:NexaStore.cases(c))if(x.whenMillis>=start&&x.whenMillis<end)rows.add(new Row(x.whenMillis,"⚖️ "+time(x.whenMillis)+"  "+x.title));
        for(NexaStore.BillItem x:NexaStore.bills(c))if(!x.paid&&x.dueDate>=start&&x.dueDate<end)rows.add(new Row(x.dueDate,"💳 "+time(x.dueDate)+"  "+x.title));
        for(NexaStore.TodoItem x:NexaStore.todos(c))if(!x.done&&x.dueMillis>=start&&x.dueMillis<end)rows.add(new Row(x.dueMillis,"✓ "+time(x.dueMillis)+"  "+x.title));
        for(NexaStore.ShoppingList x:NexaStore.shoppingLists(c))if(x.dueMillis>=start&&x.dueMillis<end&&!shoppingListDone(c,x.name))rows.add(new Row(x.dueMillis,"🛒 "+time(x.dueMillis)+"  "+x.name));
        for(NexaStore.DocumentItem x:NexaStore.documents(c))if(x.expiryDate>=start&&x.expiryDate<end)rows.add(new Row(x.expiryDate,"📄 "+time(x.expiryDate)+"  "+x.title));
        for(NexaStore.HomeItem x:NexaStore.homeItems(c))if(x.nextDueDate>=start&&x.nextDueDate<end)rows.add(new Row(x.nextDueDate,"🏠 "+time(x.nextDueDate)+"  "+x.title));
        for(NexaStore.ServiceRecord x:NexaStore.services(c))if(x.nextDueDate>=start&&x.nextDueDate<end)rows.add(new Row(x.nextDueDate,"🚗 "+time(x.nextDueDate)+"  "+x.category));
        rows.sort(Comparator.comparingLong(a->a.at));

        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);Intent open=new Intent(c,TodayActivity.class);PendingIntent pi=PendingIntent.getActivity(c,ID,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.InboxStyle style=new Notification.InboxStyle();int shown=0;for(Row r:rows){if(shown++>=10)break;style.addLine(r.text);}style.setBigContentTitle("برنامه امروز Nexa");if(rows.size()>10)style.setSummaryText("+ "+(rows.size()-10)+" مورد دیگر");
        String content=rows.isEmpty()?"برای امروز مورد زمان‌داری ثبت نشده.":rows.size()+" مورد برای امروز • نزدیک‌ترین: "+rows.get(0).text;
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);Notification n=b.setSmallIcon(android.R.drawable.ic_menu_today).setContentTitle("Nexa Today • "+PersianDateUtil.pretty(now)).setContentText(content).setStyle(style).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).setShowWhen(false).setCategory(Notification.CATEGORY_STATUS).setPriority(Notification.PRIORITY_LOW).build();nm.notify(ID,n);scheduleMidnight(c,end+3000L);
    }

    private static void addMedicineRows(Context c,List<Row> rows,NexaStore.Medicine m,long start,long end,long now){
        if(!m.active&&m.endMillis>0&&m.endMillis<start)return;long step=Math.max(1,m.intervalHours)*3600000L;long anchor=m.firstDoseMillis>0?m.firstDoseMillis:m.nextDoseMillis-step;if(anchor<=0)return;while(anchor<start)anchor+=step;while(anchor-step>=start)anchor-=step;
        List<NexaStore.MedicineDoseLog> logs=NexaStore.medicineDoseLogsFor(c,m.id);
        for(long t=anchor;t<end;t+=step){if(t<start)continue;if(m.endMillis>0&&t>m.endMillis)break;NexaStore.MedicineDoseLog log=null;for(NexaStore.MedicineDoseLog x:logs)if(Math.abs(x.scheduledAt-t)<60_000L){log=x;break;}if(log!=null){String detail=Math.abs(log.takenAt-log.scheduledAt)>60_000L?"موعد "+time(t)+" • خوردم "+time(log.takenAt):time(t)+" • خوردم";rows.add(new Row(log.takenAt>0?log.takenAt:t,"✅ "+detail+"  "+m.name));}else{String p=t<now?"🔴 ":"💊 ";rows.add(new Row(t,p+time(t)+"  "+m.name));}}
    }

    private static boolean shoppingListDone(Context c,String name){boolean any=false;for(NexaStore.ShoppingItem x:NexaStore.shoppingItems(c))if(x.listName.equalsIgnoreCase(name)){any=true;if(!x.done)return false;}return any;}
    private static long[] dayRange(long now){Calendar cal=Calendar.getInstance();cal.setTimeInMillis(now);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();cal.add(Calendar.DAY_OF_YEAR,1);return new long[]{start,cal.getTimeInMillis()};}
    private static String time(long t){Calendar c=Calendar.getInstance();c.setTimeInMillis(t);return String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE));}
    private static void createChannel(Context c){if(Build.VERSION.SDK_INT<26)return;NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);NotificationChannel ch=new NotificationChannel(CHANNEL,"Nexa Today",NotificationManager.IMPORTANCE_LOW);ch.setDescription("خلاصه ثابت برنامه‌های امروز در نوار اعلان");ch.setSound(null,null);ch.enableVibration(false);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);nm.createNotificationChannel(ch);}
    private static void scheduleMidnight(Context c,long at){Intent i=new Intent(c,TodaySummaryReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,ID+1,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;try{if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.setExact(AlarmManager.RTC_WAKEUP,at,pi);}catch(Exception e){if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.set(AlarmManager.RTC_WAKEUP,at,pi);}}
}
