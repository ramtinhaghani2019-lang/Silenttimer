package com.example.silenttimer;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Shared alarm-style audio/vibration helper. Only one Nexa alarm session rings at a time. */
public final class AlarmSoundPlayer {
    private static MediaPlayer activePlayer;
    private static Vibrator activeVibrator;
    private AlarmSoundPlayer() {}

    public static synchronized MediaPlayer start(Context c) {
        stopAll();
        MediaPlayer mp = null;
        try {
            Uri uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
            if (uri == null) uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            mp = new MediaPlayer();
            mp.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            mp.setDataSource(c.getApplicationContext(), uri);
            mp.setLooping(true);
            mp.prepare();
            mp.start();
            activePlayer = mp;
        } catch (Exception ignored) {
            if (mp != null) try { mp.release(); } catch (Exception ignored2) {}
            activePlayer = null;
        }
        try {
            Vibrator v=(Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
            if(v!=null&&v.hasVibrator()){
                long[] pattern={0,700,350,700,600};
                if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createWaveform(pattern,0));
                else v.vibrate(pattern,0);
                activeVibrator=v;
            }
        } catch(Exception ignored){}
        return activePlayer;
    }

    public static synchronized void stop(MediaPlayer mp) {
        if (mp != null) {
            try { if (mp.isPlaying()) mp.stop(); } catch (Exception ignored) {}
            try { mp.release(); } catch (Exception ignored) {}
        }
        if (mp == activePlayer) activePlayer = null;
        stopVibration();
    }

    public static synchronized void stopAll(){
        MediaPlayer mp=activePlayer;activePlayer=null;
        if(mp!=null){try{if(mp.isPlaying())mp.stop();}catch(Exception ignored){}try{mp.release();}catch(Exception ignored){}}
        stopVibration();
    }

    private static void stopVibration(){
        if(activeVibrator!=null){try{activeVibrator.cancel();}catch(Exception ignored){}activeVibrator=null;}
    }
}
