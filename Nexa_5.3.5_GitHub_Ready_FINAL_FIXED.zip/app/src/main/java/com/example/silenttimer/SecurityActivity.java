package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;

/** PIN replacement requires knowledge of old PIN; biometric switches cannot disable it silently. */
public class SecurityActivity extends Activity {
    private EditText entry(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setBackground(UiKit.field(this));e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));return e;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,30));
        root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,UiKit.matchWrap(this,0,12));
        root.addView(UiKit.title(this,"🔐 امنیت Nexa"),UiKit.matchWrap(this,0,12));
        LinearLayout card=UiKit.colorfulCardLayout(this,3);root.addView(card,UiKit.matchWrap(this,0,14));
        card.addView(UiKit.sectionTitle(this,"PIN و اثر انگشت"));
        boolean existing=NexaStore.pinConfigured(this);
        EditText old=entry("PIN فعلی (برای تغییرات امنیتی)");
        EditText pin=entry(existing?"PIN جدید (در صورت تمایل به تغییر)":"PIN جدید ۴ تا ۶ رقمی");
        if(existing)card.addView(old,UiKit.matchWrap(this,10,8));
        card.addView(pin,UiKit.matchWrap(this,10,8));
        Switch lock=new Switch(this);lock.setText("قفل عمومی برنامه");lock.setTextColor(UiKit.TEXT);
        lock.setChecked(NexaStore.lockEnabled(this));card.addView(lock);
        Switch bio=new Switch(this);bio.setText("استفاده از اثر انگشت");bio.setTextColor(UiKit.TEXT);
        bio.setChecked(NexaStore.biometricEnabled(this));card.addView(bio);
        card.addView(UiKit.muted(this,"صندوق امن همیشه باید PIN فعال داشته باشد. عوض‌کردن PIN اطلاعات رمزگذاری‌شده را پاک نمی‌کند."),UiKit.matchWrap(this,8,10));
        Button save=UiKit.primaryButton(this,"ذخیره تنظیمات امنیتی");
        save.setOnClickListener(v->{
            String newPin=pin.getText().toString();
            if(existing&&!NexaStore.verifyPin(this,old.getText().toString())){
                Toast.makeText(this,"برای تغییر تنظیمات، PIN فعلی را وارد کن.",Toast.LENGTH_LONG).show();return;}
            if(!newPin.isEmpty()&&!newPin.matches("[0-9]{4,6}")){
                Toast.makeText(this,"PIN باید ۴ تا ۶ رقم باشد.",Toast.LENGTH_LONG).show();return;}
            if(!existing&&newPin.isEmpty()){
                Toast.makeText(this,"ابتدا PIN تعیین کن.",Toast.LENGTH_LONG).show();return;}
            if(!newPin.isEmpty())NexaStore.setPin(this,newPin);
            NexaStore.setLockEnabled(this,lock.isChecked());
            NexaStore.setBiometricEnabled(this,bio.isChecked());
            SecurityGate.lock();Toast.makeText(this,"تنظیمات امنیتی ذخیره شد.",Toast.LENGTH_LONG).show();finish();
        });card.addView(save,UiKit.matchWrap(this,8,0));setContentView(sc);
    }
}
