package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MedicineRingActivity extends Activity {
    private String id;
    private MediaPlayer alarmPlayer;
    private final Handler alarmHandler=new Handler(Looper.getMainLooper());
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);UiKit.applyWindow(this);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);id=getIntent().getStringExtra("id");NexaStore.Medicine m=NexaStore.medicine(this,id);if(m==null){finish();return;}
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));
        TextView icon=UiKit.title(this,"💊");icon.setTextSize(60);icon.setGravity(Gravity.CENTER);root.addView(icon);TextView t=UiKit.title(this,m.name);t.setGravity(Gravity.CENTER);root.addView(t,UiKit.matchWrap(this,10,5));TextView sub=UiKit.muted(this,(m.dose.isEmpty()?"زمان مصرف دارو رسیده":m.dose)+"\nموعد: "+PersianDateUtil.pretty(m.nextDoseMillis));sub.setGravity(Gravity.CENTER);sub.setTextSize(15);root.addView(sub,UiKit.matchWrap(this,0,20));
        Button onTime=UiKit.primaryButton(this,"✅ سرِ وقت خوردم");onTime.setOnClickListener(v->act("TAKEN_ON_TIME"));root.addView(onTime,UiKit.matchWrap(this,0,9));
        Button now=UiKit.secondaryButton(this,"💊 الان خوردم");now.setOnClickListener(v->act("TAKEN_NOW"));root.addView(now,UiKit.matchWrap(this,0,9));
        Button later=UiKit.secondaryButton(this,"⏰ ۵ دقیقه بعد یادآوری کن");later.setOnClickListener(v->act("SNOOZE"));root.addView(later);setContentView(root);
        alarmPlayer=AlarmSoundPlayer.start(this);long ringMs=AppPrefs.getAlarmRingDurationMs(this);if(ringMs>0)alarmHandler.postDelayed(this::stopAlarmSound,ringMs);
    }
    private void act(String action){stopAlarmSound();Intent i=new Intent(this,MedicineActionReceiver.class);i.setAction(action);i.putExtra("id",id);sendBroadcast(i);finish();}
    private void stopAlarmSound(){AlarmSoundPlayer.stop(alarmPlayer);alarmPlayer=null;}
    @Override public void onBackPressed(){android.widget.Toast.makeText(this,"برای بستن هشدار یکی از گزینه‌های روی صفحه را انتخاب کنید.",android.widget.Toast.LENGTH_SHORT).show();}
    @Override protected void onDestroy(){alarmHandler.removeCallbacksAndMessages(null);stopAlarmSound();super.onDestroy();}
}
