package com.example.silenttimer;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.widget.RemoteViews;

public class NexaWidgetProvider extends AppWidgetProvider {
    public static final String A30="nexa.widget.30",A60="nexa.widget.60",ASTOP="nexa.widget.stop";
    @Override public void onUpdate(Context c,AppWidgetManager m,int[]ids){for(int id:ids)update(c,m,id);}
    @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);String a=i.getAction();if(A30.equals(a)||A60.equals(a)||ASTOP.equals(a)){Intent s=new Intent(c,SilentTimerService.class);if(ASTOP.equals(a))s.setAction(SilentTimerService.ACTION_STOP);else{s.setAction(SilentTimerService.ACTION_START);s.putExtra(SilentTimerService.EXTRA_MINUTES,A30.equals(a)?30:60);s.putExtra(SilentTimerService.EXTRA_TARGET_MODE,AudioManager.RINGER_MODE_SILENT);}try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);}catch(Exception ignored){}}}
    private static void update(Context c,AppWidgetManager m,int id){RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.nexa_widget);v.setTextViewText(R.id.widget_status,AppPrefs.isTimerActive(c)?"Silent فعال":"Nexa آماده");v.setOnClickPendingIntent(R.id.widget_30,pi(c,A30,30));v.setOnClickPendingIntent(R.id.widget_60,pi(c,A60,60));v.setOnClickPendingIntent(R.id.widget_stop,pi(c,ASTOP,99));Intent open=new Intent(c,MainActivity.class);v.setOnClickPendingIntent(R.id.widget_title,PendingIntent.getActivity(c,5,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE));m.updateAppWidget(id,v);}
    private static PendingIntent pi(Context c,String a,int r){Intent i=new Intent(c,NexaWidgetProvider.class);i.setAction(a);return PendingIntent.getBroadcast(c,r,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
}
