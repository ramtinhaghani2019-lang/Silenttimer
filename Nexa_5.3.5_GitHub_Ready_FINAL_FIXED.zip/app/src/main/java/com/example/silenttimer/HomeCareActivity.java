package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

public class HomeCareActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if(getIntent().getBooleanExtra("quick_add",false))list.postDelayed(this::addDialog,250);
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Home"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"سرویس‌ها و کارهای دوره‌ای منزل"),UiKit.matchWrap(this,0,14));

        LinearLayout hero=UiKit.colorfulCardLayout(this,7);
        hero.addView(UiKit.sectionTitle(this,"🏠 نگهداری خانه"));
        Button add=UiKit.primaryButton(this,"＋ ثبت سرویس منزل");
        add.setOnClickListener(v->addDialog());
        hero.addView(add,UiKit.matchWrap(this,10,0));
        root.addView(hero,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() { editDialog(null); }
    private void editDialog(NexaStore.HomeItem existing) {
        LinearLayout box=UiKit.dialogPanel(this);

        Spinner cat=new Spinner(this);
        cat.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"کولر","پکیج","فیلتر آب","تصفیه هوا","برق","لوله‌کشی","آسانسور","نظافت/سرویس","سایر"}
        ));

        EditText title=field("عنوان؛ مثلاً تعویض فیلتر آب");
        EditText cost=field("هزینه (اختیاری)");
        cost.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(cost);
        EditText note=field("توضیحات");

        final long[] last={System.currentTimeMillis()};
        final long[] next={System.currentTimeMillis()+180L*24L*60L*60L*1000L};

        Button lastBtn=UiKit.secondaryButton(this,"آخرین سرویس: "+PersianDateUtil.pretty(last[0]));
        lastBtn.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,last[0],"تاریخ و ساعت آخرین سرویس",ms->{last[0]=ms;lastBtn.setText("آخرین سرویس: "+PersianDateUtil.pretty(ms));}));

        Button nextBtn=UiKit.secondaryButton(this,"سرویس بعدی: "+PersianDateUtil.pretty(next[0]));
        nextBtn.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,next[0],"تاریخ و ساعت سرویس بعدی",ms->{next[0]=ms;nextBtn.setText("سرویس بعدی: "+PersianDateUtil.pretty(ms));}));

        box.addView(cat);box.addView(title);box.addView(cost);box.addView(note);box.addView(lastBtn);box.addView(nextBtn);
        if(existing!=null){cat.setSelection(Math.max(0,java.util.Arrays.asList("کولر","پکیج","فیلتر آب","تصفیه هوا","برق","لوله‌کشی","آسانسور","نظافت/سرویس","سایر").indexOf(existing.category)));
        title.setText(existing.title);if(existing.cost>0)cost.setText(NumberFormatUtil.grouped(existing.cost));note.setText(existing.note);
        last[0]=existing.lastServiceDate;next[0]=existing.nextDueDate;
        lastBtn.setText("آخرین سرویس: "+PersianDateUtil.pretty(last[0]));nextBtn.setText("سرویس بعدی: "+PersianDateUtil.pretty(next[0]));}
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"10080,1440,0":existing.alertRules,existing==null?5:existing.alertRepeat);

        new AlertDialog.Builder(this)
                .setTitle("سرویس خانه")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(cat.getSelectedItem());

                    NexaStore.HomeItem x=existing==null?new NexaStore.HomeItem():existing;
                    x.alertRules=alerts.rules();x.alertRepeat=alerts.repeatMinutes();
                    x.category=String.valueOf(cat.getSelectedItem());
                    x.title=t;
                    x.lastServiceDate=last[0];
                    x.nextDueDate=next[0];
                    x.note=note.getText().toString().trim();
                    x.cost=NumberFormatUtil.longValue(cost.getText());

                    if(existing==null)NexaStore.addHomeItem(this,x);else NexaStore.updateHomeItem(this,x);
                    LinkedReminderHelper.upsert(
                            this,
                            "home:"+x.id,
                            "سرویس خانه: "+x.title,
                            "خانه",
                            "🏠",
                            x.note,
                            x.nextDueDate,
                            x.alertRules,
                            x.alertRepeat
                    );
                    NexaStore.addHistory(this,"خانه","ثبت سرویس: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.HomeItem> data=NexaStore.homeItems(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"سرویسی برای خانه ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        for(NexaStore.HomeItem x:data){
            LinearLayout c=UiKit.colorfulCardLayout(this,7);
            c.addView(UiKit.sectionTitle(this,"🏠 "+x.title));
            c.addView(UiKit.muted(this,x.category+" • موعد بعدی "+PersianDateUtil.format(x.nextDueDate)),UiKit.matchWrap(this,5,2));
            if(x.cost>0)c.addView(UiKit.muted(this,String.format(Locale.US,"هزینه قبلی: %,d تومان",x.cost)));
            if(!x.note.isEmpty())c.addView(UiKit.muted(this,x.note),UiKit.matchWrap(this,4,0));

            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editDialog(x));
            LinearLayout iconActions=new LinearLayout(this);iconActions.setGravity(Gravity.CENTER_VERTICAL);iconActions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
            Button del=UiKit.deleteIconButton(this);
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                .setMessage(x.title).setPositiveButton("حذف",(d,w)->{
                LinkedReminderHelper.remove(this,"home:"+x.id);
                NexaStore.removeHomeItem(this,x.id);render();
                }).setNegativeButton("انصراف",null).show());
            LinearLayout.LayoutParams idlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));idlp.setMargins(UiKit.dp(this,5),0,0,0);iconActions.addView(del,idlp);c.addView(iconActions,UiKit.matchWrap(this,8,0));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
    }
}
