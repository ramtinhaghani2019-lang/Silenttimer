package com.example.silenttimer;

import android.app.Activity;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;

public class UnlockActivity extends Activity {
    private boolean biometricStarted=false;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();if(Build.VERSION.SDK_INT>=28&&NexaStore.biometricEnabled(this))getWindow().getDecorView().postDelayed(this::biometric,220);}
    private void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));TextView t=UiKit.title(this,"NEXA");t.setGravity(Gravity.CENTER);root.addView(t,UiKit.matchWrap(this,0,6));TextView s=UiKit.muted(this,NexaStore.biometricEnabled(this)?"اثر انگشت را تأیید کن؛ PIN روش جایگزین است.":"PIN امنیتی");s.setGravity(Gravity.CENTER);root.addView(s,UiKit.matchWrap(this,0,24));EditText pin=UiKit.styleField(this,new EditText(this),"PIN");pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(pin,UiKit.matchWrap(this,0,12));Button ok=UiKit.primaryButton(this,"ورود با PIN");ok.setOnClickListener(v->{if(NexaStore.verifyPin(this,pin.getText().toString()))success();else Toast.makeText(this,"PIN نادرست است.",Toast.LENGTH_SHORT).show();});root.addView(ok,UiKit.matchWrap(this,0,10));if(Build.VERSION.SDK_INT>=28&&NexaStore.biometricEnabled(this)){Button bio=UiKit.secondaryButton(this,"👆 دوباره تلاش با اثر انگشت");bio.setOnClickListener(v->{biometricStarted=false;biometric();});root.addView(bio,UiKit.matchWrap(this,0,8));}Button forgot=UiKit.secondaryButton(this,"رمز را فراموش کرده‌ام");forgot.setOnClickListener(v->forgotPin());root.addView(forgot);setContentView(root);}
    private void success(){SecurityGate.unlock();setResult(RESULT_OK);finish();}

    private void forgotPin(){
        String email=NexaStore.accountEmail(this);
        if(email==null||email.trim().isEmpty()){Toast.makeText(this,"ایمیل بازیابی ثبت نشده است.",Toast.LENGTH_LONG).show();return;}
        EmailRecoveryClient.sendOtp(this,email,(ok,msg)->{Toast.makeText(this,msg,Toast.LENGTH_LONG).show();if(!ok)return;
            EditText code=UiKit.styleField(this,new EditText(this),"کد تأیید ایمیل");code.setInputType(InputType.TYPE_CLASS_NUMBER);
            new AlertDialog.Builder(this).setTitle("کد ارسال‌شده به "+email).setView(code).setPositiveButton("تأیید",(d,w)->{
                EmailRecoveryClient.verifyOtp(this,email,code.getText().toString().trim(),(verified,message)->{Toast.makeText(this,message,Toast.LENGTH_LONG).show();if(verified)askNewPin();});
            }).setNegativeButton("انصراف",null).show();
        });
    }
    private void askNewPin(){
        EditText p=UiKit.styleField(this,new EditText(this),"PIN جدید ۴ تا ۶ رقمی");p.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("PIN جدید").setView(p).setPositiveButton("ذخیره",(d,w)->{String x=p.getText().toString();if(!x.matches("[0-9]{4,6}")){Toast.makeText(this,"PIN باید ۴ تا ۶ رقم باشد.",Toast.LENGTH_LONG).show();return;}NexaStore.setPin(this,x);success();}).setNegativeButton("انصراف",null).show();
    }

    private void biometric(){if(Build.VERSION.SDK_INT<28||biometricStarted||isFinishing())return;biometricStarted=true;CancellationSignal signal=new CancellationSignal();BiometricPrompt prompt=new BiometricPrompt.Builder(this).setTitle("Nexa").setSubtitle("برای ادامه اثر انگشت را تأیید کن").setNegativeButton("استفاده از PIN",getMainExecutor(),(d,w)->biometricStarted=false).build();prompt.authenticate(signal,getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){@Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result){biometricStarted=false;success();}@Override public void onAuthenticationError(int code,CharSequence msg){biometricStarted=false;}@Override public void onAuthenticationFailed(){Toast.makeText(UnlockActivity.this,"اثر انگشت شناسایی نشد؛ دوباره تلاش کن یا PIN را وارد کن.",Toast.LENGTH_SHORT).show();}});}
}
