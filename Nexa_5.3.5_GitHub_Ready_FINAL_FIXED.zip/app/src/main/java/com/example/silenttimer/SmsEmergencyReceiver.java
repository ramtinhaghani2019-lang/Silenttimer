package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.telephony.SmsMessage;

/** Emergency bypass SMS with sender allow-list, optional any-sender and replay cooldown. */
public class SmsEmergencyReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent intent){
        if(!NexaStore.smsEnabled(c))return;
        String code=NexaStore.smsCode(c);
        if(code.trim().length()<8||intent==null||intent.getExtras()==null)return;
        Object[] pdus=(Object[])intent.getExtras().get("pdus");if(pdus==null)return;
        String format=intent.getStringExtra("format");StringBuilder body=new StringBuilder();String sender="";
        for(Object p:pdus){SmsMessage msg=Build.VERSION.SDK_INT>=23?
                SmsMessage.createFromPdu((byte[])p,format):SmsMessage.createFromPdu((byte[])p);
            if(msg!=null){sender=msg.getOriginatingAddress();body.append(msg.getMessageBody());}}
        boolean permitted=NexaStore.smsFromAnyone(c);
        if(!permitted)for(String entry:NexaStore.smsNumber(c).split("[;,\\n]+")){
            String stored=entry.trim();if(stored.contains("|"))stored=stored.substring(stored.lastIndexOf('|')+1).trim();
            if(!stored.isEmpty()&&AppPrefs.numbersMatch(stored,sender)){permitted=true;break;}
        }
        if(!permitted||!body.toString().trim().equalsIgnoreCase(code.trim())||NexaStore.smsRateLimited(c))return;
        AppPrefs.setIgnoreManualUntil(c,System.currentTimeMillis()+6000L);
        try{((AudioManager)c.getSystemService(Context.AUDIO_SERVICE)).setRingerMode(AudioManager.RINGER_MODE_NORMAL);}catch(Exception ignored){}
        if(AppPrefs.isTimerActive(c)){
            Intent stop=new Intent(c,SilentTimerService.class);stop.setAction(SilentTimerService.ACTION_STOP);
            try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(stop);else c.startService(stop);}catch(Exception ignored){}
        }
        NexaStore.addHistory(c,"اضطراری","خروج از حالت بی‌صدا با SMS معتبر");
    }
}
