package com.example.silenttimer;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
public final class GarageNotifier {private GarageNotifier(){} public static void check(Context c,NexaStore.Vehicle v){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel("nexa_garage","Nexa Garage",NotificationManager.IMPORTANCE_DEFAULT);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}for(NexaStore.ServiceRecord r:NexaStore.servicesFor(c,v.id)){if(r.nextDueKm>0&&v.currentKm>=r.nextDueKm){Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"nexa_garage"):new Notification.Builder(c);Notification n=b.setSmallIcon(android.R.drawable.ic_dialog_alert).setContentTitle("🚗 سرویس "+v.name).setContentText("موعد "+r.category+" در "+r.nextDueKm+" km رسیده است.").setAutoCancel(true).build();((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify((v.id+r.id).hashCode(),n);}}}}
