package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MedicineActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        AlarmSoundPlayer.stopAll();String id=i.getStringExtra("id");NexaStore.Medicine m=NexaStore.medicine(c,id);if(m==null)return;
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(("med"+id).hashCode());
        long now=System.currentTimeMillis(),scheduled=m.nextDoseMillis;String action=i.getAction();
        if("SNOOZE".equals(action)){
            int min=m.repeatMinutes>0?m.repeatMinutes:5;MedicineScheduler.scheduleAt(c,id,now+min*60_000L);NexaStore.addHistory(c,"دارو",m.name+" • "+min+" دقیقه بعد");return;
        }
        NexaStore.MedicineDoseLog log=new NexaStore.MedicineDoseLog();log.medicineId=m.id;log.scheduledAt=scheduled;
        if("TAKEN_ON_TIME".equals(action)){
            log.status="taken_on_time";log.takenAt=scheduled>0?scheduled:now;m.nextDoseMillis=(scheduled>0?scheduled:now)+m.intervalHours*60L*60L*1000L;
            NexaStore.addHistory(c,"دارو",m.name+" • سر وقت خوردم");
        }else if("TAKEN_NOW".equals(action)){
            log.status="taken_now";log.takenAt=now;m.nextDoseMillis=now+m.intervalHours*60L*60L*1000L;
            NexaStore.addHistory(c,"دارو",m.name+" • الان خوردم");
        }else return;
        NexaStore.addMedicineDoseLog(c,log);
        if(m.endMillis>0&&m.nextDoseMillis>m.endMillis)m.active=false;
        java.util.List<NexaStore.Medicine>l=NexaStore.medicines(c);for(int x=0;x<l.size();x++)if(l.get(x).id.equals(m.id))l.set(x,m);NexaStore.saveMedicines(c,l);
        if(m.active)MedicineScheduler.schedule(c,m);TodayNotificationManager.refresh(c);
    }
}
