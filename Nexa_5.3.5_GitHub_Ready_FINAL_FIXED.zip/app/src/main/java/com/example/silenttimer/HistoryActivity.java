package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Local activity history; never includes decrypted Vault secrets. */
public class HistoryActivity extends Activity {
    private LinearLayout results;
    private String query="";
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,16),UiKit.dp(this,18),UiKit.dp(this,32));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,UiKit.matchWrap(this,0,12));
        root.addView(UiKit.title(this,"Nexa History"),UiKit.matchWrap(this,0,6));
        root.addView(UiKit.muted(this,"سوابق به تفکیک ماژول، مجموعه و زمان"),UiKit.matchWrap(this,0,14));
        List<NexaStore.HistoryItem> all=NexaStore.history(this);
        LinearLayout summary=UiKit.colorfulCardLayout(this,6);
        long now=System.currentTimeMillis();int day=0,week=0;
        for(NexaStore.HistoryItem h:all){if(h.time<=now&&now-h.time<86400000L)day++;if(h.time<=now&&now-h.time<604800000L)week++;}
        summary.addView(UiKit.sectionTitle(this,"◷ گزارش فعالیت"));
        summary.addView(UiKit.muted(this,"امروز: "+day+"   •   ۷ روز اخیر: "+week+"   •   کل: "+all.size()),UiKit.matchWrap(this,8,8));
        root.addView(summary,UiKit.matchWrap(this,0,12));
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(UiKit.TEXT);
        search.setHintTextColor(UiKit.MUTED);search.setHint("⌕ جستجو در تاریخچه");
        search.setBackground(UiKit.field(this));search.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,12));
        search.setText(query);root.addView(search,UiKit.matchWrap(this,0,12));
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results);
        search.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();render(all);}public void afterTextChanged(android.text.Editable e){}});
        Button clear=UiKit.secondaryButton(this,"پاک کردن تاریخچه");clear.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("پاک کردن همه سوابق؟").setMessage("این کار برگشت‌پذیر نیست و فقط گزارش فعالیت را حذف می‌کند.")
                .setPositiveButton("پاک کردن",(d,w)->{NexaStore.clearHistory(this);build();})
                .setNegativeButton("انصراف",null).show());root.addView(clear,UiKit.matchWrap(this,18,0));
        setContentView(sc);render(all);
    }
    private void render(List<NexaStore.HistoryItem> all){
        results.removeAllViews();Map<String,List<NexaStore.HistoryItem>> groups=new LinkedHashMap<>();
        for(NexaStore.HistoryItem h:all){if(!(h.type+" "+h.text).toLowerCase().contains(query.toLowerCase()))continue;
            String type=h.type==null||h.type.trim().isEmpty()?"سایر":h.type;
            if(!groups.containsKey(type))groups.put(type,new ArrayList<>());groups.get(type).add(h);
        }
        if(groups.isEmpty()){TextView e=UiKit.muted(this,"موردی یافت نشد.");e.setGravity(Gravity.CENTER);results.addView(e,UiKit.matchWrap(this,20,0));}
        for(Map.Entry<String,List<NexaStore.HistoryItem>> group:groups.entrySet()){
            LinearLayout card=UiKit.colorfulCardLayout(this,groups.size()%4);
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setVisibility(View.GONE);
            Button toggle=UiKit.secondaryButton(this,"▸ "+group.getKey()+"   ("+group.getValue().size()+")");
            toggle.setOnClickListener(v->{boolean show=body.getVisibility()!=View.VISIBLE;body.setVisibility(show?View.VISIBLE:View.GONE);
                toggle.setText((show?"▾ ":"▸ ")+group.getKey()+"   ("+group.getValue().size()+")");});
            card.addView(toggle);
            Map<String,List<NexaStore.HistoryItem>> subjects=new LinkedHashMap<>();
            for(NexaStore.HistoryItem h:group.getValue()){
                String raw=h.text==null?"":h.text;
                String subject=raw.contains(":")?raw.substring(raw.lastIndexOf(':')+1).trim():raw.trim();
                if(subject.isEmpty())subject="سایر";
                if(!subjects.containsKey(subject))subjects.put(subject,new ArrayList<>());
                subjects.get(subject).add(h);
            }
            for(Map.Entry<String,List<NexaStore.HistoryItem>> subject:subjects.entrySet()){
                LinearLayout subjectBody=new LinearLayout(this);subjectBody.setOrientation(LinearLayout.VERTICAL);
                subjectBody.setVisibility(View.GONE);
                Button subjectHead=UiKit.secondaryButton(this,"▸ "+subject.getKey()+" ("+subject.getValue().size()+")");
                subjectHead.setOnClickListener(v->{boolean show=subjectBody.getVisibility()!=View.VISIBLE;
                    subjectBody.setVisibility(show?View.VISIBLE:View.GONE);
                    subjectHead.setText((show?"▾ ":"▸ ")+subject.getKey()+" ("+subject.getValue().size()+")");});
                body.addView(subjectHead,UiKit.matchWrap(this,6,0));
                for(NexaStore.HistoryItem h:subject.getValue()){
                    LinearLayout row=UiKit.cardLayout(this);
                    row.addView(UiKit.sectionTitle(this,h.text),UiKit.matchWrap(this,0,3));
                    row.addView(UiKit.muted(this,PersianDateUtil.pretty(h.time)));
                    subjectBody.addView(row,UiKit.matchWrap(this,7,0));
                }
                body.addView(subjectBody);
            }
            card.addView(body);results.addView(card,UiKit.matchWrap(this,0,10));
        }
    }
}
