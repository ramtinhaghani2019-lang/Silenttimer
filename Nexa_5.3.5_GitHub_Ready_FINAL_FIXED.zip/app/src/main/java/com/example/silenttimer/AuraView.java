package com.example.silenttimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

public class AuraView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AuraView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    private void glow(
            Canvas canvas,
            float x,
            float y,
            float radius,
            int center,
            int edge
    ) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(
                new RadialGradient(
                        x,
                        y,
                        radius,
                        new int[]{center, edge, 0x00000000},
                        new float[]{0f, 0.58f, 1f},
                        Shader.TileMode.CLAMP
                )
        );
        canvas.drawCircle(x, y, radius, paint);
        paint.setShader(null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float base = Math.min(getWidth(), getHeight());

        glow(canvas, cx - base * 0.18f, cy - base * 0.18f, base * 0.44f,
                0x668B5CF6, 0x226D5DFB);

        glow(canvas, cx + base * 0.20f, cy - base * 0.07f, base * 0.40f,
                0x5522D3EE, 0x1822D3EE);

        glow(canvas, cx + base * 0.10f, cy + base * 0.22f, base * 0.38f,
                0x442DD4BF, 0x122DD4BF);

        glow(canvas, cx - base * 0.20f, cy + base * 0.20f, base * 0.34f,
                0x33F472B6, 0x10F472B6);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(UiKit.dp(getContext(), 1));

        paint.setColor(0x448B5CF6);
        canvas.drawCircle(cx, cy, base * 0.39f, paint);

        paint.setColor(0x3322D3EE);
        canvas.drawCircle(cx, cy, base * 0.31f, paint);

        paint.setColor(0x282DD4BF);
        canvas.drawCircle(cx, cy, base * 0.24f, paint);
    }
}
