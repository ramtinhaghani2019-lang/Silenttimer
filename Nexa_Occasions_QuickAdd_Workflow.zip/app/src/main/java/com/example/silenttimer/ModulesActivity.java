package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Full-width RTL module directory: fixed filters, grouped short rows, real pictograms. */
public final class ModulesActivity extends Activity {
    private static final String KEY_QUERY="modules_query", KEY_GROUP="modules_group";
    private static final String[] SHORT_GROUPS={"همه", "مالی و اسناد", "زندگی و سلامت", "هشدارها", "ابزارها"};
    private static final int[] ACCENTS={0xFFE5BB62,0xFFF2CA75,0xFF65CBB4,0xFFC0A3E8,0xFF83C5E8};
    private int group=0;
    private EditText search;
    private LinearLayout results, filters;
    private ScrollView listScroll;
    private TextView count,clear;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        UiKit.applyWindow(this);
        if(state!=null)group=Math.max(0,Math.min(ModulesCatalog.GROUPS.length-1,state.getInt(KEY_GROUP,0)));
        build(state==null?"":state.getString(KEY_QUERY,""));
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putInt(KEY_GROUP,group);
        state.putString(KEY_QUERY,search==null?"":search.getText().toString());
        super.onSaveInstanceState(state);
    }
    private static GradientDrawable surface(int fill,int border,int radius,Activity a){
        GradientDrawable bg=UiKit.rounded(a,fill,radius);
        if(border!=0)bg.setStroke(UiKit.dp(a,1),border);
        return bg;
    }
    private void build(String priorQuery){
        LinearLayout frame=new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.setBackground(UiKit.screenBackground(this));
        frame.setPadding(UiKit.dp(this,14),0,UiKit.dp(this,14),0);
        frame.addView(UiKit.header(this,"بخش‌های نکسا",v->finish()),new LinearLayout.LayoutParams(-1,UiKit.dp(this,56)));

        // A single, calm search surface. The clear action is shown only for actual text.
        LinearLayout searchBar=new LinearLayout(this);
        searchBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(UiKit.dp(this,11),0,UiKit.dp(this,5),0);
        searchBar.setBackground(surface(0xFF10283C,0xFF8D7044,14,this));
        NexaOutlineIcon magnifier=new NexaOutlineIcon(this,"search",0xFFE5BB62);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(UiKit.dp(this,22),UiKit.dp(this,22));
        mp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,11),0);
        searchBar.addView(magnifier,mp);
        search=new EditText(this);
        search.setTag("nexa_directory_search_field");
        search.setTextSize(14.5f);search.setTypeface(UiKit.appFace(this,false));
        search.setSingleLine(true);search.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        search.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        search.setHint("جست‌وجو در بخش‌ها");
        search.setHintTextColor(0xFF9FADC2);search.setTextColor(0xFFF4F7FF);
        search.setPadding(0,0,0,0);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setContentDescription("جست‌وجوی بخش‌های نکسا");
        searchBar.addView(search,new LinearLayout.LayoutParams(0,UiKit.dp(this,50),1f));
        clear=new TextView(this);
        clear.setText("×");clear.setTextColor(0xFFD5E4F7);clear.setTextSize(22);
        clear.setGravity(Gravity.CENTER);clear.setClickable(true);clear.setFocusable(true);
        clear.setContentDescription("پاک کردن عبارت جست‌وجو");
        UiKit.touchFeedback(this,clear,0xFF8BABFF,10);
        clear.setOnClickListener(v->search.setText(""));
        searchBar.addView(clear,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,48)));
        frame.addView(searchBar,UiKit.matchWrap(this,9,12));

        // Exactly two rows, entirely within screen width: no clipped chips on small phones.
        filters=new LinearLayout(this);filters.setOrientation(LinearLayout.VERTICAL);
        filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.addView(filters,UiKit.matchWrap(this,0,10));
        count=UiKit.muted(this,"");count.setTextSize(12.5f);
        count.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        frame.addView(count,UiKit.matchWrap(this,0,6));

        listScroll=new ScrollView(this);
        listScroll.setFillViewport(true);listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setClipToPadding(false);
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
        results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        results.setPadding(0,0,0,UiKit.dp(this,20));
        listScroll.addView(results);
        frame.addView(listScroll,new LinearLayout.LayoutParams(-1,0,1f));

        LinearLayout nav=UiKit.bottomNav(this,-1,
            v->navigate(MainActivity.class),v->navigate(TodayActivity.class),
            v->navigate(QuickAddActivity.class),v->navigate(TimelineActivity.class));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);
        np.setMargins(0,UiKit.dp(this,4),0,UiKit.dp(this,8));
        frame.addView(nav,np);
        setContentView(frame);

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int n,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int n){
                clear.setVisibility(s.length()>0?View.VISIBLE:View.GONE);
                redraw();listScroll.scrollTo(0,0);
            }
            public void afterTextChanged(Editable s){}
        });
        search.setText(priorQuery);
        clear.setVisibility(priorQuery.isEmpty()?View.GONE:View.VISIBLE);
        redrawFilters();redraw();
    }
    private void navigate(Class<?> target){startActivity(new Intent(this,target));finish();}
    private void redrawFilters(){
        filters.removeAllViews();
        int[][] indexes={{0,1,2},{3,4}};
        for(int[] rowIndexes:indexes){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            for(int i=0;i<rowIndexes.length;i++){
                final int next=rowIndexes[i];
                TextView chip=new TextView(this);
                chip.setText(SHORT_GROUPS[next]);chip.setTextSize(12.5f);
                chip.setTypeface(UiKit.appFace(this,next==group));
                chip.setGravity(Gravity.CENTER);chip.setSingleLine(true);
                chip.setTextColor(next==group?0xFF091727:0xFFC4D3E4);
                chip.setBackground(surface(next==group?0xFFE5BB62:0xFF11273B,
                    next==group?0xFFE5BB62:0xFF665238,12,this));
                chip.setClickable(true);chip.setFocusable(true);
                chip.setContentDescription(ModulesCatalog.GROUPS[next]+(next==group?"، انتخاب‌شده":"، نمایش دسته"));
                chip.setOnClickListener(v->{group=next;redrawFilters();redraw();listScroll.scrollTo(0,0);});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,UiKit.dp(this,42),1f);
                if(i>0)lp.setMargins(UiKit.dp(this,6),0,0,0);
                row.addView(chip,lp);
            }
            filters.addView(row,UiKit.matchWrap(this,0,6));
        }
    }
    private LinearLayout moduleRow(ModulesCatalog.Item item){
        int color=ACCENTS[item.group];
        LinearLayout line=new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);line.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setMinimumHeight(UiKit.dp(this,62));
        line.setPadding(UiKit.dp(this,12),UiKit.dp(this,7),UiKit.dp(this,10),UiKit.dp(this,7));
        LinearLayout tile=new LinearLayout(this);
        tile.setGravity(Gravity.CENTER);tile.setBackground(surface(UiKit.withAlpha(color,0x26),0,12,this));
        NexaOutlineIcon icon=new NexaOutlineIcon(this,iconKind(item),color);
        tile.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,24),UiKit.dp(this,24)));
        line.addView(tile,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));
        TextView label=UiKit.sectionTitle(this,item.title);label.setTextSize(14.5f);
        label.setTextColor(0xFFF4F7FB);label.setMaxLines(2);
        label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        lp.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,7),0);
        line.addView(label,lp);
        TextView arrow=UiKit.muted(this,"‹");arrow.setTextSize(22f);arrow.setGravity(Gravity.CENTER);
        line.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(this,22),UiKit.dp(this,40)));
        line.setContentDescription("باز کردن "+item.title);
        line.setClickable(true);line.setFocusable(true);
        UiKit.touchFeedback(this,line,color,14);
        line.setOnClickListener(v->startActivity(new Intent(this,item.destination)));
        return line;
    }
    private String iconKind(ModulesCatalog.Item item){
        Class<?> type=item.destination;
        if(type==AssetsActivity.class)return "assets";
        if(type==LedgerActivity.class)return "ledger";
        if(type==BillsActivity.class)return "bills";
        if(type==DocsActivity.class)return "docs";
        if(type==SharedEntitiesActivity.class)return "shared";
        if(type==MedicineActivity.class)return "medicine";
        if(type==GarageActivity.class)return "vehicle";
        if(type==HomeCareActivity.class)return "home";
        if(type==CaseActivity.class)return "case";
        if(type==WeatherActivity.class)return "weather";
        if(type==RemindersActivity.class)return "reminders";
        if(type==AnnualOccasionsActivity.class)return "occasions";
        if(type==SilentHubActivity.class)return "silent";
        if(type==BatteryGuardActivity.class)return "battery";
        if(type==EmergencyActivity.class)return "emergency";
        if(type==VaultActivity.class)return "vault";
        if(type==FileCenterActivity.class)return "files";
        if(type==SearchActivity.class)return "search";
        if(type==TimelineActivity.class)return "timeline";
        if(type==HistoryActivity.class)return "history";
        if(type==SettingsActivity.class)return "settings";
        if(type==NexaListActivity.class)return "lists";
        return "docs";
    }
    private View divider(){
        View line=new View(this);
        line.setBackgroundColor(0xFF2D3B4E);
        return line;
    }
    private void redraw(){
        if(results==null||search==null)return;
        results.removeAllViews();
        List<ModulesCatalog.Item> visible=ModulesCatalog.filter(search.getText().toString(),group);
        count.setText(visible.size()+" بخش"+(group==0?"":" • "+ModulesCatalog.GROUPS[group]));
        // On narrow screens or with large system fonts, use full-width rows instead
        // of squeezing module names into two columns. Preserve search/filter results.
        float density=getResources().getDisplayMetrics().density;
        float availableDp=getResources().getDisplayMetrics().widthPixels/density-28f;
        boolean singleColumn=availableDp<350f || getResources().getConfiguration().fontScale>=1.25f;
        if(singleColumn){
            for(ModulesCatalog.Item item:visible){
                LinearLayout row=moduleRow(item);
                row.setBackground(surface(0xFF102235,0xFF665238,14,this));
                results.addView(row,UiKit.matchWrap(this,0,8));
            }
        }
        // Wider screens retain the compact two-column module directory.
        LinearLayout tileRow=null;
        if(!singleColumn)for(int i=0;i<visible.size();i++){
            if(i%2==0){
                tileRow=new LinearLayout(this);
                tileRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                tileRow.setGravity(Gravity.TOP);
                results.addView(tileRow,UiKit.matchWrap(this,0,8));
            }
            ModulesCatalog.Item item=visible.get(i);
            LinearLayout tile=new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(UiKit.dp(this,9),UiKit.dp(this,12),UiKit.dp(this,9),UiKit.dp(this,10));
            GradientDrawable tileBg=surface(0xFF102235,0xFF7D643D,16,this);
            tile.setBackground(tileBg);
            int accent=ACCENTS[item.group];
            NexaOutlineIcon icon=new NexaOutlineIcon(this,iconKind(item),accent);
            tile.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,32),UiKit.dp(this,32)));
            TextView label=UiKit.sectionTitle(this,item.title);
            label.setTextColor(0xFFF7F3E8);label.setTextSize(13.5f);
            label.setGravity(Gravity.CENTER);label.setMaxLines(2);
            label.setMinHeight(UiKit.dp(this,38));
            tile.addView(label,UiKit.matchWrap(this,7,0));
            tile.setContentDescription("باز کردن "+item.title);
            tile.setClickable(true);tile.setFocusable(true);
            UiKit.touchFeedback(this,tile,accent,16);
            tile.setOnClickListener(v->startActivity(new Intent(this,item.destination)));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,UiKit.dp(this,106),1f);
            if(i%2==0)lp.setMargins(0,0,UiKit.dp(this,5),0);
            else lp.setMargins(UiKit.dp(this,5),0,0,0);
            tileRow.addView(tile,lp);
            if(i==visible.size()-1 && i%2==0){
                View spacer=new View(this);
                tileRow.addView(spacer,new LinearLayout.LayoutParams(0,1,1f));
            }
        }
        if(visible.isEmpty()){
            TextView empty=UiKit.emptyState(this,"بخشی پیدا نشد","جست‌وجو یا دسته را تغییر بده.");
            results.addView(empty,UiKit.matchWrap(this,12,8));
            TextView showAll=UiKit.chip(this,"نمایش همه بخش‌ها",true);
            showAll.setMinimumHeight(UiKit.dp(this,48));
            showAll.setClickable(true);showAll.setFocusable(true);
            showAll.setOnClickListener(v->{group=0;search.setText("");redrawFilters();redraw();});
            results.addView(showAll,UiKit.matchWrap(this,4,10));
        }
    }
}
