package com.example.silenttimer;
import android.provider.Settings;
import android.os.PowerManager;
import android.app.NotificationManager;
import android.app.AlarmManager;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.Manifest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_APP_UNLOCK=810;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean startupDone=false;
    private boolean permissionRepairShown=false;
    private boolean awaitingUnlock=false;
    private RingTimerView ring;
    private TextView heroTime,heroState,heroSub,todaySummary;

    private final Runnable ticker=new Runnable(){
        @Override public void run(){
            refresh();
            handler.postDelayed(this,1000);
        }
    };

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        AppPrefs.applyLaunchSafetyMigration(this);
        continueStartup();
    }

    private void continueStartup(){
        if(startupDone||isFinishing())return;
        if(NexaStore.lockEnabled(this)&&!SecurityGate.isUnlocked()){
            if(!awaitingUnlock){
                awaitingUnlock=true;
                startActivityForResult(new Intent(this,UnlockActivity.class),REQ_APP_UNLOCK);
            }
            return;
        }
        startupDone=true;
        boolean first=!AppPrefs.isSetupCompleted(this);
        if(!first)ensureMonitor();
        build();
        if(!NexaStore.accountConfigured(this)){
            startActivityForResult(new Intent(this,AccountSetupActivity.class),811);
        }else if(first){
            startPermissionSetup();
        }
    }

    private void startPermissionSetup(){
        Intent i=new Intent(this,SettingsActivity.class);
        i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
        startActivity(i);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==REQ_APP_UNLOCK){
            awaitingUnlock=false;
            if(result==RESULT_OK&&SecurityGate.isUnlocked()) continueStartup();
            else finish();
            return;
        }
        if(request==811){
            if(!NexaStore.accountConfigured(this)){
                // Keep setup mandatory without saving an incomplete/invalid profile.
                finish();return;
            }
            if(!AppPrefs.isSetupCompleted(this))startPermissionSetup();
        }
    }

    @Override protected void onResume(){
        super.onResume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        TodayNotificationManager.refresh(this);
        handler.postDelayed(this::checkCriticalPermissions,450);
    }

    /**
     * Special Android permissions cannot legally be made permanent by an app.
     * Nexa therefore verifies the real OS state on every foreground entry and,
     * if Android/One UI has revoked one, opens the existing guided repair flow.
     */
    private void checkCriticalPermissions(){
        if(isFinishing()||!AppPrefs.isSetupCompleted(this)||permissionRepairShown)return;
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);
        boolean notifications=Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
        boolean exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms();
        boolean full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent();
        boolean battery=pm.isIgnoringBatteryOptimizations(getPackageName());
        boolean dnd=nm.isNotificationPolicyAccessGranted();
        if(notifications&&exact&&full&&battery&&dnd)return;
        permissionRepairShown=true;
        new android.app.AlertDialog.Builder(this)
            .setTitle("یک دسترسی Nexa غیرفعال شده")
            .setMessage("Android یا One UI یکی از دسترسی‌های ضروری هشدارها را غیرفعال کرده است. Nexa خودش هیچ دسترسی تأییدشده‌ای را حذف نمی‌کند. برای حفظ هشدار دارو، یادآورها و Lock Screen، وضعیت واقعی سیستم را دوباره تأیید کن.")
            .setPositiveButton("بررسی و فعال‌سازی",(d,w)->{Intent i=new Intent(this,SettingsActivity.class);i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);startActivity(i);})
            .setNegativeButton("بعداً",null)
            .show();
    }

    @Override protected void onPause(){
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private void build(){
        LinearLayout screen=new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,22));
        sc.addView(root);

        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout hb=new LinearLayout(this);
        hb.setOrientation(LinearLayout.VERTICAL);
        head.addView(hb,new LinearLayout.LayoutParams(0,-2,1f));

        TextView logo=UiKit.title(this,"NEXA");
        logo.setTextSize(34);
        hb.addView(logo);
        hb.addView(UiKit.muted(this,"Obsidian Personal Assistant • "+VersionUtil.name(this)));

        Button quick=UiKit.secondaryButton(this,"＋");
        quick.setTextSize(24);
        quick.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        head.addView(quick);

        Button settings=UiKit.secondaryButton(this,"⚙");
        settings.setTextSize(21);
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        head.addView(settings);

        root.addView(head,UiKit.matchWrap(this,0,18));

        FrameLayout hero=new FrameLayout(this);
        hero.setBackground(UiKit.accentCard(this));
        hero.setPadding(UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20));
        root.addView(hero,UiKit.matchWrap(this,0,14));

        AuraView aura=new AuraView(this);
        FrameLayout.LayoutParams ap=new FrameLayout.LayoutParams(UiKit.dp(this,270),UiKit.dp(this,270));
        ap.gravity=Gravity.CENTER;
        hero.addView(aura,ap);

        ring=new RingTimerView(this);
        int[] themePalette=UiKit.palette(this);
        ring.setColors(themePalette[4],UiKit.withAlpha(themePalette[7],0x30));
        FrameLayout.LayoutParams rp=new FrameLayout.LayoutParams(UiKit.dp(this,220),UiKit.dp(this,220));
        rp.gravity=Gravity.CENTER;
        hero.addView(ring,rp);

        LinearLayout ht=new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hp=new FrameLayout.LayoutParams(UiKit.dp(this,190),UiKit.dp(this,190));
        hp.gravity=Gravity.CENTER;
        hero.addView(ht,hp);

        heroState=UiKit.muted(this,"");
        heroState.setTextColor(UiKit.CYAN);
        heroState.setGravity(Gravity.CENTER);
        ht.addView(heroState);

        heroTime=UiKit.title(this,"");
        heroTime.setTextSize(33);
        heroTime.setGravity(Gravity.CENTER);
        ht.addView(heroTime,UiKit.matchWrap(this,6,3));

        heroSub=UiKit.muted(this,"");
        heroSub.setGravity(Gravity.CENTER);
        ht.addView(heroSub);

        LinearLayout quickTimers=new LinearLayout(this);
        quickTimers.setOrientation(LinearLayout.HORIZONTAL);
        addQuick(quickTimers,"15 دقیقه",15);
        addQuick(quickTimers,"30 دقیقه",30);
        addQuick(quickTimers,"1 ساعت",60);
        root.addView(quickTimers,UiKit.matchWrap(this,0,12));

        Button quickAdd=UiKit.primaryButton(this,"＋ ثبت سریع در Nexa");
        quickAdd.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        root.addView(quickAdd,UiKit.matchWrap(this,0,14));

        LinearLayout today=UiKit.colorfulCardLayout(this,1);
        today.addView(UiKit.sectionTitle(this,"✦ امروز در Nexa"));
        todaySummary=UiKit.muted(this,"");
        today.addView(todaySummary,UiKit.matchWrap(this,7,10));
        Button openToday=UiKit.secondaryButton(this,"باز کردن Nexa Today");
        openToday.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        today.addView(openToday);
        root.addView(today,UiKit.matchWrap(this,0,14));

        root.addView(UiKit.sectionTitle(this,"ماژول‌های Nexa"),UiKit.matchWrap(this,0,10));

        addFeatureRow(root,
                new Feature("🔕","Nexa Silent","سکوت و تماس مهم",SilentHubActivity.class,0),
                new Feature("✦","Nexa Today","خلاصه امروز",TodayActivity.class,1));

        addFeatureRow(root,
                new Feature("📅","Nexa Reminder","قرار و سررسید",RemindersActivity.class,1),
                new Feature("💊","Nexa Med","دارو و مصرف",MedicineActivity.class,2));

        addFeatureRow(root,
                new Feature("🚗","Nexa Garage","سرویس و کیلومتر",GarageActivity.class,2),
                new Feature("🛒","Nexa List","خرید و To‑Do",NexaListActivity.class,3));

        addFeatureRow(root,
                new Feature("⚖️","Nexa Case","دادگاه و پرونده",CaseActivity.class,3),
                new Feature("🔐","Nexa Vault","اطلاعات محرمانه",VaultActivity.class,3));

        addFeatureRow(root,
                new Feature("📈","Nexa Assets","دارایی و سود/زیان",AssetsActivity.class,1),
                new Feature("📄","Nexa Docs","مدارک و انقضا",DocsActivity.class,1));

        addFeatureRow(root,
                new Feature("💳","Nexa Bills","قسط و پرداخت",BillsActivity.class,2),
                new Feature("🆘","Nexa Emergency","کارت اضطراری",EmergencyActivity.class,3));

        addFeatureRow(root,
                new Feature("🏠","Nexa Home","سرویس منزل",HomeCareActivity.class,2),
                new Feature("◷","Timeline & History","خط زمانی و سوابق",TimelineActivity.class,0));


        TextView foot=UiKit.muted(this,"Nexa "+VersionUtil.name(this)+" • سازنده: Darvish • 09354485733");
        foot.setGravity(Gravity.CENTER);
        root.addView(foot,UiKit.matchWrap(this,14,8));

        screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));

        LinearLayout bottom=UiKit.bottomNav(
                this,0,
                v->{},
                v->startActivity(new Intent(this,TodayActivity.class)),
                v->startActivity(new Intent(this,QuickAddActivity.class)),
                v->startActivity(new Intent(this,TimelineActivity.class))
        );
        LinearLayout.LayoutParams bp=UiKit.matchWrap(this);
        bp.setMargins(UiKit.dp(this,16),0,UiKit.dp(this,16),UiKit.dp(this,12));
        screen.addView(bottom,bp);

        setContentView(screen);
        refresh();
    }

    private static final class Feature{
        String icon,title,sub;
        Class<?> cls;
        int v;
        Feature(String i,String t,String s,Class<?>c,int x){
            icon=i;title=t;sub=s;cls=c;v=x;
        }
    }

    private void addFeatureRow(LinearLayout root,Feature a,Feature b){
        if(a==null && b==null)return;
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if(a!=null) row.addView(tile(a),tileLp(true));
        if(b!=null) row.addView(tile(b),tileLp(false));
        root.addView(row,UiKit.matchWrap(this,0,10));
    }

    private LinearLayout.LayoutParams tileLp(boolean first){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,UiKit.dp(this,124),1f);
        if(first)p.setMargins(0,0,UiKit.dp(this,5),0);
        else p.setMargins(UiKit.dp(this,5),0,0,0);
        return p;
    }

    private View tile(Feature f){
        LinearLayout c=UiKit.colorfulCardLayout(this,f.v);
        c.setGravity(Gravity.CENTER);

        TextView icon=UiKit.title(this,f.icon);
        icon.setTextSize(28);
        icon.setGravity(Gravity.CENTER);
        c.addView(icon);

        TextView t=UiKit.sectionTitle(this,f.title);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(15);
        c.addView(t,UiKit.matchWrap(this,4,1));

        TextView s=UiKit.muted(this,f.sub);
        s.setGravity(Gravity.CENTER);
        c.addView(s);

        c.setOnClickListener(v->startActivity(new Intent(this,f.cls)));
        return c;
    }

    private void addQuick(LinearLayout row,String text,int min){
        TextView chip=UiKit.chip(this,text,false);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
        p.setMargins(UiKit.dp(this,4),0,UiKit.dp(this,4),0);
        row.addView(chip,p);

        chip.setOnClickListener(v->{
            if(!AppPrefs.isSetupCompleted(this)){
                Intent i=new Intent(this,SettingsActivity.class);
                i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
                startActivity(i);
                return;
            }

            Intent i=new Intent(this,SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_START);
            i.putExtra(SilentTimerService.EXTRA_MINUTES,min);
            i.putExtra(SilentTimerService.EXTRA_TARGET_MODE,AudioManager.RINGER_MODE_SILENT);

            try{
                if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
                else startService(i);
            }catch(Exception ignored){}

            Toast.makeText(this,"تایمر شروع شد.",Toast.LENGTH_SHORT).show();
        });
    }

    private void refresh(){
        if(heroTime==null)return;

        long now=System.currentTimeMillis();
        long end=AppPrefs.getEndAt(this);
        long start=AppPrefs.getStartAt(this);

        if(end>now){
            long rem=end-now,sec=rem/1000,h=sec/3600,m=(sec%3600)/60,s=sec%60;
            heroState.setText("● تایمر فعال");
            heroTime.setText(h>0
                    ?String.format(Locale.US,"%02d:%02d:%02d",h,m,s)
                    :String.format(Locale.US,"%02d:%02d",m,s));
            heroSub.setText(
                    (AppPrefs.getTargetRingerMode(this)==AudioManager.RINGER_MODE_VIBRATE?"Vibrate":"Silent")+
                            " • پایان "+
                            new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(end))
            );
            float prog=0;
            if(start>0&&end>start)prog=1f-(float)rem/(float)(end-start);
            ring.setProgress(prog);
        }else{
            heroState.setText("● آماده");
            heroTime.setText("Nexa");
            heroSub.setText("دستیار شخصی آماده است");
            ring.setProgress(0);
        }

        int upcoming=0;
        for(NexaStore.Reminder r:NexaStore.reminders(this))
            if(r.whenMillis>=now&&r.whenMillis<=now+24L*60L*60L*1000)upcoming++;

        int meds=0;
        for(NexaStore.Medicine m:NexaStore.medicines(this))if(m.active)meds++;

        int tasks=0;
        for(NexaStore.TodoItem t:NexaStore.todos(this))if(!t.done)tasks++;

        int bills=0;
        for(NexaStore.BillItem b:NexaStore.bills(this))if(!b.paid)bills++;

        todaySummary.setText(
                upcoming+" یادآور نزدیک • "+
                meds+" برنامه دارویی • "+
                tasks+" کار باز • "+
                bills+" پرداخت باز"
        );
    }

    private void ensureMonitor(){
        if(!AppPrefs.isMonitoringEnabled(this))return;

        Intent i=new Intent(this,SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_MONITOR);

        try{
            if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
            else startService(i);
        }catch(Exception ignored){}

        ReminderScheduler.rescheduleAll(this);
        EmergencyCardManager.refresh(this);
    }
}
