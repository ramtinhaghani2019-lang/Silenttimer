package com.example.silenttimer;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import java.text.DecimalFormat;

public final class NumberFormatUtil {
    private NumberFormatUtil() {}

    public static void attachThousands(EditText e) {
        e.addTextChangedListener(new TextWatcher() {
            boolean busy=false;
            @Override public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            @Override public void onTextChanged(CharSequence s,int st,int b,int c){}
            @Override public void afterTextChanged(Editable ed){
                if(busy)return;
                String raw=toLatin(ed.toString()).replace(",","").replace("٬","").trim();
                if(raw.isEmpty()||"-".equals(raw))return;
                if(!raw.matches("-?\\d+"))return;
                try{
                    long v=Long.parseLong(raw);
                    String formatted=new DecimalFormat("#,###").format(v);
                    if(!formatted.equals(ed.toString())){
                        busy=true;e.setText(formatted);e.setSelection(formatted.length());busy=false;
                    }
                }catch(Exception ignored){}
            }
        });
    }


    public static void attachThousandsDecimal(EditText e) {
        e.addTextChangedListener(new TextWatcher() {
            boolean busy=false;
            @Override public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            @Override public void onTextChanged(CharSequence s,int st,int b,int c){}
            @Override public void afterTextChanged(Editable ed){
                if(busy)return;String raw=toLatin(ed.toString()).replace(",","").replace("٬","").replace("٫",".").trim();
                if(raw.isEmpty()||raw.equals(".")||raw.equals("-"))return;
                if(!raw.matches("-?\\d*(\\.\\d*)?"))return;
                try{String[]parts=raw.split("\\.",-1);long whole=parts[0].isEmpty()?0:Long.parseLong(parts[0]);String formatted=new DecimalFormat("#,###").format(whole);if(raw.startsWith("-")&&whole==0)formatted="-0";if(parts.length>1)formatted += "."+parts[1];if(!formatted.equals(ed.toString())){busy=true;e.setText(formatted);e.setSelection(formatted.length());busy=false;}}catch(Exception ignored){}
            }
        });
    }

    public static double doubleValue(CharSequence s){try{return Double.parseDouble(toLatin(String.valueOf(s)).replace(",","").replace("٬","").replace("٫",".").trim());}catch(Exception e){return 0d;}}

    public static long longValue(CharSequence s) {
        try{return Long.parseLong(toLatin(String.valueOf(s)).replace(",","").replace("٬","").trim());}
        catch(Exception e){return 0L;}
    }

    public static int intValue(CharSequence s) {
        long v=longValue(s);return v>Integer.MAX_VALUE?Integer.MAX_VALUE:(int)Math.max(Integer.MIN_VALUE,v);
    }

        public static String grouped(long v){return new DecimalFormat("#,###").format(v);}

    public static String format(long v){return grouped(v);}

public static String toLatin(String s){
        if(s==null)return "";
        String fa="۰۱۲۳۴۵۶۷۸۹", ar="٠١٢٣٤٥٦٧٨٩";
        StringBuilder out=new StringBuilder();
        for(char ch:s.toCharArray()){
            int i=fa.indexOf(ch); if(i>=0){out.append((char)('0'+i));continue;}
            i=ar.indexOf(ch); if(i>=0){out.append((char)('0'+i));continue;}
            out.append(ch);
        }
        return out.toString();
    }
}
