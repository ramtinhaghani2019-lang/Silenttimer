package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class MedicineScheduler {
    private MedicineScheduler(){}
    public static void rescheduleAll(Context c){for(NexaStore.Medicine m:NexaStore.medicines(c))if(m.active)schedule(c,m);}
    public static void cancel(Context c,String id){Intent i=new Intent(c,MedicineAlarmReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,("med"+id).hashCode(),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null){android.app.AlarmManager am=(android.app.AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pi);pi.cancel();}}
    public static void schedule(Context c,NexaStore.Medicine m){if(!m.active||m.nextDoseMillis<=0)return;if(m.endMillis>0&&m.nextDoseMillis>m.endMillis)return;Intent i=new Intent(c,MedicineAlarmReceiver.class);i.putExtra("id",m.id);PendingIntent pi=PendingIntent.getBroadcast(c,("med"+m.id).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);ReminderScheduler.setAlarm(c,Math.max(System.currentTimeMillis()+1000,m.nextDoseMillis),pi);}
}
