package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.method.PasswordTransformationMethod;
import android.view.inputmethod.InputMethodManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class VaultActivity extends Activity {
    private LinearLayout list;
    private static final int VAULT_UNLOCK=701;
    private boolean authenticated=false;
    private boolean awaitingUnlock=false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        UiKit.applyWindow(this);

        // Never construct the secret-bearing UI before Vault-specific authentication.
        if(!NexaStore.pinConfigured(this)){
            Toast.makeText(this,"ابتدا PIN صندوق امن را در تنظیمات امنیت فعال کنید.",Toast.LENGTH_LONG).show();
            startActivity(new android.content.Intent(this,SecurityActivity.class));
            finish();return;
        }
        SecurityGate.lock();
        awaitingUnlock=true;
        startActivityForResult(new android.content.Intent(this, UnlockActivity.class),VAULT_UNLOCK);
    }
    @Override protected void onActivityResult(int request,int result,android.content.Intent data){
        super.onActivityResult(request,result,data);
        if(request==VAULT_UNLOCK){awaitingUnlock=false;
            if(result==RESULT_OK && SecurityGate.isUnlocked()){
                authenticated=true;build();getWindow().getDecorView().setVisibility(View.VISIBLE);
                if(getIntent().getBooleanExtra("quick_add",false))list.postDelayed(this::addDialog,300);
            }else finish();
        }
    }
    @Override protected void onStop(){super.onStop();
        // Relock when leaving this screen. Existing displayed values are discarded on return.
        if(authenticated){authenticated=false;SecurityGate.lock();getWindow().getDecorView().setVisibility(View.INVISIBLE);}
    }
    @Override protected void onRestart(){super.onRestart();
        if(!awaitingUnlock && !authenticated && NexaStore.pinConfigured(this)){awaitingUnlock=true;
            startActivityForResult(new android.content.Intent(this,UnlockActivity.class),VAULT_UNLOCK);}
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Vault"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"رمزها و یادداشت‌های محرمانه؛ داده حساس با Android Keystore رمزگذاری می‌شود."),UiKit.matchWrap(this,0,14));

        LinearLayout security=UiKit.colorfulCardLayout(this,3);
        security.addView(UiKit.sectionTitle(this,"🔐 صندوق امن"));
        if(!NexaStore.lockEnabled(this)) {
            security.addView(UiKit.muted(this,"پیشنهاد: قبل از استفاده، قفل PIN/اثر انگشت Nexa را از تنظیمات فعال کن."),UiKit.matchWrap(this,6,10));
            Button openSec=UiKit.secondaryButton(this,"رفتن به تنظیمات امنیت");
            openSec.setOnClickListener(v->startActivity(new android.content.Intent(this,SecurityActivity.class)));
            security.addView(openSec);
        } else {
            security.addView(UiKit.muted(this,"قفل Nexa فعال است • اسکرین‌شات این صفحه غیرفعال است."),UiKit.matchWrap(this,6,0));
        }
        root.addView(security,UiKit.matchWrap(this,0,12));

        Button add=UiKit.primaryButton(this,"＋ مورد محرمانه جدید");
        add.setOnClickListener(v->addDialog());
        root.addView(add,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() { editDialog(null); }

    private void editDialog(NexaStore.VaultEntry existing) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        Spinner type=new Spinner(this);
        java.util.List<String> types=new java.util.ArrayList<>();
        java.util.Collections.addAll(types,"اینستاگرام / شبکه اجتماعی","بانک‌ها","ایمیل‌ها","سایت‌ها","Wi-Fi","یادداشت محرمانه","سایر");
        for(NexaStore.VaultEntry x:NexaStore.vault(this))if(!types.contains(x.type))types.add(x.type);
        types.add("➕ مجموعه جدید");
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,types){
            @Override public View getView(int position,View convert,android.view.ViewGroup parent){TextView v=(TextView)super.getView(position,convert,parent);v.setTextColor(UiKit.TEXT);v.setPadding(12,16,12,16);return v;}
            @Override public View getDropDownView(int position,View convert,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convert,parent);v.setTextColor(UiKit.TEXT);v.setBackgroundColor(UiKit.CARD_2);v.setPadding(18,16,18,16);return v;}
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);type.setAdapter(adapter);
        type.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){
                if(pos==types.size()-1){EditText input=field("نام مجموعه جدید");new AlertDialog.Builder(VaultActivity.this)
                    .setTitle("➕ مجموعه جدید").setView(input)
                    .setPositiveButton("افزودن",(d,w)->{String value=input.getText().toString().trim();
                        if(!value.isEmpty() && !types.contains(value)){types.add(types.size()-1,value);adapter.notifyDataSetChanged();type.setSelection(types.indexOf(value));}})
                    .setNegativeButton("انصراف",(d,w)->type.setSelection(0)).show();}
            }
        });

        EditText title=field("عنوان؛ مثلاً ایمیل کاری");
        EditText username=field("نام کاربری / ایمیل / شناسه");
        EditText secret=field("رمز / اطلاعات محرمانه");
        secret.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText note=field("یادداشت");

        secret.setTextDirection(View.TEXT_DIRECTION_LTR);secret.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        username.setTextDirection(View.TEXT_DIRECTION_LTR);
        if(existing!=null){
            type.setSelection(Math.max(0,types.indexOf(existing.type)));
            title.setText(existing.title);username.setText(VaultCrypto.decrypt(existing.usernameEncrypted));
            secret.setText(VaultCrypto.decrypt(existing.secretEncrypted));note.setText(VaultCrypto.decrypt(existing.noteEncrypted));
        }
        box.addView(type);box.addView(title);box.addView(username);box.addView(secret);box.addView(note);

        new AlertDialog.Builder(this)
                .setTitle(existing==null?"مورد محرمانه جدید":"ویرایش مورد محرمانه")
                .setMessage("برای کارت بانکی بهتر است رمز پویا، CVV2 و اطلاعاتی که امکان سوءاستفاده مستقیم دارند ذخیره نشوند.")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())return;

                    NexaStore.VaultEntry x=existing==null?new NexaStore.VaultEntry():existing;
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.usernameEncrypted=VaultCrypto.encrypt(username.getText().toString());
                    x.secretEncrypted=VaultCrypto.encrypt(secret.getText().toString());
                    x.noteEncrypted=VaultCrypto.encrypt(note.getText().toString());

                    if((!username.getText().toString().isEmpty() && x.usernameEncrypted.isEmpty()) ||
                       (!secret.getText().toString().isEmpty() && x.secretEncrypted.isEmpty())) {
                        Toast.makeText(this,"رمزگذاری انجام نشد؛ مورد ذخیره نشد.",Toast.LENGTH_LONG).show();
                        return;
                    }

                    if(existing==null)NexaStore.addVault(this,x);else NexaStore.updateVault(this,x);
                    NexaStore.addHistory(this,"Vault",(existing==null?"مورد جدید: ":"ویرایش مورد: ")+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.VaultEntry> data=NexaStore.vault(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"هنوز چیزی در Vault ذخیره نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        java.util.Map<String,java.util.List<NexaStore.VaultEntry>> groups=new java.util.LinkedHashMap<>();
        for(NexaStore.VaultEntry x:data){
            if(!groups.containsKey(x.type))groups.put(x.type,new java.util.ArrayList<>());
            groups.get(x.type).add(x);
        }
        for(java.util.Map.Entry<String,java.util.List<NexaStore.VaultEntry>> group:groups.entrySet()){
            LinearLayout groupCard=UiKit.colorfulCardLayout(this,3);
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
            body.setVisibility(View.GONE);
            Button toggle=UiKit.secondaryButton(this,"▸ "+group.getKey()+"  ("+group.getValue().size()+")");
            toggle.setOnClickListener(v->{boolean open=body.getVisibility()!=View.VISIBLE;
                body.setVisibility(open?View.VISIBLE:View.GONE);
                toggle.setText((open?"▾ ":"▸ ")+group.getKey()+"  ("+group.getValue().size()+")");});
            groupCard.addView(toggle);
            for(NexaStore.VaultEntry x:group.getValue()){
                LinearLayout c=UiKit.cardLayout(this);
                c.addView(UiKit.sectionTitle(this,"🔐 "+x.title));
                TextView secret=UiKit.muted(this,"••••••••");secret.setTextSize(16);
                secret.setTextDirection(View.TEXT_DIRECTION_LTR);
                secret.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
                secret.setGravity(Gravity.LEFT);
                c.addView(secret,UiKit.matchWrap(this,10,8));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button show=UiKit.secondaryButton(this,"👁 نمایش");
                final Runnable hide=()->secret.setText("••••••••");
                show.setOnClickListener(v->{
                    if(!authenticated){android.widget.Toast.makeText(this,"صندوق قفل است.",Toast.LENGTH_SHORT).show();return;}
                    String u=VaultCrypto.decrypt(x.usernameEncrypted), password=VaultCrypto.decrypt(x.secretEncrypted),n=VaultCrypto.decrypt(x.noteEncrypted);
                    // Separate values in a LTR view to prevent Persian bidi reordering.
                    secret.setText((u.isEmpty()?"":"User: "+u+"\n")+(password.isEmpty()?"":"Password: "+password+"\n")+(n.isEmpty()?"":"Note: "+n));
                    secret.removeCallbacks(hide);secret.postDelayed(hide,15000);
                });
                Button copy=UiKit.secondaryButton(this,"⧉ کپی");
                copy.setOnClickListener(v->{if(!authenticated)return;
                    ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(ClipData.newPlainText("Nexa",VaultCrypto.decrypt(x.secretEncrypted)));
                    Toast.makeText(this,"رمز کپی شد؛ کلیپ‌بورد ممکن است توسط برنامه‌های دیگر خوانده شود.",Toast.LENGTH_LONG).show();});
                Button edit=UiKit.secondaryButton(this,"✎");edit.setOnClickListener(v->editDialog(x));
                Button del=UiKit.secondaryButton(this,"×");
                del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف از Vault؟").setMessage(x.title)
                    .setPositiveButton("حذف",(d,w)->{NexaStore.removeVault(this,x.id);render();})
                    .setNegativeButton("انصراف",null).show());
                for(Button button:new Button[]{show,copy,edit,del})actions.addView(button,new LinearLayout.LayoutParams(0,-2,1f));
                c.addView(actions,UiKit.matchWrap(this,6,0));body.addView(c,UiKit.matchWrap(this,8,0));
            }
            groupCard.addView(body);list.addView(groupCard,UiKit.matchWrap(this,0,10));
        }
    }
}
