package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MedicineActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){String id=i.getStringExtra("id");NexaStore.Medicine m=NexaStore.medicine(c,id);if(m==null)return;((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(("med"+id).hashCode());long now=System.currentTimeMillis();String action=i.getAction();if("SNOOZE".equals(action)){m.nextDoseMillis=now+10*60_000L;NexaStore.addHistory(c,"دارو",m.name+" • ۱۰ دقیقه بعد");}else{if("TAKEN".equals(action))NexaStore.addHistory(c,"دارو",m.name+" • خوردم");else NexaStore.addHistory(c,"دارو",m.name+" • رد شد");m.nextDoseMillis=now+m.intervalHours*60L*60L*1000L;if(m.endMillis>0&&m.nextDoseMillis>m.endMillis)m.active=false;}java.util.List<NexaStore.Medicine>l=NexaStore.medicines(c);for(int x=0;x<l.size();x++)if(l.get(x).id.equals(m.id))l.set(x,m);NexaStore.saveMedicines(c,l);if(m.active)MedicineScheduler.schedule(c,m);}
}
