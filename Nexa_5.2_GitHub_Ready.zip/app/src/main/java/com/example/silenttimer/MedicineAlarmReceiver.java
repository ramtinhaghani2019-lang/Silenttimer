package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class MedicineAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL="nexa_medicine";
    @Override public void onReceive(Context c,Intent i){String id=i.getStringExtra("id");NexaStore.Medicine m=NexaStore.medicine(c,id);if(m==null||!m.active)return;createChannel(c);Intent act=new Intent(c,MedicineActionReceiver.class);act.putExtra("id",id);act.setAction("TAKEN");PendingIntent taken=PendingIntent.getBroadcast(c,(id+"t").hashCode(),act,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent sn=new Intent(c,MedicineActionReceiver.class);sn.putExtra("id",id);sn.setAction("SNOOZE");PendingIntent snooze=PendingIntent.getBroadcast(c,(id+"s").hashCode(),sn,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent sk=new Intent(c,MedicineActionReceiver.class);sk.putExtra("id",id);sk.setAction("SKIP");PendingIntent skip=PendingIntent.getBroadcast(c,(id+"k").hashCode(),sk,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);Notification n=b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("💊 زمان مصرف "+m.name).setContentText(m.dose.isEmpty()?"نوبت دارو رسیده":m.dose).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true).addAction(new Notification.Action.Builder(android.R.drawable.checkbox_on_background,"خوردم",taken).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_popup_reminder,"بعداً",snooze).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"رد شد",skip).build()).build();((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(("med"+id).hashCode(),n);NexaStore.addHistory(c,"دارو","یادآوری "+m.name);m.nextDoseMillis=System.currentTimeMillis()+m.repeatMinutes*60_000L;save(c,m);MedicineScheduler.schedule(c,m);}
    private void createChannel(Context c){if(Build.VERSION.SDK_INT<26)return;NotificationChannelHelper.ensureMedicine(c);}
    private void save(Context c,NexaStore.Medicine m){java.util.List<NexaStore.Medicine>l=NexaStore.medicines(c);for(int x=0;x<l.size();x++)if(l.get(x).id.equals(m.id))l.set(x,m);NexaStore.saveMedicines(c,l);}
}
