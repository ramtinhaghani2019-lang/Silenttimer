package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i){String token=i.getStringExtra("token");if(token==null)return;NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);nm.cancel(token.hashCode());if("DISMISS".equals(i.getAction())){NexaStore.dismissToken(c,token);NexaStore.addHistory(c,"یادآور","هشدار خاموش شد");}else if("SNOOZE".equals(i.getAction())){String id=i.getStringExtra("id");int repeat=i.getIntExtra("repeat",5);ReminderScheduler.scheduleToken(c,id,token,System.currentTimeMillis()+repeat*60_000L,repeat);}}
}
