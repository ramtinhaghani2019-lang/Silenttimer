package com.example.silenttimer;

import android.content.Context;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.Arrays;

/** Reusable optional alert controls: all due-date modules use the same syntax. */
public final class AlertEditor {
    private final EditText rules;
    private final Spinner repeat;
    private static final int[] MINUTES={0,5,10,15,30,60};
    public AlertEditor(Context c,LinearLayout box,String initial,int repeatInitial){
        TextView head=UiKit.sectionTitle(c,"🔔 هشدارهای این مورد");box.addView(head,UiKit.matchWrap(c,10,6));
        TextView hint=UiKit.muted(c,"چند هشدار با ویرگول: D3@09:00 یعنی ۳ روز قبل ساعت ۹؛ 120 یعنی ۱۲۰ دقیقه زودتر. 0 = زمان اصلی");
        box.addView(hint,UiKit.matchWrap(c,2,6));
        rules=new EditText(c);rules.setSingleLine(false);rules.setText(initial);rules.setTextColor(UiKit.TEXT);
        rules.setTextDirection(View.TEXT_DIRECTION_LTR);rules.setHintTextColor(UiKit.MUTED);
        rules.setBackground(UiKit.field(c));rules.setPadding(UiKit.dp(c,12),UiKit.dp(c,10),UiKit.dp(c,12),UiKit.dp(c,10));
        rules.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);box.addView(rules,UiKit.matchWrap(c,0,8));
        repeat=new Spinner(c);
        ArrayAdapter<String> a=new ArrayAdapter<String>(c,android.R.layout.simple_spinner_item,
            Arrays.asList("تکرار خاموش","هر ۵ دقیقه","هر ۱۰ دقیقه","هر ۱۵ دقیقه","هر ۳۰ دقیقه","هر ۶۰ دقیقه")){
            @Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);return t;}
        };a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        repeat.setAdapter(a);for(int i=0;i<MINUTES.length;i++)if(MINUTES[i]==repeatInitial)repeat.setSelection(i);
        box.addView(repeat,UiKit.matchWrap(c,0,8));
    }
    public String rules(){return rules.getText().toString().trim();}
    public int repeatMinutes(){return MINUTES[repeat.getSelectedItemPosition()];}
    public boolean valid(long due){for(String r:AlertRules.split(rules()))if(AlertRules.trigger(due,r)<=0)return false;return true;}
}
