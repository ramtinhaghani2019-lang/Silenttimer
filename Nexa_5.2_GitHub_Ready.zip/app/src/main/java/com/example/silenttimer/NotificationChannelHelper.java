package com.example.silenttimer;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
public final class NotificationChannelHelper {private NotificationChannelHelper(){} public static void ensureMedicine(Context c){NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);NotificationChannel ch=new NotificationChannel(MedicineAlarmReceiver.CHANNEL,"Nexa Medicine",NotificationManager.IMPORTANCE_HIGH);ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);ch.enableVibration(true);nm.createNotificationChannel(ch);}}
