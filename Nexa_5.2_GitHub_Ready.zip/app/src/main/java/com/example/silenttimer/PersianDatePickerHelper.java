package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.widget.LinearLayout;
import android.widget.NumberPicker;

import java.util.Calendar;

public final class PersianDatePickerHelper {
    private PersianDatePickerHelper() {}

    public interface Callback {
        void onPicked(long millis);
    }

    public static void pickDateTime(Activity a, long current, String title, Callback cb) {
        if (current <= 0) current = System.currentTimeMillis();
        final long base = current;

        int[] j = PersianDateUtil.fromMillis(current);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(current);

        LinearLayout row = new LinearLayout(a);
        row.setPadding(UiKit.dp(a, 8), UiKit.dp(a, 8), UiKit.dp(a, 8), UiKit.dp(a, 8));

        NumberPicker year = new NumberPicker(a);
        NumberPicker month = new NumberPicker(a);
        NumberPicker day = new NumberPicker(a);

        year.setMinValue(j[0] - 1);
        year.setMaxValue(j[0] + 15);
        year.setValue(j[0]);

        month.setMinValue(1);
        month.setMaxValue(12);
        month.setDisplayedValues(PersianDateUtil.MONTHS);
        month.setValue(j[1]);

        day.setMinValue(1);
        day.setMaxValue(31);
        day.setValue(j[2]);

        row.addView(year, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(month, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(day, new LinearLayout.LayoutParams(0, -2, 1f));

        new AlertDialog.Builder(a)
                .setTitle(title)
                .setView(row)
                .setPositiveButton("ادامه", (d, w) -> {
                    int yy = year.getValue();
                    int mm = month.getValue();
                    int dd = Math.min(day.getValue(), PersianDateUtil.monthLength(yy, mm));

                    Calendar cc = Calendar.getInstance();
                    cc.setTimeInMillis(base);

                    new TimePickerDialog(
                            a,
                            (v, hh, min) -> cb.onPicked(PersianDateUtil.toMillis(yy, mm, dd, hh, min)),
                            cc.get(Calendar.HOUR_OF_DAY),
                            cc.get(Calendar.MINUTE),
                            true
                    ).show();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    public static void pickDate(Activity a, long current, String title, Callback cb) {
        if (current <= 0) current = System.currentTimeMillis();
        int[] j = PersianDateUtil.fromMillis(current);

        LinearLayout row = new LinearLayout(a);
        row.setPadding(UiKit.dp(a, 8), UiKit.dp(a, 8), UiKit.dp(a, 8), UiKit.dp(a, 8));

        NumberPicker year = new NumberPicker(a);
        NumberPicker month = new NumberPicker(a);
        NumberPicker day = new NumberPicker(a);

        year.setMinValue(j[0] - 5);
        year.setMaxValue(j[0] + 20);
        year.setValue(j[0]);

        month.setMinValue(1);
        month.setMaxValue(12);
        month.setDisplayedValues(PersianDateUtil.MONTHS);
        month.setValue(j[1]);

        day.setMinValue(1);
        day.setMaxValue(31);
        day.setValue(j[2]);

        row.addView(year, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(month, new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(day, new LinearLayout.LayoutParams(0, -2, 1f));

        new AlertDialog.Builder(a)
                .setTitle(title)
                .setView(row)
                .setPositiveButton("تأیید", (d, w) -> {
                    int yy = year.getValue();
                    int mm = month.getValue();
                    int dd = Math.min(day.getValue(), PersianDateUtil.monthLength(yy, mm));
                    cb.onPicked(PersianDateUtil.toMillis(yy, mm, dd, 9, 0));
                })
                .setNegativeButton("انصراف", null)
                .show();
    }
}
