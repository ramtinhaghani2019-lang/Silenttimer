package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class NexaStore {
    private static final String PREF = "nexa_store";
    private NexaStore() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static final class Reminder {
        public String id = UUID.randomUUID().toString();
        public String title = "";
        public String category = "قرار";
        public String icon = "📅";
        public String note = "";
        public String sourceKey = "";
        public String doctorName = "";
        public String doctorFileNumber = "";
        public String doctorCenter = "";
        public String doctorPhone = "";
        public String doctorAddress = "";
        public long whenMillis;
        public String offsetsMinutes = "5760,1440,0";
        public int repeatMinutes = 5;
        public boolean done = false;
        public boolean active = true;

        JSONObject json() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("title", title); o.put("category", category); o.put("icon", icon);
            o.put("note", note); o.put("sourceKey", sourceKey);
            o.put("doctorName", doctorName); o.put("doctorFileNumber", doctorFileNumber);
            o.put("doctorCenter", doctorCenter); o.put("doctorPhone", doctorPhone); o.put("doctorAddress", doctorAddress);
            o.put("when", whenMillis); o.put("offsets", offsetsMinutes);
            o.put("repeat", repeatMinutes);o.put("done", done); o.put("active", active); return o;
        }
        static Reminder from(JSONObject o) {
            Reminder r = new Reminder();
            r.id=o.optString("id",r.id); r.title=o.optString("title",""); r.category=o.optString("category","قرار");
            r.icon=o.optString("icon","📅"); r.note=o.optString("note","");
            r.sourceKey=o.optString("sourceKey","");
            r.doctorName=o.optString("doctorName",""); r.doctorFileNumber=o.optString("doctorFileNumber","");
            r.doctorCenter=o.optString("doctorCenter",""); r.doctorPhone=o.optString("doctorPhone","");
            r.doctorAddress=o.optString("doctorAddress","");
            r.whenMillis=o.optLong("when",0);
            r.offsetsMinutes=o.optString("offsets","5760,1440,0"); r.repeatMinutes=o.optInt("repeat",5);
            r.done=o.optBoolean("done",false); r.active=o.optBoolean("active",true); return r;
        }
    }

    public static final class Medicine {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public String dose = "";
        public int intervalHours = 8;
        public long nextDoseMillis;
        public long endMillis;
        public int repeatMinutes = 5;
        public boolean active = true;
        public String doctor=""; public long prescriptionDate=0;
        JSONObject json() throws Exception { JSONObject o=new JSONObject();o.put("doctor",doctor);o.put("prescriptionDate",prescriptionDate); o.put("id",id);o.put("name",name);o.put("dose",dose);o.put("interval",intervalHours);o.put("next",nextDoseMillis);o.put("end",endMillis);o.put("repeat",repeatMinutes);o.put("active",active);return o; }
        static Medicine from(JSONObject o){Medicine m=new Medicine();m.id=o.optString("id",m.id);m.name=o.optString("name","");m.dose=o.optString("dose","");m.intervalHours=o.optInt("interval",8);m.nextDoseMillis=o.optLong("next",0);m.endMillis=o.optLong("end",0);m.repeatMinutes=o.optInt("repeat",5);m.active=o.optBoolean("active",true);m.doctor=o.optString("doctor","");m.prescriptionDate=o.optLong("prescriptionDate",0);return m;}
    }

    public static final class Vehicle {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public String type = "خودرو";
        public int currentKm = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("type",type);o.put("km",currentKm);return o;}
        static Vehicle from(JSONObject o){Vehicle v=new Vehicle();v.id=o.optString("id",v.id);v.name=o.optString("name","");v.type=o.optString("type","خودرو");v.currentKm=o.optInt("km",0);return v;}
    }

    public static final class ServiceRecord {
        public String id = UUID.randomUUID().toString();
        public String vehicleId = "";
        public String category = "سرویس دوره‌ای";
        public String icon = "🔧";
        public long dateMillis = System.currentTimeMillis();
        public int km = 0;
        public String note = "";
        public long cost = 0;
        public int nextDueKm = 0;
        public long nextDueDate = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("vehicle",vehicleId);o.put("category",category);o.put("icon",icon);o.put("date",dateMillis);o.put("km",km);o.put("note",note);o.put("cost",cost);o.put("nextKm",nextDueKm);o.put("nextDate",nextDueDate);return o;}
        static ServiceRecord from(JSONObject o){ServiceRecord r=new ServiceRecord();r.id=o.optString("id",r.id);r.vehicleId=o.optString("vehicle","");r.category=o.optString("category","سرویس دوره‌ای");r.icon=o.optString("icon","🔧");r.dateMillis=o.optLong("date",0);r.km=o.optInt("km",0);r.note=o.optString("note","");r.cost=o.optLong("cost",0);r.nextDueKm=o.optInt("nextKm",0);r.nextDueDate=o.optLong("nextDate",0);return r;}
    }

    public static final class FuelRecord {
        public String id = UUID.randomUUID().toString();
        public String vehicleId = "";
        public long dateMillis = System.currentTimeMillis();
        public int km = 0;
        public double liters = 0;
        public long cost = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("vehicle",vehicleId);o.put("date",dateMillis);o.put("km",km);o.put("liters",liters);o.put("cost",cost);return o;}
        static FuelRecord from(JSONObject o){FuelRecord f=new FuelRecord();f.id=o.optString("id",f.id);f.vehicleId=o.optString("vehicle","");f.dateMillis=o.optLong("date",0);f.km=o.optInt("km",0);f.liters=o.optDouble("liters",0);f.cost=o.optLong("cost",0);return f;}
    }

    public static final class Profile {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public int minutes = 60;
        public int mode = 0;
        public boolean allowedCalls = true;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("minutes",minutes);o.put("mode",mode);o.put("allowed",allowedCalls);return o;}
        static Profile from(JSONObject o){Profile x=new Profile();x.id=o.optString("id",x.id);x.name=o.optString("name","");x.minutes=o.optInt("minutes",60);x.mode=o.optInt("mode",0);x.allowedCalls=o.optBoolean("allowed",true);return x;}
    }

    public static final class WeeklySchedule {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public int daysMask = 62; // Mon-Fri Calendar bit mapping below
        public int startHour = 9, startMinute = 0;
        public int endHour = 17, endMinute = 0;
        public int mode = 0;
        public boolean enabled = true;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("days",daysMask);o.put("sh",startHour);o.put("sm",startMinute);o.put("eh",endHour);o.put("em",endMinute);o.put("mode",mode);o.put("enabled",enabled);return o;}
        static WeeklySchedule from(JSONObject o){WeeklySchedule s=new WeeklySchedule();s.id=o.optString("id",s.id);s.name=o.optString("name","");s.daysMask=o.optInt("days",62);s.startHour=o.optInt("sh",9);s.startMinute=o.optInt("sm",0);s.endHour=o.optInt("eh",17);s.endMinute=o.optInt("em",0);s.mode=o.optInt("mode",0);s.enabled=o.optBoolean("enabled",true);return s;}
    }

    public static final class HistoryItem {
        public long time = System.currentTimeMillis();
        public String type = "";
        public String text = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("time",time);o.put("type",type);o.put("text",text);return o;}
        static HistoryItem from(JSONObject o){HistoryItem h=new HistoryItem();h.time=o.optLong("time",0);h.type=o.optString("type","");h.text=o.optString("text","");return h;}
    }

    public static final class ShoppingItem {
        public String id = UUID.randomUUID().toString();
        public String listName = "خرید";
        public String name = "";
        public String quantity = "";
        public String category = "";
        public long price = 0;
        public String store="";
        public String receiptUri="";
        public long purchasedAt=0;
        public boolean important = false;
        public boolean done = false;
        public long createdAt = System.currentTimeMillis();
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("list",listName);o.put("name",name);o.put("qty",quantity);o.put("category",category);o.put("price",price);o.put("store",store);o.put("receipt",receiptUri);o.put("purchasedAt",purchasedAt);o.put("important",important);o.put("done",done);o.put("created",createdAt);return o;}
        static ShoppingItem from(JSONObject o){ShoppingItem x=new ShoppingItem();x.id=o.optString("id",x.id);x.listName=o.optString("list","خرید");x.name=o.optString("name","");x.quantity=o.optString("qty","");x.category=o.optString("category","");x.price=o.optLong("price",0);x.store=o.optString("store","");x.receiptUri=o.optString("receipt","");x.purchasedAt=o.optLong("purchasedAt",0);x.important=o.optBoolean("important",false);x.done=o.optBoolean("done",false);x.createdAt=o.optLong("created",0);return x;}
    }

    public static final class TodoItem {
        public String id = UUID.randomUUID().toString();
        public String title = "";
        public String category = "عمومی";
        public String note = "";
        public long dueMillis = 0;
        public boolean done = false;
        public long createdAt = System.currentTimeMillis();
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("title",title);o.put("category",category);o.put("note",note);o.put("due",dueMillis);o.put("done",done);o.put("created",createdAt);return o;}
        static TodoItem from(JSONObject o){TodoItem x=new TodoItem();x.id=o.optString("id",x.id);x.title=o.optString("title","");x.category=o.optString("category","عمومی");x.note=o.optString("note","");x.dueMillis=o.optLong("due",0);x.done=o.optBoolean("done",false);x.createdAt=o.optLong("created",0);return x;}
    }

    public static final class CaseItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String title = "";
        public String caseNumber = "";
        public String court = "";
        public String branch = "";
        public String counterparty = "";
        public String lawyer = "";
        public String note = "";
        public long whenMillis = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("title",title);o.put("case",caseNumber);o.put("court",court);o.put("branch",branch);o.put("party",counterparty);o.put("lawyer",lawyer);o.put("note",note);o.put("when",whenMillis);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static CaseItem from(JSONObject o){CaseItem x=new CaseItem();x.id=o.optString("id",x.id);x.title=o.optString("title","");x.caseNumber=o.optString("case","");x.court=o.optString("court","");x.branch=o.optString("branch","");x.counterparty=o.optString("party","");x.lawyer=o.optString("lawyer","");x.note=o.optString("note","");x.whenMillis=o.optLong("when",0);x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    public static final class VaultEntry {
        public String id = UUID.randomUUID().toString();
        public String type = "اکانت";
        public String title = "";
        public String usernameEncrypted = "";
        public String secretEncrypted = "";
        public String noteEncrypted = "";
        public long updatedAt = System.currentTimeMillis();
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("title",title);o.put("user",usernameEncrypted);o.put("secret",secretEncrypted);o.put("note",noteEncrypted);o.put("updated",updatedAt);return o;}
        static VaultEntry from(JSONObject o){VaultEntry x=new VaultEntry();x.id=o.optString("id",x.id);x.type=o.optString("type","اکانت");x.title=o.optString("title","");x.usernameEncrypted=o.optString("user","");x.secretEncrypted=o.optString("secret","");x.noteEncrypted=o.optString("note","");x.updatedAt=o.optLong("updated",0);return x;}
    }

    public static final class AssetEntry {
        public String id = UUID.randomUUID().toString();
        public String type = "سایر";
        public String name = "";
        public double amount = 0;
        public double buyUnitPrice = 0;
        public double currentUnitPrice = 0;
        public double fee = 0;
        public String currency = "تومان";
        public boolean autoPrice = false;
        public long buyDate = System.currentTimeMillis();
        public String note = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("name",name);o.put("amount",amount);o.put("buy",buyUnitPrice);o.put("current",currentUnitPrice);o.put("fee",fee);o.put("currency",currency);o.put("autoPrice",autoPrice);o.put("date",buyDate);o.put("note",note);return o;}
        static AssetEntry from(JSONObject o){AssetEntry x=new AssetEntry();x.id=o.optString("id",x.id);x.type=o.optString("type","سایر");x.name=o.optString("name","");x.amount=o.optDouble("amount",0);x.buyUnitPrice=o.optDouble("buy",0);x.currentUnitPrice=o.optDouble("current",0);x.fee=o.optDouble("fee",0);x.currency=o.optString("currency","تومان");x.autoPrice=o.optBoolean("autoPrice",false);x.buyDate=o.optLong("date",0);x.note=o.optString("note","");return x;}
    }

    public static final class DocumentItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String type = "مدرک";
        public String title = "";
        public String number = "";
        public long issueDate = 0;
        public long expiryDate = 0;
        public String note = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("title",title);o.put("number",number);o.put("issue",issueDate);o.put("expiry",expiryDate);o.put("note",note);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static DocumentItem from(JSONObject o){DocumentItem x=new DocumentItem();x.id=o.optString("id",x.id);x.type=o.optString("type","مدرک");x.title=o.optString("title","");x.number=o.optString("number","");x.issueDate=o.optLong("issue",0);x.expiryDate=o.optLong("expiry",0);x.note=o.optString("note","");x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    public static final class BillItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String type = "قسط";
        public String title = "";
        public long amount = 0;
        public long dueDate = 0;
        public String recurrence = "یک‌بار";
        public String note = "";
        public boolean paid = false;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("title",title);o.put("amount",amount);o.put("due",dueDate);o.put("repeat",recurrence);o.put("note",note);o.put("paid",paid);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static BillItem from(JSONObject o){BillItem x=new BillItem();x.id=o.optString("id",x.id);x.type=o.optString("type","قسط");x.title=o.optString("title","");x.amount=o.optLong("amount",0);x.dueDate=o.optLong("due",0);x.recurrence=o.optString("repeat","یک‌بار");x.note=o.optString("note","");x.paid=o.optBoolean("paid",false);x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    public static final class HomeItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String category = "خانه";
        public String title = "";
        public long lastServiceDate = 0;
        public long nextDueDate = 0;
        public long cost = 0;
        public String note = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("category",category);o.put("title",title);o.put("last",lastServiceDate);o.put("next",nextDueDate);o.put("cost",cost);o.put("note",note);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static HomeItem from(JSONObject o){HomeItem x=new HomeItem();x.id=o.optString("id",x.id);x.category=o.optString("category","خانه");x.title=o.optString("title","");x.lastServiceDate=o.optLong("last",0);x.nextDueDate=o.optLong("next",0);x.cost=o.optLong("cost",0);x.note=o.optString("note","");x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    private interface Parser<T>{T parse(JSONObject o);} private interface Writer<T>{JSONObject write(T v)throws Exception;}
    private static <T> List<T> read(Context c,String key,Parser<T> parser){List<T> out=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString(key,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(parser.parse(o));}}catch(Exception ignored){}return out;}
    private static <T> void save(Context c,String key,List<T> list,Writer<T> writer){JSONArray a=new JSONArray();try{for(T v:list)a.put(writer.write(v));}catch(Exception ignored){}p(c).edit().putString(key,a.toString()).apply();}

    public static List<Reminder> reminders(Context c){List<Reminder> l=read(c,"reminders",Reminder::from);Collections.sort(l, Comparator.comparingLong(a->a.whenMillis));return l;}
    public static void saveReminders(Context c,List<Reminder> l){save(c,"reminders",l,Reminder::json);} public static void addReminder(Context c,Reminder r){List<Reminder>l=reminders(c);l.add(r);saveReminders(c,l);} public static void removeReminder(Context c,String id){List<Reminder>l=reminders(c);l.removeIf(x->x.id.equals(id));saveReminders(c,l);} public static void updateReminder(Context c,Reminder x){List<Reminder>l=reminders(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveReminders(c,l);} public static Reminder reminder(Context c,String id){for(Reminder r:reminders(c))if(r.id.equals(id))return r;return null;}

    public static List<Medicine> medicines(Context c){return read(c,"medicines",Medicine::from);} public static void saveMedicines(Context c,List<Medicine> l){save(c,"medicines",l,Medicine::json);} public static void addMedicine(Context c,Medicine m){List<Medicine>l=medicines(c);l.add(m);saveMedicines(c,l);} public static void updateMedicine(Context c,Medicine m){List<Medicine>l=medicines(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(m.id))l.set(i,m);saveMedicines(c,l);} public static Medicine medicine(Context c,String id){for(Medicine m:medicines(c))if(m.id.equals(id))return m;return null;} public static void removeMedicine(Context c,String id){List<Medicine>l=medicines(c);l.removeIf(x->x.id.equals(id));saveMedicines(c,l);}

    public static List<Vehicle> vehicles(Context c){return read(c,"vehicles",Vehicle::from);} public static void saveVehicles(Context c,List<Vehicle> l){save(c,"vehicles",l,Vehicle::json);} public static void addVehicle(Context c,Vehicle v){List<Vehicle>l=vehicles(c);l.add(v);saveVehicles(c,l);} public static Vehicle vehicle(Context c,String id){for(Vehicle v:vehicles(c))if(v.id.equals(id))return v;return null;} public static void updateVehicle(Context c,Vehicle v){List<Vehicle>l=vehicles(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(v.id))l.set(i,v);saveVehicles(c,l);}
    public static List<ServiceRecord> services(Context c){return read(c,"services",ServiceRecord::from);} public static void addService(Context c,ServiceRecord r){List<ServiceRecord>l=services(c);l.add(r);save(c,"services",l,ServiceRecord::json);} public static void updateService(Context c,ServiceRecord x){List<ServiceRecord>l=services(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"services",l,ServiceRecord::json);} public static void removeService(Context c,String id){List<ServiceRecord>l=services(c);l.removeIf(x->x.id.equals(id));save(c,"services",l,ServiceRecord::json);} public static List<ServiceRecord> servicesFor(Context c,String vehicleId){List<ServiceRecord>out=new ArrayList<>();for(ServiceRecord r:services(c))if(r.vehicleId.equals(vehicleId))out.add(r);out.sort((a,b)->Long.compare(b.dateMillis,a.dateMillis));return out;}
    public static List<FuelRecord> fuels(Context c){return read(c,"fuels",FuelRecord::from);} public static void addFuel(Context c,FuelRecord r){List<FuelRecord>l=fuels(c);l.add(r);save(c,"fuels",l,FuelRecord::json);} public static void updateFuel(Context c,FuelRecord x){List<FuelRecord>l=fuels(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"fuels",l,FuelRecord::json);} public static void removeFuel(Context c,String id){List<FuelRecord>l=fuels(c);l.removeIf(x->x.id.equals(id));save(c,"fuels",l,FuelRecord::json);} public static List<FuelRecord> fuelsFor(Context c,String vehicleId){List<FuelRecord>out=new ArrayList<>();for(FuelRecord r:fuels(c))if(r.vehicleId.equals(vehicleId))out.add(r);out.sort((a,b)->Long.compare(b.dateMillis,a.dateMillis));return out;}

    public static List<Profile> profiles(Context c){List<Profile>l=read(c,"profiles",Profile::from);if(l.isEmpty()&&!p(c).getBoolean("profiles_initialized",false)){p(c).edit().putBoolean("profiles_initialized",true).apply();String[]n={"جلسه","خواب","مطالعه","کار"};int[]m={60,480,90,120};for(int i=0;i<n.length;i++){Profile x=new Profile();x.name=n[i];x.minutes=m[i];x.mode=0;x.allowedCalls=(i<2);l.add(x);}saveProfiles(c,l);}return l;} public static void saveProfiles(Context c,List<Profile>l){save(c,"profiles",l,Profile::json);} public static void addProfile(Context c,Profile x){List<Profile>l=profiles(c);l.add(x);saveProfiles(c,l);} public static void updateProfile(Context c,Profile x){List<Profile>l=profiles(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveProfiles(c,l);} public static void removeProfile(Context c,String id){List<Profile>l=profiles(c);l.removeIf(x->x.id.equals(id));saveProfiles(c,l);}
    public static List<WeeklySchedule> schedules(Context c){return read(c,"schedules",WeeklySchedule::from);} public static void saveSchedules(Context c,List<WeeklySchedule>l){save(c,"schedules",l,WeeklySchedule::json);} public static void addSchedule(Context c,WeeklySchedule s){List<WeeklySchedule>l=schedules(c);l.add(s);saveSchedules(c,l);} public static void updateSchedule(Context c,WeeklySchedule x){List<WeeklySchedule>l=schedules(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveSchedules(c,l);} public static void removeSchedule(Context c,String id){List<WeeklySchedule>l=schedules(c);l.removeIf(x->x.id.equals(id));saveSchedules(c,l);}

    public static void addHistory(Context c,String type,String text){List<HistoryItem>l=history(c);HistoryItem h=new HistoryItem();h.type=type;h.text=text;l.add(0,h);while(l.size()>300)l.remove(l.size()-1);save(c,"history",l,HistoryItem::json);} public static List<HistoryItem> history(Context c){return read(c,"history",HistoryItem::from);} public static void clearHistory(Context c){p(c).edit().remove("history").apply();}

    public static String[] defaultReminderCategories(){return new String[]{"📅 قرار","🩺 دکتر","💳 چک و قسط","💼 کار","🎂 تولد","💊 دارو","📄 مدارک","🔔 سایر"};}
    public static List<String> customCategories(Context c){List<String>out=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString("custom_categories","[]"));for(int i=0;i<a.length();i++)out.add(a.optString(i));}catch(Exception ignored){}return out;}
    public static void addCustomCategory(Context c,String name){List<String>l=customCategories(c);if(!l.contains(name)){l.add(name);JSONArray a=new JSONArray();for(String s:l)a.put(s);p(c).edit().putString("custom_categories",a.toString()).apply();}}
    public static List<String> garageCategories(Context c){List<String>out=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString("garage_categories","[]"));for(int i=0;i<a.length();i++)out.add(a.optString(i));}catch(Exception ignored){}return out;}
    public static void addGarageCategory(Context c,String name){List<String>l=garageCategories(c);if(!l.contains(name)){l.add(name);JSONArray a=new JSONArray();for(String x:l)a.put(x);p(c).edit().putString("garage_categories",a.toString()).apply();}}


    public static List<ShoppingItem> shoppingItems(Context c){List<ShoppingItem>l=read(c,"shopping",ShoppingItem::from);l.sort((a,b)->{int g=a.listName.compareToIgnoreCase(b.listName);if(g!=0)return g;if(a.done!=b.done)return a.done?1:-1;return Long.compare(a.createdAt,b.createdAt);});return l;}
    public static void saveShoppingItems(Context c,List<ShoppingItem>l){save(c,"shopping",l,ShoppingItem::json);} public static void addShoppingItem(Context c,ShoppingItem x){List<ShoppingItem>l=shoppingItems(c);l.add(x);saveShoppingItems(c,l);} public static void updateShoppingItem(Context c,ShoppingItem x){List<ShoppingItem>l=shoppingItems(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveShoppingItems(c,l);} public static void removeShoppingItem(Context c,String id){List<ShoppingItem>l=shoppingItems(c);l.removeIf(x->x.id.equals(id));saveShoppingItems(c,l);}

    public static List<TodoItem> todos(Context c){List<TodoItem>l=read(c,"todos",TodoItem::from);l.sort((a,b)->{if(a.done!=b.done)return a.done?1:-1;long ad=a.dueMillis==0?Long.MAX_VALUE:a.dueMillis,bd=b.dueMillis==0?Long.MAX_VALUE:b.dueMillis;return Long.compare(ad,bd);});return l;}
    public static void saveTodos(Context c,List<TodoItem>l){save(c,"todos",l,TodoItem::json);} public static void addTodo(Context c,TodoItem x){List<TodoItem>l=todos(c);l.add(x);saveTodos(c,l);} public static void updateTodo(Context c,TodoItem x){List<TodoItem>l=todos(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveTodos(c,l);} public static void removeTodo(Context c,String id){List<TodoItem>l=todos(c);l.removeIf(x->x.id.equals(id));saveTodos(c,l);}

    public static List<CaseItem> cases(Context c){List<CaseItem>l=read(c,"cases",CaseItem::from);l.sort(Comparator.comparingLong(a->a.whenMillis));return l;} public static void addCase(Context c,CaseItem x){List<CaseItem>l=cases(c);l.add(x);save(c,"cases",l,CaseItem::json);} public static void updateCase(Context c,CaseItem x){List<CaseItem>l=cases(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"cases",l,CaseItem::json);} public static void removeCase(Context c,String id){List<CaseItem>l=cases(c);l.removeIf(x->x.id.equals(id));save(c,"cases",l,CaseItem::json);}

    public static List<VaultEntry> vault(Context c){return read(c,"vault",VaultEntry::from);} public static void addVault(Context c,VaultEntry x){List<VaultEntry>l=vault(c);l.add(x);save(c,"vault",l,VaultEntry::json);} public static void updateVault(Context c,VaultEntry x){List<VaultEntry>l=vault(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"vault",l,VaultEntry::json);} public static void removeVault(Context c,String id){List<VaultEntry>l=vault(c);l.removeIf(x->x.id.equals(id));save(c,"vault",l,VaultEntry::json);}

    public static List<AssetEntry> assets(Context c){return read(c,"assets",AssetEntry::from);} public static void saveAssets(Context c,List<AssetEntry>l){save(c,"assets",l,AssetEntry::json);} public static void addAsset(Context c,AssetEntry x){List<AssetEntry>l=assets(c);l.add(x);saveAssets(c,l);} public static void updateAsset(Context c,AssetEntry x){List<AssetEntry>l=assets(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveAssets(c,l);} public static void removeAsset(Context c,String id){List<AssetEntry>l=assets(c);l.removeIf(x->x.id.equals(id));saveAssets(c,l);}

    public static List<DocumentItem> documents(Context c){List<DocumentItem>l=read(c,"documents",DocumentItem::from);l.sort(Comparator.comparingLong(a->a.expiryDate));return l;} public static void addDocument(Context c,DocumentItem x){List<DocumentItem>l=documents(c);l.add(x);save(c,"documents",l,DocumentItem::json);} public static void updateDocument(Context c,DocumentItem x){List<DocumentItem>l=documents(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"documents",l,DocumentItem::json);} public static void removeDocument(Context c,String id){List<DocumentItem>l=documents(c);l.removeIf(x->x.id.equals(id));save(c,"documents",l,DocumentItem::json);}

    public static List<BillItem> bills(Context c){List<BillItem>l=read(c,"bills",BillItem::from);l.sort((a,b)->{if(a.paid!=b.paid)return a.paid?1:-1;return Long.compare(a.dueDate,b.dueDate);});return l;} public static void saveBills(Context c,List<BillItem>l){save(c,"bills",l,BillItem::json);} public static void addBill(Context c,BillItem x){List<BillItem>l=bills(c);l.add(x);saveBills(c,l);} public static void updateBill(Context c,BillItem x){List<BillItem>l=bills(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveBills(c,l);} public static void removeBill(Context c,String id){List<BillItem>l=bills(c);l.removeIf(x->x.id.equals(id));saveBills(c,l);}

    public static List<HomeItem> homeItems(Context c){List<HomeItem>l=read(c,"home_items",HomeItem::from);l.sort(Comparator.comparingLong(a->a.nextDueDate));return l;} public static void addHomeItem(Context c,HomeItem x){List<HomeItem>l=homeItems(c);l.add(x);save(c,"home_items",l,HomeItem::json);} public static void updateHomeItem(Context c,HomeItem x){List<HomeItem>l=homeItems(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"home_items",l,HomeItem::json);} public static void removeHomeItem(Context c,String id){List<HomeItem>l=homeItems(c);l.removeIf(x->x.id.equals(id));save(c,"home_items",l,HomeItem::json);}

    public static void removeReminderBySource(Context c,String sourceKey){if(sourceKey==null||sourceKey.isEmpty())return;List<Reminder>l=reminders(c);l.removeIf(x->sourceKey.equals(x.sourceKey));saveReminders(c,l);}
    public static int marketRefreshMode(Context c){return p(c).getInt("market_refresh_mode",1);}
    public static void setMarketRefreshMode(Context c,int mode){p(c).edit().putInt("market_refresh_mode",Math.max(0,Math.min(2,mode))).apply();}
    public static void setUsdToman(Context c,double v){p(c).edit().putString("usd_toman",String.valueOf(v)).apply();} public static double usdToman(Context c){try{return Double.parseDouble(p(c).getString("usd_toman","0"));}catch(Exception e){return 0;}}
    public static void setMarketSnapshot(Context c,double gold,double silver,double copper,double eurPerUsd,long updated){p(c).edit().putString("market_gold",String.valueOf(gold)).putString("market_silver",String.valueOf(silver)).putString("market_copper",String.valueOf(copper)).putString("market_eur",String.valueOf(eurPerUsd)).putLong("market_updated",updated).apply();}
    private static double prefDouble(Context c,String key){try{return Double.parseDouble(p(c).getString(key,"0"));}catch(Exception e){return 0;}} public static double marketGold(Context c){return prefDouble(c,"market_gold");} public static double marketSilver(Context c){return prefDouble(c,"market_silver");} public static double marketCopper(Context c){return prefDouble(c,"market_copper");} public static double marketEurPerUsd(Context c){return prefDouble(c,"market_eur");} public static long marketUpdated(Context c){return p(c).getLong("market_updated",0);}

    public static void setEmergencyEnabled(Context c,boolean v){p(c).edit().putBoolean("emergency_card_enabled",v).apply();} public static boolean emergencyEnabled(Context c){return p(c).getBoolean("emergency_card_enabled",false);}
    public static void setEmergencyName(Context c,String v){p(c).edit().putString("emergency_name",v).apply();} public static String emergencyName(Context c){return p(c).getString("emergency_name","");}
    public static void setEmergencyPhone1(Context c,String v){p(c).edit().putString("emergency_phone1",v).apply();} public static String emergencyPhone1(Context c){return p(c).getString("emergency_phone1","");}
    public static void setEmergencyPhone2(Context c,String v){p(c).edit().putString("emergency_phone2",v).apply();} public static String emergencyPhone2(Context c){return p(c).getString("emergency_phone2","");}
    public static void setEmergencyNote(Context c,String v){p(c).edit().putString("emergency_note",v).apply();} public static String emergencyNote(Context c){return p(c).getString("emergency_note","");}

    public static void setSmsEnabled(Context c,boolean v){p(c).edit().putBoolean("sms_enabled",v).apply();} public static boolean smsEnabled(Context c){return p(c).getBoolean("sms_enabled",false);} public static void setSmsNumber(Context c,String v){p(c).edit().putString("sms_number",v).apply();} public static String smsNumber(Context c){return p(c).getString("sms_number","");} public static void setSmsCode(Context c,String v){
        String encrypted=VaultCrypto.encrypt(v);
        if(!v.isEmpty()&&encrypted.isEmpty())return;
        p(c).edit().putString("sms_code",v.isEmpty()?"":"enc:"+encrypted).apply();
    }
    public static String smsCode(Context c){
        String raw=p(c).getString("sms_code","");
        if(raw.startsWith("enc:"))return VaultCrypto.decrypt(raw.substring(4));
        if(!raw.isEmpty()){String encoded=VaultCrypto.encrypt(raw);
            if(!encoded.isEmpty())p(c).edit().putString("sms_code","enc:"+encoded).apply();}
        return raw;
    }
    public static void setSmsFromAnyone(Context c,boolean v){p(c).edit().putBoolean("sms_any_sender",v).apply();}
    public static boolean smsFromAnyone(Context c){return p(c).getBoolean("sms_any_sender",false);}
    public static boolean smsRateLimited(Context c){long now=System.currentTimeMillis();
        long then=p(c).getLong("last_sms_activation",0L);
        if(now-then<60000L)return true;
        p(c).edit().putLong("last_sms_activation",now).apply();return false;
    }
    public static void setUnlockNote(Context c,String v){p(c).edit().putString("unlock_note",v).apply();} public static String unlockNote(Context c){return p(c).getString("unlock_note","");}
    public static void setPin(Context c,String v){String hashed=SecurityUtil.hashPin(v);if(!hashed.isEmpty())p(c).edit().putString("pin_secure",hashed).remove("pin").apply();} public static String pin(Context c){return "";} public static boolean verifyPin(Context c,String value){String secure=p(c).getString("pin_secure","");if(!secure.isEmpty())return SecurityUtil.verifyPin(value,secure);String legacy=p(c).getString("pin","");if(!legacy.isEmpty()&&legacy.equals(value)){setPin(c,value);return true;}return false;} public static void setLockEnabled(Context c,boolean v){p(c).edit().putBoolean("lock_enabled",v).apply();} public static boolean lockEnabled(Context c){return p(c).getBoolean("lock_enabled",false);} public static void setBiometricEnabled(Context c,boolean v){p(c).edit().putBoolean("bio_enabled",v).apply();} public static boolean biometricEnabled(Context c){return p(c).getBoolean("bio_enabled",false);}

    public static boolean accountConfigured(Context c){return p(c).getBoolean("account_configured",false);}
    public static String accountName(Context c){return p(c).getString("account_name","");}
    public static String accountEmail(Context c){return p(c).getString("account_email","");}
    public static String accountPhone(Context c){return p(c).getString("account_phone","");}
    public static void saveAccount(Context c,String name,String email,String phone){p(c).edit()
            .putString("account_name",name).putString("account_email",email)
            .putString("account_phone",phone).putBoolean("account_configured",true).apply();}
    public static boolean pinConfigured(Context c){return p(c).contains("pin_secure")||p(c).contains("pin");}

    public static boolean tokenDismissed(Context c,String token){return p(c).getStringSet("dismissed_tokens",new HashSet<>()).contains(token);} public static void dismissToken(Context c,String token){Set<String>s=new HashSet<>(p(c).getStringSet("dismissed_tokens",new HashSet<>()));s.add(token);p(c).edit().putStringSet("dismissed_tokens",s).apply();}

    public static String exportJson(Context c){
        JSONObject root=new JSONObject();
        try{
            java.util.Map<String,?> all=p(c).getAll();
            java.util.Map<String,Object> safe=new java.util.HashMap<>();
            for(java.util.Map.Entry<String,?>e:all.entrySet()){
                if(!"vault".equals(e.getKey()))safe.put(e.getKey(),e.getValue());
            }
            root.put("schema",2);
            root.put("nexa",mapToJson(safe));
            root.put("silent",mapToJson(c.getSharedPreferences("silent_timer_prefs",Context.MODE_PRIVATE).getAll()));
            root.put("vault_note","Vault is intentionally excluded from portable backup because its encryption key stays in Android Keystore.");
        }catch(Exception ignored){}
        return root.toString();
    }
    private static JSONObject mapToJson(java.util.Map<String,?> map)throws Exception{JSONObject o=new JSONObject();for(java.util.Map.Entry<String,?>e:map.entrySet()){Object v=e.getValue();if(v instanceof Set){JSONArray a=new JSONArray();for(Object x:(Set<?>)v)a.put(String.valueOf(x));JSONObject wrap=new JSONObject();wrap.put("__set",a);o.put(e.getKey(),wrap);}else o.put(e.getKey(),v);}return o;}
    public static boolean importJson(Context c,String raw){
        try{
            String vaultLocal=p(c).getString("vault","[]");
            JSONObject root=new JSONObject(raw);
            restorePrefs(p(c),root.getJSONObject("nexa"));
            p(c).edit().putString("vault",vaultLocal).apply();
            restorePrefs(c.getSharedPreferences("silent_timer_prefs",Context.MODE_PRIVATE),root.getJSONObject("silent"));
            return true;
        }catch(Exception e){
            return false;
        }
    }
    private static void restorePrefs(SharedPreferences sp,JSONObject o)throws Exception{SharedPreferences.Editor ed=sp.edit().clear();java.util.Iterator<String>it=o.keys();while(it.hasNext()){String k=it.next();Object v=o.get(k);if(v instanceof Boolean)ed.putBoolean(k,(Boolean)v);else if(v instanceof Integer)ed.putInt(k,(Integer)v);else if(v instanceof Long)ed.putLong(k,(Long)v);else if(v instanceof Double)ed.putFloat(k,((Double)v).floatValue());else if(v instanceof JSONObject && ((JSONObject)v).has("__set")){Set<String>s=new HashSet<>();JSONArray a=((JSONObject)v).getJSONArray("__set");for(int i=0;i<a.length();i++)s.add(a.getString(i));ed.putStringSet(k,s);}else ed.putString(k,String.valueOf(v));}ed.apply();}
}
