package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;
import java.util.List;

public class MedicineActivity extends Activity {
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);Button back=UiKit.secondaryButton(this,"‹");back.setOnClickListener(v->finish());root.addView(back,UiKit.matchWrap(this,0,12));root.addView(UiKit.title(this,"یادآور دارو"),UiKit.matchWrap(this,0,14));LinearLayout hero=UiKit.colorfulCardLayout(this,2);hero.addView(UiKit.sectionTitle(this,"💊 برنامه مصرف دارو"));hero.addView(UiKit.muted(this,"هر ۴، ۶، ۸ یا ۱۲ ساعت؛ با تأیید خوردم، بعداً یا رد شد."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ داروی جدید");add.setOnClickListener(v->addDialog());hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private EditText f(String h){EditText e=new EditText(this);e.setHint(h);return e;}
    private void addDialog(){medicineDialog(null);}
    private void medicineDialog(NexaStore.Medicine existing){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(32,8,32,0);
        EditText name=f("نام دارو");EditText dose=f("مقدار/توضیح؛ مثلاً یک عدد بعد غذا");
        EditText doctor=f("نام پزشک تجویزکننده (اختیاری)");
        Button prescription=UiKit.secondaryButton(this,"📅 تاریخ نسخه (اختیاری)");
        final long[] prescriptionDate={existing==null?0:existing.prescriptionDate};
        prescription.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,prescriptionDate[0]>0?prescriptionDate[0]:System.currentTimeMillis(),"تاریخ نسخه",millis->{prescriptionDate[0]=millis;prescription.setText("📅 "+PersianDateUtil.pretty(millis));}));
        Spinner interval=new Spinner(this);interval.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"هر ۴ ساعت","هر ۶ ساعت","هر ۸ ساعت","هر ۱۲ ساعت","هر ۲۴ ساعت"}));interval.setSelection(2);
        EditText days=f("تعداد روز دوره؛ 0 یعنی بدون پایان");days.setInputType(InputType.TYPE_CLASS_NUMBER);
        Button start=UiKit.secondaryButton(this,"انتخاب ساعت شروع");Calendar cal=Calendar.getInstance();
        if(existing!=null&&existing.nextDoseMillis>0)cal.setTimeInMillis(existing.nextDoseMillis);
        final int[] hm={cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE)};
        start.setText(String.format(java.util.Locale.US,"شروع %02d:%02d",hm[0],hm[1]));
        start.setOnClickListener(v->new TimePickerDialog(this,(p1,h,m)->{hm[0]=h;hm[1]=m;start.setText(String.format(java.util.Locale.US,"شروع %02d:%02d",h,m));},hm[0],hm[1],true).show());
        if(existing!=null){name.setText(existing.name);dose.setText(existing.dose);doctor.setText(existing.doctor);if(prescriptionDate[0]>0)prescription.setText("📅 "+PersianDateUtil.pretty(prescriptionDate[0]));int[]opts={4,6,8,12,24};for(int j=0;j<opts.length;j++)if(opts[j]==existing.intervalHours)interval.setSelection(j);}
        box.addView(name);box.addView(dose);box.addView(doctor);box.addView(prescription);box.addView(interval);box.addView(days);box.addView(start);
        new AlertDialog.Builder(this).setTitle(existing==null?"داروی جدید":"ویرایش دارو").setView(box).setPositiveButton("ذخیره",(d,w)->{
            String n=name.getText().toString().trim();if(n.isEmpty()){Toast.makeText(this,"نام دارو ضروری است",Toast.LENGTH_SHORT).show();return;}
            int[]hours={4,6,8,12,24};NexaStore.Medicine m=existing==null?new NexaStore.Medicine():existing;
            m.name=n;m.dose=dose.getText().toString().trim();m.doctor=doctor.getText().toString().trim();m.prescriptionDate=prescriptionDate[0];m.intervalHours=hours[interval.getSelectedItemPosition()];
            Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,hm[0]);c.set(Calendar.MINUTE,hm[1]);c.set(Calendar.SECOND,0);
            if(existing==null||existing.nextDoseMillis<=0){if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);m.nextDoseMillis=c.getTimeInMillis();}
            else{Calendar prev=Calendar.getInstance();prev.setTimeInMillis(existing.nextDoseMillis);prev.set(Calendar.HOUR_OF_DAY,hm[0]);prev.set(Calendar.MINUTE,hm[1]);prev.set(Calendar.SECOND,0);if(prev.getTimeInMillis()<System.currentTimeMillis())prev.add(Calendar.DAY_OF_YEAR,1);m.nextDoseMillis=prev.getTimeInMillis();}
            int dd=0;try{dd=Integer.parseInt(days.getText().toString());}catch(Exception ignored){}
            if(dd>0)m.endMillis=m.nextDoseMillis+dd*24L*60*60*1000;
            MedicineScheduler.cancel(this,m.id);
            if(existing==null)NexaStore.addMedicine(this,m);else NexaStore.updateMedicine(this,m);
            MedicineScheduler.schedule(this,m);NexaStore.addHistory(this,"دارو",(existing==null?"دارو اضافه شد: ":"دارو ویرایش شد: ")+m.name);render();
        }).setNegativeButton("انصراف",null).show();
    }
    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Medicine> ms=NexaStore.medicines(this);if(ms.isEmpty()){TextView e=UiKit.muted(this,"هنوز دارویی ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}for(NexaStore.Medicine m:ms){LinearLayout c=UiKit.colorfulCardLayout(this,2);c.addView(UiKit.sectionTitle(this,"💊 "+m.name));c.addView(UiKit.muted(this,(m.dose.isEmpty()?"":m.dose+" • ")+"هر "+m.intervalHours+" ساعت"),UiKit.matchWrap(this,5,3));c.addView(UiKit.muted(this,"نوبت بعد: "+PersianDateUtil.pretty(m.nextDoseMillis)));if(!m.doctor.isEmpty())c.addView(UiKit.muted(this,"پزشک: "+m.doctor));Button edit=UiKit.secondaryButton(this,"✎ ویرایش");edit.setOnClickListener(v->medicineDialog(m));c.addView(edit);Button del=UiKit.secondaryButton(this,"حذف");del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف دارو؟").setPositiveButton("حذف",(d,w)->{MedicineScheduler.cancel(this,m.id);NexaStore.removeMedicine(this,m.id);render();}).setNegativeButton("انصراف",null).show());c.addView(del,UiKit.matchWrap(this,10,0));list.addView(c,UiKit.matchWrap(this,0,12));}}
}
