package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MedicineActivity extends Activity {
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}

    private EditText f(String h){return UiKit.styleField(this,new EditText(this),h);}
    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackground(UiKit.screenBackground(this));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());head.addView(back);TextView title=UiKit.title(this,"یادآور دارو");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1f);tp.setMargins(UiKit.dp(this,12),0,0,0);head.addView(title,tp);root.addView(head,UiKit.matchWrap(this,0,14));
        LinearLayout hero=UiKit.colorfulCardLayout(this,2);hero.addView(UiKit.sectionTitle(this,"💊 برنامه مصرف دارو"));hero.addView(UiKit.muted(this,"دارو، پزشک و زمان مصرف را ساده ثبت کن؛ هشدارها هم از همین‌جا مدیریت می‌شوند."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ داروی جدید");add.setOnClickListener(v->medicineDialog(null));hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();
    }

    private void medicineDialog(NexaStore.Medicine existing){
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,existing==null?"💊 داروی جدید":"✎ ویرایش دارو"),UiKit.matchWrap(this,0,8));
        EditText name=f("نام دارو");EditText dose=f("مقدار / توضیح؛ مثلاً ۱ عدد بعد غذا");

        List<NexaStore.Doctor> doctors=NexaStore.doctors(this);ArrayList<String> doctorNames=new ArrayList<>();for(NexaStore.Doctor d:doctors)doctorNames.add(d.name);
        AutoCompleteTextView doctor=new AutoCompleteTextView(this);UiKit.styleField(this,doctor,"نام پزشک؛ انتخاب از لیست یا تایپ دستی");doctor.setThreshold(1);doctor.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,doctorNames));
        Button addDoctor=UiKit.secondaryButton(this,"＋");addDoctor.setContentDescription("افزودن پزشک کامل");
        LinearLayout doctorRow=new LinearLayout(this);doctorRow.setOrientation(LinearLayout.HORIZONTAL);doctorRow.addView(doctor,new LinearLayout.LayoutParams(0,-2,1f));doctorRow.addView(addDoctor,new LinearLayout.LayoutParams(UiKit.dp(this,52),UiKit.dp(this,52)));
        addDoctor.setOnClickListener(v->doctorDialog(d->{doctor.setText(d.name);doctor.dismissDropDown();}));

        final long[] prescriptionDate={existing==null?0:existing.prescriptionDate};Button prescription=UiKit.secondaryButton(this,prescriptionDate[0]>0?"📅 "+PersianDateUtil.pretty(prescriptionDate[0]):"📅 تاریخ نسخه (اختیاری)");prescription.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,prescriptionDate[0]>0?prescriptionDate[0]:System.currentTimeMillis(),"تاریخ نسخه",millis->{prescriptionDate[0]=millis;prescription.setText("📅 "+PersianDateUtil.pretty(millis));}));

        Spinner interval=new Spinner(this);ArrayAdapter<String> ia=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,new String[]{"هر ۴ ساعت","هر ۶ ساعت","هر ۸ ساعت","هر ۱۲ ساعت","هر ۲۴ ساعت"}){@Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);return t;}@Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);return t;}};interval.setAdapter(ia);interval.setSelection(2);
        EditText days=f("تعداد روز دوره؛ ۰ یعنی بدون پایان");days.setInputType(InputType.TYPE_CLASS_NUMBER);
        Calendar cal=Calendar.getInstance();if(existing!=null&&existing.nextDoseMillis>0)cal.setTimeInMillis(existing.nextDoseMillis);final int[]hm={cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE)};Button start=UiKit.secondaryButton(this,String.format(java.util.Locale.US,"🕒 شروع %02d:%02d",hm[0],hm[1]));start.setOnClickListener(v->new TimePickerDialog(this,(p,h,m)->{hm[0]=h;hm[1]=m;start.setText(String.format(java.util.Locale.US,"🕒 شروع %02d:%02d",h,m));},hm[0],hm[1],true).show());

        if(existing!=null){name.setText(existing.name);dose.setText(existing.dose);doctor.setText(existing.doctor);int[]opts={4,6,8,12,24};for(int j=0;j<opts.length;j++)if(opts[j]==existing.intervalHours)interval.setSelection(j);if(existing.endMillis>existing.nextDoseMillis&&existing.nextDoseMillis>0)days.setText(String.valueOf(Math.max(1,(existing.endMillis-existing.nextDoseMillis)/(24L*60*60*1000))));}
        box.addView(UiKit.muted(this,"اطلاعات دارو"));box.addView(name,UiKit.matchWrap(this,5,6));box.addView(dose,UiKit.matchWrap(this,0,8));box.addView(UiKit.muted(this,"پزشک تجویزکننده"));box.addView(doctorRow,UiKit.matchWrap(this,5,6));box.addView(UiKit.muted(this,"اگر پزشک مهم نیست، فقط نامش را تایپ کن. اگر ذخیره شده باشد، هنگام تایپ پیشنهاد می‌شود."),UiKit.matchWrap(this,0,8));box.addView(prescription,UiKit.matchWrap(this,0,10));box.addView(UiKit.muted(this,"برنامه مصرف"));box.addView(interval,UiKit.matchWrap(this,4,6));box.addView(days,UiKit.matchWrap(this,0,6));box.addView(start);

        new AlertDialog.Builder(this).setView(box).setPositiveButton("ذخیره دارو",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty()){Toast.makeText(this,"نام دارو ضروری است.",Toast.LENGTH_SHORT).show();return;}int[]hours={4,6,8,12,24};NexaStore.Medicine m=existing==null?new NexaStore.Medicine():existing;m.name=n;m.dose=dose.getText().toString().trim();m.doctor=doctor.getText().toString().trim();m.prescriptionDate=prescriptionDate[0];m.intervalHours=hours[interval.getSelectedItemPosition()];Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,hm[0]);c.set(Calendar.MINUTE,hm[1]);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);m.nextDoseMillis=c.getTimeInMillis();int dd=0;try{dd=Integer.parseInt(days.getText().toString().trim());}catch(Exception ignored){}m.endMillis=dd>0?m.nextDoseMillis+dd*24L*60*60*1000:0;MedicineScheduler.cancel(this,m.id);if(existing==null)NexaStore.addMedicine(this,m);else NexaStore.updateMedicine(this,m);MedicineScheduler.schedule(this,m);NexaStore.addHistory(this,"دارو",(existing==null?"دارو اضافه شد: ":"دارو ویرایش شد: ")+m.name);render();}).setNegativeButton("انصراف",null).show();
    }

    private interface DoctorCallback{void saved(NexaStore.Doctor d);}
    private void doctorDialog(DoctorCallback cb){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"افزودن پزشک"),UiKit.matchWrap(this,0,8));EditText n=f("نام پزشک");EditText sp=f("تخصص");EditText file=f("شماره پرونده");EditText center=f("نام مطب / مرکز");EditText phone=f("شماره تماس");phone.setInputType(InputType.TYPE_CLASS_PHONE);EditText address=f("آدرس");for(View v:new View[]{n,sp,file,center,phone,address})box.addView(v,UiKit.matchWrap(this,0,6));new AlertDialog.Builder(this).setView(box).setPositiveButton("ذخیره پزشک",(d,w)->{if(n.getText().toString().trim().isEmpty())return;NexaStore.Doctor doc=new NexaStore.Doctor();doc.name=n.getText().toString().trim();doc.specialty=sp.getText().toString().trim();doc.fileNumber=file.getText().toString().trim();doc.center=center.getText().toString().trim();doc.phone=phone.getText().toString().trim();doc.address=address.getText().toString().trim();NexaStore.upsertDoctor(this,doc);cb.saved(doc);}).setNegativeButton("انصراف",null).show();}

    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Medicine>ms=NexaStore.medicines(this);if(ms.isEmpty()){TextView e=UiKit.muted(this,"هنوز دارویی ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}for(NexaStore.Medicine m:ms){LinearLayout c=UiKit.colorfulCardLayout(this,2);c.addView(UiKit.sectionTitle(this,"💊 "+m.name));c.addView(UiKit.muted(this,(m.dose.isEmpty()?"":m.dose+" • ")+"هر "+m.intervalHours+" ساعت"),UiKit.matchWrap(this,5,3));c.addView(UiKit.muted(this,"نوبت بعد: "+PersianDateUtil.pretty(m.nextDoseMillis)));if(!m.doctor.isEmpty())c.addView(UiKit.muted(this,"پزشک: "+m.doctor));LinearLayout actions=new LinearLayout(this);Button edit=UiKit.secondaryButton(this,"✎ ویرایش");edit.setOnClickListener(v->medicineDialog(m));Button del=UiKit.secondaryButton(this,"حذف");del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف دارو؟").setPositiveButton("حذف",(d,w)->{MedicineScheduler.cancel(this,m.id);NexaStore.removeMedicine(this,m.id);render();}).setNegativeButton("انصراف",null).show());actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1f));actions.addView(del,new LinearLayout.LayoutParams(0,-2,1f));c.addView(actions,UiKit.matchWrap(this,10,0));list.addView(c,UiKit.matchWrap(this,0,12));}}
}
