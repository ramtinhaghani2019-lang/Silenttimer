package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class NexaListActivity extends Activity {
    private LinearLayout shoppingBox;
    private LinearLayout todoBox;
    private LinearLayout shoppingHead,todoHead;
    private int selectedTab=0;
    private String pendingReceiptId=null;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();

        String quick = getIntent().getStringExtra("quick_add");
        if ("shopping".equals(quick)) {
            shoppingBox.postDelayed(this::addShoppingDialog, 250);
        } else if ("todo".equals(quick)) {
            selectTab(1);todoBox.postDelayed(this::addTodoDialog, 250);
        }
    }

    private void build() {
        ScrollView sc = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back = UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v -> finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa List"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"خریدها و کارهای روزانه؛ موارد انجام‌شده حذف نمی‌شوند و کم‌رنگ می‌مانند."),UiKit.matchWrap(this,0,14));

        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
        Button shopTab=UiKit.secondaryButton(this,"🛒 خریدها");Button taskTab=UiKit.secondaryButton(this,"✓ کارها");
        shopTab.setOnClickListener(v->selectTab(0));taskTab.setOnClickListener(v->selectTab(1));
        tabs.addView(shopTab,new LinearLayout.LayoutParams(0,-2,1f));tabs.addView(taskTab,new LinearLayout.LayoutParams(0,-2,1f));
        root.addView(tabs,UiKit.matchWrap(this,0,14));
        shoppingHead = UiKit.colorfulCardLayout(this,3);
        shoppingHead.addView(UiKit.sectionTitle(this,"🛒 لیست خرید"));
        Button addShopping = UiKit.primaryButton(this,"＋ افزودن قلم خرید");
        addShopping.setOnClickListener(v -> addShoppingDialog());
        shoppingHead.addView(addShopping,UiKit.matchWrap(this,10,8));

        LinearLayout shopActions = new LinearLayout(this);
        shopActions.setOrientation(LinearLayout.HORIZONTAL);

        Button reset = UiKit.secondaryButton(this,"فعال‌کردن دوباره همه");
        reset.setOnClickListener(v -> {
            List<NexaStore.ShoppingItem> items = NexaStore.shoppingItems(this);
            for (NexaStore.ShoppingItem x : items) x.done = false;
            NexaStore.saveShoppingItems(this, items);
            render();
        });
        Button clearDone = UiKit.secondaryButton(this,"پاک‌کردن خریدشده‌ها");
        clearDone.setOnClickListener(v -> {
            List<NexaStore.ShoppingItem> items = NexaStore.shoppingItems(this);
            items.removeIf(x -> x.done);
            NexaStore.saveShoppingItems(this, items);
            render();
        });
        shopActions.addView(reset,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams ac = new LinearLayout.LayoutParams(0,-2,1f);
        ac.setMargins(UiKit.dp(this,6),0,0,0);
        shopActions.addView(clearDone,ac);
        shoppingHead.addView(shopActions);
        root.addView(shoppingHead,UiKit.matchWrap(this,0,12));

        shoppingBox = new LinearLayout(this);
        shoppingBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(shoppingBox,UiKit.matchWrap(this,0,18));

        todoHead = UiKit.colorfulCardLayout(this,1);
        todoHead.addView(UiKit.sectionTitle(this,"✓ To‑Do"));
        Button addTodo = UiKit.primaryButton(this,"＋ کار جدید");
        addTodo.setOnClickListener(v -> addTodoDialog());
        todoHead.addView(addTodo,UiKit.matchWrap(this,10,0));
        root.addView(todoHead,UiKit.matchWrap(this,0,12));

        todoBox = new LinearLayout(this);
        todoBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(todoBox);

        setContentView(sc);
        render();selectTab(selectedTab);
    }
    private void selectTab(int tab){selectedTab=tab;
        if(shoppingHead!=null)shoppingHead.setVisibility(tab==0?View.VISIBLE:View.GONE);
        if(shoppingBox!=null)shoppingBox.setVisibility(tab==0?View.VISIBLE:View.GONE);
        if(todoHead!=null)todoHead.setVisibility(tab==1?View.VISIBLE:View.GONE);
        if(todoBox!=null)todoBox.setVisibility(tab==1?View.VISIBLE:View.GONE);
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addShoppingDialog() { editShoppingDialog(null); }
    private void editShoppingDialog(NexaStore.ShoppingItem existing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        EditText listName = field("نام لیست؛ مثلاً سوپرمارکت");
        listName.setText("خرید");
        EditText name = field("نام کالا؛ برای چند کالا، هر کدام یک خط");
        name.setSingleLine(false);name.setMinLines(2);
        EditText qty = field("مقدار؛ مثلاً ۲ عدد / ۱ کیلو");
        EditText cat = field("دسته؛ مثلاً خوراکی");
        EditText price = field("قیمت تقریبی (اختیاری)");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        CheckBox important = new CheckBox(this);
        important.setText("مهم ⭐");

        box.addView(listName);
        box.addView(name);
        box.addView(qty);
        box.addView(cat);
        box.addView(price);
        box.addView(important);
        if(existing!=null){listName.setText(existing.listName);name.setText(existing.name);
            qty.setText(existing.quantity);cat.setText(existing.category);
            price.setText(String.valueOf(existing.price));important.setChecked(existing.important);}

        new AlertDialog.Builder(this)
                .setTitle(existing==null?"افزودن چند قلم خرید":"ویرایش قلم خرید")
                .setView(box)
                .setPositiveButton("افزودن",(d,w)->{
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) return;
                    String[] names=existing==null?n.split("\n"):new String[]{n};
                    for(String value:names){if(value.trim().isEmpty())continue;
                        NexaStore.ShoppingItem x=existing==null?new NexaStore.ShoppingItem():existing;
                        x.listName=listName.getText().toString().trim().isEmpty()?"خرید":listName.getText().toString().trim();
                        x.name=value.trim();x.quantity=qty.getText().toString().trim();x.category=cat.getText().toString().trim();
                        x.important=important.isChecked();
                        try{x.price=Long.parseLong(price.getText().toString().replace(",","").trim());}catch(Exception ignored){}
                        if(existing==null)NexaStore.addShoppingItem(this,x);else NexaStore.updateShoppingItem(this,x);
                        NexaStore.addHistory(this,"لیست",(existing==null?"افزوده شد: ":"ویرایش شد: ")+x.name);
                    }
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void addTodoDialog() { editTodoDialog(null); }
    private void editTodoDialog(NexaStore.TodoItem existing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        EditText title = field("عنوان کار");
        EditText category = field("دسته؛ مثلاً خانه / کار");
        EditText note = field("توضیحات");
        Button due = UiKit.secondaryButton(this,"بدون تاریخ");
        final long[] dueMillis = {0L};

        due.setOnClickListener(v -> PersianDatePickerHelper.pickDateTime(
                this,
                System.currentTimeMillis()+60L*60L*1000L,
                "موعد انجام",
                ms -> {
                    dueMillis[0] = ms;
                    due.setText(PersianDateUtil.pretty(ms));
                }
        ));

        box.addView(title);
        box.addView(category);
        box.addView(note);
        box.addView(due);
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"60,0":"60,0",5);
        if(existing!=null){title.setText(existing.title);category.setText(existing.category);note.setText(existing.note);
            dueMillis[0]=existing.dueMillis;if(existing.dueMillis>0)due.setText(PersianDateUtil.pretty(dueMillis[0]));}

        new AlertDialog.Builder(this)
                .setTitle(existing==null?"کار جدید":"ویرایش کار")
                .setView(box)
                .setPositiveButton("افزودن",(d,w)->{
                    String t = title.getText().toString().trim();
                    if (t.isEmpty()) return;
                    NexaStore.TodoItem x = existing==null?new NexaStore.TodoItem():existing;
                    x.title = t;
                    x.category = category.getText().toString().trim().isEmpty() ? "عمومی" : category.getText().toString().trim();
                    x.note = note.getText().toString().trim();
                    x.dueMillis = dueMillis[0];
                    if(existing==null)NexaStore.addTodo(this,x);else NexaStore.updateTodo(this,x);
                    NexaStore.addHistory(this,"کار","افزوده شد: "+x.title);
                    if (x.dueMillis > System.currentTimeMillis()) {
                        LinkedReminderHelper.upsert(
                                this,
                                "todo:"+x.id,
                                x.title,
                                "کار",
                                "✓",
                                x.note,
                                x.dueMillis,
                                alerts.rules(),
                                alerts.repeatMinutes()
                        );
                    }
                    else LinkedReminderHelper.remove(this,"todo:"+x.id);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void showBoughtDialog(NexaStore.ShoppingItem item){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);
        EditText price=field("قیمت پرداختی تومان (اختیاری)");price.setInputType(InputType.TYPE_CLASS_NUMBER);
        if(item.price>0)price.setText(String.valueOf(item.price));
        EditText quantity=field("مقدار/وزن نهایی؛ مثلاً ۳۰۰ گرم");quantity.setText(item.quantity);
        EditText store=field("نام فروشگاه (اختیاری)");store.setText(item.store);
        CheckBox receipt=new CheckBox(this);receipt.setText("📷 افزودن تصویر رسید از گالری");receipt.setTextColor(UiKit.TEXT);
        box.addView(price);box.addView(quantity);box.addView(store);box.addView(receipt);
        new AlertDialog.Builder(this).setTitle("ثبت خرید "+item.name).setView(box)
            .setPositiveButton("خریدم ✓",(d,w)->{
                try{item.price=Long.parseLong(price.getText().toString().replace(",","").trim());}catch(Exception ignored){}
                item.quantity=quantity.getText().toString().trim();item.store=store.getText().toString().trim();
                item.purchasedAt=System.currentTimeMillis();item.done=true;NexaStore.updateShoppingItem(this,item);
                if(receipt.isChecked()){pendingReceiptId=item.id;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                    startActivityForResult(i,887);}
                render();
            }).setNegativeButton("انصراف",null).show();
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(request==887&&result==RESULT_OK&&data!=null&&data.getData()!=null&&pendingReceiptId!=null){
            Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
            for(NexaStore.ShoppingItem x:NexaStore.shoppingItems(this))if(x.id.equals(pendingReceiptId)){
                x.receiptUri=uri.toString();NexaStore.updateShoppingItem(this,x);break;}
            pendingReceiptId=null;render();
        }
    }
    private void render() {
        if (shoppingBox == null) return;
        shoppingBox.removeAllViews();
        todoBox.removeAllViews();

        List<NexaStore.ShoppingItem> items = NexaStore.shoppingItems(this);
        if (items.isEmpty()) {
            TextView e = UiKit.muted(this,"لیست خرید خالی است.");
            e.setGravity(Gravity.CENTER);
            shoppingBox.addView(e,UiKit.matchWrap(this,8,0));
        } else {
            java.util.Map<String,java.util.List<NexaStore.ShoppingItem>> groups=new java.util.LinkedHashMap<>();
            for(NexaStore.ShoppingItem x:items){if(!groups.containsKey(x.listName))groups.put(x.listName,new java.util.ArrayList<>());
                groups.get(x.listName).add(x);}
            for(java.util.Map.Entry<String,java.util.List<NexaStore.ShoppingItem>> group:groups.entrySet()){
                LinearLayout groupCard=UiKit.colorfulCardLayout(this,3),body=new LinearLayout(this);
                body.setOrientation(LinearLayout.VERTICAL);body.setVisibility(View.GONE);
                long spent=0;for(NexaStore.ShoppingItem x:group.getValue())if(x.done)spent+=x.price;
                Button toggleGroup=UiKit.secondaryButton(this,"▸ "+group.getKey()+" ("+group.getValue().size()+")");
                toggleGroup.setOnClickListener(v->{boolean open=body.getVisibility()!=View.VISIBLE;
                    body.setVisibility(open?View.VISIBLE:View.GONE);
                    toggleGroup.setText((open?"▾ ":"▸ ")+group.getKey()+" ("+group.getValue().size()+")");});
                groupCard.addView(toggleGroup);
                groupCard.addView(UiKit.muted(this,String.format(java.util.Locale.US,"جمع هزینه خریدشده: %,d تومان",spent)),UiKit.matchWrap(this,6,6));
                for(NexaStore.ShoppingItem x:group.getValue()){
                    LinearLayout c=UiKit.cardLayout(this);c.setAlpha(x.done?0.60f:1f);
                    TextView title=UiKit.sectionTitle(this,(x.important?"⭐ ":"")+x.name);
                    if(x.done)title.setPaintFlags(title.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG);
                    c.addView(title);
                    String sub=x.quantity+(x.category.isEmpty()?"":" • "+x.category)+
                        (x.price>0?String.format(java.util.Locale.US," • %,d تومان",x.price):"");
                    c.addView(UiKit.muted(this,sub),UiKit.matchWrap(this,5,0));
                    if(!x.store.isEmpty())c.addView(UiKit.muted(this,"فروشگاه: "+x.store));
                    LinearLayout buttons=new LinearLayout(this);
                    Button bought=UiKit.secondaryButton(this,x.done?"برگرداندن":"خریدم ✓");
                    bought.setOnClickListener(v->{if(x.done){x.done=false;NexaStore.updateShoppingItem(this,x);render();}
                        else showBoughtDialog(x);});
                    Button edit=UiKit.secondaryButton(this,"ویرایش");edit.setOnClickListener(v->editShoppingDialog(x));
                    Button del=UiKit.secondaryButton(this,"حذف");del.setOnClickListener(v->new AlertDialog.Builder(this)
                        .setTitle("حذف کالا؟").setMessage(x.name).setPositiveButton("حذف",(d,w)->{NexaStore.removeShoppingItem(this,x.id);render();})
                        .setNegativeButton("انصراف",null).show());
                    for(Button btn:new Button[]{bought,edit,del})buttons.addView(btn,new LinearLayout.LayoutParams(0,-2,1f));
                    c.addView(buttons,UiKit.matchWrap(this,8,0));body.addView(c,UiKit.matchWrap(this,8,0));
                }
                groupCard.addView(body);shoppingBox.addView(groupCard,UiKit.matchWrap(this,0,10));
            }
        }

        List<NexaStore.TodoItem> todos = NexaStore.todos(this);
        if (todos.isEmpty()) {
            TextView e = UiKit.muted(this,"کاری ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            todoBox.addView(e,UiKit.matchWrap(this,8,0));
        } else {
            for (NexaStore.TodoItem x : todos) {
                LinearLayout c = UiKit.colorfulCardLayout(this,1);
                c.setAlpha(x.done ? 0.48f : 1f);

                TextView t = UiKit.sectionTitle(this,x.title);
                if (x.done) t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                c.addView(t);

                String sub = x.category;
                if (x.dueMillis > 0) sub += " • "+PersianDateUtil.pretty(x.dueMillis);
                c.addView(UiKit.muted(this,sub),UiKit.matchWrap(this,5,2));
                if (!x.note.isEmpty()) c.addView(UiKit.muted(this,x.note));

                LinearLayout actions = new LinearLayout(this);
                Button toggle = UiKit.secondaryButton(this,x.done?"برگرداندن":"انجام شد ✓");
                toggle.setOnClickListener(v -> {
                    x.done = !x.done;
                    NexaStore.updateTodo(this,x);
                    if (x.done) LinkedReminderHelper.remove(this,"todo:"+x.id);
                    render();
                });
                Button edit = UiKit.secondaryButton(this,"ویرایش");edit.setOnClickListener(v->editTodoDialog(x));
                Button del = UiKit.secondaryButton(this,"حذف");
                del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("حذف کار؟").setMessage(x.title)
                    .setPositiveButton("حذف",(d,w)->{
                    LinkedReminderHelper.remove(this,"todo:"+x.id);
                    NexaStore.removeTodo(this,x.id);
                    render();
                }).setNegativeButton("انصراف",null).show());
                actions.addView(toggle,new LinearLayout.LayoutParams(0,-2,1f));
                actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1f));
                LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0,-2,1f);
                dp.setMargins(UiKit.dp(this,6),0,0,0);
                actions.addView(del,dp);
                c.addView(actions,UiKit.matchWrap(this,10,0));

                todoBox.addView(c,UiKit.matchWrap(this,0,8));
            }
        }
    }
}
