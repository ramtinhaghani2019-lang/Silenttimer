package com.example.silenttimer;

import android.content.Context;

public final class LinkedReminderHelper {
    private LinkedReminderHelper() {}

    public static void upsert(
            Context c,
            String sourceKey,
            String title,
            String category,
            String icon,
            String note,
            long whenMillis,
            String offsetsMinutes,
            int repeatMinutes
    ) {
        for(NexaStore.Reminder old:NexaStore.reminders(c))if(sourceKey.equals(old.sourceKey))ReminderScheduler.cancelReminder(c,old);
        NexaStore.removeReminderBySource(c, sourceKey);

        if (whenMillis <= System.currentTimeMillis()) {
            ReminderScheduler.rescheduleAll(c);
            return;
        }

        NexaStore.Reminder r = new NexaStore.Reminder();
        r.title = title;
        r.category = category;
        r.icon = icon;
        r.note = note == null ? "" : note;
        r.sourceKey = sourceKey;
        r.whenMillis = whenMillis;
        r.offsetsMinutes = offsetsMinutes;
        r.repeatMinutes = repeatMinutes;
        NexaStore.addReminder(c, r);
        ReminderScheduler.scheduleReminder(c, r);
    }

    public static void remove(Context c, String sourceKey) {
        for(NexaStore.Reminder old:NexaStore.reminders(c))if(sourceKey.equals(old.sourceKey))ReminderScheduler.cancelReminder(c,old);
        NexaStore.removeReminderBySource(c, sourceKey);
        ReminderScheduler.rescheduleAll(c);
    }
}
