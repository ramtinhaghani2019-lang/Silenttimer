package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;

public class SettingsActivity extends Activity {
    public static final String EXTRA_START_SETUP="start_setup";
    private static final int REQ_RUNTIME=7101,REQ_CALL_SCREENING=7102,REQ_EXPORT=7103,REQ_IMPORT=7104,REQ_UNLOCK=7190,REQ_SMS_CONTACT=7191;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean setupInProgress=false,autoFirstRunSetup=false;private int waitingSpecialStep=0;
    private TextView overlayStatus,dndStatus,phoneStatus,screeningStatus,exactAlarmStatus,fullScreenStatus,batteryStatus;private Button setupButton;private EditText smsNumber,smsCode;private Switch smsSwitch,smsAnyone;
    private boolean verifiedSettings=false;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        boolean firstSetup=getIntent().getBooleanExtra(EXTRA_START_SETUP,false)&&!AppPrefs.isSetupCompleted(this);
        if(firstSetup||!NexaStore.pinConfigured(this)){verifiedSettings=true;openSettings();}
        else{SecurityGate.lock();startActivityForResult(new Intent(this,UnlockActivity.class),REQ_UNLOCK);}
    }
    private void openSettings(){buildUi();if(getIntent().getBooleanExtra(EXTRA_START_SETUP,false)){
        autoFirstRunSetup=!AppPrefs.isSetupCompleted(this);setupInProgress=true;handler.postDelayed(this::continueSetup,350);
    }}
    @Override protected void onResume(){super.onResume();refreshStatuses();if(setupInProgress&&waitingSpecialStep!=0){int step=waitingSpecialStep;waitingSpecialStep=0;if(!stepGranted(step)){setupInProgress=false;Toast.makeText(this,"این دسترسی تأیید نشد. از همین صفحه دوباره راه‌اندازی کامل را بزن.",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this::continueSetup,300);}}
    private void buildUi(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.secondaryButton(this,"‹");back.setOnClickListener(v->finish());head.addView(back);LinearLayout tb=new LinearLayout(this);tb.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(0,-2,1f);tl.setMargins(UiKit.dp(this,12),0,0,0);head.addView(tb,tl);tb.addView(UiKit.title(this,"تنظیمات"));tb.addView(UiKit.muted(this,"Nexa • Obsidian Spectrum"));root.addView(head,UiKit.matchWrap(this,0,18));LinearLayout account=UiKit.colorfulCardLayout(this,1);
        account.addView(UiKit.sectionTitle(this,"👤 حساب کاربری و ایمیل"));
        account.addView(UiKit.muted(this,"نام: "+NexaStore.accountName(this)+" • ایمیل ثبت‌شده: "+NexaStore.accountEmail(this)+
            "\nایمیل فعلاً محلی و تأییدنشده است؛ بازیابی آنلاین فعال نیست."),UiKit.matchWrap(this,7,8));
        Button editAccount=UiKit.secondaryButton(this,"✎ ویرایش مشخصات");
        editAccount.setOnClickListener(v->startActivity(new Intent(this,AccountSetupActivity.class)));
        account.addView(editAccount);root.addView(account,UiKit.matchWrap(this,0,14));LinearLayout access=UiKit.colorfulCardLayout(this,0);access.addView(UiKit.sectionTitle(this,"راه‌اندازی کامل دسترسی‌ها"));access.addView(UiKit.muted(this,"در نصب اول خودکار اجرا می‌شود؛ هر صفحه را تأیید کنی، صفحه بعدی خودش باز می‌شود."),UiKit.matchWrap(this,6,14));setupButton=UiKit.primaryButton(this,"شروع راه‌اندازی کامل");setupButton.setOnClickListener(v->{setupInProgress=true;waitingSpecialStep=0;continueSetup();});access.addView(setupButton);root.addView(access,UiKit.matchWrap(this,0,14));LinearLayout checklist=UiKit.colorfulCardLayout(this,1);checklist.addView(UiKit.sectionTitle(this,"وضعیت دسترسی‌ها"));overlayStatus=status("نمایش روی برنامه‌ها");dndStatus=status("کنترل Silent / Vibrate");phoneStatus=status("تماس، مخاطبین، پیامک و اعلان‌ها");screeningStatus=status("Call Screening تماس‌های مجاز");exactAlarmStatus=status("آلارم دقیق");fullScreenStatus=status("نمایش تمام‌صفحه هشدار روی Lock Screen");batteryStatus=status("فعالیت پس‌زمینه بدون محدودیت");checklist.addView(overlayStatus,UiKit.matchWrap(this,12,5));checklist.addView(dndStatus,UiKit.matchWrap(this,0,5));checklist.addView(phoneStatus,UiKit.matchWrap(this,0,5));checklist.addView(screeningStatus,UiKit.matchWrap(this,0,5));checklist.addView(exactAlarmStatus,UiKit.matchWrap(this,0,5));checklist.addView(fullScreenStatus,UiKit.matchWrap(this,0,5));checklist.addView(batteryStatus);root.addView(checklist,UiKit.matchWrap(this,0,14));
        LinearLayout sms=UiKit.colorfulCardLayout(this,2);sms.addView(UiKit.sectionTitle(this,"📩 کد اضطراری پیامکی"));sms.addView(UiKit.muted(this,"فقط اگر پیامک از شماره تعریف‌شده باشد و کد داخل متن باشد، گوشی از Silent/Vibrate خارج می‌شود."),UiKit.matchWrap(this,6,10));smsSwitch=new Switch(this);smsSwitch.setText("فعال");smsSwitch.setTextColor(UiKit.TEXT);smsSwitch.setChecked(NexaStore.smsEnabled(this));sms.addView(smsSwitch);smsNumber=field("شماره مجاز برای پیامک اضطراری");smsNumber.setInputType(InputType.TYPE_CLASS_PHONE);smsNumber.setText(NexaStore.smsNumber(this));sms.addView(smsNumber,UiKit.matchWrap(this,8,6));smsCode=field("کد محرمانه؛ مثلاً NX-4827");smsCode.setText(NexaStore.smsCode(this));sms.addView(smsCode,UiKit.matchWrap(this,0,8));smsAnyone=new Switch(this);smsAnyone.setText("اجازه استفاده از کد از هر شماره (با احتیاط)");
        smsAnyone.setTextColor(UiKit.TEXT);smsAnyone.setChecked(NexaStore.smsFromAnyone(this));sms.addView(smsAnyone);
        sms.addView(UiKit.muted(this,"برای چند مخاطب، شماره‌ها را با «،» یا خط جدید جدا کن. کد باید حداقل ۸ کاراکتر باشد و متن پیامک دقیقاً همان کد باشد."),UiKit.matchWrap(this,6,8));
        Button smsContact=UiKit.secondaryButton(this,"➕ انتخاب مخاطب مجاز");
        smsContact.setOnClickListener(v->{Intent intent=new Intent(Intent.ACTION_PICK,
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI);startActivityForResult(intent,REQ_SMS_CONTACT);});
        sms.addView(smsContact,UiKit.matchWrap(this,0,9));
        Button saveSms=UiKit.secondaryButton(this,"ذخیره کد اضطراری");saveSms.setOnClickListener(v->{String code=smsCode.getText().toString().trim();
            if(smsSwitch.isChecked()&&code.length()<8){Toast.makeText(this,"کد اضطراری باید حداقل ۸ کاراکتر باشد.",Toast.LENGTH_LONG).show();return;}
            NexaStore.setSmsEnabled(this,smsSwitch.isChecked());NexaStore.setSmsNumber(this,smsNumber.getText().toString().trim());
            NexaStore.setSmsFromAnyone(this,smsAnyone.isChecked());NexaStore.setSmsCode(this,code);Toast.makeText(this,"ذخیره شد.",Toast.LENGTH_SHORT).show();});sms.addView(saveSms);root.addView(sms,UiKit.matchWrap(this,0,14));
        LinearLayout tools=UiKit.colorfulCardLayout(this,3);tools.addView(UiKit.sectionTitle(this,"امنیت و پشتیبان‌گیری"));Button security=UiKit.secondaryButton(this,"🔐 PIN و اثر انگشت");security.setOnClickListener(v->startActivity(new Intent(this,SecurityActivity.class)));tools.addView(security,UiKit.matchWrap(this,10,8));Button export=UiKit.secondaryButton(this,"⬆ تهیه فایل Backup");export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Nexa_Backup.json");startActivityForResult(i,REQ_EXPORT);});tools.addView(export,UiKit.matchWrap(this,0,8));Button imp=UiKit.secondaryButton(this,"⬇ بازیابی Backup");imp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");startActivityForResult(i,REQ_IMPORT);});tools.addView(imp,UiKit.matchWrap(this,0,8));tools.addView(UiKit.muted(this,"برای امنیت، رمزهای Nexa Vault در Backup عمومی منتقل نمی‌شوند؛ کلید Vault فقط داخل Android Keystore همین دستگاه است."),UiKit.matchWrap(this,0,8));Button test=UiKit.secondaryButton(this,"🧪 Nexa Test Center");test.setOnClickListener(v->startActivity(new Intent(this,TestCenterActivity.class)));tools.addView(test);root.addView(tools,UiKit.matchWrap(this,0,14));
        LinearLayout monitor=UiKit.cardLayout(this);LinearLayout mr=new LinearLayout(this);mr.setGravity(Gravity.CENTER_VERTICAL);TextView mt=UiKit.sectionTitle(this,"تشخیص خودکار Silent / Vibrate");mr.addView(mt,new LinearLayout.LayoutParams(0,-2,1f));Switch sw=new Switch(this);sw.setChecked(AppPrefs.isMonitoringEnabled(this));sw.setText(sw.isChecked()?"روشن":"خاموش");mr.addView(sw);monitor.addView(mr);monitor.addView(UiKit.muted(this,"پس از روشن‌شدن گوشی، Nexa دوباره آماده می‌شود."),UiKit.matchWrap(this,8,0));sw.setOnCheckedChangeListener((b,v)->{AppPrefs.setMonitoringEnabled(this,v);sw.setText(v?"روشن":"خاموش");});root.addView(monitor,UiKit.matchWrap(this,0,14));
        LinearLayout about=UiKit.cardLayout(this);about.setBackground(UiKit.accentCard(this));about.addView(UiKit.sectionTitle(this,"درباره Nexa"));TextView info=UiKit.muted(this,"NEXA 5.2\nObsidian Personal Assistant\n\nسازنده: درویش\nشماره تماس سازنده: 09354485733");info.setTextSize(14);about.addView(info,UiKit.matchWrap(this,8,0));root.addView(about);setContentView(sc);refreshStatuses();}
    private EditText field(String h){EditText e=new EditText(this);e.setHint(h);e.setHintTextColor(UiKit.MUTED);e.setTextColor(UiKit.TEXT);e.setBackground(UiKit.field(this));e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));return e;}
    private TextView status(String x){TextView t=UiKit.muted(this,x);t.setTextSize(14);return t;}
    private String pfx(boolean x){return x?"✓  ":"○  ";}
    private boolean runtimeReady(){return checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED&&(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED);}
    private boolean screening(){if(Build.VERSION.SDK_INT<29)return true;RoleManager rm=getSystemService(RoleManager.class);return rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)&&rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);}
    private void refreshStatuses(){if(overlayStatus==null)return;NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);boolean o=Settings.canDrawOverlays(this),d=nm.isNotificationPolicyAccessGranted(),r=runtimeReady(),s=screening(),exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms(),full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent(),bat=pm.isIgnoringBatteryOptimizations(getPackageName());overlayStatus.setText(pfx(o)+"نمایش روی برنامه‌ها");dndStatus.setText(pfx(d)+"کنترل Silent / Vibrate");phoneStatus.setText(pfx(r)+"تماس، مخاطبین، پیامک و اعلان‌ها");screeningStatus.setText(pfx(s)+"Call Screening تماس‌های مجاز");exactAlarmStatus.setText(pfx(exact)+"آلارم دقیق");fullScreenStatus.setText(pfx(full)+"نمایش تمام‌صفحه هشدار روی Lock Screen");batteryStatus.setText(pfx(bat)+"فعالیت پس‌زمینه بدون محدودیت");setupButton.setText(o&&d&&r&&s&&exact&&full&&bat?"همه دسترسی‌ها آماده‌اند ✓":"شروع راه‌اندازی کامل");}
    private boolean stepGranted(int s){if(s==1)return Settings.canDrawOverlays(this);if(s==2)return ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted();if(s==3)return Build.VERSION.SDK_INT<31||((AlarmManager)getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();if(s==4)return Build.VERSION.SDK_INT<34||((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent();if(s==5)return ((PowerManager)getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());return true;}
    private void continueSetup(){refreshStatuses();if(!Settings.canDrawOverlays(this)){waitingSpecialStep=1;startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;}NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);if(!nm.isNotificationPolicyAccessGranted()){waitingSpecialStep=2;startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));return;}ArrayList<String> rt=new ArrayList<>();if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.READ_PHONE_STATE);if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.READ_CONTACTS);if(checkSelfPermission(Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.RECEIVE_SMS);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.POST_NOTIFICATIONS);if(!rt.isEmpty()){requestPermissions(rt.toArray(new String[0]),REQ_RUNTIME);return;}if(Build.VERSION.SDK_INT>=29&&!screening()){RoleManager rm=getSystemService(RoleManager.class);startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),REQ_CALL_SCREENING);return;}AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){waitingSpecialStep=3;try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){setupInProgress=false;}return;}if(Build.VERSION.SDK_INT>=34&&!nm.canUseFullScreenIntent()){waitingSpecialStep=4;try{startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));}catch(Exception e){setupInProgress=false;}return;}PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);if(!pm.isIgnoringBatteryOptimizations(getPackageName())){waitingSpecialStep=5;try{startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}return;}setupInProgress=false;AppPrefs.setSetupCompleted(this,true);ReminderScheduler.rescheduleAll(this);Intent mon=new Intent(this,SilentTimerService.class);mon.setAction(SilentTimerService.ACTION_MONITOR);try{if(Build.VERSION.SDK_INT>=26)startForegroundService(mon);else startService(mon);}catch(Exception ignored){}refreshStatuses();Toast.makeText(this,"راه‌اندازی Nexa کامل شد.",Toast.LENGTH_LONG).show();if(autoFirstRunSetup)handler.postDelayed(this::finish,700);}
    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);if(r!=REQ_RUNTIME)return;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED){setupInProgress=false;Toast.makeText(this,"برای ادامه، دسترسی‌های این مرحله باید تأیید شوند.",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this::continueSetup,250);}
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r==REQ_UNLOCK){if(result==RESULT_OK&&SecurityGate.isUnlocked()){
            verifiedSettings=true;openSettings();}else finish();return;}
        if(r==REQ_SMS_CONTACT){if(result==RESULT_OK&&data!=null&&data.getData()!=null){
            try(android.database.Cursor cr=getContentResolver().query(data.getData(),new String[]{
                android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
                if(cr!=null&&cr.moveToFirst()&&smsNumber!=null){
                    String entry=cr.getString(0)+"|"+cr.getString(1);
                    smsNumber.setText(smsNumber.getText().toString()+
                        (smsNumber.length()>0?";":"")+entry);
                }
            }catch(Exception ignored){}
        }return;}if(r==REQ_CALL_SCREENING){if(!screening()){setupInProgress=false;Toast.makeText(this,"Call Screening فعال نشد.",Toast.LENGTH_LONG).show();}else handler.postDelayed(this::continueSetup,250);return;}if(result!=RESULT_OK||data==null||data.getData()==null)return;try{if(r==REQ_EXPORT){OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(NexaStore.exportJson(this).getBytes(java.nio.charset.StandardCharsets.UTF_8));out.close();Toast.makeText(this,"Backup ساخته شد.",Toast.LENGTH_SHORT).show();}else if(r==REQ_IMPORT){BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData())));StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null)s.append(line);br.close();if(NexaStore.importJson(this,s.toString())){ReminderScheduler.rescheduleAll(this);EmergencyCardManager.refresh(this);Toast.makeText(this,"Backup بازیابی شد.",Toast.LENGTH_LONG).show();recreate();}else Toast.makeText(this,"فایل معتبر نیست.",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"خطا در فایل Backup.",Toast.LENGTH_SHORT).show();}}
}
