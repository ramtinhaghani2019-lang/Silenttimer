# NEXA 5.2 (source preview) — Obsidian Personal Assistant

**Developer / سازنده:** درویش  
**Developer phone / شماره تماس سازنده:** 09354485733  
**Version / نسخه:** 5.2 — build not yet verified

Nexa is a modular personal utility assistant for Android. It keeps the original Silent Timer engine and adds separate modules so the home screen stays organized.

## Home modules

### 🔕 Nexa Silent
- Smart Silent / Vibrate timer
- 5-minute increments
- exact end clock time
- manual Samsung Silent/Vibrate detection
- allowed calls
- Call Screening role
- emergency SMS code
- Quick Settings tile and notification controls

### ✦ Nexa Today
- upcoming reminders
- medicine doses
- open tasks
- bills due soon
- garage snapshot
- next-unlock note

### 📅 Nexa Reminder
- Solar Hijri / Persian date
- default and custom categories
- doctor appointments
- doctor name
- medical file number
- clinic/center name
- clinic phone and address
- multi-stage reminders
- repeating alarm until dismissed
- ongoing lock-screen reminder card

### 💊 Nexa Med
- medicine name and instructions
- every 4 / 6 / 8 / 12 / 24 hours
- course length
- Taken / Later / Skipped actions
- reminder repeat

### 🚗 Nexa Garage
- multiple cars / motorcycles
- odometer
- service categories
- service notes and cost
- next service by km/date
- fuel log

### 🛒 Nexa List
- multiple shopping lists
- quantity, category, optional price
- important items
- purchased items remain visible with strike-through and lower opacity
- reset purchased items
- clear purchased items
- To-Do list with optional due date

### 🎯 Nexa Focus (inside Nexa Silent)
- meeting, sleep, study and work profiles
- custom profiles
- weekly schedules

### ⚖️ Nexa Case
- case title and case number
- court and branch
- counterparty
- lawyer
- notes
- Persian court date/time
- automatic multi-stage court reminder

### 🔐 Nexa Vault
- account, email, site, Wi-Fi and private notes
- bank/account category
- sensitive fields encrypted with AES-GCM using Android Keystore
- screenshot protection on Vault screen
- PIN/biometric app lock integration
- Vault secrets intentionally excluded from portable JSON backup because the encryption key is device-bound

### 📈 Nexa Assets
- gold 18k / 24k
- silver
- copper
- USD / EUR
- stocks
- custom assets
- Persian buy date
- amount, unit price, fee
- current value and profit/loss
- optional online global spot references for gold/silver and EUR/USD
- manual USD/Toman rate for local estimate
- market reference is not an Iranian retail-market quote

### 📄 Nexa Docs
- national ID, driver license, passport, insurance, inspection, contracts, permits
- issue/expiry Persian dates
- document number
- 30-day / 7-day / 1-day / due-date renewal reminders

### 💳 Nexa Bills
- installments
- utility bills
- rent
- subscriptions
- insurance
- checks
- one-time / monthly / yearly recurrence
- Persian due-date selection
- recurring due dates advance in the Persian calendar

### 🆘 Nexa Emergency
- optional public emergency lock-screen notification card
- display name
- up to two emergency phone numbers
- safe public note
- quick dial buttons

### 🏠 Nexa Home
- AC, boiler, filters, plumbing, electrical, elevator and custom home maintenance
- last service date
- next service date
- cost and notes
- reminder before next service

### ◷ Nexa Timeline
- unified future and recent timeline from reminders, medicines, cases, bills, documents, home service, garage and history

### ☷ Nexa History
- activity history and recent events

## Global tools
- Universal Search across modules
- Quick Add from the home screen
- Local JSON Backup / Restore
- PIN and biometric lock
- Nexa Test Center
- home-screen widget
- boot restoration and background monitoring

## First launch
The first launch automatically starts the sequential permission/setup flow:
1. Display over other apps
2. Notification policy / Silent control
3. Phone state, contacts, SMS and notification permission
4. Call Screening role
5. Exact alarm access
6. Full-screen lock-screen alarm access (where required by Android)
7. Battery optimization exemption

## Data
Most data stays locally on the phone. Online access is used only by the optional market-reference feature in Nexa Assets.

## Release audit (57 user corrections)

See `IMPLEMENTATION_AUDIT_FA.md` for individual status, known gaps and security/build limitations. First-run email is local and unverified. There is no email OTP/password recovery backend in this preview. No Iranian multi-source price consensus is claimed.
