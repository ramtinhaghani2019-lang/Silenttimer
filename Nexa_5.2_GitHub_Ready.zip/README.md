# Nexa 5.2.1 — Obsidian Personal Assistant

**Developer / سازنده:** Darvish  
**Contact:** 09354485733

این بسته نسخه اصلاحی 5.2 است و برای Build با Android Gradle Plugin پروژه و Gradle 8.9 آماده شده است.

## Build

```bash
gradle --no-daemon clean assembleDebug
```

APK خروجی:

`app/build/outputs/apk/debug/app-debug.apk`

برای جزئیات اصلاحات، فایل `IMPLEMENTATION_AUDIT_FA.md` را ببینید.
