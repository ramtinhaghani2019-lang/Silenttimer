# Silent Timer

Personal Android utility for Samsung Galaxy A52s and similar Android phones.

## Features
- Timed real silent/ringer mode
- Automatically restores the previous ringer mode
- Floating draggable countdown
- AMOLED / Midnight / Light / Glass-style themes
- Stores one emergency phone number
- While the timer is active, the app attempts to temporarily restore ringing for that number, then returns to silent after the call
- No ads, no account, no internet feature

## First-run permissions
The app asks for:
- Display over other apps
- Do Not Disturb / notification policy access
- Phone state
- Call log (needed to identify the incoming number on supported Android builds)
- Notifications on Android 13+

## GitHub build
Open the **Actions** tab and run **Build Silent Timer APK**.
After a successful build, download the artifact named **SilentTimer-APK**.

## Note about the emergency-number feature
Android and Samsung firmware can restrict incoming-number visibility and ringtone changes. The timed-silent function and floating timer are independent of this. The emergency-number exception should be tested on the target A52s after installation.
