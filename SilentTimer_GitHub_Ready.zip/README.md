# Silent Timer 2.0

Personal Android app for timed Silent mode with smart Samsung-panel behavior.

## Core features
- Timed Silent mode in 15-minute steps
- Floating countdown
- Automatic sound restore at timer end
- Detects manual Silent mode while the monitoring service is active and shows a floating time picker
- Manual override: if the user turns sound back on during an active timer, the timer is cancelled
- Multiple allowed phone numbers
- Master on/off switch for allowed callers
- Allowed callers can ring while the phone is manually Silent or Silent Timer is active
- After an allowed call ends, the previous Silent state is restored
- Notification actions: +15 minutes, end now, allowed callers on/off
- Quick Settings tile: one tap starts 30 minutes; tap again ends the timer
- AMOLED / Midnight / Light / Glass themes
- No internet feature, no ads, no account

## Important
The smart manual-Silent detection uses a low-priority foreground monitoring service. Android may show a persistent Silent Timer notification while this mode is active.

On Samsung, add the **Silent Timer** tile once from Quick Settings > Edit buttons.

Incoming number visibility depends on phone/Android permissions. This feature has already been designed around the same READ_PHONE_STATE + READ_CALL_LOG approach used by the previous working build.
