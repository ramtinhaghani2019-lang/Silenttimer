# Silent Timer 3.0

A personal Android utility for timed Silent/Vibrate control.

## Main features
- Professional multi-screen dashboard
- Smart Silent page separate from Allowed Calls page
- 5-minute timer increments
- Quick presets from 5 minutes upward
- Set an exact clock time such as 13:45 for automatic sound restoration
- Detect manual Silent and Vibrate changes from the Samsung sound panel
- Show a floating timer chooser every time manual Silent/Vibrate is detected
- Floating countdown can collapse to the screen edge and reopen on tap
- Multiple allowed phone numbers
- Pick allowed numbers directly from Contacts
- Master on/off switch for allowed-call ringing
- Allowed calls can ring while the phone is manually Silent/Vibrate or while a timer is active
- Returns to the previous Silent/Vibrate state after the allowed call ends
- Boot receiver starts the monitor after phone restart
- Quick Settings tile
- Notification actions: +5 minutes, stop, allowed calls on/off
- Appearance settings moved to a dedicated Settings screen
- No internet feature and no ads

## Samsung note
For the most reliable always-on monitoring, allow background activity / unrestricted battery use for Silent Timer in Samsung battery settings.

## 3.1 reliability fix
- Fixes timer expiry so sound is restored exactly when the countdown ends.
- Fixes the floating countdown remaining on screen after expiry.
- Adds an AlarmManager backup expiry path in case the main timer callback is delayed.
