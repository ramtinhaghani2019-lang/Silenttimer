# Silent Timer 4.0

A personal Android utility for timed Silent/Vibrate control.

## 4.0 redesign
- New premium multi-screen UI
- Home dashboard with circular timer status
- Separate Smart Silent and Allowed Calls screens
- Settings removed from the home screen and placed behind a gear button
- Bottom navigation for Home / Smart Silent / Allowed Calls
- 5-minute timer increments
- Exact clock-time exit such as 13:45
- Manual Samsung Silent/Vibrate detection
- Every manual Silent/Vibrate event opens a fresh timer chooser
- Timer chooser now has:
  - Close (X)
  - "No timer; keep this mode"
  - +5 / -5
  - quick presets
  - exact clock-time option
- Floating countdown collapses to the screen edge and reopens on tap
- Boot receiver restarts monitoring after phone restart
- Quick Settings tile
- Notification actions: +5 minutes / stop / allowed calls on-off

## Allowed calls 4.0
- Multiple numbers
- Direct contact picker
- Master on/off switch
- Uses Android's official Call Screening role on Android 10+
- When an allowed number calls during Silent/Vibrate:
  - phone temporarily switches to normal ringing
  - after the call ends it returns to the previous Silent/Vibrate state
- If a timer is active, the timer continues and the call returns to the timer's mode afterward

## Samsung reliability
For consistent manual Silent/Vibrate detection, set Silent Timer battery usage to Unrestricted / بدون محدودیت in Samsung settings.
