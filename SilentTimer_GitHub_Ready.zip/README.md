# Silent Timer 4.1 — Obsidian Edition

## What changed
- One fixed premium visual identity: Obsidian
- More graphical home dashboard with an ambient aura behind the circular timer
- Theme switching removed
- Permission setup removed from Home and moved entirely into Settings
- New one-tap sequential setup:
  1. Display over other apps
  2. Notification policy / Silent control
  3. Phone state, contacts and notifications
  4. Call Screening role
  5. Battery optimization exemption
- After you approve each step, the next required system page opens automatically
- Allowed-call temporary sound changes are now ignored by the manual Silent/Vibrate detector
- When an allowed call ends and the phone returns to Silent/Vibrate, the timer-choice popup no longer opens
- Background monitor remains enabled after reboot
- Smart Silent and Allowed Calls remain separate screens
- 5-minute increments, exact end time, Quick Settings tile and floating timer are preserved
