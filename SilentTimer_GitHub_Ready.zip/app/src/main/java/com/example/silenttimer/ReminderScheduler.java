package com.example.silenttimer;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.util.List;

public final class ReminderScheduler {
    public static final String CHANNEL = "nexa_reminders";
    public static final String LOCK_CHANNEL = "nexa_lock_card";
    private ReminderScheduler() {}

    public static void rescheduleAll(Context c) {
        for (NexaStore.Reminder r : NexaStore.reminders(c)) {
            if (r.active) scheduleReminder(c, r);
        }
        MedicineScheduler.rescheduleAll(c);
        WeeklyScheduler.rescheduleAll(c);
        updateLockCard(c);
    }

    public static void scheduleReminder(Context c, NexaStore.Reminder r) {
        String[] pieces = r.offsetsMinutes.split(",");
        for (String piece : pieces) {
            try {
                long offset = Long.parseLong(piece.trim());
                long trigger = r.whenMillis - offset * 60_000L;
                if (trigger > System.currentTimeMillis()) {
                    String token = r.id + ":" + offset;
                    scheduleToken(c, r.id, token, trigger, r.repeatMinutes);
                }
            } catch (Exception ignored) {}
        }
        updateLockCard(c);
    }

    public static void scheduleToken(Context c, String reminderId, String token, long trigger, int repeatMinutes) {
        Intent i = new Intent(c, ReminderAlarmReceiver.class);
        i.putExtra("id", reminderId);
        i.putExtra("token", token);
        i.putExtra("repeat", repeatMinutes);
        PendingIntent pi = PendingIntent.getBroadcast(c, token.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setAlarm(c, trigger, pi);
    }

    public static void setAlarm(Context c, long trigger, PendingIntent pi) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi);
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi); else am.set(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch=new NotificationChannel(CHANNEL,"Nexa Reminders",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("قرارها، سررسیدها و هشدارهای Nexa"); ch.enableVibration(true); ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC); nm.createNotificationChannel(ch);
        NotificationChannel lock=new NotificationChannel(LOCK_CHANNEL,"Nexa Lock Reminder",NotificationManager.IMPORTANCE_LOW);
        lock.setDescription("نمایش نزدیک‌ترین قرار روی صفحه قفل"); lock.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC); lock.setSound(null,null); nm.createNotificationChannel(lock);
    }

    public static void updateLockCard(Context c) {
        createChannels(c);
        NexaStore.Reminder next=null; long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:NexaStore.reminders(c)) if(r.active && r.whenMillis>=now && (next==null || r.whenMillis<next.whenMillis)) next=r;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(next==null){nm.cancel(9200);return;}
        Intent open=new Intent(c,RemindersActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,9200,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,LOCK_CHANNEL):new Notification.Builder(c);
        Notification n=b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(next.icon+"  "+next.title).setContentText("نزدیک‌ترین یادآور • "+PersianDateUtil.pretty(next.whenMillis)).setContentIntent(pi).setOngoing(true).setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_REMINDER).build();
        nm.notify(9200,n);
    }
}
