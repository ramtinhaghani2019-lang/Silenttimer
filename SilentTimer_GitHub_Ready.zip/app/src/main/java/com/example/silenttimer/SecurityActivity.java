package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;

public class SecurityActivity extends Activity {
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,20),UiKit.dp(this,20),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);Button back=UiKit.secondaryButton(this,"‹ بازگشت");back.setOnClickListener(v->finish());root.addView(back,UiKit.matchWrap(this,0,14));root.addView(UiKit.title(this,"امنیت"),UiKit.matchWrap(this,0,14));LinearLayout card=UiKit.colorfulCardLayout(this,3);root.addView(card,UiKit.matchWrap(this,0,14));card.addView(UiKit.sectionTitle(this,"PIN و بیومتریک"));EditText pin=new EditText(this);pin.setHint("PIN چهار تا شش رقمی");pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);pin.setTextColor(UiKit.TEXT);pin.setHintTextColor(UiKit.MUTED);pin.setBackground(UiKit.field(this));pin.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));card.addView(pin,UiKit.matchWrap(this,12,8));Switch lock=new Switch(this);lock.setText("قفل برنامه");lock.setTextColor(UiKit.TEXT);lock.setChecked(NexaStore.lockEnabled(this));card.addView(lock);Switch bio=new Switch(this);bio.setText("اثر انگشت / بیومتریک");bio.setTextColor(UiKit.TEXT);bio.setChecked(NexaStore.biometricEnabled(this));card.addView(bio);Button save=UiKit.primaryButton(this,"ذخیره تنظیمات امنیتی");save.setOnClickListener(v->{String p=pin.getText().toString().trim();if(lock.isChecked()&&(p.length()<4||p.length()>6)){Toast.makeText(this,"PIN باید ۴ تا ۶ رقم باشد.",Toast.LENGTH_SHORT).show();return;}if(!p.isEmpty())NexaStore.setPin(this,p);NexaStore.setLockEnabled(this,lock.isChecked());NexaStore.setBiometricEnabled(this,bio.isChecked());if(lock.isChecked())SecurityGate.lock();else SecurityGate.unlock();Toast.makeText(this,"ذخیره شد.",Toast.LENGTH_SHORT).show();});card.addView(save,UiKit.matchWrap(this,12,0));setContentView(sc);}
}
