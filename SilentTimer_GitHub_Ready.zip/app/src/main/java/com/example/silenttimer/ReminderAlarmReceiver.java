package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent intent) {
        String id=intent.getStringExtra("id"), token=intent.getStringExtra("token");
        int repeat=intent.getIntExtra("repeat",10);
        if(id==null||token==null||NexaStore.tokenDismissed(c,token))return;
        NexaStore.Reminder r=NexaStore.reminder(c,id); if(r==null||!r.active)return;
        ReminderScheduler.createChannels(c);
        Intent dismiss=new Intent(c,ReminderActionReceiver.class);dismiss.setAction("DISMISS");dismiss.putExtra("token",token);
        PendingIntent dismissPi=PendingIntent.getBroadcast(c,(token+"d").hashCode(),dismiss,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent snooze=new Intent(c,ReminderActionReceiver.class);snooze.setAction("SNOOZE");snooze.putExtra("token",token);snooze.putExtra("id",id);snooze.putExtra("repeat",repeat);
        PendingIntent snoozePi=PendingIntent.getBroadcast(c,(token+"s").hashCode(),snooze,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent open=new Intent(c,RemindersActivity.class);PendingIntent openPi=PendingIntent.getActivity(c,token.hashCode(),open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent ring=new Intent(c,ReminderRingActivity.class);ring.putExtra("id",id);ring.putExtra("token",token);ring.putExtra("repeat",repeat);ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);PendingIntent ringPi=PendingIntent.getActivity(c,(token+"ring").hashCode(),ring,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ReminderScheduler.CHANNEL):new Notification.Builder(c);
        Notification n=b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(r.icon+"  "+r.title).setContentText(r.category+" • "+PersianDateUtil.pretty(r.whenMillis)+(r.doctorName.isEmpty()?"":" • پزشک "+r.doctorName)+(r.doctorFileNumber.isEmpty()?"":" • پرونده "+r.doctorFileNumber)+(r.note.isEmpty()?"":" • "+r.note)).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setVisibility(Notification.VISIBILITY_PUBLIC).setAutoCancel(false).setOngoing(true).setContentIntent(openPi).setFullScreenIntent(ringPi,true).addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"خاموش",dismissPi).build()).addAction(new Notification.Action.Builder(android.R.drawable.ic_popup_reminder,"یادآوری بعداً",snoozePi).build()).build();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(token.hashCode(),n);
        NexaStore.addHistory(c,"یادآور","هشدار: "+r.title);
        ReminderScheduler.scheduleToken(c,id,token,System.currentTimeMillis()+repeat*60_000L,repeat);
        ReminderScheduler.updateLockCard(c);
    }
}
