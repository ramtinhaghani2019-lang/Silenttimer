package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class DocsActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 250);
        }
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Docs"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"مدارک مهم، تاریخ انقضا و هشدار تمدید"),UiKit.matchWrap(this,0,14));

        LinearLayout hero=UiKit.colorfulCardLayout(this,1);
        hero.addView(UiKit.sectionTitle(this,"📄 مدارک و تمدیدها"));
        hero.addView(UiKit.muted(this,"هشدار پیش‌فرض: ۳۰ روز، ۷ روز، ۱ روز قبل و روز انقضا."),UiKit.matchWrap(this,6,10));
        Button add=UiKit.primaryButton(this,"＋ ثبت مدرک");
        add.setOnClickListener(v->addDialog());
        hero.addView(add);
        root.addView(hero,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        Spinner type=new Spinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"کارت ملی","گواهینامه","پاسپورت","بیمه","معاینه فنی","قرارداد","مجوز","سایر"}
        ));

        EditText title=field("عنوان مدرک");
        EditText number=field("شماره / شناسه");
        EditText note=field("توضیحات");

        final long[] issue={System.currentTimeMillis()};
        final long[] expiry={System.currentTimeMillis()+365L*24L*60L*60L*1000L};

        Button issueBtn=UiKit.secondaryButton(this,"تاریخ صدور: "+PersianDateUtil.format(issue[0]));
        issueBtn.setOnClickListener(v->PersianDatePickerHelper.pickDate(this,issue[0],"تاریخ صدور",ms->{issue[0]=ms;issueBtn.setText("تاریخ صدور: "+PersianDateUtil.format(ms));}));

        Button expiryBtn=UiKit.secondaryButton(this,"تاریخ انقضا: "+PersianDateUtil.format(expiry[0]));
        expiryBtn.setOnClickListener(v->PersianDatePickerHelper.pickDate(this,expiry[0],"تاریخ انقضا",ms->{expiry[0]=ms;expiryBtn.setText("تاریخ انقضا: "+PersianDateUtil.format(ms));}));

        box.addView(type);box.addView(title);box.addView(number);box.addView(note);box.addView(issueBtn);box.addView(expiryBtn);

        new AlertDialog.Builder(this)
                .setTitle("مدرک جدید")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(type.getSelectedItem());

                    NexaStore.DocumentItem x=new NexaStore.DocumentItem();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.number=number.getText().toString().trim();
                    x.note=note.getText().toString().trim();
                    x.issueDate=issue[0];
                    x.expiryDate=expiry[0];

                    NexaStore.addDocument(this,x);
                    LinkedReminderHelper.upsert(
                            this,
                            "doc:"+x.id,
                            "تمدید "+x.title,
                            "مدارک",
                            "📄",
                            x.number.isEmpty()?x.note:("شماره: "+x.number+" • "+x.note),
                            x.expiryDate,
                            "43200,10080,1440,0",
                            30
                    );
                    NexaStore.addHistory(this,"مدارک","ثبت شد: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.DocumentItem> data=NexaStore.documents(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"مدرکی ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        long now=System.currentTimeMillis();

        for(NexaStore.DocumentItem x:data){
            long days=TimeUnit.MILLISECONDS.toDays(x.expiryDate-now);
            LinearLayout c=UiKit.colorfulCardLayout(this,days<30?3:1);
            c.addView(UiKit.sectionTitle(this,"📄 "+x.title));
            c.addView(UiKit.muted(this,x.type+" • انقضا "+PersianDateUtil.format(x.expiryDate)),UiKit.matchWrap(this,5,2));

            TextView state=UiKit.muted(this,days>=0?(days+" روز تا انقضا"):("منقضی شده • "+Math.abs(days)+" روز گذشته"));
            state.setTextColor(days<0?UiKit.PINK:(days<30?UiKit.GOLD:UiKit.TEAL));
            c.addView(state);

            if(!x.number.isEmpty())c.addView(UiKit.muted(this,"شماره: "+x.number),UiKit.matchWrap(this,4,0));
            if(!x.note.isEmpty())c.addView(UiKit.muted(this,x.note),UiKit.matchWrap(this,4,0));

            Button del=UiKit.secondaryButton(this,"حذف");
            del.setOnClickListener(v->{
                LinkedReminderHelper.remove(this,"doc:"+x.id);
                NexaStore.removeDocument(this,x.id);
                render();
            });
            c.addView(del,UiKit.matchWrap(this,10,0));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
    }
}
