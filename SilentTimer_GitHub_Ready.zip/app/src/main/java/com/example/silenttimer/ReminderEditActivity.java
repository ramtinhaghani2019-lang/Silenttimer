package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class ReminderEditActivity extends Activity {
    private EditText title,note;
    private Spinner category,repeat;
    private TextView dateText,timeText;
    private CheckBox d4,d1,d0;
    private int jy,jm,jd,hour,minute;
    private final List<String> categories=new ArrayList<>();

    private LinearLayout doctorBox;
    private EditText doctorName,doctorFile,doctorCenter,doctorPhone,doctorAddress;

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        int[]j=PersianDateUtil.fromMillis(System.currentTimeMillis());
        jy=j[0];jm=j[1];jd=j[2];
        Calendar c=Calendar.getInstance();
        hour=c.get(Calendar.HOUR_OF_DAY);
        minute=c.get(Calendar.MINUTE);
        build();
    }

    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setBackground(UiKit.screenBackground(this));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sc.addView(root);

        Button back=UiKit.secondaryButton(this,"‹ بازگشت");
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Reminder"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"📅 قرار، پزشک، چک، قسط، تولد و هر سررسید مهم"),UiKit.matchWrap(this,0,14));

        LinearLayout card=UiKit.colorfulCardLayout(this,1);
        root.addView(card);

        title=field("عنوان یادآور");
        card.addView(title,UiKit.matchWrap(this,0,8));

        categories.clear();
        for(String s:NexaStore.defaultReminderCategories())categories.add(s);
        categories.addAll(NexaStore.customCategories(this));

        category=new Spinner(this);
        refreshCategory();
        card.addView(category,UiKit.matchWrap(this,0,8));

        Button custom=UiKit.secondaryButton(this,"＋ دسته‌بندی جدید");
        custom.setOnClickListener(v->newCategory());
        card.addView(custom,UiKit.matchWrap(this,0,8));

        doctorBox=new LinearLayout(this);
        doctorBox.setOrientation(LinearLayout.VERTICAL);
        doctorBox.setPadding(0,UiKit.dp(this,4),0,UiKit.dp(this,8));
        doctorName=field("نام پزشک");
        doctorFile=field("شماره پرونده");
        doctorCenter=field("نام مطب / مرکز درمانی");
        doctorPhone=field("شماره تماس مطب");
        doctorAddress=field("آدرس");
        doctorBox.addView(UiKit.sectionTitle(this,"🩺 اطلاعات پزشکی"));
        doctorBox.addView(doctorName,UiKit.matchWrap(this,8,5));
        doctorBox.addView(doctorFile,UiKit.matchWrap(this,0,5));
        doctorBox.addView(doctorCenter,UiKit.matchWrap(this,0,5));
        doctorBox.addView(doctorPhone,UiKit.matchWrap(this,0,5));
        doctorBox.addView(doctorAddress);
        doctorBox.setVisibility(View.GONE);
        card.addView(doctorBox);

        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id){updateSpecialFields();}
            @Override public void onNothingSelected(AdapterView<?> p){}
        });

        note=field("توضیحات / یادداشت");
        card.addView(note,UiKit.matchWrap(this,0,10));

        dateText=UiKit.secondaryButton(this,"");
        ((Button)dateText).setOnClickListener(v->pickDate());
        card.addView(dateText,UiKit.matchWrap(this,0,8));

        timeText=UiKit.secondaryButton(this,"");
        ((Button)timeText).setOnClickListener(v->pickTime());
        card.addView(timeText,UiKit.matchWrap(this,0,12));

        card.addView(UiKit.sectionTitle(this,"هشدارها"));

        d4=new CheckBox(this);
        d4.setText("۴ روز قبل");
        d4.setTextColor(UiKit.TEXT);
        d4.setChecked(true);
        card.addView(d4);

        d1=new CheckBox(this);
        d1.setText("۱ روز قبل");
        d1.setTextColor(UiKit.TEXT);
        d1.setChecked(true);
        card.addView(d1);

        d0=new CheckBox(this);
        d0.setText("در زمان اصلی");
        d0.setTextColor(UiKit.TEXT);
        d0.setChecked(true);
        card.addView(d0);

        card.addView(UiKit.muted(this,"اگر هشدار را خاموش نکنی، دوباره تکرار می‌شود."),UiKit.matchWrap(this,8,5));

        repeat=new Spinner(this);
        repeat.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"هر ۵ دقیقه","هر ۱۰ دقیقه","هر ۱۵ دقیقه","هر ۳۰ دقیقه"}
        ));
        repeat.setSelection(1);
        card.addView(repeat);

        Button save=UiKit.primaryButton(this,"ذخیره یادآور");
        save.setOnClickListener(v->save());
        root.addView(save,UiKit.matchWrap(this,14,0));

        updateLabels();
        setContentView(sc);
    }

    private EditText field(String hint){
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void refreshCategory(){
        category.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,categories));
    }

    private void updateSpecialFields(){
        Object selected=category.getSelectedItem();
        String cat=selected==null?"":String.valueOf(selected);
        doctorBox.setVisibility(cat.contains("دکتر")||cat.contains("پزشک")?View.VISIBLE:View.GONE);
    }

    private void newCategory(){
        EditText e=field("مثلاً بیمه");
        new AlertDialog.Builder(this)
                .setTitle("دسته‌بندی جدید")
                .setView(e)
                .setPositiveButton("افزودن",(d,w)->{
                    String x=e.getText().toString().trim();
                    if(!x.isEmpty()){
                        String val="🔖 "+x;
                        NexaStore.addCustomCategory(this,val);
                        categories.add(val);
                        refreshCategory();
                        category.setSelection(categories.size()-1);
                    }
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void pickDate(){
        LinearLayout row=new LinearLayout(this);
        row.setPadding(12,8,12,8);
        NumberPicker y=new NumberPicker(this),m=new NumberPicker(this),d=new NumberPicker(this);
        y.setMinValue(jy);y.setMaxValue(jy+10);y.setValue(jy);
        m.setMinValue(1);m.setMaxValue(12);m.setDisplayedValues(PersianDateUtil.MONTHS);m.setValue(jm);
        d.setMinValue(1);d.setMaxValue(31);d.setValue(jd);
        row.addView(y,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(m,new LinearLayout.LayoutParams(0,-2,1));
        row.addView(d,new LinearLayout.LayoutParams(0,-2,1));

        new AlertDialog.Builder(this)
                .setTitle("تاریخ شمسی")
                .setView(row)
                .setPositiveButton("تأیید",(x,w)->{
                    jy=y.getValue();jm=m.getValue();
                    jd=Math.min(d.getValue(),PersianDateUtil.monthLength(jy,jm));
                    updateLabels();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void pickTime(){
        new TimePickerDialog(this,(v,h,m)->{
            hour=h;minute=m;updateLabels();
        },hour,minute,true).show();
    }

    private void updateLabels(){
        dateText.setText(String.format(java.util.Locale.US,"تاریخ: %04d/%02d/%02d",jy,jm,jd));
        timeText.setText(String.format(java.util.Locale.US,"ساعت: %02d:%02d",hour,minute));
    }

    private void save(){
        String t=title.getText().toString().trim();
        if(t.isEmpty()){
            Toast.makeText(this,"عنوان را وارد کن.",Toast.LENGTH_SHORT).show();
            return;
        }

        NexaStore.Reminder r=new NexaStore.Reminder();
        r.title=t;
        String cat=String.valueOf(category.getSelectedItem());
        r.category=cat;
        r.icon=cat.contains(" ")?cat.substring(0,cat.indexOf(' ')):"📅";
        r.note=note.getText().toString().trim();

        if(cat.contains("دکتر")||cat.contains("پزشک")){
            r.doctorName=doctorName.getText().toString().trim();
            r.doctorFileNumber=doctorFile.getText().toString().trim();
            r.doctorCenter=doctorCenter.getText().toString().trim();
            r.doctorPhone=doctorPhone.getText().toString().trim();
            r.doctorAddress=doctorAddress.getText().toString().trim();
        }

        r.whenMillis=PersianDateUtil.toMillis(jy,jm,jd,hour,minute);
        if(r.whenMillis<=System.currentTimeMillis()){
            Toast.makeText(this,"زمان باید در آینده باشد.",Toast.LENGTH_SHORT).show();
            return;
        }

        List<String> offs=new ArrayList<>();
        if(d4.isChecked())offs.add("5760");
        if(d1.isChecked())offs.add("1440");
        if(d0.isChecked())offs.add("0");
        if(offs.isEmpty())offs.add("0");
        r.offsetsMinutes=android.text.TextUtils.join(",",offs);

        int[] mins={5,10,15,30};
        r.repeatMinutes=mins[repeat.getSelectedItemPosition()];

        NexaStore.addReminder(this,r);
        ReminderScheduler.scheduleReminder(this,r);
        NexaStore.addHistory(this,"یادآور","ثبت شد: "+r.title);
        finish();
    }
}
