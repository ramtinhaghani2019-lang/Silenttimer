package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class NexaListActivity extends Activity {
    private LinearLayout shoppingBox;
    private LinearLayout todoBox;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();

        String quick = getIntent().getStringExtra("quick_add");
        if ("shopping".equals(quick)) {
            shoppingBox.postDelayed(this::addShoppingDialog, 250);
        } else if ("todo".equals(quick)) {
            todoBox.postDelayed(this::addTodoDialog, 250);
        }
    }

    private void build() {
        ScrollView sc = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back = UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v -> finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa List"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"خریدها و کارهای روزانه؛ موارد انجام‌شده حذف نمی‌شوند و کم‌رنگ می‌مانند."),UiKit.matchWrap(this,0,14));

        LinearLayout shoppingHead = UiKit.colorfulCardLayout(this,3);
        shoppingHead.addView(UiKit.sectionTitle(this,"🛒 لیست خرید"));
        Button addShopping = UiKit.primaryButton(this,"＋ افزودن قلم خرید");
        addShopping.setOnClickListener(v -> addShoppingDialog());
        shoppingHead.addView(addShopping,UiKit.matchWrap(this,10,8));

        LinearLayout shopActions = new LinearLayout(this);
        shopActions.setOrientation(LinearLayout.HORIZONTAL);

        Button reset = UiKit.secondaryButton(this,"فعال‌کردن دوباره همه");
        reset.setOnClickListener(v -> {
            List<NexaStore.ShoppingItem> items = NexaStore.shoppingItems(this);
            for (NexaStore.ShoppingItem x : items) x.done = false;
            NexaStore.saveShoppingItems(this, items);
            render();
        });
        Button clearDone = UiKit.secondaryButton(this,"پاک‌کردن خریدشده‌ها");
        clearDone.setOnClickListener(v -> {
            List<NexaStore.ShoppingItem> items = NexaStore.shoppingItems(this);
            items.removeIf(x -> x.done);
            NexaStore.saveShoppingItems(this, items);
            render();
        });
        shopActions.addView(reset,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams ac = new LinearLayout.LayoutParams(0,-2,1f);
        ac.setMargins(UiKit.dp(this,6),0,0,0);
        shopActions.addView(clearDone,ac);
        shoppingHead.addView(shopActions);
        root.addView(shoppingHead,UiKit.matchWrap(this,0,12));

        shoppingBox = new LinearLayout(this);
        shoppingBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(shoppingBox,UiKit.matchWrap(this,0,18));

        LinearLayout todoHead = UiKit.colorfulCardLayout(this,1);
        todoHead.addView(UiKit.sectionTitle(this,"✓ To‑Do"));
        Button addTodo = UiKit.primaryButton(this,"＋ کار جدید");
        addTodo.setOnClickListener(v -> addTodoDialog());
        todoHead.addView(addTodo,UiKit.matchWrap(this,10,0));
        root.addView(todoHead,UiKit.matchWrap(this,0,12));

        todoBox = new LinearLayout(this);
        todoBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(todoBox);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addShoppingDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        EditText listName = field("نام لیست؛ مثلاً سوپرمارکت");
        listName.setText("خرید");
        EditText name = field("نام کالا");
        EditText qty = field("مقدار؛ مثلاً ۲ عدد / ۱ کیلو");
        EditText cat = field("دسته؛ مثلاً خوراکی");
        EditText price = field("قیمت تقریبی (اختیاری)");
        price.setInputType(InputType.TYPE_CLASS_NUMBER);
        CheckBox important = new CheckBox(this);
        important.setText("مهم ⭐");

        box.addView(listName);
        box.addView(name);
        box.addView(qty);
        box.addView(cat);
        box.addView(price);
        box.addView(important);

        new AlertDialog.Builder(this)
                .setTitle("قلم خرید جدید")
                .setView(box)
                .setPositiveButton("افزودن",(d,w)->{
                    String n = name.getText().toString().trim();
                    if (n.isEmpty()) return;
                    NexaStore.ShoppingItem x = new NexaStore.ShoppingItem();
                    x.listName = listName.getText().toString().trim().isEmpty() ? "خرید" : listName.getText().toString().trim();
                    x.name = n;
                    x.quantity = qty.getText().toString().trim();
                    x.category = cat.getText().toString().trim();
                    x.important = important.isChecked();
                    try { x.price = Long.parseLong(price.getText().toString().trim()); } catch (Exception ignored) {}
                    NexaStore.addShoppingItem(this,x);
                    NexaStore.addHistory(this,"لیست","افزوده شد: "+x.name);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void addTodoDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        EditText title = field("عنوان کار");
        EditText category = field("دسته؛ مثلاً خانه / کار");
        EditText note = field("توضیحات");
        Button due = UiKit.secondaryButton(this,"بدون تاریخ");
        final long[] dueMillis = {0L};

        due.setOnClickListener(v -> PersianDatePickerHelper.pickDateTime(
                this,
                System.currentTimeMillis()+60L*60L*1000L,
                "موعد انجام",
                ms -> {
                    dueMillis[0] = ms;
                    due.setText(PersianDateUtil.pretty(ms));
                }
        ));

        box.addView(title);
        box.addView(category);
        box.addView(note);
        box.addView(due);

        new AlertDialog.Builder(this)
                .setTitle("کار جدید")
                .setView(box)
                .setPositiveButton("افزودن",(d,w)->{
                    String t = title.getText().toString().trim();
                    if (t.isEmpty()) return;
                    NexaStore.TodoItem x = new NexaStore.TodoItem();
                    x.title = t;
                    x.category = category.getText().toString().trim().isEmpty() ? "عمومی" : category.getText().toString().trim();
                    x.note = note.getText().toString().trim();
                    x.dueMillis = dueMillis[0];
                    NexaStore.addTodo(this,x);
                    NexaStore.addHistory(this,"کار","افزوده شد: "+x.title);
                    if (x.dueMillis > System.currentTimeMillis()) {
                        LinkedReminderHelper.upsert(
                                this,
                                "todo:"+x.id,
                                x.title,
                                "کار",
                                "✓",
                                x.note,
                                x.dueMillis,
                                "60,0",
                                10
                        );
                    }
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if (shoppingBox == null) return;
        shoppingBox.removeAllViews();
        todoBox.removeAllViews();

        List<NexaStore.ShoppingItem> items = NexaStore.shoppingItems(this);
        if (items.isEmpty()) {
            TextView e = UiKit.muted(this,"لیست خرید خالی است.");
            e.setGravity(Gravity.CENTER);
            shoppingBox.addView(e,UiKit.matchWrap(this,8,0));
        } else {
            String lastList = null;
            for (NexaStore.ShoppingItem x : items) {
                if (!x.listName.equals(lastList)) {
                    TextView group = UiKit.sectionTitle(this,"▸ "+x.listName);
                    shoppingBox.addView(group,UiKit.matchWrap(this,8,6));
                    lastList = x.listName;
                }

                LinearLayout c = UiKit.cardLayout(this);
                c.setAlpha(x.done ? 0.48f : 1f);

                TextView t = UiKit.sectionTitle(this,(x.important?"⭐ ":"")+x.name);
                if (x.done) t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                c.addView(t);

                String sub = "";
                if (!x.quantity.isEmpty()) sub += x.quantity;
                if (!x.category.isEmpty()) sub += (sub.isEmpty()?"":" • ")+x.category;
                if (x.price > 0) sub += (sub.isEmpty()?"":" • ")+String.format(java.util.Locale.US,"%,d تومان",x.price);
                if (!sub.isEmpty()) c.addView(UiKit.muted(this,sub),UiKit.matchWrap(this,5,0));

                LinearLayout actions = new LinearLayout(this);
                Button toggle = UiKit.secondaryButton(this,x.done?"برگرداندن":"خریدم ✓");
                toggle.setOnClickListener(v -> {
                    x.done = !x.done;
                    NexaStore.updateShoppingItem(this,x);
                    render();
                });
                Button del = UiKit.secondaryButton(this,"حذف");
                del.setOnClickListener(v -> {
                    NexaStore.removeShoppingItem(this,x.id);
                    render();
                });
                actions.addView(toggle,new LinearLayout.LayoutParams(0,-2,1f));
                LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0,-2,1f);
                dp.setMargins(UiKit.dp(this,6),0,0,0);
                actions.addView(del,dp);
                c.addView(actions,UiKit.matchWrap(this,10,0));

                shoppingBox.addView(c,UiKit.matchWrap(this,0,8));
            }
        }

        List<NexaStore.TodoItem> todos = NexaStore.todos(this);
        if (todos.isEmpty()) {
            TextView e = UiKit.muted(this,"کاری ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            todoBox.addView(e,UiKit.matchWrap(this,8,0));
        } else {
            for (NexaStore.TodoItem x : todos) {
                LinearLayout c = UiKit.colorfulCardLayout(this,1);
                c.setAlpha(x.done ? 0.48f : 1f);

                TextView t = UiKit.sectionTitle(this,x.title);
                if (x.done) t.setPaintFlags(t.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                c.addView(t);

                String sub = x.category;
                if (x.dueMillis > 0) sub += " • "+PersianDateUtil.pretty(x.dueMillis);
                c.addView(UiKit.muted(this,sub),UiKit.matchWrap(this,5,2));
                if (!x.note.isEmpty()) c.addView(UiKit.muted(this,x.note));

                LinearLayout actions = new LinearLayout(this);
                Button toggle = UiKit.secondaryButton(this,x.done?"برگرداندن":"انجام شد ✓");
                toggle.setOnClickListener(v -> {
                    x.done = !x.done;
                    NexaStore.updateTodo(this,x);
                    if (x.done) LinkedReminderHelper.remove(this,"todo:"+x.id);
                    render();
                });
                Button del = UiKit.secondaryButton(this,"حذف");
                del.setOnClickListener(v -> {
                    LinkedReminderHelper.remove(this,"todo:"+x.id);
                    NexaStore.removeTodo(this,x.id);
                    render();
                });
                actions.addView(toggle,new LinearLayout.LayoutParams(0,-2,1f));
                LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(0,-2,1f);
                dp.setMargins(UiKit.dp(this,6),0,0,0);
                actions.addView(del,dp);
                c.addView(actions,UiKit.matchWrap(this,10,0));

                todoBox.addView(c,UiKit.matchWrap(this,0,8));
            }
        }
    }
}
