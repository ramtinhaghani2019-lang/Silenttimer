package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class RemindersActivity extends Activity {
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.secondaryButton(this,"‹");back.setOnClickListener(v->finish());h.addView(back);TextView title=UiKit.title(this,"Nexa Reminder");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1f);tp.setMargins(UiKit.dp(this,12),0,0,0);h.addView(title,tp);root.addView(h,UiKit.matchWrap(this,0,16));LinearLayout hero=UiKit.colorfulCardLayout(this,1);hero.addView(UiKit.sectionTitle(this,"📅 تقویم شمسی + هشدار چندمرحله‌ای"));hero.addView(UiKit.muted(this,"قرار، دکتر، چک، قسط، تولد و هر چیزی که نباید فراموش شود."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ یادآور جدید");add.setOnClickListener(v->startActivity(new Intent(this,ReminderEditActivity.class)));hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Reminder> rs=NexaStore.reminders(this);if(rs.isEmpty()){TextView e=UiKit.muted(this,"هنوز یادآوری ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}for(NexaStore.Reminder r:rs){LinearLayout c=UiKit.colorfulCardLayout(this,Math.abs(r.category.hashCode())%4);TextView t=UiKit.sectionTitle(this,r.icon+"  "+r.title);c.addView(t);c.addView(UiKit.muted(this,r.category+" • "+PersianDateUtil.pretty(r.whenMillis)),UiKit.matchWrap(this,6,3));if(!r.doctorName.isEmpty())c.addView(UiKit.muted(this,"🩺 پزشک: "+r.doctorName),UiKit.matchWrap(this,4,0));
if(!r.doctorFileNumber.isEmpty())c.addView(UiKit.muted(this,"شماره پرونده: "+r.doctorFileNumber),UiKit.matchWrap(this,3,0));
if(!r.doctorCenter.isEmpty())c.addView(UiKit.muted(this,"مرکز: "+r.doctorCenter),UiKit.matchWrap(this,3,0));
if(!r.doctorPhone.isEmpty())c.addView(UiKit.muted(this,"تماس: "+r.doctorPhone),UiKit.matchWrap(this,3,0));
if(!r.doctorAddress.isEmpty())c.addView(UiKit.muted(this,"آدرس: "+r.doctorAddress),UiKit.matchWrap(this,3,0));
if(!r.note.isEmpty())c.addView(UiKit.muted(this,r.note),UiKit.matchWrap(this,4,0));LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);Button del=UiKit.secondaryButton(this,"حذف");del.setOnClickListener(v->{NexaStore.removeReminder(this,r.id);ReminderScheduler.rescheduleAll(this);render();});row.addView(del,new LinearLayout.LayoutParams(0,-2,1f));c.addView(row,UiKit.matchWrap(this,10,0));list.addView(c,UiKit.matchWrap(this,0,12));}}
}
