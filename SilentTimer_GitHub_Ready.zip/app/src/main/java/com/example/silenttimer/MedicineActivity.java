package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;
import java.util.List;

public class MedicineActivity extends Activity {
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);Button back=UiKit.secondaryButton(this,"‹");back.setOnClickListener(v->finish());root.addView(back,UiKit.matchWrap(this,0,12));root.addView(UiKit.title(this,"یادآور دارو"),UiKit.matchWrap(this,0,14));LinearLayout hero=UiKit.colorfulCardLayout(this,2);hero.addView(UiKit.sectionTitle(this,"💊 برنامه مصرف دارو"));hero.addView(UiKit.muted(this,"هر ۴، ۶، ۸ یا ۱۲ ساعت؛ با تأیید خوردم، بعداً یا رد شد."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ داروی جدید");add.setOnClickListener(v->addDialog());hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private EditText f(String h){EditText e=new EditText(this);e.setHint(h);return e;}
    private void addDialog(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(32,8,32,0);EditText name=f("نام دارو");EditText dose=f("مقدار/توضیح؛ مثلاً یک عدد بعد غذا");Spinner interval=new Spinner(this);interval.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"هر ۴ ساعت","هر ۶ ساعت","هر ۸ ساعت","هر ۱۲ ساعت","هر ۲۴ ساعت"}));interval.setSelection(2);EditText days=f("تعداد روز دوره؛ 0 یعنی بدون پایان");days.setInputType(InputType.TYPE_CLASS_NUMBER);Button start=new Button(this);Calendar cal=Calendar.getInstance();final int[] hm={cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE)};start.setText(String.format(java.util.Locale.US,"شروع %02d:%02d",hm[0],hm[1]));start.setOnClickListener(v->new TimePickerDialog(this,(p,h,m)->{hm[0]=h;hm[1]=m;start.setText(String.format(java.util.Locale.US,"شروع %02d:%02d",h,m));},hm[0],hm[1],true).show());box.addView(name);box.addView(dose);box.addView(interval);box.addView(days);box.addView(start);new AlertDialog.Builder(this).setTitle("داروی جدید").setView(box).setPositiveButton("ذخیره",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty())return;int[]hours={4,6,8,12,24};NexaStore.Medicine m=new NexaStore.Medicine();m.name=n;m.dose=dose.getText().toString().trim();m.intervalHours=hours[interval.getSelectedItemPosition()];Calendar s=Calendar.getInstance();s.set(Calendar.HOUR_OF_DAY,hm[0]);s.set(Calendar.MINUTE,hm[1]);s.set(Calendar.SECOND,0);if(s.getTimeInMillis()<=System.currentTimeMillis())s.add(Calendar.DAY_OF_YEAR,1);m.nextDoseMillis=s.getTimeInMillis();int dd=0;try{dd=Integer.parseInt(days.getText().toString());}catch(Exception ignored){}m.endMillis=dd>0?m.nextDoseMillis+dd*24L*60*60*1000:0;NexaStore.addMedicine(this,m);MedicineScheduler.schedule(this,m);NexaStore.addHistory(this,"دارو","دارو اضافه شد: "+m.name);render();}).setNegativeButton("انصراف",null).show();}
    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Medicine> ms=NexaStore.medicines(this);if(ms.isEmpty()){TextView e=UiKit.muted(this,"هنوز دارویی ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}for(NexaStore.Medicine m:ms){LinearLayout c=UiKit.colorfulCardLayout(this,2);c.addView(UiKit.sectionTitle(this,"💊 "+m.name));c.addView(UiKit.muted(this,(m.dose.isEmpty()?"":m.dose+" • ")+"هر "+m.intervalHours+" ساعت"),UiKit.matchWrap(this,5,3));c.addView(UiKit.muted(this,"نوبت بعد: "+PersianDateUtil.pretty(m.nextDoseMillis)));Button del=UiKit.secondaryButton(this,"حذف");del.setOnClickListener(v->{NexaStore.removeMedicine(this,m.id);render();});c.addView(del,UiKit.matchWrap(this,10,0));list.addView(c,UiKit.matchWrap(this,0,12));}}
}
