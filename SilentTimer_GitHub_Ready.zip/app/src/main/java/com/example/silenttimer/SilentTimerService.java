package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.Locale;

public class SilentTimerService extends Service {
    public static final String ACTION_START = "com.example.silenttimer.START";
    public static final String ACTION_STOP = "com.example.silenttimer.STOP";
    public static final String EXTRA_MINUTES = "minutes";
    public static final String EXTRA_EMERGENCY_NUMBER = "emergency_number";

    private static final String CHANNEL_ID = "silent_timer_active";
    private static final int NOTIFICATION_ID = 7001;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private AudioManager audioManager;
    private WindowManager windowManager;
    private TextView bubble;
    private WindowManager.LayoutParams bubbleParams;
    private PowerManager.WakeLock wakeLock;
    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;

    private long endAt;
    private int originalRingerMode;
    private boolean emergencyOverride = false;
    private String emergencyNumber = "";

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            long remaining = endAt - System.currentTimeMillis();
            if (remaining <= 0L) {
                finishTimer();
                return;
            }
            updateBubble(remaining);
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        createChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();

        if (ACTION_STOP.equals(action)) {
            restoreAndStop();
            return START_NOT_STICKY;
        }

        startForeground(NOTIFICATION_ID, buildNotification());

        if (ACTION_START.equals(action) && intent != null) {
            int minutes = Math.max(1, Math.min(180, intent.getIntExtra(EXTRA_MINUTES, 30)));
            emergencyNumber = intent.getStringExtra(EXTRA_EMERGENCY_NUMBER);
            if (emergencyNumber == null) emergencyNumber = "";

            originalRingerMode = audioManager.getRingerMode();
            AppPrefs.setOriginalRingerMode(this, originalRingerMode);
            AppPrefs.setEmergencyNumber(this, emergencyNumber);
            endAt = System.currentTimeMillis() + minutes * 60_000L;
            AppPrefs.setEndAt(this, endAt);
        } else {
            endAt = AppPrefs.getEndAt(this);
            emergencyNumber = AppPrefs.getEmergencyNumber(this);
            originalRingerMode = AppPrefs.getOriginalRingerMode(this, AudioManager.RINGER_MODE_NORMAL);
        }

        if (endAt <= System.currentTimeMillis()) {
            restoreAndStop();
            return START_NOT_STICKY;
        }

        acquireWakeLock();
        setSilentSafely();
        createOrRefreshBubble();
        registerPhoneListener();
        handler.removeCallbacks(ticker);
        handler.post(ticker);

        return START_STICKY;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                this, 10, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent stop = new Intent(this, SilentTimerService.class);
        stop.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(
                this, 11, stop, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);

        return b.setContentTitle("Silent Timer فعال است")
                .setContentText("گوشی تا پایان تایمر بی‌صدا می‌ماند")
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode)
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel,
                        "پایان تایمر",
                        stopPi).build())
                .build();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Silent Timer", NotificationManager.IMPORTANCE_LOW);
            ch.setDescription("نمایش وضعیت تایمر بی‌صدا");
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(ch);
        }
    }

    private void setSilentSafely() {
        if (!emergencyOverride) {
            try {
                audioManager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
            } catch (SecurityException ignored) {
            }
        }
    }

    private void restoreRinger() {
        try {
            audioManager.setRingerMode(originalRingerMode);
        } catch (SecurityException ignored) {
            try {
                audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
            } catch (SecurityException ignoredAgain) {}
        }
    }

    private void createOrRefreshBubble() {
        if (!android.provider.Settings.canDrawOverlays(this)) return;
        if (bubble != null) return;

        bubble = new TextView(this);
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(16f);
        bubble.setGravity(Gravity.CENTER);
        bubble.setPadding(dp(18), dp(14), dp(18), dp(14));

        GradientDrawable bg = new GradientDrawable();
        bg.setShape(GradientDrawable.RECTANGLE);
        bg.setCornerRadius(dp(24));
        bg.setColor(0xE61A1A1A);
        bg.setStroke(dp(1), 0x55FFFFFF);
        bubble.setBackground(bg);
        bubble.setElevation(dp(8));

        bubbleParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );
        bubbleParams.gravity = Gravity.TOP | Gravity.END;
        bubbleParams.x = dp(18);
        bubbleParams.y = dp(120);

        final int[] startX = new int[1];
        final int[] startY = new int[1];
        final float[] downX = new float[1];
        final float[] downY = new float[1];

        bubble.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    startX[0] = bubbleParams.x;
                    startY[0] = bubbleParams.y;
                    downX[0] = event.getRawX();
                    downY[0] = event.getRawY();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    bubbleParams.x = startX[0] + Math.round(downX[0] - event.getRawX());
                    bubbleParams.y = startY[0] + Math.round(event.getRawY() - downY[0]);
                    try {
                        windowManager.updateViewLayout(bubble, bubbleParams);
                    } catch (Exception ignored) {}
                    return true;
                default:
                    return true;
            }
        });

        try {
            windowManager.addView(bubble, bubbleParams);
        } catch (Exception ignored) {
            bubble = null;
        }
    }

    private void updateBubble(long remainingMs) {
        if (bubble == null) return;
        long totalSec = Math.max(0, remainingMs / 1000L);
        long h = totalSec / 3600;
        long m = (totalSec % 3600) / 60;
        long s = totalSec % 60;
        if (h > 0) {
            bubble.setText(String.format(Locale.US, "%02d:%02d:%02d", h, m, s));
        } else {
            bubble.setText(String.format(Locale.US, "%02d:%02d", m, s));
        }
    }

    @SuppressWarnings("deprecation")
    private void registerPhoneListener() {
        if (phoneStateListener != null) return;
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                super.onCallStateChanged(state, incomingNumber);

                if (state == TelephonyManager.CALL_STATE_RINGING) {
                    if (isEmergencyMatch(incomingNumber)) {
                        emergencyOverride = true;
                        try {
                            audioManager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                        } catch (SecurityException ignored) {}
                    }
                } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                    if (emergencyOverride) {
                        emergencyOverride = false;
                        if (System.currentTimeMillis() < endAt) setSilentSafely();
                    }
                }
            }
        };

        try {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (SecurityException ignored) {
        }
    }

    private boolean isEmergencyMatch(String incoming) {
        String wanted = digitsOnly(emergencyNumber);
        String got = digitsOnly(incoming);
        if (wanted.length() < 7 || got.length() < 7) return false;

        int compare = Math.min(10, Math.min(wanted.length(), got.length()));
        return wanted.substring(wanted.length() - compare)
                .equals(got.substring(got.length() - compare));
    }

    private String digitsOnly(String value) {
        if (value == null) return "";
        return value.replaceAll("[^0-9]", "");
    }

    private void acquireWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) return;
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SilentTimer:Countdown");
        wakeLock.acquire(Math.max(60_000L, endAt - System.currentTimeMillis() + 60_000L));
    }

    private void finishTimer() {
        restoreAndStop();
    }

    private void restoreAndStop() {
        handler.removeCallbacks(ticker);
        restoreRinger();
        AppPrefs.clearTimer(this);
        removeBubble();
        unregisterPhoneListener();
        releaseWakeLock();
        stopForeground(true);
        stopSelf();
    }

    @SuppressWarnings("deprecation")
    private void unregisterPhoneListener() {
        if (telephonyManager != null && phoneStateListener != null) {
            try {
                telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
            } catch (Exception ignored) {}
        }
        phoneStateListener = null;
    }

    private void removeBubble() {
        if (bubble != null) {
            try {
                windowManager.removeView(bubble);
            } catch (Exception ignored) {}
            bubble = null;
        }
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            wakeLock.release();
        }
        wakeLock = null;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(ticker);
        removeBubble();
        unregisterPhoneListener();
        releaseWakeLock();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
