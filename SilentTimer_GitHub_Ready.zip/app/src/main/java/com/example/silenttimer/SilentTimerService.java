package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.service.quicksettings.TileService;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class SilentTimerService extends Service {
    public static final String ACTION_MONITOR = "com.example.silenttimer.MONITOR";
    public static final String ACTION_START = "com.example.silenttimer.START";
    public static final String ACTION_STOP = "com.example.silenttimer.STOP";
    public static final String ACTION_ADD_15 = "com.example.silenttimer.ADD_15";
    public static final String ACTION_TOGGLE_ALLOWED = "com.example.silenttimer.TOGGLE_ALLOWED";
    public static final String ACTION_REFRESH = "com.example.silenttimer.REFRESH";

    public static final String EXTRA_MINUTES = "minutes";
    public static final String EXTRA_RESTORE_MODE = "restore_mode";

    private static final String CHANNEL_ID = "silent_timer_status_v2";
    private static final int NOTIFICATION_ID = 7001;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private AudioManager audioManager;
    private WindowManager windowManager;
    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private PowerManager.WakeLock wakeLock;

    private TextView timerBubble;
    private WindowManager.LayoutParams bubbleParams;

    private LinearLayout manualPrompt;
    private WindowManager.LayoutParams promptParams;
    private TextView promptTime;
    private int promptMinutes = 30;

    private long endAt = 0L;
    private int originalRingerMode = AudioManager.RINGER_MODE_NORMAL;
    private long ignoreRingerChangesUntil = 0L;

    private boolean emergencyOverride = false;
    private int preEmergencyMode = AudioManager.RINGER_MODE_SILENT;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            if (!timerActive()) return;

            long remaining = endAt - System.currentTimeMillis();
            if (remaining <= 0L) {
                finishTimer(true);
                return;
            }

            updateBubble(remaining);
            updateNotification();
            handler.postDelayed(this, 1000L);
        }
    };

    private final BroadcastReceiver ringerReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!AudioManager.RINGER_MODE_CHANGED_ACTION.equals(intent.getAction())) return;

            int mode = intent.getIntExtra(
                    AudioManager.EXTRA_RINGER_MODE,
                    audioManager == null ? AudioManager.RINGER_MODE_NORMAL : audioManager.getRingerMode()
            );

            if (System.currentTimeMillis() < ignoreRingerChangesUntil) return;
            if (emergencyOverride) return;

            if (timerActive()) {
                if (mode != AudioManager.RINGER_MODE_SILENT) {
                    cancelTimerBecauseUserChangedMode();
                }
                return;
            }

            if (mode == AudioManager.RINGER_MODE_SILENT && AppPrefs.isMonitoringEnabled(SilentTimerService.this)) {
                showManualSilentPrompt();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();

        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        telephonyManager = (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        createChannel();
        startForeground(NOTIFICATION_ID, buildNotification());
        registerRingerReceiver();
        registerPhoneListener();

        restoreTimerState();
        if (timerActive()) {
            acquireWakeLock();
            createOrRefreshTimerBubble();
            handler.post(ticker);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_MONITOR : intent.getAction();
        if (action == null) action = ACTION_MONITOR;

        switch (action) {
            case ACTION_START:
                int minutes = intent == null ? 30 : intent.getIntExtra(EXTRA_MINUTES, 30);
                int requestedRestoreMode = intent == null
                        ? Integer.MIN_VALUE
                        : intent.getIntExtra(EXTRA_RESTORE_MODE, Integer.MIN_VALUE);
                startTimer(minutes, requestedRestoreMode);
                break;

            case ACTION_STOP:
                finishTimer(true);
                break;

            case ACTION_ADD_15:
                extendTimer(15);
                break;

            case ACTION_TOGGLE_ALLOWED:
                AppPrefs.setAllowedCallsEnabled(
                        this,
                        !AppPrefs.isAllowedCallsEnabled(this)
                );
                updateNotification();
                break;

            case ACTION_REFRESH:
                updateNotification();
                break;

            case ACTION_MONITOR:
            default:
                restoreTimerState();
                if (timerActive()) {
                    createOrRefreshTimerBubble();
                    handler.removeCallbacks(ticker);
                    handler.post(ticker);
                }
                updateNotification();
                break;
        }

        requestTileRefresh();
        return START_STICKY;
    }

    private void startTimer(int minutes, int requestedRestoreMode) {
        removeManualPrompt();

        minutes = Math.max(15, Math.min(720, ((minutes + 14) / 15) * 15));
        int current = audioManager.getRingerMode();

        if (requestedRestoreMode == AudioManager.RINGER_MODE_NORMAL ||
                requestedRestoreMode == AudioManager.RINGER_MODE_VIBRATE ||
                requestedRestoreMode == AudioManager.RINGER_MODE_SILENT) {
            originalRingerMode = requestedRestoreMode;
        } else if (current == AudioManager.RINGER_MODE_SILENT) {
            // If the user was already in Silent, a timed silence should end in Normal.
            originalRingerMode = AudioManager.RINGER_MODE_NORMAL;
        } else {
            originalRingerMode = current;
        }

        endAt = System.currentTimeMillis() + minutes * 60_000L;
        AppPrefs.setMinutes(this, minutes);
        AppPrefs.setOriginalRingerMode(this, originalRingerMode);
        AppPrefs.setEndAt(this, endAt);

        setRingerModeInternal(AudioManager.RINGER_MODE_SILENT);
        acquireWakeLock();
        createOrRefreshTimerBubble();

        handler.removeCallbacks(ticker);
        handler.post(ticker);
        updateNotification();
        requestTileRefresh();
    }

    private void extendTimer(int minutes) {
        if (!timerActive()) return;

        long candidate = endAt + minutes * 60_000L;
        long max = System.currentTimeMillis() + 12L * 60L * 60L * 1000L;
        endAt = Math.min(candidate, max);
        AppPrefs.setEndAt(this, endAt);

        acquireWakeLock();
        updateBubble(endAt - System.currentTimeMillis());
        updateNotification();
    }

    private void finishTimer(boolean restoreSound) {
        if (!timerActive() && AppPrefs.getEndAt(this) <= 0L) {
            updateNotification();
            return;
        }

        handler.removeCallbacks(ticker);

        if (restoreSound) {
            setRingerModeInternal(originalRingerMode);
        }

        AppPrefs.clearTimer(this);
        endAt = 0L;
        removeTimerBubble();
        releaseWakeLock();
        updateNotification();
        requestTileRefresh();
    }

    private void cancelTimerBecauseUserChangedMode() {
        handler.removeCallbacks(ticker);
        AppPrefs.clearTimer(this);
        endAt = 0L;
        removeTimerBubble();
        releaseWakeLock();
        updateNotification();
        requestTileRefresh();

        Toast.makeText(
                this,
                "تایمر لغو شد؛ تغییر دستی حالت صدا تشخیص داده شد.",
                Toast.LENGTH_SHORT
        ).show();
    }

    private void restoreTimerState() {
        endAt = AppPrefs.getEndAt(this);
        originalRingerMode = AppPrefs.getOriginalRingerMode(
                this,
                AudioManager.RINGER_MODE_NORMAL
        );

        if (endAt > 0L && endAt <= System.currentTimeMillis()) {
            setRingerModeInternal(originalRingerMode);
            AppPrefs.clearTimer(this);
            endAt = 0L;
        }
    }

    private boolean timerActive() {
        return endAt > System.currentTimeMillis();
    }

    private void setRingerModeInternal(int mode) {
        try {
            ignoreRingerChangesUntil = System.currentTimeMillis() + 3000L;
            audioManager.setRingerMode(mode);
        } catch (SecurityException ignored) {
        }
    }

    private void registerRingerReceiver() {
        IntentFilter filter = new IntentFilter(AudioManager.RINGER_MODE_CHANGED_ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(ringerReceiver, filter, Context.RECEIVER_EXPORTED);
        } else {
            registerReceiver(ringerReceiver, filter);
        }
    }

    @SuppressWarnings("deprecation")
    private void registerPhoneListener() {
        if (phoneStateListener != null) return;

        phoneStateListener = new PhoneStateListener() {
            @Override
            public void onCallStateChanged(int state, String incomingNumber) {
                super.onCallStateChanged(state, incomingNumber);

                if (state == TelephonyManager.CALL_STATE_RINGING) {
                    if (AppPrefs.isAllowedNumber(SilentTimerService.this, incomingNumber)) {
                        int currentMode = audioManager.getRingerMode();
                        if (timerActive() || currentMode == AudioManager.RINGER_MODE_SILENT) {
                            emergencyOverride = true;
                            preEmergencyMode = currentMode;
                            setRingerModeInternal(AudioManager.RINGER_MODE_NORMAL);
                        }
                    }
                } else if (state == TelephonyManager.CALL_STATE_IDLE) {
                    if (emergencyOverride) {
                        emergencyOverride = false;
                        if (timerActive()) {
                            setRingerModeInternal(AudioManager.RINGER_MODE_SILENT);
                        } else {
                            setRingerModeInternal(preEmergencyMode);
                        }
                    }
                }
            }
        };

        try {
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);
        } catch (SecurityException ignored) {
        }
    }

    private void showManualSilentPrompt() {
        if (!Settings.canDrawOverlays(this)) return;
        if (manualPrompt != null) return;
        if (timerActive()) return;

        promptMinutes = 30;

        manualPrompt = new LinearLayout(this);
        manualPrompt.setOrientation(LinearLayout.VERTICAL);
        manualPrompt.setPadding(dp(18), dp(16), dp(18), dp(16));
        manualPrompt.setGravity(Gravity.CENTER);

        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xF21A1722);
        bg.setCornerRadius(dp(24));
        bg.setStroke(dp(1), 0x558B5CF6);
        manualPrompt.setBackground(bg);
        manualPrompt.setElevation(dp(10));

        TextView title = new TextView(this);
        title.setText("تا چه مدت Silent بماند؟");
        title.setTextColor(Color.WHITE);
        title.setTextSize(16f);
        title.setGravity(Gravity.CENTER);
        manualPrompt.addView(title, matchWrap());

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(0, dp(12), 0, dp(12));
        manualPrompt.addView(controls, matchWrap());

        Button minus = smallButton("−15");
        controls.addView(minus, fixedButtonParams(72));

        promptTime = new TextView(this);
        promptTime.setTextColor(Color.WHITE);
        promptTime.setTextSize(24f);
        promptTime.setGravity(Gravity.CENTER);
        promptTime.setText(formatPromptMinutes(promptMinutes));
        LinearLayout.LayoutParams timeParams = new LinearLayout.LayoutParams(dp(130), dp(52));
        controls.addView(promptTime, timeParams);

        Button plus = smallButton("+15");
        controls.addView(plus, fixedButtonParams(72));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        manualPrompt.addView(actions, matchWrap());

        Button later = smallButton("فعلاً نه");
        Button confirm = smallButton("فعال کن");
        LinearLayout.LayoutParams actionP = new LinearLayout.LayoutParams(0, dp(50), 1f);
        actionP.setMargins(dp(4), 0, dp(4), 0);
        actions.addView(later, actionP);
        actions.addView(confirm, actionP);

        minus.setOnClickListener(v -> {
            promptMinutes = Math.max(15, promptMinutes - 15);
            promptTime.setText(formatPromptMinutes(promptMinutes));
        });

        plus.setOnClickListener(v -> {
            promptMinutes = Math.min(720, promptMinutes + 15);
            promptTime.setText(formatPromptMinutes(promptMinutes));
        });

        later.setOnClickListener(v -> removeManualPrompt());

        confirm.setOnClickListener(v -> {
            int selected = promptMinutes;
            removeManualPrompt();
            startTimer(selected, AudioManager.RINGER_MODE_NORMAL);
        });

        promptParams = new WindowManager.LayoutParams(
                dp(330),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
        );
        promptParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        promptParams.y = dp(110);

        try {
            windowManager.addView(manualPrompt, promptParams);
        } catch (Exception ignored) {
            manualPrompt = null;
        }
    }

    private String formatPromptMinutes(int minutes) {
        if (minutes < 60) return minutes + " دقیقه";
        int h = minutes / 60;
        int m = minutes % 60;
        if (m == 0) return h + " ساعت";
        return h + ":" + String.format(Locale.US, "%02d", m);
    }

    private Button smallButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14f);
        b.setAllCaps(false);
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF30263F);
        g.setCornerRadius(dp(14));
        b.setBackground(g);
        return b;
    }

    private LinearLayout.LayoutParams fixedButtonParams(int widthDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(widthDp), dp(50));
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private void removeManualPrompt() {
        if (manualPrompt != null) {
            try {
                windowManager.removeView(manualPrompt);
            } catch (Exception ignored) {
            }
            manualPrompt = null;
            promptTime = null;
        }
    }

    private void createOrRefreshTimerBubble() {
        if (!Settings.canDrawOverlays(this)) return;

        if (timerBubble == null) {
            timerBubble = new TextView(this);
            timerBubble.setTextColor(Color.WHITE);
            timerBubble.setTextSize(16f);
            timerBubble.setGravity(Gravity.CENTER);
            timerBubble.setPadding(dp(18), dp(14), dp(18), dp(14));

            GradientDrawable bg = new GradientDrawable();
            bg.setCornerRadius(dp(24));
            bg.setColor(0xED17141F);
            bg.setStroke(dp(1), 0x668B5CF6);
            timerBubble.setBackground(bg);
            timerBubble.setElevation(dp(8));

            bubbleParams = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
            );
            bubbleParams.gravity = Gravity.TOP | Gravity.END;
            bubbleParams.x = dp(18);
            bubbleParams.y = dp(120);

            final int[] startX = new int[1];
            final int[] startY = new int[1];
            final float[] downX = new float[1];
            final float[] downY = new float[1];

            timerBubble.setOnTouchListener((v, event) -> {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        startX[0] = bubbleParams.x;
                        startY[0] = bubbleParams.y;
                        downX[0] = event.getRawX();
                        downY[0] = event.getRawY();
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        bubbleParams.x = startX[0] + Math.round(downX[0] - event.getRawX());
                        bubbleParams.y = startY[0] + Math.round(event.getRawY() - downY[0]);
                        try {
                            windowManager.updateViewLayout(timerBubble, bubbleParams);
                        } catch (Exception ignored) {
                        }
                        return true;

                    default:
                        return true;
                }
            });

            try {
                windowManager.addView(timerBubble, bubbleParams);
            } catch (Exception ignored) {
                timerBubble = null;
            }
        }

        if (timerBubble != null) {
            updateBubble(Math.max(0L, endAt - System.currentTimeMillis()));
        }
    }

    private void updateBubble(long remainingMs) {
        if (timerBubble == null) return;

        long totalSec = Math.max(0L, remainingMs / 1000L);
        long h = totalSec / 3600L;
        long m = (totalSec % 3600L) / 60L;
        long s = totalSec % 60L;

        if (h > 0L) {
            timerBubble.setText(String.format(Locale.US, "%02d:%02d:%02d", h, m, s));
        } else {
            timerBubble.setText(String.format(Locale.US, "%02d:%02d", m, s));
        }
    }

    private void removeTimerBubble() {
        if (timerBubble != null) {
            try {
                windowManager.removeView(timerBubble);
            } catch (Exception ignored) {
            }
            timerBubble = null;
        }
    }

    private void acquireWakeLock() {
        releaseWakeLock();

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "SilentTimer:ActiveCountdown");

        long duration = Math.max(
                60_000L,
                endAt - System.currentTimeMillis() + 60_000L
        );
        wakeLock.acquire(duration);
    }

    private void releaseWakeLock() {
        if (wakeLock != null && wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {
            }
        }
        wakeLock = null;
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                this,
                10,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setContentIntent(openPi)
                .setCategory(Notification.CATEGORY_SERVICE);

        boolean active = timerActive();
        boolean allowed = AppPrefs.isAllowedCallsEnabled(this);

        if (active) {
            long remaining = Math.max(0L, endAt - System.currentTimeMillis());
            builder.setContentTitle("Silent Timer فعال است")
                    .setContentText("زمان باقی‌مانده: " + formatRemainingShort(remaining));

            builder.addAction(actionFor(
                    android.R.drawable.ic_input_add,
                    "+15 دقیقه",
                    ACTION_ADD_15,
                    20
            ));
            builder.addAction(actionFor(
                    android.R.drawable.ic_menu_close_clear_cancel,
                    "پایان الان",
                    ACTION_STOP,
                    21
            ));
            builder.addAction(actionFor(
                    android.R.drawable.ic_menu_call,
                    allowed ? "تماس‌های مجاز: روشن" : "تماس‌های مجاز: خاموش",
                    ACTION_TOGGLE_ALLOWED,
                    22
            ));
        } else {
            builder.setContentTitle("Silent Timer آماده است")
                    .setContentText(
                            allowed
                                    ? "تشخیص Silent دستی و تماس‌های مجاز فعال است"
                                    : "تشخیص Silent دستی فعال است"
                    );

            builder.addAction(actionFor(
                    android.R.drawable.ic_menu_call,
                    allowed ? "تماس‌های مجاز: روشن" : "تماس‌های مجاز: خاموش",
                    ACTION_TOGGLE_ALLOWED,
                    23
            ));
        }

        return builder.build();
    }

    private Notification.Action actionFor(int icon, String title, String action, int requestCode) {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(action);

        PendingIntent pi = PendingIntent.getService(
                this,
                requestCode,
                i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        return new Notification.Action.Builder(icon, title, pi).build();
    }

    private void updateNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(NOTIFICATION_ID, buildNotification());
    }

    private String formatRemainingShort(long remainingMs) {
        long totalMin = Math.max(1L, (remainingMs + 59_999L) / 60_000L);
        if (totalMin < 60L) return totalMin + " دقیقه";
        long h = totalMin / 60L;
        long m = totalMin % 60L;
        if (m == 0L) return h + " ساعت";
        return h + " ساعت و " + m + " دقیقه";
    }

    private void createChannel() {
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,
                "Silent Timer",
                NotificationManager.IMPORTANCE_LOW
        );
        channel.setDescription("پایش حالت Silent و نمایش وضعیت تایمر");
        channel.setSound(null, null);
        channel.enableVibration(false);

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(channel);
    }

    private void requestTileRefresh() {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                TileService.requestListeningState(
                        this,
                        new ComponentName(this, SilentTimerTileService.class)
                );
            } catch (Exception ignored) {
            }
        }
    }

    @SuppressWarnings("deprecation")
    private void unregisterPhoneListener() {
        if (telephonyManager != null && phoneStateListener != null) {
            try {
                telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
            } catch (Exception ignored) {
            }
        }
        phoneStateListener = null;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(ticker);
        removeManualPrompt();
        removeTimerBubble();
        releaseWakeLock();

        try {
            unregisterReceiver(ringerReceiver);
        } catch (Exception ignored) {
        }

        unregisterPhoneListener();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
