package com.example.silenttimer;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.service.quicksettings.TileService;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class SilentTimerService extends Service {

    public static final String ACTION_MONITOR =
            "com.example.silenttimer.MONITOR";
    public static final String ACTION_START =
            "com.example.silenttimer.START";
    public static final String ACTION_STOP =
            "com.example.silenttimer.STOP";
    public static final String ACTION_ADD_5 =
            "com.example.silenttimer.ADD_5";
    public static final String ACTION_TOGGLE_ALLOWED =
            "com.example.silenttimer.TOGGLE_ALLOWED";
    public static final String ACTION_REFRESH =
            "com.example.silenttimer.REFRESH";
    public static final String ACTION_EXPIRE =
            "com.example.silenttimer.EXPIRE";

    public static final String EXTRA_MINUTES = "minutes";
    public static final String EXTRA_END_AT = "end_at";
    public static final String EXTRA_TARGET_MODE = "target_mode";

    private static final String CHANNEL_ID = "silent_timer_status_v3";
    private static final int NOTIFICATION_ID = 7001;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private AudioManager audioManager;
    private WindowManager windowManager;
    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private PowerManager.WakeLock wakeLock;

    private TextView timerBubble;
    private WindowManager.LayoutParams bubbleParams;
    private boolean bubbleCollapsed = false;
    private float bubbleDownX;
    private float bubbleDownY;
    private int bubbleStartX;
    private int bubbleStartY;

    private LinearLayout manualPrompt;
    private WindowManager.LayoutParams promptParams;
    private TextView promptTime;
    private TextView promptModeLabel;
    private int promptMinutes = 30;
    private int promptMode = AudioManager.RINGER_MODE_SILENT;

    private long endAt = 0L;
    private int originalRingerMode = AudioManager.RINGER_MODE_NORMAL;
    private int targetRingerMode = AudioManager.RINGER_MODE_SILENT;
    private long ignoreRingerChangesUntil = 0L;

    private boolean emergencyOverride = false;
    private int preEmergencyMode = AudioManager.RINGER_MODE_SILENT;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            // IMPORTANT:
            // Do not call timerActive() before checking expiry. At the exact
            // expiry moment timerActive() becomes false, which previously
            // caused the runnable to return before restoring sound/removing
            // the overlay.
            if (endAt <= 0L) return;

            long remaining = endAt - System.currentTimeMillis();

            if (remaining <= 0L) {
                finishTimer(true);
                return;
            }

            updateBubble(remaining);
            updateNotification();
            handler.postDelayed(this, 1000L);
        }
    };

    private final BroadcastReceiver ringerReceiver =
            new BroadcastReceiver() {
                @Override
                public void onReceive(
                        Context context,
                        Intent intent
                ) {
                    if (!AudioManager.RINGER_MODE_CHANGED_ACTION
                            .equals(intent.getAction())) {
                        return;
                    }

                    int mode = intent.getIntExtra(
                            AudioManager.EXTRA_RINGER_MODE,
                            audioManager == null
                                    ? AudioManager.RINGER_MODE_NORMAL
                                    : audioManager.getRingerMode()
                    );

                    if (System.currentTimeMillis()
                            < ignoreRingerChangesUntil) {
                        return;
                    }

                    if (emergencyOverride) return;

                    if (timerActive()) {
                        if (mode != targetRingerMode) {
                            cancelTimerWithoutRestoring();

                            if (mode == AudioManager.RINGER_MODE_SILENT ||
                                    mode == AudioManager.RINGER_MODE_VIBRATE) {
                                showManualModePrompt(mode);
                            }
                        }
                        return;
                    }

                    if (!AppPrefs.isMonitoringEnabled(
                            SilentTimerService.this
                    )) {
                        return;
                    }

                    if (mode == AudioManager.RINGER_MODE_SILENT ||
                            mode == AudioManager.RINGER_MODE_VIBRATE) {
                        AppPrefs.setLastManualMode(
                                SilentTimerService.this,
                                mode
                        );

                        showManualModePrompt(mode);
                    } else {
                        removeManualPrompt();
                    }
                }
            };

    @Override
    public void onCreate() {
        super.onCreate();

        audioManager =
                (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        windowManager =
                (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        telephonyManager =
                (TelephonyManager) getSystemService(Context.TELEPHONY_SERVICE);

        createChannel();
        startForeground(
                NOTIFICATION_ID,
                buildNotification()
        );

        registerRingerReceiver();
        registerPhoneListener();

        restoreTimerState();

        if (timerActive()) {
            acquireWakeLock();
            createOrRefreshTimerBubble();
            handler.post(ticker);
        }
    }

    @Override
    public int onStartCommand(
            Intent intent,
            int flags,
            int startId
    ) {
        String action =
                intent == null ? ACTION_MONITOR : intent.getAction();

        if (action == null) action = ACTION_MONITOR;

        switch (action) {
            case ACTION_START:
                handleStart(intent);
                break;

            case ACTION_STOP:
                finishTimer(true);
                break;

            case ACTION_ADD_5:
                extendTimer(5);
                break;

            case ACTION_TOGGLE_ALLOWED:
                AppPrefs.setAllowedCallsEnabled(
                        this,
                        !AppPrefs.isAllowedCallsEnabled(this)
                );
                updateNotification();
                break;

            case ACTION_REFRESH:
                updateNotification();
                break;

            case ACTION_EXPIRE:
                // Backup expiry path from AlarmManager.
                if (endAt <= 0L) {
                    restoreTimerState();
                }
                if (endAt > 0L &&
                        System.currentTimeMillis() >= endAt - 1500L) {
                    finishTimer(true);
                } else if (endAt > System.currentTimeMillis()) {
                    scheduleEndAlarm();
                }
                break;

            case ACTION_MONITOR:
            default:
                restoreTimerState();

                if (timerActive()) {
                    createOrRefreshTimerBubble();
                    handler.removeCallbacks(ticker);
                    handler.post(ticker);
                }

                updateNotification();
                break;
        }

        requestTileRefresh();
        return START_STICKY;
    }

    private void handleStart(Intent intent) {
        int minutes =
                intent == null
                        ? AppPrefs.getMinutes(this)
                        : intent.getIntExtra(
                                EXTRA_MINUTES,
                                AppPrefs.getMinutes(this)
                        );

        long requestedEndAt =
                intent == null
                        ? 0L
                        : intent.getLongExtra(EXTRA_END_AT, 0L);

        int requestedMode =
                intent == null
                        ? AudioManager.RINGER_MODE_SILENT
                        : intent.getIntExtra(
                                EXTRA_TARGET_MODE,
                                AudioManager.RINGER_MODE_SILENT
                        );

        if (requestedMode != AudioManager.RINGER_MODE_SILENT &&
                requestedMode != AudioManager.RINGER_MODE_VIBRATE) {
            requestedMode = AudioManager.RINGER_MODE_SILENT;
        }

        startTimer(
                minutes,
                requestedEndAt,
                requestedMode
        );
    }

    private void startTimer(
            int minutes,
            long requestedEndAt,
            int requestedMode
    ) {
        removeManualPrompt();

        int current = audioManager.getRingerMode();

        originalRingerMode =
                (current == AudioManager.RINGER_MODE_NORMAL)
                        ? AudioManager.RINGER_MODE_NORMAL
                        : AudioManager.RINGER_MODE_NORMAL;

        targetRingerMode = requestedMode;

        if (requestedEndAt > System.currentTimeMillis()) {
            endAt = requestedEndAt;
        } else {
            minutes = Math.max(
                    5,
                    Math.min(720, ((minutes + 4) / 5) * 5)
            );

            endAt =
                    System.currentTimeMillis() +
                            minutes * 60_000L;

            AppPrefs.setMinutes(this, minutes);
        }

        AppPrefs.setOriginalRingerMode(
                this,
                originalRingerMode
        );

        AppPrefs.setTargetRingerMode(
                this,
                targetRingerMode
        );

        AppPrefs.setEndAt(this, endAt);

        setRingerModeInternal(targetRingerMode);

        scheduleEndAlarm();
        acquireWakeLock();
        createOrRefreshTimerBubble();

        handler.removeCallbacks(ticker);
        handler.post(ticker);

        updateNotification();
        requestTileRefresh();
    }

    private void extendTimer(int minutes) {
        if (!timerActive()) return;

        long candidate =
                endAt + minutes * 60_000L;

        long max =
                System.currentTimeMillis() +
                        12L * 60L * 60L * 1000L;

        endAt = Math.min(candidate, max);
        AppPrefs.setEndAt(this, endAt);

        scheduleEndAlarm();
        acquireWakeLock();
        updateBubble(
                endAt - System.currentTimeMillis()
        );
        updateNotification();
    }

    private void finishTimer(boolean restoreSound) {
        handler.removeCallbacks(ticker);

        boolean hadTimer =
                timerActive() || AppPrefs.getEndAt(this) > 0L;

        if (hadTimer && restoreSound) {
            setRingerModeInternal(
                    AudioManager.RINGER_MODE_NORMAL
            );
        }

        cancelEndAlarm();
        cancelEndAlarm();
        AppPrefs.clearTimer(this);
        endAt = 0L;

        removeTimerBubble();
        releaseWakeLock();

        updateNotification();
        requestTileRefresh();
    }

    private void cancelTimerWithoutRestoring() {
        handler.removeCallbacks(ticker);

        AppPrefs.clearTimer(this);
        endAt = 0L;

        removeTimerBubble();
        releaseWakeLock();

        updateNotification();
        requestTileRefresh();
    }

    private void restoreTimerState() {
        endAt = AppPrefs.getEndAt(this);

        originalRingerMode = AppPrefs.getOriginalRingerMode(
                this,
                AudioManager.RINGER_MODE_NORMAL
        );

        targetRingerMode = AppPrefs.getTargetRingerMode(this);

        if (endAt > 0L &&
                endAt <= System.currentTimeMillis()) {
            setRingerModeInternal(
                    AudioManager.RINGER_MODE_NORMAL
            );

            cancelEndAlarm();
            AppPrefs.clearTimer(this);
            endAt = 0L;
        } else if (endAt > System.currentTimeMillis()) {
            scheduleEndAlarm();
        }
    }

    private boolean timerActive() {
        return endAt > System.currentTimeMillis();
    }

    private void setRingerModeInternal(int mode) {
        try {
            ignoreRingerChangesUntil =
                    System.currentTimeMillis() + 2500L;

            audioManager.setRingerMode(mode);
        } catch (SecurityException ignored) {}
    }

    private PendingIntent timerEndPendingIntent() {
        Intent i = new Intent(this, TimerEndReceiver.class);

        return PendingIntent.getBroadcast(
                this,
                9001,
                i,
                PendingIntent.FLAG_UPDATE_CURRENT |
                        PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void scheduleEndAlarm() {
        if (endAt <= System.currentTimeMillis()) return;

        AlarmManager am =
                (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        PendingIntent pi = timerEndPendingIntent();

        try {
            if (Build.VERSION.SDK_INT >= 31) {
                if (am.canScheduleExactAlarms()) {
                    am.setExactAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            endAt,
                            pi
                    );
                } else {
                    // No special "Alarms & reminders" access: still keep a
                    // system wake-up backup. The foreground service/wakelock
                    // remains the primary precise path.
                    am.setAndAllowWhileIdle(
                            AlarmManager.RTC_WAKEUP,
                            endAt,
                            pi
                    );
                }
            } else if (Build.VERSION.SDK_INT >= 23) {
                am.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        endAt,
                        pi
                );
            } else {
                am.setExact(
                        AlarmManager.RTC_WAKEUP,
                        endAt,
                        pi
                );
            }
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        endAt,
                        pi
                );
            } else {
                am.set(
                        AlarmManager.RTC_WAKEUP,
                        endAt,
                        pi
                );
            }
        }
    }

    private void cancelEndAlarm() {
        try {
            AlarmManager am =
                    (AlarmManager) getSystemService(Context.ALARM_SERVICE);

            am.cancel(timerEndPendingIntent());
        } catch (Exception ignored) {}
    }

    private void registerRingerReceiver() {
        IntentFilter filter =
                new IntentFilter(
                        AudioManager.RINGER_MODE_CHANGED_ACTION
                );

        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(
                    ringerReceiver,
                    filter,
                    Context.RECEIVER_EXPORTED
            );
        } else {
            registerReceiver(ringerReceiver, filter);
        }
    }

    @SuppressWarnings("deprecation")
    private void registerPhoneListener() {
        if (phoneStateListener != null) return;

        phoneStateListener =
                new PhoneStateListener() {
                    @Override
                    public void onCallStateChanged(
                            int state,
                            String incomingNumber
                    ) {
                        super.onCallStateChanged(
                                state,
                                incomingNumber
                        );

                        if (state ==
                                TelephonyManager.CALL_STATE_RINGING) {

                            if (AppPrefs.isAllowedNumber(
                                    SilentTimerService.this,
                                    incomingNumber
                            )) {
                                int currentMode =
                                        audioManager.getRingerMode();

                                if (currentMode ==
                                        AudioManager.RINGER_MODE_SILENT ||
                                        currentMode ==
                                                AudioManager.RINGER_MODE_VIBRATE ||
                                        timerActive()) {

                                    emergencyOverride = true;
                                    preEmergencyMode = currentMode;

                                    setRingerModeInternal(
                                            AudioManager.RINGER_MODE_NORMAL
                                    );
                                }
                            }
                        } else if (state ==
                                TelephonyManager.CALL_STATE_IDLE) {

                            if (emergencyOverride) {
                                emergencyOverride = false;

                                if (timerActive()) {
                                    setRingerModeInternal(
                                            targetRingerMode
                                    );
                                } else {
                                    setRingerModeInternal(
                                            preEmergencyMode
                                    );
                                }
                            }
                        }
                    }
                };

        try {
            telephonyManager.listen(
                    phoneStateListener,
                    PhoneStateListener.LISTEN_CALL_STATE
            );
        } catch (SecurityException ignored) {}
    }

    private void showManualModePrompt(int mode) {
        if (!Settings.canDrawOverlays(this)) return;
        if (!AppPrefs.isMonitoringEnabled(this)) return;

        removeManualPrompt();

        promptMode = mode;
        promptMinutes = 30;

        manualPrompt = new LinearLayout(this);
        manualPrompt.setOrientation(
                LinearLayout.VERTICAL
        );
        manualPrompt.setPadding(
                dp(18),
                dp(16),
                dp(18),
                dp(16)
        );

        GradientDrawable bg =
                new GradientDrawable();

        bg.setColor(0xF51B1B20);
        bg.setCornerRadius(dp(26));
        bg.setStroke(dp(1), 0x558B5CF6);

        manualPrompt.setBackground(bg);
        manualPrompt.setElevation(dp(12));

        promptModeLabel = new TextView(this);
        promptModeLabel.setTextColor(Color.WHITE);
        promptModeLabel.setTextSize(16f);
        promptModeLabel.setGravity(Gravity.CENTER);
        promptModeLabel.setText(
                mode == AudioManager.RINGER_MODE_VIBRATE
                        ? "Vibrate فعال شد"
                        : "Silent فعال شد"
        );
        manualPrompt.addView(
                promptModeLabel,
                new LinearLayout.LayoutParams(
                        dp(290),
                        LinearLayout.LayoutParams.WRAP_CONTENT
                )
        );

        TextView hint = new TextView(this);
        hint.setText(
                "چه زمانی دوباره صدا روشن شود؟"
        );
        hint.setTextColor(0xFFB8B8C5);
        hint.setTextSize(13f);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(5), 0, dp(10));
        manualPrompt.addView(hint);

        promptTime = new TextView(this);
        promptTime.setTextColor(Color.WHITE);
        promptTime.setTextSize(30f);
        promptTime.setGravity(Gravity.CENTER);
        promptTime.setPadding(0, 0, 0, dp(10));
        manualPrompt.addView(promptTime);

        LinearLayout stepRow =
                new LinearLayout(this);

        stepRow.setOrientation(
                LinearLayout.HORIZONTAL
        );
        stepRow.setGravity(Gravity.CENTER);

        manualPrompt.addView(stepRow);

        Button minus =
                overlayButton("− 5");
        Button plus =
                overlayButton("+ 5");

        stepRow.addView(minus);
        stepRow.addView(plus);

        minus.setOnClickListener(v -> {
            promptMinutes =
                    Math.max(5, promptMinutes - 5);
            updatePromptTime();
        });

        plus.setOnClickListener(v -> {
            promptMinutes =
                    Math.min(720, promptMinutes + 5);
            updatePromptTime();
        });

        LinearLayout presets1 =
                new LinearLayout(this);

        presets1.setOrientation(
                LinearLayout.HORIZONTAL
        );
        presets1.setGravity(Gravity.CENTER);

        presets1.setPadding(
                0,
                dp(8),
                0,
                0
        );

        manualPrompt.addView(presets1);

        addPromptPreset(presets1, 5);
        addPromptPreset(presets1, 10);
        addPromptPreset(presets1, 15);
        addPromptPreset(presets1, 30);

        LinearLayout presets2 =
                new LinearLayout(this);

        presets2.setOrientation(
                LinearLayout.HORIZONTAL
        );
        presets2.setGravity(Gravity.CENTER);

        presets2.setPadding(
                0,
                dp(6),
                0,
                dp(10)
        );

        manualPrompt.addView(presets2);

        addPromptPreset(presets2, 45);
        addPromptPreset(presets2, 60);
        addPromptPreset(presets2, 90);
        addPromptPreset(presets2, 120);

        Button start =
                overlayPrimaryButton("فعال کردن تایمر");

        start.setOnClickListener(v -> {
            removeManualPrompt();

            startTimer(
                    promptMinutes,
                    0L,
                    promptMode
            );
        });

        manualPrompt.addView(
                start,
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(48)
                )
        );

        Button more =
                overlayButton("تنظیم ساعت مشخص");

        more.setOnClickListener(v -> {
            removeManualPrompt();

            Intent open =
                    new Intent(
                            SilentTimerService.this,
                            SmartSilentActivity.class
                    );

            open.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK
            );

            startActivity(open);
        });

        LinearLayout.LayoutParams moreParams =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        dp(44)
                );

        moreParams.topMargin = dp(8);
        manualPrompt.addView(more, moreParams);

        promptParams =
                new WindowManager.LayoutParams(
                        dp(330),
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        Build.VERSION.SDK_INT >= 26
                                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                                : WindowManager.LayoutParams.TYPE_PHONE,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSLUCENT
                );

        promptParams.gravity =
                Gravity.TOP | Gravity.CENTER_HORIZONTAL;

        promptParams.y = dp(90);

        try {
            windowManager.addView(
                    manualPrompt,
                    promptParams
            );
        } catch (Exception ignored) {
            manualPrompt = null;
        }

        updatePromptTime();
    }

    private void updatePromptTime() {
        if (promptTime == null) return;

        if (promptMinutes < 60) {
            promptTime.setText(
                    promptMinutes + " دقیقه"
            );
        } else {
            int h = promptMinutes / 60;
            int m = promptMinutes % 60;

            promptTime.setText(
                    m == 0
                            ? h + " ساعت"
                            : h + " ساعت و " + m + " دقیقه"
            );
        }
    }

    private void addPromptPreset(
            LinearLayout row,
            int minutes
    ) {
        Button b =
                overlayButton(
                        minutes < 60
                                ? String.valueOf(minutes)
                                : (minutes / 60) + "h"
                );

        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(
                        0,
                        dp(40),
                        1f
                );

        lp.setMargins(
                dp(3),
                0,
                dp(3),
                0
        );

        row.addView(b, lp);

        b.setOnClickListener(v -> {
            promptMinutes = minutes;
            updatePromptTime();
        });
    }

    private Button overlayButton(String text) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(13f);
        b.setTextColor(Color.WHITE);
        b.setBackground(
                rounded(
                        0xFF303038,
                        14
                )
        );
        return b;
    }

    private Button overlayPrimaryButton(
            String text
    ) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextSize(14f);
        b.setTextColor(Color.WHITE);
        b.setBackground(
                rounded(
                        0xFF8B5CF6,
                        16
                )
        );
        return b;
    }

    private void removeManualPrompt() {
        if (manualPrompt != null) {
            try {
                windowManager.removeView(
                        manualPrompt
                );
            } catch (Exception ignored) {}

            manualPrompt = null;
        }
    }

    private void createOrRefreshTimerBubble() {
        if (!Settings.canDrawOverlays(this)) return;

        if (timerBubble != null) {
            updateBubble(
                    endAt - System.currentTimeMillis()
            );
            return;
        }

        timerBubble = new TextView(this);
        timerBubble.setTextColor(Color.WHITE);
        timerBubble.setTextSize(15f);
        timerBubble.setGravity(Gravity.CENTER);
        timerBubble.setPadding(
                dp(15),
                dp(11),
                dp(15),
                dp(11)
        );
        timerBubble.setBackground(
                rounded(
                        0xF21C1C22,
                        24
                )
        );
        timerBubble.setElevation(dp(8));

        bubbleParams =
                new WindowManager.LayoutParams(
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.WRAP_CONTENT,
                        Build.VERSION.SDK_INT >= 26
                                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                                : WindowManager.LayoutParams.TYPE_PHONE,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                        PixelFormat.TRANSLUCENT
                );

        bubbleParams.gravity =
                Gravity.TOP | Gravity.END;

        bubbleParams.x = dp(10);
        bubbleParams.y = dp(120);

        timerBubble.setOnTouchListener(
                (v, event) -> {
                    switch (event.getActionMasked()) {
                        case MotionEvent.ACTION_DOWN:
                            bubbleStartX =
                                    bubbleParams.x;
                            bubbleStartY =
                                    bubbleParams.y;

                            bubbleDownX =
                                    event.getRawX();
                            bubbleDownY =
                                    event.getRawY();

                            return true;

                        case MotionEvent.ACTION_MOVE:
                            bubbleParams.x =
                                    bubbleStartX +
                                            Math.round(
                                                    bubbleDownX -
                                                            event.getRawX()
                                            );

                            bubbleParams.y =
                                    bubbleStartY +
                                            Math.round(
                                                    event.getRawY() -
                                                            bubbleDownY
                                            );

                            try {
                                windowManager.updateViewLayout(
                                        timerBubble,
                                        bubbleParams
                                );
                            } catch (Exception ignored) {}

                            return true;

                        case MotionEvent.ACTION_UP:
                            float dx =
                                    Math.abs(
                                            event.getRawX() -
                                                    bubbleDownX
                                    );

                            float dy =
                                    Math.abs(
                                            event.getRawY() -
                                                    bubbleDownY
                                    );

                            if (dx < dp(8) &&
                                    dy < dp(8)) {
                                toggleBubble();
                            }

                            return true;

                        default:
                            return true;
                    }
                }
        );

        try {
            windowManager.addView(
                    timerBubble,
                    bubbleParams
            );
        } catch (Exception ignored) {
            timerBubble = null;
        }

        updateBubble(
                endAt - System.currentTimeMillis()
        );
    }

    private void toggleBubble() {
        bubbleCollapsed =
                !bubbleCollapsed;

        if (bubbleParams != null) {
            bubbleParams.x =
                    bubbleCollapsed ? 0 : dp(10);
        }

        updateBubble(
                endAt - System.currentTimeMillis()
        );

        if (timerBubble != null &&
                bubbleParams != null) {
            try {
                windowManager.updateViewLayout(
                        timerBubble,
                        bubbleParams
                );
            } catch (Exception ignored) {}
        }
    }

    private void updateBubble(long remainingMs) {
        if (timerBubble == null) return;

        if (bubbleCollapsed) {
            timerBubble.setText("◷");
            timerBubble.setPadding(
                    dp(11),
                    dp(11),
                    dp(11),
                    dp(11)
            );
            return;
        }

        timerBubble.setPadding(
                dp(15),
                dp(11),
                dp(15),
                dp(11)
        );

        long sec =
                Math.max(
                        0L,
                        remainingMs / 1000L
                );

        long h = sec / 3600L;
        long m = (sec % 3600L) / 60L;
        long s = sec % 60L;

        String time =
                h > 0
                        ? String.format(
                                Locale.US,
                                "%02d:%02d:%02d",
                                h,
                                m,
                                s
                        )
                        : String.format(
                                Locale.US,
                                "%02d:%02d",
                                m,
                                s
                        );

        timerBubble.setText(
                "◷  " + time + "   ‹"
        );
    }

    private void removeTimerBubble() {
        if (timerBubble != null) {
            try {
                windowManager.removeView(
                        timerBubble
                );
            } catch (Exception ignored) {}

            timerBubble = null;
        }

        bubbleCollapsed = false;
    }

    private Notification buildNotification() {
        Intent open =
                new Intent(
                        this,
                        MainActivity.class
                );

        PendingIntent openPi =
                PendingIntent.getActivity(
                        this,
                        10,
                        open,
                        PendingIntent.FLAG_UPDATE_CURRENT |
                                PendingIntent.FLAG_IMMUTABLE
                );

        Intent add =
                new Intent(
                        this,
                        SilentTimerService.class
                );

        add.setAction(ACTION_ADD_5);

        PendingIntent addPi =
                PendingIntent.getService(
                        this,
                        11,
                        add,
                        PendingIntent.FLAG_UPDATE_CURRENT |
                                PendingIntent.FLAG_IMMUTABLE
                );

        Intent stop =
                new Intent(
                        this,
                        SilentTimerService.class
                );

        stop.setAction(ACTION_STOP);

        PendingIntent stopPi =
                PendingIntent.getService(
                        this,
                        12,
                        stop,
                        PendingIntent.FLAG_UPDATE_CURRENT |
                                PendingIntent.FLAG_IMMUTABLE
                );

        Intent toggle =
                new Intent(
                        this,
                        SilentTimerService.class
                );

        toggle.setAction(
                ACTION_TOGGLE_ALLOWED
        );

        PendingIntent togglePi =
                PendingIntent.getService(
                        this,
                        13,
                        toggle,
                        PendingIntent.FLAG_UPDATE_CURRENT |
                                PendingIntent.FLAG_IMMUTABLE
                );

        Notification.Builder b =
                Build.VERSION.SDK_INT >= 26
                        ? new Notification.Builder(
                                this,
                                CHANNEL_ID
                        )
                        : new Notification.Builder(this);

        String title;
        String text;

        if (timerActive()) {
            title = "Silent Timer فعال است";

            SimpleDateFormat f =
                    new SimpleDateFormat(
                            "HH:mm",
                            Locale.getDefault()
                    );

            text =
                    "پایان " +
                            f.format(new Date(endAt)) +
                            "  •  " +
                            (
                                    targetRingerMode ==
                                            AudioManager.RINGER_MODE_VIBRATE
                                            ? "Vibrate"
                                            : "Silent"
                            );
        } else {
            title = "Silent Timer آماده است";
            text = "تشخیص Silent و Vibrate دستی فعال است";
        }

        return b
                .setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(
                        android.R.drawable.ic_lock_silent_mode
                )
                .setOngoing(true)
                .setContentIntent(openPi)
                .addAction(
                        new Notification.Action.Builder(
                                android.R.drawable.ic_input_add,
                                "+5 دقیقه",
                                addPi
                        ).build()
                )
                .addAction(
                        new Notification.Action.Builder(
                                android.R.drawable.ic_menu_close_clear_cancel,
                                "پایان",
                                stopPi
                        ).build()
                )
                .addAction(
                        new Notification.Action.Builder(
                                android.R.drawable.ic_menu_call,
                                AppPrefs.isAllowedCallsEnabled(this)
                                        ? "تماس مجاز: روشن"
                                        : "تماس مجاز: خاموش",
                                togglePi
                        ).build()
                )
                .build();
    }

    private void updateNotification() {
        try {
            NotificationManager nm =
                    (NotificationManager)
                            getSystemService(
                                    Context.NOTIFICATION_SERVICE
                            );

            nm.notify(
                    NOTIFICATION_ID,
                    buildNotification()
            );
        } catch (Exception ignored) {}
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel =
                    new NotificationChannel(
                            CHANNEL_ID,
                            "Silent Timer",
                            NotificationManager.IMPORTANCE_LOW
                    );

            channel.setDescription(
                    "وضعیت سایلنت هوشمند و تایمر"
            );

            channel.setSound(null, null);

            NotificationManager nm =
                    (NotificationManager)
                            getSystemService(
                                    Context.NOTIFICATION_SERVICE
                            );

            nm.createNotificationChannel(
                    channel
            );
        }
    }

    private void acquireWakeLock() {
        releaseWakeLock();

        PowerManager pm =
                (PowerManager)
                        getSystemService(
                                Context.POWER_SERVICE
                        );

        wakeLock =
                pm.newWakeLock(
                        PowerManager.PARTIAL_WAKE_LOCK,
                        "SilentTimer:Timer"
                );

        long duration =
                Math.max(
                        60_000L,
                        endAt -
                                System.currentTimeMillis() +
                                60_000L
                );

        try {
            wakeLock.acquire(duration);
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        if (wakeLock != null &&
                wakeLock.isHeld()) {
            try {
                wakeLock.release();
            } catch (Exception ignored) {}
        }

        wakeLock = null;
    }

    private void requestTileRefresh() {
        if (Build.VERSION.SDK_INT >= 24) {
            try {
                TileService.requestListeningState(
                        this,
                        new ComponentName(
                                this,
                                SilentTimerTileService.class
                        )
                );
            } catch (Exception ignored) {}
        }
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(ticker);
        removeTimerBubble();
        removeManualPrompt();
        releaseWakeLock();

        try {
            unregisterReceiver(
                    ringerReceiver
            );
        } catch (Exception ignored) {}

        if (telephonyManager != null &&
                phoneStateListener != null) {
            try {
                telephonyManager.listen(
                        phoneStateListener,
                        PhoneStateListener.LISTEN_NONE
                );
            } catch (Exception ignored) {}
        }

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private GradientDrawable rounded(
            int color,
            int radiusDp
    ) {
        GradientDrawable g =
                new GradientDrawable();

        g.setColor(color);
        g.setCornerRadius(
                dp(radiusDp)
        );

        return g;
    }

    private int dp(int value) {
        return Math.round(
                value *
                        getResources()
                                .getDisplayMetrics()
                                .density
        );
    }
}
