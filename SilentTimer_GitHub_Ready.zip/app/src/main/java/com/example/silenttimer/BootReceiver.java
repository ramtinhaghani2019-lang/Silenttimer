package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(
            Context context,
            Intent intent
    ) {
        if (!AppPrefs.isMonitoringEnabled(context)) return;

        Intent service =
                new Intent(
                        context,
                        SilentTimerService.class
                );

        service.setAction(
                SilentTimerService.ACTION_MONITOR
        );

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (Exception ignored) {}
    }
}
