package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.telephony.SmsMessage;

public class SmsEmergencyReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent intent){if(!NexaStore.smsEnabled(c))return;String wanted=NexaStore.smsNumber(c),code=NexaStore.smsCode(c);if(wanted.trim().isEmpty()||code.trim().isEmpty())return;if(intent.getExtras()==null)return;Object[]pdus=(Object[])intent.getExtras().get("pdus");if(pdus==null)return;String format=intent.getStringExtra("format");StringBuilder body=new StringBuilder();String sender="";for(Object p:pdus){SmsMessage m=Build.VERSION.SDK_INT>=23?SmsMessage.createFromPdu((byte[])p,format):SmsMessage.createFromPdu((byte[])p);if(m!=null){sender=m.getOriginatingAddress();body.append(m.getMessageBody());}}if(AppPrefs.numbersMatch(wanted,sender)&&body.toString().contains(code)){AppPrefs.setIgnoreManualUntil(c,System.currentTimeMillis()+6000L);try{((AudioManager)c.getSystemService(Context.AUDIO_SERVICE)).setRingerMode(AudioManager.RINGER_MODE_NORMAL);}catch(Exception ignored){}if(AppPrefs.isTimerActive(c)){Intent stop=new Intent(c,SilentTimerService.class);stop.setAction(SilentTimerService.ACTION_STOP);try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(stop);else c.startService(stop);}catch(Exception ignored){}}NexaStore.addHistory(c,"اضطراری","خروج از سایلنت با کد پیامکی");}}
}
