package com.example.silenttimer;

import android.app.Activity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SmartSilentActivity extends Activity {

    private LinearLayout root;
    private TextView durationText;
    private TextView clockText;
    private TextView activeInfo;

    private int minutes = 30;
    private int targetMode = AudioManager.RINGER_MODE_SILENT;
    private long selectedEndAt = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        minutes = AppPrefs.getMinutes(this);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshActiveInfo();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 28)
        );
        root.setBackgroundColor(p[0]);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        Button back = UiKit.secondaryButton(this, "‹");
        back.setTextSize(26f);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = UiKit.title(this, "سایلنت هوشمند");
        LinearLayout.LayoutParams tp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(UiKit.dp(this, 12), 0, 0, 0);
        header.addView(title, tp);

        LinearLayout modeCard = UiKit.cardLayout(this);
        root.addView(modeCard, UiKit.matchWrap(this, 0, 12));

        modeCard.addView(UiKit.sectionTitle(this, "حالت صدا"));

        TextView modeDesc = UiKit.muted(
                this,
                "تایمر روی Silent یا Vibrate اجرا شود."
        );
        modeCard.addView(modeDesc, UiKit.matchWrap(this, 4, 12));

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeCard.addView(modeRow, UiKit.matchWrap(this));

        Button silentButton = UiKit.secondaryButton(this, "Silent");
        Button vibrateButton = UiKit.secondaryButton(this, "Vibrate");

        LinearLayout.LayoutParams half =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        half.setMargins(UiKit.dp(this, 4), 0, UiKit.dp(this, 4), 0);

        modeRow.addView(silentButton, half);
        modeRow.addView(vibrateButton, half);

        silentButton.setOnClickListener(v -> {
            targetMode = AudioManager.RINGER_MODE_SILENT;
            silentButton.setText("Silent ✓");
            vibrateButton.setText("Vibrate");
        });

        vibrateButton.setOnClickListener(v -> {
            targetMode = AudioManager.RINGER_MODE_VIBRATE;
            silentButton.setText("Silent");
            vibrateButton.setText("Vibrate ✓");
        });

        LinearLayout durationCard = UiKit.cardLayout(this);
        root.addView(durationCard, UiKit.matchWrap(this, 0, 12));

        durationCard.addView(UiKit.sectionTitle(this, "مدت زمان"));

        durationText = new TextView(this);
        durationText.setTextColor(p[2]);
        durationText.setTextSize(34f);
        durationText.setGravity(Gravity.CENTER);
        durationText.setPadding(0, UiKit.dp(this, 12), 0, UiKit.dp(this, 12));
        durationCard.addView(durationText);

        LinearLayout stepRow = new LinearLayout(this);
        stepRow.setOrientation(LinearLayout.HORIZONTAL);
        durationCard.addView(stepRow, UiKit.matchWrap(this, 0, 12));

        Button minus = UiKit.secondaryButton(this, "− 5");
        Button plus = UiKit.secondaryButton(this, "+ 5");

        LinearLayout.LayoutParams stepParams =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        stepParams.setMargins(UiKit.dp(this, 4), 0, UiKit.dp(this, 4), 0);

        stepRow.addView(minus, stepParams);
        stepRow.addView(plus, stepParams);

        minus.setOnClickListener(v -> {
            selectedEndAt = 0L;
            minutes = Math.max(5, minutes - 5);
            updateDuration();
        });

        plus.setOnClickListener(v -> {
            selectedEndAt = 0L;
            minutes = Math.min(720, minutes + 5);
            updateDuration();
        });

        LinearLayout presets = new LinearLayout(this);
        presets.setOrientation(LinearLayout.VERTICAL);
        durationCard.addView(presets);

        addPresetRow(presets, new int[]{5, 10, 15});
        addPresetRow(presets, new int[]{30, 45, 60});
        addPresetRow(presets, new int[]{90, 120, 180});

        LinearLayout clockCard = UiKit.cardLayout(this);
        root.addView(clockCard, UiKit.matchWrap(this, 0, 12));

        clockCard.addView(UiKit.sectionTitle(this, "خروج در ساعت مشخص"));

        TextView clockDesc = UiKit.muted(
                this,
                "مثلاً مشخص کن رأس ساعت 13:45 گوشی از Silent/Vibrate خارج شود."
        );
        clockCard.addView(clockDesc, UiKit.matchWrap(this, 4, 12));

        clockText = new TextView(this);
        clockText.setText("ساعت مشخص نشده");
        clockText.setTextColor(p[2]);
        clockText.setTextSize(22f);
        clockText.setGravity(Gravity.CENTER);
        clockCard.addView(clockText, UiKit.matchWrap(this, 4, 12));

        Button chooseClock = UiKit.secondaryButton(this, "انتخاب ساعت");
        chooseClock.setOnClickListener(v -> chooseEndClock());
        clockCard.addView(chooseClock);

        activeInfo = UiKit.muted(this, "");
        activeInfo.setGravity(Gravity.CENTER);
        root.addView(activeInfo, UiKit.matchWrap(this, 6, 12));

        Button start = UiKit.primaryButton(this, "شروع تایمر");
        start.setOnClickListener(v -> startTimer());
        root.addView(start, UiKit.matchWrap(this, 0, 10));

        Button stop = UiKit.secondaryButton(this, "پایان تایمر و بازگشت صدا");
        stop.setOnClickListener(v -> stopTimer());
        root.addView(stop);

        updateDuration();
        refreshActiveInfo();
        setContentView(scroll);
    }

    private void addPresetRow(LinearLayout parent, int[] values) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(row, UiKit.matchWrap(this, 0, 8));

        for (int value : values) {
            Button b = UiKit.secondaryButton(
                    this,
                    value < 60 ? value + " دقیقه" : formatMinutes(value)
            );

            LinearLayout.LayoutParams p =
                    new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            p.setMargins(UiKit.dp(this, 3), 0, UiKit.dp(this, 3), 0);
            row.addView(b, p);

            b.setOnClickListener(v -> {
                selectedEndAt = 0L;
                minutes = value;
                updateDuration();
            });
        }
    }

    private void chooseEndClock() {
        Calendar now = Calendar.getInstance();

        TimePickerDialog dialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minuteOfHour) -> {
                    Calendar end = Calendar.getInstance();
                    end.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    end.set(Calendar.MINUTE, minuteOfHour);
                    end.set(Calendar.SECOND, 0);
                    end.set(Calendar.MILLISECOND, 0);

                    if (end.getTimeInMillis() <= System.currentTimeMillis()) {
                        end.add(Calendar.DAY_OF_YEAR, 1);
                    }

                    selectedEndAt = end.getTimeInMillis();

                    SimpleDateFormat f =
                            new SimpleDateFormat("HH:mm", Locale.getDefault());

                    clockText.setText(
                            "پایان در " + f.format(new Date(selectedEndAt))
                    );
                },
                now.get(Calendar.HOUR_OF_DAY),
                now.get(Calendar.MINUTE),
                true
        );

        dialog.show();
    }

    private void startTimer() {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_START);
        i.putExtra(SilentTimerService.EXTRA_TARGET_MODE, targetMode);

        if (selectedEndAt > 0L) {
            i.putExtra(SilentTimerService.EXTRA_END_AT, selectedEndAt);
        } else {
            i.putExtra(SilentTimerService.EXTRA_MINUTES, minutes);
        }

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }

        AppPrefs.setMinutes(this, minutes);
        finish();
    }

    private void stopTimer() {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_STOP);

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }

        selectedEndAt = 0L;
        refreshActiveInfo();
    }

    private void updateDuration() {
        durationText.setText(formatMinutes(minutes));

        if (selectedEndAt == 0L) {
            clockText.setText("ساعت مشخص نشده");
        }
    }

    private String formatMinutes(int value) {
        if (value < 60) return value + " دقیقه";

        int h = value / 60;
        int m = value % 60;

        if (m == 0) return h + " ساعت";
        return h + " ساعت و " + m + " دقیقه";
    }

    private void refreshActiveInfo() {
        if (activeInfo == null) return;

        if (!AppPrefs.isTimerActive(this)) {
            activeInfo.setText("تایمر فعالی وجود ندارد.");
            return;
        }

        SimpleDateFormat f =
                new SimpleDateFormat("HH:mm", Locale.getDefault());

        activeInfo.setText(
                "تایمر فعال است  •  پایان " +
                        f.format(new Date(AppPrefs.getEndAt(this)))
        );
    }
}
