package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class VaultActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        UiKit.applyWindow(this);

        if (NexaStore.lockEnabled(this) && !SecurityGate.isUnlocked()) {
            startActivity(new android.content.Intent(this, UnlockActivity.class));
        }

        build();

        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 300);
        }
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Vault"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"رمزها و یادداشت‌های محرمانه؛ داده حساس با Android Keystore رمزگذاری می‌شود."),UiKit.matchWrap(this,0,14));

        LinearLayout security=UiKit.colorfulCardLayout(this,3);
        security.addView(UiKit.sectionTitle(this,"🔐 صندوق امن"));
        if(!NexaStore.lockEnabled(this)) {
            security.addView(UiKit.muted(this,"پیشنهاد: قبل از استفاده، قفل PIN/اثر انگشت Nexa را از تنظیمات فعال کن."),UiKit.matchWrap(this,6,10));
            Button openSec=UiKit.secondaryButton(this,"رفتن به تنظیمات امنیت");
            openSec.setOnClickListener(v->startActivity(new android.content.Intent(this,SecurityActivity.class)));
            security.addView(openSec);
        } else {
            security.addView(UiKit.muted(this,"قفل Nexa فعال است • اسکرین‌شات این صفحه غیرفعال است."),UiKit.matchWrap(this,6,0));
        }
        root.addView(security,UiKit.matchWrap(this,0,12));

        Button add=UiKit.primaryButton(this,"＋ مورد محرمانه جدید");
        add.setOnClickListener(v->addDialog());
        root.addView(add,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        Spinner type=new Spinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"Instagram / شبکه اجتماعی","ایمیل","سایت","Wi‑Fi","کارت/حساب بانکی","یادداشت محرمانه","سایر"}
        ));

        EditText title=field("عنوان؛ مثلاً ایمیل کاری");
        EditText username=field("نام کاربری / ایمیل / شناسه");
        EditText secret=field("رمز / اطلاعات محرمانه");
        secret.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        EditText note=field("یادداشت");

        box.addView(type);box.addView(title);box.addView(username);box.addView(secret);box.addView(note);

        new AlertDialog.Builder(this)
                .setTitle("مورد محرمانه جدید")
                .setMessage("برای کارت بانکی بهتر است رمز پویا، CVV2 و اطلاعاتی که امکان سوءاستفاده مستقیم دارند ذخیره نشوند.")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())return;

                    NexaStore.VaultEntry x=new NexaStore.VaultEntry();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.usernameEncrypted=VaultCrypto.encrypt(username.getText().toString());
                    x.secretEncrypted=VaultCrypto.encrypt(secret.getText().toString());
                    x.noteEncrypted=VaultCrypto.encrypt(note.getText().toString());

                    if((!username.getText().toString().isEmpty() && x.usernameEncrypted.isEmpty()) ||
                       (!secret.getText().toString().isEmpty() && x.secretEncrypted.isEmpty())) {
                        Toast.makeText(this,"رمزگذاری انجام نشد؛ مورد ذخیره نشد.",Toast.LENGTH_LONG).show();
                        return;
                    }

                    NexaStore.addVault(this,x);
                    NexaStore.addHistory(this,"Vault","مورد جدید: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.VaultEntry> data=NexaStore.vault(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"هنوز چیزی در Vault ذخیره نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        for(NexaStore.VaultEntry x:data){
            LinearLayout c=UiKit.colorfulCardLayout(this,3);
            c.addView(UiKit.sectionTitle(this,"🔐 "+x.title));
            c.addView(UiKit.muted(this,x.type),UiKit.matchWrap(this,5,6));

            TextView secret=UiKit.muted(this,"••••••••");
            secret.setTextSize(16);
            c.addView(secret);

            LinearLayout actions=new LinearLayout(this);
            Button show=UiKit.secondaryButton(this,"نمایش");
            show.setOnClickListener(v->{
                String u=VaultCrypto.decrypt(x.usernameEncrypted);
                String s=VaultCrypto.decrypt(x.secretEncrypted);
                String n=VaultCrypto.decrypt(x.noteEncrypted);
                String text="";
                if(!u.isEmpty())text+="شناسه: "+u;
                if(!s.isEmpty())text+=(text.isEmpty()?"":"\n")+"رمز: "+s;
                if(!n.isEmpty())text+=(text.isEmpty()?"":"\n")+"یادداشت: "+n;
                if(text.isEmpty())text="اطلاعاتی ثبت نشده یا کلید رمزگذاری قابل بازیابی نیست.";
                secret.setText(text);
                secret.postDelayed(()->secret.setText("••••••••"),15000);
            });

            Button del=UiKit.secondaryButton(this,"حذف");
            del.setOnClickListener(v->new AlertDialog.Builder(this)
                    .setTitle("حذف از Vault؟")
                    .setMessage(x.title)
                    .setPositiveButton("حذف",(d,w)->{
                        NexaStore.removeVault(this,x.id);
                        render();
                    })
                    .setNegativeButton("انصراف",null)
                    .show());

            actions.addView(show,new LinearLayout.LayoutParams(0,-2,1f));
            LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(0,-2,1f);
            dp.setMargins(UiKit.dp(this,6),0,0,0);
            actions.addView(del,dp);
            c.addView(actions,UiKit.matchWrap(this,10,0));

            list.addView(c,UiKit.matchWrap(this,0,10));
        }
    }
}
