package com.example.silenttimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

public class AuraView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    public AuraView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;

        float r1 = Math.min(getWidth(), getHeight()) * 0.48f;
        paint.setShader(new RadialGradient(
                cx, cy, r1,
                new int[]{0x558B5CF6, 0x222DD4BF, 0x00000000},
                new float[]{0f, 0.52f, 1f},
                Shader.TileMode.CLAMP
        ));
        canvas.drawCircle(cx, cy, r1, paint);

        paint.setShader(null);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(UiKit.dp(getContext(), 1));

        paint.setColor(0x228B5CF6);
        canvas.drawCircle(cx, cy, r1 * 0.82f, paint);

        paint.setColor(0x182DD4BF);
        canvas.drawCircle(cx, cy, r1 * 0.64f, paint);
    }
}
