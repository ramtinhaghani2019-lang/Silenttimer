package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class SettingsActivity extends Activity {
    public static final String EXTRA_START_SETUP = "start_setup";

    private static final int REQ_RUNTIME = 7101;
    private static final int REQ_CALL_SCREENING = 7102;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean setupInProgress = false;
    private int waitingSpecialStep = 0;

    private TextView overlayStatus;
    private TextView dndStatus;
    private TextView phoneStatus;
    private TextView screeningStatus;
    private TextView batteryStatus;
    private Button setupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        buildUi();

        if (getIntent().getBooleanExtra(EXTRA_START_SETUP, false)) {
            setupInProgress = true;
            handler.postDelayed(this::continueSetup, 350L);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatuses();

        if (setupInProgress && waitingSpecialStep != 0) {
            int completedStep = waitingSpecialStep;
            waitingSpecialStep = 0;

            if (!stepGranted(completedStep)) {
                setupInProgress = false;
                Toast.makeText(
                        this,
                        "این دسترسی تأیید نشد. هر زمان خواستی دوباره «راه‌اندازی کامل» را بزن.",
                        Toast.LENGTH_LONG
                ).show();
                return;
            }

            handler.postDelayed(this::continueSetup, 300L);
        }
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 28)
        );
        root.setBackground(UiKit.screenBackground(this));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        Button back = UiKit.secondaryButton(this, "‹");
        back.setTextSize(25f);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleLp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        titleLp.setMargins(UiKit.dp(this, 12), 0, 0, 0);
        header.addView(titleBox, titleLp);

        titleBox.addView(UiKit.title(this, "تنظیمات"));
        titleBox.addView(
                UiKit.muted(this, "Obsidian Edition"),
                UiKit.matchWrap(this, 3, 0)
        );

        LinearLayout accessHero = new LinearLayout(this);
        accessHero.setOrientation(LinearLayout.VERTICAL);
        accessHero.setPadding(
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20)
        );
        accessHero.setBackground(UiKit.accentCard(this));
        root.addView(accessHero, UiKit.matchWrap(this, 0, 14));

        accessHero.addView(UiKit.sectionTitle(this, "راه‌اندازی کامل دسترسی‌ها"));

        TextView accessDesc = UiKit.muted(
                this,
                "فقط یک‌بار شروعش کن؛ بعد از تأیید هر صفحه، مرحله بعدی خودکار باز می‌شود."
        );
        accessHero.addView(accessDesc, UiKit.matchWrap(this, 6, 14));

        setupButton = UiKit.primaryButton(this, "شروع راه‌اندازی کامل");
        setupButton.setOnClickListener(v -> {
            setupInProgress = true;
            waitingSpecialStep = 0;
            continueSetup();
        });
        accessHero.addView(setupButton);

        LinearLayout checklist = UiKit.cardLayout(this);
        root.addView(checklist, UiKit.matchWrap(this, 0, 14));

        checklist.addView(UiKit.sectionTitle(this, "وضعیت دسترسی‌ها"));

        overlayStatus = statusLine("نمایش روی برنامه‌ها");
        dndStatus = statusLine("کنترل Silent / Vibrate");
        phoneStatus = statusLine("وضعیت تماس و اعلان‌ها");
        screeningStatus = statusLine("Call Screening تماس‌های مجاز");
        batteryStatus = statusLine("فعالیت پس‌زمینه بدون محدودیت");

        checklist.addView(overlayStatus, UiKit.matchWrap(this, 12, 6));
        checklist.addView(dndStatus, UiKit.matchWrap(this, 0, 6));
        checklist.addView(phoneStatus, UiKit.matchWrap(this, 0, 6));
        checklist.addView(screeningStatus, UiKit.matchWrap(this, 0, 6));
        checklist.addView(batteryStatus, UiKit.matchWrap(this, 0, 0));

        LinearLayout monitorCard = UiKit.cardLayout(this);
        root.addView(monitorCard, UiKit.matchWrap(this, 0, 14));

        LinearLayout monitorTop = new LinearLayout(this);
        monitorTop.setOrientation(LinearLayout.HORIZONTAL);
        monitorTop.setGravity(Gravity.CENTER_VERTICAL);
        monitorCard.addView(monitorTop);

        TextView monitorTitle = UiKit.sectionTitle(this, "تشخیص خودکار Silent / Vibrate");
        LinearLayout.LayoutParams mtp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        monitorTop.addView(monitorTitle, mtp);

        Switch monitor = new Switch(this);
        monitor.setChecked(AppPrefs.isMonitoringEnabled(this));
        monitor.setText(monitor.isChecked() ? "روشن" : "خاموش");
        monitorTop.addView(monitor);

        monitorCard.addView(
                UiKit.muted(
                        this,
                        "بعد از روشن‌شدن گوشی، Silent Timer خودش آماده به کار می‌شود."
                ),
                UiKit.matchWrap(this, 8, 0)
        );

        monitor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppPrefs.setMonitoringEnabled(this, isChecked);
            monitor.setText(isChecked ? "روشن" : "خاموش");

            Intent i = new Intent(this, SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_MONITOR);

            if (isChecked) {
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                    else startService(i);
                } catch (Exception ignored) {}
            } else {
                stopService(i);
            }
        });

        LinearLayout identityCard = UiKit.cardLayout(this);
        root.addView(identityCard, UiKit.matchWrap(this, 0, 14));

        identityCard.addView(UiKit.sectionTitle(this, "ظاهر"));
        identityCard.addView(
                UiKit.muted(
                        this,
                        "تم برنامه روی Obsidian ثابت شده؛ پس‌زمینه تیره، درخشش بنفش/فیروزه‌ای و کارت‌های شیشه‌ای."
                ),
                UiKit.matchWrap(this, 7, 0)
        );

        LinearLayout about = UiKit.cardLayout(this);
        root.addView(about, UiKit.matchWrap(this, 0, 14));

        about.addView(UiKit.sectionTitle(this, "درباره"));
        about.addView(
                UiKit.muted(
                        this,
                        "Silent Timer 4.1\nObsidian Edition • Smart Silent • Allowed Calls"
                ),
                UiKit.matchWrap(this, 6, 0)
        );

        setContentView(scroll);
        refreshStatuses();
    }

    private TextView statusLine(String label) {
        TextView tv = UiKit.muted(this, label);
        tv.setTextSize(14f);
        return tv;
    }

    private void refreshStatuses() {
        if (overlayStatus == null) return;

        overlayStatus.setText(statusPrefix(Settings.canDrawOverlays(this)) + "نمایش روی برنامه‌ها");

        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        dndStatus.setText(statusPrefix(nm.isNotificationPolicyAccessGranted()) + "کنترل Silent / Vibrate");

        boolean runtimeOk =
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                        == PackageManager.PERMISSION_GRANTED &&
                (Build.VERSION.SDK_INT < 33 ||
                        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                                == PackageManager.PERMISSION_GRANTED) &&
                checkSelfPermission(Manifest.permission.READ_CONTACTS)
                        == PackageManager.PERMISSION_GRANTED;
        phoneStatus.setText(statusPrefix(runtimeOk) + "وضعیت تماس، اعلان‌ها و مخاطبین");

        screeningStatus.setText(
                statusPrefix(isCallScreeningReady()) + "Call Screening تماس‌های مجاز"
        );

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean batteryOk = pm.isIgnoringBatteryOptimizations(getPackageName());
        batteryStatus.setText(
                statusPrefix(batteryOk) + "فعالیت پس‌زمینه بدون محدودیت"
        );

        boolean allReady =
                Settings.canDrawOverlays(this) &&
                nm.isNotificationPolicyAccessGranted() &&
                runtimeOk &&
                isCallScreeningReady() &&
                batteryOk;

        setupButton.setText(
                allReady
                        ? "همه دسترسی‌ها آماده‌اند ✓"
                        : "شروع راه‌اندازی کامل"
        );
    }

    private String statusPrefix(boolean ok) {
        return ok ? "✓  " : "○  ";
    }

    private boolean isCallScreeningReady() {
        if (Build.VERSION.SDK_INT < 29) return true;

        RoleManager rm = getSystemService(RoleManager.class);
        return rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
                rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);
    }

    private boolean stepGranted(int step) {
        switch (step) {
            case 1:
                return Settings.canDrawOverlays(this);

            case 2:
                NotificationManager nm =
                        (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                return nm.isNotificationPolicyAccessGranted();

            case 5:
                PowerManager pm =
                        (PowerManager) getSystemService(Context.POWER_SERVICE);
                return pm.isIgnoringBatteryOptimizations(getPackageName());

            default:
                return true;
        }
    }

    private void continueSetup() {
        refreshStatuses();

        if (!Settings.canDrawOverlays(this)) {
            waitingSpecialStep = 1;
            startActivity(
                    new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())
                    )
            );
            return;
        }

        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (!nm.isNotificationPolicyAccessGranted()) {
            waitingSpecialStep = 2;
            startActivity(
                    new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            );
            return;
        }

        ArrayList<String> runtime = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            runtime.add(Manifest.permission.READ_PHONE_STATE);
        }

        if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            runtime.add(Manifest.permission.READ_CONTACTS);
        }

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            runtime.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!runtime.isEmpty()) {
            requestPermissions(runtime.toArray(new String[0]), REQ_RUNTIME);
            return;
        }

        if (Build.VERSION.SDK_INT >= 29 && !isCallScreeningReady()) {
            RoleManager rm = getSystemService(RoleManager.class);
            startActivityForResult(
                    rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),
                    REQ_CALL_SCREENING
            );
            return;
        }

        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);

        if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
            waitingSpecialStep = 5;

            try {
                startActivity(
                        new Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + getPackageName())
                        )
                );
            } catch (Exception e) {
                startActivity(
                        new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                );
            }
            return;
        }

        setupInProgress = false;
        refreshStatuses();

        Intent monitor = new Intent(this, SilentTimerService.class);
        monitor.setAction(SilentTimerService.ACTION_MONITOR);

        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(monitor);
            else startService(monitor);
        } catch (Exception ignored) {}

        Toast.makeText(
                this,
                "راه‌اندازی کامل شد؛ Silent Timer آماده است.",
                Toast.LENGTH_LONG
        ).show();
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode != REQ_RUNTIME) return;

        boolean allGranted = true;

        for (int result : grantResults) {
            if (result != PackageManager.PERMISSION_GRANTED) {
                allGranted = false;
                break;
            }
        }

        if (!allGranted) {
            setupInProgress = false;
            Toast.makeText(
                    this,
                    "برای ادامه، دسترسی‌های این مرحله باید تأیید شوند.",
                    Toast.LENGTH_LONG
            ).show();
            refreshStatuses();
            return;
        }

        handler.postDelayed(this::continueSetup, 250L);
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_CALL_SCREENING) {
            if (!isCallScreeningReady()) {
                setupInProgress = false;
                Toast.makeText(
                        this,
                        "دسترسی Call Screening فعال نشد.",
                        Toast.LENGTH_LONG
                ).show();
                refreshStatuses();
                return;
            }

            handler.postDelayed(this::continueSetup, 250L);
        }
    }
}
