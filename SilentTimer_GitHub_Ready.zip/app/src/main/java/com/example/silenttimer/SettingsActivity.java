package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

public class SettingsActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        buildUi();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 28)
        );
        root.setBackground(UiKit.screenBackground(this));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        Button back = UiKit.secondaryButton(this, "‹");
        back.setTextSize(25f);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = UiKit.title(this, "تنظیمات");
        LinearLayout.LayoutParams tp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(UiKit.dp(this, 12), 0, 0, 0);
        header.addView(title, tp);

        LinearLayout appearance = UiKit.cardLayout(this);
        root.addView(appearance, UiKit.matchWrap(this, 0, 14));
        appearance.addView(UiKit.sectionTitle(this, "ظاهر برنامه"));
        appearance.addView(
                UiKit.muted(this, "تم فقط از این بخش تغییر می‌کند."),
                UiKit.matchWrap(this, 5, 10)
        );

        Spinner spinner = new Spinner(this);
        String[] themes = {"Obsidian", "Midnight", "Pearl", "Aurora"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                themes
        );
        spinner.setAdapter(adapter);
        spinner.setSelection(AppPrefs.getTheme(this));
        appearance.addView(spinner);

        spinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {
                    private boolean first = true;

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        if (first) {
                            first = false;
                            return;
                        }

                        AppPrefs.setTheme(SettingsActivity.this, position);
                        recreate();
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) {}
                }
        );

        LinearLayout monitorCard = UiKit.cardLayout(this);
        root.addView(monitorCard, UiKit.matchWrap(this, 0, 14));

        LinearLayout monitorTop = new LinearLayout(this);
        monitorTop.setOrientation(LinearLayout.HORIZONTAL);
        monitorTop.setGravity(Gravity.CENTER_VERTICAL);
        monitorCard.addView(monitorTop);

        TextView monitorTitle = UiKit.sectionTitle(this, "تشخیص خودکار Silent / Vibrate");
        LinearLayout.LayoutParams mtp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        monitorTop.addView(monitorTitle, mtp);

        Switch monitor = new Switch(this);
        monitor.setChecked(AppPrefs.isMonitoringEnabled(this));
        monitor.setText(monitor.isChecked() ? "روشن" : "خاموش");
        monitorTop.addView(monitor);

        monitorCard.addView(
                UiKit.muted(this, "بعد از روشن‌شدن گوشی، سرویس خودکار آماده می‌شود."),
                UiKit.matchWrap(this, 8, 0)
        );

        monitor.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppPrefs.setMonitoringEnabled(this, isChecked);
            monitor.setText(isChecked ? "روشن" : "خاموش");

            Intent i = new Intent(this, SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_MONITOR);

            if (isChecked) {
                try {
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
                    else startService(i);
                } catch (Exception ignored) {}
            } else {
                stopService(i);
            }
        });

        LinearLayout permissions = UiKit.cardLayout(this);
        root.addView(permissions, UiKit.matchWrap(this, 0, 14));
        permissions.addView(UiKit.sectionTitle(this, "پایداری و دسترسی‌ها"));
        permissions.addView(
                UiKit.muted(this, "برای اینکه پنجره Silent هر بار نمایش داده شود، محدودیت باتری را برای برنامه بردار."),
                UiKit.matchWrap(this, 5, 12)
        );

        Button overlay = UiKit.secondaryButton(this, "اجازه نمایش روی برنامه‌ها");
        overlay.setOnClickListener(v ->
                startActivity(new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                ))
        );
        permissions.addView(overlay, UiKit.matchWrap(this, 0, 8));

        Button dnd = UiKit.secondaryButton(this, "اجازه کنترل حالت بی‌صدا");
        dnd.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        );
        permissions.addView(dnd, UiKit.matchWrap(this, 0, 8));

        Button battery = UiKit.secondaryButton(this, "باتری: بدون محدودیت / Unrestricted");
        battery.setOnClickListener(v ->
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        );
        permissions.addView(battery);

        LinearLayout about = UiKit.cardLayout(this);
        root.addView(about, UiKit.matchWrap(this, 0, 14));
        about.addView(UiKit.sectionTitle(this, "درباره"));
        about.addView(
                UiKit.muted(
                        this,
                        "Silent Timer 4.0\nرابط کاربری جدید، Call Screening رسمی، تایمر ۵ دقیقه‌ای و Smart Silent."
                ),
                UiKit.matchWrap(this, 6, 0)
        );

        setContentView(scroll);
    }
}
