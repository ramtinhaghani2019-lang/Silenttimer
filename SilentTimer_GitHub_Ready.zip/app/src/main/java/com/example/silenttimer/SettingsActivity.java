package com.example.silenttimer;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {

    private LinearLayout root;
    private Spinner themeSpinner;
    private Switch monitorSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        buildUi();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 28)
        );
        root.setBackgroundColor(p[0]);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        Button back = UiKit.secondaryButton(this, "‹");
        back.setTextSize(26f);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = UiKit.title(this, "تنظیمات");
        LinearLayout.LayoutParams tp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(UiKit.dp(this, 12), 0, 0, 0);
        header.addView(title, tp);

        LinearLayout appearance = UiKit.cardLayout(this);
        root.addView(appearance, UiKit.matchWrap(this, 0, 12));

        appearance.addView(UiKit.sectionTitle(this, "ظاهر برنامه"));

        TextView appearanceDesc = UiKit.muted(
                this,
                "تم برنامه را انتخاب کن. این تنظیم از صفحه اصلی حذف شده است."
        );
        appearance.addView(appearanceDesc, UiKit.matchWrap(this, 5, 10));

        themeSpinner = new Spinner(this);
        String[] themes = {"AMOLED", "Midnight", "Light", "Glass"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                themes
        );

        themeSpinner.setAdapter(adapter);
        themeSpinner.setSelection(AppPrefs.getTheme(this));
        appearance.addView(themeSpinner);

        themeSpinner.setOnItemSelectedListener(
                new android.widget.AdapterView.OnItemSelectedListener() {
                    private boolean first = true;

                    @Override
                    public void onItemSelected(
                            android.widget.AdapterView<?> parent,
                            View view,
                            int position,
                            long id
                    ) {
                        if (first) {
                            first = false;
                            return;
                        }

                        AppPrefs.setTheme(SettingsActivity.this, position);
                        recreate();
                    }

                    @Override
                    public void onNothingSelected(
                            android.widget.AdapterView<?> parent
                    ) {}
                }
        );

        LinearLayout monitorCard = UiKit.cardLayout(this);
        root.addView(monitorCard, UiKit.matchWrap(this, 0, 12));

        LinearLayout monitorTop = new LinearLayout(this);
        monitorTop.setOrientation(LinearLayout.HORIZONTAL);
        monitorTop.setGravity(Gravity.CENTER_VERTICAL);
        monitorCard.addView(monitorTop);

        TextView monitorTitle = UiKit.sectionTitle(
                this,
                "سایلنت هوشمند همیشه آماده"
        );

        LinearLayout.LayoutParams mtp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        monitorTop.addView(monitorTitle, mtp);

        monitorSwitch = new Switch(this);
        monitorSwitch.setChecked(AppPrefs.isMonitoringEnabled(this));
        monitorSwitch.setText(
                monitorSwitch.isChecked() ? "روشن" : "خاموش"
        );
        monitorTop.addView(monitorSwitch);

        TextView monitorDesc = UiKit.muted(
                this,
                "بعد از روشن شدن گوشی، سرویس به‌طور خودکار برای تشخیص Silent و Vibrate آماده می‌شود."
        );
        monitorCard.addView(monitorDesc, UiKit.matchWrap(this, 8, 0));

        monitorSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppPrefs.setMonitoringEnabled(
                    SettingsActivity.this,
                    isChecked
            );

            monitorSwitch.setText(isChecked ? "روشن" : "خاموش");

            Intent i = new Intent(
                    SettingsActivity.this,
                    SilentTimerService.class
            );

            if (isChecked) {
                i.setAction(SilentTimerService.ACTION_MONITOR);

                try {
                    if (Build.VERSION.SDK_INT >= 26) {
                        startForegroundService(i);
                    } else {
                        startService(i);
                    }
                } catch (Exception ignored) {}
            } else {
                stopService(i);
            }
        });

        LinearLayout permissions = UiKit.cardLayout(this);
        root.addView(permissions, UiKit.matchWrap(this, 0, 12));

        permissions.addView(UiKit.sectionTitle(this, "دسترسی‌ها و پس‌زمینه"));

        TextView permDesc = UiKit.muted(
                this,
                "برای نمایش پنجره روی صفحه، کنترل Silent و کار پایدار در پس‌زمینه."
        );
        permissions.addView(permDesc, UiKit.matchWrap(this, 5, 12));

        Button overlay = UiKit.secondaryButton(
                this,
                "اجازه نمایش روی برنامه‌ها"
        );
        overlay.setOnClickListener(v ->
                startActivity(
                        new Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())
                        )
                )
        );
        permissions.addView(overlay, UiKit.matchWrap(this, 0, 8));

        Button dnd = UiKit.secondaryButton(
                this,
                "اجازه کنترل حالت بی‌صدا"
        );
        dnd.setOnClickListener(v ->
                startActivity(
                        new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
                )
        );
        permissions.addView(dnd, UiKit.matchWrap(this, 0, 8));

        Button battery = UiKit.secondaryButton(
                this,
                "تنظیمات باتری و فعالیت پس‌زمینه"
        );
        battery.setOnClickListener(v ->
                startActivity(
                        new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                )
        );
        permissions.addView(battery);

        LinearLayout about = UiKit.cardLayout(this);
        root.addView(about, UiKit.matchWrap(this, 0, 12));

        about.addView(UiKit.sectionTitle(this, "درباره"));

        TextView version = UiKit.muted(
                this,
                "Silent Timer 3.0\nطراحی چندصفحه‌ای با سایلنت هوشمند، Vibrate، تماس‌های مجاز و Quick Settings."
        );
        about.addView(version, UiKit.matchWrap(this, 6, 0));

        setContentView(scroll);
    }
}
