package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class TodayActivity extends Activity {
    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Today"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"✦ آنچه امروز و در ۲۴ ساعت آینده مهم است"),UiKit.matchWrap(this,0,14));

        long now=System.currentTimeMillis(),end=now+24L*60L*60L*1000L;

        LinearLayout rcard=UiKit.colorfulCardLayout(this,1);
        rcard.addView(UiKit.sectionTitle(this,"📅 قرارها و سررسیدهای نزدیک"));
        int rc=0;
        for(NexaStore.Reminder r:NexaStore.reminders(this))
            if(r.whenMillis>=now&&r.whenMillis<=end){
                rc++;
                String extra="";
                if(!r.doctorName.isEmpty())extra+=" • دکتر "+r.doctorName;
                if(!r.doctorFileNumber.isEmpty())extra+=" • پرونده "+r.doctorFileNumber;
                rcard.addView(UiKit.muted(this,r.icon+" "+r.title+" • "+PersianDateUtil.pretty(r.whenMillis)+extra),UiKit.matchWrap(this,7,0));
            }
        if(rc==0)rcard.addView(UiKit.muted(this,"در ۲۴ ساعت آینده موردی نیست."),UiKit.matchWrap(this,7,0));
        root.addView(rcard,UiKit.matchWrap(this,0,12));

        LinearLayout meds=UiKit.colorfulCardLayout(this,2);
        meds.addView(UiKit.sectionTitle(this,"💊 داروها"));
        int mc=0;
        for(NexaStore.Medicine m:NexaStore.medicines(this))
            if(m.active){
                mc++;
                meds.addView(UiKit.muted(this,m.name+" • نوبت بعد "+PersianDateUtil.pretty(m.nextDoseMillis)),UiKit.matchWrap(this,7,0));
            }
        if(mc==0)meds.addView(UiKit.muted(this,"داروی فعالی ثبت نشده."),UiKit.matchWrap(this,7,0));
        root.addView(meds,UiKit.matchWrap(this,0,12));

        LinearLayout tasks=UiKit.colorfulCardLayout(this,3);
        tasks.addView(UiKit.sectionTitle(this,"✓ کارها و پرداخت‌ها"));
        int tc=0;
        for(NexaStore.TodoItem t:NexaStore.todos(this))
            if(!t.done && (t.dueMillis==0 || t.dueMillis<=end)){
                tc++;
                tasks.addView(UiKit.muted(this,"✓ "+t.title+(t.dueMillis>0?" • "+PersianDateUtil.pretty(t.dueMillis):"")),UiKit.matchWrap(this,7,0));
            }
        for(NexaStore.BillItem x:NexaStore.bills(this))
            if(!x.paid && x.dueDate>=now && x.dueDate<=end){
                tc++;
                tasks.addView(UiKit.muted(this,"💳 "+x.title+" • "+PersianDateUtil.pretty(x.dueDate)),UiKit.matchWrap(this,7,0));
            }
        if(tc==0)tasks.addView(UiKit.muted(this,"کار یا پرداخت فوری وجود ندارد."),UiKit.matchWrap(this,7,0));
        root.addView(tasks,UiKit.matchWrap(this,0,12));

        LinearLayout garage=UiKit.colorfulCardLayout(this,0);
        garage.addView(UiKit.sectionTitle(this,"🚗 وضعیت گاراژ"));
        if(NexaStore.vehicles(this).isEmpty())garage.addView(UiKit.muted(this,"وسیله‌ای ثبت نشده."),UiKit.matchWrap(this,7,0));
        for(NexaStore.Vehicle v:NexaStore.vehicles(this))
            garage.addView(UiKit.muted(this,v.name+" • "+v.currentKm+" km"),UiKit.matchWrap(this,7,0));
        root.addView(garage,UiKit.matchWrap(this,0,12));

        LinearLayout unlock=UiKit.cardLayout(this);
        unlock.addView(UiKit.sectionTitle(this,"🔓 یادآوری دفعه بعد که گوشی را باز کردم"));
        EditText note=new EditText(this);
        note.setHint("یک یادداشت کوتاه...");
        note.setTextColor(UiKit.TEXT);
        note.setHintTextColor(UiKit.MUTED);
        note.setBackground(UiKit.field(this));
        note.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        unlock.addView(note,UiKit.matchWrap(this,10,8));
        Button save=UiKit.secondaryButton(this,"ثبت برای بازشدن بعدی گوشی");
        save.setOnClickListener(v->{NexaStore.setUnlockNote(this,note.getText().toString().trim());note.setText("");});
        unlock.addView(save);
        root.addView(unlock,UiKit.matchWrap(this,0,12));

        Button quick=UiKit.primaryButton(this,"＋ Quick Add");
        quick.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        root.addView(quick);

        setContentView(sc);
    }
}
