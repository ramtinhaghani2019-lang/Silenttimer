package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_PERMISSIONS = 3301;

    private LinearLayout root;
    private TextView statusText;
    private TextView activeUntil;
    private TextView allowedSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        ensureMonitorService();
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshDashboard();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 20),
                UiKit.dp(this, 20),
                UiKit.dp(this, 28)
        );
        root.setBackgroundColor(p[0]);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 20));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams titleBoxParams =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(titleBox, titleBoxParams);

        TextView title = UiKit.title(this, "Silent Timer");
        titleBox.addView(title);

        TextView subtitle = UiKit.muted(
                this,
                "کنترل هوشمند سکوت، ویبره و تماس‌های مهم"
        );
        titleBox.addView(subtitle, UiKit.matchWrap(this, 4, 0));

        Button settings = UiKit.secondaryButton(this, "⚙");
        settings.setTextSize(22f);
        settings.setMinWidth(UiKit.dp(this, 54));
        settings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class))
        );
        header.addView(settings);

        LinearLayout statusCard = UiKit.cardLayout(this);
        root.addView(statusCard, UiKit.matchWrap(this, 0, 14));

        TextView statusTitle = UiKit.sectionTitle(this, "وضعیت");
        statusCard.addView(statusTitle);

        statusText = new TextView(this);
        statusText.setTextSize(20f);
        statusText.setTextColor(p[2]);
        statusText.setGravity(Gravity.RIGHT);
        statusText.setPadding(0, UiKit.dp(this, 10), 0, 0);
        statusCard.addView(statusText);

        activeUntil = UiKit.muted(this, "");
        statusCard.addView(activeUntil, UiKit.matchWrap(this, 6, 0));

        TextView smartSilent = UiKit.navCard(
                this,
                "سایلنت هوشمند",
                "زمان‌دار، حالت Silent/Vibrate و خروج در ساعت مشخص",
                "◷"
        );
        smartSilent.setOnClickListener(v ->
                startActivity(new Intent(this, SmartSilentActivity.class))
        );
        root.addView(smartSilent, UiKit.matchWrap(this, 0, 12));

        TextView allowedCalls = UiKit.navCard(
                this,
                "تماس‌های مجاز",
                "انتخاب چند مخاطب و کنترل زنگ خوردن در حالت بی‌صدا",
                "☎"
        );
        allowedCalls.setOnClickListener(v ->
                startActivity(new Intent(this, AllowedCallsActivity.class))
        );
        root.addView(allowedCalls, UiKit.matchWrap(this, 0, 12));

        LinearLayout quickCard = UiKit.cardLayout(this);
        root.addView(quickCard, UiKit.matchWrap(this, 0, 12));

        TextView quickTitle = UiKit.sectionTitle(this, "شروع سریع");
        quickCard.addView(quickTitle);

        TextView quickDesc = UiKit.muted(
                this,
                "برای مواقعی که فقط می‌خواهی سریع گوشی بی‌صدا شود."
        );
        quickCard.addView(quickDesc, UiKit.matchWrap(this, 4, 12));

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        quickRow.setGravity(Gravity.CENTER);
        quickCard.addView(quickRow, UiKit.matchWrap(this));

        addQuickButton(quickRow, "15 دقیقه", 15);
        addQuickButton(quickRow, "30 دقیقه", 30);
        addQuickButton(quickRow, "1 ساعت", 60);

        LinearLayout allowedCard = UiKit.cardLayout(this);
        root.addView(allowedCard, UiKit.matchWrap(this, 0, 12));

        allowedSummary = UiKit.muted(this, "");
        allowedSummary.setTextSize(14f);
        allowedCard.addView(allowedSummary);

        Button permissionButton = UiKit.secondaryButton(
                this,
                "بررسی دسترسی‌های ضروری"
        );
        permissionButton.setOnClickListener(v -> ensurePermissions());
        root.addView(permissionButton, UiKit.matchWrap(this, 0, 12));

        TextView footer = UiKit.muted(
                this,
                "بدون اینترنت  •  بدون تبلیغ  •  آماده‌به‌کار در پس‌زمینه"
        );
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, UiKit.matchWrap(this, 8, 0));

        setContentView(scroll);
        refreshDashboard();
    }

    private void addQuickButton(
            LinearLayout row,
            String text,
            int minutes
    ) {
        Button b = UiKit.secondaryButton(this, text);
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(
                UiKit.dp(this, 4),
                0,
                UiKit.dp(this, 4),
                0
        );
        row.addView(b, lp);

        b.setOnClickListener(v -> {
            if (!hasCorePermissions()) {
                ensurePermissions();
                return;
            }

            Intent i = new Intent(this, SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_START);
            i.putExtra(SilentTimerService.EXTRA_MINUTES, minutes);
            i.putExtra(
                    SilentTimerService.EXTRA_TARGET_MODE,
                    android.media.AudioManager.RINGER_MODE_SILENT
            );

            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }

            Toast.makeText(
                    this,
                    "تایمر شروع شد.",
                    Toast.LENGTH_SHORT
            ).show();
        });
    }

    private void refreshDashboard() {
        if (statusText == null) return;

        int[] p = UiKit.palette(this);

        if (AppPrefs.isTimerActive(this)) {
            long remaining =
                    Math.max(0L, AppPrefs.getEndAt(this) - System.currentTimeMillis());

            long minutes = (remaining + 59_999L) / 60_000L;

            statusText.setText("●  تایمر فعال");
            statusText.setTextColor(p[3]);

            java.text.SimpleDateFormat f =
                    new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault());

            activeUntil.setText(
                    "حدود " + minutes + " دقیقه باقی مانده  •  پایان " +
                            f.format(new java.util.Date(AppPrefs.getEndAt(this)))
            );
        } else {
            statusText.setText("●  آماده");
            statusText.setTextColor(p[2]);

            int mode =
                    ((android.media.AudioManager) getSystemService(Context.AUDIO_SERVICE))
                            .getRingerMode();

            if (mode == android.media.AudioManager.RINGER_MODE_SILENT) {
                activeUntil.setText("گوشی اکنون روی Silent است.");
            } else if (mode == android.media.AudioManager.RINGER_MODE_VIBRATE) {
                activeUntil.setText("گوشی اکنون روی Vibrate است.");
            } else {
                activeUntil.setText("گوشی در حالت صدادار است.");
            }
        }

        int count = AppPrefs.getAllowedContacts(this).size();

        allowedSummary.setText(
                "تماس‌های مجاز: " +
                        (AppPrefs.isAllowedCallsEnabled(this) ? "روشن" : "خاموش") +
                        "  •  " + count + " شماره ذخیره‌شده"
        );
    }

    private void ensureMonitorService() {
        if (!AppPrefs.isMonitoringEnabled(this)) return;

        Intent service = new Intent(this, SilentTimerService.class);
        service.setAction(SilentTimerService.ACTION_MONITOR);

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(service);
            } else {
                startService(service);
            }
        } catch (Exception ignored) {}
    }

    private boolean hasCorePermissions() {
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        boolean overlay = Settings.canDrawOverlays(this);
        boolean dnd = nm.isNotificationPolicyAccessGranted();

        boolean phone =
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                        == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.READ_CALL_LOG)
                        == PackageManager.PERMISSION_GRANTED;

        return overlay && dnd && phone;
    }

    private void ensurePermissions() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(
                    new Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())
                    )
            );
            return;
        }

        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        if (!nm.isNotificationPolicyAccessGranted()) {
            startActivity(
                    new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
            );
            return;
        }

        java.util.ArrayList<String> missing = new java.util.ArrayList<>();

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_PHONE_STATE);
        }

        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG)
                != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_CALL_LOG);
        }

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!missing.isEmpty()) {
            requestPermissions(
                    missing.toArray(new String[0]),
                    REQ_PERMISSIONS
            );
            return;
        }

        Toast.makeText(
                this,
                "همه دسترسی‌های اصلی آماده‌اند.",
                Toast.LENGTH_SHORT
        ).show();
    }
}
