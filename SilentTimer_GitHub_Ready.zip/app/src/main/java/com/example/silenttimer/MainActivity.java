package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_PHONE = 1101;

    private LinearLayout root;
    private LinearLayout timerCard;
    private LinearLayout contactsCard;
    private LinearLayout contactsList;
    private LinearLayout appearanceCard;
    private LinearLayout smartCard;

    private TextView title;
    private TextView subtitle;
    private TextView statusPill;
    private TextView timerPreview;
    private TextView timerCaption;
    private TextView footer;
    private TextView contactsCount;

    private SeekBar seekBar;
    private EditText contactNameInput;
    private EditText contactNumberInput;
    private Switch allowedSwitch;
    private Spinner themeSpinner;
    private ArrayAdapter<String> themeAdapter;

    private Button startButton;
    private Button stopButton;
    private Button permissionsButton;

    // bg, card, primary, accent, secondary, field
    private final int[][] palettes = new int[][]{
            {0xFF050505, 0xFF151515, 0xFFF8F8FA, 0xFF8B5CF6, 0xFFA7A7B2, 0xFF202024},
            {0xFF091221, 0xFF13233A, 0xFFF7FAFF, 0xFF38BDF8, 0xFFA7B7D1, 0xFF1B2D49},
            {0xFFF2F4F8, 0xFFFFFFFF, 0xFF171B29, 0xFF5A4CF2, 0xFF707789, 0xFFEDF0F5},
            {0xFF10201E, 0xAAE7FFF9, 0xFFF8FFFD, 0xFF57E6C1, 0xFFB6CEC8, 0x333FFFFF}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        loadSavedValues();
        applyTheme(AppPrefs.getTheme(this));
        refreshAll();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshAll();
        startMonitorIfReady();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        scroll.addView(
                root,
                new ScrollView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                )
        );

        statusPill = new TextView(this);
        statusPill.setText("●  آماده");
        statusPill.setTextSize(13f);
        statusPill.setGravity(Gravity.CENTER);
        statusPill.setPadding(dp(12), dp(7), dp(12), dp(7));
        LinearLayout.LayoutParams pillParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
        pillParams.gravity = Gravity.CENTER_HORIZONTAL;
        pillParams.bottomMargin = dp(12);
        root.addView(statusPill, pillParams);

        title = new TextView(this);
        title.setText("Silent Timer");
        title.setTextSize(34f);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        subtitle = new TextView(this);
        subtitle.setText("کنترل هوشمند Silent، بدون از دست دادن تماس‌های مهم");
        subtitle.setTextSize(14f);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
        root.addView(subtitle, matchWrapWithMargins(0, 4, 0, 20));

        buildTimerCard();
        buildSmartCard();
        buildContactsCard();
        buildAppearanceCard();

        permissionsButton = new Button(this);
        permissionsButton.setAllCaps(false);
        permissionsButton.setTextSize(14f);
        permissionsButton.setOnClickListener(v -> ensurePermissions(false));
        root.addView(permissionsButton, matchWrapWithMargins(0, 0, 0, 10));

        startButton = new Button(this);
        startButton.setAllCaps(false);
        startButton.setText("شروع Silent Timer");
        startButton.setTextSize(17f);
        startButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        startButton.setMinHeight(dp(56));
        startButton.setOnClickListener(v -> {
            if (!ensurePermissions(true)) return;
            startTimer();
        });
        root.addView(startButton, matchWrapWithMargins(0, 0, 0, 10));

        stopButton = new Button(this);
        stopButton.setAllCaps(false);
        stopButton.setText("پایان تایمر و بازگشت صدا");
        stopButton.setTextSize(15f);
        stopButton.setMinHeight(dp(50));
        stopButton.setOnClickListener(v -> sendServiceAction(SilentTimerService.ACTION_STOP));
        root.addView(stopButton, matchWrap());

        footer = new TextView(this);
        footer.setText("بدون اینترنت  •  بدون تبلیغ  •  پردازش روی خود گوشی");
        footer.setTextSize(12f);
        footer.setGravity(Gravity.CENTER);
        footer.setAlpha(0.82f);
        root.addView(footer, matchWrapWithMargins(0, 18, 0, 0));

        setContentView(scroll);
    }

    private void buildTimerCard() {
        timerCard = makeCard();
        root.addView(timerCard, matchWrapWithMargins(0, 0, 0, 14));

        TextView heading = makeSectionTitle("تایمر سکوت");
        timerCard.addView(heading, matchWrap());

        timerPreview = new TextView(this);
        timerPreview.setText("30:00");
        timerPreview.setTextSize(44f);
        timerPreview.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        timerPreview.setGravity(Gravity.CENTER);
        timerPreview.setLetterSpacing(0.06f);
        timerCard.addView(timerPreview, matchWrapWithMargins(0, 12, 0, 0));

        timerCaption = new TextView(this);
        timerCaption.setText("30 دقیقه");
        timerCaption.setTextSize(14f);
        timerCaption.setGravity(Gravity.CENTER);
        timerCard.addView(timerCaption, matchWrapWithMargins(0, 0, 0, 8));

        seekBar = new SeekBar(this);
        seekBar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        seekBar.setMax(31); // 15 min ... 8 hours
        seekBar.setProgress(1); // 30 min
        timerCard.addView(seekBar, matchWrapWithMargins(0, 0, 0, 10));

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int minutes = selectedMinutes();
                timerPreview.setText(formatDurationPreview(minutes));
                timerCaption.setText(formatMinutesLabel(minutes));
            }

            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        TextView quickLabel = smallLabel("انتخاب سریع");
        timerCard.addView(quickLabel, matchWrapWithMargins(0, 2, 0, 8));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        timerCard.addView(row, matchWrap());

        addPresetButton(row, "15د", 15);
        addPresetButton(row, "30د", 30);
        addPresetButton(row, "45د", 45);
        addPresetButton(row, "1س", 60);
        addPresetButton(row, "2س", 120);
    }

    private void buildSmartCard() {
        smartCard = makeCard();
        root.addView(smartCard, matchWrapWithMargins(0, 0, 0, 14));

        TextView heading = makeSectionTitle("Silent هوشمند");
        smartCard.addView(heading, matchWrap());

        TextView line1 = makeInfoLine("● وقتی از پنل سامسونگ Silent کنی، انتخاب زمان خودکار ظاهر می‌شود.");
        smartCard.addView(line1, matchWrapWithMargins(0, 8, 0, 4));

        TextView line2 = makeInfoLine("● زمان با گام‌های ۱۵ دقیقه‌ای تنظیم می‌شود.");
        smartCard.addView(line2, matchWrapWithMargins(0, 0, 0, 4));

        TextView line3 = makeInfoLine("● اگر وسط تایمر خودت صدا را روشن کنی، تایمر خودکار لغو می‌شود.");
        smartCard.addView(line3, matchWrap());
    }

    private void buildContactsCard() {
        contactsCard = makeCard();
        root.addView(contactsCard, matchWrapWithMargins(0, 0, 0, 14));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        contactsCard.addView(header, matchWrap());

        TextView heading = makeSectionTitle("تماس‌های مجاز");
        LinearLayout.LayoutParams headingP = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(heading, headingP);

        allowedSwitch = new Switch(this);
        allowedSwitch.setText("روشن");
        allowedSwitch.setTextSize(13f);
        allowedSwitch.setChecked(AppPrefs.isAllowedCallsEnabled(this));
        header.addView(allowedSwitch);

        allowedSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppPrefs.setAllowedCallsEnabled(MainActivity.this, isChecked);
            allowedSwitch.setText(isChecked ? "روشن" : "خاموش");
            sendServiceAction(SilentTimerService.ACTION_REFRESH);
        });

        TextView note = makeInfoLine(
                "وقتی روشن باشد، شماره‌های این لیست حتی در Silent دستی یا تایمر می‌توانند با صدا زنگ بخورند."
        );
        contactsCard.addView(note, matchWrapWithMargins(0, 8, 0, 12));

        contactsCount = new TextView(this);
        contactsCount.setTextSize(13f);
        contactsCard.addView(contactsCount, matchWrapWithMargins(0, 0, 0, 8));

        contactsList = new LinearLayout(this);
        contactsList.setOrientation(LinearLayout.VERTICAL);
        contactsCard.addView(contactsList, matchWrap());

        contactNameInput = new EditText(this);
        contactNameInput.setHint("نام (اختیاری)");
        contactNameInput.setSingleLine(true);
        contactNameInput.setTextSize(15f);
        contactNameInput.setPadding(dp(14), dp(11), dp(14), dp(11));
        contactsCard.addView(contactNameInput, matchWrapWithMargins(0, 10, 0, 8));

        contactNumberInput = new EditText(this);
        contactNumberInput.setHint("شماره تماس");
        contactNumberInput.setInputType(InputType.TYPE_CLASS_PHONE);
        contactNumberInput.setSingleLine(true);
        contactNumberInput.setTextDirection(View.TEXT_DIRECTION_LTR);
        contactNumberInput.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        contactNumberInput.setTextSize(16f);
        contactNumberInput.setPadding(dp(14), dp(11), dp(14), dp(11));
        contactsCard.addView(contactNumberInput, matchWrapWithMargins(0, 0, 0, 8));

        Button addContact = new Button(this);
        addContact.setAllCaps(false);
        addContact.setText("＋ افزودن شماره");
        addContact.setTextSize(14f);
        addContact.setOnClickListener(v -> addContact());
        contactsCard.addView(addContact, matchWrap());
    }

    private void buildAppearanceCard() {
        appearanceCard = makeCard();
        root.addView(appearanceCard, matchWrapWithMargins(0, 0, 0, 14));

        TextView heading = makeSectionTitle("ظاهر برنامه");
        appearanceCard.addView(heading, matchWrapWithMargins(0, 0, 0, 10));

        themeSpinner = new Spinner(this);
        String[] themes = {"AMOLED", "Midnight", "Light", "Glass"};

        themeAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, themes) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convertView, parent);
                int themeIndex = AppPrefs.getTheme(MainActivity.this);
                if (themeIndex < 0 || themeIndex >= palettes.length) themeIndex = 0;
                tv.setTextColor(palettes[themeIndex][2]);
                tv.setTextSize(16f);
                tv.setGravity(Gravity.CENTER);
                tv.setPadding(dp(14), dp(12), dp(14), dp(12));
                return tv;
            }

            @Override
            public View getDropDownView(int position, View convertView, ViewGroup parent) {
                TextView tv = (TextView) super.getDropDownView(position, convertView, parent);
                tv.setTextColor(Color.BLACK);
                tv.setBackgroundColor(Color.WHITE);
                tv.setTextSize(16f);
                tv.setPadding(dp(18), dp(14), dp(18), dp(14));
                return tv;
            }
        };

        themeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        themeSpinner.setAdapter(themeAdapter);
        appearanceCard.addView(themeSpinner, matchWrap());

        themeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                AppPrefs.setTheme(MainActivity.this, position);
                applyTheme(position);
            }

            @Override
            public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        TextView tileHint = makeInfoLine(
                "Quick Settings: از بخش ویرایش دکمه‌های پنل سامسونگ، Silent Timer را یک‌بار به پنل اضافه کن. یک لمس = ۳۰ دقیقه."
        );
        appearanceCard.addView(tileHint, matchWrapWithMargins(0, 10, 0, 0));
    }

    private void addPresetButton(LinearLayout row, String label, int minutes) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(label);
        b.setTextSize(12f);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(3), dp(8), dp(3), dp(8));

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.setMargins(dp(2), 0, dp(2), 0);
        row.addView(b, p);

        b.setOnClickListener(v -> setMinutes(minutes));
    }

    private void setMinutes(int minutes) {
        minutes = Math.max(15, Math.min(480, ((minutes + 14) / 15) * 15));
        seekBar.setProgress((minutes / 15) - 1);
        timerPreview.setText(formatDurationPreview(minutes));
        timerCaption.setText(formatMinutesLabel(minutes));
    }

    private int selectedMinutes() {
        return (seekBar.getProgress() + 1) * 15;
    }

    private void loadSavedValues() {
        int minutes = AppPrefs.getMinutes(this);
        setMinutes(minutes);

        int theme = AppPrefs.getTheme(this);
        if (theme >= 0 && theme < themeSpinner.getCount()) {
            themeSpinner.setSelection(theme);
        }

        allowedSwitch.setChecked(AppPrefs.isAllowedCallsEnabled(this));
        allowedSwitch.setText(allowedSwitch.isChecked() ? "روشن" : "خاموش");
        renderContacts();
    }

    private void addContact() {
        String name = contactNameInput.getText().toString().trim();
        String number = contactNumberInput.getText().toString().trim();

        if (number.isEmpty()) {
            Toast.makeText(this, "شماره را وارد کن.", Toast.LENGTH_SHORT).show();
            return;
        }

        AppPrefs.addAllowedContact(this, name, number);
        contactNameInput.setText("");
        contactNumberInput.setText("");
        renderContacts();
        sendServiceAction(SilentTimerService.ACTION_REFRESH);
    }

    private void renderContacts() {
        if (contactsList == null) return;

        contactsList.removeAllViews();
        List<AppPrefs.ContactEntry> contacts = AppPrefs.getAllowedContacts(this);
        contactsCount.setText(contacts.size() + " شماره در لیست");

        if (contacts.isEmpty()) {
            TextView empty = makeInfoLine("هنوز شماره‌ای اضافه نشده.");
            empty.setGravity(Gravity.CENTER);
            contactsList.addView(empty, matchWrapWithMargins(0, 4, 0, 4));
            return;
        }

        for (int i = 0; i < contacts.size(); i++) {
            final int index = i;
            AppPrefs.ContactEntry entry = contacts.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(8), dp(12), dp(8));
            row.setBackground(roundRect(currentPalette()[5], 14));

            TextView info = new TextView(this);
            String displayName = entry.name.trim().isEmpty() ? "شماره مجاز" : entry.name.trim();
            info.setText(displayName + "\n" + entry.number);
            info.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
            info.setTextSize(14f);
            info.setTextColor(currentPalette()[2]);
            LinearLayout.LayoutParams infoP = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(info, infoP);

            Button remove = new Button(this);
            remove.setText("حذف");
            remove.setAllCaps(false);
            remove.setTextSize(12f);
            remove.setMinWidth(0);
            remove.setMinimumWidth(0);
            remove.setPadding(dp(10), dp(6), dp(10), dp(6));
            remove.setOnClickListener(v -> {
                AppPrefs.removeAllowedContact(MainActivity.this, index);
                renderContacts();
                sendServiceAction(SilentTimerService.ACTION_REFRESH);
            });
            row.addView(remove);

            contactsList.addView(row, matchWrapWithMargins(0, 0, 0, 6));
        }
    }

    private boolean ensurePermissions(boolean starting) {
        if (!Settings.canDrawOverlays(this)) {
            if (starting) {
                Toast.makeText(this, "ابتدا اجازه نمایش پنجره هوشمند را بده.", Toast.LENGTH_LONG).show();
            }

            Intent i = new Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())
            );
            startActivity(i);
            return false;
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            if (starting) {
                Toast.makeText(this, "ابتدا اجازه کنترل حالت Silent را بده.", Toast.LENGTH_LONG).show();
            }

            startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            return false;
        }

        List<String> missing = new ArrayList<>();

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_PHONE_STATE);
        }

        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_CALL_LOG);
        }

        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQ_PHONE);
            return false;
        }

        refreshPermissionButton();
        startMonitorService();
        return true;
    }

    private boolean corePermissionsReady() {
        if (!Settings.canDrawOverlays(this)) return false;

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) return false;

        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        return Build.VERSION.SDK_INT < 33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void startMonitorIfReady() {
        if (corePermissionsReady()) {
            startMonitorService();
        }
    }

    private void startMonitorService() {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_MONITOR);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
    }

    private void startTimer() {
        int minutes = selectedMinutes();
        AppPrefs.setMinutes(this, minutes);

        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_START);
        i.putExtra(SilentTimerService.EXTRA_MINUTES, minutes);

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }

        statusPill.setText("●  تایمر فعال");
        Toast.makeText(this, "Silent Timer شروع شد.", Toast.LENGTH_SHORT).show();
        moveTaskToBack(true);
    }

    private void sendServiceAction(String action) {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(action);

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
    }

    private void refreshAll() {
        refreshPermissionButton();
        refreshTimerState();
        renderContacts();

        if (allowedSwitch != null) {
            allowedSwitch.setChecked(AppPrefs.isAllowedCallsEnabled(this));
            allowedSwitch.setText(allowedSwitch.isChecked() ? "روشن" : "خاموش");
        }
    }

    private void refreshPermissionButton() {
        if (permissionsButton == null) return;
        permissionsButton.setText(
                corePermissionsReady()
                        ? "مجوزها و پایش هوشمند آماده‌اند ✓"
                        : "بررسی و فعال‌سازی مجوزها"
        );
    }

    private void refreshTimerState() {
        if (statusPill == null) return;
        statusPill.setText(AppPrefs.isTimerActive(this) ? "●  تایمر فعال" : "●  آماده");
    }

    private String formatDurationPreview(int minutes) {
        if (minutes < 60) {
            return String.format(Locale.US, "%02d:00", minutes);
        }

        int hours = minutes / 60;
        int mins = minutes % 60;
        return String.format(Locale.US, "%02d:%02d:00", hours, mins);
    }

    private String formatMinutesLabel(int minutes) {
        if (minutes < 60) return minutes + " دقیقه";

        int h = minutes / 60;
        int m = minutes % 60;

        if (m == 0) return h + " ساعت";
        return h + " ساعت و " + m + " دقیقه";
    }

    private LinearLayout makeCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(17), dp(17), dp(17), dp(17));
        card.setElevation(dp(2));
        return card;
    }

    private TextView makeSectionTitle(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(17f);
        tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    private TextView makeInfoLine(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13f);
        tv.setGravity(Gravity.RIGHT);
        tv.setLineSpacing(0f, 1.15f);
        return tv;
    }

    private TextView smallLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12f);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private void applyTheme(int index) {
        if (index < 0 || index >= palettes.length) index = 0;
        int[] p = palettes[index];

        root.setBackgroundColor(p[0]);

        title.setTextColor(p[2]);
        timerPreview.setTextColor(p[2]);
        timerCaption.setTextColor(p[4]);
        subtitle.setTextColor(p[4]);
        footer.setTextColor(p[4]);

        timerCard.setBackground(cardBackground(p[1], p[3], index == 3));
        smartCard.setBackground(cardBackground(p[1], p[3], index == 3));
        contactsCard.setBackground(cardBackground(p[1], p[3], index == 3));
        appearanceCard.setBackground(cardBackground(p[1], p[3], index == 3));

        tintTextChildren(timerCard, p);
        tintTextChildren(smartCard, p);
        tintTextChildren(contactsCard, p);
        tintTextChildren(appearanceCard, p);

        contactNameInput.setTextColor(p[2]);
        contactNumberInput.setTextColor(p[2]);
        contactNameInput.setHintTextColor(withAlpha(p[4], 0xCC));
        contactNumberInput.setHintTextColor(withAlpha(p[4], 0xCC));
        contactNameInput.setBackground(roundRect(p[5], 15));
        contactNumberInput.setBackground(roundRect(p[5], 15));

        themeSpinner.setBackground(roundRect(p[5], 15));
        if (themeAdapter != null) themeAdapter.notifyDataSetChanged();

        statusPill.setTextColor(p[3]);
        statusPill.setBackground(roundRect(withAlpha(p[3], 0x26), 100));

        seekBar.setProgressTintList(ColorStateList.valueOf(p[3]));
        seekBar.setThumbTintList(ColorStateList.valueOf(p[3]));

        stylePrimaryButton(startButton, p[3]);
        styleSecondaryButton(stopButton, p[1], p[2], p[3]);
        styleSecondaryButton(permissionsButton, p[5], p[4], p[3]);

        if (allowedSwitch != null) {
            allowedSwitch.setTextColor(p[2]);
        }

        renderContacts();

        getWindow().setStatusBarColor(p[0]);
        getWindow().setNavigationBarColor(p[0]);

        if (Build.VERSION.SDK_INT >= 23) {
            int flags = getWindow().getDecorView().getSystemUiVisibility();
            if (index == 2) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    private void tintTextChildren(ViewGroup group, int[] p) {
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);

            if (child instanceof TextView &&
                    !(child instanceof Button) &&
                    !(child instanceof EditText) &&
                    !(child instanceof Switch)) {
                TextView tv = (TextView) child;
                tv.setTextColor(
                        tv.getTextSize() / getResources().getDisplayMetrics().scaledDensity >= 16f
                                ? p[2]
                                : p[4]
                );
            }

            if (child instanceof ViewGroup) {
                tintTextChildren((ViewGroup) child, p);
            }
        }
    }

    private int[] currentPalette() {
        int index = AppPrefs.getTheme(this);
        if (index < 0 || index >= palettes.length) index = 0;
        return palettes[index];
    }

    private void stylePrimaryButton(Button b, int accent) {
        if (b == null) return;
        b.setTextColor(Color.WHITE);
        b.setBackground(roundRect(accent, 18));
        b.setPadding(dp(12), dp(14), dp(12), dp(14));
        b.setElevation(dp(3));
    }

    private void styleSecondaryButton(Button b, int bg, int fg, int border) {
        if (b == null) return;
        b.setTextColor(fg);
        GradientDrawable g = roundRect(bg, 18);
        g.setStroke(dp(1), withAlpha(border, 0x66));
        b.setBackground(g);
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
        b.setElevation(0f);
    }

    private GradientDrawable cardBackground(int color, int accent, boolean glass) {
        GradientDrawable g = roundRect(color, 24);
        g.setStroke(dp(1), glass ? withAlpha(Color.WHITE, 0x55) : withAlpha(accent, 0x22));
        return g;
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    private LinearLayout.LayoutParams matchWrapWithMargins(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
