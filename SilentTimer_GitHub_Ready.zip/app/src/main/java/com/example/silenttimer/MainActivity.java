package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_PHONE = 1101;

    private LinearLayout root;
    private TextView title;
    private TextView minutesLabel;
    private EditText numberInput;
    private SeekBar seekBar;
    private Spinner themeSpinner;
    private Button startButton;
    private Button stopButton;
    private Button permissionsButton;

    private final int[][] palettes = new int[][]{
            {0xFF000000, 0xFF141414, 0xFFFFFFFF, 0xFF7C4DFF}, // AMOLED
            {0xFF0B1020, 0xFF18213A, 0xFFF5F7FF, 0xFF5CD6FF}, // Midnight
            {0xFFEEF2F7, 0xFFFFFFFF, 0xFF172033, 0xFF4355E8}, // Light
            {0xFF17201F, 0xAAFFFFFF, 0xFFFFFFFF, 0xFF7BE7C4}  // Glass-ish
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        loadSavedValues();
        applyTheme(AppPrefs.getTheme(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshPermissionButton();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(22), dp(26), dp(22), dp(26));

        title = new TextView(this);
        title.setText("Silent Timer");
        title.setTextSize(30f);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(20));
        root.addView(title, matchWrap());

        minutesLabel = new TextView(this);
        minutesLabel.setTextSize(18f);
        root.addView(minutesLabel, matchWrap());

        seekBar = new SeekBar(this);
        seekBar.setMax(179); // 1..180
        seekBar.setProgress(29);
        root.addView(seekBar, matchWrap());
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int minutes = progress + 1;
                minutesLabel.setText("مدت سکوت: " + minutes + " دقیقه");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        numberInput = new EditText(this);
        numberInput.setHint("شماره اضطراری، مثال: 0912...");
        numberInput.setInputType(InputType.TYPE_CLASS_PHONE);
        numberInput.setSingleLine(true);
        numberInput.setPadding(dp(14), dp(12), dp(14), dp(12));
        root.addView(numberInput, matchWrapWithMargins(0, 14, 0, 10));

        TextView note = new TextView(this);
        note.setText("اگر این شماره هنگام فعال بودن تایمر تماس بگیرد، برنامه تلاش می‌کند فقط برای همان تماس صدا را موقتاً برگرداند.");
        note.setTextSize(13f);
        note.setAlpha(0.82f);
        root.addView(note, matchWrapWithMargins(0, 0, 0, 18));

        themeSpinner = new Spinner(this);
        String[] themes = {"AMOLED", "Midnight", "Light", "Glass"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, themes);
        themeSpinner.setAdapter(adapter);
        root.addView(themeSpinner, matchWrapWithMargins(0, 0, 0, 18));
        themeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                AppPrefs.setTheme(MainActivity.this, position);
                applyTheme(position);
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        permissionsButton = new Button(this);
        permissionsButton.setText("بررسی مجوزها");
        permissionsButton.setOnClickListener(v -> ensurePermissions(false));
        root.addView(permissionsButton, matchWrapWithMargins(0, 0, 0, 10));

        startButton = new Button(this);
        startButton.setText("شروع سایلنت");
        startButton.setOnClickListener(v -> {
            if (!ensurePermissions(true)) return;
            startTimer();
        });
        root.addView(startButton, matchWrapWithMargins(0, 0, 0, 10));

        stopButton = new Button(this);
        stopButton.setText("پایان تایمر و بازگشت صدا");
        stopButton.setOnClickListener(v -> {
            Intent i = new Intent(this, SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_STOP);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        });
        root.addView(stopButton, matchWrap());

        setContentView(root);
    }

    private void loadSavedValues() {
        int minutes = Math.max(1, Math.min(180, AppPrefs.getMinutes(this)));
        seekBar.setProgress(minutes - 1);
        minutesLabel.setText("مدت سکوت: " + minutes + " دقیقه");
        numberInput.setText(AppPrefs.getEmergencyNumber(this));
        int theme = AppPrefs.getTheme(this);
        if (theme >= 0 && theme < themeSpinner.getCount()) themeSpinner.setSelection(theme);
    }

    private boolean ensurePermissions(boolean starting) {
        if (!Settings.canDrawOverlays(this)) {
            if (starting) Toast.makeText(this, "ابتدا اجازه نمایش تایمر شناور را بده.", Toast.LENGTH_LONG).show();
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return false;
        }

        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (!nm.isNotificationPolicyAccessGranted()) {
            if (starting) Toast.makeText(this, "ابتدا اجازه کنترل حالت بی‌صدا را بده.", Toast.LENGTH_LONG).show();
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
            return false;
        }

        List<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_PHONE_STATE);
        }
        if (checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_CALL_LOG);
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!missing.isEmpty()) {
            requestPermissions(missing.toArray(new String[0]), REQ_PHONE);
            return false;
        }

        refreshPermissionButton();
        return true;
    }

    private void startTimer() {
        int minutes = seekBar.getProgress() + 1;
        String number = numberInput.getText().toString().trim();
        AppPrefs.setMinutes(this, minutes);
        AppPrefs.setEmergencyNumber(this, number);

        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_START);
        i.putExtra(SilentTimerService.EXTRA_MINUTES, minutes);
        i.putExtra(SilentTimerService.EXTRA_EMERGENCY_NUMBER, number);

        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        Toast.makeText(this, "تایمر شروع شد.", Toast.LENGTH_SHORT).show();
        moveTaskToBack(true);
    }

    private void refreshPermissionButton() {
        boolean overlay = Settings.canDrawOverlays(this);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        boolean dnd = nm.isNotificationPolicyAccessGranted();
        boolean phone = checkSelfPermission(Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
                checkSelfPermission(Manifest.permission.READ_CALL_LOG) == PackageManager.PERMISSION_GRANTED;

        if (permissionsButton != null) {
            permissionsButton.setText((overlay && dnd && phone) ? "مجوزهای اصلی آماده‌اند ✓" : "بررسی و فعال‌سازی مجوزها");
        }
    }

    private void applyTheme(int index) {
        if (index < 0 || index >= palettes.length) index = 0;
        int[] p = palettes[index];
        root.setBackgroundColor(p[0]);
        title.setTextColor(p[2]);
        minutesLabel.setTextColor(p[2]);

        for (int i = 0; i < root.getChildCount(); i++) {
            View child = root.getChildAt(i);
            if (child instanceof TextView && !(child instanceof Button) && !(child instanceof EditText)) {
                ((TextView) child).setTextColor(p[2]);
            }
        }

        numberInput.setTextColor(p[2]);
        numberInput.setHintTextColor(withAlpha(p[2], 0x88));
        numberInput.setBackground(roundRect(p[1], 18));

        styleButton(permissionsButton, p[3], Color.WHITE);
        styleButton(startButton, p[3], Color.WHITE);
        styleButton(stopButton, p[1], p[2]);
        getWindow().setStatusBarColor(p[0]);
        getWindow().setNavigationBarColor(p[0]);
    }

    private void styleButton(Button b, int bg, int fg) {
        b.setTextColor(fg);
        b.setBackground(roundRect(bg, 18));
        b.setPadding(dp(12), dp(12), dp(12), dp(12));
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrapWithMargins(int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = matchWrap();
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
