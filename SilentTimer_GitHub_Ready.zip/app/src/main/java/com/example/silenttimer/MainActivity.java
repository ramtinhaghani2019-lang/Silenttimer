package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_PERMISSIONS = 3301;

    private final Handler handler = new Handler(Looper.getMainLooper());

    private RingTimerView ring;
    private TextView heroTime;
    private TextView heroState;
    private TextView heroSub;
    private TextView allowedSummary;

    private final Runnable uiTicker = new Runnable() {
        @Override
        public void run() {
            refreshDashboard();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        ensureMonitorService();
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(uiTicker);
        handler.post(uiTicker);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(uiTicker);
        super.onPause();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 18)
        );
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        LinearLayout headText = new LinearLayout(this);
        headText.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams htp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        header.addView(headText, htp);

        TextView title = UiKit.title(this, "Silent Timer");
        headText.addView(title);

        TextView subtitle = UiKit.muted(this, "سکوت هوشمند، بدون از دست دادن تماس مهم");
        headText.addView(subtitle, UiKit.matchWrap(this, 3, 0));

        Button settings = UiKit.secondaryButton(this, "⚙");
        settings.setTextSize(21f);
        settings.setMinWidth(UiKit.dp(this, 54));
        settings.setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class))
        );
        header.addView(settings);

        FrameLayout hero = new FrameLayout(this);
        hero.setBackground(UiKit.accentCard(this));
        hero.setPadding(
                UiKit.dp(this, 18),
                UiKit.dp(this, 22),
                UiKit.dp(this, 18),
                UiKit.dp(this, 22)
        );
        root.addView(hero, UiKit.matchWrap(this, 0, 16));

        AuraView aura = new AuraView(this);
        FrameLayout.LayoutParams auraLp =
                new FrameLayout.LayoutParams(UiKit.dp(this, 270), UiKit.dp(this, 270));
        auraLp.gravity = Gravity.CENTER;
        hero.addView(aura, auraLp);

        ring = new RingTimerView(this);
        ring.setColors(p[4], UiKit.withAlpha(p[5], 0x30));
        FrameLayout.LayoutParams ringLp =
                new FrameLayout.LayoutParams(UiKit.dp(this, 220), UiKit.dp(this, 220));
        ringLp.gravity = Gravity.CENTER;
        hero.addView(ring, ringLp);

        LinearLayout heroText = new LinearLayout(this);
        heroText.setOrientation(LinearLayout.VERTICAL);
        heroText.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams heroTextLp =
                new FrameLayout.LayoutParams(UiKit.dp(this, 190), UiKit.dp(this, 190));
        heroTextLp.gravity = Gravity.CENTER;
        hero.addView(heroText, heroTextLp);

        heroState = new TextView(this);
        heroState.setTextColor(p[4]);
        heroState.setTextSize(14f);
        heroState.setGravity(Gravity.CENTER);
        heroText.addView(heroState, UiKit.matchWrap(this));

        heroTime = new TextView(this);
        heroTime.setTextColor(p[3]);
        heroTime.setTextSize(34f);
        heroTime.setGravity(Gravity.CENTER);
        heroTime.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        heroText.addView(heroTime, UiKit.matchWrap(this, 7, 4));

        heroSub = UiKit.muted(this, "");
        heroSub.setGravity(Gravity.CENTER);
        heroText.addView(heroSub, UiKit.matchWrap(this));

        TextView quickTitle = UiKit.sectionTitle(this, "شروع سریع");
        root.addView(quickTitle, UiKit.matchWrap(this, 0, 10));

        LinearLayout quickRow = new LinearLayout(this);
        quickRow.setOrientation(LinearLayout.HORIZONTAL);
        quickRow.setGravity(Gravity.CENTER);
        root.addView(quickRow, UiKit.matchWrap(this, 0, 16));

        addQuick(quickRow, "15 دقیقه", 15);
        addQuick(quickRow, "30 دقیقه", 30);
        addQuick(quickRow, "1 ساعت", 60);

        TextView smart = UiKit.navCard(
                this,
                "◷",
                "سایلنت هوشمند",
                "Silent / Vibrate، زمان‌بندی و خروج در ساعت مشخص"
        );
        smart.setOnClickListener(v ->
                startActivity(new Intent(this, SmartSilentActivity.class))
        );
        root.addView(smart, UiKit.matchWrap(this, 0, 12));

        TextView calls = UiKit.navCard(
                this,
                "☎",
                "تماس‌های مجاز",
                "انتخاب مخاطب، چند شماره و کنترل زنگ خوردن"
        );
        calls.setOnClickListener(v ->
                startActivity(new Intent(this, AllowedCallsActivity.class))
        );
        root.addView(calls, UiKit.matchWrap(this, 0, 12));

        LinearLayout allowedCard = UiKit.cardLayout(this);
        allowedSummary = UiKit.muted(this, "");
        allowedSummary.setTextSize(14f);
        allowedCard.addView(allowedSummary);
        root.addView(allowedCard, UiKit.matchWrap(this, 0, 12));


        TextView foot = UiKit.muted(
                this,
                "بدون اینترنت  •  بدون تبلیغ  •  آماده‌به‌کار در پس‌زمینه"
        );
        foot.setGravity(Gravity.CENTER);
        root.addView(foot, UiKit.matchWrap(this, 8, 12));

        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        LinearLayout bottom = UiKit.bottomNav(
                this,
                0,
                v -> {},
                v -> startActivity(new Intent(this, SmartSilentActivity.class)),
                v -> startActivity(new Intent(this, AllowedCallsActivity.class))
        );
        LinearLayout.LayoutParams bottomLp = UiKit.matchWrap(this);
        bottomLp.setMargins(
                UiKit.dp(this, 16),
                0,
                UiKit.dp(this, 16),
                UiKit.dp(this, 12)
        );
        screen.addView(bottom, bottomLp);

        setContentView(screen);
        refreshDashboard();
    }

    private void addQuick(LinearLayout row, String text, int minutes) {
        TextView chip = UiKit.chip(this, text, false);
        LinearLayout.LayoutParams lp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(UiKit.dp(this, 4), 0, UiKit.dp(this, 4), 0);
        row.addView(chip, lp);

        chip.setOnClickListener(v -> {
            if (!hasCorePermissions()) {
                Intent setup = new Intent(this, SettingsActivity.class);
                setup.putExtra(SettingsActivity.EXTRA_START_SETUP, true);
                startActivity(setup);
                Toast.makeText(
                        this,
                        "ابتدا راه‌اندازی دسترسی‌ها را کامل کن.",
                        Toast.LENGTH_SHORT
                ).show();
                return;
            }

            Intent i = new Intent(this, SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_START);
            i.putExtra(SilentTimerService.EXTRA_MINUTES, minutes);
            i.putExtra(
                    SilentTimerService.EXTRA_TARGET_MODE,
                    AudioManager.RINGER_MODE_SILENT
            );

            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(i);
            } else {
                startService(i);
            }

            Toast.makeText(this, "تایمر شروع شد.", Toast.LENGTH_SHORT).show();
        });
    }

    private void refreshDashboard() {
        if (heroTime == null) return;

        int[] p = UiKit.palette(this);
        long now = System.currentTimeMillis();
        long endAt = AppPrefs.getEndAt(this);
        long startAt = AppPrefs.getStartAt(this);

        if (endAt > now) {
            long remaining = endAt - now;
            long totalSec = remaining / 1000L;
            long h = totalSec / 3600L;
            long m = (totalSec % 3600L) / 60L;
            long s = totalSec % 60L;

            heroState.setText("●  تایمر فعال");
            heroTime.setText(
                    h > 0
                            ? String.format(Locale.US, "%02d:%02d:%02d", h, m, s)
                            : String.format(Locale.US, "%02d:%02d", m, s)
            );

            SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.getDefault());
            heroSub.setText(
                    (AppPrefs.getTargetRingerMode(this) == AudioManager.RINGER_MODE_VIBRATE
                            ? "Vibrate"
                            : "Silent")
                            + "  •  پایان " + f.format(new Date(endAt))
            );

            float progress = 0f;
            if (startAt > 0 && endAt > startAt) {
                progress = 1f - ((float) remaining / (float) (endAt - startAt));
            }
            ring.setProgress(progress);
        } else {
            AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            int mode = am.getRingerMode();

            heroState.setText("●  آماده");
            heroTime.setText(
                    mode == AudioManager.RINGER_MODE_SILENT
                            ? "Silent"
                            : mode == AudioManager.RINGER_MODE_VIBRATE
                            ? "Vibrate"
                            : "Sound"
            );
            heroSub.setText("برای شروع یکی از زمان‌ها را انتخاب کن.");
            ring.setProgress(0f);
        }

        int count = AppPrefs.getAllowedContacts(this).size();
        allowedSummary.setText(
                "تماس‌های مجاز  •  "
                        + (AppPrefs.isAllowedCallsEnabled(this) ? "روشن" : "خاموش")
                        + "  •  " + count + " مخاطب"
        );
    }

    private void ensureMonitorService() {
        if (!AppPrefs.isMonitoringEnabled(this)) return;

        Intent service = new Intent(this, SilentTimerService.class);
        service.setAction(SilentTimerService.ACTION_MONITOR);

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                startForegroundService(service);
            } else {
                startService(service);
            }
        } catch (Exception ignored) {}
    }

    private boolean hasCorePermissions() {
        NotificationManager nm =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        boolean overlay = Settings.canDrawOverlays(this);
        boolean dnd = nm.isNotificationPolicyAccessGranted();
        boolean phone =
                checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                        == PackageManager.PERMISSION_GRANTED;

        return overlay && dnd && phone;
    }

}

