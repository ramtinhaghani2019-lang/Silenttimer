package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;

public final class AppPrefs {
    private static final String NAME = "silent_timer_prefs";

    private AppPrefs() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static void setMinutes(Context c, int value) {
        prefs(c).edit().putInt("minutes", value).apply();
    }

    public static int getMinutes(Context c) {
        return prefs(c).getInt("minutes", 30);
    }

    public static void setEmergencyNumber(Context c, String value) {
        prefs(c).edit().putString("emergency_number", value == null ? "" : value.trim()).apply();
    }

    public static String getEmergencyNumber(Context c) {
        return prefs(c).getString("emergency_number", "");
    }

    public static void setTheme(Context c, int value) {
        prefs(c).edit().putInt("theme", value).apply();
    }

    public static int getTheme(Context c) {
        return prefs(c).getInt("theme", 0);
    }

    public static void setEndAt(Context c, long value) {
        prefs(c).edit().putLong("end_at", value).apply();
    }

    public static long getEndAt(Context c) {
        return prefs(c).getLong("end_at", 0L);
    }

    public static void setOriginalRingerMode(Context c, int value) {
        prefs(c).edit().putInt("original_ringer_mode", value).apply();
    }

    public static int getOriginalRingerMode(Context c, int fallback) {
        return prefs(c).getInt("original_ringer_mode", fallback);
    }

    public static void clearTimer(Context c) {
        prefs(c).edit().remove("end_at").apply();
    }
}
