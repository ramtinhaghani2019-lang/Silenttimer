package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class AppPrefs {
    private static final String NAME = "silent_timer_prefs";
    private static final String KEY_CONTACTS = "allowed_contacts_json";

    private AppPrefs() {}

    public static final class ContactEntry {
        public final String name;
        public final String number;

        public ContactEntry(String name, String number) {
            this.name = name == null ? "" : name;
            this.number = number == null ? "" : number;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static void setMinutes(Context c, int value) {
        int v = Math.max(5, Math.min(720, value));
        v = ((v + 4) / 5) * 5;
        prefs(c).edit().putInt("minutes", v).apply();
    }

    public static int getMinutes(Context c) {
        int v = prefs(c).getInt("minutes", 30);
        v = Math.max(5, Math.min(720, v));
        return ((v + 4) / 5) * 5;
    }

    public static void setTheme(Context c, int value) {
        prefs(c).edit().putInt("theme", value).apply();
    }

    public static int getTheme(Context c) {
        return prefs(c).getInt("theme", 0);
    }

    public static void setEndAt(Context c, long value) {
        prefs(c).edit().putLong("end_at", value).apply();
    }

    public static long getEndAt(Context c) {
        return prefs(c).getLong("end_at", 0L);
    }

    public static boolean isTimerActive(Context c) {
        return getEndAt(c) > System.currentTimeMillis();
    }

    public static void setOriginalRingerMode(Context c, int value) {
        prefs(c).edit().putInt("original_ringer_mode", value).apply();
    }

    public static int getOriginalRingerMode(Context c, int fallback) {
        return prefs(c).getInt("original_ringer_mode", fallback);
    }

    public static void setTargetRingerMode(Context c, int value) {
        prefs(c).edit().putInt("target_ringer_mode", value).apply();
    }

    public static int getTargetRingerMode(Context c) {
        return prefs(c).getInt("target_ringer_mode", AudioManager.RINGER_MODE_SILENT);
    }

    public static void clearTimer(Context c) {
        prefs(c).edit()
                .remove("end_at")
                .remove("original_ringer_mode")
                .remove("target_ringer_mode")
                .apply();
    }

    public static void setAllowedCallsEnabled(Context c, boolean value) {
        prefs(c).edit().putBoolean("allowed_calls_enabled", value).apply();
    }

    public static boolean isAllowedCallsEnabled(Context c) {
        return prefs(c).getBoolean("allowed_calls_enabled", true);
    }

    public static void setMonitoringEnabled(Context c, boolean value) {
        prefs(c).edit().putBoolean("monitoring_enabled", value).apply();
    }

    public static boolean isMonitoringEnabled(Context c) {
        return prefs(c).getBoolean("monitoring_enabled", true);
    }

    public static void setLastManualMode(Context c, int mode) {
        prefs(c).edit().putInt("last_manual_mode", mode).apply();
    }

    public static int getLastManualMode(Context c) {
        return prefs(c).getInt("last_manual_mode", AudioManager.RINGER_MODE_SILENT);
    }

    public static List<ContactEntry> getAllowedContacts(Context c) {
        migrateLegacyNumberIfNeeded(c);

        List<ContactEntry> result = new ArrayList<>();
        String raw = prefs(c).getString(KEY_CONTACTS, "[]");

        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj == null) continue;

                String name = obj.optString("name", "");
                String number = obj.optString("number", "");

                if (!number.trim().isEmpty()) {
                    result.add(new ContactEntry(name, number));
                }
            }
        } catch (Exception ignored) {}

        return result;
    }

    public static void addAllowedContact(Context c, String name, String number) {
        String cleanNumber = number == null ? "" : number.trim();
        if (cleanNumber.isEmpty()) return;

        List<ContactEntry> list = getAllowedContacts(c);

        for (ContactEntry entry : list) {
            if (numbersMatch(entry.number, cleanNumber)) return;
        }

        list.add(new ContactEntry(
                name == null ? "" : name.trim(),
                cleanNumber
        ));

        saveContacts(c, list);
    }

    public static void removeAllowedContact(Context c, int index) {
        List<ContactEntry> list = getAllowedContacts(c);
        if (index < 0 || index >= list.size()) return;
        list.remove(index);
        saveContacts(c, list);
    }

    public static boolean isAllowedNumber(Context c, String incoming) {
        if (!isAllowedCallsEnabled(c)) return false;
        if (incoming == null || incoming.trim().isEmpty()) return false;

        for (ContactEntry entry : getAllowedContacts(c)) {
            if (numbersMatch(entry.number, incoming)) return true;
        }
        return false;
    }

    private static void saveContacts(Context c, List<ContactEntry> list) {
        JSONArray array = new JSONArray();

        try {
            for (ContactEntry entry : list) {
                JSONObject obj = new JSONObject();
                obj.put("name", entry.name);
                obj.put("number", entry.number);
                array.put(obj);
            }
        } catch (Exception ignored) {}

        prefs(c).edit().putString(KEY_CONTACTS, array.toString()).apply();
    }

    private static void migrateLegacyNumberIfNeeded(Context c) {
        SharedPreferences p = prefs(c);
        if (p.getBoolean("legacy_number_migrated", false)) return;

        String oldNumber = p.getString("emergency_number", "");

        if (oldNumber != null && !oldNumber.trim().isEmpty()) {
            List<ContactEntry> list = new ArrayList<>();
            list.add(new ContactEntry("شماره قبلی", oldNumber.trim()));
            saveContacts(c, list);
        }

        p.edit().putBoolean("legacy_number_migrated", true).apply();
    }

    public static boolean numbersMatch(String a, String b) {
        String x = normalizeNumber(a);
        String y = normalizeNumber(b);

        if (x.length() < 7 || y.length() < 7) return false;

        int compare = Math.min(10, Math.min(x.length(), y.length()));

        return x.substring(x.length() - compare)
                .equals(y.substring(y.length() - compare));
    }

    public static String normalizeNumber(String value) {
        if (value == null) return "";
        return value.replaceAll("[^0-9]", "");
    }

    // compatibility with old builds
    public static void setEmergencyNumber(Context c, String value) {
        prefs(c).edit().putString(
                "emergency_number",
                value == null ? "" : value.trim()
        ).apply();
    }

    public static String getEmergencyNumber(Context c) {
        return prefs(c).getString("emergency_number", "");
    }
}
