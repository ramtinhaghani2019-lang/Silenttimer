package com.example.silenttimer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class UiKit {
    private UiKit() {}

    public static final int THEME_OBSIDIAN = 0;
    public static final int THEME_MIDNIGHT = 1;
    public static final int THEME_PEARL = 2;
    public static final int THEME_AURORA = 3;

    // bgTop, bgBottom, card, text, accent, muted, field, accent2
    private static final int[][] PALETTES = new int[][]{
            {0xFF05060A, 0xFF0C0B12, 0xFF14151D, 0xFFF8F8FB, 0xFF8B5CF6, 0xFF9A9EAE, 0xFF20212B, 0xFF2DD4BF},
            {0xFF06111E, 0xFF0C1C31, 0xFF13243D, 0xFFF7FAFF, 0xFF38BDF8, 0xFF9EB3CC, 0xFF1B2F4D, 0xFF7C3AED},
            {0xFFF7F8FC, 0xFFEEF1F7, 0xFFFFFFFF, 0xFF171B29, 0xFF5B4CF0, 0xFF707789, 0xFFF0F2F7, 0xFF0EA5E9},
            {0xFF071816, 0xFF102522, 0xFF17332E, 0xFFF7FFFC, 0xFF59E6C2, 0xFFB0C9C2, 0xFF21423B, 0xFFA78BFA}
    };

    public static int[] palette(Context c) {
        // Silent Timer 4.1 uses one premium visual identity only: Obsidian.
        return PALETTES[THEME_OBSIDIAN];
    }

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static GradientDrawable screenBackground(Context c) {
        int[] p = palette(c);
        return new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{p[0], p[1]}
        );
    }

    public static GradientDrawable rounded(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable card(Context c) {
        int[] p = palette(c);
        GradientDrawable g = rounded(c, p[2], 26);
        g.setStroke(dp(c, 1), withAlpha(p[4], 0x22));
        return g;
    }

    public static GradientDrawable field(Context c) {
        int[] p = palette(c);
        GradientDrawable g = rounded(c, p[6], 18);
        g.setStroke(dp(c, 1), withAlpha(p[4], 0x26));
        return g;
    }

    public static GradientDrawable accentCard(Context c) {
        int[] p = palette(c);
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                new int[]{withAlpha(p[4], 0x35), withAlpha(p[7], 0x22)}
        );
        g.setCornerRadius(dp(c, 30));
        g.setStroke(dp(c, 1), withAlpha(p[4], 0x55));
        return g;
    }

    public static TextView title(Context c, String text) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(p[3]);
        tv.setTextSize(30f);
        tv.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static TextView sectionTitle(Context c, String text) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(p[3]);
        tv.setTextSize(17f);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static TextView muted(Context c, String text) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(p[5]);
        tv.setTextSize(13f);
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static LinearLayout cardLayout(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        card.setBackground(card(c));
        card.setElevation(dp(c, 3));
        return card;
    }

    public static Button primaryButton(Context c, String text) {
        int[] p = palette(c);
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16f);
        b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        b.setMinHeight(dp(c, 56));
        GradientDrawable g = new GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{p[4], p[7]}
        );
        g.setCornerRadius(dp(c, 18));
        b.setBackground(g);
        b.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        b.setElevation(dp(c, 4));
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        int[] p = palette(c);
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(p[3]);
        b.setTextSize(14f);
        b.setMinHeight(dp(c, 48));
        GradientDrawable g = rounded(c, p[6], 16);
        g.setStroke(dp(c, 1), withAlpha(p[4], 0x40));
        b.setBackground(g);
        b.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        b.setElevation(0f);
        return b;
    }

    public static TextView navCard(Context c, String icon, String title, String subtitle) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(icon + "   " + title + "\n      " + subtitle);
        tv.setTextColor(p[3]);
        tv.setTextSize(16f);
        tv.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tv.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        tv.setLineSpacing(0f, 1.28f);
        tv.setPadding(dp(c, 18), dp(c, 19), dp(c, 18), dp(c, 19));
        tv.setBackground(card(c));
        tv.setElevation(dp(c, 2));
        return tv;
    }

    public static TextView chip(Context c, String text, boolean active) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextSize(13f);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(c, 14), dp(c, 9), dp(c, 14), dp(c, 9));
        if (active) {
            tv.setTextColor(Color.WHITE);
            tv.setBackground(rounded(c, p[4], 100));
        } else {
            tv.setTextColor(p[3]);
            tv.setBackground(field(c));
        }
        return tv;
    }

    public static LinearLayout bottomNav(Context c, int selected, final View.OnClickListener home, final View.OnClickListener smart, final View.OnClickListener calls) {
        LinearLayout nav = new LinearLayout(c);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(c, 8), dp(c, 8), dp(c, 8), dp(c, 8));
        nav.setBackground(card(c));

        TextView homeTab = navTab(c, "⌂\nخانه", selected == 0);
        TextView smartTab = navTab(c, "◷\nسایلنت", selected == 1);
        TextView callsTab = navTab(c, "☎\nتماس‌ها", selected == 2);

        homeTab.setOnClickListener(home);
        smartTab.setOnClickListener(smart);
        callsTab.setOnClickListener(calls);

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        nav.addView(homeTab, lp);
        nav.addView(smartTab, lp);
        nav.addView(callsTab, lp);
        return nav;
    }

    private static TextView navTab(Context c, String text, boolean selected) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(12f);
        tv.setTextColor(selected ? p[4] : p[5]);
        tv.setPadding(dp(c, 8), dp(c, 5), dp(c, 8), dp(c, 5));
        return tv;
    }

    public static void applyWindow(Activity a) {
        int[] p = palette(a);
        a.getWindow().setStatusBarColor(p[0]);
        a.getWindow().setNavigationBarColor(p[0]);

        if (Build.VERSION.SDK_INT >= 23) {
            int flags = a.getWindow().getDecorView().getSystemUiVisibility();
            flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            a.getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    public static LinearLayout.LayoutParams matchWrap(Context c) {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    public static LinearLayout.LayoutParams matchWrap(Context c, int top, int bottom) {
        LinearLayout.LayoutParams p = matchWrap(c);
        p.setMargins(0, dp(c, top), 0, dp(c, bottom));
        return p;
    }
}
