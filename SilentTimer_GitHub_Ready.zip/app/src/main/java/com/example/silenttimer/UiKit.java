package com.example.silenttimer;

import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class UiKit {
    private UiKit() {}

    public static final int THEME_AMOLED = 0;
    public static final int THEME_MIDNIGHT = 1;
    public static final int THEME_LIGHT = 2;
    public static final int THEME_GLASS = 3;

    // bg, card, text, accent, muted, field
    private static final int[][] PALETTES = new int[][] {
            {0xFF050505, 0xFF151515, 0xFFF7F7FA, 0xFF8B5CF6, 0xFFA8A8B3, 0xFF222226},
            {0xFF09111F, 0xFF13213A, 0xFFF7FAFF, 0xFF38BDF8, 0xFFA5B4CC, 0xFF1A2945},
            {0xFFF3F5F9, 0xFFFFFFFF, 0xFF171B2A, 0xFF5B4CF0, 0xFF6E7588, 0xFFEEF0F5},
            {0xFF10201D, 0xCC1E3530, 0xFFF7FFFC, 0xFF59E6C2, 0xFFB9CEC8, 0x66314F48}
    };

    public static int[] palette(Context c) {
        int i = AppPrefs.getTheme(c);
        if (i < 0 || i >= PALETTES.length) i = 0;
        return PALETTES[i];
    }

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable rounded(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static GradientDrawable card(Context c) {
        int[] p = palette(c);
        GradientDrawable g = rounded(c, p[1], 24);
        g.setStroke(dp(c, 1), withAlpha(p[3], 0x28));
        return g;
    }

    public static GradientDrawable field(Context c) {
        int[] p = palette(c);
        GradientDrawable g = rounded(c, p[5], 16);
        g.setStroke(dp(c, 1), withAlpha(p[3], 0x22));
        return g;
    }

    public static TextView title(Context c, String text) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(p[2]);
        tv.setTextSize(28f);
        tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static TextView sectionTitle(Context c, String text) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(p[2]);
        tv.setTextSize(17f);
        tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static TextView muted(Context c, String text) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(p[4]);
        tv.setTextSize(13f);
        tv.setGravity(Gravity.RIGHT);
        return tv;
    }

    public static LinearLayout cardLayout(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        card.setBackground(card(c));
        card.setElevation(dp(c, 2));
        return card;
    }

    public static Button primaryButton(Context c, String text) {
        int[] p = palette(c);
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16f);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setMinHeight(dp(c, 54));
        b.setBackground(rounded(c, p[3], 18));
        b.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        int[] p = palette(c);
        Button b = new Button(c);
        b.setAllCaps(false);
        b.setText(text);
        b.setTextColor(p[2]);
        b.setTextSize(14f);
        b.setMinHeight(dp(c, 48));
        GradientDrawable g = rounded(c, p[5], 16);
        g.setStroke(dp(c, 1), withAlpha(p[3], 0x55));
        b.setBackground(g);
        return b;
    }

    public static TextView navCard(Context c, String title, String subtitle, String symbol) {
        int[] p = palette(c);
        TextView tv = new TextView(c);
        tv.setText(symbol + "   " + title + "\n" + subtitle);
        tv.setTextColor(p[2]);
        tv.setTextSize(17f);
        tv.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tv.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        tv.setLineSpacing(0f, 1.22f);
        tv.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 18));
        GradientDrawable g = card(c);
        tv.setBackground(g);
        tv.setElevation(dp(c, 2));
        return tv;
    }

    public static void applyWindow(Activity a) {
        int[] p = palette(a);
        a.getWindow().setStatusBarColor(p[0]);
        a.getWindow().setNavigationBarColor(p[0]);

        if (Build.VERSION.SDK_INT >= 23) {
            int flags = a.getWindow().getDecorView().getSystemUiVisibility();
            if (AppPrefs.getTheme(a) == THEME_LIGHT) {
                flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            } else {
                flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            }
            a.getWindow().getDecorView().setSystemUiVisibility(flags);
        }
    }

    public static LinearLayout.LayoutParams matchWrap(Context c) {
        return new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    public static LinearLayout.LayoutParams matchWrap(Context c, int top, int bottom) {
        LinearLayout.LayoutParams p = matchWrap(c);
        p.setMargins(0, dp(c, top), 0, dp(c, bottom));
        return p;
    }

    public static int withAlpha(int color, int alpha) {
        return Color.argb(alpha, Color.red(color), Color.green(color), Color.blue(color));
    }

    public static ColorStateList tint(int color) {
        return ColorStateList.valueOf(color);
    }
}
