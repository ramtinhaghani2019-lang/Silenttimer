package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

public final class WeeklyScheduler {
    private WeeklyScheduler(){}
    public static void rescheduleAll(Context c){for(NexaStore.WeeklySchedule s:NexaStore.schedules(c))if(s.enabled)scheduleNext(c,s);}
    public static void scheduleNext(Context c,NexaStore.WeeklySchedule s){long next=nextStart(s);Intent i=new Intent(c,ScheduleReceiver.class);i.putExtra("id",s.id);PendingIntent pi=PendingIntent.getBroadcast(c,("sch"+s.id).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);ReminderScheduler.setAlarm(c,next,pi);}
    public static long nextStart(NexaStore.WeeklySchedule s){Calendar now=Calendar.getInstance();for(int add=0;add<8;add++){Calendar c=(Calendar)now.clone();c.add(Calendar.DAY_OF_YEAR,add);int dow=c.get(Calendar.DAY_OF_WEEK);int bit=1<<(dow-1);if((s.daysMask&bit)==0)continue;c.set(Calendar.HOUR_OF_DAY,s.startHour);c.set(Calendar.MINUTE,s.startMinute);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);if(c.getTimeInMillis()>System.currentTimeMillis()+1000)return c.getTimeInMillis();}return System.currentTimeMillis()+24*60*60*1000L;}
}
