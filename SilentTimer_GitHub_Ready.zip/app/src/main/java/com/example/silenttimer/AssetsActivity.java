package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;
import java.util.List;
import java.util.Locale;

public class AssetsActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private TextView marketStatus;
    private EditText usdToman;
    private final DecimalFormat df = new DecimalFormat("#,##0.##");

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 250);
        }
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Assets"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"ثبت خرید دارایی، قیمت روز و محاسبه سود/زیان"),UiKit.matchWrap(this,0,14));

        LinearLayout sumCard=UiKit.colorfulCardLayout(this,1);
        sumCard.addView(UiKit.sectionTitle(this,"📈 نمای سبد"));
        summary=UiKit.muted(this,"");
        summary.setTextSize(15);
        sumCard.addView(summary,UiKit.matchWrap(this,8,0));
        root.addView(sumCard,UiKit.matchWrap(this,0,12));

        LinearLayout market=UiKit.colorfulCardLayout(this,2);
        market.addView(UiKit.sectionTitle(this,"🌐 قیمت مرجع آنلاین"));
        market.addView(UiKit.muted(this,"طلای جهانی، نقره و نرخ مرجع EUR/USD آنلاین‌اند. برای برآورد تومان، نرخ دلار آزاد را خودت وارد کن. این بخش قیمت رسمی بازار ایران نیست. منابع مرجع: gold-api.com و open.er-api.com"),UiKit.matchWrap(this,6,10));

        usdToman=field("نرخ فعلی ۱ دلار به تومان");
        usdToman.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        double saved=NexaStore.usdToman(this);
        if(saved>0)usdToman.setText(String.format(Locale.US,"%.0f",saved));
        market.addView(usdToman,UiKit.matchWrap(this,0,8));

        LinearLayout mr=new LinearLayout(this);
        Button saveRate=UiKit.secondaryButton(this,"ذخیره نرخ دلار");
        saveRate.setOnClickListener(v->{
            double x=num(usdToman.getText().toString());
            NexaStore.setUsdToman(this,x);
            applyMarketToAssets();
            render();
        });
        Button refresh=UiKit.primaryButton(this,"به‌روزرسانی آنلاین");
        refresh.setOnClickListener(v->{
            refresh.setEnabled(false);
            marketStatus.setText("در حال دریافت...");
            MarketDataHelper.refresh(this,(ok,msg)->{
                refresh.setEnabled(true);
                marketStatus.setText(msg);
                if(ok){
                    applyMarketToAssets();
                    render();
                }
            });
        });
        mr.addView(saveRate,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-2,1f);
        rp.setMargins(UiKit.dp(this,6),0,0,0);
        mr.addView(refresh,rp);
        market.addView(mr);

        marketStatus=UiKit.muted(this,"");
        market.addView(marketStatus,UiKit.matchWrap(this,8,0));
        root.addView(market,UiKit.matchWrap(this,0,12));

        Button add=UiKit.primaryButton(this,"＋ ثبت خرید جدید");
        add.setOnClickListener(v->addDialog());
        root.addView(add,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
        updateMarketText();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        Spinner type=new Spinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"طلای ۱۸ عیار","طلای ۲۴ عیار","نقره","مس","دلار","یورو","سهام / بورس","سایر"}
        ));

        EditText name=field("نام/نماد؛ مثلاً طلا، EUR، خودروئی");
        EditText amount=field("مقدار / تعداد");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText buy=field("قیمت خرید هر واحد");
        buy.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText current=field("قیمت فعلی هر واحد (اختیاری)");
        current.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText fee=field("کارمزد کل (اختیاری)");
        fee.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText note=field("یادداشت");

        final long[] dateMillis={System.currentTimeMillis()};
        Button date=UiKit.secondaryButton(this,"تاریخ خرید: "+PersianDateUtil.format(dateMillis[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDate(
                this,dateMillis[0],"تاریخ خرید",ms->{dateMillis[0]=ms;date.setText("تاریخ خرید: "+PersianDateUtil.format(ms));}
        ));

        box.addView(type);box.addView(name);box.addView(amount);box.addView(buy);box.addView(current);box.addView(fee);box.addView(note);box.addView(date);

        new AlertDialog.Builder(this)
                .setTitle("ثبت دارایی")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    double a=num(amount.getText().toString());
                    double b=num(buy.getText().toString());
                    if(a<=0||b<=0)return;

                    NexaStore.AssetEntry x=new NexaStore.AssetEntry();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.name=name.getText().toString().trim().isEmpty()?x.type:name.getText().toString().trim();
                    x.amount=a;
                    x.buyUnitPrice=b;
                    x.currentUnitPrice=num(current.getText().toString());
                    if(x.currentUnitPrice<=0)x.currentUnitPrice=b;
                    x.fee=num(fee.getText().toString());
                    x.buyDate=dateMillis[0];
                    x.note=note.getText().toString().trim();
                    NexaStore.addAsset(this,x);
                    applyMarketToAsset(x);
                    NexaStore.updateAsset(this,x);
                    NexaStore.addHistory(this,"دارایی","ثبت خرید: "+x.name);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void editCurrent(NexaStore.AssetEntry x) {
        EditText e=field("قیمت فعلی هر واحد");
        e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        e.setText(String.format(Locale.US,"%.2f",x.currentUnitPrice));
        new AlertDialog.Builder(this)
                .setTitle("قیمت فعلی")
                .setView(e)
                .setPositiveButton("ذخیره",(d,w)->{
                    double v=num(e.getText().toString());
                    if(v>0){x.currentUnitPrice=v;NexaStore.updateAsset(this,x);render();}
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void applyMarketToAssets() {
        List<NexaStore.AssetEntry> all=NexaStore.assets(this);
        for(NexaStore.AssetEntry x:all)applyMarketToAsset(x);
        NexaStore.saveAssets(this,all);
    }

    private void applyMarketToAsset(NexaStore.AssetEntry x) {
        double usd=NexaStore.usdToman(this);
        if(usd<=0)return;

        double gold=NexaStore.marketGold(this);
        double silver=NexaStore.marketSilver(this);
        double eur=NexaStore.marketEurPerUsd(this);

        if(x.type.contains("۱۸") && gold>0) {
            x.currentUnitPrice=(gold/31.1035)*0.75*usd;
        } else if(x.type.contains("۲۴") && gold>0) {
            x.currentUnitPrice=(gold/31.1035)*usd;
        } else if(x.type.equals("نقره") && silver>0) {
            x.currentUnitPrice=(silver/31.1035)*usd;
        } else if(x.type.equals("دلار")) {
            x.currentUnitPrice=usd;
        } else if(x.type.equals("یورو") && eur>0) {
            x.currentUnitPrice=(usd/eur);
        }
    }

    private void updateMarketText() {
        if(marketStatus==null)return;
        long t=NexaStore.marketUpdated(this);
        if(t<=0){
            marketStatus.setText("هنوز قیمت آنلاین دریافت نشده.");
            return;
        }

        String s="آخرین دریافت: "+PersianDateUtil.pretty(t);
        if(NexaStore.marketGold(this)>0)s+=" • XAU $"+df.format(NexaStore.marketGold(this));
        if(NexaStore.marketSilver(this)>0)s+=" • XAG $"+df.format(NexaStore.marketSilver(this));
        marketStatus.setText(s);
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();

        List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        double cost=0,current=0;
        for(NexaStore.AssetEntry x:data){
            cost += x.amount*x.buyUnitPrice + x.fee;
            current += x.amount*x.currentUnitPrice;
        }
        double pnl=current-cost;
        summary.setText(
                "بهای خرید: "+money(cost)+"\n"+
                "ارزش فعلی: "+money(current)+"\n"+
                "سود/زیان: "+(pnl>=0?"+":"")+money(pnl)+
                (cost>0?"  ("+String.format(Locale.US,"%+.1f%%",pnl/cost*100.0)+")":"")
        );

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"هنوز دارایی ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            updateMarketText();
            return;
        }

        for(NexaStore.AssetEntry x:data){
            double c=x.amount*x.buyUnitPrice+x.fee;
            double v=x.amount*x.currentUnitPrice;
            double p=v-c;

            LinearLayout card=UiKit.colorfulCardLayout(this,p>=0?2:3);
            card.addView(UiKit.sectionTitle(this,"📈 "+x.name));
            card.addView(UiKit.muted(this,x.type+" • مقدار "+df.format(x.amount)+" • خرید "+PersianDateUtil.format(x.buyDate)),UiKit.matchWrap(this,5,3));
            card.addView(UiKit.muted(this,"میانگین خرید: "+money(x.buyUnitPrice)+" • قیمت فعلی: "+money(x.currentUnitPrice)));
            TextView pl=UiKit.sectionTitle(this,(p>=0?"سود ":"زیان ")+money(Math.abs(p)));
            pl.setTextColor(p>=0?UiKit.TEAL:UiKit.PINK);
            card.addView(pl,UiKit.matchWrap(this,8,0));

            LinearLayout actions=new LinearLayout(this);
            Button edit=UiKit.secondaryButton(this,"قیمت روز");
            edit.setOnClickListener(vw->editCurrent(x));
            Button del=UiKit.secondaryButton(this,"حذف");
            del.setOnClickListener(vw->{
                NexaStore.removeAsset(this,x.id);
                render();
            });
            actions.addView(edit,new LinearLayout.LayoutParams(0,-2,1f));
            LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,-2,1f);
            ap.setMargins(UiKit.dp(this,6),0,0,0);
            actions.addView(del,ap);
            card.addView(actions,UiKit.matchWrap(this,10,0));
            list.addView(card,UiKit.matchWrap(this,0,10));
        }

        updateMarketText();
    }

    private double num(String s) {
        try{return Double.parseDouble(s.replace(",","").trim());}catch(Exception e){return 0;}
    }

    private String money(double v) {
        return df.format(v)+" تومان";
    }
}
