package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoryActivity extends Activity {
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);Button back=UiKit.secondaryButton(this,"‹");back.setOnClickListener(v->finish());root.addView(back,UiKit.matchWrap(this,0,12));root.addView(UiKit.title(this,"تاریخچه"),UiKit.matchWrap(this,0,14));List<NexaStore.HistoryItem> all=NexaStore.history(this);LinearLayout sum=UiKit.colorfulCardLayout(this,1);sum.addView(UiKit.sectionTitle(this,"گزارش فعالیت"));long now=System.currentTimeMillis();int today=0,week=0;for(NexaStore.HistoryItem h:all){if(now-h.time<=24L*60*60*1000)today++;if(now-h.time<=7L*24*60*60*1000)week++;}sum.addView(UiKit.muted(this,"امروز: "+today+" • ۷ روز اخیر: "+week+" • کل: "+all.size()),UiKit.matchWrap(this,6,8));Button clear=UiKit.secondaryButton(this,"پاک کردن تاریخچه");clear.setOnClickListener(v->{NexaStore.clearHistory(this);build();});sum.addView(clear);root.addView(sum,UiKit.matchWrap(this,0,14));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);SimpleDateFormat f=new SimpleDateFormat("yyyy/MM/dd HH:mm",Locale.US);if(all.isEmpty()){TextView e=UiKit.muted(this,"تاریخچه خالی است.");e.setGravity(Gravity.CENTER);list.addView(e);}for(NexaStore.HistoryItem h:all){LinearLayout c=UiKit.cardLayout(this);c.addView(UiKit.sectionTitle(this,h.type));c.addView(UiKit.muted(this,h.text),UiKit.matchWrap(this,4,2));c.addView(UiKit.muted(this,f.format(new Date(h.time))));list.addView(c,UiKit.matchWrap(this,0,8));}setContentView(sc);}
}
