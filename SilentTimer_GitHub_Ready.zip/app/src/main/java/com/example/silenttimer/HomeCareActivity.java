package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;
import java.util.Locale;

public class HomeCareActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if(getIntent().getBooleanExtra("quick_add",false))list.postDelayed(this::addDialog,250);
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.secondaryButton(this,"‹");
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Home"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"سرویس‌ها و کارهای دوره‌ای منزل"),UiKit.matchWrap(this,0,14));

        LinearLayout hero=UiKit.colorfulCardLayout(this,2);
        hero.addView(UiKit.sectionTitle(this,"🏠 نگهداری خانه"));
        Button add=UiKit.primaryButton(this,"＋ ثبت سرویس منزل");
        add.setOnClickListener(v->addDialog());
        hero.addView(add,UiKit.matchWrap(this,10,0));
        root.addView(hero,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        Spinner cat=new Spinner(this);
        cat.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"کولر","پکیج","فیلتر آب","تصفیه هوا","برق","لوله‌کشی","آسانسور","نظافت/سرویس","سایر"}
        ));

        EditText title=field("عنوان؛ مثلاً تعویض فیلتر آب");
        EditText cost=field("هزینه (اختیاری)");
        cost.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText note=field("توضیحات");

        final long[] last={System.currentTimeMillis()};
        final long[] next={System.currentTimeMillis()+180L*24L*60L*60L*1000L};

        Button lastBtn=UiKit.secondaryButton(this,"آخرین سرویس: "+PersianDateUtil.format(last[0]));
        lastBtn.setOnClickListener(v->PersianDatePickerHelper.pickDate(this,last[0],"تاریخ آخرین سرویس",ms->{last[0]=ms;lastBtn.setText("آخرین سرویس: "+PersianDateUtil.format(ms));}));

        Button nextBtn=UiKit.secondaryButton(this,"سرویس بعدی: "+PersianDateUtil.format(next[0]));
        nextBtn.setOnClickListener(v->PersianDatePickerHelper.pickDate(this,next[0],"تاریخ سرویس بعدی",ms->{next[0]=ms;nextBtn.setText("سرویس بعدی: "+PersianDateUtil.format(ms));}));

        box.addView(cat);box.addView(title);box.addView(cost);box.addView(note);box.addView(lastBtn);box.addView(nextBtn);

        new AlertDialog.Builder(this)
                .setTitle("سرویس خانه")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(cat.getSelectedItem());

                    NexaStore.HomeItem x=new NexaStore.HomeItem();
                    x.category=String.valueOf(cat.getSelectedItem());
                    x.title=t;
                    x.lastServiceDate=last[0];
                    x.nextDueDate=next[0];
                    x.note=note.getText().toString().trim();
                    try{x.cost=Long.parseLong(cost.getText().toString().trim());}catch(Exception ignored){}

                    NexaStore.addHomeItem(this,x);
                    LinkedReminderHelper.upsert(
                            this,
                            "home:"+x.id,
                            "سرویس خانه: "+x.title,
                            "خانه",
                            "🏠",
                            x.note,
                            x.nextDueDate,
                            "10080,1440,0",
                            30
                    );
                    NexaStore.addHistory(this,"خانه","ثبت سرویس: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.HomeItem> data=NexaStore.homeItems(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"سرویسی برای خانه ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        for(NexaStore.HomeItem x:data){
            LinearLayout c=UiKit.colorfulCardLayout(this,2);
            c.addView(UiKit.sectionTitle(this,"🏠 "+x.title));
            c.addView(UiKit.muted(this,x.category+" • موعد بعدی "+PersianDateUtil.format(x.nextDueDate)),UiKit.matchWrap(this,5,2));
            if(x.cost>0)c.addView(UiKit.muted(this,String.format(Locale.US,"هزینه قبلی: %,d تومان",x.cost)));
            if(!x.note.isEmpty())c.addView(UiKit.muted(this,x.note),UiKit.matchWrap(this,4,0));

            Button del=UiKit.secondaryButton(this,"حذف");
            del.setOnClickListener(v->{
                LinkedReminderHelper.remove(this,"home:"+x.id);
                NexaStore.removeHomeItem(this,x.id);
                render();
            });
            c.addView(del,UiKit.matchWrap(this,10,0));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
    }
}
