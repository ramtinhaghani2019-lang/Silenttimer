package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class AllowedCallsActivity extends Activity {

    private static final int PICK_CONTACT = 5501;

    private LinearLayout root;
    private LinearLayout listContainer;
    private Switch enabledSwitch;
    private TextView countText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 28)
        );
        root.setBackgroundColor(p[0]);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        Button back = UiKit.secondaryButton(this, "‹");
        back.setTextSize(26f);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = UiKit.title(this, "تماس‌های مجاز");
        LinearLayout.LayoutParams tp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(UiKit.dp(this, 12), 0, 0, 0);
        header.addView(title, tp);

        LinearLayout masterCard = UiKit.cardLayout(this);
        root.addView(masterCard, UiKit.matchWrap(this, 0, 12));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        masterCard.addView(top);

        TextView masterTitle = UiKit.sectionTitle(this, "زنگ خوردن شماره‌های مجاز");
        LinearLayout.LayoutParams mt =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        top.addView(masterTitle, mt);

        enabledSwitch = new Switch(this);
        enabledSwitch.setChecked(AppPrefs.isAllowedCallsEnabled(this));
        enabledSwitch.setText(
                enabledSwitch.isChecked() ? "روشن" : "خاموش"
        );
        top.addView(enabledSwitch);

        TextView masterDesc = UiKit.muted(
                this,
                "وقتی روشن باشد، این شماره‌ها حتی در Silent یا Vibrate می‌توانند با صدا زنگ بخورند."
        );
        masterCard.addView(masterDesc, UiKit.matchWrap(this, 8, 0));

        enabledSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppPrefs.setAllowedCallsEnabled(
                    AllowedCallsActivity.this,
                    isChecked
            );
            enabledSwitch.setText(isChecked ? "روشن" : "خاموش");
            sendRefresh();
        });

        LinearLayout addCard = UiKit.cardLayout(this);
        root.addView(addCard, UiKit.matchWrap(this, 0, 12));

        addCard.addView(UiKit.sectionTitle(this, "افزودن شماره"));

        TextView addDesc = UiKit.muted(
                this,
                "از دفتر تلفن انتخاب کن یا شماره را دستی وارد کن."
        );
        addCard.addView(addDesc, UiKit.matchWrap(this, 5, 12));

        Button pick = UiKit.primaryButton(this, "انتخاب از دفتر تلفن");
        pick.setOnClickListener(v -> pickContact());
        addCard.addView(pick, UiKit.matchWrap(this, 0, 8));

        Button manual = UiKit.secondaryButton(this, "افزودن دستی");
        manual.setOnClickListener(v -> showManualAddDialog());
        addCard.addView(manual);

        LinearLayout listCard = UiKit.cardLayout(this);
        root.addView(listCard, UiKit.matchWrap(this, 0, 12));

        LinearLayout listHeader = new LinearLayout(this);
        listHeader.setOrientation(LinearLayout.HORIZONTAL);
        listHeader.setGravity(Gravity.CENTER_VERTICAL);
        listCard.addView(listHeader);

        TextView listTitle = UiKit.sectionTitle(this, "شماره‌های ذخیره‌شده");
        LinearLayout.LayoutParams ltp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        listHeader.addView(listTitle, ltp);

        countText = UiKit.muted(this, "");
        listHeader.addView(countText);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listCard.addView(listContainer, UiKit.matchWrap(this, 12, 0));

        TextView note = UiKit.muted(
                this,
                "بعد از پایان تماس مجاز، گوشی به همان حالت Silent یا Vibrate قبلی برمی‌گردد."
        );
        note.setGravity(Gravity.CENTER);
        root.addView(note, UiKit.matchWrap(this, 6, 0));

        setContentView(scroll);
        refreshList();
    }

    private void pickContact() {
        Intent i = new Intent(
                Intent.ACTION_PICK,
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        );
        startActivityForResult(i, PICK_CONTACT);
    }

    @Override
    protected void onActivityResult(
            int requestCode,
            int resultCode,
            Intent data
    ) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode != PICK_CONTACT ||
                resultCode != RESULT_OK ||
                data == null ||
                data.getData() == null) {
            return;
        }

        Cursor cursor = null;

        try {
            cursor = getContentResolver().query(
                    data.getData(),
                    new String[] {
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER
                    },
                    null,
                    null,
                    null
            );

            if (cursor != null && cursor.moveToFirst()) {
                String name = cursor.getString(0);
                String number = cursor.getString(1);

                AppPrefs.addAllowedContact(this, name, number);
                refreshList();
                sendRefresh();

                Toast.makeText(
                        this,
                        "مخاطب اضافه شد.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        } catch (Exception e) {
            Toast.makeText(
                    this,
                    "خواندن مخاطب انجام نشد.",
                    Toast.LENGTH_SHORT
            ).show();
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void showManualAddDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(
                UiKit.dp(this, 18),
                UiKit.dp(this, 8),
                UiKit.dp(this, 18),
                0
        );

        EditText name = new EditText(this);
        name.setHint("نام");
        name.setSingleLine(true);
        box.addView(name);

        EditText number = new EditText(this);
        number.setHint("شماره تماس");
        number.setInputType(InputType.TYPE_CLASS_PHONE);
        number.setSingleLine(true);
        box.addView(number);

        new AlertDialog.Builder(this)
                .setTitle("افزودن شماره")
                .setView(box)
                .setPositiveButton(
                        "افزودن",
                        (dialog, which) -> {
                            if (number.getText().toString().trim().isEmpty()) {
                                return;
                            }

                            AppPrefs.addAllowedContact(
                                    this,
                                    name.getText().toString(),
                                    number.getText().toString()
                            );

                            refreshList();
                            sendRefresh();
                        }
                )
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void refreshList() {
        if (listContainer == null) return;

        listContainer.removeAllViews();

        List<AppPrefs.ContactEntry> list =
                AppPrefs.getAllowedContacts(this);

        countText.setText(list.size() + " شماره");

        if (list.isEmpty()) {
            TextView empty = UiKit.muted(
                    this,
                    "هنوز شماره‌ای اضافه نشده."
            );
            empty.setGravity(Gravity.CENTER);
            listContainer.addView(empty);
            return;
        }

        for (int i = 0; i < list.size(); i++) {
            AppPrefs.ContactEntry entry = list.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(
                    UiKit.dp(this, 12),
                    UiKit.dp(this, 10),
                    UiKit.dp(this, 12),
                    UiKit.dp(this, 10)
            );
            row.setBackground(UiKit.field(this));

            LinearLayout textBox = new LinearLayout(this);
            textBox.setOrientation(LinearLayout.VERTICAL);

            LinearLayout.LayoutParams textParams =
                    new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(textBox, textParams);

            TextView name = UiKit.sectionTitle(
                    this,
                    entry.name.trim().isEmpty() ? "بدون نام" : entry.name
            );
            name.setTextSize(15f);
            textBox.addView(name);

            TextView number = UiKit.muted(this, entry.number);
            number.setTextDirection(View.TEXT_DIRECTION_LTR);
            number.setGravity(Gravity.LEFT);
            textBox.addView(number);

            final int index = i;

            Button remove = UiKit.secondaryButton(this, "حذف");
            remove.setMinWidth(UiKit.dp(this, 70));
            remove.setOnClickListener(v -> {
                AppPrefs.removeAllowedContact(
                        AllowedCallsActivity.this,
                        index
                );
                refreshList();
                sendRefresh();
            });

            row.addView(remove);

            listContainer.addView(
                    row,
                    UiKit.matchWrap(this, i == 0 ? 0 : 8, 0)
            );
        }
    }

    private void sendRefresh() {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_REFRESH);

        try {
            startService(i);
        } catch (Exception ignored) {}
    }
}
