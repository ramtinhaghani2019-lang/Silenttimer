package com.example.silenttimer;

import android.app.Activity;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class UnlockActivity extends Activity {
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));TextView t=UiKit.title(this,"NEXA");t.setGravity(Gravity.CENTER);root.addView(t,UiKit.matchWrap(this,0,6));TextView s=UiKit.muted(this,"قفل امنیتی");s.setGravity(Gravity.CENTER);root.addView(s,UiKit.matchWrap(this,0,24));EditText pin=new EditText(this);pin.setHint("PIN");pin.setTextColor(UiKit.TEXT);pin.setHintTextColor(UiKit.MUTED);pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);pin.setBackground(UiKit.field(this));pin.setPadding(UiKit.dp(this,16),UiKit.dp(this,14),UiKit.dp(this,16),UiKit.dp(this,14));root.addView(pin,UiKit.matchWrap(this,0,12));Button ok=UiKit.primaryButton(this,"باز کردن");ok.setOnClickListener(v->{if(NexaStore.verifyPin(this,pin.getText().toString())){SecurityGate.unlock();finish();}else Toast.makeText(this,"PIN نادرست است.",Toast.LENGTH_SHORT).show();});root.addView(ok,UiKit.matchWrap(this,0,10));if(Build.VERSION.SDK_INT>=28&&NexaStore.biometricEnabled(this)){Button bio=UiKit.secondaryButton(this,"باز کردن با اثر انگشت / بیومتریک");bio.setOnClickListener(v->biometric());root.addView(bio);}setContentView(root);}
    private void biometric(){if(Build.VERSION.SDK_INT<28)return;CancellationSignal cs=new CancellationSignal();BiometricPrompt p=new BiometricPrompt.Builder(this).setTitle("Nexa").setSubtitle("احراز هویت").setNegativeButton("انصراف",getMainExecutor(),(d,w)->{}).build();p.authenticate(cs,getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){@Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){SecurityGate.unlock();finish();}});}
    @Override public void onBackPressed(){finishAffinity();}
}
