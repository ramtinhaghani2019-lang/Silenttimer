# ممیزی Nexa 5.3.3

مبنای این نسخه Nexa 5.3.2 است و قابلیت‌های قبلی حذف نشده‌اند.

## بستن موارد باقی‌مانده 5.3 / 5.3.1
- [x] حفظ اصلاحات 5.2، 5.3، 5.3.1 و 5.3.2
- [x] Alarm واقعی با صدای زنگ سیستم و ویبره حلقه‌ای
- [x] پیش‌فرض «زنگ تا تأیید کاربر»
- [x] مدت قابل تنظیم ۳۰ ثانیه / ۱ / ۲ / ۵ دقیقه
- [x] تکرار هشدار طبق موتور موجود (پیش‌فرض ۵ دقیقه) تا تأیید
- [x] توقف زنگ با اکشن‌های Notification و Full Screen
- [x] انتخابگر ساعت Obsidian در Medicine، Profiles، AlertEditor، SmartSilent و DateTime picker
- [x] Docs: روز هفته + تاریخ + ساعت ویرایش‌پذیر
- [x] Home/Garage/Assets/Bills/Case/Reminder/Shopping از DateTime/pretty موجود استفاده می‌کنند
- [x] مدیریت تصاویر به تفکیک module directory با تعداد و حجم
- [x] حذف انتخابی ماژول با هشدار برگشت‌ناپذیر و تأیید دومرحله‌ای
- [x] اکشن‌های AlertEditor آیکونی و کوچک
- [x] تم Dialog سراسری Obsidian
- [x] versionName=5.3.3 و versionCode=18

## نکته تست نهایی
این ممیزی سورس/ساختار است. تأیید نهایی رفتار سیستم Alarm، Full Screen Intent، Lock Screen و مجوزهای Android فقط بعد از Build موفق GitHub Actions و تست روی دستگاه ممکن است.
