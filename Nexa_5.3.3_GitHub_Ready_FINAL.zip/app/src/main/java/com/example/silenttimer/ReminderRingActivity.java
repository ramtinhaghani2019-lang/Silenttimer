package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ReminderRingActivity extends Activity {
    private String token,id; private int repeat;
    private MediaPlayer alarmPlayer;
    private final Handler alarmHandler=new Handler(Looper.getMainLooper());
    @Override protected void onCreate(Bundle b){super.onCreate(b);if(Build.VERSION.SDK_INT>=27){setShowWhenLocked(true);setTurnScreenOn(true);}else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED|WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON|WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);UiKit.applyWindow(this);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);token=getIntent().getStringExtra("token");id=getIntent().getStringExtra("id");repeat=getIntent().getIntExtra("repeat",10);NexaStore.Reminder r=NexaStore.reminder(this,id);if(r==null){finish();return;}LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));TextView icon=UiKit.title(this,r.icon);icon.setTextSize(58);icon.setGravity(Gravity.CENTER);root.addView(icon);TextView title=UiKit.title(this,r.title);title.setGravity(Gravity.CENTER);root.addView(title,UiKit.matchWrap(this,12,8));TextView when=UiKit.muted(this,r.category+" • "+PersianDateUtil.pretty(r.whenMillis));when.setGravity(Gravity.CENTER);root.addView(when,UiKit.matchWrap(this,0,20));if(!r.doctorName.isEmpty()||!r.doctorFileNumber.isEmpty()){String medical="";if(!r.doctorName.isEmpty())medical+="پزشک: "+r.doctorName;if(!r.doctorFileNumber.isEmpty())medical+=(medical.isEmpty()?"":" • ")+"پرونده: "+r.doctorFileNumber;TextView med=UiKit.muted(this,medical);med.setGravity(Gravity.CENTER);med.setTextSize(15);root.addView(med,UiKit.matchWrap(this,0,10));}if(!r.note.isEmpty()){TextView note=UiKit.muted(this,r.note);note.setGravity(Gravity.CENTER);note.setTextSize(16);root.addView(note,UiKit.matchWrap(this,0,22));}Button dismiss=UiKit.primaryButton(this,"خاموش کردن هشدار");dismiss.setOnClickListener(v->act("DISMISS"));root.addView(dismiss,UiKit.matchWrap(this,0,10));Button snooze=UiKit.secondaryButton(this,"یادآوری "+repeat+" دقیقه بعد");snooze.setOnClickListener(v->act("SNOOZE"));root.addView(snooze);setContentView(root);alarmPlayer=AlarmSoundPlayer.start(this);long ringMs=AppPrefs.getAlarmRingDurationMs(this);if(ringMs>0)alarmHandler.postDelayed(this::stopAlarmSound,ringMs);}
    private void act(String a){stopAlarmSound();Intent i=new Intent(this,ReminderActionReceiver.class);i.setAction(a);i.putExtra("token",token);i.putExtra("id",id);i.putExtra("repeat",repeat);sendBroadcast(i);finish();}
    private void stopAlarmSound(){AlarmSoundPlayer.stop(alarmPlayer);alarmPlayer=null;}
    @Override protected void onDestroy(){alarmHandler.removeCallbacksAndMessages(null);stopAlarmSound();super.onDestroy();}
}
