package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MedicineActivity extends Activity {
    private LinearLayout list;

    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}

    private EditText f(String h){return UiKit.styleField(this,new EditText(this),h);}

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackground(UiKit.screenBackground(this));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());head.addView(back);TextView title=UiKit.title(this,"Nexa Med");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1f);tp.setMargins(UiKit.dp(this,12),0,0,0);head.addView(title,tp);root.addView(head,UiKit.matchWrap(this,0,14));
        LinearLayout hero=UiKit.colorfulCardLayout(this,2);hero.addView(UiKit.sectionTitle(this,"💊 برنامه مصرف دارو"));hero.addView(UiKit.muted(this,"زمان اولین دوز را وارد کن؛ Nexa نوبت‌های بعد را خودش حساب می‌کند."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ داروی جدید");add.setOnClickListener(v->medicineDialog(null));hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();
    }

    private void medicineDialog(NexaStore.Medicine existing){
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,existing==null?"💊 داروی جدید":"✎ ویرایش دارو"),UiKit.matchWrap(this,0,8));
        EditText name=f("نام دارو");EditText dose=f("مقدار / توضیح؛ مثلاً ۱ عدد بعد غذا");

        ArrayList<String> doctorNames=new ArrayList<>();for(NexaStore.Doctor d:NexaStore.doctors(this))doctorNames.add(d.name);
        AutoCompleteTextView doctor=new AutoCompleteTextView(this);UiKit.styleField(this,doctor,"نام پزشک؛ انتخاب یا تایپ دستی");doctor.setThreshold(1);doctor.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,doctorNames));
        Button doctorList=UiKit.secondaryButton(this,"پزشکان ذخیره‌شده");doctorList.setOnClickListener(v->showDoctorDirectory(d->{doctor.setText(d.name);doctor.dismissDropDown();}));

        final long[] prescriptionDate={existing==null?0:existing.prescriptionDate};Button prescription=UiKit.secondaryButton(this,prescriptionDate[0]>0?"📅 "+PersianDateUtil.pretty(prescriptionDate[0]):"📅 تاریخ نسخه (اختیاری)");prescription.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,prescriptionDate[0]>0?prescriptionDate[0]:System.currentTimeMillis(),"تاریخ نسخه",millis->{prescriptionDate[0]=millis;prescription.setText("📅 "+PersianDateUtil.pretty(millis));}));

        Spinner interval=new Spinner(this);ArrayAdapter<String> ia=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,new String[]{"هر ۴ ساعت","هر ۶ ساعت","هر ۸ ساعت","هر ۱۲ ساعت","هر ۲۴ ساعت"}){@Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);return t;}@Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);return t;}};interval.setAdapter(ia);interval.setSelection(2);
        EditText days=f("تعداد روز دوره؛ ۰ یعنی بدون پایان");days.setInputType(InputType.TYPE_CLASS_NUMBER);

        long base=existing!=null&&existing.firstDoseMillis>0?existing.firstDoseMillis:System.currentTimeMillis();Calendar cal=Calendar.getInstance();cal.setTimeInMillis(base);final int[]hm={cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE)};
        Button firstDose=UiKit.secondaryButton(this,String.format(Locale.US,"🕒 اولین دوز خورده‌شده: %02d:%02d",hm[0],hm[1]));
        firstDose.setOnClickListener(v->PersianDatePickerHelper.pickTime(this,hm[0],hm[1],"ساعت اولین دوز",(h,m)->{hm[0]=h;hm[1]=m;firstDose.setText(String.format(Locale.US,"🕒 اولین دوز خورده‌شده: %02d:%02d",h,m));}));

        if(existing!=null){name.setText(existing.name);dose.setText(existing.dose);doctor.setText(existing.doctor);int[]opts={4,6,8,12,24};for(int j=0;j<opts.length;j++)if(opts[j]==existing.intervalHours)interval.setSelection(j);if(existing.endMillis>0&&existing.firstDoseMillis>0)days.setText(String.valueOf(Math.max(1,(existing.endMillis-existing.firstDoseMillis)/(24L*60*60*1000))));}

        box.addView(UiKit.muted(this,"اطلاعات دارو"));box.addView(name,UiKit.matchWrap(this,5,6));box.addView(dose,UiKit.matchWrap(this,0,8));box.addView(UiKit.muted(this,"پزشک تجویزکننده"));box.addView(doctor,UiKit.matchWrap(this,5,6));box.addView(doctorList,UiKit.matchWrap(this,0,5));box.addView(UiKit.muted(this,"اگر پزشک مهم نیست، فقط نامش را تایپ کن. با چند حرف، پزشکان ذخیره‌شده پیشنهاد می‌شوند."),UiKit.matchWrap(this,0,8));box.addView(prescription,UiKit.matchWrap(this,0,10));box.addView(UiKit.muted(this,"برنامه مصرف"));box.addView(interval,UiKit.matchWrap(this,4,6));box.addView(days,UiKit.matchWrap(this,0,6));box.addView(firstDose);box.addView(UiKit.muted(this,"نوبت بعدی از زمان همین دوز + فاصله دارو حساب می‌شود."),UiKit.matchWrap(this,5,0));

        new AlertDialog.Builder(this).setView(box).setPositiveButton("ذخیره دارو",(d,w)->{
            String n=name.getText().toString().trim();if(n.isEmpty()){Toast.makeText(this,"نام دارو ضروری است.",Toast.LENGTH_SHORT).show();return;}
            int[]hours={4,6,8,12,24};NexaStore.Medicine m=existing==null?new NexaStore.Medicine():existing;m.name=n;m.dose=dose.getText().toString().trim();m.doctor=doctor.getText().toString().trim();m.prescriptionDate=prescriptionDate[0];m.intervalHours=hours[interval.getSelectedItemPosition()];
            Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,hm[0]);c.set(Calendar.MINUTE,hm[1]);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);long first=c.getTimeInMillis();if(first>System.currentTimeMillis()+60_000L)c.add(Calendar.DAY_OF_YEAR,-1);first=c.getTimeInMillis();
            m.firstDoseMillis=first;m.nextDoseMillis=first+m.intervalHours*60L*60L*1000L;
            int dd=0;try{dd=Integer.parseInt(days.getText().toString().trim());}catch(Exception ignored){}m.endMillis=dd>0?m.firstDoseMillis+dd*24L*60*60*1000:0;m.active=m.endMillis<=0||m.nextDoseMillis<=m.endMillis;
            MedicineScheduler.cancel(this,m.id);if(existing==null){NexaStore.addMedicine(this,m);NexaStore.MedicineDoseLog log=new NexaStore.MedicineDoseLog();log.medicineId=m.id;log.scheduledAt=m.firstDoseMillis;log.takenAt=m.firstDoseMillis;log.status="taken_on_time";NexaStore.addMedicineDoseLog(this,log);}else NexaStore.updateMedicine(this,m);
            if(m.active)MedicineScheduler.schedule(this,m);NexaStore.addHistory(this,"دارو",(existing==null?"دارو اضافه شد: ":"دارو ویرایش شد: ")+m.name);TodayNotificationManager.refresh(this);render();
        }).setNegativeButton("انصراف",null).show();
    }

    private interface DoctorCallback{void saved(NexaStore.Doctor d);}
    private void showDoctorDirectory(DoctorCallback cb){
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"پزشکان ذخیره‌شده"),UiKit.matchWrap(this,0,8));List<NexaStore.Doctor> docs=NexaStore.doctors(this);
        if(docs.isEmpty())box.addView(UiKit.muted(this,"هنوز پزشکی ذخیره نشده."),UiKit.matchWrap(this,0,8));
        for(NexaStore.Doctor doc:docs){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);Button pick=UiKit.secondaryButton(this,doc.name+(doc.specialty.isEmpty()?"":" • "+doc.specialty));pick.setOnClickListener(v->cb.saved(doc));row.addView(pick,new LinearLayout.LayoutParams(0,-2,1f));box.addView(row,UiKit.matchWrap(this,0,5));}
        Button add=UiKit.addIconButton(this);add.setContentDescription("افزودن پزشک");add.setOnClickListener(v->doctorDialog(cb));box.addView(add,UiKit.matchWrap(this,8,0));
        new AlertDialog.Builder(this).setTitle("انتخاب پزشک").setView(box).setNegativeButton("بستن",null).show();
    }

    private void doctorDialog(DoctorCallback cb){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"افزودن پزشک"),UiKit.matchWrap(this,0,8));EditText n=f("نام پزشک");EditText sp=f("تخصص");EditText file=f("شماره پرونده");EditText center=f("نام مطب / مرکز");EditText phone=f("شماره تماس");phone.setInputType(InputType.TYPE_CLASS_PHONE);EditText address=f("آدرس");for(View v:new View[]{n,sp,file,center,phone,address})box.addView(v,UiKit.matchWrap(this,0,6));new AlertDialog.Builder(this).setView(box).setPositiveButton("ذخیره پزشک",(d,w)->{if(n.getText().toString().trim().isEmpty())return;NexaStore.Doctor doc=new NexaStore.Doctor();doc.name=n.getText().toString().trim();doc.specialty=sp.getText().toString().trim();doc.fileNumber=file.getText().toString().trim();doc.center=center.getText().toString().trim();doc.phone=phone.getText().toString().trim();doc.address=address.getText().toString().trim();NexaStore.upsertDoctor(this,doc);cb.saved(doc);}).setNegativeButton("انصراف",null).show();}

    private void render(){
        if(list==null)return;list.removeAllViews();List<NexaStore.Medicine>ms=NexaStore.medicines(this);if(ms.isEmpty()){TextView e=UiKit.muted(this,"هنوز دارویی ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}
        for(NexaStore.Medicine m:ms){
            LinearLayout c=UiKit.colorfulCardLayout(this,2);c.addView(UiKit.sectionTitle(this,"💊 "+m.name));c.addView(UiKit.muted(this,(m.dose.isEmpty()?"":m.dose+" • ")+"هر "+m.intervalHours+" ساعت"),UiKit.matchWrap(this,5,3));c.addView(UiKit.muted(this,"نوبت بعد: "+PersianDateUtil.pretty(m.nextDoseMillis)));if(!m.doctor.isEmpty())c.addView(UiKit.muted(this,"پزشک: "+m.doctor));
            addTodayDoses(c,m);
            LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->medicineDialog(m));Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف دارو؟").setMessage(m.name).setPositiveButton("حذف",(d,w)->{MedicineScheduler.cancel(this,m.id);NexaStore.removeMedicine(this,m.id);TodayNotificationManager.refresh(this);render();}).setNegativeButton("انصراف",null).show());actions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dl.setMargins(UiKit.dp(this,6),0,0,0);actions.addView(del,dl);c.addView(actions,UiKit.matchWrap(this,10,0));list.addView(c,UiKit.matchWrap(this,0,12));
        }
    }

    private void addTodayDoses(LinearLayout card,NexaStore.Medicine m){
        long now=System.currentTimeMillis();Calendar cal=Calendar.getInstance();cal.setTimeInMillis(now);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();cal.add(Calendar.DAY_OF_YEAR,1);long end=cal.getTimeInMillis();long step=Math.max(1,m.intervalHours)*3600000L;long anchor=m.firstDoseMillis>0?m.firstDoseMillis:m.nextDoseMillis-step;while(anchor<start)anchor+=step;while(anchor-step>=start)anchor-=step;
        TextView heading=UiKit.muted(this,"دوزهای امروز");heading.setTextColor(UiKit.CYAN);card.addView(heading,UiKit.matchWrap(this,9,2));
        boolean any=false;for(long t=anchor;t<end;t+=step){if(t<start)continue;if(m.endMillis>0&&t>m.endMillis)break;any=true;NexaStore.MedicineDoseLog log=findDoseLog(m.id,t);String line;if(log!=null){if(Math.abs(log.takenAt-log.scheduledAt)>60_000L)line="✅ موعد "+time(t)+" • خوردم "+time(log.takenAt);else line="✅ "+time(t)+" • خوردم";}else if(t<m.nextDoseMillis-60_000L)line="🔴 "+time(t)+" • ثبت مصرف نشده";else if(Math.abs(t-m.nextDoseMillis)<60_000L)line=(t<now?"🔴 ":"⏳ ")+time(t)+" • "+(t<now?"عقب‌افتاده":"نوبت بعد");else line="○ "+time(t)+" • بعدی";card.addView(UiKit.muted(this,line),UiKit.matchWrap(this,2,0));}
        if(!any)card.addView(UiKit.muted(this,"برای امروز دوزی باقی نمانده."),UiKit.matchWrap(this,2,0));
    }

    private NexaStore.MedicineDoseLog findDoseLog(String medicineId,long scheduled){for(NexaStore.MedicineDoseLog x:NexaStore.medicineDoseLogsFor(this,medicineId))if(Math.abs(x.scheduledAt-scheduled)<60_000L)return x;return null;}
    private String time(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);return String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE));}
}
