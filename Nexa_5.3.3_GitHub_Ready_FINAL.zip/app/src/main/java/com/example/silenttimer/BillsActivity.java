package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class BillsActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 250);
        }
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Bills"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"قبض، قسط، اجاره و پرداخت‌های دوره‌ای"),UiKit.matchWrap(this,0,14));

        LinearLayout hero=UiKit.colorfulCardLayout(this,1);
        hero.addView(UiKit.sectionTitle(this,"💳 سررسیدهای مالی"));
        Button add=UiKit.primaryButton(this,"＋ ثبت پرداخت / قسط");
        add.setOnClickListener(v->addDialog());
        hero.addView(add,UiKit.matchWrap(this,10,0));
        root.addView(hero,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() { editDialog(null); }
    private void editDialog(NexaStore.BillItem existing) {
        LinearLayout box=UiKit.dialogPanel(this);

        Spinner type=new Spinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"قسط","قبض","اجاره","اشتراک","بیمه","چک","سایر"}
        ));

        EditText title=field("عنوان؛ مثلاً قسط وام");
        EditText amount=field("مبلغ تومان");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(amount);
        EditText note=field("توضیحات");

        Spinner repeat=new Spinner(this);
        repeat.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"یک‌بار","ماهانه","سالانه"}
        ));

        final long[] due={System.currentTimeMillis()+24L*60L*60L*1000L};
        Button date=UiKit.secondaryButton(this,"سررسید: "+PersianDateUtil.pretty(due[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,due[0],"تاریخ و ساعت سررسید",ms->{due[0]=ms;date.setText("سررسید: "+PersianDateUtil.pretty(ms));}));

        box.addView(type);box.addView(title);box.addView(amount);box.addView(repeat);box.addView(note);box.addView(date);
        if(existing!=null){type.setSelection(Math.max(0,java.util.Arrays.asList("قسط","قبض","اجاره","اشتراک","بیمه","چک","سایر").indexOf(existing.type)));
        title.setText(existing.title);amount.setText(NumberFormatUtil.grouped(existing.amount));note.setText(existing.note);
        repeat.setSelection(Math.max(0,java.util.Arrays.asList("یک‌بار","ماهانه","سالانه").indexOf(existing.recurrence)));
        due[0]=existing.dueDate;date.setText("سررسید: "+PersianDateUtil.pretty(due[0]));}
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"1440,120,0":existing.alertRules,existing==null?10:existing.alertRepeat);

        new AlertDialog.Builder(this)
                .setTitle("سررسید جدید")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(type.getSelectedItem());

                    NexaStore.BillItem x=existing==null?new NexaStore.BillItem():existing;
                    x.alertRules=alerts.rules();x.alertRepeat=alerts.repeatMinutes();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.amount=NumberFormatUtil.longValue(amount.getText());
                    x.recurrence=String.valueOf(repeat.getSelectedItem());
                    x.note=note.getText().toString().trim();
                    x.dueDate=due[0];
                    if(existing==null)NexaStore.addBill(this,x);else NexaStore.updateBill(this,x);
                    schedule(x);
                    NexaStore.addHistory(this,"پرداخت","ثبت شد: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void schedule(NexaStore.BillItem x) {
        LinkedReminderHelper.upsert(
                this,
                "bill:"+x.id,
                x.title,
                x.type,
                "💳",
                (x.amount>0?String.format(Locale.US,"%,d تومان",x.amount):"")+(x.note.isEmpty()?"":" • "+x.note),
                x.dueDate,
                x.alertRules,
                            x.alertRepeat
        );
    }

    private void markPaid(NexaStore.BillItem x) {
        if ("ماهانه".equals(x.recurrence) || "سالانه".equals(x.recurrence)) {
            x.dueDate="ماهانه".equals(x.recurrence)
                    ? PersianDateUtil.addJalaliMonths(x.dueDate,1)
                    : PersianDateUtil.addJalaliYears(x.dueDate,1);
            x.paid=false;
            NexaStore.updateBill(this,x);
            schedule(x);
            NexaStore.addHistory(this,"پرداخت","پرداخت شد و سررسید بعدی ثبت شد: "+x.title);
        } else {
            x.paid=true;
            NexaStore.updateBill(this,x);
            LinkedReminderHelper.remove(this,"bill:"+x.id);
            NexaStore.addHistory(this,"پرداخت","پرداخت شد: "+x.title);
        }
        render();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.BillItem> data=NexaStore.bills(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"سررسیدی ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        for(NexaStore.BillItem x:data){
            LinearLayout c=UiKit.colorfulCardLayout(this,x.paid?2:1);
            c.setAlpha(x.paid?0.55f:1f);
            c.addView(UiKit.sectionTitle(this,"💳 "+x.title));
            c.addView(UiKit.muted(this,x.type+" • "+x.recurrence+" • "+PersianDateUtil.pretty(x.dueDate)),UiKit.matchWrap(this,5,2));
            if(x.amount>0)c.addView(UiKit.muted(this,String.format(Locale.US,"%,d تومان",x.amount)));
            if(!x.note.isEmpty())c.addView(UiKit.muted(this,x.note),UiKit.matchWrap(this,4,0));

            LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
            Button paid=UiKit.secondaryButton(this,x.paid?"پرداخت شده ✓":"پرداخت شد");paid.setEnabled(!x.paid);paid.setOnClickListener(v->markPaid(x));
            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editDialog(x));
            Button del=UiKit.deleteIconButton(this);
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                .setMessage(x.title).setPositiveButton("حذف",(d,w)->{
                LinkedReminderHelper.remove(this,"bill:"+x.id);
                NexaStore.removeBill(this,x.id);render();
                }).setNegativeButton("انصراف",null).show());
            actions.addView(paid,new LinearLayout.LayoutParams(0,-2,1f));
            LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));ep.setMargins(UiKit.dp(this,6),0,0,0);actions.addView(edit,ep);
            LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dp.setMargins(UiKit.dp(this,5),0,0,0);actions.addView(del,dp);
            c.addView(actions,UiKit.matchWrap(this,10,0));

            list.addView(c,UiKit.matchWrap(this,0,10));
        }
    }
}
