package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class CaseActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 250);
        }
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,UiKit.matchWrap(this,0,12));

        root.addView(UiKit.title(this,"Nexa Case"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"پرونده‌ها، وقت دادگاه و اطلاعات جلسه‌ها"),UiKit.matchWrap(this,0,14));

        LinearLayout hero=UiKit.colorfulCardLayout(this,5);
        hero.addView(UiKit.sectionTitle(this,"⚖️ پرونده و وقت دادگاه"));
        Button add=UiKit.primaryButton(this,"＋ ثبت پرونده / وقت دادگاه");
        add.setOnClickListener(v->addDialog());
        hero.addView(add,UiKit.matchWrap(this,10,0));
        root.addView(hero,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() { editDialog(null); }
    private void editDialog(NexaStore.CaseItem existing) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        EditText title=field("عنوان پرونده");
        EditText caseNumber=field("شماره پرونده");
        EditText court=field("نام دادگاه");
        EditText branch=field("شعبه");
        EditText party=field("طرف پرونده");
        EditText lawyer=field("نام وکیل");
        EditText note=field("توضیحات");
        final long[] when={System.currentTimeMillis()+24L*60L*60L*1000L};
        Button date=UiKit.secondaryButton(this,PersianDateUtil.pretty(when[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,when[0],"تاریخ و ساعت جلسه",ms->{when[0]=ms;date.setText(PersianDateUtil.pretty(ms));}));

        box.addView(title);box.addView(caseNumber);box.addView(court);box.addView(branch);
        box.addView(party);box.addView(lawyer);box.addView(note);box.addView(date);
        if(existing!=null){title.setText(existing.title);caseNumber.setText(existing.caseNumber);court.setText(existing.court);
        branch.setText(existing.branch);party.setText(existing.counterparty);lawyer.setText(existing.lawyer);note.setText(existing.note);
        when[0]=existing.whenMillis;date.setText(PersianDateUtil.pretty(when[0]));}
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"10080,1440,0":existing.alertRules,existing==null?10:existing.alertRepeat);

        new AlertDialog.Builder(this)
                .setTitle("پرونده جدید")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())return;
                    NexaStore.CaseItem x=existing==null?new NexaStore.CaseItem():existing;
                    x.alertRules=alerts.rules();x.alertRepeat=alerts.repeatMinutes();
                    x.title=t;
                    x.caseNumber=caseNumber.getText().toString().trim();
                    x.court=court.getText().toString().trim();
                    x.branch=branch.getText().toString().trim();
                    x.counterparty=party.getText().toString().trim();
                    x.lawyer=lawyer.getText().toString().trim();
                    x.note=note.getText().toString().trim();
                    x.whenMillis=when[0];
                    if(existing==null)NexaStore.addCase(this,x);else NexaStore.updateCase(this,x);
                    LinkedReminderHelper.upsert(
                            this,
                            "case:"+x.id,
                            "وقت دادگاه: "+x.title,
                            "دادگاه",
                            "⚖️",
                            "شماره پرونده: "+x.caseNumber+" • "+x.court+" "+x.branch,
                            x.whenMillis,
                            x.alertRules,
                            x.alertRepeat
                    );
                    NexaStore.addHistory(this,"دادگاه","ثبت شد: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.CaseItem> data=NexaStore.cases(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"هنوز پرونده‌ای ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        for(NexaStore.CaseItem x:data){
            LinearLayout c=UiKit.colorfulCardLayout(this,5);
            c.addView(UiKit.sectionTitle(this,"⚖️ "+x.title));
            c.addView(UiKit.muted(this,"جلسه: "+PersianDateUtil.pretty(x.whenMillis)),UiKit.matchWrap(this,6,2));

            if(!x.caseNumber.isEmpty())c.addView(UiKit.muted(this,"شماره پرونده: "+x.caseNumber));
            if(!x.court.isEmpty())c.addView(UiKit.muted(this,"دادگاه: "+x.court+(x.branch.isEmpty()?"":" • شعبه "+x.branch)));
            if(!x.counterparty.isEmpty())c.addView(UiKit.muted(this,"طرف پرونده: "+x.counterparty));
            if(!x.lawyer.isEmpty())c.addView(UiKit.muted(this,"وکیل: "+x.lawyer));
            if(!x.note.isEmpty())c.addView(UiKit.muted(this,x.note),UiKit.matchWrap(this,5,0));

            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editDialog(x));
            LinearLayout iconActions=new LinearLayout(this);iconActions.setGravity(Gravity.CENTER_VERTICAL);iconActions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
            Button del=UiKit.deleteIconButton(this);
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                .setMessage(x.title).setPositiveButton("حذف",(d,w)->{
                LinkedReminderHelper.remove(this,"case:"+x.id);
                NexaStore.removeCase(this,x.id);render();
                }).setNegativeButton("انصراف",null).show());
            LinearLayout.LayoutParams idlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));idlp.setMargins(UiKit.dp(this,5),0,0,0);iconActions.addView(del,idlp);c.addView(iconActions,UiKit.matchWrap(this,8,0));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
    }
}
