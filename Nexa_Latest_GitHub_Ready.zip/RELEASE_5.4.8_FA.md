# Nexa 5.4.8 — Stability & Regression Batch

نسخه: 5.4.8
Build: 30
پایه: 5.4.7 Hotfix تأییدشده روی گوشی

## اصلاحات این بسته
- هشدار Medicine و Reminder اکنون صدا/ویبره Alarm را از خود Receiver شروع می‌کنند؛ وابسته به بازشدن Full Screen Activity نیستند.
- Notification Channel هشدارها نسخه جدید دارد تا تنظیمات صدای صحیح روی نصب ارتقایی اعمال شود.
- Full Screen هشدار Medicine/Reminder حفظ شده و Emergency نیز هنگام فعال بودن مسیر Full Screen/Lock Screen دارد (در چارچوب مجوزهای Android 14 و تنظیمات Lock Screen دستگاه).
- صدای تأیید خروج خودکار از Silent تقویت شد و از STREAM_RING بعد از بازگرداندن Ringer Mode پخش می‌شود.
- Theme پس از فعال‌سازی فوراً با بازسازی Task اصلی روی کل Nexa اعمال می‌شود؛ نیاز به بستن دستی برنامه نیست.
- رنگ حلقه Timer از Accent پوسته فعال گرفته می‌شود.
- دکمه جستجوی سراسری اضافی از Header صفحه Home حذف شد؛ خود Nexa Search حذف نشده است.
- یادآور جدید به‌صورت پیش‌فرض فقط یک هشدار «زمان اصلی» دارد؛ هشدارهای بیشتر با «افزودن هشدار» اضافه می‌شوند.
- ثبت تکراری History در پایان Silent حذف شد.

## موارد بزرگ طراحی که عمداً در این Build وارد نشدند
برای جلوگیری از Regression مجدد، بازطراحی‌های سنگین Assets، بدهی/فاکتور، مدیریت اطلاعات مشترک، کرکره‌ای‌سازی سراسری و بازطراحی لیست خرید در Build جداگانه انجام می‌شوند. این فایل آن‌ها را حذف‌شده تلقی نمی‌کند؛ فقط از Stability Batch جدا شده‌اند.

## تست ضروری
1. ورود اثر انگشت + Home + Recent Apps
2. Silent و Popup پایان + خروج خودکار + Beep
3. Medicine در Silent و Lock Screen
4. Reminder/Alarm روی Lock Screen
5. Emergency روی Lock Screen
6. Theme: اعمال فوری روی کل برنامه
7. Timer: رنگ هماهنگ Theme
8. Reminder جدید: یک هشدار پیش‌فرض + افزودن هشدار
