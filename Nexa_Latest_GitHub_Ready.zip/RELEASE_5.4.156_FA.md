# Nexa 5.4.156 / Build 178 — Candidate (29 October 2026)

Base: exact GitHub `main` ZIP blob SHA `ce7561cc6982d7e0e35f841971c5b1dc69160cab` at commit `500241e6db46c0d2dc6b0584d51f343c59a942e7` (Build 177, both GitHub workflows successful).

## Changes

- Financial voice parser now handles compound Persian amounts, e.g. `۵۰ میلیون و ۲۰۰ هزار` = 50,200,000 toman. Does not accept truncated or ambiguous multi-part amounts, repeated/out-of-order units, fractional/negative/rial instructions, or overflow.
- Credit commands like `پنجاه میلیون از احمدی طلب دارم` recognized conservatively; mixed financial directions rejected.
- Financial voice party lookup prioritizes exact normalized names over earlier near matches; duplicate exact names remain blocked.
- Voice draft routes added for new assets and garage vehicles, pre-filling editable form names. Nothing is saved until the user explicitly presses Save.
- Removed duplicate hero from asset overview; existing collapsible market section remains available.
- Regression instrumentation expanded with voice safety, composite amount and asset/vehicle draft tests.
- VersionCode 178 / VersionName 5.4.156; existing applicationId and production signing configuration unchanged. No database schema changes or silent financial writes.

## Validation

- Local pure Java `jvmtests/com/example/silenttimer/Smoke.java` run against updated production parser/recurrence/date classes: 105 assertions passed.
- Additional static checks and ZIP integrity/security scan performed before handoff.
- Full Android compilation, emulator regression and install/upgrade are NOT verified locally; await GitHub workflows for this new ZIP. Production signing secrets remain in GitHub only.

Upload this single `Nexa_Latest_GitHub_Ready.zip` to the repository root on `main`, replacing the old ZIP. Do not upload unpacked source or signing files.
