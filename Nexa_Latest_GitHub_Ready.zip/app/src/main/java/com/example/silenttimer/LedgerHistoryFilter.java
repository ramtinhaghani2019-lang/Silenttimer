package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Read-only transaction filtering. Never reorders rows or recalculates running balances. */
public final class LedgerHistoryFilter {
    private LedgerHistoryFilter() {}

    public static final String ALL="ALL";
    public static final String[] KINDS={ALL,"DEBT","CREDIT","PAYMENT","RECEIPT"};

    /** Normalizes Persian and Arabic digit/letter variants and numeric grouping separators. */
    public static String normalize(String value) {
        if(value==null)return "";
        StringBuilder out=new StringBuilder(value.length());
        for(int i=0;i<value.length();i++) {
            char c=value.charAt(i);
            if(c>='۰'&&c<='۹')out.append((char)('0'+c-'۰'));
            else if(c>='\u0660'&&c<='\u0669')out.append((char)('0'+c-'\u0660'));
            else if(c=='ي'||c=='ى')out.append('ی');
            else if(c=='ك')out.append('ک');
            else if(c=='٬'||c==','||c=='\u00A0'||c=='\u202F')continue;
            else if(Character.isWhitespace(c))out.append(' ');
            else out.append(c);
        }
        return out.toString().trim().toLowerCase(Locale.ROOT);
    }

    /** Unknown kinds match no transactions; ALL matches all supported and legacy kinds. */
    public static boolean matches(LedgerReport.Row row,String kind,String query) {
        if(row==null||row.entry==null)return false;
        String selected=kind==null?ALL:kind;
        if(!ALL.equals(selected) && !selected.equals(row.entry.kind))return false;
        String q=normalize(query);
        if(q.isEmpty())return true;
        String searchable=normalize((row.entry.note==null?"":row.entry.note)+" "
            +(row.partyName==null?"":row.partyName)+" "
            +LedgerPresentation.label(row.entry.kind)+" "
            +LedgerPresentation.shortLabel(row.entry.kind)+" "
            +row.entry.amount);
        return searchable.contains(q);
    }

    /** Inclusive calendar-day window; unlike fixed 24h subtraction, DST is respected. */
    public static long recentStart(int days,long now,TimeZone zone) {
        if(days<=0)return Long.MIN_VALUE;
        Calendar c=Calendar.getInstance(zone==null?TimeZone.getDefault():zone);
        c.setTimeInMillis(now);
        c.set(Calendar.HOUR_OF_DAY,0);
        c.set(Calendar.MINUTE,0);
        c.set(Calendar.SECOND,0);
        c.set(Calendar.MILLISECOND,0);
        c.add(Calendar.DAY_OF_YEAR,1-days);
        return c.getTimeInMillis();
    }

    /** Group transactions by LOCAL calendar day, not UTC date or insert order. */
    public static int dayKey(long when,TimeZone zone) {
        Calendar c=Calendar.getInstance(zone==null?TimeZone.getDefault():zone);
        c.setTimeInMillis(when);
        return c.get(Calendar.YEAR)*10000+(c.get(Calendar.MONTH)+1)*100+c.get(Calendar.DAY_OF_MONTH);
    }

    /** Date filter changes display only. Original running balances on Row are retained. */
    public static List<LedgerReport.Row> selectBetween(List<LedgerReport.Row> rows,
                String kind,String query,long fromInclusive,long toInclusive) {
        if(rows==null||rows.isEmpty()||fromInclusive>toInclusive)return Collections.emptyList();
        List<LedgerReport.Row> result=new ArrayList<>();
        for(LedgerReport.Row row:rows) {
            if(row!=null&&row.entry!=null&&row.entry.dateMillis>=fromInclusive
                  &&row.entry.dateMillis<=toInclusive&&matches(row,kind,query))result.add(row);
        }
        return result;
    }

    public static List<LedgerReport.Row> select(List<LedgerReport.Row> rows,String kind,String query) {
        return selectBetween(rows,kind,query,Long.MIN_VALUE,Long.MAX_VALUE);
    }
}
