package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;

public final class NotificationChannelHelper {
    public static final String CHANNEL_MISSED_CALL = "nexa_missed_call_v2";
    public static final String CHANNEL_REMINDER = "nexa_reminder_core_v1";
    public static final String CHANNEL_BATTERY_ALARM = "nexa_battery_alarm_v1";
    public static final String CHANNEL_LOW_BATTERY = "nexa_low_battery_v1";
    public static final String CHANNEL_THEFT_ALARM = "nexa_theft_alarm_v1";
    public static final String CHANNEL_SECURITY = "nexa_security_v1";

    private NotificationChannelHelper(){}
    public static void ensureMedicine(Context c){
        if(Build.VERSION.SDK_INT<26)return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch=new NotificationChannel(MedicineAlarmReceiver.CHANNEL,"Nexa Medicine Alarm",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("هشدار زنگ‌دار دارو؛ تا تأیید کاربر هر ۵ دقیقه تکرار می‌شود");
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,700,350,700,350,1000});
        Uri sound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        AudioAttributes attrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        ch.setSound(sound,attrs);
        // Medicine is an explicit alarm, not an ordinary notification. When Nexa has DND policy access, allow it to be heard in Silent/DND.
        try{ch.setBypassDnd(true);}catch(Exception ignored){}
        nm.createNotificationChannel(ch);
    }


    public static void ensureCoreChannels(Context c){
        if(Build.VERSION.SDK_INT<26 || c==null)return;
        ensureSimple(c, CHANNEL_MISSED_CALL, "تماس‌های از دست‌رفته", "نمایش تماس‌های از دست‌رفته Nexa روی صفحه قفل", NotificationManager.IMPORTANCE_HIGH, true);
        ensureSimple(c, CHANNEL_REMINDER, "یادآورها", "یادآورهای عمومی Nexa", NotificationManager.IMPORTANCE_HIGH, true);
        ensureSimple(c, CHANNEL_BATTERY_ALARM, "هشدار شارژ باتری", "هشدار رسیدن شارژ به حد تعیین‌شده", NotificationManager.IMPORTANCE_HIGH, true);
        ensureSimple(c, CHANNEL_LOW_BATTERY, "باتری کم", "هشدار کاهش شارژ باتری", NotificationManager.IMPORTANCE_HIGH, true);
        ensureSimple(c, CHANNEL_THEFT_ALARM, "هشدار ضدسرقت", "هشدار امنیتی قطع شارژر", NotificationManager.IMPORTANCE_HIGH, true);
        ensureSimple(c, CHANNEL_SECURITY, "امنیت Nexa", "اعلان‌های امنیتی Nexa", NotificationManager.IMPORTANCE_HIGH, true);
    }

    public static void ensureMissedCall(Context c){
        if(Build.VERSION.SDK_INT<26 || c==null)return;
        ensureSimple(c, CHANNEL_MISSED_CALL, "تماس‌های از دست‌رفته", "نمایش تمام‌صفحه و واضح تماس‌های از دست‌رفته Nexa روی صفحه قفل", NotificationManager.IMPORTANCE_HIGH, true);
    }

    private static void ensureSimple(Context c,String id,String name,String description,int importance,boolean vibration){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm==null || nm.getNotificationChannel(id)!=null)return;
        NotificationChannel ch=new NotificationChannel(id,name,importance);
        ch.setDescription(description);
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        ch.setShowBadge(true);
        ch.enableVibration(vibration);
        try{ch.setBypassDnd(false);}catch(Exception ignored){}
        nm.createNotificationChannel(ch);
    }
}
