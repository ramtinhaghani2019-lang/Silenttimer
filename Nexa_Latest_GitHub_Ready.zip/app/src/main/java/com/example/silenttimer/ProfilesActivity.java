package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class ProfilesActivity extends Activity {
    private LinearLayout profiles,schedules,summary;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}

    private EditText field(String hint){return UiKit.styleField(this,new EditText(this),hint);}
    private Spinner spinner(String[] values){Spinner s=UiKit.styledSpinner(this);ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,Arrays.asList(values)){
        @Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);t.setPadding(12,14,12,14);return t;}
        @Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);t.setPadding(18,16,18,16);return t;}
    };s.setAdapter(a);return s;}

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        sc.setBackground(UiKit.screenBackground(this));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.header(this,"پروفایل‌های تمرکز",v->finish()),UiKit.matchWrap(this,0,6));
        root.addView(UiKit.muted(this,"🔕 حالت‌های آماده و زمان‌بندی سکوت، یک‌جا و در دسترس"),UiKit.matchWrap(this,0,16));
        summary=new LinearLayout(this);summary.setOrientation(LinearLayout.VERTICAL);
        root.addView(summary,UiKit.matchWrap(this,0,16));

        LinearLayout profileHeader=UiKit.colorfulCardLayout(this,5);
        profileHeader.addView(NexaFocusUi.section(this,"⚡ پروفایل‌های آماده"));
        profileHeader.addView(UiKit.muted(this,"برای جلسه، خواب یا مطالعه یک حالت بساز؛ با یک لمس فعالش کن."),UiKit.matchWrap(this,3,12));
        Button add=UiKit.primaryButton(this,"＋ ساخت پروفایل");
        add.setOnClickListener(v->profileDialog(null));profileHeader.addView(add);
        root.addView(profileHeader,UiKit.matchWrap(this,0,12));
        profiles=new LinearLayout(this);profiles.setOrientation(LinearLayout.VERTICAL);
        root.addView(profiles,UiKit.matchWrap(this,0,13));

        LinearLayout weekly=UiKit.colorfulCardLayout(this,2);
        weekly.addView(NexaFocusUi.section(this,"🗓 برنامه هفتگی"));
        weekly.addView(UiKit.muted(this,"سکوت خودکار برای ساعت‌های معین در روزهای انتخابی."),UiKit.matchWrap(this,3,12));
        Button addSch=UiKit.primaryButton(this,"＋ زمان‌بندی جدید");
        addSch.setOnClickListener(v->scheduleDialog(null));weekly.addView(addSch);
        root.addView(weekly,UiKit.matchWrap(this,0,12));
        schedules=new LinearLayout(this);schedules.setOrientation(LinearLayout.VERTICAL);
        root.addView(schedules);setContentView(sc);render();
    }

    private void profileDialog(NexaStore.Profile existing){
        LinearLayout b=UiKit.dialogPanel(this);b.addView(UiKit.sectionTitle(this,existing==null?"پروفایل جدید":"ویرایش پروفایل"),UiKit.matchWrap(this,0,8));
        EditText name=field("نام پروفایل؛ مثلاً جلسه");
        Spinner hours=spinner(new String[]{"۰ ساعت","۱ ساعت","۲ ساعت","۳ ساعت","۴ ساعت","۵ ساعت","۶ ساعت","۸ ساعت","۱۲ ساعت","۲۴ ساعت"});
        final int[] hourValues={0,1,2,3,4,5,6,8,12,24};
        Spinner minutes=spinner(new String[]{"۰ دقیقه","۵ دقیقه","۱۰ دقیقه","۱۵ دقیقه","۲۰ دقیقه","۳۰ دقیقه","۴۵ دقیقه"});
        final int[] minuteValues={0,5,10,15,20,30,45};
        Switch allowed=UiKit.styledSwitch(this);allowed.setText("تماس‌های مجاز فعال باشند");allowed.setTextColor(UiKit.TEXT);allowed.setChecked(true);
        if(existing!=null){name.setText(existing.name);int h=existing.minutes/60,m=existing.minutes%60;int hi=0,mi=0;for(int i=0;i<hourValues.length;i++)if(hourValues[i]<=h)hi=i;for(int i=0;i<minuteValues.length;i++)if(minuteValues[i]<=m)mi=i;hours.setSelection(hi);minutes.setSelection(mi);allowed.setChecked(existing.allowedCalls);}
        b.addView(UiKit.fieldLabel(this,"عنوان پروفایل"));
        b.addView(name,UiKit.matchWrap(this,0,10));
        b.addView(UiKit.fieldLabel(this,"مدت زمان سکوت"));
        LinearLayout timeRow=new LinearLayout(this);timeRow.setOrientation(LinearLayout.HORIZONTAL);
        timeRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams hourLp=new LinearLayout.LayoutParams(0,-2,1f);
        hourLp.setMargins(0,0,UiKit.dp(this,5),0);
        timeRow.addView(hours,hourLp);
        LinearLayout.LayoutParams minLp=new LinearLayout.LayoutParams(0,-2,1f);
        timeRow.addView(minutes,minLp);
        b.addView(timeRow,UiKit.matchWrap(this,0,12));
        b.addView(UiKit.fieldLabel(this,"تماس‌های ضروری"));b.addView(allowed);
        new AlertDialog.Builder(this).setView(b).setPositiveButton("ذخیره",(d,w)->{NexaStore.Profile p=existing==null?new NexaStore.Profile():existing;p.name=name.getText().toString().trim();p.minutes=hourValues[hours.getSelectedItemPosition()]*60+minuteValues[minutes.getSelectedItemPosition()];if(p.minutes<=0)p.minutes=60;p.mode=0;p.allowedCalls=allowed.isChecked();if(p.name.isEmpty())p.name="پروفایل";if(existing==null)NexaStore.addProfile(this,p);else NexaStore.updateProfile(this,p);render();}).setNegativeButton("انصراف",null).show();
    }

    private void scheduleDialog(NexaStore.WeeklySchedule existing){
        LinearLayout b=UiKit.dialogPanel(this);b.addView(UiKit.sectionTitle(this,existing==null?"زمان‌بندی جدید":"ویرایش زمان‌بندی"),UiKit.matchWrap(this,0,8));
        EditText name=field("نام زمان‌بندی");Spinner days=spinner(new String[]{"شنبه تا چهارشنبه","همه روزها","پنجشنبه و جمعه"});
        Button start=UiKit.secondaryButton(this,"شروع 09:00"),end=UiKit.secondaryButton(this,"پایان 17:00");final int[] sh={9,0},eh={17,0};
        if(existing!=null){name.setText(existing.name);sh[0]=existing.startHour;sh[1]=existing.startMinute;eh[0]=existing.endHour;eh[1]=existing.endMinute;start.setText(String.format(Locale.US,"شروع %02d:%02d",sh[0],sh[1]));end.setText(String.format(Locale.US,"پایان %02d:%02d",eh[0],eh[1]));if(existing.daysMask==127)days.setSelection(1);}
        start.setOnClickListener(v->PersianDatePickerHelper.pickTime(this,sh[0],sh[1],"ساعت شروع",(h,m)->{sh[0]=h;sh[1]=m;start.setText(String.format(Locale.US,"شروع %02d:%02d",h,m));}));
        end.setOnClickListener(v->PersianDatePickerHelper.pickTime(this,eh[0],eh[1],"ساعت پایان",(h,m)->{eh[0]=h;eh[1]=m;end.setText(String.format(Locale.US,"پایان %02d:%02d",h,m));}));
        b.addView(UiKit.fieldLabel(this,"نام زمان‌بندی"));b.addView(name,UiKit.matchWrap(this,0,8));
        b.addView(UiKit.fieldLabel(this,"روزهای هفته"));b.addView(days,UiKit.matchWrap(this,0,8));
        b.addView(UiKit.fieldLabel(this,"ساعت شروع و پایان"));
        b.addView(start,UiKit.matchWrap(this,0,6));b.addView(end,UiKit.matchWrap(this,0,4));
        new AlertDialog.Builder(this).setView(b).setPositiveButton("ذخیره",(d,w)->{NexaStore.WeeklySchedule s=existing==null?new NexaStore.WeeklySchedule():existing;s.name=name.getText().toString().trim();if(s.name.isEmpty())s.name="زمان‌بندی";int sel=days.getSelectedItemPosition();if(sel==1)s.daysMask=127;else if(sel==2)s.daysMask=(1<<(5-1))|(1<<(6-1));else s.daysMask=(1<<(7-1))|(1<<(1-1))|(1<<(2-1))|(1<<(3-1))|(1<<(4-1));s.startHour=sh[0];s.startMinute=sh[1];s.endHour=eh[0];s.endMinute=eh[1];s.mode=0;if(existing!=null)WeeklyScheduler.cancel(this,s.id);if(existing==null)NexaStore.addSchedule(this,s);else NexaStore.updateSchedule(this,s);WeeklyScheduler.scheduleNext(this,s);render();}).setNegativeButton("انصراف",null).show();
    }

    private String duration(int minutes){int h=minutes/60,m=minutes%60;if(h>0&&m>0)return h+" ساعت و "+m+" دقیقه";if(h>0)return h+" ساعت";return m+" دقیقه";}
    private void render(){
        if(profiles==null||schedules==null||summary==null)return;
        List<NexaStore.Profile> allProfiles=NexaStore.profiles(this);
        List<NexaStore.WeeklySchedule> allSchedules=NexaStore.schedules(this);
        int active=0;for(NexaStore.WeeklySchedule a:allSchedules)if(a.enabled)active++;
        summary.removeAllViews();
        summary.addView(NexaFocusUi.metrics(this,allProfiles.size(),active,allSchedules.size()),UiKit.matchWrap(this));
        profiles.removeAllViews();
        if(allProfiles.isEmpty())profiles.addView(NexaFocusUi.empty(this,"هنوز پروفایلی ندارید","با ساخت اولین پروفایل، سکوت دلخواهتان با یک لمس فعال می‌شود."),UiKit.matchWrap(this,0,10));
        for(NexaStore.Profile p:allProfiles){
            LinearLayout c=NexaFocusUi.record(this,"⚡",p.name,duration(p.minutes)+" • حالت Silent",UiKit.PURPLE);
            c.addView(NexaFocusUi.status(this,p.allowedCalls?"تماس ضروری: مجاز":"تماس ضروری: خاموش",p.allowedCalls?UiKit.GREEN:UiKit.MUTED),UiKit.matchWrap(this,10,9));
            Button run=UiKit.primaryButton(this,"🔕 فعال کردن "+p.name);
            run.setOnClickListener(v->{AppPrefs.setAllowedCallsEnabled(this,p.allowedCalls);Intent i=new Intent(this,SilentTimerService.class);i.setAction(SilentTimerService.ACTION_START);i.putExtra(SilentTimerService.EXTRA_MINUTES,p.minutes);i.putExtra(SilentTimerService.EXTRA_TARGET_MODE,AudioManager.RINGER_MODE_SILENT);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);NexaStore.addHistory(this,"پروفایل",p.name+" فعال شد");finish();});
            c.addView(run);
            LinearLayout a=new LinearLayout(this);a.setGravity(Gravity.CENTER_VERTICAL);
            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->profileDialog(p));
            Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف پروفایل؟").setPositiveButton("حذف",(d,w)->{NexaStore.removeProfile(this,p.id);render();}).setNegativeButton("انصراف",null).show());
            a.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));dl.setMargins(UiKit.dp(this,7),0,0,0);a.addView(del,dl);
            c.addView(a,UiKit.matchWrap(this,8,0));profiles.addView(c,UiKit.matchWrap(this,0,10));
        }
        schedules.removeAllViews();
        if(allSchedules.isEmpty())schedules.addView(NexaFocusUi.empty(this,"برنامه هفتگی خالی است","برای فعال‌سازی خودکار Silent یک زمان‌بندی بسازید."),UiKit.matchWrap(this,0,10));
        for(NexaStore.WeeklySchedule item:allSchedules){
            final NexaStore.WeeklySchedule s=item;
            LinearLayout c=NexaFocusUi.record(this,"🗓",s.name,String.format(Locale.US,"%02d:%02d تا %02d:%02d • Silent",s.startHour,s.startMinute,s.endHour,s.endMinute),s.enabled?UiKit.GREEN:UiKit.BLUE);
            c.addView(NexaFocusUi.status(this,s.enabled?"زمان‌بندی فعال":"زمان‌بندی غیرفعال",s.enabled?UiKit.GREEN:UiKit.MUTED),UiKit.matchWrap(this,9,4));
            Switch enabled=UiKit.styledSwitch(this);enabled.setText("فعال‌سازی خودکار");enabled.setTextColor(UiKit.TEXT);enabled.setChecked(s.enabled);
            enabled.setOnCheckedChangeListener((button,value)->{s.enabled=value;WeeklyScheduler.cancel(this,s.id);NexaStore.updateSchedule(this,s);if(value)WeeklyScheduler.scheduleNext(this,s);render();});
            c.addView(enabled,UiKit.matchWrap(this,0,6));
            LinearLayout a=new LinearLayout(this);a.setGravity(Gravity.CENTER_VERTICAL);
            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->scheduleDialog(s));
            Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف زمان‌بندی؟").setPositiveButton("حذف",(d,w)->{WeeklyScheduler.cancel(this,s.id);NexaStore.removeSchedule(this,s.id);render();}).setNegativeButton("انصراف",null).show());
            a.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));dl.setMargins(UiKit.dp(this,7),0,0,0);a.addView(del,dl);
            c.addView(a);schedules.addView(c,UiKit.matchWrap(this,0,10));
        }
    }
}
