package com.example.silenttimer;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import java.util.Calendar;
public class ScheduleReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){String id=i.getStringExtra("id");for(NexaStore.WeeklySchedule s:NexaStore.schedules(c)){if(!s.id.equals(id)||!s.enabled)continue;Calendar end=Calendar.getInstance();end.set(Calendar.HOUR_OF_DAY,s.endHour);end.set(Calendar.MINUTE,s.endMinute);end.set(Calendar.SECOND,0);end.set(Calendar.MILLISECOND,0);if(end.getTimeInMillis()<=System.currentTimeMillis())end.add(Calendar.DAY_OF_YEAR,1);Intent service=new Intent(c,SilentTimerService.class);service.setAction(SilentTimerService.ACTION_START);service.putExtra(SilentTimerService.EXTRA_END_AT,end.getTimeInMillis());service.putExtra(SilentTimerService.EXTRA_TARGET_MODE,s.mode==1?AudioManager.RINGER_MODE_VIBRATE:AudioManager.RINGER_MODE_SILENT);try{if(Build.VERSION.SDK_INT>=26)c.startForegroundService(service);else c.startService(service);}catch(Exception ignored){}NexaStore.addHistory(c,"پروفایل","زمان‌بندی "+s.name+" فعال شد");WeeklyScheduler.scheduleNext(c,s);break;}}}
