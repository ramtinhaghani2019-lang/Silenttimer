package com.example.silenttimer;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.GradientDrawable;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** Native RTL bottom sheet, backed by real NexaOutlineIcon instances; never stores a selected asset. */
final class AssetSelectionSheet {
    private AssetSelectionSheet(){}
    static String category(String raw){
        if(raw==null)return "سایر";
        if(raw.contains("صندوق")||raw.contains("کاریزما")||raw.contains("سهام")||raw.contains("بورس"))return "صندوق‌ها و سهام";
        if(raw.contains("طلا")||raw.contains("نقره")||raw.contains("مس")||raw.contains("شمش"))return "فلزات گران‌بها";
        if(raw.contains("دلار")||raw.contains("یورو")||raw.contains("ارز"))return "ارزها";
        if(raw.contains("سکه"))return "سکه‌ها";
        if(raw.contains("سهام")||raw.contains("بورس")||raw.contains("صندوق")||raw.contains("کاریزما"))return "صندوق‌ها و سهام";
        if(raw.contains("اونس"))return "فلزات گران‌بها";
        return "سایر";
    }
    static String unit(String raw){
        if(raw==null)return "واحد";
        if(raw.contains("صندوق")||raw.contains("کاریزما"))return "واحد";
        if(raw.contains("طلا")||raw.contains("نقره")||raw.contains("مس"))return "گرم";
        if(raw.contains("سکه"))return "عدد";
        if(raw.contains("سهام")||raw.contains("بورس"))return "سهم";
        return "واحد";
    }
    static String normalize(String raw){
        if(raw==null)return "";
        StringBuilder b=new StringBuilder();
        for(int i=0;i<raw.length();i++){
            char c=raw.charAt(i);
            if(c=='ي')c='ی'; if(c=='ك')c='ک';
            if(c=='أ'||c=='إ')c='ا';
            if(c=='‌'||c==' '||c=='-')continue;
            b.append(c);
        }
        return b.toString().toLowerCase(java.util.Locale.ROOT);
    }
    static void show(Activity activity, List<String> available, String selected, Consumer<String> onSelect){
        Dialog dialog=new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout shell=new LinearLayout(activity);
        shell.setOrientation(LinearLayout.VERTICAL);shell.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        shell.setPadding(UiKit.dp(activity,17),UiKit.dp(activity,18),UiKit.dp(activity,17),UiKit.dp(activity,24));
        GradientDrawable bg=UiKit.rounded(activity,0xFF102238,24);
        bg.setStroke(UiKit.dp(activity,1),0xFF34506B);
        shell.setBackground(bg);
        LinearLayout bar=new LinearLayout(activity);bar.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=UiKit.title(activity,"انتخاب دارایی");title.setTextSize(20f);
        bar.addView(title,new LinearLayout.LayoutParams(0,-2,1f));
        TextView close=UiKit.title(activity,"×");close.setGravity(Gravity.CENTER);
        close.setTextSize(27f);close.setContentDescription("بستن انتخاب دارایی");
        close.setMinWidth(UiKit.dp(activity,48));close.setMinHeight(UiKit.dp(activity,48));
        close.setOnClickListener(v->dialog.dismiss());
        bar.addView(close,new LinearLayout.LayoutParams(UiKit.dp(activity,48),UiKit.dp(activity,48)));
        shell.addView(bar,UiKit.matchWrap(activity,0,9));
        EditText search=UiKit.styleField(activity,new EditText(activity),"جست‌وجوی نام دارایی...");
        search.setSingleLine(true);search.setTextDirection(View.TEXT_DIRECTION_RTL);
        shell.addView(search,new LinearLayout.LayoutParams(-1,UiKit.dp(activity,51)));
        ScrollView scroll=new ScrollView(activity);
        scroll.setFillViewport(false);
        LinearLayout results=new LinearLayout(activity);
        results.setOrientation(LinearLayout.VERTICAL);results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(results);
        shell.addView(scroll,new LinearLayout.LayoutParams(-1,0,1f));
        Runnable render=()->{
            results.removeAllViews();
            String q=normalize(search.getText().toString());
            String[] cats={"فلزات گران‌بها","ارزها","سکه‌ها","صندوق‌ها و سهام","سایر"};
            int found=0;
            for(String cat:cats){
                List<String> filtered=new ArrayList<>();
                for(String item:available)if(cat.equals(category(item))&&normalize(item).contains(q))filtered.add(item);
                if(filtered.isEmpty())continue;
                TextView label=UiKit.fieldLabel(activity,cat);label.setTextColor(UiKit.GOLD);
                label.setTextSize(13.5f);results.addView(label,UiKit.matchWrap(activity,15,8));
                for(String item:filtered){
                    found++;
                    final boolean active=item.equals(selected);
                    LinearLayout row=UiKit.cardLayout(activity);
                    row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);row.setOrientation(LinearLayout.HORIZONTAL);
                    row.setGravity(Gravity.CENTER_VERTICAL);
                    row.setBackground(UiKit.rounded(activity,active?0xFF25435C:0xFF162D48,14));
                    row.addView(new NexaOutlineIcon(activity,AssetVisualPolicy.iconFor(item),UiKit.GOLD),
                        new LinearLayout.LayoutParams(UiKit.dp(activity,28),UiKit.dp(activity,28)));
                    LinearLayout words=new LinearLayout(activity);words.setOrientation(LinearLayout.VERTICAL);
                    TextView name=UiKit.sectionTitle(activity,item);name.setTextSize(14f);words.addView(name);
                    TextView detail=UiKit.muted(activity,"واحد مقدار: "+unit(item));detail.setTextSize(11f);words.addView(detail);
                    LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(0,-2,1f);wp.rightMargin=UiKit.dp(activity,11);
                    row.addView(words,wp);
                    if(active){TextView checked=UiKit.title(activity,"✓");checked.setTextColor(UiKit.GOLD);
                        row.addView(checked,new LinearLayout.LayoutParams(UiKit.dp(activity,22),-2));}
                    row.setMinimumHeight(UiKit.dp(activity,61));
                    row.setClickable(true);row.setFocusable(true);
                    row.setContentDescription("انتخاب "+item+(active?"، انتخاب‌شده":""));
                    UiKit.touchFeedback(activity,row,UiKit.GOLD,14);
                    row.setOnClickListener(v->{dialog.dismiss();onSelect.accept(item);});
                    results.addView(row,UiKit.matchWrap(activity,0,6));
                }
            }
            if(found==0){TextView empty=UiKit.muted(activity,"دارایی مطابق جست‌وجو پیدا نشد.");
                results.addView(empty,UiKit.matchWrap(activity,22,8));}
        };
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){render.run();}
            public void afterTextChanged(Editable s){}
        });
        render.run();
        dialog.setContentView(shell);dialog.show();
        Window window=dialog.getWindow();
        if(window!=null){
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setGravity(Gravity.BOTTOM);
            window.setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                Math.round(activity.getResources().getDisplayMetrics().heightPixels*0.80f));
            window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        }
    }
}
