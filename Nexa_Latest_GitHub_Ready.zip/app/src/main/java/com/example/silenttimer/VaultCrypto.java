package com.example.silenttimer;

import android.util.Base64;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public final class VaultCrypto {
    private static final String STORE = "AndroidKeyStore";
    private static final String ALIAS = "nexa_vault_aes_v1";
    private VaultCrypto() {}

    private static SecretKey key() throws Exception {
        KeyStore ks = KeyStore.getInstance(STORE);
        ks.load(null);

        if (ks.containsAlias(ALIAS)) {
            return (SecretKey) ks.getKey(ALIAS, null);
        }

        KeyGenerator kg = KeyGenerator.getInstance("AES", STORE);
        android.security.keystore.KeyGenParameterSpec spec =
                new android.security.keystore.KeyGenParameterSpec.Builder(
                        ALIAS,
                        android.security.keystore.KeyProperties.PURPOSE_ENCRYPT |
                                android.security.keystore.KeyProperties.PURPOSE_DECRYPT
                )
                        .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setRandomizedEncryptionRequired(true)
                        .build();

        kg.init(spec);
        return kg.generateKey();
    }

    public static String encrypt(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, key());

            byte[] iv = cipher.getIV();
            byte[] out = cipher.doFinal(raw.getBytes(StandardCharsets.UTF_8));

            ByteBuffer bb = ByteBuffer.allocate(4 + iv.length + out.length);
            bb.putInt(iv.length);
            bb.put(iv);
            bb.put(out);

            return Base64.encodeToString(bb.array(), Base64.NO_WRAP);
        } catch (Exception e) {
            return "";
        }
    }

    public static String decrypt(String packed) {
        if (packed == null || packed.isEmpty()) return "";
        try {
            byte[] all = Base64.decode(packed, Base64.NO_WRAP);
            ByteBuffer bb = ByteBuffer.wrap(all);

            int ivLen = bb.getInt();
            if (ivLen < 12 || ivLen > 32) return "";

            byte[] iv = new byte[ivLen];
            bb.get(iv);

            byte[] encrypted = new byte[bb.remaining()];
            bb.get(encrypted);

            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, key(), new GCMParameterSpec(128, iv));

            return new String(cipher.doFinal(encrypted), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "";
        }
    }
}
