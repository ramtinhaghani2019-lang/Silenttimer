package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import java.util.Calendar;

/** Yearly rearm occurs on the main day, even if the user never opens Nexa. */
public class OccasionAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent intent){
        if(intent==null)return;
        String id=intent.getStringExtra("id");int lead=intent.getIntExtra("lead",-1);
        long eventAt=intent.getLongExtra("eventAt",0);
        OccasionStore.Occasion e=OccasionStore.find(c,id);
        if(e==null||!e.active||eventAt<=0||!OccasionScheduler.selected(e,lead))return;
        // Reject stale alarms after edits, calendar changes or delayed delivery.
        Calendar cal=Calendar.getInstance();cal.setTimeInMillis(eventAt);
        int year="gregorian".equals(e.calendar)?cal.get(Calendar.YEAR):PersianDateUtil.fromMillis(eventAt)[0];
        if(year<e.year || eventAt!=AnnualOccasionDates.yearDate(e.calendar,year,e.month,e.day,e.hour,e.minute))return;
        long trigger=AnnualOccasionDates.beforeDays(eventAt,lead),now=System.currentTimeMillis();
        if(now<trigger-120000L)return;
        if(now>trigger+18L*60L*60L*1000L){
            if(lead==0)OccasionScheduler.scheduleAfter(c,e,eventAt+1000L);
            return;
        }
        String token=OccasionScheduler.token(e.id,lead)+":"+eventAt;
        if(!NexaNotificationEngine.acquireDelivery(c,token))return;
        // Rearm next year's date first; persistent scheduling survives ignoring the notification.
        if(lead==0)OccasionScheduler.scheduleAfter(c,e,eventAt+1000L);
        ReminderScheduler.createChannels(c);
        int notificationId=token.hashCode();
        Intent open=new Intent(c,AnnualOccasionsActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent openPi=PendingIntent.getActivity(c,notificationId,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent dismiss=new Intent(c,OccasionDismissReceiver.class);dismiss.setAction(token);dismiss.putExtra("token",token);
        dismiss.putExtra("notificationId",notificationId);dismiss.putExtra("owner",OccasionScheduler.token(e.id,lead));
        PendingIntent dismissPi=PendingIntent.getBroadcast(c,notificationId,dismiss,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String heading=e.icon()+" "+e.typeLabel()+": "+e.title;
        String body=lead==0?"امروز • یادآوری سالانه":lead+" روز تا این مناسبت • "+PersianDateUtil.pretty(eventAt);
        Notification notification=new Notification.Builder(c,ReminderScheduler.CHANNEL)
            .setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(heading)
            .setContentText(body).setContentIntent(openPi).setDeleteIntent(dismissPi)
            .setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER)
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel,"خاموش کردن",dismissPi).build())
            .build();
        NotificationManager mgr=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(mgr!=null)try{mgr.notify(notificationId,notification);}catch(SecurityException ignored){}
        if(lead==0)AlarmSoundPlayer.start(c,OccasionScheduler.token(e.id,lead),NexaAudioController.PRIORITY_REMINDER,NexaAudioController.SOUND_REMINDER,null);
    }
}
