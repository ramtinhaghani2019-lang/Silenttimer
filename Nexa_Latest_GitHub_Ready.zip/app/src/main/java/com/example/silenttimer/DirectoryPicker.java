package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import java.util.function.Consumer;

/** Select or create a directory entry without navigating away from the current editor. */
public final class DirectoryPicker {
    private DirectoryPicker(){}
    public static void seller(Activity a,Consumer<NexaStore.ShoppingSeller> picked){
        LinearLayout rows=UiKit.dialogPanel(a);
        Button add=UiKit.primaryButton(a,"＋ افزودن شخص / دریافت‌کننده جدید");
        rows.addView(add,UiKit.matchWrap(a,0,9));
        java.util.List<NexaStore.ShoppingSeller> all=NexaStore.sellers(a);
        if(all.isEmpty())rows.addView(UiKit.muted(a,"هنوز شخصی ثبت نشده است."));
        AlertDialog dialog=new AlertDialog.Builder(a).setTitle("انتخاب از دفتر مشترک")
            .setView(wrap(a,rows)).setNegativeButton("بستن",null).create();
        add.setOnClickListener(v->sellerEditor(a,null,s->{dialog.dismiss();picked.accept(s);}));
        for(NexaStore.ShoppingSeller s:all){
            Button b=UiKit.secondaryButton(a,s.name+(s.category.isEmpty()?"":" • "+s.category));
            b.setOnClickListener(v->{dialog.dismiss();picked.accept(s);});
            rows.addView(b,UiKit.matchWrap(a,0,5));
        }
        dialog.show();
    }
    public static void sellerEditor(Activity a,NexaStore.ShoppingSeller existing,Consumer<NexaStore.ShoppingSeller> saved){
        LinearLayout box=UiKit.dialogPanel(a);
        EditText name=UiKit.styleField(a,new EditText(a),"نام شخص یا فروشنده");
        EditText category=UiKit.styleField(a,new EditText(a),"دسته‌بندی؛ مثلاً شخص، فروشگاه");
        if(existing!=null){name.setText(existing.name);category.setText(existing.category);}
        box.addView(name,UiKit.matchWrap(a,0,6));box.addView(category,UiKit.matchWrap(a,0,6));
        AlertDialog dialog=new AlertDialog.Builder(a).setTitle("افزودن به دفتر مشترک")
            .setView(box).setPositiveButton("ثبت",null).setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty()){
                name.setError("نام را وارد کن");return;
            }
            NexaStore.ShoppingSeller s=existing==null?new NexaStore.ShoppingSeller():existing;
            s.name=name.getText().toString().trim();
            s.category=category.getText().toString().trim().isEmpty()?"عمومی":category.getText().toString().trim();
            NexaStore.upsertSeller(a,s);dialog.dismiss();saved.accept(s);
        }));
        dialog.show();
    }
    public static void card(Activity a,Consumer<NexaStore.BankCard> picked){
        LinearLayout rows=UiKit.dialogPanel(a);
        Button add=UiKit.primaryButton(a,"＋ افزودن کارت مقصد جدید");
        rows.addView(add,UiKit.matchWrap(a,0,8));
        java.util.List<NexaStore.BankCard> cards=NexaStore.bankCards(a);
        if(cards.isEmpty())rows.addView(UiKit.muted(a,"کارت مقصدی ثبت نشده است."));
        AlertDialog dialog=new AlertDialog.Builder(a).setTitle("انتخاب کارت مقصد")
            .setView(wrap(a,rows)).setNegativeButton("بستن",null).create();
        add.setOnClickListener(v->PaymentCardEditor.show(a,null,c->{dialog.dismiss();picked.accept(c);}));
        for(NexaStore.BankCard c:cards){
            LinearLayout row=new LinearLayout(a);row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            Button pick=UiKit.secondaryButton(a,c.display());
            row.addView(pick,new LinearLayout.LayoutParams(0,-2,1f));
            pick.setOnClickListener(v->{dialog.dismiss();picked.accept(c);});
            Button copy=UiKit.iconButton(a,"⧉","کپی شماره کارت",UiKit.GOLD);
            copy.setOnClickListener(v->Toast.makeText(a,
                PaymentCardSecrets.copy(a,c.id)?"شماره کارت کپی شد":"شماره کامل این کارت ثبت نشده",Toast.LENGTH_SHORT).show());
            row.addView(copy,new LinearLayout.LayoutParams(UiKit.dp(a,45),UiKit.dp(a,45)));
            rows.addView(row,UiKit.matchWrap(a,0,5));
        }
        dialog.show();
    }
    private static ScrollView wrap(Activity a,LinearLayout content){
        ScrollView sc=new ScrollView(a);sc.setFillViewport(false);sc.addView(content);
        return sc;
    }
}
