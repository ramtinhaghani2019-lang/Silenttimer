package com.example.silenttimer;

/** Shared semantic icon selection for asset groups and market rate tiles. */
final class AssetVisualPolicy {
    private AssetVisualPolicy(){}
    static String iconFor(String label){
        if(label==null)return "assets";
        String s=label.trim();
        if(s.contains("یورو"))return "eur";
        if(s.contains("دلار"))return "usd";
        if(s.contains("اونس"))return "ounce";
        if(s.contains("سکه"))return "coin";
        if(s.contains("طلا")||s.contains("شمش"))return "gold";
        return "assets";
    }
}
