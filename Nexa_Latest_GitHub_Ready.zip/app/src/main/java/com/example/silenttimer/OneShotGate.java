package com.example.silenttimer;

import java.util.concurrent.atomic.AtomicBoolean;

/** Exactly-once guard for asynchronous broadcast completion and timeout races. */
public final class OneShotGate {
    private final AtomicBoolean completed = new AtomicBoolean(false);
    public boolean claim() { return completed.compareAndSet(false, true); }
    public boolean isCompleted() { return completed.get(); }
}
