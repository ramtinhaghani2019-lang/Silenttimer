package com.example.silenttimer;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

/**
 * Read-only iCalendar export. Floating local dates intentionally preserve wall-clock
 * times for daily/weekly/monthly recurrences when daylight-saving time changes.
 * The target calendar owns its events after the file is imported; Nexa never edits them.
 */
public final class ReminderCalendarExporter {
    private ReminderCalendarExporter() {}

    /** Past, paused and completed items are never silently exported as upcoming events. */
    public static boolean eligible(NexaStore.Reminder reminder, long now) {
        return reminder != null && reminder.id != null && !reminder.id.isEmpty()
                && reminder.active && !reminder.done && reminder.whenMillis > now;
    }

    /** Selection is ID-based to avoid exporting a stale Activity object. */
    public static List<NexaStore.Reminder> pick(List<NexaStore.Reminder> source,
                                                Set<String> ids, long now) {
        List<NexaStore.Reminder> found = new ArrayList<>();
        if (source == null || ids == null || ids.isEmpty()) return found;
        Set<String> already = new HashSet<>();
        for (NexaStore.Reminder r : source) {
            if (eligible(r, now) && ids.contains(r.id) && already.add(r.id)) found.add(r);
        }
        return found;
    }

    /** True for non-numeric clock-specific rules not representable by a simple VALARM. */
    public static boolean hasUnportableAlerts(NexaStore.Reminder r) {
        if (r == null) return false;
        for (String rule : AlertRules.split(r.offsetsMinutes)) {
            if (!rule.matches("[0-9]+")) return true;
            try { if (Long.parseLong(rule) > 52560000L) return true; }
            catch (NumberFormatException e) { return true; }
        }
        return false;
    }

    /** RFC 5545 text escaping. Escapes happen before UTF-8 line folding. */
    static String escapeText(String text) {
        if (text == null) return "";
        return text.replace("\\", "\\\\").replace("\r\n", "\n").replace('\r', '\n')
                .replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;");
    }

    /** Fold content lines at most 75 octets; never split a UTF-8 code point. */
    static void line(StringBuilder out, String value) {
        int bytes = 0;
        for (int i = 0; i < value.length();) {
            int cp = value.codePointAt(i);
            int count = new String(Character.toChars(cp)).getBytes(StandardCharsets.UTF_8).length;
            if (bytes + count > 75) {
                out.append("\r\n ");
                bytes = 1; // one ASCII fold whitespace octet
            }
            out.appendCodePoint(cp);
            bytes += count;
            i += Character.charCount(cp);
        }
        out.append("\r\n");
    }

    private static String localTime(long millis) {
        // Floating local time: calendars preserve the reminder's wall-clock hour.
        return new SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US).format(new Date(millis));
    }

    private static String utcTime(long millis) {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        return format.format(new Date(millis));
    }

    private static String recurrenceRule(String kind) {
        if ("daily".equals(kind)) return "FREQ=DAILY";
        if ("weekly".equals(kind)) return "FREQ=WEEKLY";
        if ("biweekly".equals(kind)) return "FREQ=WEEKLY;INTERVAL=2";
        if ("monthly".equals(kind)) return "FREQ=MONTHLY";
        return "";
    }

    /** Creates a portable .ics document. Note/category inclusion is explicit opt-in. */
    public static String create(List<NexaStore.Reminder> reminders, boolean includeDetails,
                                long now) {
        StringBuilder out = new StringBuilder(1024);
        line(out, "BEGIN:VCALENDAR");
        line(out, "VERSION:2.0");
        line(out, "PRODID:-//Nexa//Nexa Reminder Export//FA");
        line(out, "CALSCALE:GREGORIAN");
        if (reminders != null) {
            Set<String> already = new HashSet<>();
            for (NexaStore.Reminder reminder : reminders) {
                if (!eligible(reminder, now) || !already.add(reminder.id)) continue;
                // Stable anonymous UID lets importers recognise repeated exports.
                String uid = UUID.nameUUIDFromBytes(reminder.id.getBytes(StandardCharsets.UTF_8))
                        + "@nexa.local";
                line(out, "BEGIN:VEVENT");
                line(out, "UID:" + uid);
                line(out, "DTSTAMP:" + utcTime(now));
                line(out, "DTSTART:" + localTime(reminder.whenMillis));
                line(out, "DURATION:PT10M");
                line(out, "SUMMARY:" + escapeText(reminder.title == null
                        || reminder.title.trim().isEmpty() ? "یادآور Nexa" : reminder.title));
                if (includeDetails) {
                    String category = reminder.category == null ? "" : reminder.category.trim();
                    String note = reminder.note == null ? "" : reminder.note.trim();
                    String details = category.isEmpty() ? note
                            : note.isEmpty() ? category : category + "\n" + note;
                    if (!details.isEmpty()) line(out, "DESCRIPTION:" + escapeText(details));
                }
                String rule = recurrenceRule(reminder.recurrence);
                if (!rule.isEmpty()) line(out, "RRULE:" + rule);
                Set<Long> alarmOffsets = new HashSet<>();
                for (String offset : AlertRules.split(reminder.offsetsMinutes)) {
                    if (!offset.matches("[0-9]+")) continue;
                    try {
                        long minutes = Long.parseLong(offset);
                        if (minutes > 52560000L || !alarmOffsets.add(minutes)) continue;
                        line(out, "BEGIN:VALARM");
                        line(out, "ACTION:DISPLAY");
                        line(out, "DESCRIPTION:یادآور Nexa");
                        line(out, "TRIGGER:" + (minutes == 0 ? "PT0M" : "-PT" + minutes + "M"));
                        line(out, "END:VALARM");
                    } catch (NumberFormatException ignored) {
                        // Invalid/special Nexa rule has no 1:1 RFC 5545 representation.
                    }
                }
                line(out, "END:VEVENT");
            }
        }
        line(out, "END:VCALENDAR");
        return out.toString();
    }
}
