package com.example.silenttimer;

/** Display-only grouping. History records are never changed or removed. */
public final class TimelineHistoryGroupPolicy {
    private TimelineHistoryGroupPolicy(){}

    public static String medicineName(String type, String detail){
        if(type==null || !normalize(type).contains("دارو"))return null;
        if(detail==null)return null;
        String text=detail.trim().replace('ي','ی').replace('ك','ک');
        String[] leading={"هشدار:","هشدار :","دارو اضافه شد:","دارو ویرایش شد:",
                "دارو اضافه شد :","دارو ویرایش شد :"};
        for(String p:leading)if(text.startsWith(p)){
            text=text.substring(p.length()).trim();break;
        }
        int separator=text.indexOf('•');
        if(separator>=0)text=text.substring(0,separator);
        text=text.replace('\u200c',' ').replaceAll("\\s+"," ").trim();
        return text.isEmpty()?null:text;
    }

    public static String keyFor(String kind,String type,String detail){
        if(!"history".equals(kind))return null;
        String name=medicineName(type,detail);
        return name==null?null:"medicine:"+normalize(name);
    }

    public static String actionFor(String detail){
        if(detail==null)return "ثبت سابقه";
        String s=detail.trim();
        if(s.startsWith("هشدار:" ) || s.startsWith("هشدار :"))return "هشدار دارو";
        int bullet=s.indexOf('•');
        if(bullet>=0 && bullet+1<s.length())return s.substring(bullet+1).trim();
        if(s.startsWith("دارو اضافه شد"))return "ثبت دارو";
        if(s.startsWith("دارو ویرایش شد"))return "ویرایش دارو";
        return "ثبت سابقه";
    }

    private static String normalize(String s){
        return s.trim().replace('ي','ی').replace('ك','ک').replace('\u200c',' ')
                .replaceAll("\\s+"," ").toLowerCase(java.util.Locale.ROOT);
    }
}
