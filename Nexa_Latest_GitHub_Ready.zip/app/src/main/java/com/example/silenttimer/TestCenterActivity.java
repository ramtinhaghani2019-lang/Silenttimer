package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class TestCenterActivity extends Activity {
    private LinearLayout checks;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    @Override
    protected void onResume() {
        super.onResume();
        renderChecks();
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"مرکز تست Nexa"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.featureHero(this,"test","مرکز تست","بررسی سلامت قابلیت‌ها و Regression"),UiKit.matchWrap(this,0,14));
        root.addView(UiKit.muted(this,"مرکز تست برای اینکه قابلیت‌ها را مرحله‌به‌مرحله بررسی کنیم."),UiKit.matchWrap(this,0,14));

        LinearLayout card=UiKit.colorfulCardLayout(this,1);
        card.addView(UiKit.sectionTitle(this,"وضعیت سیستم"));
        checks=new LinearLayout(this);
        checks.setOrientation(LinearLayout.VERTICAL);
        card.addView(checks,UiKit.matchWrap(this,8,0));
        root.addView(card,UiKit.matchWrap(this,0,12));

        Button notification=UiKit.primaryButton(this,"تست اعلان همین الان");
        notification.setOnClickListener(v->testNotification());
        root.addView(notification,UiKit.matchWrap(this,0,8));

        Button reminder=UiKit.secondaryButton(this,"ساخت یادآور آزمایشی ۱ دقیقه‌ای");
        reminder.setOnClickListener(v->testReminder());
        root.addView(reminder,UiKit.matchWrap(this,0,8));

        Button overlay=UiKit.secondaryButton(this,"تست Overlay با بازکردن Smart Silent");
        overlay.setOnClickListener(v->startActivity(new Intent(this,SmartSilentActivity.class)));
        root.addView(overlay,UiKit.matchWrap(this,0,8));

        Button settings=UiKit.secondaryButton(this,"رفتن به راه‌اندازی دسترسی‌ها");
        settings.setOnClickListener(v->{
            Intent i=new Intent(this,SettingsActivity.class);
            i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
            startActivity(i);
        });
        root.addView(settings);

        setContentView(sc);
        renderChecks();
    }

    private void renderChecks() {
        if(checks==null)return;
        checks.removeAllViews();

        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);

        addCheck("نمایش روی برنامه‌ها", Settings.canDrawOverlays(this));
        addCheck("کنترل Silent / DND",nm.isNotificationPolicyAccessGranted());
        addCheck("وضعیت تماس",checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==PackageManager.PERMISSION_GRANTED);
        addCheck("مخاطبین",checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED);
        addCheck("پیامک اضطراری",checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED);

        boolean notif=Build.VERSION.SDK_INT<33 ||
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED;
        addCheck("اعلان‌ها",notif);

        boolean screening=true;
        if(Build.VERSION.SDK_INT>=29){
            RoleManager rm=getSystemService(RoleManager.class);
            screening=rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)&&rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);
        }
        addCheck("Call Screening",screening);
        addCheck("باتری بدون محدودیت",pm.isIgnoringBatteryOptimizations(getPackageName()));

        AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);
        boolean exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms();
        addCheck("Exact Alarm",exact);
        boolean full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent();
        addCheck("هشدار تمام‌صفحه روی Lock Screen",full);

        addCheck("راه‌اندازی اولیه کامل",AppPrefs.isSetupCompleted(this));
    }

    private void addCheck(String label,boolean ok){
        TextView t=UiKit.muted(this,(ok?"✓  ":"○  ")+label);
        t.setTextColor(ok?UiKit.TEAL:UiKit.GOLD);
        t.setTextSize(14);
        checks.addView(t,UiKit.matchWrap(this,4,4));
    }

    private void testNotification(){
        String ch="nexa_test";
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);

        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel nc=new NotificationChannel(ch,"Nexa Test",NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(nc);
        }

        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,ch):new Notification.Builder(this);
        Notification n=b
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("Nexa Test ✓")
                .setContentText("اگر این اعلان را می‌بینی، تست اعلان موفق است.")
                .setAutoCancel(true)
                .build();
        nm.notify(9750,n);
    }

    private void testReminder(){
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.title="تست یک دقیقه‌ای Nexa";
        r.category="تست";
        r.icon="🧪";
        r.note="این یک یادآور آزمایشی است.";
        r.whenMillis=System.currentTimeMillis()+60_000L;
        r.offsetsMinutes="0";
        r.repeatMinutes=5;
        r.sourceKey="test:"+System.currentTimeMillis();
        NexaStore.addReminder(this,r);
        ReminderScheduler.scheduleReminder(this,r);
        Toast.makeText(this,"یادآور تست برای یک دقیقه بعد ساخته شد.",Toast.LENGTH_LONG).show();
    }
}
