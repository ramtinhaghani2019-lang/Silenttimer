package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Presentation-only surfaces shared by document and household maintenance pages. */
final class NexaCareUi {
    private NexaCareUi() {}

    static LinearLayout metrics(Context c,String[] names,int[] values,int[] colors){
        if(names.length!=values.length||values.length!=colors.length||names.length==0)
            throw new IllegalArgumentException("Status metric lengths must match");
        LinearLayout strip=new LinearLayout(c);
        boolean stacked=HomeUi.shouldStack(c);
        strip.setOrientation(stacked?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        strip.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<names.length;i++){
            LinearLayout card=UiKit.cardLayout(c);
            card.setPadding(UiKit.dp(c,11),UiKit.dp(c,11),UiKit.dp(c,11),UiKit.dp(c,10));
            card.setBackground(UiKit.colorfulCard(c,colors[i]==UiKit.RED?4:colors[i]==UiKit.GOLD?0:3));
            card.setMinimumHeight(UiKit.dp(c,78));
            TextView count=UiKit.sectionTitle(c,String.valueOf(values[i]));
            count.setTextSize(22f); count.setTextColor(colors[i]);
            count.setGravity(Gravity.RIGHT);card.addView(count);
            TextView name=UiKit.muted(c,names[i]);name.setTextSize(11.5f);
            card.addView(name,UiKit.matchWrap(c,3,0));
            card.setContentDescription(names[i]+"، "+values[i]+" مورد");
            LinearLayout.LayoutParams lp=stacked?new LinearLayout.LayoutParams(-1,-2):new LinearLayout.LayoutParams(0,-2,1f);
            if(i>0){if(stacked)lp.topMargin=UiKit.dp(c,7);else lp.leftMargin=UiKit.dp(c,7);}
            strip.addView(card,lp);
        }
        return strip;
    }

    static TextView filter(Context c,String title,boolean selected){
        TextView chip=UiKit.chip(c,title,selected);
        chip.setTextSize(12f);chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(UiKit.dp(c,44));
        chip.setContentDescription("فیلتر "+title+(selected?"، انتخاب‌شده":""));
        UiKit.touchFeedback(c,chip,UiKit.PURPLE,18);
        return chip;
    }

    static LinearLayout record(Context c,boolean overdue,boolean soon){
        LinearLayout item=UiKit.cardLayout(c);
        item.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        item.setPadding(UiKit.dp(c,14),UiKit.dp(c,12),UiKit.dp(c,14),UiKit.dp(c,12));
        item.setBackground(overdue?UiKit.subtlePastCard(c):UiKit.colorfulCard(c,soon?0:5));
        item.setMinimumHeight(UiKit.dp(c,90));
        return item;
    }

    static TextView state(Context c,String label,int tone){
        TextView state=UiKit.statusBadge(c,label,tone);
        state.setTextColor(tone);state.setTextSize(11.5f);
        state.setGravity(Gravity.CENTER);
        state.setMinHeight(UiKit.dp(c,32));
        return state;
    }

    static TextView formHeading(Context c,String title){
        TextView label=UiKit.sectionTitle(c,title);
        label.setTextSize(15f);
        label.setPadding(0,UiKit.dp(c,12),0,UiKit.dp(c,6));
        return label;
    }
}
