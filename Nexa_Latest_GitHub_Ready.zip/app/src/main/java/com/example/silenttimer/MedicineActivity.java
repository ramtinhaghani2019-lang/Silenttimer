package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MedicineActivity extends Activity {
    private LinearLayout list;
    private LinearLayout metricsHost;
    private LinearLayout filtersHost;
    private int medicineFilter=0; // UI-only: all, active, overdue, completed

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        if(b!=null)medicineFilter=b.getInt("medicine_display_filter",0);
        UiKit.applyWindow(this);build();
        // Voice instructions only populate the medicine name. Nothing is saved
        // until the user reviews the treatment form and explicitly confirms.
        if(b==null && getIntent()!=null && getIntent().getBooleanExtra("quick_add",false)){
            String name=getIntent().getStringExtra("voice_title");
            if(name!=null && !name.trim().isEmpty())medicineDialog(null,name.trim());
        }
    }
    @Override protected void onResume(){super.onResume();render();}
    @Override protected void onSaveInstanceState(Bundle out){
        out.putInt("medicine_display_filter",medicineFilter);
        super.onSaveInstanceState(out);
    }

    private EditText f(String h){return UiKit.styleField(this,new EditText(this),h);}

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackground(UiKit.screenBackground(this));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,14),UiKit.dp(this,10),UiKit.dp(this,14),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.header(this,"دارو و سلامت",v->finish()),UiKit.matchWrap(this,0,10));
        // Single compact action surface instead of two stacked hero banners.
        LinearLayout hero=HomeUi.panel(this,true);
        hero.addView(HomeUi.heading(this,"برنامه مصرف داروها"));
        hero.addView(HomeUi.secondary(this,"نوبت‌های مصرف و سابقه واقعی داروهای ثبت‌شده"),UiKit.matchWrap(this,4,10));
        LinearLayout heroActions=new LinearLayout(this);
        boolean stacked=HomeUi.compactGridNeedsStack(this);
        heroActions.setOrientation(stacked?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        heroActions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        heroActions.setGravity(Gravity.CENTER_VERTICAL);
        Button add=UiKit.primaryButton(this,"＋ داروی جدید");
        add.setOnClickListener(v->medicineDialog(null));
        LinearLayout.LayoutParams ap=stacked?UiKit.matchWrap(this,0,5):new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f);
        heroActions.addView(add,ap);
        Button report=UiKit.secondaryButton(this,"گزارش مصرف");
        report.setContentDescription("مشاهده گزارش مصرف داروها");
        report.setOnClickListener(v->showMedicineReport());
        LinearLayout.LayoutParams rp=stacked?UiKit.matchWrap(this):new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f);
        if(!stacked)rp.setMargins(UiKit.dp(this,8),0,0,0);
        heroActions.addView(report,rp);
        hero.addView(heroActions);root.addView(hero,UiKit.matchWrap(this,0,11));
        metricsHost=new LinearLayout(this);metricsHost.setOrientation(LinearLayout.VERTICAL);
        root.addView(metricsHost,UiKit.matchWrap(this,0,10));
        root.addView(NexaMedicineUi.formHeading(this,"فهرست داروها"),UiKit.matchWrap(this,0,5));
        filtersHost=new LinearLayout(this);filtersHost.setOrientation(LinearLayout.VERTICAL);
        root.addView(filtersHost,UiKit.matchWrap(this,0,10));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        setContentView(sc);render();
    }

    private void medicineDialog(NexaStore.Medicine existing){medicineDialog(existing,null);}
    private void medicineDialog(NexaStore.Medicine existing,String suggestedName){
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,existing==null?"💊 داروی جدید":"✎ ویرایش دارو"),UiKit.matchWrap(this,0,8));
        EditText name=f("نام دارو");EditText dose=f("مقدار / توضیح؛ مثلاً ۱ عدد بعد غذا");
        if(existing==null && suggestedName!=null)name.setText(suggestedName);

        ArrayList<String> doctorNames=new ArrayList<>();for(NexaStore.Doctor d:NexaStore.doctors(this))doctorNames.add(d.name);
        AutoCompleteTextView doctor=new AutoCompleteTextView(this);UiKit.styleField(this,doctor,"نام پزشک؛ انتخاب یا تایپ دستی");doctor.setThreshold(1);doctor.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,doctorNames));
        Button doctorList=UiKit.secondaryButton(this,"پزشکان ذخیره‌شده");doctorList.setOnClickListener(v->showDoctorDirectory(d->{doctor.setText(d.name);doctor.dismissDropDown();}));

        final long[] prescriptionDate={existing==null?0:existing.prescriptionDate};Button prescription=UiKit.secondaryButton(this,prescriptionDate[0]>0?"📅 "+PersianDateUtil.pretty(prescriptionDate[0]):"📅 تاریخ نسخه (اختیاری)");prescription.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,prescriptionDate[0]>0?prescriptionDate[0]:System.currentTimeMillis(),"تاریخ نسخه",millis->{prescriptionDate[0]=millis;prescription.setText("📅 "+PersianDateUtil.pretty(millis));}));

        Spinner interval=UiKit.styledSpinner(this);ArrayAdapter<String> ia=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,new String[]{"هر ۴ ساعت","هر ۶ ساعت","هر ۸ ساعت","هر ۱۲ ساعت","هر ۲۴ ساعت"}){@Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);return t;}@Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);return t;}};interval.setAdapter(ia);interval.setSelection(2);
        EditText days=f("تعداد روز دوره؛ ۰ یعنی بدون پایان");days.setInputType(InputType.TYPE_CLASS_NUMBER);

        final long[] firstDoseMillis={existing!=null&&existing.firstDoseMillis>0?existing.firstDoseMillis:System.currentTimeMillis()};
        Button firstDose=UiKit.secondaryButton(this,"🕒 اولین دوز خورده‌شده: "+PersianDateUtil.pretty(firstDoseMillis[0]));
        firstDose.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,firstDoseMillis[0],"تاریخ و ساعت اولین دوز",millis->{firstDoseMillis[0]=millis;firstDose.setText("🕒 اولین دوز خورده‌شده: "+PersianDateUtil.pretty(millis));}));

        if(existing!=null){name.setText(existing.name);dose.setText(existing.dose);doctor.setText(existing.doctor);int[]opts={4,6,8,12,24};for(int j=0;j<opts.length;j++)if(opts[j]==existing.intervalHours)interval.setSelection(j);if(existing.endMillis>0&&existing.firstDoseMillis>0)days.setText(String.valueOf(Math.max(1,(existing.endMillis-existing.firstDoseMillis)/(24L*60*60*1000))));}

        if(existing==null && suggestedName!=null)
            box.addView(UiKit.muted(this,"نام از گفتار آمده؛ برنامه و مقدار مصرف را حتماً با نسخه خود تطبیق بده."),UiKit.matchWrap(this,0,7));
        // Show the four daily essentials first; optional prescription metadata never blocks saving.
        box.addView(UiKit.formField(this,"نام دارو",name),UiKit.matchWrap(this,0,5));
        box.addView(UiKit.formField(this,"مقدار و شیوه مصرف",dose),UiKit.matchWrap(this,0,6));
        box.addView(UiKit.formField(this,"فاصله نوبت‌ها",interval),UiKit.matchWrap(this,0,6));
        box.addView(UiKit.formField(this,"مدت دوره (روز)",days),UiKit.matchWrap(this,0,6));
        box.addView(UiKit.formField(this,"زمان مبنای مصرف",firstDose),UiKit.matchWrap(this,0,6));
        box.addView(UiKit.muted(this,"زمان نوبت بعد از آخرین مصرف ثبت‌شده محاسبه می‌شود."),UiKit.matchWrap(this,0,8));
        LinearLayout optional=new LinearLayout(this);optional.setOrientation(LinearLayout.VERTICAL);
        optional.addView(UiKit.formField(this,"پزشک تجویزکننده",doctor));
        optional.addView(doctorList,UiKit.matchWrap(this,4,7));
        optional.addView(UiKit.formField(this,"تاریخ نسخه",prescription),UiKit.matchWrap(this,0,0));
        boolean hasDetails=existing!=null &&
                ((existing.doctor!=null&&!existing.doctor.isEmpty())||existing.prescriptionDate>0);
        box.addView(UiKit.optionalFormFields(this,"پزشک و اطلاعات نسخه (اختیاری)",optional,hasDetails),
                UiKit.matchWrap(this,1,0));

        ScrollView formScroll=new ScrollView(this);formScroll.setFillViewport(false);formScroll.addView(box);
        AlertDialog editor=new AlertDialog.Builder(this).setView(formScroll)
            .setPositiveButton("ذخیره دارو",null).setNegativeButton("انصراف",null).create();
        editor.setOnShowListener(ignored->editor.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim();
            if(n.isEmpty()){name.setError("نام دارو الزامی است");name.requestFocus();return;}
            int[]hours={4,6,8,12,24};NexaStore.Medicine m=existing==null?new NexaStore.Medicine():existing;m.name=n;m.dose=dose.getText().toString().trim();m.doctor=doctor.getText().toString().trim();m.prescriptionDate=prescriptionDate[0];m.intervalHours=hours[interval.getSelectedItemPosition()];
            long first=firstDoseMillis[0];
            boolean baselineChanged=existing!=null && existing.firstDoseMillis!=first;
            m.firstDoseMillis=first;
            long effectiveBase=baselineChanged?first:latestEffectiveDoseBase(m.id, first);
            m.nextDoseMillis=effectiveBase+m.intervalHours*60L*60L*1000L;
            if(baselineChanged){
                // Editing the first consumed dose is an explicit schedule reset. Old dose logs must not
                // immediately override the newly selected baseline during render/reconciliation.
                NexaStore.clearMedicineDoseLogs(this,m.id);
                NexaStore.MedicineDoseLog baseLog=new NexaStore.MedicineDoseLog();
                baseLog.medicineId=m.id;baseLog.scheduledAt=first;baseLog.takenAt=first;baseLog.status="taken_on_time";
                NexaStore.addMedicineDoseLog(this,baseLog);
            }
            int dd=0;try{dd=Integer.parseInt(days.getText().toString().trim());}catch(Exception ignored){}m.endMillis=dd>0?m.firstDoseMillis+dd*24L*60*60*1000:0;m.active=m.endMillis<=0||m.nextDoseMillis<=m.endMillis;
            MedicineScheduler.cancel(this,m.id);if(existing==null){NexaStore.addMedicine(this,m);NexaStore.MedicineDoseLog log=new NexaStore.MedicineDoseLog();log.medicineId=m.id;log.scheduledAt=m.firstDoseMillis;log.takenAt=m.firstDoseMillis;log.status="taken_on_time";NexaStore.addMedicineDoseLog(this,log);}else NexaStore.updateMedicine(this,m);
            if(m.active)MedicineScheduler.schedule(this,m);NexaStore.addHistory(this,"دارو",(existing==null?"دارو اضافه شد: ":"دارو ویرایش شد: ")+m.name);TodayNotificationManager.refresh(this);render();
            editor.dismiss();
        }));
        editor.show();
    }

    private interface DoctorCallback{void saved(NexaStore.Doctor d);}
    private void showDoctorDirectory(DoctorCallback cb){
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"پزشکان ذخیره‌شده"),UiKit.matchWrap(this,0,8));List<NexaStore.Doctor> docs=NexaStore.doctors(this);
        if(docs.isEmpty())box.addView(UiKit.muted(this,"هنوز پزشکی ذخیره نشده."),UiKit.matchWrap(this,0,8));
        for(NexaStore.Doctor doc:docs){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);Button pick=UiKit.secondaryButton(this,doc.name+(doc.specialty.isEmpty()?"":" • "+doc.specialty));pick.setOnClickListener(v->cb.saved(doc));row.addView(pick,new LinearLayout.LayoutParams(0,-2,1f));box.addView(row,UiKit.matchWrap(this,0,5));}
        Button add=UiKit.addIconButton(this);add.setContentDescription("افزودن پزشک");add.setOnClickListener(v->doctorDialog(cb));box.addView(add,UiKit.matchWrap(this,8,0));
        new AlertDialog.Builder(this).setTitle("انتخاب پزشک").setView(box).setNegativeButton("بستن",null).show();
    }

    private void doctorDialog(DoctorCallback cb){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"افزودن پزشک"),UiKit.matchWrap(this,0,8));EditText n=f("نام پزشک");EditText sp=f("تخصص");EditText file=f("شماره پرونده");EditText center=f("نام مطب / مرکز");EditText phone=f("شماره تماس");phone.setInputType(InputType.TYPE_CLASS_PHONE);EditText address=f("آدرس");for(View v:new View[]{n,sp,file,center,phone,address})box.addView(v,UiKit.matchWrap(this,0,6));new AlertDialog.Builder(this).setView(box).setPositiveButton("ذخیره پزشک",(d,w)->{if(n.getText().toString().trim().isEmpty())return;NexaStore.Doctor doc=new NexaStore.Doctor();doc.name=n.getText().toString().trim();doc.specialty=sp.getText().toString().trim();doc.fileNumber=file.getText().toString().trim();doc.center=center.getText().toString().trim();doc.phone=phone.getText().toString().trim();doc.address=address.getText().toString().trim();NexaStore.upsertDoctor(this,doc);cb.saved(doc);}).setNegativeButton("انصراف",null).show();}

    private void render(){
        if(list==null)return;
        list.removeAllViews();List<NexaStore.Medicine> ms=NexaStore.medicines(this);
        long now=System.currentTimeMillis();int active=0,overdue=0,soon=0,shown=0;
        // Preserve the existing reconciliation and scheduler: only the rendering is changed.
        for(NexaStore.Medicine m:ms){
            reconcileNextDose(m);
            int state=MedicineOverviewPolicy.classify(m.active,m.nextDoseMillis,now);
            if(m.active)active++;
            if(state==MedicineOverviewPolicy.OVERDUE)overdue++;
            if(state==MedicineOverviewPolicy.SOON)soon++;
        }
        if(metricsHost!=null){metricsHost.removeAllViews();metricsHost.addView(NexaMedicineUi.metrics(this,active,overdue,soon));}
        showMedicineFilters();
        for(NexaStore.Medicine m:ms){
            int state=MedicineOverviewPolicy.classify(m.active,m.nextDoseMillis,now);
            if(medicineFilter==1&&!m.active)continue;
            if(medicineFilter==2&&state!=MedicineOverviewPolicy.OVERDUE)continue;
            if(medicineFilter==3&&m.active)continue;
            shown++;
            LinearLayout c=NexaMedicineUi.medicineCard(this,state);
            LinearLayout summary=new LinearLayout(this);summary.setOrientation(LinearLayout.VERTICAL);
            LinearLayout titleRow=new LinearLayout(this);titleRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            titleRow.setGravity(Gravity.CENTER_VERTICAL);
            TextView name=UiKit.sectionTitle(this,"💊 "+m.name);
            name.setMaxLines(2);titleRow.addView(name,new LinearLayout.LayoutParams(0,-2,1f));
            TextView arrow=UiKit.muted(this,"⌄");arrow.setTextSize(22f);
            arrow.setGravity(Gravity.CENTER);titleRow.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(this,38),UiKit.dp(this,42)));
            summary.addView(titleRow);
            summary.addView(UiKit.muted(this,(m.dose.isEmpty()?"":m.dose+" • ")+"هر "+m.intervalHours+" ساعت"),UiKit.matchWrap(this,4,7));
            LinearLayout meta=new LinearLayout(this);meta.setOrientation(LinearLayout.VERTICAL);meta.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            LinearLayout.LayoutParams stateParams=new LinearLayout.LayoutParams(-2,-2);
            stateParams.gravity=Gravity.RIGHT;stateParams.bottomMargin=UiKit.dp(this,5);
            meta.addView(NexaMedicineUi.state(this,state),stateParams);
            if(m.active&&m.nextDoseMillis>0)meta.addView(UiKit.muted(this,"نوبت بعد: "+PersianDateUtil.pretty(m.nextDoseMillis)));
            else if(!m.active)meta.addView(UiKit.muted(this,"دوره مصرف به پایان رسیده است."));
            summary.addView(meta);c.addView(summary);
            LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);details.setVisibility(View.GONE);
            if(!m.doctor.isEmpty())details.addView(UiKit.muted(this,"پزشک: "+m.doctor),UiKit.matchWrap(this,7,0));
            addTodayDoses(details,m);
            addRecentDoseHistory(details,m);
            LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);
            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->medicineDialog(m));
            Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف دارو؟").setMessage(m.name).setPositiveButton("حذف",(d,w)->{MedicineScheduler.cancel(this,m.id);NexaStore.removeMedicine(this,m.id);TodayNotificationManager.refresh(this);render();}).setNegativeButton("انصراف",null).show());
            actions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));dl.setMargins(UiKit.dp(this,8),0,0,0);actions.addView(del,dl);
            details.addView(actions,UiKit.matchWrap(this,12,0));c.addView(details);
            summary.setOnClickListener(v->{boolean open=details.getVisibility()!=View.VISIBLE;details.setVisibility(open?View.VISIBLE:View.GONE);arrow.setText(open?"⌃":"⌄");summary.setContentDescription(m.name+(open?"، بستن جزئیات":"، نمایش جزئیات"));});
            summary.setClickable(true);summary.setFocusable(true);
            summary.setContentDescription(m.name+"، نمایش جزئیات");
            UiKit.touchFeedback(this,summary,UiKit.PURPLE,18);
            list.addView(c,UiKit.matchWrap(this,0,8));
        }
        if(shown==0){
            String message=ms.isEmpty()?"هنوز دارویی ثبت نشده.":"در این فیلتر دارویی وجود ندارد.";
            list.addView(UiKit.emptyState(this,message,ms.isEmpty()?"برای شروع «داروی جدید» را انتخاب کن.":"فیلتر «همه» را انتخاب کن تا تمام داروها نمایش داده شوند."),UiKit.matchWrap(this,5,4));
        }
    }

    private void showMedicineFilters(){
        if(filtersHost==null)return;filtersHost.removeAllViews();
        HorizontalScrollView scroll=new HorizontalScrollView(this);scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(false);scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] filters={"همه","فعال","عقب‌افتاده","پایان‌یافته"};
        for(int i=0;i<filters.length;i++){
            final int selected=i;TextView chip=NexaMedicineUi.filter(this,filters[i],medicineFilter==i);
            chip.setOnClickListener(v->{medicineFilter=selected;render();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,44));
            if(i>0)lp.setMargins(UiKit.dp(this,7),0,0,0);row.addView(chip,lp);
        }
        scroll.addView(row);filtersHost.addView(scroll);
    }

    private void addTodayDoses(LinearLayout card,NexaStore.Medicine m){
        long now=System.currentTimeMillis();Calendar cal=Calendar.getInstance();cal.setTimeInMillis(now);cal.set(Calendar.HOUR_OF_DAY,0);cal.set(Calendar.MINUTE,0);cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);long start=cal.getTimeInMillis();cal.add(Calendar.DAY_OF_YEAR,1);long end=cal.getTimeInMillis();
        TextView heading=UiKit.muted(this,"دوزهای امروز");heading.setTextColor(UiKit.CYAN);card.addView(heading,UiKit.matchWrap(this,9,2));
        List<NexaStore.MedicineDoseLog> logs=NexaStore.medicineDoseLogsFor(this,m.id);boolean any=false;
        logs.sort((a,b)->Long.compare(a.scheduledAt,b.scheduledAt));
        for(NexaStore.MedicineDoseLog log:logs){long t=log.scheduledAt>0?log.scheduledAt:log.takenAt;if(t<start||t>=end)continue;any=true;String line;if("skipped".equals(log.status))line="⚪ "+time(t)+" • مصرف نشد";else if(log.takenAt>0&&Math.abs(log.takenAt-t)>60_000L)line="✅ موعد "+time(t)+" • خوردم "+time(log.takenAt);else line="✅ "+time(t)+" • خوردم";card.addView(UiKit.muted(this,line),UiKit.matchWrap(this,2,0));}
        if(m.nextDoseMillis>=start&&m.nextDoseMillis<end){any=true;String line=(m.nextDoseMillis<now?"🔴 ":"⏳ ")+time(m.nextDoseMillis)+" • "+(m.nextDoseMillis<now?"عقب‌افتاده":"نوبت بعد");card.addView(UiKit.muted(this,line),UiKit.matchWrap(this,2,0));}
        if(!any)card.addView(UiKit.muted(this,"برای امروز دوزی باقی نمانده."),UiKit.matchWrap(this,2,0));
    }


    private void addRecentDoseHistory(LinearLayout card,NexaStore.Medicine m){
        long now=System.currentTimeMillis();
        if(m.firstDoseMillis<=0||m.intervalHours<=0)return;
        final long day=24L*60L*60L*1000L;
        long from=Math.max(m.firstDoseMillis,now-7L*day);
        long until=m.endMillis>0?Math.min(now,m.endMillis):now;
        if(until<from)return;
        long step=m.intervalHours*60L*60L*1000L;
        long slot=m.firstDoseMillis;
        if(slot<from){long jumps=(from-slot+step-1)/step;slot+=jumps*step;}
        java.util.ArrayList<String> lines=new java.util.ArrayList<>();
        int taken=0,missed=0,guard=0;
        for(long scheduled=slot;scheduled<=until&&guard<400;scheduled+=step,guard++){
            NexaStore.MedicineDoseLog log=findDoseLog(m.id,scheduled);
            if(log!=null&&log.takenAt>0){taken++;String label=Math.abs(log.takenAt-scheduled)>60_000L?"✅ موعد "+PersianDateUtil.pretty(scheduled)+" • مصرف "+PersianDateUtil.pretty(log.takenAt):"✅ "+PersianDateUtil.pretty(scheduled)+" • مصرف شد";lines.add(label);}
            else if(log!=null&&"skipped".equals(log.status)){missed++;lines.add("⚪ "+PersianDateUtil.pretty(scheduled)+" • ثبت شد: مصرف نشد");}
            else if(scheduled<now){missed++;lines.add("🔴 "+PersianDateUtil.pretty(scheduled)+" • فراموش‌شده");}
        }
        TextView heading=UiKit.muted(this,"۷ روز اخیر • ✅ "+taken+" مصرف‌شده   •   🔴 "+missed+" فراموش‌شده");heading.setTextColor(UiKit.CYAN);card.addView(heading,UiKit.matchWrap(this,10,3));
        int start=Math.max(0,lines.size()-12);
        if(lines.isEmpty())card.addView(UiKit.muted(this,"در ۷ روز اخیر سابقه‌ای ثبت نشده."),UiKit.matchWrap(this,2,0));
        else for(int i=lines.size()-1;i>=start;i--)card.addView(UiKit.muted(this,lines.get(i)),UiKit.matchWrap(this,2,0));
    }

    private long latestEffectiveDoseBase(String medicineId,long fallback){
        long base=fallback;
        for(NexaStore.MedicineDoseLog x:NexaStore.medicineDoseLogsFor(this,medicineId)){
            long candidate="taken_now".equals(x.status)&&x.takenAt>0?x.takenAt:(x.scheduledAt>0?x.scheduledAt:x.takenAt);
            if(candidate>base)base=candidate;
        }
        return base;
    }

    private void reconcileNextDose(NexaStore.Medicine m){
        if(m==null||m.intervalHours<=0)return;
        long base=latestEffectiveDoseBase(m.id,m.firstDoseMillis);
        if(base<=0)return;
        long expected=base+m.intervalHours*60L*60L*1000L;
        if(m.nextDoseMillis!=expected){
            m.nextDoseMillis=expected;
            if(m.endMillis>0&&m.nextDoseMillis>m.endMillis)m.active=false;
            NexaStore.updateMedicine(this,m);
            if(m.active){MedicineScheduler.cancel(this,m.id);MedicineScheduler.schedule(this,m);}
        }
    }

    private void showMedicineReport(){
        List<NexaStore.Medicine> meds=NexaStore.medicines(this);
        LinearLayout box=UiKit.dialogPanel(this);
        box.addView(UiKit.sectionTitle(this,"📊 گزارش مصرف دارو"),UiKit.matchWrap(this,0,8));
        if(meds.isEmpty()){box.addView(UiKit.muted(this,"هنوز دارویی ثبت نشده."));}
        else {
            long now=System.currentTimeMillis();
            for(NexaStore.Medicine m:meds){
                List<NexaStore.MedicineDoseLog> logs=NexaStore.medicineDoseLogsFor(this,m.id);
                MedicineStats.Summary s7=MedicineStats.summarize(m,logs,now,7);
                MedicineStats.Summary s30=MedicineStats.summarize(m,logs,now,30);
                LinearLayout card=UiKit.colorfulCardLayout(this,2);
                card.addView(UiKit.sectionTitle(this,"💊 "+m.name));
                String state=m.active?"فعال":"پایان‌یافته";
                card.addView(UiKit.muted(this,"وضعیت: "+state+(m.active&&m.nextDoseMillis>0?" • نوبت بعد: "+PersianDateUtil.pretty(m.nextDoseMillis):"")),UiKit.matchWrap(this,4,4));
                card.addView(UiKit.muted(this,"۷ روز: "+s7.adherencePercent()+"٪ پایبندی • "+s7.taken+" مصرف • "+s7.missed+" از دست‌رفته"),UiKit.matchWrap(this,2,2));
                card.addView(UiKit.muted(this,"۳۰ روز: "+s30.adherencePercent()+"٪ پایبندی • "+s30.taken+" مصرف • "+s30.missed+" از دست‌رفته"),UiKit.matchWrap(this,2,2));
                card.addView(UiKit.muted(this,"سرِ وقت: "+s30.onTime+" • با تأخیر: "+s30.late+" • ثبت «مصرف نشد»: "+s30.skipped),UiKit.matchWrap(this,2,0));
                box.addView(card,UiKit.matchWrap(this,0,8));
            }
        }
        ScrollView scroll=new ScrollView(this);scroll.addView(box);
        new AlertDialog.Builder(this).setView(scroll).setPositiveButton("بستن",null).show();
    }

    private NexaStore.MedicineDoseLog findDoseLog(String medicineId,long scheduled){for(NexaStore.MedicineDoseLog x:NexaStore.medicineDoseLogsFor(this,medicineId))if(Math.abs(x.scheduledAt-scheduled)<60_000L)return x;return null;}
    private String time(long millis){Calendar c=Calendar.getInstance();c.setTimeInMillis(millis);return String.format(Locale.US,"%02d:%02d",c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE));}
}
