package com.example.silenttimer;

import java.util.Locale;

/** Read-only Persian search normalization, independent of storage and financial math. */
public final class SearchQueryPolicy {
    private SearchQueryPolicy(){}

    /** Arabic/Persian letters and numerals are normalized for matching only. */
    public static String normalize(String raw){
        if(raw==null)return "";
        StringBuilder out=new StringBuilder();
        boolean previousSpace=true;
        for(int i=0;i<raw.length();i++){
            char c=raw.charAt(i);
            if(c=='ي'||c=='ى')c='ی';
            else if(c=='ك')c='ک';
            else if(c=='أ'||c=='إ'||c=='آ')c='ا';
            else if(c=='ۀ'||c=='ة')c='ه';
            else if(c>='۰'&&c<='۹')c=(char)('0'+c-'۰');
            else if(c>='٠'&&c<='٩')c=(char)('0'+c-'٠');
            // Ignore Quranic vowel marks and text direction marks; no user data is changed.
            if((c>='\u064b'&&c<='\u065f') || c=='\u0670' ||
                    c=='\u200e'||c=='\u200f'||c=='\u061c')continue;
            if(Character.isWhitespace(c) || c=='\u200c' || c=='\u200d' ||
                    c=='،'||c==','||c=='؛'||c==';'||c==':'||c=='-'||c=='_'||
                    c=='('||c==')'||c=='/'||c=='\n'||c=='\r'){
                if(!previousSpace){out.append(' ');previousSpace=true;}
            }else{
                out.append(Character.toLowerCase(c));
                previousSpace=false;
            }
        }
        return out.toString().trim();
    }

    /** Search words can appear in different fields, in any order. */
    public static boolean matches(String content,String query){
        String q=normalize(query);
        if(q.isEmpty())return false;
        String hay=normalize(content);
        if(hay.contains(q))return true;
        for(String word:q.split(" "))if(!hay.contains(word))return false;
        return true;
    }

    /** Exact and prefix hits outrank loose matches; caller keeps original ordering for ties. */
    public static int score(String content,String query){
        String h=normalize(content),q=normalize(query);
        if(h.isEmpty()||q.isEmpty())return 0;
        if(h.equals(q))return 4;
        if(h.startsWith(q))return 3;
        if(h.contains(q))return 2;
        return matches(h,q)?1:0;
    }
}
