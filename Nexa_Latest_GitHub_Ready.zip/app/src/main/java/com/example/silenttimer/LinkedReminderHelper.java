package com.example.silenttimer;

import android.content.Context;

public final class LinkedReminderHelper {
    private LinkedReminderHelper() {}

    public static void upsert(Context c,String sourceKey,String title,String category,
            String icon,String note,long whenMillis,String offsetsMinutes,int repeatMinutes){
        upsert(c,sourceKey,title,category,icon,note,whenMillis,offsetsMinutes,repeatMinutes,"none");
    }

    public static void upsert(
            Context c,
            String sourceKey,
            String title,
            String category,
            String icon,
            String note,
            long whenMillis,
            String offsetsMinutes,
            int repeatMinutes,
            String recurrence
    ) {
        for(NexaStore.Reminder old:NexaStore.reminders(c))if(sourceKey.equals(old.sourceKey))ReminderScheduler.cancelReminder(c,old);
        NexaStore.removeReminderBySource(c, sourceKey);

        long now=System.currentTimeMillis();
        String rule=ReminderRecurrence.normalize(recurrence);
        if(whenMillis<=now && ReminderRecurrence.isRecurring(rule) && !sourceKey.startsWith("bill:")){
            whenMillis=ReminderRecurrence.next(whenMillis,rule,now);
        }
        if (whenMillis <= now) {
            ReminderScheduler.rescheduleAll(c);
            TodayNotificationManager.refresh(c);
            return;
        }

        NexaStore.Reminder r = new NexaStore.Reminder();
        r.title = title;
        r.category = category;
        r.icon = icon;
        r.note = note == null ? "" : note;
        r.sourceKey = sourceKey;
        r.whenMillis = whenMillis;
        r.offsetsMinutes = offsetsMinutes;
        r.repeatMinutes = repeatMinutes;
        r.recurrence = ReminderRecurrence.normalize(recurrence);
        NexaStore.addReminder(c, r);
        if(ReminderRecurrence.isRecurring(rule))syncNextOccurrence(c,r);
        ReminderScheduler.scheduleReminder(c, r);
        TodayNotificationManager.refresh(c);
    }

    public static void syncNextOccurrence(Context c,NexaStore.Reminder r){
        if(r==null||r.sourceKey==null||r.sourceKey.isEmpty())return;
        String key=r.sourceKey;
        if(key.startsWith("bill:"))return; // payment state is advanced only by explicit payment
        if(key.startsWith("home:"))for(NexaStore.HomeItem x:NexaStore.homeItems(c))if(key.equals("home:"+x.id)){
            x.nextDueDate=r.whenMillis;NexaStore.updateHomeItem(c,x);return;
        }
        if(key.startsWith("doc:"))for(NexaStore.DocumentItem x:NexaStore.documents(c))if(key.equals("doc:"+x.id)){
            x.expiryDate=r.whenMillis;NexaStore.updateDocument(c,x);return;
        }
        if(key.startsWith("case:"))for(NexaStore.CaseItem x:NexaStore.cases(c))if(key.equals("case:"+x.id)){
            x.whenMillis=r.whenMillis;NexaStore.updateCase(c,x);return;
        }
        if(key.startsWith("service:"))for(NexaStore.Vehicle v:NexaStore.vehicles(c))for(NexaStore.ServiceRecord x:NexaStore.servicesFor(c,v.id))if(key.equals("service:"+x.id)){
            x.nextDueDate=r.whenMillis;NexaStore.updateService(c,x);return;
        }
        if(key.startsWith("ledger:"))for(NexaStore.LedgerEntry x:NexaStore.ledgerEntries(c))if(key.equals("ledger:"+x.id)){
            x.dueMillis=r.whenMillis;NexaStore.updateLedgerEntry(c,x);return;
        }
        if(key.startsWith("shopping:"))for(NexaStore.ShoppingList x:NexaStore.shoppingLists(c))if(key.equals("shopping:"+x.id)){
            x.dueMillis=r.whenMillis;NexaStore.updateShoppingList(c,x,x.name);return;
        }
        if(key.startsWith("todo:"))for(NexaStore.TodoItem x:NexaStore.todos(c))if(key.equals("todo:"+x.id)){
            x.dueMillis=r.whenMillis;x.done=false;NexaStore.updateTodo(c,x);return;
        }
    }

    public static void remove(Context c, String sourceKey) {
        for(NexaStore.Reminder old:NexaStore.reminders(c))if(sourceKey.equals(old.sourceKey))ReminderScheduler.cancelReminder(c,old);
        NexaStore.removeReminderBySource(c, sourceKey);
        ReminderScheduler.rescheduleAll(c);
        TodayNotificationManager.refresh(c);
    }
}
