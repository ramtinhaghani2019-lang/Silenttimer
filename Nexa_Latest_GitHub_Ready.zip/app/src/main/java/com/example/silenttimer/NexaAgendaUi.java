package com.example.silenttimer;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Pure presentation primitives for Today and Timeline: no storage, timekeeping or navigation. */
final class NexaAgendaUi {
    private NexaAgendaUi(){}

    static LinearLayout stats(Context c,String[] labels,String[] values,int[] accents){
        if(labels==null||values==null||accents==null||labels.length!=values.length||labels.length!=accents.length)
            throw new IllegalArgumentException("Metric arrays must have identical length");
        // Three metrics should not become three giant vertical cards on a normal 320dp phone.
        float density=c.getResources().getDisplayMetrics().density;
        float widthDp=c.getResources().getDisplayMetrics().widthPixels/Math.max(0.1f,density);
        boolean stack=HomeUi.shouldStack(c) &&
                (widthDp<310f||c.getResources().getConfiguration().fontScale>=1.60f);
        LinearLayout group=new LinearLayout(c);
        group.setOrientation(stack?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        group.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int k=0;k<labels.length;k++){
            LinearLayout tile=UiKit.cardLayout(c);
            tile.setPadding(UiKit.dp(c,9),UiKit.dp(c,10),UiKit.dp(c,9),UiKit.dp(c,10));
            tile.setBackground(UiKit.colorfulCard(c,accentVariant(accents[k])));
            TextView value=new TextView(c);
            value.setText(values[k]);value.setTextColor(accents[k]);
            value.setTextSize(19f);value.setTypeface(UiKit.appFace(c,true));
            value.setGravity(Gravity.RIGHT);value.setMaxLines(2);
            TextView label=UiKit.muted(c,labels[k]);label.setTextSize(11f);label.setMaxLines(2);
            tile.addView(value);tile.addView(label,UiKit.matchWrap(c,2,0));
            tile.setContentDescription(labels[k]+"، "+values[k]);
            LinearLayout.LayoutParams lp=stack?new LinearLayout.LayoutParams(-1,-2):
                    new LinearLayout.LayoutParams(0,-2,1f);
            if(k>0){if(stack)lp.topMargin=UiKit.dp(c,7);else lp.leftMargin=UiKit.dp(c,8);}
            group.addView(tile,lp);
        }
        return group;
    }
    private static int accentVariant(int color){
        if(color==UiKit.RED||color==UiKit.PINK)return 4;
        if(color==UiKit.GREEN||color==UiKit.TEAL)return 3;
        if(color==UiKit.GOLD||color==UiKit.ORANGE)return 0;
        if(color==UiKit.BLUE||color==UiKit.CYAN)return 2;
        return 5;
    }
    static LinearLayout event(Context c,String emoji,String title,String detail,String state,int tone,boolean actionable){
        LinearLayout item=new LinearLayout(c);item.setOrientation(LinearLayout.HORIZONTAL);
        item.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        item.setGravity(Gravity.CENTER_VERTICAL);
        item.setPadding(UiKit.dp(c,10),UiKit.dp(c,8),UiKit.dp(c,10),UiKit.dp(c,8));
        item.setMinimumHeight(UiKit.dp(c,76));
        item.setBackground(tone==UiKit.RED?UiKit.subtlePastCard(c):UiKit.card(c));
        TextView symbol=new TextView(c);symbol.setText(emoji==null?"◈":emoji);
        symbol.setGravity(Gravity.CENTER);symbol.setTextSize(19f);symbol.setTextColor(UiKit.GOLD);
        symbol.setBackground(UiKit.rounded(c,0xFF1C3551,11));
        item.addView(symbol,new LinearLayout.LayoutParams(UiKit.dp(c,38),UiKit.dp(c,38)));
        LinearLayout body=new LinearLayout(c);body.setOrientation(LinearLayout.VERTICAL);
        TextView head=UiKit.sectionTitle(c,title==null?"":title);
        head.setTextColor(UiKit.TEXT);head.setTextSize(13.5f);head.setMaxLines(2);
        body.addView(head);
        if(state!=null&&!state.isEmpty()){
            TextView status=UiKit.muted(c,state);
            status.setTextColor(tone);status.setTextSize(11.5f);
            body.addView(status,UiKit.matchWrap(c,2,0));
        }
        TextView sub=UiKit.muted(c,detail==null?"":detail);
        sub.setTextSize(11f);sub.setMaxLines(2);
        body.addView(sub,UiKit.matchWrap(c,3,0));
        LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1f);
        bp.setMargins(UiKit.dp(c,8),0,0,0);item.addView(body,bp);
        if(actionable){
            TextView arrow=UiKit.muted(c,"‹");arrow.setTextSize(24f);
            arrow.setGravity(Gravity.CENTER);arrow.setTextColor(UiKit.MUTED);
            item.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(c,21),UiKit.dp(c,40)));
            UiKit.touchFeedback(c,item,UiKit.PURPLE,19);
        }
        return item;
    }
    static TextView chip(Context c,String text,boolean selected){
        TextView chip=UiKit.chip(c,text,selected);
        chip.setMinHeight(UiKit.dp(c,44));
        chip.setTextSize(12.5f);
        UiKit.touchFeedback(c,chip,UiKit.PURPLE,18);
        return chip;
    }
}
