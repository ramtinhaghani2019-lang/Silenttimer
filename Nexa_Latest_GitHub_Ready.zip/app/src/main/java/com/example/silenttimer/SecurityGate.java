package com.example.silenttimer;
import android.content.Context;
public final class SecurityGate {
    private SecurityGate(){}
    private static boolean unlocked=false;
    private static long unlockedUntil=0L;
    public static void unlock(){unlocked=true;unlockedUntil=System.currentTimeMillis()+5L*60L*1000L;}
    public static void unlock(Context c){
        int min=NexaStore.securityAutoLockMinutes(c);
        if(min<=0)min=5;
        unlocked=true;unlockedUntil=System.currentTimeMillis()+min*60L*1000L;
    }
    public static void lock(){unlocked=false;unlockedUntil=0L;}
    public static boolean isUnlocked(){if(!unlocked)return false;if(System.currentTimeMillis()>unlockedUntil){lock();return false;}return true;}
}
