package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public final class EmergencyCardManager {
    private static final String CHANNEL = "nexa_emergency_card_v2";
    private static final int ID = 9400;
    private EmergencyCardManager() {}

    public static void refresh(Context c) {
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);

        if(!NexaStore.emergencyEnabled(c)) {
            nm.cancel(ID);
            return;
        }

        if(Build.VERSION.SDK_INT>=26) {
            NotificationChannel ch=new NotificationChannel(
                    CHANNEL,
                    "Nexa Emergency Card",
                    NotificationManager.IMPORTANCE_HIGH
            );
            ch.setDescription("کارت اضطراری اختیاری روی صفحه قفل");
            ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            ch.setSound(null,null);
            nm.createNotificationChannel(ch);
        }

        Intent open=new Intent(c,EmergencyActivity.class);
        PendingIntent pi=PendingIntent.getActivity(
                c,ID,open,
                PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE
        );

        String name=NexaStore.emergencyName(c);
        String p1=NexaStore.emergencyPhone1(c);
        String p2=NexaStore.emergencyPhone2(c);
        String note=NexaStore.emergencyNote(c);

        String title="🆘 Nexa Emergency";
        if(!name.isEmpty()) title+=" • "+name;

        String text="";
        if(!p1.isEmpty())text+="تماس: "+p1;
        if(!p2.isEmpty())text+=(text.isEmpty()?"":" • ")+p2;
        if(!note.isEmpty())text+=(text.isEmpty()?"":" • ")+note;
        if(text.isEmpty())text="کارت اضطراری فعال است";

        Notification.Builder b=Build.VERSION.SDK_INT>=26
                ? new Notification.Builder(c,CHANNEL)
                : new Notification.Builder(c);

        Notification n=b
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(new Notification.BigTextStyle().bigText(text))
                .setContentIntent(pi)
                .setOngoing(true)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_HIGH)
                .build();

        nm.notify(ID,n);
    }
}
