package com.example.silenttimer;

/** UI unit conversion only. Existing asset monetary fields remain persisted in toman.
 * Never multiply stored prices or convert persisted legacy rows in-place. */
public final class AssetMoneyUnit {
    private AssetMoneyUnit() {}
    public static boolean isRial(String currency) {return "ریال".equals(currency);}
    public static String displayUnit(String currency) {return isRial(currency)?"ریال":"تومان";}
    public static double fromStored(double toman, String displayUnit) {
        return isRial(displayUnit)?toman*10d:toman;
    }
    public static double toStored(double input, String displayUnit) {
        return isRial(displayUnit)?input/10d:input;
    }
}
