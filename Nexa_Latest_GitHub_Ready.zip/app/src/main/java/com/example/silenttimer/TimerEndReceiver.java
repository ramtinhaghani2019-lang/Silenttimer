package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class TimerEndReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null) return;
        // Restore before asking Android to start a service: background FGS
        // restrictions must not strand the user in Silent after the deadline.
        try {
            TimerExpiryRecovery.restoreIfDue(context);
        } catch (RuntimeException error) {
            BackgroundReliability.record(context, "timer-expire.direct-restore", error);
            TimerExpiryRecovery.scheduleRetry(context);
        }
        Intent service = new Intent(context, SilentTimerService.class);
        service.setAction(SilentTimerService.ACTION_EXPIRE);

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (RuntimeException error) {
            BackgroundReliability.record(context, "timer-expire.start", error);
        }
    }
}
