package com.example.silenttimer;

import java.util.List;

/** Applies a single manually entered fund/unit quote to an entire asset type.
 * Pure calculations and all-or-nothing validation happen before persistence. */
public final class AssetGroupQuoteEngine {
    private AssetGroupQuoteEngine() {}
    private static String norm(String s){return s==null?"":s.trim();}
    public static boolean validQuote(double quote){return Double.isFinite(quote)&&quote>0;}
    public static boolean belongs(NexaStore.AssetEntry x,String group){
        return x!=null&&!norm(group).isEmpty()&&norm(group).equals(norm(x.type));
    }
    public static double quantity(List<NexaStore.AssetEntry> data){
        double q=0;
        if(data==null)return 0;
        for(NexaStore.AssetEntry x:data)if(x!=null){q+=x.amount;}
        return q;
    }
    /** A single unit quote is only shown when every purchase has the same rate. */
    public static double sharedQuote(List<NexaStore.AssetEntry> data){
        if(data==null||data.isEmpty())return Double.NaN;
        double quote=Double.NaN;
        for(NexaStore.AssetEntry x:data){
            if(x==null||!validQuote(x.currentUnitPrice))return Double.NaN;
            if(Double.isNaN(quote))quote=x.currentUnitPrice;
            else if(Double.compare(quote,x.currentUnitPrice)!=0)return Double.NaN;
        }
        return quote;
    }
    /** Returns affected count; zero indicates invalid input, so no entries were changed. */
    public static int applyQuote(List<NexaStore.AssetEntry> data,String group,double quote,long asOf){
        if(data==null||norm(group).isEmpty()||!validQuote(quote)||asOf<=0)return 0;
        int matched=0;
        double groupMarket=0d,groupCost=0d;
        // Validate every affected entry and the whole new valuation before touching any entry.
        for(NexaStore.AssetEntry x:data){
            if(!belongs(x,group))continue;
            if(!Double.isFinite(x.amount)||x.amount<0
                    ||!Double.isFinite(x.buyUnitPrice)||x.buyUnitPrice<0
                    ||!Double.isFinite(x.fee)||x.fee<0
                    ||!Double.isFinite(x.realizedProfit)||!Double.isFinite(x.soldAmount)||x.soldAmount<0
                    ||!Double.isFinite(x.amount*quote)
                    ||!Double.isFinite(x.amount*x.buyUnitPrice+x.fee))return 0;
            groupMarket+=x.amount*quote;
            groupCost+=x.amount*x.buyUnitPrice+x.fee;
            if(!Double.isFinite(groupMarket)||!Double.isFinite(groupCost))return 0;
            matched++;
        }
        if(matched==0)return 0;
        for(NexaStore.AssetEntry x:data)if(belongs(x,group)){
            x.currentUnitPrice=quote;
            x.autoPrice=false; // Keep this fund's own NAV separate from generic market feeds.
            x.quoteUpdatedAt=asOf;
        }
        return matched;
    }
}
