package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Pure, privacy-minimizing recent route policy. Only fixed route keys are kept:
 * no contact names, amounts, medical records, search text or other user data.
 */
public final class QuickAccessRecentPolicy {
    private static final String[] VALID = {
            "voice", "occasion", "reminder", "medicine", "shopping", "todo",
            "bills", "assets", "case", "docs", "homecare", "vehicle"
    };
    private static final int MAX = 3;
    private QuickAccessRecentPolicy() {}

    public static boolean isAllowed(String key) {
        if (key == null) return false;
        for (String id : VALID) if (id.equals(key)) return true;
        return false;
    }

    /** Sanitizes older or corrupt stored values and preserves most-recent-first order. */
    public static List<String> recent(String stored) {
        if (stored == null || stored.isEmpty()) return Collections.emptyList();
        List<String> result = new ArrayList<>();
        for (String key : stored.split(",", -1)) {
            if (!isAllowed(key) || result.contains(key)) continue;
            result.add(key);
            if (result.size() == MAX) break;
        }
        return result;
    }

    public static String remember(String stored, String key) {
        List<String> keys = new ArrayList<>(recent(stored));
        if (isAllowed(key)) {
            keys.remove(key);
            keys.add(0, key);
            if (keys.size() > MAX) keys.remove(keys.size()-1);
        }
        return String.join(",", keys);
    }
}
