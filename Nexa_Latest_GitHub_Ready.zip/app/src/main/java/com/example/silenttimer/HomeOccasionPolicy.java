package com.example.silenttimer;

import java.util.List;

/** Non-mutating, user-visible occasion preview for the dashboard. */
public final class HomeOccasionPolicy {
    private HomeOccasionPolicy(){}
    public static final class Match {
        public final OccasionStore.Occasion occasion;
        public final long due;
        Match(OccasionStore.Occasion value,long at){occasion=value;due=at;}
    }
    public static Match closest(List<OccasionStore.Occasion> occasions,long now){
        Match best=null;
        if(occasions==null)return null;
        for(OccasionStore.Occasion e:occasions){
            if(e==null||!e.active)continue;
            long due=AnnualOccasionDates.next(e,now);
            if(due<=0)continue;
            if(best==null||due<best.due)best=new Match(e,due);
        }
        return best;
    }
    public static boolean hasScheduled(List<OccasionStore.Occasion> occasions,long now){
        return closest(occasions,now)!=null;
    }
}
