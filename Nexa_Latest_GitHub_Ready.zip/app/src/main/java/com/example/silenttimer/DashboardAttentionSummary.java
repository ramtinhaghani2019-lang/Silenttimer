package com.example.silenttimer;

/** UI-only alert summary: zero-valued categories never waste vertical space. */
final class DashboardAttentionSummary {
    private DashboardAttentionSummary(){}
    static String compact(int reminders,int bills,int documents,int home,int todos){
        int[] counts={reminders,bills,documents,home,todos};
        String[] labels={"یادآور معوق","پرداخت معوق","مدرک رو به انقضا","سرویس خانه","کار عقب‌افتاده"};
        int total=0;
        StringBuilder result=new StringBuilder();
        for(int i=0;i<counts.length;i++){
            if(counts[i]<=0)continue;
            total+=counts[i];
            if(result.length()>0)result.append("  •  ");
            result.append(toPersian(counts[i])).append(' ').append(labels[i]);
        }
        if(total==0)return "موردی نیازمند توجه نیست";
        return result.toString();
    }
    private static String toPersian(int n){
        return String.valueOf(n).replace('0','۰').replace('1','۱').replace('2','۲')
                .replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶')
                .replace('7','۷').replace('8','۸').replace('9','۹');
    }
}
