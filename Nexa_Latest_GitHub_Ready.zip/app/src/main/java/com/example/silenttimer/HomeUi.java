package com.example.silenttimer;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.TextView;

/** Native, concise dashboard components; no network or persistence side effects. */
final class HomeUi {
    private HomeUi(){}
    private static final int CARD=0xFF0D203A;
    private static final int CARD_FOCUS=0xFF10294B;
    private static final int BORDER=0xFF38547B;
    private static final int WHITE=0xFFF5F7FC;
    private static final int SUB=0xFFADBBD0;
    static boolean shouldStack(Context c){
        float density=c.getResources().getDisplayMetrics().density;
        float width=c.getResources().getDisplayMetrics().widthPixels/density;
        return width<440f||c.getResources().getConfiguration().fontScale>1.10f;
    }
    /** Keep the reference-style two-column grid on ordinary phones.
     * Accessibility users with very large fonts still get full-width rows. */
    static boolean compactGridNeedsStack(Context c){
        float density=c.getResources().getDisplayMetrics().density;
        float widthDp=c.getResources().getDisplayMetrics().widthPixels/Math.max(0.1f,density);
        return widthDp<350f || c.getResources().getConfiguration().fontScale>=1.45f;
    }
    private static GradientDrawable shape(Context c,int fill,int stroke,int radius){
        GradientDrawable bg=new GradientDrawable();
        // Subtle directional light gives native cards depth without bitmaps.
        int upper=fill==CARD_FOCUS?0xFF1A3B65:(fill==CARD?0xFF142E50:fill);
        bg.setOrientation(GradientDrawable.Orientation.TL_BR);
        bg.setColors(new int[]{upper,fill});
        bg.setCornerRadius(UiKit.dp(c,radius));
        bg.setStroke(UiKit.dp(c,1),stroke);
        return bg;
    }
    static LinearLayout panel(Context c,boolean focus){
        LinearLayout p=new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        p.setPadding(UiKit.dp(c,12),UiKit.dp(c,11),UiKit.dp(c,12),UiKit.dp(c,11));
        p.setBackground(shape(c,focus?CARD_FOCUS:CARD,focus?0xFFC39B54:BORDER,17));
        // Prevent tiny targets when the system font is enlarged.
        p.setMinimumHeight(UiKit.dp(c,48));
        return p;
    }
    static TextView secondary(Context c,String s){
        TextView t=new TextView(c);
        t.setText(s);t.setTextColor(SUB);t.setTextSize(12);
        t.setGravity(Gravity.RIGHT);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        t.setIncludeFontPadding(false);t.setLineSpacing(UiKit.dp(c,3),1.10f);
        return t;
    }
    static TextView heading(Context c,String s){
        TextView t=new TextView(c);
        t.setText(s);t.setTextColor(WHITE);t.setTextSize(15);
        t.setTypeface(UiKit.appFace(c,true));
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);t.setLineSpacing(UiKit.dp(c,2),1.05f);
        // Semantic heading improves navigation for screen readers (API 28+).
        if(android.os.Build.VERSION.SDK_INT>=28)t.setAccessibilityHeading(true);
        return t;
    }
    static TextView sectionLabel(Context c,String s){
        TextView v=heading(c,s);
        v.setTextSize(15f);v.setTextColor(0xFFE7C37C);v.setPadding(UiKit.dp(c,2),UiKit.dp(c,3),UiKit.dp(c,2),UiKit.dp(c,3));
        return v;
    }
    static TextView badge(Context c,String s,int color){
        TextView v=secondary(c,s);v.setTextSize(12f);v.setTextColor(0xFFF4F6F1);
        v.setGravity(Gravity.CENTER);v.setPadding(UiKit.dp(c,11),UiKit.dp(c,7),UiKit.dp(c,11),UiKit.dp(c,7));
        v.setBackground(shape(c,0xFF2A3850,color,100));
        return v;
    }
    static LinearLayout headerRow(Context c,String s,String action){
        LinearLayout line=new LinearLayout(c);line.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=heading(c,s);line.addView(t,new LinearLayout.LayoutParams(0,-2,1f));
        TextView a=secondary(c,action);a.setTextColor(UiKit.GOLD);a.setTextSize(12);
        line.addView(a);
        return line;
    }
    /** Consistent 48dp+ touch feedback and TalkBack names for dashboard destinations. */
    static void destination(Context c,View view,String description,int rippleColor){
        view.setClickable(true);
        view.setFocusable(true);
        view.setContentDescription(description);
        UiKit.touchFeedback(c,view,rippleColor,20);
    }
    static LinearLayout balanceCard(Context c,String title,int color){
        LinearLayout card=panel(c,false);
        int shaded=color==UiKit.GREEN?0xFF0B382C:
                   color==UiKit.PURPLE?0xFF302044:
                   color==UiKit.RED?0xFF461923:0xFF43310F;
        int upper=color==UiKit.GREEN?0xFF12614B:
                  color==UiKit.PURPLE?0xFF56366D:
                  color==UiKit.RED?0xFF742E3A:0xFF6B531A;
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{upper,shaded});
        bg.setCornerRadius(UiKit.dp(c,16));
        bg.setStroke(UiKit.dp(c,1),UiKit.withAlpha(color,0xCC));
        card.setBackground(bg);
        card.setPadding(UiKit.dp(c,10),UiKit.dp(c,7),UiKit.dp(c,10),UiKit.dp(c,7));
        TextView titleView=secondary(c,title);
        titleView.setTextColor(0xFFF7F4EE);titleView.setTextSize(12f);
        titleView.setTypeface(UiKit.appFace(c,true));
        card.addView(titleView);
        card.setMinimumHeight(UiKit.dp(c,80));
        return card;
    }
    static TextView money(Context c,String s,int color){
        TextView v=heading(c,s);
        v.setTextSize(15f);v.setTextColor(color);v.setMaxLines(2);
        // Currency is rendered separately; auto-size prevents long Persian
        // digit balances from being cropped inside the financial card.
        v.setAutoSizeTextTypeUniformWithConfiguration(11,15,1,
                TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
        v.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
        return v;
    }
    /** Amount and currency share one row to avoid a third oversized line in every finance tile. */
    static LinearLayout compactAmount(Context c,TextView amount){
        LinearLayout row=new LinearLayout(c);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView currency=secondary(c,"تومان");
        currency.setTextSize(10.5f);
        currency.setMinWidth(UiKit.dp(c,36));
        row.addView(currency,new LinearLayout.LayoutParams(-2,-2));
        row.addView(amount,new LinearLayout.LayoutParams(0,-2,1f));
        return row;
    }

    /** Native compact destination cards; use the same outline icon family as the directory. */
    static LinearLayout shortcut(Context c,String icon,String title,String subtitle){
        LinearLayout card=panel(c,false);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(UiKit.dp(c,8),UiKit.dp(c,13),UiKit.dp(c,8),UiKit.dp(c,12));
        card.setMinimumHeight(UiKit.dp(c,116));
        String kind="modules";
        if(title.contains("یادآور"))kind="reminders";
        else if(title.contains("مناسبت"))kind="occasions";
        else if(title.contains("حساب"))kind="ledger";
        else if(title.contains("فهرست"))kind="lists";
        else if(title.contains("دارو"))kind="medicine";
        else if(title.contains("شارژ"))kind="battery";
        else if(title.contains("جست"))kind="search";
        else if(title.contains("خط زمان"))kind="timeline";
        NexaOutlineIcon symbol=new NexaOutlineIcon(c,kind,UiKit.GOLD);
        symbol.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        card.addView(symbol,new LinearLayout.LayoutParams(UiKit.dp(c,32),UiKit.dp(c,32)));
        TextView name=heading(c,title);
        name.setGravity(Gravity.CENTER);
        name.setTextSize(13.5f);
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(name,UiKit.matchWrap(c,8,1));
        TextView description=secondary(c,subtitle);
        description.setGravity(Gravity.CENTER);
        description.setTextSize(10.5f);
        description.setMaxLines(2);
        description.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(description);
        name.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        description.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        destination(c,card,title+"؛ "+subtitle,UiKit.GOLD);
        return card;
    }

    /** Reference-aligned circular header action with a real vector icon and 48dp touch target. */
    static FrameLayout headerAction(Context c,String kind,String description,int tint){
        FrameLayout frame=new FrameLayout(c);
        GradientDrawable bg=new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{0xFF203B52,0xFF091A29});
        bg.setCornerRadius(UiKit.dp(c,40));
        bg.setStroke(UiKit.dp(c,1),0xFFA88B54);
        frame.setBackground(bg);
        NexaOutlineIcon symbol=new NexaOutlineIcon(c,kind,tint);
        FrameLayout.LayoutParams ip=new FrameLayout.LayoutParams(UiKit.dp(c,23),UiKit.dp(c,23),Gravity.CENTER);
        frame.addView(symbol,ip);
        frame.setMinimumWidth(UiKit.dp(c,48));
        frame.setMinimumHeight(UiKit.dp(c,48));
        destination(c,frame,description,tint);
        return frame;
    }
    /** Short reference-style action: symbol above a Persian label. */
    static LinearLayout miniShortcut(Context c,String kind,String title){
        LinearLayout card=panel(c,false);
        card.setGravity(Gravity.CENTER);
        card.setPadding(UiKit.dp(c,3),UiKit.dp(c,8),UiKit.dp(c,3),UiKit.dp(c,7));
        card.setMinimumHeight(UiKit.dp(c,70));
        NexaOutlineIcon icon=new NexaOutlineIcon(c,kind,UiKit.GOLD);
        card.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(c,24),UiKit.dp(c,24)));
        TextView text=heading(c,title);
        text.setTextSize(10f);
        text.setGravity(Gravity.CENTER);
        text.setMaxLines(1);
        text.setEllipsize(android.text.TextUtils.TruncateAt.END);
        card.addView(text,UiKit.matchWrap(c,5,0));
        destination(c,card,"باز کردن "+title,UiKit.GOLD);
        return card;
    }

    static TextView directoryLink(Context c,String label){
        TextView t=heading(c,label);t.setGravity(Gravity.CENTER);
        t.setTextColor(0xFFDBE6F7);t.setTextSize(14f);
        t.setMinHeight(UiKit.dp(c,48));t.setFocusable(true);
        t.setBackground(shape(c,0xFF263D60,0xFF557FB9,16));
        UiKit.touchFeedback(c,t,UiKit.PURPLE,16);
        t.setContentDescription("باز کردن فهرست همه بخش‌ها و ابزارهای Nexa");
        return t;
    }
}
