package com.example.silenttimer;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Native, concise dashboard components; no network or persistence side effects. */
final class HomeUi {
    private HomeUi(){}
    private static final int CARD=0xFF211C3D;
    private static final int CARD_FOCUS=0xFF28224A;
    private static final int BORDER=0xFF453A70;
    private static final int WHITE=0xFFF8F7FF;
    private static final int SUB=0xFFB6B4D2;
    static boolean shouldStack(Context c){
        float density=c.getResources().getDisplayMetrics().density;
        float width=c.getResources().getDisplayMetrics().widthPixels/density;
        return width<350f||c.getResources().getConfiguration().fontScale>1.18f;
    }
    private static GradientDrawable shape(Context c,int fill,int stroke,int radius){
        GradientDrawable bg=new GradientDrawable();
        bg.setColor(fill);
        bg.setCornerRadius(UiKit.dp(c,radius));
        bg.setStroke(UiKit.dp(c,1),stroke);
        return bg;
    }
    static LinearLayout panel(Context c,boolean focus){
        LinearLayout p=new LinearLayout(c);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        p.setPadding(UiKit.dp(c,15),UiKit.dp(c,14),UiKit.dp(c,15),UiKit.dp(c,14));
        p.setBackground(shape(c,focus?CARD_FOCUS:CARD,focus?0xFF8969D3:BORDER,20));
        return p;
    }
    static TextView secondary(Context c,String s){
        TextView t=new TextView(c);
        t.setText(s);t.setTextColor(SUB);t.setTextSize(13);
        t.setGravity(Gravity.RIGHT);t.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        t.setIncludeFontPadding(false);t.setLineSpacing(UiKit.dp(c,2),1.05f);
        return t;
    }
    static TextView heading(Context c,String s){
        TextView t=new TextView(c);
        t.setText(s);t.setTextColor(WHITE);t.setTextSize(16);
        t.setTypeface(Typeface.create("sans-serif-medium",Typeface.BOLD));
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        t.setIncludeFontPadding(false);
        return t;
    }
    static TextView sectionLabel(Context c,String s){
        TextView v=heading(c,s);
        v.setTextSize(15f);v.setTextColor(0xFFE1DCFF);v.setPadding(UiKit.dp(c,2),0,UiKit.dp(c,2),0);
        return v;
    }
    static TextView badge(Context c,String s,int color){
        TextView v=secondary(c,s);v.setTextSize(12f);v.setTextColor(0xFFF4F6F1);
        v.setGravity(Gravity.CENTER);v.setPadding(UiKit.dp(c,11),UiKit.dp(c,7),UiKit.dp(c,11),UiKit.dp(c,7));
        v.setBackground(shape(c,0xFF28264A,color,100));
        return v;
    }
    static LinearLayout headerRow(Context c,String s,String action){
        LinearLayout line=new LinearLayout(c);line.setGravity(Gravity.CENTER_VERTICAL);
        TextView t=heading(c,s);line.addView(t,new LinearLayout.LayoutParams(0,-2,1f));
        TextView a=secondary(c,action);a.setTextColor(UiKit.GOLD);a.setTextSize(12);
        line.addView(a);
        return line;
    }
    static LinearLayout balanceCard(Context c,String title,int color){
        LinearLayout card=panel(c,false);
        TextView titleView=secondary(c,"●  "+title);
        titleView.setTextColor(color);titleView.setTextSize(13f);
        card.addView(titleView);
        card.setMinimumHeight(UiKit.dp(c,83));
        return card;
    }
    static TextView money(Context c,String s,int color){
        TextView v=heading(c,s);
        v.setTextSize(16f);v.setTextColor(color);v.setMaxLines(3);
        v.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
        return v;
    }
    static LinearLayout shortcut(Context c,String icon,String title,String subtitle){
        LinearLayout line=panel(c,false);
        line.setOrientation(LinearLayout.HORIZONTAL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setMinimumHeight(UiKit.dp(c,72));
        TextView pict=heading(c,icon);pict.setTextSize(24);pict.setGravity(Gravity.CENTER);
        line.addView(pict,new LinearLayout.LayoutParams(UiKit.dp(c,40),UiKit.dp(c,45)));
        LinearLayout texts=new LinearLayout(c);texts.setOrientation(LinearLayout.VERTICAL);
        TextView label=heading(c,title);label.setTextSize(14);
        TextView desc=secondary(c,subtitle);desc.setTextSize(11f);desc.setMaxLines(2);
        texts.addView(label);texts.addView(desc,UiKit.matchWrap(c,4,0));
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1f);
        tp.setMargins(UiKit.dp(c,5),0,0,0);
        line.addView(texts,tp);
        UiKit.touchFeedback(c,line,UiKit.GOLD,18);
        return line;
    }
    static TextView directoryLink(Context c,String label){
        TextView t=heading(c,label);t.setGravity(Gravity.CENTER);
        t.setTextColor(0xFFE1DCFF);t.setTextSize(14f);
        t.setMinHeight(UiKit.dp(c,50));
        t.setBackground(shape(c,0xFF33265A,0xFF7355B8,16));
        UiKit.touchFeedback(c,t,UiKit.PURPLE,16);
        t.setContentDescription("مشاهده همه بخش‌های Nexa");
        return t;
    }
}
