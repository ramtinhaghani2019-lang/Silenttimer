package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.telephony.TelephonyManager;

public class CallStateReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(intent.getAction())) {
            return;
        }

        String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);

        if (!TelephonyManager.EXTRA_STATE_IDLE.equals(state)) {
            return;
        }

        if (!AppPrefs.isBypassActive(context)) {
            return;
        }

        AudioManager am =
                (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);

        int restoreMode;

        if (AppPrefs.isTimerActive(context)) {
            restoreMode = AppPrefs.getTargetRingerMode(context);
        } else {
            restoreMode = AppPrefs.getBypassRestoreMode(context);
        }

        AppPrefs.setIgnoreManualUntil(
                context,
                System.currentTimeMillis() + 5000L
        );

        try {
            NexaAudioController.setRingerMode(context, restoreMode);
        } catch (SecurityException ignored) {}

        AppPrefs.setBypassActive(context, false);
    }
}
