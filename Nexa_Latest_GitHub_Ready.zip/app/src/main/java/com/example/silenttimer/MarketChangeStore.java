package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;

/** Provider-provided change percentages relative to previous trading day. No inferred values. */
final class MarketChangeStore {
    private MarketChangeStore() {}
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("nexa_market_day_change",Context.MODE_PRIVATE);}
    static void save(Context c, JSONObject changes, String feedDate, String feedTime){
        SharedPreferences.Editor e=prefs(c).edit().clear();
        if(changes!=null){
            java.util.Iterator<String> it=changes.keys();
            while(it.hasNext()){
                String key=it.next();
                double v=changes.optDouble(key,Double.NaN);
                if(Double.isFinite(v)&&v>=-100d&&v<=10000d)e.putString("pct_"+key,String.valueOf(v));
            }
        }
        String d=feedDate==null?"":feedDate.trim().replaceAll("[^0-9۰-۹/\\-]","");
        String t=feedTime==null?"":feedTime.trim().replaceAll("[^0-9۰-۹:]","");
        e.putString("date",d.substring(0,Math.min(16,d.length())));
        e.putString("time",t.substring(0,Math.min(8,t.length())));
        e.apply();
    }
    static String sourceDate(Context c){
        String date=prefs(c).getString("date","");
        String time=prefs(c).getString("time","");
        return date.isEmpty()?"":date+(time.isEmpty()?"":" • "+time);
    }
    static double percent(Context c,String name){
        String[] keys;
        if(name.contains("یورو"))keys=new String[]{"euro","eur"};
        else if(name.contains("دلار"))keys=new String[]{"dollar","usd"};
        else if(name.contains("۱۸"))keys=new String[]{"gold","gold18","gold_18"};
        else if(name.contains("۲۴"))keys=new String[]{"gold24","gold_24"};
        else if(name.contains("اونس"))keys=new String[]{"ounce","gold_ounce"};
        else if(name.contains("امامی"))keys=new String[]{"coin","emami"};
        else if(name.contains("بهار"))keys=new String[]{"bahar"};
        else if(name.contains("نیم"))keys=new String[]{"half"};
        else if(name.contains("ربع"))keys=new String[]{"quarter"};
        else if(name.contains("گرمی"))keys=new String[]{"gram","gerami"};
        else return Double.NaN;
        for(String key:keys){String raw=prefs(c).getString("pct_"+key,null);if(raw!=null){
            try{return Double.parseDouble(raw);}catch(NumberFormatException ignored){}
        }}
        return Double.NaN;
    }
}
