package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Read-only forecast of upcoming bill obligations; never mutates persisted bills. */
public final class BillForecast {
    private BillForecast() {}

    public static final class Entry {
        public final String id, title, type, recurrence;
        public final long amount, dueMillis;
        public final boolean paid;
        public Entry(String id, String title, String type, long amount, long dueMillis,
                     String recurrence, boolean paid) {
            this.id=id==null?"":id;
            this.title=title==null?"":title;
            this.type=type==null?"":type;
            this.amount=amount;
            this.dueMillis=dueMillis;
            this.recurrence=recurrence==null?"":recurrence;
            this.paid=paid;
        }
    }

    public static final class Occurrence {
        public final String id, title, type;
        public final long at, amount;
        public final boolean projected;
        Occurrence(Entry entry, long date, boolean futureRepeat) {
            id=entry.id;title=entry.title;type=entry.type;
            at=date;amount=Math.max(0L,entry.amount);projected=futureRepeat;
        }
    }

    public static final class Result {
        public final List<Occurrence> upcoming;
        public final List<Occurrence> overdue;
        public final long upcomingTotal, overdueTotal;
        Result(List<Occurrence> upcoming, List<Occurrence> overdue) {
            this.upcoming=Collections.unmodifiableList(upcoming);
            this.overdue=Collections.unmodifiableList(overdue);
            long future=0L,past=0L;
            for(Occurrence o:upcoming) future=safeAdd(future,o.amount);
            for(Occurrence o:overdue) past=safeAdd(past,o.amount);
            upcomingTotal=future;overdueTotal=past;
        }
    }

    private static long safeAdd(long a,long b) {
        if(b<=0L)return a;
        return a>Long.MAX_VALUE-b?Long.MAX_VALUE:a+b;
    }

    /** Calendar-day shift respects daylight-saving changes in the user's timezone. */
    static long horizon(long now,int days){
        Calendar c=Calendar.getInstance();c.setTimeInMillis(now);
        c.add(Calendar.DAY_OF_YEAR,days);return c.getTimeInMillis();
    }

    /** From now (inclusive) to now+days (exclusive); 1..90 days. */
    public static Result calculate(List<Entry> bills,long now,int days){
        if(days<1||days>90)throw new IllegalArgumentException("days must be 1..90");
        long until=horizon(now,days);
        List<Occurrence> upcoming=new ArrayList<>(),overdue=new ArrayList<>();
        if(bills!=null)for(Entry e:bills){
            if(e==null||e.paid||e.dueMillis<=0L)continue;
            // An overdue recurring bill does not advance until the user records a payment;
            // do not invent future obligations for its still-unsettled schedule.
            if(e.dueMillis<now){
                overdue.add(new Occurrence(e,e.dueMillis,false));
                continue;
            }
            boolean monthly="ماهانه".equals(e.recurrence), yearly="سالانه".equals(e.recurrence);
            if(!monthly&&!yearly){
                if(e.dueMillis<until) upcoming.add(new Occurrence(e,e.dueMillis,false));
                continue;
            }
            long at=e.dueMillis;
            for(int offset=0;offset<8&&at<until;offset++){
                upcoming.add(new Occurrence(e,at,offset>0));
                // Match BillsActivity.markPaid, which advances each period from the current due date.
                long next=monthly?PersianDateUtil.addJalaliMonths(at,1)
                                 :PersianDateUtil.addJalaliYears(at,1);
                if(next<=at)break;
                at=next;
            }
        }
        Comparator<Occurrence> byDate=Comparator.comparingLong(o->o.at);
        upcoming.sort(byDate);overdue.sort(byDate);
        return new Result(upcoming,overdue);
    }

    public static long sumBefore(List<Occurrence> items,long exclusiveEnd){
        long total=0L;
        if(items!=null)for(Occurrence o:items)if(o!=null&&o.at<exclusiveEnd)total=safeAdd(total,o.amount);
        return total;
    }
}
