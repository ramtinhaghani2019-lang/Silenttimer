package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Visual-only garage components: no repository, scheduler, alarm or vehicle mutation. */
final class NexaGarageUi {
    private NexaGarageUi() {}

    static LinearLayout metrics(Context c, int vehicles, int overdue, int soon) {
        return metricsWithFirstLabel(c,"وسایل",vehicles,overdue,soon);
    }

    static LinearLayout serviceMetrics(Context c, int services, int overdue, int soon) {
        return metricsWithFirstLabel(c,"سرویس‌ها",services,overdue,soon);
    }

    private static LinearLayout metricsWithFirstLabel(Context c, String firstLabel, int count, int overdue, int soon) {
        String[] labels={firstLabel,"موعد گذشته","نزدیک سرویس"};
        int[] values={count,overdue,soon};
        int[] tones={UiKit.PURPLE,UiKit.RED,UiKit.GOLD};
        int[] variants={5,4,0};
        LinearLayout strip=new LinearLayout(c);
        boolean stacked=HomeUi.shouldStack(c);
        strip.setOrientation(stacked?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        strip.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<labels.length;i++) {
            LinearLayout card=UiKit.cardLayout(c);
            card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            card.setPadding(UiKit.dp(c,11),UiKit.dp(c,11),UiKit.dp(c,10),UiKit.dp(c,10));
            card.setBackground(UiKit.colorfulCard(c,variants[i]));
            card.setMinimumHeight(UiKit.dp(c,78));
            TextView value=UiKit.sectionTitle(c,String.valueOf(values[i]));
            value.setTextColor(tones[i]);value.setTextSize(23f);
            value.setGravity(Gravity.RIGHT);card.addView(value);
            TextView label=UiKit.muted(c,labels[i]);label.setTextSize(11.5f);
            card.addView(label,UiKit.matchWrap(c,3,0));
            card.setContentDescription(labels[i]+"، "+values[i]+" مورد");
            LinearLayout.LayoutParams lp=stacked?new LinearLayout.LayoutParams(-1,-2):new LinearLayout.LayoutParams(0,-2,1f);
            if(i>0){if(stacked)lp.topMargin=UiKit.dp(c,7);else lp.leftMargin=UiKit.dp(c,7);}
            strip.addView(card,lp);
        }
        return strip;
    }

    static LinearLayout vehicleCard(Context c, boolean overdue, boolean soon) {
        LinearLayout card=UiKit.cardLayout(c);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(UiKit.dp(c,14),UiKit.dp(c,13),UiKit.dp(c,14),UiKit.dp(c,13));
        card.setMinimumHeight(UiKit.dp(c,112));
        card.setBackground(overdue?UiKit.subtlePastCard(c):UiKit.colorfulCard(c,soon?0:5));
        return card;
    }

    static LinearLayout serviceGroup(Context c, boolean overdue, boolean soon) {
        LinearLayout card=UiKit.cardLayout(c);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setBackground(overdue?UiKit.subtlePastCard(c):UiKit.colorfulCard(c,soon?0:5));
        card.setPadding(UiKit.dp(c,12),UiKit.dp(c,12),UiKit.dp(c,12),UiKit.dp(c,12));
        card.setMinimumHeight(UiKit.dp(c,72));
        return card;
    }

    static LinearLayout historyRecord(Context c) {
        LinearLayout card=UiKit.cardLayout(c);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(UiKit.dp(c,12),UiKit.dp(c,11),UiKit.dp(c,12),UiKit.dp(c,11));
        card.setMinimumHeight(UiKit.dp(c,76));
        return card;
    }

    static TextView state(Context c, String title, int color) {
        TextView badge=UiKit.statusBadge(c,title,color);
        badge.setTextColor(color);badge.setTextSize(11.5f);
        badge.setGravity(Gravity.CENTER);
        badge.setMinHeight(UiKit.dp(c,34));
        return badge;
    }

    static TextView sectionLabel(Context c, String title) {
        TextView titleView=UiKit.sectionTitle(c,title);
        titleView.setTextSize(15f);
        titleView.setPadding(0,UiKit.dp(c,11),0,UiKit.dp(c,7));
        return titleView;
    }
}
