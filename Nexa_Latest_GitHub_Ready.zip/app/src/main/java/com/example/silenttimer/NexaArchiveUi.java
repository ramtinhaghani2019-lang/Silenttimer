package com.example.silenttimer;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Shared lightweight Aurora surfaces for activity history and local-file management. */
public final class NexaArchiveUi {
    private NexaArchiveUi(){}
    public static HorizontalScrollView metrics(Context c,String[] titles,String[] values,int[] colors){
        HorizontalScrollView sc=new HorizontalScrollView(c);
        sc.setHorizontalScrollBarEnabled(false);
        sc.setFillViewport(true);
        LinearLayout strip=new LinearLayout(c);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<titles.length;i++){
            LinearLayout item=UiKit.financialMetric(c,titles[i],values[i],colors[i]);
            item.setMinimumWidth(UiKit.dp(c,118));
            // Fixed minimum-size touch-friendly cards remain scrollable on narrow screens.
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(UiKit.dp(c,124),-2);
            if(i>0)p.setMargins(UiKit.dp(c,8),0,0,0);
            strip.addView(item,p);
        }
        sc.addView(strip);
        return sc;
    }
    public static TextView chip(Context c,String title,boolean selected){
        TextView chip=new TextView(c);
        chip.setText(title);
        chip.setTextSize(13f);
        chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(UiKit.dp(c,46));
        chip.setPadding(UiKit.dp(c,16),UiKit.dp(c,10),UiKit.dp(c,16),UiKit.dp(c,10));
        chip.setTextColor(selected?UiKit.TEXT:UiKit.MUTED);
        GradientDrawable surface=UiKit.rounded(c,selected?0xFF423268:0xFF22203E,24);
        surface.setStroke(UiKit.dp(c,1),UiKit.withAlpha(selected?UiKit.PURPLE:UiKit.INDIGO,selected?0xD0:0x58));
        chip.setBackground(surface);
        chip.setClickable(true);chip.setFocusable(true);
        chip.setContentDescription(title+(selected?"، انتخاب‌شده":"، انتخاب فیلتر"));
        UiKit.touchFeedback(c,chip,UiKit.PURPLE,24);
        return chip;
    }
    public static LinearLayout record(Context c,String title,String detail,String badge,int accent){
        LinearLayout box=UiKit.cardLayout(c);
        box.setMinimumHeight(UiKit.dp(c,80));
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView name=UiKit.sectionTitle(c,title==null?"":title);
        name.setMaxLines(3);
        box.addView(name,UiKit.matchWrap(c,0,4));
        if(badge!=null&&!badge.isEmpty()){
            LinearLayout badges=new LinearLayout(c);badges.setGravity(Gravity.RIGHT);
            badges.addView(UiKit.statusBadge(c,badge,accent));
            box.addView(badges,UiKit.matchWrap(c,2,5));
        }
        if(detail!=null&&!detail.isEmpty())box.addView(UiKit.muted(c,detail));
        box.setContentDescription((title==null?"":title)+"، "+(detail==null?"":detail));
        return box;
    }
}
