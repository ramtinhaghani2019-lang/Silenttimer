package com.example.silenttimer;

import java.util.Calendar;

public final class PersianDateUtil {
    private PersianDateUtil() {}

    public static final String[] MONTHS = {
            "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
            "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    };

    public static int[] fromMillis(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        return gregorianToJalali(
                c.get(Calendar.YEAR),
                c.get(Calendar.MONTH) + 1,
                c.get(Calendar.DAY_OF_MONTH)
        );
    }

    public static long toMillis(int jy, int jm, int jd, int hour, int minute) {
        int[] g = jalaliToGregorian(jy, jm, jd);
        Calendar c = Calendar.getInstance();
        c.set(Calendar.YEAR, g[0]);
        c.set(Calendar.MONTH, g[1] - 1);
        c.set(Calendar.DAY_OF_MONTH, g[2]);
        c.set(Calendar.HOUR_OF_DAY, hour);
        c.set(Calendar.MINUTE, minute);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static String weekday(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        switch (c.get(Calendar.DAY_OF_WEEK)) {
            case Calendar.SATURDAY: return "شنبه";
            case Calendar.SUNDAY: return "یکشنبه";
            case Calendar.MONDAY: return "دوشنبه";
            case Calendar.TUESDAY: return "سه‌شنبه";
            case Calendar.WEDNESDAY: return "چهارشنبه";
            case Calendar.THURSDAY: return "پنجشنبه";
            default: return "جمعه";
        }
    }

    public static String format(long millis) {
        int[] j = fromMillis(millis);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        return weekday(millis) + " • " + String.format(
                java.util.Locale.US,
                "%04d/%02d/%02d  %02d:%02d",
                j[0], j[1], j[2],
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE)
        );
    }

    public static String pretty(long millis) {
        int[] j = fromMillis(millis);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        return weekday(millis) + "، " + j[2] + " " + MONTHS[j[1]-1] + " " + j[0] +
                " • " + String.format(java.util.Locale.US, "%02d:%02d",
                c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    public static long addJalaliMonths(long millis, int months) {
        int[] j = fromMillis(millis);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);

        int total = (j[0] * 12 + (j[1] - 1)) + months;
        int newYear = total / 12;
        int newMonth = total % 12 + 1;
        int newDay = Math.min(j[2], monthLength(newYear, newMonth));

        return toMillis(
                newYear,
                newMonth,
                newDay,
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE)
        );
    }

    public static long addJalaliYears(long millis, int years) {
        int[] j = fromMillis(millis);
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        int newYear = j[0] + years;
        int newDay = Math.min(j[2], monthLength(newYear, j[1]));
        return toMillis(
                newYear,
                j[1],
                newDay,
                c.get(Calendar.HOUR_OF_DAY),
                c.get(Calendar.MINUTE)
        );
    }

    public static int monthLength(int jy, int jm) {
        if (jm <= 6) return 31;
        if (jm <= 11) return 30;
        return isLeapJalali(jy) ? 30 : 29;
    }

    public static boolean isLeapJalali(int jy) {
        int[] breaks = {-61, 9, 38, 199, 426, 686, 756, 818, 1111,
                1181, 1210, 1635, 2060, 2097, 2192, 2262, 2324, 2394, 2456, 3178};
        int bl = breaks.length;
        int gy = jy + 621;
        int leapJ = -14;
        int jp = breaks[0];
        int jump = 0;
        if (jy < jp || jy >= breaks[bl - 1]) return false;
        for (int i = 1; i < bl; i++) {
            int jm = breaks[i];
            jump = jm - jp;
            if (jy < jm) break;
            leapJ += div(jump, 33) * 8 + div(mod(jump, 33), 4);
            jp = jm;
        }
        int n = jy - jp;
        leapJ += div(n, 33) * 8 + div(mod(n, 33) + 3, 4);
        if (mod(jump, 33) == 4 && jump - n == 4) leapJ++;
        int leapG = div(gy, 4) - div((div(gy, 100) + 1) * 3, 4) - 150;
        int march = 20 + leapJ - leapG;
        if (jump - n < 6) n = n - jump + div(jump + 4, 33) * 33;
        int leap = mod(mod(n + 1, 33) - 1, 4);
        if (leap == -1) leap = 4;
        return leap == 0;
    }

    public static int[] jalaliToGregorian(int jy, int jm, int jd) {
        jy += 1595;
        int days = -355668 + (365 * jy) + (div(jy, 33) * 8) + div(mod(jy, 33) + 3, 4) + jd;
        if (jm < 7) days += (jm - 1) * 31;
        else days += ((jm - 7) * 30) + 186;
        int gy = 400 * div(days, 146097);
        days = mod(days, 146097);
        if (days > 36524) {
            gy += 100 * div(--days, 36524);
            days = mod(days, 36524);
            if (days >= 365) days++;
        }
        gy += 4 * div(days, 1461);
        days = mod(days, 1461);
        if (days > 365) {
            gy += div(days - 1, 365);
            days = mod(days - 1, 365);
        }
        int gd = days + 1;
        int[] sal_a = {0, 31, ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)) ? 29 : 28,
                31,30,31,30,31,31,30,31,30,31};
        int gm;
        for (gm = 1; gm <= 12 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
        return new int[]{gy, gm, gd};
    }

    public static int[] gregorianToJalali(int gy, int gm, int gd) {
        int[] g_d_m = {0,31,59,90,120,151,181,212,243,273,304,334};
        int gy2 = (gm > 2) ? (gy + 1) : gy;
        int days = 355666 + (365 * gy) + div(gy2 + 3, 4) - div(gy2 + 99, 100) +
                div(gy2 + 399, 400) + gd + g_d_m[gm - 1];
        int jy = -1595 + 33 * div(days, 12053);
        days = mod(days, 12053);
        jy += 4 * div(days, 1461);
        days = mod(days, 1461);
        if (days > 365) {
            jy += div(days - 1, 365);
            days = mod(days - 1, 365);
        }
        int jm, jd;
        if (days < 186) {
            jm = 1 + div(days, 31);
            jd = 1 + mod(days, 31);
        } else {
            jm = 7 + div(days - 186, 30);
            jd = 1 + mod(days - 186, 30);
        }
        return new int[]{jy, jm, jd};
    }

    private static int div(int a, int b) { return a / b; }
    private static int mod(int a, int b) { return a - (a / b) * b; }
}
