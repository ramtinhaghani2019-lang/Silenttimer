package com.example.silenttimer;
import android.app.AlarmManager;import android.app.PendingIntent;import android.content.*;import android.os.Build;
/** Battery-conscious background price check. Android may batch this inexact alarm. */
public class PriceMonitorReceiver extends BroadcastReceiver{
    public static final long INTERVAL=15*60_000L;
    public void onReceive(Context c,Intent i){if(!AssetMarketEngine.hasActiveAlerts(c)){cancel(c);return;}final PendingResult pr=goAsync();MarketDataHelper.refresh(c,(ok,msg)->{try{if(ok){AssetMarketEngine.updateOnlineAssets(c);AssetMarketEngine.checkAlerts(c);}}finally{schedule(c);pr.finish();}});}
    public static void schedule(Context c){if(!AssetMarketEngine.hasActiveAlerts(c)){cancel(c);return;}AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;long at=System.currentTimeMillis()+INTERVAL;am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pending(c));}
    public static void cancel(Context c){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pending(c));}
    private static PendingIntent pending(Context c){int flags=PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);return PendingIntent.getBroadcast(c,4579,new Intent(c,PriceMonitorReceiver.class),flags);}
}
