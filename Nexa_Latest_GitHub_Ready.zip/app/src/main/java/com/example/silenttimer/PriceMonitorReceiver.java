package com.example.silenttimer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/** Inexact and bounded price checks: no unresolved goAsync broadcast during a slow network request. */
public class PriceMonitorReceiver extends BroadcastReceiver {
    public static final long INTERVAL = 15 * 60_000L;

    @Override public void onReceive(Context context, Intent intent) {
        final Context c = context.getApplicationContext();
        try {
            if (!AssetMarketEngine.hasActiveAlerts(c)) { cancel(c); return; }
            final BackgroundReliability.BroadcastCompletion completion =
                    new BackgroundReliability.BroadcastCompletion(c, "price-monitor", goAsync(), () -> schedule(c));
            try {
                MarketDataHelper.refresh(c, (ok, message) -> completion.finish(() -> {
                    if (ok) {
                        AssetMarketEngine.updateOnlineAssets(c);
                        AssetMarketEngine.checkAlerts(c);
                    }
                }));
            } catch (RuntimeException error) {
                BackgroundReliability.record(c, "price-monitor.start", error);
                completion.finish(null);
            }
        } catch (RuntimeException error) {
            BackgroundReliability.record(c, "price-monitor.receive", error);
        }
    }

    public static void schedule(Context c) {
        if (!AssetMarketEngine.hasActiveAlerts(c)) { cancel(c); return; }
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + INTERVAL, pending(c));
    }

    public static void cancel(Context c) {
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pending(c));
    }

    private static PendingIntent pending(Context c) {
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        return PendingIntent.getBroadcast(c, 4579, new Intent(c, PriceMonitorReceiver.class), flags);
    }
}
