package com.example.silenttimer;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Read-only, time-filtered ledger reports. Never rewrites stored transactions or account balances. */
public final class LedgerReport {
    private LedgerReport() {}

    public static final class Row {
        public final NexaStore.LedgerEntry entry;
        public final String partyName;
        /** Signed amount added to this party's balance. Positive = they owe me. */
        public final long delta;
        /** Balance after this transaction, including transactions before the report's date range. */
        public final long runningBalance;
        Row(NexaStore.LedgerEntry entry, String partyName, long delta, long runningBalance) {
            this.entry=entry;
            this.partyName=partyName;
            this.delta=delta;
            this.runningBalance=runningBalance;
        }
    }

    public static final class Result {
        public final List<Row> rows;
        public final long openingNet;
        public final long closingNet;
        public final long debtAdded;
        public final long creditAdded;
        public final long paid;
        public final long received;
        public final long periodChange;
        Result(List<Row> rows,long openingNet,long closingNet,long debtAdded,long creditAdded,
               long paid,long received,long periodChange) {
            this.rows=Collections.unmodifiableList(rows);
            this.openingNet=openingNet;
            this.closingNet=closingNet;
            this.debtAdded=debtAdded;
            this.creditAdded=creditAdded;
            this.paid=paid;
            this.received=received;
            this.periodChange=periodChange;
        }
    }

    /** 0 = all dates; otherwise the rolling 30/90-day window ending at now. */
    public static long startMillis(int recentDays,long now) {
        if(recentDays<=0)return Long.MIN_VALUE;
        long duration=recentDays*86400000L;
        return now<Long.MIN_VALUE+duration?Long.MIN_VALUE:now-duration;
    }

    public static Result generate(List<NexaStore.LedgerParty> parties,
                                  List<NexaStore.LedgerEntry> entries,
                                  String selectedPartyId,long start,long end) {
        Map<String,String> names=new HashMap<>();
        if(parties!=null)for(NexaStore.LedgerParty p:parties) {
            if(p!=null&&p.id!=null)names.put(p.id,p.name==null?"":p.name);
        }
        List<NexaStore.LedgerEntry> sorted=new ArrayList<>();
        if(entries!=null)for(NexaStore.LedgerEntry e:entries) {
            if(e!=null && e.partyId!=null && (selectedPartyId==null || selectedPartyId.equals(e.partyId)))sorted.add(e);
        }
        sorted.sort((a,b)->{
            int byTime=Long.compare(a.dateMillis,b.dateMillis);
            if(byTime!=0)return byTime;
            String ai=a.id==null?"":a.id,bi=b.id==null?"":b.id;
            return ai.compareTo(bi);
        });
        Map<String,Long> balances=new HashMap<>();
        List<Row> rows=new ArrayList<>();
        long opening=0,closing=0,debt=0,credit=0,paid=0,received=0,change=0;
        for(NexaStore.LedgerEntry e:sorted) {
            long delta=NexaStore.ledgerDelta(e);
            long previous=balances.containsKey(e.partyId)?balances.get(e.partyId):0L;
            long current=previous+delta;
            balances.put(e.partyId,current);
            if(e.dateMillis<start){opening+=delta;closing+=delta;continue;}
            if(e.dateMillis>end)continue;
            closing+=delta;
            change+=delta;
            if("DEBT".equals(e.kind))debt+=e.amount;
            if("CREDIT".equals(e.kind))credit+=e.amount;
            if("PAYMENT".equals(e.kind))paid+=e.amount;
            if("RECEIPT".equals(e.kind))received+=e.amount;
            String name=names.get(e.partyId);
            rows.add(new Row(e,name==null||name.trim().isEmpty()?"طرف‌حساب نامشخص":name,delta,current));
        }
        return new Result(rows,opening,closing,debt,credit,paid,received,change);
    }

    private static String label(String kind) {
        if("DEBT".equals(kind))return "بدهی جدید";
        if("CREDIT".equals(kind))return "طلب جدید";
        if("PAYMENT".equals(kind))return "پرداخت کردم";
        if("RECEIPT".equals(kind))return "دریافت کردم";
        return "نامشخص";
    }

    /** Escape RFC 4180 quotes and protect Excel/Sheets from formula injection. */
    public static String csvCell(String value) {
        String s=value==null?"":value;
        String leading=s.trim();
        if(!leading.isEmpty()) {
            char c=leading.charAt(0);
            if(c=='='||c=='+'||c=='-'||c=='@')s="'"+s;
        }
        return "\""+s.replace("\"","\"\"")+"\"";
    }

    private static String date(long when) {
        return when<=0?"":new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(new Date(when));
    }

    /** UTF-8 BOM makes Persian headers and text readable in Excel on Windows. */
    public static String toCsv(Result report) {
        StringBuilder out=new StringBuilder("\uFEFF");
        out.append("تاریخ,طرف‌حساب,نوع تراکنش,مبلغ (تومان),تغییر مانده (تومان),مانده حساب (تومان),سررسید,توضیحات\r\n");
        for(Row r:report.rows){
            NexaStore.LedgerEntry e=r.entry;
            String[] cells={date(e.dateMillis),r.partyName,label(e.kind),Long.toString(e.amount),
                    Long.toString(r.delta),Long.toString(r.runningBalance),date(e.dueMillis),e.note};
            for(int i=0;i<cells.length;i++){
                if(i>0)out.append(',');
                // Amount and balances are generated numeric values, safe as numbers in Excel.
                out.append(i>=3 && i<=5 ? cells[i] : csvCell(cells[i]));
            }
            out.append("\r\n");
        }
        return out.toString();
    }
}
