package com.example.silenttimer;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.view.Gravity;
import android.widget.TextView;

/** Build 198: native visual components for medication screens. No data or scheduling access. */
final class NexaMedicineUi {
    private NexaMedicineUi(){}
    static HorizontalScrollView metrics(Context c,int active,int overdue,int soon){
        HorizontalScrollView scroll=new HorizontalScrollView(c);
        scroll.setHorizontalScrollBarEnabled(false);scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout strip=new LinearLayout(c);strip.setOrientation(LinearLayout.HORIZONTAL);
        strip.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] labels={"داروی فعال","عقب‌افتاده","در ۲۴ ساعت آینده"};
        int[] numbers={active,overdue,soon},tones={UiKit.TEAL,UiKit.RED,UiKit.GOLD};
        for(int i=0;i<labels.length;i++){
            LinearLayout tile=UiKit.cardLayout(c);
            tile.setPadding(UiKit.dp(c,12),UiKit.dp(c,10),UiKit.dp(c,12),UiKit.dp(c,10));
            tile.setBackground(UiKit.colorfulCard(c,i==1?4:i==2?0:1));
            tile.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            TextView value=UiKit.sectionTitle(c,String.valueOf(numbers[i]));
            value.setTextSize(21f);value.setTextColor(tones[i]);tile.addView(value);
            TextView label=UiKit.muted(c,labels[i]);label.setTextSize(11.5f);label.setMaxLines(2);
            tile.addView(label,UiKit.matchWrap(c,3,0));
            tile.setContentDescription(labels[i]+"، "+numbers[i]+" دارو");
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(UiKit.dp(c,116),UiKit.dp(c,84));
            if(i>0)lp.setMargins(UiKit.dp(c,8),0,0,0);strip.addView(tile,lp);
        }
        scroll.addView(strip);return scroll;
    }
    static TextView filter(Context c,String title,boolean selected){
        return NexaCareUi.filter(c,title,selected);
    }
    static LinearLayout medicineCard(Context c,int state){
        LinearLayout card=UiKit.cardLayout(c);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(UiKit.dp(c,15),UiKit.dp(c,12),UiKit.dp(c,15),UiKit.dp(c,13));
        if(state==MedicineOverviewPolicy.OVERDUE)card.setBackground(UiKit.subtlePastCard(c));
        else if(state==MedicineOverviewPolicy.SOON)card.setBackground(UiKit.colorfulCard(c,0));
        else if(state==MedicineOverviewPolicy.FINISHED)card.setBackground(UiKit.colorfulCard(c,5));
        else card.setBackground(UiKit.colorfulCard(c,1));
        card.setMinimumHeight(UiKit.dp(c,105));
        return card;
    }
    static TextView state(Context c,int state){
        String label=state==MedicineOverviewPolicy.OVERDUE?"● موعد گذشته":
                state==MedicineOverviewPolicy.SOON?"◷ نوبت نزدیک":
                state==MedicineOverviewPolicy.FINISHED?"✓ دوره پایان‌یافته":"● در برنامه";
        int color=state==MedicineOverviewPolicy.OVERDUE?UiKit.RED:
                state==MedicineOverviewPolicy.SOON?UiKit.GOLD:
                state==MedicineOverviewPolicy.FINISHED?UiKit.INDIGO:UiKit.TEAL;
        TextView badge=UiKit.statusBadge(c,label,color);
        badge.setTextSize(12f);badge.setTextColor(color);
        badge.setMinHeight(UiKit.dp(c,34));
        badge.setContentDescription(label);
        return badge;
    }
    static TextView formHeading(Context c,String heading){
        TextView title=UiKit.fieldLabel(c,heading);title.setTextSize(14f);
        title.setPadding(UiKit.dp(c,2),UiKit.dp(c,14),UiKit.dp(c,2),UiKit.dp(c,6));
        return title;
    }
}
