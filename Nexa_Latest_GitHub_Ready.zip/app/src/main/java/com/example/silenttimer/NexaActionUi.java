package com.example.silenttimer;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Compact, accessible premium Aurora action and search surfaces. No persistence here. */
public final class NexaActionUi {
    private NexaActionUi(){}
    public static LinearLayout tile(Context c,String emoji,String label,String detail,int variant){
        LinearLayout tile=UiKit.colorfulCardLayout(c,variant);
        tile.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        tile.setMinimumHeight(UiKit.dp(c,112));
        tile.setPadding(UiKit.dp(c,13),UiKit.dp(c,13),UiKit.dp(c,13),UiKit.dp(c,13));
        TextView pict=UiKit.sectionTitle(c,emoji);pict.setTextSize(23f);
        tile.addView(pict,UiKit.matchWrap(c,0,8));
        TextView name=UiKit.sectionTitle(c,label);name.setTextSize(14.5f);name.setTextColor(UiKit.TEXT);
        tile.addView(name);
        TextView sub=UiKit.muted(c,detail);sub.setMaxLines(2);sub.setTextSize(11.8f);
        tile.addView(sub,UiKit.matchWrap(c,5,0));
        tile.setClickable(true);tile.setFocusable(true);
        tile.setContentDescription("باز کردن "+label+"، "+detail);
        return tile;
    }
    public static LinearLayout result(Context c,String title,String detail,String group,boolean exact){
        LinearLayout card=UiKit.cardLayout(c);
        card.setMinimumHeight(UiKit.dp(c,82));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout top=new LinearLayout(c);top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView name=UiKit.sectionTitle(c,title);name.setTextSize(14.5f);name.setTextColor(UiKit.TEXT);
        top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=UiKit.muted(c,"‹");arrow.setTextSize(26f);arrow.setGravity(Gravity.CENTER);
        top.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(c,28),UiKit.dp(c,38)));
        card.addView(top);
        TextView description=UiKit.muted(c,detail);description.setMaxLines(3);
        card.addView(description,UiKit.matchWrap(c,1,8));
        LinearLayout meta=new LinearLayout(c);meta.setOrientation(LinearLayout.HORIZONTAL);meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView category=UiKit.statusBadge(c,group,UiKit.INDIGO);meta.addView(category);
        if(exact){TextView best=UiKit.statusBadge(c,"تطابق دقیق",UiKit.GREEN);
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,-2);bp.setMargins(UiKit.dp(c,7),0,0,0);meta.addView(best,bp);}
        card.addView(meta);
        card.setClickable(true);card.setFocusable(true);
        card.setContentDescription("باز کردن نتیجه "+title+"، "+group);
        return card;
    }
    public static TextView categoryChip(Context c,String label,boolean chosen){
        TextView t=UiKit.chip(c,label,chosen);t.setMinHeight(UiKit.dp(c,44));
        t.setPadding(UiKit.dp(c,15),UiKit.dp(c,8),UiKit.dp(c,15),UiKit.dp(c,8));
        t.setClickable(true);t.setFocusable(true);t.setContentDescription(label+(chosen?"، انتخاب‌شده":"، انتخاب فیلتر"));
        return t;
    }
}
