package com.example.silenttimer;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Compact, accessible premium Aurora action and search surfaces. No persistence here. */
public final class NexaActionUi {
    private NexaActionUi(){}
    public static LinearLayout tile(Context c,String emoji,String label,String detail,int variant){
        LinearLayout tile=UiKit.colorfulCardLayout(c,variant);
        tile.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        tile.setMinimumHeight(UiKit.dp(c,112));
        tile.setPadding(UiKit.dp(c,13),UiKit.dp(c,13),UiKit.dp(c,13),UiKit.dp(c,13));
        LinearLayout iconTile=new LinearLayout(c);
        iconTile.setGravity(Gravity.CENTER);
        int tint=quickTint(variant);
        iconTile.setBackground(UiKit.rounded(c,UiKit.withAlpha(tint,0x26),12));
        iconTile.addView(new NexaOutlineIcon(c,quickKind(label,emoji),tint),
                new LinearLayout.LayoutParams(UiKit.dp(c,24),UiKit.dp(c,24)));
        tile.addView(iconTile,new LinearLayout.LayoutParams(UiKit.dp(c,46),UiKit.dp(c,46)));
        TextView name=UiKit.sectionTitle(c,label);name.setTextSize(14.5f);name.setTextColor(UiKit.TEXT);
        tile.addView(name);
        TextView sub=UiKit.muted(c,detail);sub.setMaxLines(2);sub.setTextSize(11.8f);
        tile.addView(sub,UiKit.matchWrap(c,5,0));
        tile.setClickable(true);tile.setFocusable(true);
        tile.setContentDescription("باز کردن "+label+"، "+detail);
        return tile;
    }
    /** One-line icon + two-line description, ideal on narrow screens or large font sizes. */
    /** Shared grouped quick-entry row: 64dp, real pictogram, two-line label and an arrow. */
    public static LinearLayout compactTile(Context c,String emoji,String label,String detail,int variant){
        LinearLayout tile=new LinearLayout(c);
        tile.setOrientation(LinearLayout.HORIZONTAL);
        tile.setGravity(Gravity.CENTER_VERTICAL);
        tile.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        tile.setMinimumHeight(UiKit.dp(c,64));
        tile.setPadding(UiKit.dp(c,10),UiKit.dp(c,7),UiKit.dp(c,10),UiKit.dp(c,7));
        int color=quickTint(variant);
        LinearLayout iconTile=new LinearLayout(c);
        iconTile.setGravity(Gravity.CENTER);
        iconTile.setBackground(UiKit.rounded(c,UiKit.withAlpha(color,0x24),12));
        iconTile.addView(new NexaOutlineIcon(c,quickKind(label,emoji),color),
                new LinearLayout.LayoutParams(UiKit.dp(c,23),UiKit.dp(c,23)));
        tile.addView(iconTile,new LinearLayout.LayoutParams(UiKit.dp(c,42),UiKit.dp(c,42)));
        LinearLayout words=new LinearLayout(c);words.setOrientation(LinearLayout.VERTICAL);
        words.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView name=UiKit.sectionTitle(c,label);name.setTextSize(14.5f);name.setMaxLines(2);
        TextView desc=UiKit.muted(c,detail);desc.setTextSize(11.5f);desc.setMaxLines(2);
        words.addView(name);words.addView(desc,UiKit.matchWrap(c,3,0));
        LinearLayout.LayoutParams wp=new LinearLayout.LayoutParams(0,-2,1f);
        wp.setMargins(UiKit.dp(c,10),0,UiKit.dp(c,4),0);
        tile.addView(words,wp);
        TextView arrow=UiKit.muted(c,"‹");arrow.setTextSize(20f);arrow.setGravity(Gravity.CENTER);
        tile.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(c,20),UiKit.dp(c,38)));
        tile.setClickable(true);tile.setFocusable(true);
        tile.setContentDescription("باز کردن "+label+"، "+detail);
        UiKit.touchFeedback(c,tile,color,13);
        return tile;
    }
    private static int quickTint(int variant){
        switch(variant){
            case 0:return UiKit.GOLD;
            case 1:return UiKit.CYAN;
            case 2:return UiKit.TEAL;
            case 3:return UiKit.GREEN;
            case 4:return UiKit.PINK;
            case 5:return UiKit.INDIGO;
            case 6:return UiKit.PURPLE;
            default:return UiKit.BLUE;
        }
    }
    private static String quickKind(String label,String emoji){
        if(label.contains("صوت"))return "voice";
        if(label.contains("مناسبت"))return "occasions";
        if(label.contains("یادآور"))return "reminders";
        if(label.contains("دارو"))return "medicine";
        if(label.contains("خرید"))return "shopping";
        if(label.contains("کارهای"))return "todo";
        if(label.contains("قسط")||label.contains("قبض"))return "bills";
        if(label.contains("دارایی"))return "assets";
        if(label.contains("پرونده"))return "case";
        if(label.contains("مدرک"))return "docs";
        if(label.contains("خانه"))return "home";
        if(label.contains("خودرو"))return "vehicle";
        return "quick";
    }
    public static LinearLayout result(Context c,String title,String detail,String group,boolean exact){
        LinearLayout card=UiKit.cardLayout(c);
        card.setMinimumHeight(UiKit.dp(c,82));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout top=new LinearLayout(c);top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView name=UiKit.sectionTitle(c,title);name.setTextSize(14.5f);name.setTextColor(UiKit.TEXT);
        top.addView(name,new LinearLayout.LayoutParams(0,-2,1));
        TextView arrow=UiKit.muted(c,"‹");arrow.setTextSize(26f);arrow.setGravity(Gravity.CENTER);
        top.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(c,28),UiKit.dp(c,38)));
        card.addView(top);
        TextView description=UiKit.muted(c,detail);description.setMaxLines(3);
        card.addView(description,UiKit.matchWrap(c,1,8));
        LinearLayout meta=new LinearLayout(c);meta.setOrientation(LinearLayout.HORIZONTAL);meta.setGravity(Gravity.CENTER_VERTICAL);
        TextView category=UiKit.statusBadge(c,group,UiKit.INDIGO);meta.addView(category);
        if(exact){TextView best=UiKit.statusBadge(c,"تطابق دقیق",UiKit.GREEN);
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,-2);bp.setMargins(UiKit.dp(c,7),0,0,0);meta.addView(best,bp);}
        card.addView(meta);
        card.setClickable(true);card.setFocusable(true);
        card.setContentDescription("باز کردن نتیجه "+title+"، "+group);
        return card;
    }
    public static TextView categoryChip(Context c,String label,boolean chosen){
        TextView t=UiKit.chip(c,label,chosen);t.setMinHeight(UiKit.dp(c,44));
        t.setPadding(UiKit.dp(c,15),UiKit.dp(c,8),UiKit.dp(c,15),UiKit.dp(c,8));
        t.setClickable(true);t.setFocusable(true);t.setContentDescription(label+(chosen?"، انتخاب‌شده":"، انتخاب فیلتر"));
        return t;
    }
}
