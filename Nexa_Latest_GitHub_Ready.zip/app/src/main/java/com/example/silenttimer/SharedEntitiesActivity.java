package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

/** Central shared directory for sellers/providers and bank cards. */
public class SharedEntitiesActivity extends Activity {
    private LinearLayout sellersBox,cardsBox;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){
        ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));
        root.addView(UiKit.title(this,"دفتر مشترک نِکسا"));
        root.addView(UiKit.featureHero(this,"contacts","دفتر مشترک","فروشندگان، سرویس‌دهندگان و کارت‌های ذخیره‌شده"),UiKit.matchWrap(this,0,14));
        
        LinearLayout sellers=UiKit.colorfulCardLayout(this,4);LinearLayout sh=new LinearLayout(this);sh.setGravity(Gravity.CENTER_VERTICAL);sh.addView(UiKit.sectionTitle(this,"🏪 فروشندگان و سرویس‌دهندگان"),new LinearLayout.LayoutParams(0,-2,1f));Button sp=UiKit.addIconButton(this);sp.setOnClickListener(v->editSeller(null));sh.addView(sp,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));sellers.addView(sh);sellers.addView(UiKit.muted(this,"برای ساخت مورد جدید فقط از + بالای همین لیست استفاده کن."),UiKit.matchWrap(this,4,8));sellersBox=new LinearLayout(this);sellersBox.setOrientation(LinearLayout.VERTICAL);sellers.addView(sellersBox);root.addView(sellers,UiKit.matchWrap(this,0,12));
        LinearLayout cards=UiKit.colorfulCardLayout(this,1);LinearLayout ch=new LinearLayout(this);ch.setGravity(Gravity.CENTER_VERTICAL);ch.addView(UiKit.sectionTitle(this,"🏦 بانک‌ها و کارت‌ها"),new LinearLayout.LayoutParams(0,-2,1f));Button cp=UiKit.addIconButton(this);cp.setOnClickListener(v->editCard(null));ch.addView(cp,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));cards.addView(ch);cards.addView(UiKit.muted(this,"نام صاحب کارت و شماره کامل کارت مقصد به‌صورت رمزگذاری‌شده در همین دستگاه ذخیره می‌شوند. رمز دوم و CVV2 را وارد نکنید."),UiKit.matchWrap(this,4,8));cardsBox=new LinearLayout(this);cardsBox.setOrientation(LinearLayout.VERTICAL);cards.addView(cardsBox);root.addView(cards,UiKit.matchWrap(this,0,12));setContentView(sc);render();
    }
    private EditText field(String h){return UiKit.styleField(this,new EditText(this),h);}
    private void render(){
        sellersBox.removeAllViews();List<NexaStore.ShoppingSeller> ss=NexaStore.sellers(this);if(ss.isEmpty())sellersBox.addView(UiKit.muted(this,"هنوز موردی ثبت نشده."));
        for(NexaStore.ShoppingSeller s:ss){LinearLayout c=UiKit.cardLayout(this);c.addView(UiKit.sectionTitle(this,s.name));String meta=(s.category==null||s.category.isEmpty()?"عمومی":s.category)+(s.phone.isEmpty()?"":" • "+s.phone);c.addView(UiKit.muted(this,meta));if(!s.address.isEmpty())c.addView(UiKit.muted(this,s.address));int purchases=NexaStore.purchasesForSeller(this,s.id).size(),bills=NexaStore.billsForSeller(this,s.id).size();c.addView(UiKit.muted(this,"سابقه: "+purchases+" خرید • "+bills+" پرداخت/سررسید"),UiKit.matchWrap(this,4,4));LinearLayout a=new LinearLayout(this);Button history=UiKit.secondaryButton(this,"سابقه");history.setOnClickListener(v->showSellerHistory(s));a.addView(history,new LinearLayout.LayoutParams(0,-2,1f));Button e=UiKit.editIconButton(this);e.setOnClickListener(v->editSeller(s));a.addView(e,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));Button d=UiKit.deleteIconButton(this);d.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف فروشنده؟").setMessage("رکوردهای قبلی حذف نمی‌شوند، اما اتصالشان به دفتر مشترک باقی می‌ماند تا تاریخچه از بین نرود.").setPositiveButton("حذف از دفتر",(x,w)->{NexaStore.removeSeller(this,s.id);render();}).setNegativeButton("انصراف",null).show());a.addView(d,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));c.addView(a,UiKit.matchWrap(this,7,0));sellersBox.addView(c,UiKit.matchWrap(this,0,7));}
        cardsBox.removeAllViews();List<NexaStore.BankCard> cs=NexaStore.bankCards(this);if(cs.isEmpty())cardsBox.addView(UiKit.muted(this,"هنوز کارتی ثبت نشده."));for(NexaStore.BankCard c:cs){LinearLayout row=UiKit.cardLayout(this);row.addView(UiKit.sectionTitle(this,c.display()));row.addView(UiKit.muted(this,PaymentCardSecrets.masked(this,c.id)));LinearLayout a=new LinearLayout(this);Button copy=UiKit.iconButton(this,"⧉","کپی شماره کارت",UiKit.GOLD);copy.setOnClickListener(v->Toast.makeText(this,PaymentCardSecrets.copy(this,c.id)?"شماره کارت کپی شد":"شماره کامل این کارت ثبت نشده",Toast.LENGTH_SHORT).show());a.addView(copy,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));Button e=UiKit.editIconButton(this);e.setOnClickListener(v->editCard(c));a.addView(e,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));Button d=UiKit.deleteIconButton(this);d.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف کارت؟").setMessage(c.display()).setPositiveButton("حذف",(x,w)->{NexaStore.removeBankCard(this,c.id);render();}).setNegativeButton("انصراف",null).show());a.addView(d,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));row.addView(a);cardsBox.addView(row,UiKit.matchWrap(this,0,7));}
    }
    private void editSeller(NexaStore.ShoppingSeller existing){LinearLayout box=UiKit.dialogPanel(this);EditText name=field("نام فروشنده / سرویس‌دهنده");EditText category=field("دسته؛ مثلاً فروشگاه، تعمیرگاه، پزشک");EditText phone=field("تلفن");EditText address=field("آدرس");EditText note=field("توضیحات");phone.setInputType(InputType.TYPE_CLASS_PHONE);if(existing!=null){name.setText(existing.name);category.setText(existing.category);phone.setText(existing.phone);address.setText(existing.address);note.setText(existing.note);}box.addView(name);box.addView(category);box.addView(phone);box.addView(address);box.addView(note);AlertDialog editor=new AlertDialog.Builder(this).setTitle(existing==null?"فروشنده جدید":"ویرایش فروشنده").setView(box).setPositiveButton("ذخیره",null).setNegativeButton("انصراف",null).create();
        editor.setOnShowListener(dialog->editor.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("نام را وارد کن");name.requestFocus();return;}NexaStore.ShoppingSeller s=existing==null?new NexaStore.ShoppingSeller():existing;s.name=n;s.category=category.getText().toString().trim().isEmpty()?"عمومی":category.getText().toString().trim();s.phone=phone.getText().toString().trim();s.address=address.getText().toString().trim();s.note=note.getText().toString().trim();NexaStore.upsertSeller(this,s);editor.dismiss();Toast.makeText(this,"ذخیره شد.",Toast.LENGTH_SHORT).show();render();}));
        editor.show();}
    private void editCard(NexaStore.BankCard existing){
        PaymentCardEditor.show(this,existing,saved->render());
    }
    private void showSellerHistory(NexaStore.ShoppingSeller s){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,s.name));for(NexaStore.ShoppingItem x:NexaStore.purchasesForSeller(this,s.id))box.addView(UiKit.muted(this,"🛒 "+PersianDateUtil.pretty(x.purchasedAt)+" • "+x.name+" • "+NumberFormatUtil.grouped(x.price)+" تومان"),UiKit.matchWrap(this,3,3));for(NexaStore.BillItem x:NexaStore.billsForSeller(this,s.id))box.addView(UiKit.muted(this,"💳 "+PersianDateUtil.pretty(x.dueDate)+" • "+x.title+" • "+NumberFormatUtil.grouped(x.amount)+" تومان"),UiKit.matchWrap(this,3,3));new AlertDialog.Builder(this).setTitle("تاریخچه فروشنده").setView(box).setPositiveButton("بستن",null).show();}
}
