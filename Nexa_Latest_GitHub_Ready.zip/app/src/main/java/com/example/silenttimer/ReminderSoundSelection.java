package com.example.silenttimer;

import android.content.Context;
import android.database.Cursor;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.provider.OpenableColumns;

/** Per-reminder audio override; empty string inherits the global reminder profile. */
public final class ReminderSoundSelection {
    private ReminderSoundSelection(){}

    /** Never store file:// or arbitrary remote streams in a reminder. */
    public static String normalize(String raw){
        if(raw==null || raw.trim().isEmpty())return "";
        try{
            Uri u=Uri.parse(raw.trim());
            return AlarmSoundSelection.isSupportedUri(u)?u.toString():"";
        }catch(Exception e){return "";}
    }

    public static Uri selected(String raw){
        String normalized=normalize(raw);
        return normalized.isEmpty()?null:Uri.parse(normalized);
    }

    /** Missing SD card or revoked SAF access => inherit configured reminder sound. */
    public static Uri usable(Context c,String raw){
        Uri uri=selected(raw);
        return uri!=null && AlarmSoundSelection.isReadable(c,uri)?uri:null;
    }

    public static String displayName(Context c,String raw){
        Uri uri=selected(raw);
        if(uri==null)return "صدای عمومی یادآورها";
        if(!AlarmSoundSelection.isReadable(c,uri))
            return "فایل در دسترس نیست؛ صدای عمومی پخش می‌شود";
        try{
            Ringtone ringtone=RingtoneManager.getRingtone(c,uri);
            if(ringtone!=null){
                String title=ringtone.getTitle(c);
                if(title!=null&&!title.trim().isEmpty())return title.trim();
            }
        }catch(Exception ignored){}
        try(Cursor cursor=c.getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(cursor!=null&&cursor.moveToFirst()){
                String title=cursor.getString(0);
                if(title!=null&&!title.trim().isEmpty())return title.trim();
            }
        }catch(Exception ignored){}
        return "صدای اختصاصی یادآور";
    }
}
