package com.example.silenttimer;

import java.util.ArrayList;
import java.util.List;

/** Stateless, read-only export of an explicitly selected shopping or todo list. */
public final class ListShareExport {
    private ListShareExport() {}

    public static final class Entry {
        public final String title;
        public final String detail;
        public final String category;
        public final boolean done;
        public final boolean important;

        public Entry(String title, String detail, String category, boolean done, boolean important) {
            this.title = title;
            this.detail = detail;
            this.category = category;
            this.done = done;
            this.important = important;
        }
    }

    public static List<Entry> select(List<Entry> entries, boolean includeDone) {
        List<Entry> picked = new ArrayList<>();
        if (entries == null) return picked;
        for (Entry e : entries) {
            if (e != null && !e.done && !plain(e.title).isEmpty()) picked.add(e);
            else if (e != null && includeDone && !plain(e.title).isEmpty()) picked.add(e);
        }
        return picked;
    }

    /** One-line normalization keeps arbitrary user names from forging additional entries. */
    static String plain(String s) {
        if (s == null) return "";
        StringBuilder out = new StringBuilder();
        boolean space = false;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            int type = Character.getType(c);
            if (Character.isISOControl(c) || type == Character.FORMAT || Character.isWhitespace(c)) {
                if (out.length() > 0) space = true;
            } else {
                if (space) out.append(' ');
                out.append(c);
                space = false;
            }
        }
        return out.toString().trim();
    }

    public static String text(String heading, List<Entry> entries, boolean includeDone, boolean todo) {
        List<Entry> picked = select(entries, includeDone);
        StringBuilder s = new StringBuilder();
        s.append(todo ? "✓ کارهای روزانه" : "🛒 لیست خرید").append(" • ").append(plain(heading));
        s.append("\n").append("تعداد: ").append(faDigits(picked.size())).append("\n");
        for (int i = 0; i < picked.size(); i++) {
            Entry e = picked.get(i);
            s.append(faDigits(i + 1)).append(". ").append(e.done ? "☑ " : "☐ ");
            if (e.important) s.append("⭐ ");
            s.append(plain(e.title));
            if (!plain(e.detail).isEmpty()) s.append(" — ").append(plain(e.detail));
            if (!plain(e.category).isEmpty()) s.append(" ( ").append(plain(e.category)).append(" )");
            s.append('\n');
        }
        s.append("ارسال‌شده از Nexa");
        return s.toString();
    }

    private static String faDigits(int n) {
        String digits = String.valueOf(n);
        StringBuilder localized = new StringBuilder();
        for (int i = 0; i < digits.length(); i++) {
            char c = digits.charAt(i);
            localized.append(c >= '0' && c <= '9' ? (char) ('۰' + c - '0') : c);
        }
        return localized.toString();
    }

    private static String cell(String s) {
        String safe = plain(s);
        // Excel/Sheets may interpret cells beginning with these characters as formulas.
        if (!safe.isEmpty() && "=+-@".indexOf(safe.charAt(0)) >= 0) safe = "'" + safe;
        return "\"" + safe.replace("\"", "\"\"") + "\"";
    }

    public static String csv(String heading, List<Entry> entries, boolean includeDone, boolean todo) {
        List<Entry> picked = select(entries, includeDone);
        StringBuilder s = new StringBuilder("\ufeff"); // BOM for Persian text in Excel.
        s.append("نوع,فهرست,عنوان,مقدار یا سررسید,دسته,وضعیت,اهمیت\r\n");
        for (Entry e : picked) {
            s.append(cell(todo ? "کار" : "خرید")).append(',');
            s.append(cell(heading)).append(',');
            s.append(cell(e.title)).append(',');
            s.append(cell(e.detail)).append(',');
            s.append(cell(e.category)).append(',');
            s.append(cell(e.done ? "انجام‌شده" : "باقی‌مانده")).append(',');
            s.append(cell(e.important ? "مهم" : "عادی")).append("\r\n");
        }
        return s.toString();
    }
}
