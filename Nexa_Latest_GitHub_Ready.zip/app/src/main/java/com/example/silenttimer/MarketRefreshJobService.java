package com.example.silenttimer;

import android.app.job.JobParameters;
import android.app.job.JobService;

/** JobScheduler worker. Network runs on MarketDataHelper's private thread. */
public final class MarketRefreshJobService extends JobService {
    private volatile boolean stopped;
    @Override public boolean onStartJob(JobParameters params){
        stopped=false;
        if(NexaStore.marketRefreshMode(this)!=2)return false;
        long previous=NexaStore.marketLastAttempt(this);
        long now=System.currentTimeMillis();
        if(previous>0&&now-previous>=0&&now-previous<MarketRefreshScheduler.FOREGROUND_PERIOD_MS)return false;
        try{
            MarketDataHelper.refresh(this,(ok,msg)->{
                if(stopped)return;
                if(ok){AssetMarketEngine.updateOnlineAssets(this);AssetMarketEngine.checkAlerts(this);}
                jobFinished(params,false);
            });
            return true;
        }catch(RuntimeException ex){
            BackgroundReliability.record(this,"market.job",ex);
            return false;
        }
    }
    @Override public boolean onStopJob(JobParameters params){stopped=true;return true;}
}
