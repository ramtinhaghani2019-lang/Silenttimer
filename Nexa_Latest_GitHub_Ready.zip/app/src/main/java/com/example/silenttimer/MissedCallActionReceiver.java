package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

/** Handles user actions from the Nexa missed-call lock-screen notification. */
public class MissedCallActionReceiver extends BroadcastReceiver {
    public static final String ACTION_OPEN_DIALER = "com.example.silenttimer.MISSED_CALL_OPEN_DIALER";
    public static final String ACTION_CLEAR = "com.example.silenttimer.MISSED_CALL_CLEAR";
    public static final String EXTRA_NUMBER = "number";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null) return;
        String action = intent.getAction();
        if (!ACTION_OPEN_DIALER.equals(action) && !ACTION_CLEAR.equals(action)) return;

        MissedCallGuard.resetMissedCount(context);
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

        if (ACTION_OPEN_DIALER.equals(action)) {
            String number = intent.getStringExtra(EXTRA_NUMBER);
            Intent dial = new Intent(Intent.ACTION_DIAL);
            if (number != null && !number.trim().isEmpty()) {
                dial.setData(Uri.fromParts("tel", number.trim(), null));
            }
            dial.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                context.startActivity(dial);
            } catch (Exception ignored) {
            }
        }
    }
}
