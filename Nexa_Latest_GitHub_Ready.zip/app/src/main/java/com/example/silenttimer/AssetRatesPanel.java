package com.example.silenttimer;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Market snapshots shown as distinct, labelled rates; no conversions or persistence. */
final class AssetRatesPanel {
    private AssetRatesPanel(){}

    static void addGroup(Context context,LinearLayout parent,String section,String[] labels,double[] values){
        if(labels==null||values==null||labels.length!=values.length)
            throw new IllegalArgumentException("Invalid rate group");
        TextView heading=UiKit.sectionTitle(context,section);
        heading.setTextSize(14f);
        parent.addView(heading,UiKit.matchWrap(context,8,5));
        final int screenDp=context.getResources().getConfiguration().screenWidthDp;
        final float fontScale=context.getResources().getConfiguration().fontScale;
        final int columns=screenDp>=340&&fontScale<1.35f?2:1;
        final int width=UiKit.dp(context,Math.max(140,screenDp-88));
        final int cell=(width-(columns-1)*UiKit.dp(context,8))/columns;
        GridLayout grid=new GridLayout(context);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        grid.setColumnCount(columns);
        for(int i=0;i<labels.length;i++){
            LinearLayout tile=new LinearLayout(context);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            tile.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            tile.setPadding(UiKit.dp(context,10),UiKit.dp(context,8),UiKit.dp(context,10),UiKit.dp(context,8));
            GradientDrawable surface=UiKit.rounded(context,UiKit.CARD_2,12);
            surface.setStroke(UiKit.dp(context,1),0xFF465B74);
            tile.setBackground(surface);
            TextView label=UiKit.muted(context,labels[i]);
            label.setTextSize(11.5f);label.setMaxLines(1);
            label.setEllipsize(TextUtils.TruncateAt.END);
            tile.addView(label);
            String rate=rateText(values[i]);
            TextView amount=UiKit.title(context,rate);
            amount.setTextSize(16f);
            amount.setTextColor(UiKit.TEXT);
            amount.setMaxLines(1);
            amount.setAutoSizeTextTypeUniformWithConfiguration(11,16,1,TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
            tile.addView(amount,UiKit.matchWrap(context,3,0));
            tile.setContentDescription(labels[i]+"، "+rate);
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();
            lp.width=columns==1?-1:Math.max(UiKit.dp(context,126),cell);
            lp.height=UiKit.dp(context,67);
            lp.setMargins(0,0,(i%columns==columns-1)?0:UiKit.dp(context,8),UiKit.dp(context,8));
            grid.addView(tile,lp);
        }
        parent.addView(grid,UiKit.matchWrap(context,0,0));
    }

    static String rateText(double value){
        return AssetRateFormatter.display(value);
    }
}
