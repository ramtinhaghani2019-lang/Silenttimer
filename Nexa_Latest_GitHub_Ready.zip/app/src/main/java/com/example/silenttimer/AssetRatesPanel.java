package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;

/** Reference-style rate tiles. No conversions or changes to the provider's stored values. */
final class AssetRatesPanel {
    private AssetRatesPanel(){}

    static void addGroup(Context c,LinearLayout parent,String section,String[] labels,double[] values){
        if(labels==null||values==null||labels.length!=values.length)
            throw new IllegalArgumentException("Invalid rate group");
        TextView heading=UiKit.sectionTitle(c,section);
        heading.setTextSize(14f);
        parent.addView(heading,UiKit.matchWrap(c,8,5));
        int width=c.getResources().getConfiguration().screenWidthDp;
        float fontScale=c.getResources().getConfiguration().fontScale;
        int columns=width>=360&&fontScale<1.30f?2:1;
        for(int from=0;from<labels.length;from+=columns){
            LinearLayout row=new LinearLayout(c);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            row.setOrientation(LinearLayout.HORIZONTAL);
            for(int i=from;i<Math.min(labels.length,from+columns);i++){
                LinearLayout tile=new LinearLayout(c);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                tile.setPadding(UiKit.dp(c,12),UiKit.dp(c,9),UiKit.dp(c,12),UiKit.dp(c,9));
                GradientDrawable surface=UiKit.rounded(c,UiKit.CARD_2,12);
                surface.setStroke(UiKit.dp(c,1),0xFF465B74);
                tile.setBackground(surface);
                LinearLayout line=new LinearLayout(c);
                line.setGravity(Gravity.CENTER_VERTICAL);
                line.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                NexaOutlineIcon icon=new NexaOutlineIcon(c,AssetVisualPolicy.iconFor(labels[i]),UiKit.GOLD);
                line.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(c,24),UiKit.dp(c,24)));
                TextView label=UiKit.muted(c,labels[i]);
                label.setTextSize(12f);label.setMaxLines(2);
                label.setEllipsize(TextUtils.TruncateAt.END);
                LinearLayout.LayoutParams llp=new LinearLayout.LayoutParams(0,-2,1f);
                llp.rightMargin=UiKit.dp(c,7);line.addView(label,llp);
                tile.addView(line);
                String rate=rateText(values[i]);
                TextView amount=UiKit.title(c,rate);
                amount.setTextSize(17f);amount.setMaxLines(3);
                amount.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_SIMPLE);
                amount.setAutoSizeTextTypeUniformWithConfiguration(12,17,1,TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
                tile.addView(amount,UiKit.matchWrap(c,7,0));
                tile.setContentDescription(labels[i]+"، "+rate);
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
                lp.bottomMargin=UiKit.dp(c,8);
                if(i>from)lp.rightMargin=UiKit.dp(c,8);
                row.addView(tile,lp);
            }
            // Incomplete rows stretch to the full available width, never half-empty.
            parent.addView(row,UiKit.matchWrap(c,0,0));
        }
    }
    static String rateText(double value){return AssetRateFormatter.display(value);}
}
