package com.example.silenttimer;

import android.app.Activity;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** One authoritative map of the original Nexa destinations. No data or permissions are changed. */
final class ModulesCatalog {
    private ModulesCatalog(){}
    static final String[] GROUPS={"همه","مالی و اسناد","زندگی و سلامت","هشدار و زمان‌بندی","ابزارها و مدیریت"};
    static final class Item {
        final String title,aliases,mark;final int group;final Class<? extends Activity> destination;
        Item(String title,String aliases,String mark,int group,Class<? extends Activity> destination){
            this.title=title;this.aliases=aliases;this.mark=mark;this.group=group;this.destination=destination;
        }
    }
    static final Item[] ALL={
        new Item("دارایی‌ها","اموال سرمایه سرمایه گذاری طلا سکه خرید فروش","📈",1,AssetsActivity.class),
        new Item("حسابداری","بدهی طلب پرداخت دریافت دفتر حساب","💳",1,LedgerActivity.class),
        new Item("قبوض و اقساط","قسط پرداخت قبض سررسید وام","💳",1,BillsActivity.class),
        new Item("اسناد و مدارک","مدرک سند گواهینامه انقضا","📄",1,DocsActivity.class),
        new Item("دفتر مشترک","فروشنده بانک مخاطب کارت گیرنده","📄",1,SharedEntitiesActivity.class),
        new Item("دارو و سلامت","دارو پزشکی سلامت دوز مصرف","💊",2,MedicineActivity.class),
        new Item("سرویس خودرو","ماشین اتومبیل تعمیر کیلومتر سوخت","🚗",2,GarageActivity.class),
        new Item("سرویس خانه","منزل تعمیرات نگهداری","🏠",2,HomeCareActivity.class),
        new Item("پرونده‌ها","پرونده حقوقی وکیل دادگاه","⚖️",2,CaseActivity.class),
        new Item("هواشناسی","آب هوا پیش بینی","◈",2,WeatherActivity.class),
        new Item("یادآورها","هشدار برنامه تکرار","📅",3,RemindersActivity.class),
        new Item("مناسبت‌ها","تولد سالگرد ازدواج مراسم","🎂",3,AnnualOccasionsActivity.class),
        new Item("سایلنت و تمرکز","سکوت زمان بندی تماس مجاز","◷",3,SilentHubActivity.class),
        new Item("باتری و شارژ","آلارم هشدار جدا کردن شارژر","◈",3,BatteryGuardActivity.class),
        new Item("اضطراری","کمک فوری تماس اضطراری","◈",3,EmergencyActivity.class),
        new Item("امنیت و حریم خصوصی","قفل رمز صندوق امن","◈",4,VaultActivity.class),
        new Item("فایل‌ها و فاکتورها","پیوست سند فاکتور فایل عکس","📄",4,FileCenterActivity.class),
        new Item("جست‌وجوی سراسری","پیدا کردن جستجو","⌕",4,SearchActivity.class),
        new Item("خط زمانی","تقویم برنامه روز","📅",4,TimelineActivity.class),
        new Item("تاریخچه","سوابق فعالیت گزارش","📄",4,HistoryActivity.class),
        new Item("تنظیمات","پیکربندی دسترسی اعلان صدا","◈",4,SettingsActivity.class),
        new Item("کارها و فهرست‌ها","خرید لیست انجام دادنی","🛒",4,NexaListActivity.class)
    };
    static List<Item> filter(String query,int group){
        List<Item> result=new ArrayList<>();
        for(Item item:ALL)if((group==0||group==item.group)
            && FeatureSearch.matches(item.title,item.aliases,GROUPS[item.group],query))result.add(item);
        return Collections.unmodifiableList(result);
    }
}
