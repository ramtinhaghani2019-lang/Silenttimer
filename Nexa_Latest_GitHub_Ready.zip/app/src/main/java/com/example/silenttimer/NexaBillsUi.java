package com.example.silenttimer;

import android.content.Context;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Compact visual summary, with no storage mutation or reminder side effects. */
final class NexaBillsUi {
    private NexaBillsUi() { }

    static HorizontalScrollView metrics(Context c, int overdue, int soon, int paid) {
        HorizontalScrollView scroll = new HorizontalScrollView(c);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addMetric(c,row,"سررسید معوق",overdue,UiKit.RED);
        addMetric(c,row,"تا ۷ روز آینده",soon,UiKit.GOLD);
        addMetric(c,row,"پرداخت‌شده",paid,UiKit.GREEN);
        scroll.addView(row);
        scroll.setContentDescription("خلاصه قبوض و اقساط: "+overdue+" معوق، "+soon+
                " سررسید در هفت روز آینده، "+paid+" پرداخت‌شده");
        return scroll;
    }

    private static void addMetric(Context c, LinearLayout row, String label, int value, int color) {
        LinearLayout item=UiKit.financialMetric(c,label,String.valueOf(value),color);
        item.setMinimumHeight(UiKit.dp(c,84));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(UiKit.dp(c,140),-2);
        lp.setMargins(UiKit.dp(c,2),0,UiKit.dp(c,6),0);
        row.addView(item,lp);
    }

    static TextView status(Context c, boolean paid, boolean overdue, boolean soon) {
        String title=paid?"✓ پرداخت‌شده":overdue?"● معوق":soon?"◷ نزدیک سررسید":"◷ در انتظار";
        int tint=paid?UiKit.GREEN:overdue?UiKit.RED:soon?UiKit.GOLD:UiKit.BLUE;
        TextView badge=UiKit.statusBadge(c,title,tint);
        badge.setContentDescription(paid?"پرداخت‌شده":overdue?"سررسید معوق":soon?
                "سررسید در هفت روز آینده":"سررسید آینده");
        return badge;
    }
}
