package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;

/** PIN replacement requires knowledge of old PIN; biometric switches cannot disable it silently. */
public class SecurityActivity extends Activity {
    private EditText entry(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);e.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setBackground(UiKit.field(this));e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));return e;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,30));
        root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));
        root.addView(UiKit.title(this,"🔐 امنیت Nexa"),UiKit.matchWrap(this,0,12));root.addView(UiKit.featureHero(this,"security","مرکز امنیت","قفل برنامه • حریم خصوصی • کنترل دسترسی"),UiKit.matchWrap(this,0,14));
        LinearLayout card=UiKit.colorfulCardLayout(this,3);root.addView(card,UiKit.matchWrap(this,0,14));
        card.addView(UiKit.sectionTitle(this,"PIN و اثر انگشت"));
        boolean existing=NexaStore.pinConfigured(this);
        EditText old=entry("PIN فعلی (برای تغییرات امنیتی)");
        EditText pin=entry(existing?"PIN جدید (در صورت تمایل به تغییر)":"PIN جدید ۴ تا ۶ رقمی");
        if(existing)card.addView(old,UiKit.matchWrap(this,10,8));
        card.addView(pin,UiKit.matchWrap(this,10,8));
        Switch lock=UiKit.styledSwitch(this);lock.setText("قفل عمومی برنامه");lock.setTextColor(UiKit.TEXT);
        lock.setChecked(NexaStore.lockEnabled(this));card.addView(lock);
        Switch bio=UiKit.styledSwitch(this);bio.setText("استفاده از اثر انگشت");bio.setTextColor(UiKit.TEXT);
        bio.setChecked(NexaStore.biometricEnabled(this));card.addView(bio);
        card.addView(UiKit.muted(this,"صندوق امن همیشه باید PIN فعال داشته باشد. عوض‌کردن PIN اطلاعات رمزگذاری‌شده را پاک نمی‌کند."),UiKit.matchWrap(this,8,10));
        card.addView(UiKit.muted(this,"قفل خودکار بخش‌های حساس"),UiKit.matchWrap(this,8,4));
        Spinner timeout=UiKit.styledSpinner(this);String[] timeoutLabels={"۱ دقیقه","۵ دقیقه","۱۰ دقیقه","۳۰ دقیقه"};int[] timeoutVals={1,5,10,30};ArrayAdapter<String> ta=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,timeoutLabels);timeout.setAdapter(ta);int current=NexaStore.securityAutoLockMinutes(this),sel=1;for(int i=0;i<timeoutVals.length;i++)if(timeoutVals[i]==current)sel=i;timeout.setSelection(sel);card.addView(timeout,UiKit.matchWrap(this,0,8));
        Switch bg=UiKit.styledSwitch(this);bg.setText("Vault با رفتن به پس‌زمینه دوباره قفل شود");bg.setTextColor(UiKit.TEXT);bg.setChecked(NexaStore.vaultLockOnBackground(this));card.addView(bg);
        Button recovery=UiKit.secondaryButton(this,NexaStore.recoveryCodeConfigured(this)?"🔁 ساخت Recovery Code جدید":"🧩 ساخت Recovery Code");recovery.setOnClickListener(v->{String code=RecoveryCodeUtil.generate();NexaStore.setRecoveryCode(this,code);ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);new AlertDialog.Builder(this).setTitle("Recovery Code — فقط همین یک‌بار").setMessage(code+"\n\nاین کد را بیرون از گوشی در جای امن نگه دار. Nexa فقط نسخه هش‌شده را ذخیره می‌کند.").setPositiveButton("کپی",(d,w)->{cm.setPrimaryClip(ClipData.newPlainText("Nexa Recovery Code",code));Toast.makeText(this,"کد کپی شد.",Toast.LENGTH_SHORT).show();}).setNegativeButton("بستن",null).show();});card.addView(recovery,UiKit.matchWrap(this,6,10));
        Button save=UiKit.primaryButton(this,"ذخیره تنظیمات امنیتی");
        save.setOnClickListener(v->{
            String newPin=pin.getText().toString();
            if(existing&&!NexaStore.verifyPin(this,old.getText().toString())){
                Toast.makeText(this,"برای تغییر تنظیمات، PIN فعلی را وارد کن.",Toast.LENGTH_LONG).show();return;}
            if(!newPin.isEmpty()&&!newPin.matches("[0-9]{4,6}")){
                Toast.makeText(this,"PIN باید ۴ تا ۶ رقم باشد.",Toast.LENGTH_LONG).show();return;}
            if(!existing&&newPin.isEmpty()){
                Toast.makeText(this,"ابتدا PIN تعیین کن.",Toast.LENGTH_LONG).show();return;}
            if(!newPin.isEmpty())NexaStore.setPin(this,newPin);
            NexaStore.setLockEnabled(this,lock.isChecked());
            NexaStore.setSecurityAutoLockMinutes(this,timeoutVals[timeout.getSelectedItemPosition()]);
            NexaStore.setVaultLockOnBackground(this,bg.isChecked());
            NexaStore.setBiometricEnabled(this,bio.isChecked());
            SecurityGate.lock();Toast.makeText(this,"تنظیمات امنیتی ذخیره شد.",Toast.LENGTH_LONG).show();finish();
        });card.addView(save,UiKit.matchWrap(this,8,0));setContentView(sc);
    }
}
