package com.example.silenttimer;

import android.content.Context;
import android.media.MediaPlayer;

/**
 * Backward-compatible facade for alarm sound callers.
 * Build 55 routes all behavior through {@link NexaAudioController}.
 */
public final class AlarmSoundPlayer {
    private AlarmSoundPlayer() {}

    public static MediaPlayer start(Context context) {
        return NexaAudioController.startAlarm(
                context,
                "legacy-alarm",
                NexaAudioController.PRIORITY_NORMAL);
    }

    public static MediaPlayer start(Context context, String owner, int priority) {
        return NexaAudioController.startAlarm(context, owner, priority);
    }

    public static void stop(MediaPlayer player) {
        NexaAudioController.stopAlarm(player);
    }

    public static void stopAll() {
        NexaAudioController.stopAll();
    }
}
