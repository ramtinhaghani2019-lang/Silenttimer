package com.example.silenttimer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** One PendingIntent per event+lead offset, overwritten when the year's due changes. */
public final class OccasionScheduler {
    private OccasionScheduler(){}
    private static final int[] OFFSETS={0,1,3,7};
    static String token(String id,int days){return "nexa:occasion:"+id+":"+days;}
    private static PendingIntent intent(Context c,OccasionStore.Occasion e,int days,int flags,long date){
        Intent i=new Intent(c,OccasionAlarmReceiver.class);
        i.setAction(token(e.id,days));i.putExtra("id",e.id);i.putExtra("lead",days);i.putExtra("eventAt",date);
        return PendingIntent.getBroadcast(c,token(e.id,days).hashCode(),i,flags|PendingIntent.FLAG_IMMUTABLE);
    }
    static boolean selected(OccasionStore.Occasion e,int days){
        return days==0 || days==1&&e.oneDay || days==3&&e.threeDays || days==7&&e.sevenDays;
    }
    public static void cancel(Context c,OccasionStore.Occasion e){
        if(e==null)return;
        AlarmManager mgr=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        for(int days:OFFSETS){
            PendingIntent pi=intent(c,e,days,PendingIntent.FLAG_NO_CREATE,0);
            if(pi!=null){if(mgr!=null)mgr.cancel(pi);pi.cancel();}
            NexaAudioController.stopOwner(token(e.id,days));
        }
    }
    public static void schedule(Context c,OccasionStore.Occasion e){
        scheduleAfter(c,e,System.currentTimeMillis());
    }
    public static void scheduleAfter(Context c,OccasionStore.Occasion e,long after){
        if(e==null)return;
        cancel(c,e);
        if(!e.active)return;
        long now=System.currentTimeMillis();
        long eventAt=AnnualOccasionDates.next(e,after);
        if(eventAt<=0)return;
        for(int days:OFFSETS){
            if(!selected(e,days))continue;
            long trigger=AnnualOccasionDates.beforeDays(eventAt,days);
            if(trigger<=now)continue;
            PendingIntent pi=intent(c,e,days,PendingIntent.FLAG_UPDATE_CURRENT,eventAt);
            ReminderScheduler.setAlarm(c,trigger,pi);
        }
    }
    public static void scheduleAll(Context c){for(OccasionStore.Occasion e:OccasionStore.all(c))schedule(c,e);}
}
