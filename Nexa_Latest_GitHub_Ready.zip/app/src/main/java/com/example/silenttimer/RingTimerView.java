package com.example.silenttimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public class RingTimerView extends View {
    private final Paint basePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint progressPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float progress = 0f;
    private int accent = 0xFF8B5CF6;
    private int muted = 0x33222222;

    public RingTimerView(Context context) {
        super(context);
        basePaint.setStyle(Paint.Style.STROKE);
        progressPaint.setStyle(Paint.Style.STROKE);
        basePaint.setStrokeCap(Paint.Cap.ROUND);
        progressPaint.setStrokeCap(Paint.Cap.ROUND);
    }

    public void setProgress(float value) {
        progress = Math.max(0f, Math.min(1f, value));
        invalidate();
    }

    public void setColors(int accentColor, int baseColor) {
        accent = accentColor;
        muted = baseColor;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float stroke = UiKit.dp(getContext(), 11);
        float pad = stroke / 2f + UiKit.dp(getContext(), 3);

        basePaint.setStrokeWidth(stroke);
        progressPaint.setStrokeWidth(stroke);

        basePaint.setColor(muted);
        progressPaint.setColor(accent);

        RectF rect = new RectF(
                pad,
                pad,
                getWidth() - pad,
                getHeight() - pad
        );

        canvas.drawArc(rect, -90f, 360f, false, basePaint);

        if (progress > 0f) {
            canvas.drawArc(
                    rect,
                    -90f,
                    360f * progress,
                    false,
                    progressPaint
            );
        }
    }
}
