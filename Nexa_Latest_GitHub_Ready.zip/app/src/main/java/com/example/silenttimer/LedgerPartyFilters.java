package com.example.silenttimer;

/** Balance filters used only for the visible party list. Ledger accounting never changes. */
final class LedgerPartyFilters {
    private LedgerPartyFilters() {}
    static boolean valid(String mode) {
        return "all".equals(mode)||"receivable".equals(mode)||"debt".equals(mode)||"settled".equals(mode);
    }
    static boolean matches(String mode,long balance) {
        if("receivable".equals(mode))return balance>0;
        if("debt".equals(mode))return balance<0;
        if("settled".equals(mode))return balance==0;
        return true;
    }
}
