package com.example.silenttimer;

import android.app.*;import android.content.*;import android.os.Build;

public class WeatherAlertReceiver extends BroadcastReceiver{
    private static final String PREF="nexa_weather_alert"; private static final String ENABLED="enabled", LAST="last_signature"; private static final int REQ=8812, ID=8813;
    public void onReceive(Context c,Intent i){
        if(!isEnabled(c))return;
        final String city=WeatherRepository.savedCity(c).trim();
        if(city.isEmpty())return; // Never geocode an empty saved location.
        final PendingResult pr=goAsync();
        WeatherRepository.fetch(c,city,(d,e)->{
            try {
                // A delayed background response must not alert for a different city or after disabling alerts.
                if(shouldNotifyForSelection(isEnabled(c),WeatherRepository.savedCity(c),d))checkAndNotify(c,d);
            } finally {
                if(isEnabled(c))schedule(c);
                pr.finish();
            }
        });
    }
    public static boolean shouldNotifyForSelection(boolean enabled,String selectedCity,WeatherRepository.Data result){
        return enabled && selectedCity!=null && !selectedCity.trim().isEmpty()
                && WeatherRepository.matchesCity(result,selectedCity)
                && WeatherRepository.usableCache(result,System.currentTimeMillis());
    }
    static void checkAndNotify(Context c,WeatherRepository.Data d){boolean rain=(d.code>=51&&d.code<=67)||(d.code>=80&&d.code<=82)||d.code>=95;boolean snow=d.code>=71&&d.code<=77;boolean likely=d.precip>=55;if(!rain&&!snow&&!likely)return;String type=snow?"برف":rain?"بارش":"احتمال بارش";String sig=d.city+":"+type+":"+(d.precip/10);String old=c.getSharedPreferences(PREF,0).getString(LAST,"");if(sig.equals(old))return;c.getSharedPreferences(PREF,0).edit().putString(LAST,sig).apply();NotificationChannelHelper.ensureCoreChannels(c);Intent open=new Intent(c,WeatherActivity.class);PendingIntent pi=PendingIntent.getActivity(c,ID,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);String text=d.city+" • "+type+" • احتمال بارش "+d.precip+"٪";Notification n=new Notification.Builder(c,NotificationChannelHelper.CHANNEL_WEATHER).setSmallIcon(R.drawable.app_icon).setContentTitle("☔ هشدار هواشناسی Nexa").setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PUBLIC).setContentIntent(pi).build();NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.notify(ID,n);}
    public static boolean isEnabled(Context c){return c.getSharedPreferences(PREF,0).getBoolean(ENABLED,false);} public static void setEnabled(Context c,boolean v){c.getSharedPreferences(PREF,0).edit().putBoolean(ENABLED,v).apply();}
    private static PendingIntent pending(Context c){return PendingIntent.getBroadcast(c,REQ,new Intent(c,WeatherAlertReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
    public static void schedule(Context c){if(!isEnabled(c))return;AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.setInexactRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+15*60*1000L,30*60*1000L,pending(c));}
    public static void cancel(Context c){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pending(c));c.getSharedPreferences(PREF,0).edit().remove(LAST).apply();}
}
