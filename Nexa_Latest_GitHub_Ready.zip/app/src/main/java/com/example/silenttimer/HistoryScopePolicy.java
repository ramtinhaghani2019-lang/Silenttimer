package com.example.silenttimer;

import java.util.Locale;

/** Pure logic for recent activity scope; no personal record is copied or persisted. */
public final class HistoryScopePolicy {
    public static final String ALL="all", TODAY="today", WEEK="week";
    private HistoryScopePolicy(){}
    public static boolean inWindow(String scope,long timestamp,long now){
        if(ALL.equals(scope))return true;
        long window=TODAY.equals(scope)?86_400_000L:WEEK.equals(scope)?604_800_000L:-1L;
        return window>=0 && timestamp<=now && timestamp>=now-window;
    }
    public static boolean matches(String scope,long time,long now,String type,String description,String query){
        if(!inWindow(scope,time,now))return false;
        String q=query==null?"":query.trim().toLowerCase(Locale.ROOT);
        return q.isEmpty()||((type==null?"":type)+" "+(description==null?"":description)).toLowerCase(Locale.ROOT).contains(q);
    }
}
