package com.example.silenttimer;

/** Presentation-only portfolio filtering. Never alters AssetFinanceEngine or stored assets. */
final class AssetOverviewPolicy {
    static final int ALL=0, GAIN=1, LOSS=2, ALERT=3;
    private AssetOverviewPolicy() {}
    static boolean matches(int filter,double openCost,double marketValue,boolean hasPriceAlert){
        if(filter==GAIN)return marketValue>openCost;
        if(filter==LOSS)return marketValue<openCost;
        if(filter==ALERT)return hasPriceAlert;
        return true;
    }
}
