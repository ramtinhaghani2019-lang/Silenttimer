package com.example.silenttimer;

/** Visual settings navigation only; does not persist or modify any settings. */
public final class SettingsDirectory {
    private SettingsDirectory() {}
    public static String aliases(String title) {
        String t = FeatureSearch.normalize(title);
        if (t.contains("حساب کاربری")) return "نام پروفایل مشخصات ورود";
        if (t.contains("ارسال ایمیل")) return "ایمیل بازیابی کد تایید supabase";
        if (t.contains("صندوق امن")) return "vault رمز صندوق بازیابی backup";
        if (t.contains("راه اندازی دسترسی")) return "مجوز راه اندازی نصب اجازه";
        if (t.contains("وضعیت دسترسی")) return "مجوز آلارم باتری نوتیفیکیشن اعلان ها تماس سایلنت";
        if (t.contains("کد اضطراری")) return "sms پیامک شماره مجاز کد سکوت";
        if (t.contains("امنیت و پشتیبان")) return "رمز پین اثر انگشت backup بکاپ ذخیره";
        if (t.contains("صدای هشدار")) return "آهنگ زنگ صدا موسیقی باتری دارو ضدسرقت یادآور سایلنت ولوم";
        if (t.contains("رفتار زنگ")) return "زمان مدت هشدار تکرار ویبره صدا";
        if (t.contains("دفتر مشترک")) return "فروشندگان کارت بانک فایل فاکتور";
        if (t.contains("تشخیص خودکار")) return "silent vibrate سایلنت ویبره سکوت پایش";
        if (t.contains("سازگاری")) return "گوشی سامسونگ اندروید باتری اعلان";
        if (t.contains("درباره")) return "نسخه سازنده اطلاعات تماس";
        return "";
    }
    public static boolean matches(String title, String query) {
        return FeatureSearch.matches(title, aliases(title), "تنظیمات", query);
    }
}
