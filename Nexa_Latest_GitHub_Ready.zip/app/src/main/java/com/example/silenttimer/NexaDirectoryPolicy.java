package com.example.silenttimer;

/** Screen-width and pagination policy shared by search and reminders.
 *  The data set stays intact for exports, sorting and batch actions; only rendered
 *  view counts are limited so large personal archives remain responsive.
 */
public final class NexaDirectoryPolicy {
    public static final int REMINDER_PAGE_SIZE = 12;
    public static final int SEARCH_PAGE_SIZE = 20;
    private NexaDirectoryPolicy() {}

    public static int filterColumns(int widthDp, float fontScale) {
        return widthDp >= 380 && fontScale <= 1.20f ? 3 : 2;
    }
    public static int visibleCount(int total, int limit) {
        return Math.min(Math.max(total,0),Math.max(limit,0));
    }
    public static int nextLimit(int current, int pageSize) {
        if (pageSize <= 0) return current;
        if (current >= Integer.MAX_VALUE - pageSize) return Integer.MAX_VALUE;
        return Math.max(0,current)+pageSize;
    }
    public static int remaining(int total, int limit) {
        return Math.max(0,total-visibleCount(total,limit));
    }
}
