package com.example.silenttimer;

/** Presentation-only ledger rules. Does not alter stored amounts or balance math. */
public final class LedgerPresentation {
    private LedgerPresentation() {}

    public static final String[] KINDS={"DEBT","CREDIT","PAYMENT","RECEIPT"};
    public static final int RED=0xFFFF646A;
    public static final int YELLOW=0xFFF5CD58;
    public static final int GREEN=0xFF4DD998;
    public static final int PURPLE=0xFFC199FC;

    public static int color(String kind) {
        if("DEBT".equals(kind))return RED;
        if("CREDIT".equals(kind))return YELLOW;
        if("PAYMENT".equals(kind))return GREEN;
        if("RECEIPT".equals(kind))return PURPLE;
        return 0xFFB8B8B0;
    }
    public static String shortLabel(String kind) {
        if("DEBT".equals(kind))return "بدهی";
        if("CREDIT".equals(kind))return "طلب";
        if("PAYMENT".equals(kind))return "پرداخت";
        if("RECEIPT".equals(kind))return "دریافت";
        return "نامشخص";
    }
    public static String label(String kind) {
        if("DEBT".equals(kind))return "بدهی جدید";
        if("CREDIT".equals(kind))return "طلب جدید";
        if("PAYMENT".equals(kind))return "پرداخت کردم";
        if("RECEIPT".equals(kind))return "دریافت کردم";
        return "تراکنش نامشخص";
    }
    public static String help(String kind) {
        if("DEBT".equals(kind))return "من به این شخص بدهکارم";
        if("CREDIT".equals(kind))return "این شخص به من بدهکار است";
        if("PAYMENT".equals(kind))return "از طرف من پرداخت شده است";
        if("RECEIPT".equals(kind))return "من از این شخص دریافت کرده‌ام";
        return "نوع تراکنش را انتخاب کنید";
    }
    /** Convert UI digits; numeric storage and CSV exports remain unchanged. */
    public static String persian(String input) {
        if(input==null)return "";
        StringBuilder result=new StringBuilder(input.length());
        for(int i=0;i<input.length();i++) {
            char ch=input.charAt(i);
            if(ch>='0'&&ch<='9')result.append((char)('۰'+ch-'0'));
            else if(ch>='\u0660'&&ch<='\u0669')result.append((char)('۰'+ch-'\u0660'));
            else if(ch==',')result.append('٬');
            else result.append(ch);
        }
        return result.toString();
    }
    /** Reject zero, negative, decimals, or values beyond 64-bit integer range. */
    public static long positiveAmount(String input) {
        if(input==null)return 0;
        StringBuilder digits=new StringBuilder();
        for(int i=0;i<input.length();i++) {
            char ch=input.charAt(i);
            if(ch>='0'&&ch<='9')digits.append(ch);
            else if(ch>='۰'&&ch<='۹')digits.append((char)('0'+ch-'۰'));
            else if(ch>='\u0660'&&ch<='\u0669')digits.append((char)('0'+ch-'\u0660'));
            else if(ch==','||ch=='٬'||ch==' '||ch=='\u00A0'||ch=='\u202F')continue;
            else return 0;
        }
        if(digits.length()==0)return 0;
        try {long value=Long.parseLong(digits.toString());return value>0?value:0;}
        catch(NumberFormatException ex){return 0;}
    }
}
