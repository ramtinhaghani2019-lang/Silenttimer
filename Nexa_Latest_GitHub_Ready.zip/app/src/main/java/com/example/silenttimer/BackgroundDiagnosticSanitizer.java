package com.example.silenttimer;

/** Allowlisted, bounded export of technical error labels only. No message/stack data. */
public final class BackgroundDiagnosticSanitizer {
    private BackgroundDiagnosticSanitizer() {}

    public static String sanitize(String raw) {
        if (raw == null || raw.isEmpty()) return "";
        StringBuilder safe = new StringBuilder();
        int count = 0;
        for (String line : raw.split("\n")) {
            String[] parts = line.split(" \\| ", -1);
            if (parts.length != 3 || !parts[0].matches("[0-9]{1,16}")
                    || !parts[1].matches("[a-zA-Z0-9._-]{1,64}")
                    || !parts[2].matches("[a-zA-Z0-9_$]{1,64}")) continue;
            if (++count > 8) break;
            if (safe.length() > 0) safe.append('\n');
            safe.append(parts[0]).append(" | ").append(parts[1])
                    .append(" | ").append(parts[2]);
        }
        return safe.toString();
    }
}
