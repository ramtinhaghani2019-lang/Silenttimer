package com.example.silenttimer;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

/**
 * Central audio coordinator for Nexa alarm and ringer-mode operations.
 *
 * Build 56 keeps the priority-aware alarm session and also centralizes temporary
 * ringer overrides plus exact restoration of the pre-override ringer mode.
 */
public final class NexaAudioController {
    public static final int PRIORITY_NORMAL = 10;
    public static final int PRIORITY_REMINDER = 40;
    public static final int PRIORITY_MEDICINE = 60;
    public static final int PRIORITY_BATTERY = 70;
    public static final int PRIORITY_SECURITY = 90;
    public static final int PRIORITY_THEFT = 100;

    public static final int SOUND_ALARM = 1;
    public static final int SOUND_REMINDER = 2;
    public static final int SOUND_BATTERY = 3;
    public static final int SOUND_THEFT = 4;
    public static final int SOUND_SILENT_EXIT = 5;
    public static final long SAME_OWNER_DEBOUNCE_MS = 15_000L;

    private static MediaPlayer activePlayer;
    private static AudioManager activeAudioManager;
    private static AudioManager.OnAudioFocusChangeListener activeFocusListener;
    private static android.media.AudioFocusRequest activeFocusRequest;
    private static Vibrator activeVibrator;
    private static int activePriority;
    private static String activeOwner = "";
    private static long activeStartedAt;
    private static long audioSessionGeneration;

    private NexaAudioController() {}

    /**
     * Starts a looping alarm session. A lower-priority request is ignored while
     * a higher-priority Nexa alarm is still playing.
     */
    public static synchronized MediaPlayer startAlarm(
            Context context,
            String owner,
            int priority) {
        if (context == null) return null;

        return startAlarm(context, owner, priority, SOUND_ALARM);
    }

    public static synchronized MediaPlayer startAlarm(
            Context context, String owner, int priority, int soundProfile) {
        if (context == null) return null;
        int normalizedPriority = Math.max(PRIORITY_NORMAL, priority);
        String normalizedOwner = owner == null ? "" : owner;
        if (isActiveLocked() && normalizedOwner.equals(activeOwner)
                && normalizedPriority <= activePriority
                && System.currentTimeMillis() - activeStartedAt < SAME_OWNER_DEBOUNCE_MS) {
            return activePlayer;
        }
        if (isActiveLocked() && normalizedPriority < activePriority) return null;

        // Never interrupt a currently active alarm for a request deferred by a call.
        if (isCallAudioMode(context) && shouldDeferDuringCall(normalizedPriority)) return null;
        stopActiveLocked();
        final long newSessionGeneration = ++audioSessionGeneration;

        MediaPlayer player = null;
        try {
            Uri uri=AlarmSoundSelection.resolve(context,soundProfile);
            if(uri==null)throw new IllegalStateException("No alarm sound");
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build());
            try{
                player.setDataSource(context.getApplicationContext(),uri);
                player.setLooping(true);
                player.prepare();
            }catch(Exception inaccessible){
                player.reset();
                Uri fallback=AlarmSoundSelection.fallback(context,soundProfile);
                if(fallback==null)throw inaccessible;
                player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                player.setDataSource(context.getApplicationContext(),fallback);
                player.setLooping(true);
                player.prepare();
            }
            float gain=AlarmSoundSelection.volumeGain(context,soundProfile);
            player.setVolume(gain,gain);
            if (!requestAlarmFocus(context,normalizedPriority,newSessionGeneration)
                    && normalizedPriority < PRIORITY_SECURITY)
                throw new IllegalStateException("Audio focus unavailable");
            player.start();

            activePlayer = player;
            activePriority = normalizedPriority;
            activeOwner = normalizedOwner;
            activeStartedAt = System.currentTimeMillis();
        } catch (Exception ignored) {
            if (player != null) {
                try { player.release(); } catch (Exception ignored2) {}
            }
            activePlayer = null;
            activePriority = 0;
            activeOwner = "";
            activeStartedAt = 0L;
            abandonAlarmFocus();
        }

        // Never leave an indefinite vibration when audio playback could not start.
        if (activePlayer == null) return null;
        try {
            Vibrator vibrator = (Vibrator) context.getSystemService(Context.VIBRATOR_SERVICE);
            if (AlarmSoundSelection.vibrationEnabled(context,soundProfile)
                    && vibrator != null && vibrator.hasVibrator()) {
                long[] pattern = {0, 700, 350, 700, 600};
                if (Build.VERSION.SDK_INT >= 26) {
                    vibrator.vibrate(VibrationEffect.createWaveform(pattern, 0));
                } else {
                    vibrator.vibrate(pattern, 0);
                }
                activeVibrator = vibrator;
            }
        } catch (Exception ignored) {}

        return activePlayer;
    }

    /** Phone calls take precedence over ordinary reminders, but not security alarms. */
    public static boolean shouldDeferDuringCall(int priority){
        return priority < PRIORITY_SECURITY;
    }

    public static boolean isCallAudioMode(Context context){
        if(context==null)return false;
        try{
            AudioManager manager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(manager==null)return false;
            int mode=manager.getMode();
            return mode==AudioManager.MODE_IN_CALL || mode==AudioManager.MODE_IN_COMMUNICATION;
        }catch(Exception ignored){return false;}
    }

    private static boolean requestAlarmFocus(Context context,int priority,long sessionGeneration){
        try{
            AudioManager manager=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);
            if(manager==null)return true;
            AudioManager.OnAudioFocusChangeListener listener=change->{
                if(change==AudioManager.AUDIOFOCUS_LOSS
                    || change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT){
                    synchronized(NexaAudioController.class){
                        if(activePriority>0 && activePriority<PRIORITY_SECURITY
                            && audioSessionGeneration==sessionGeneration)stopActiveLocked();
                    }
                }
            };
            int granted;
            if(Build.VERSION.SDK_INT>=26){
                android.media.AudioFocusRequest request=
                    new android.media.AudioFocusRequest.Builder(
                        priority>=PRIORITY_SECURITY?AudioManager.AUDIOFOCUS_GAIN:
                            AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                        .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                        .setOnAudioFocusChangeListener(listener).build();
                granted=manager.requestAudioFocus(request);
                if(granted==AudioManager.AUDIOFOCUS_REQUEST_GRANTED)
                    activeFocusRequest=request;
            }else{
                granted=manager.requestAudioFocus(listener,AudioManager.STREAM_ALARM,
                    priority>=PRIORITY_SECURITY?AudioManager.AUDIOFOCUS_GAIN:
                        AudioManager.AUDIOFOCUS_GAIN_TRANSIENT);
            }
            if(granted==AudioManager.AUDIOFOCUS_REQUEST_GRANTED){
                activeAudioManager=manager;
                activeFocusListener=listener;
            }
            return granted==AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
        }catch(Exception ignored){return true;}
    }

    private static void abandonAlarmFocus(){
        AudioManager manager=activeAudioManager;
        AudioManager.OnAudioFocusChangeListener listener=activeFocusListener;
        android.media.AudioFocusRequest request=activeFocusRequest;
        activeAudioManager=null;
        activeFocusListener=null;
        activeFocusRequest=null;
        if(manager==null)return;
        try{
            if(Build.VERSION.SDK_INT>=26 && request!=null)
                manager.abandonAudioFocusRequest(request);
            else if(listener!=null)manager.abandonAudioFocus(listener);
        }catch(Exception ignored){}
    }

    /** Stops a specific session without accidentally stopping a newer session. */
    public static synchronized void stopAlarm(MediaPlayer player) {
        if (player == null) return;
        if (player == activePlayer) {
            stopActiveLocked();
            return;
        }
        try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
        try { player.release(); } catch (Exception ignored) {}
    }

    public static synchronized void stopAll() {
        stopActiveLocked();
    }

    /** Stops only the matching logical alarm owner, preserving unrelated critical alarms. */
    public static synchronized void stopOwner(String owner) {
        String normalized = owner == null ? "" : owner;
        if (normalized.equals(activeOwner)) {
            stopActiveLocked();
        }
    }

    public static synchronized int getActivePriority() {
        return activePriority;
    }

    public static synchronized String getActiveOwner() {
        return activeOwner;
    }

    public static boolean isSupportedRingerMode(int mode) {
        return mode == AudioManager.RINGER_MODE_NORMAL
                || mode == AudioManager.RINGER_MODE_SILENT
                || mode == AudioManager.RINGER_MODE_VIBRATE;
    }

    /** Returns the current supported ringer mode, defaulting safely to NORMAL. */
    public static int getRingerMode(Context context) {
        if (context == null) return AudioManager.RINGER_MODE_NORMAL;
        AudioManager audioManager =
                (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) return AudioManager.RINGER_MODE_NORMAL;
        try {
            int mode = audioManager.getRingerMode();
            return isSupportedRingerMode(mode) ? mode : AudioManager.RINGER_MODE_NORMAL;
        } catch (Exception ignored) {
            return AudioManager.RINGER_MODE_NORMAL;
        }
    }

    /** Single ringer-mode write entry point for Silent and temporary bypass flows. */
    public static boolean setRingerMode(Context context, int mode) {
        if (context == null || !isSupportedRingerMode(mode)) return false;
        AudioManager audioManager =
                (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) return false;
        try {
            audioManager.setRingerMode(mode);
            return true;
        } catch (SecurityException ignored) {
            return false;
        }
    }

    /**
     * Applies a temporary ringer override and returns the exact mode that should
     * later be restored. A negative result means the override could not be applied.
     */
    public static int beginTemporaryOverride(Context context, int targetMode) {
        if (context == null || !isSupportedRingerMode(targetMode)) return -1;
        int previousMode = getRingerMode(context);
        return setRingerMode(context, targetMode) ? previousMode : -1;
    }

    /** Restores a previously captured ringer mode through the same central path. */
    public static boolean restoreRingerMode(Context context, int previousMode) {
        return setRingerMode(context, previousMode);
    }

    private static boolean isActiveLocked() {
        if (activePlayer != null) {
            try {
                if (activePlayer.isPlaying()) return true;
            } catch (Exception ignored) {}
        }
        return activeVibrator != null && activePriority > 0;
    }

    private static void stopActiveLocked() {
        // Invalidate stale asynchronous audio-focus callbacks even if owner IDs repeat.
        ++audioSessionGeneration;
        MediaPlayer player = activePlayer;
        activePlayer = null;
        activePriority = 0;
        activeOwner = "";
        activeStartedAt = 0L;

        if (player != null) {
            try { if (player.isPlaying()) player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
        }

        if (activeVibrator != null) {
            try { activeVibrator.cancel(); } catch (Exception ignored) {}
            activeVibrator = null;
        }
        abandonAlarmFocus();
    }
}
