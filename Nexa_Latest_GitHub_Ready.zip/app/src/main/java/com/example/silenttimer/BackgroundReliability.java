package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

/** A bounded, local-only record of handled background failures. No personal content or stack trace persisted. */
public final class BackgroundReliability {
    private static final String TAG = "NexaBackground";
    private static final String PREF = "nexa_background_diagnostics";
    private static final String KEY = "recent";
    private static final long DEADLINE_MS = 8000L; // Android's broadcast lifetime is short.
    private BackgroundReliability() {}

    public static void record(Context context, String component, RuntimeException error) {
        Log.e(TAG, component, error);
        try {
            String type = error.getClass().getSimpleName();
            String entry = System.currentTimeMillis() + " | " + component + " | " + type;
            SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE);
            String old = prefs.getString(KEY, "");
            String[] lines = old.split("\n");
            StringBuilder out = new StringBuilder(entry);
            int kept = 0;
            for (String line : lines) {
                if (line.isEmpty()) continue;
                // Avoid filling diagnostics with a once-per-second repeated failure.
                if (kept == 0 && line.endsWith(" | " + component + " | " + type)) continue;
                if (++kept > 7) break;
                out.append('\n').append(line);
            }
            prefs.edit().putString(KEY, out.toString()).apply();
        } catch (RuntimeException ignored) { /* Diagnostics must never crash the app. */ }
    }

    public static void run(Context context, String component, Runnable action) {
        try { action.run(); }
        catch (RuntimeException e) { record(context, component, e); }
    }

    public static String recent(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .getString(KEY, "");
    }

    /** Removes only handled-error diagnostics; never touches timers or app data. */
    public static void clear(Context context) {
        context.getApplicationContext().getSharedPreferences(PREF, Context.MODE_PRIVATE)
                .edit().remove(KEY).apply();
    }

    /** Diagnostic export is explicitly initiated by the user. Never include
     * exceptions, messages, stack traces, phone numbers, or saved financial data. */
    public static String shareableReport(Context context) {
        String safe = sanitizeEntries(recent(context));
        return "Nexa " + BuildConfig.VERSION_NAME + " / Build " + BuildConfig.VERSION_CODE
                + "\nAndroid API " + android.os.Build.VERSION.SDK_INT
                + "\nHandled background errors (not a full Android crash log):\n"
                + (safe.isEmpty() ? "none" : safe);
    }

    /** Sanitization is implemented by a pure-Java helper for JVM smoke testing. */
    static String sanitizeEntries(String raw) {
        return BackgroundDiagnosticSanitizer.sanitize(raw);
    }

    /** Always finishes a goAsync broadcast, even if a network callback never arrives. */
    public static final class BroadcastCompletion {
        private final Context context;
        private final String component;
        private final BroadcastReceiver.PendingResult pending;
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final OneShotGate gate = new OneShotGate();
        private final Runnable afterFinish;
        private final Runnable deadline = () -> finish(null);

        public BroadcastCompletion(Context context, String component,
                                   BroadcastReceiver.PendingResult pending, Runnable afterFinish) {
            this.context = context.getApplicationContext();
            this.component = component;
            this.pending = pending;
            this.afterFinish = afterFinish;
            handler.postDelayed(deadline, DEADLINE_MS);
        }

        public void finish(Runnable work) {
            if (!gate.claim()) return;
            handler.removeCallbacks(deadline);
            try {
                if (work != null) run(context, component + ".callback", work);
            } finally {
                try { run(context, component + ".reschedule", afterFinish); }
                finally { pending.finish(); }
            }
        }
    }
}
