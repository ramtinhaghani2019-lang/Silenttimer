package com.example.silenttimer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

/** Offline Persian/English OCR. No image or recognized text is uploaded. */
public final class AssetReceiptOcr {
    private AssetReceiptOcr() {}
    public interface Listener { void onResult(AssetReceiptParser.Result result, String error); }

    public static void read(Context context, Uri uri, Listener callback){
        Context app=context.getApplicationContext();
        new Thread(()->{
            AssetReceiptParser.Result result=null;
            String error=null;
            Bitmap image=null;
            TessBaseAPI tess=null;
            try {
                if(uri==null || !"content".equalsIgnoreCase(uri.getScheme()))
                    throw new IllegalArgumentException("فایل تصویری معتبر انتخاب نشده است.");
                File root=new File(app.getFilesDir(),"receipt_ocr");
                File modelDir=new File(root,"tessdata");
                if(!modelDir.isDirectory()&&!modelDir.mkdirs())
                    throw new IllegalStateException("پوشه OCR ایجاد نشد.");
                copyModel(app,modelDir,"fas.traineddata");
                copyModel(app,modelDir,"eng.traineddata");
                Bitmap decoded=loadBitmap(app,uri);
                if(decoded==null)throw new IllegalArgumentException("تصویر انتخاب‌شده خوانده نشد.");
                image=prepare(decoded);
                if(image!=decoded)decoded.recycle();
                tess=new TessBaseAPI();
                if(!tess.init(root.getAbsolutePath(),"fas+eng"))
                    throw new IllegalStateException("موتور خواندن رسید راه‌اندازی نشد.");
                tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK);
                tess.setImage(image);
                String detected=tess.getUTF8Text();
                result=AssetReceiptParser.parse(detected);
                if(result.recognizedCount()<4){
                    tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT);
                    tess.setImage(image);
                    AssetReceiptParser.Result extra=AssetReceiptParser.parse(tess.getUTF8Text());
                    result=AssetReceiptParser.supplement(result,extra);
                }
                if(result.recognizedCount()==0)error="متن مالی قابل اتکایی تشخیص داده نشد؛ اطلاعات را دستی وارد کن.";
            }catch(Exception | LinkageError ex){
                error="خواندن تصویر ممکن نشد. می‌توانی اطلاعات را دستی وارد کنی.";
                android.util.Log.w("NexaReceiptOcr", "OCR failed", ex);
            }finally{
                if(tess!=null)try{tess.recycle();}catch(Exception ignored){}
                if(image!=null&&!image.isRecycled())image.recycle();
            }
            final AssetReceiptParser.Result recognized=result;
            final String finalError=error;
            new Handler(Looper.getMainLooper()).post(()->callback.onResult(recognized,finalError));
        },"nexa-receipt-ocr").start();
    }
    private static void copyModel(Context context,File modelDir,String name)throws Exception{
        File output=new File(modelDir,name);
        try(InputStream asset=context.getAssets().open("tessdata/"+name)){
            if(output.exists()&&output.length()==asset.available())return;
            try(FileOutputStream dest=new FileOutputStream(output,false)){
                byte[] buf=new byte[8192];int n;
                while((n=asset.read(buf))!=-1)dest.write(buf,0,n);
            }
        }
    }
    private static Bitmap loadBitmap(Context context,Uri uri)throws Exception{
        BitmapFactory.Options measure=new BitmapFactory.Options();
        measure.inJustDecodeBounds=true;
        try(InputStream stream=context.getContentResolver().openInputStream(uri)){
            if(stream==null)throw new IllegalArgumentException("منبع تصویر در دسترس نیست.");
            BitmapFactory.decodeStream(stream,null,measure);
        }
        BitmapFactory.Options read=new BitmapFactory.Options();
        read.inPreferredConfig=Bitmap.Config.ARGB_8888;
        int larger=Math.max(measure.outWidth,measure.outHeight);
        read.inSampleSize=1;
        while(larger/read.inSampleSize>3000)read.inSampleSize*=2;
        try(InputStream stream=context.getContentResolver().openInputStream(uri)){
            if(stream==null)throw new IllegalArgumentException("منبع تصویر در دسترس نیست.");
            return BitmapFactory.decodeStream(stream,null,read);
        }
    }
    private static Bitmap prepare(Bitmap source){
        float upscale=Math.min(2f,Math.min(2600f/source.getHeight(),1600f/source.getWidth()));
        if(upscale<=0f)upscale=1f;
        int w=Math.max(1,Math.round(source.getWidth()*upscale));
        int h=Math.max(1,Math.round(source.getHeight()*upscale));
        Bitmap dst=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(dst);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        // Improved legibility for grey receipts while preserving numerical glyphs.
        ColorMatrix grey=new ColorMatrix();grey.setSaturation(0f);
        ColorMatrix contrast=new ColorMatrix(new float[]{
            1.2f,0,0,0,-23f, 0,1.2f,0,0,-23f, 0,0,1.2f,0,-23f, 0,0,0,1,0
        });grey.postConcat(contrast);
        paint.setColorFilter(new ColorMatrixColorFilter(grey));
        canvas.drawBitmap(source,null,new android.graphics.Rect(0,0,w,h),paint);
        return dst;
    }
}
