package com.example.silenttimer;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import com.googlecode.tesseract.android.TessBaseAPI;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/** Offline Persian/English OCR. No image or recognized text is uploaded. */
public final class AssetReceiptOcr {
    private AssetReceiptOcr() {}
    public interface Listener { void onResult(AssetReceiptParser.Result result, String error); }

    public static void read(Context context, Uri uri, Listener callback){
        read(context,uri,"",callback);
    }
    public static void read(Context context, Uri uri, String expectedAssetType, Listener callback){
        Context app=context.getApplicationContext();
        new Thread(()->{
            AssetReceiptParser.Result result=null;
            String error=null;
            Bitmap image=null;
            Bitmap decodedForRows=null;
            TessBaseAPI tess=null;
            TessBaseAPI scriptFallback=null;
            try {
                if(uri==null || !"content".equalsIgnoreCase(uri.getScheme()))
                    throw new IllegalArgumentException("فایل تصویری معتبر انتخاب نشده است.");
                File root=new File(app.getFilesDir(),"receipt_ocr");
                File modelDir=new File(root,"tessdata");
                if(!modelDir.isDirectory()&&!modelDir.mkdirs())
                    throw new IllegalStateException("پوشه OCR ایجاد نشد.");
                copyModel(app,modelDir,"fas.traineddata");
                copyModel(app,modelDir,"eng.traineddata");
                Bitmap decoded=loadBitmap(app,uri);
                if(decoded==null)throw new IllegalArgumentException("تصویر انتخاب‌شده خوانده نشد.");
                decodedForRows=decoded;
                image=prepare(decoded);
                tess=new TessBaseAPI();
                if(!tess.init(root.getAbsolutePath(),"fas+eng"))
                    throw new IllegalStateException("موتور خواندن رسید راه‌اندازی نشد.");
                tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK);
                tess.setImage(image);
                String detected=tess.getUTF8Text();
                result=AssetReceiptParser.parse(detected);
                if(result.recognizedCount()<4){
                    tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SPARSE_TEXT);
                    tess.setImage(image);
                    AssetReceiptParser.Result extra=AssetReceiptParser.parse(tess.getUTF8Text());
                    result=AssetReceiptParser.supplement(result,extra);
                }
                // A Karizma account screenshot uses alternating light rows. A whole-page OCR
                // may merge the number in the left column with a different right-hand label.
                // Read numeric cells separately and only accept mathematically reconciled sets.
                if(!AssetReceiptParser.financiallyConsistent(result) &&
                    ("صندوق نقره کاریزما".equals(result.assetType) ||
                     "صندوق نقره کاریزما".equals(expectedAssetType))){
                    // The selected asset can guide layout matching, never silently
                    // override a different provider read from the actual receipt.
                    if(result.assetType.isEmpty())result.assetType=expectedAssetType;
                    result=readKarizmaRows(decodedForRows,tess,detected,result);
                    // Secondary OFFLINE Arabic-script recognizer. The Persian model
                    // sometimes drops Persian digits even in isolated receipt cells;
                    // the alternative script model can recover other candidates.
                    // It runs only for unresolved provider rows and is never trusted
                    // without independent financial reconciliation.
                    if(!AssetReceiptParser.financiallyConsistent(result)){
                        try{
                            copyModel(app,modelDir,"Arabic.traineddata");
                            scriptFallback=new TessBaseAPI();
                            if(scriptFallback.init(root.getAbsolutePath(),"Arabic")){
                                result=readKarizmaRows(decodedForRows,scriptFallback,detected,result);
                            }
                        }catch(Exception | LinkageError modelError){
                            android.util.Log.w("NexaReceiptOcr","Arabic-script fallback unavailable",modelError);
                        }
                    }
                }
                if(result.recognizedCount()==0)error="متن مالی قابل اتکایی تشخیص داده نشد؛ اطلاعات را دستی وارد کن.";

            }catch(Exception | LinkageError ex){
                error="خواندن تصویر ممکن نشد. می‌توانی اطلاعات را دستی وارد کنی.";
                android.util.Log.w("NexaReceiptOcr", "OCR failed", ex);
            }finally{
                if(tess!=null)try{tess.recycle();}catch(Exception ignored){}
                if(scriptFallback!=null)try{scriptFallback.recycle();}catch(Exception ignored){}
                if(image!=null&&!image.isRecycled())image.recycle();
                if(decodedForRows!=null&&!decodedForRows.isRecycled())decodedForRows.recycle();
            }
            final AssetReceiptParser.Result recognized=result;
            final String finalError=error;
            new Handler(Looper.getMainLooper()).post(()->callback.onResult(recognized,finalError));
        },"nexa-receipt-ocr").start();
    }
    private static final class Stripe{
        final int top,bottom;
        Stripe(int t,int b){top=t;bottom=b;}
    }
    /** Extract only the left numeric column from Karizma's alternating receipt rows. */
    private static AssetReceiptParser.Result readKarizmaRows(Bitmap raw,TessBaseAPI tess,
            String pageText,AssetReceiptParser.Result base){
        if(raw==null || raw.getWidth()<260 || raw.getHeight()<400)return base;
        List<Stripe> bands=receiptBands(raw);
        if(bands.size()<6 || bands.size()>9)return base;
        // The first dark band can represent the tool name OR the transaction type.
        // OCR often misses the label, so try both geometries, but never adopt a
        // layout without independent financial reconciliation of the numbers.
        String normalized=AssetReceiptParser.ascii(pageText==null?"":pageText);
        boolean hasToolLabel=normalized.contains("نام ابزار");
        boolean hasTransactionLabel=normalized.contains("شماره بیمه") ||
            normalized.contains("نوع تراکنش");
        int[] offsets=hasToolLabel?new int[]{0,2}:
            hasTransactionLabel?new int[]{2,0}:new int[]{0,2};
        for(int offset:offsets){
            AssetReceiptFieldFusion.Candidates variants=new AssetReceiptFieldFusion.Candidates();
            try{
                for(int k=0;k<bands.size();k++){
                    int row=offset+2*k;
                    String key=fieldForRow(row);
                    if(key!=null)recognizeValue(raw,tess,bands.get(k).top,bands.get(k).bottom,key,variants);
                    if(k+1<bands.size()){
                        String whiteKey=fieldForRow(row+1);
                        if(whiteKey!=null)recognizeValue(raw,tess,bands.get(k).bottom,
                            bands.get(k+1).top,whiteKey,variants);
                    }
                }
            }catch(Exception ex){android.util.Log.w("NexaReceiptOcr","row OCR failed",ex);}
            AssetReceiptParser.Result merged=AssetReceiptFieldFusion.fuse(base,variants);
            // Preserve independently reconciled values when the complete set is
            // unavailable. Never erase a valid amount/rate/quantity trio merely
            // because OCR missed a different line such as the gram fee.
            if(AssetReceiptParser.financiallyConsistent(merged))return merged;
            int verified=AssetReceiptImportPlan.evaluate(merged,merged.assetType).verifiedNumericFields;
            int previous=AssetReceiptImportPlan.evaluate(base,base.assetType).verifiedNumericFields;
            if(verified>previous)base=merged;
        }
        return base;
    }
    private static String fieldForRow(int row){
        switch(row){
            case 4:return "amount";
            case 5:return "gross";
            case 6:return "price";
            case 7:return "cashFee";
            case 8:return "gramFee";
            default:return null;
        }
    }
    /** Find gray rounded horizontal bands without assuming absolute screen coordinates. */
    private static List<Stripe> receiptBands(Bitmap raw){
        List<Stripe> out=new ArrayList<>();
        int w=raw.getWidth(),h=raw.getHeight(),x=Math.round(w*.13f);
        int begin=Math.round(h*.20f),end=Math.round(h*.92f),run=-1;
        for(int y=begin;y<=end;y++){
            boolean gray=false;
            if(y<end){
                int c=raw.getPixel(x,y);
                int r=android.graphics.Color.red(c),g=android.graphics.Color.green(c),b=android.graphics.Color.blue(c);
                gray=r>=216&&r<=249&&Math.abs(r-g)<16&&b>=g&&b-r<30;
            }
            if(gray && run<0)run=y;
            if(!gray && run>=0){
                int len=y-run;
                if(len>w*.075f && len<w*.175f)out.add(new Stripe(run,y));
                run=-1;
            }
        }
        if(out.size()<6)return out;
        // Avoid guessing row indices when the photo is a collage or nonuniform layout.
        for(int i=1;i<out.size();i++){
            int period=out.get(i).top-out.get(i-1).top;
            if(period<w*.15f||period>w*.30f)return new ArrayList<>();
        }
        return out;
    }
    private static void recognizeValue(Bitmap src,TessBaseAPI tess,int top,int bottom,
            String kind,AssetReceiptFieldFusion.Candidates variants){
        int w=src.getWidth();
        // The longest label (price per gram) starts in the middle of a row;
        // do NOT include its Persian letters in the numeric OCR crop.
        float endRatio="gross".equals(kind)?0.432f:
            "price".equals(kind)?0.375f:
            "amount".equals(kind)?0.423f:
            "cashFee".equals(kind)?0.405f:0.411f;
        int x=(int)(w*.13f),right=(int)(w*endRatio);
        int pad=Math.max(3,(bottom-top)/12);
        top=Math.max(0,top+pad);bottom=Math.min(src.getHeight(),bottom-pad);
        if(right<=x||bottom<=top)return;
        Bitmap part=null,large=null,binary=null;
        try{
            part=Bitmap.createBitmap(src,x,top,right-x,bottom-top);
            int factor=Math.max(2,Math.min(4,1050/Math.max(1,part.getWidth())));
            large=Bitmap.createScaledBitmap(part,part.getWidth()*factor,part.getHeight()*factor,true);
            // Try isolated gray-on-white and binarized numerals. The different
            // page segmentation passes are candidates, not trusted readings.
            tess.setVariable("tessedit_char_whitelist",
                "0123456789۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩,./٫٬");
            tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_LINE);
            tess.setImage(large);
            variants.add(kind,tess.getUTF8Text());
            binary=thresholdForDigits(large);
            tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_WORD);
            tess.setImage(binary);
            variants.add(kind,tess.getUTF8Text());
            // Persian numerals may be discarded by the strict whitelist. A
            // separate unfiltered line pass can recover the full token.
            tess.setVariable("tessedit_char_whitelist","");
            tess.setPageSegMode(TessBaseAPI.PageSegMode.PSM_RAW_LINE);
            tess.setImage(large);
            variants.add(kind,tess.getUTF8Text());
        }finally{
            tess.setVariable("tessedit_char_whitelist","");
            if(binary!=null&&!binary.isRecycled())binary.recycle();
            if(large!=null&&!large.isRecycled())large.recycle();
            if(part!=null&&!part.isRecycled())part.recycle();
        }
    }
    /** White background and dark numerals without flattening glyphs to grey. */
    private static Bitmap thresholdForDigits(Bitmap source){
        Bitmap out=Bitmap.createBitmap(source.getWidth(),source.getHeight(),Bitmap.Config.ARGB_8888);
        int[] pixels=new int[source.getWidth()*source.getHeight()];
        source.getPixels(pixels,0,source.getWidth(),0,0,source.getWidth(),source.getHeight());
        for(int i=0;i<pixels.length;i++){
            int c=pixels[i];
            int lum=(android.graphics.Color.red(c)*3+android.graphics.Color.green(c)*6+
                android.graphics.Color.blue(c))/10;
            pixels[i]=lum<175?android.graphics.Color.BLACK:android.graphics.Color.WHITE;
        }
        out.setPixels(pixels,0,source.getWidth(),0,0,source.getWidth(),source.getHeight());
        return out;
    }
    private static void copyModel(Context context,File modelDir,String name)throws Exception{
        File output=new File(modelDir,name);
        try(InputStream asset=context.getAssets().open("tessdata/"+name)){
            if(output.exists()&&output.length()==asset.available())return;
            try(FileOutputStream dest=new FileOutputStream(output,false)){
                byte[] buf=new byte[8192];int n;
                while((n=asset.read(buf))!=-1)dest.write(buf,0,n);
            }
        }
    }
    private static Bitmap loadBitmap(Context context,Uri uri)throws Exception{
        BitmapFactory.Options measure=new BitmapFactory.Options();
        measure.inJustDecodeBounds=true;
        try(InputStream stream=context.getContentResolver().openInputStream(uri)){
            if(stream==null)throw new IllegalArgumentException("منبع تصویر در دسترس نیست.");
            BitmapFactory.decodeStream(stream,null,measure);
        }
        BitmapFactory.Options read=new BitmapFactory.Options();
        read.inPreferredConfig=Bitmap.Config.ARGB_8888;
        int larger=Math.max(measure.outWidth,measure.outHeight);
        read.inSampleSize=1;
        while(larger/read.inSampleSize>3000)read.inSampleSize*=2;
        try(InputStream stream=context.getContentResolver().openInputStream(uri)){
            if(stream==null)throw new IllegalArgumentException("منبع تصویر در دسترس نیست.");
            return BitmapFactory.decodeStream(stream,null,read);
        }
    }
    private static Bitmap prepare(Bitmap source){
        float upscale=Math.min(2f,Math.min(2600f/source.getHeight(),1600f/source.getWidth()));
        if(upscale<=0f)upscale=1f;
        int w=Math.max(1,Math.round(source.getWidth()*upscale));
        int h=Math.max(1,Math.round(source.getHeight()*upscale));
        Bitmap dst=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888);
        Canvas canvas=new Canvas(dst);
        Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG);
        // Improved legibility for grey receipts while preserving numerical glyphs.
        ColorMatrix grey=new ColorMatrix();grey.setSaturation(0f);
        ColorMatrix contrast=new ColorMatrix(new float[]{
            1.2f,0,0,0,-23f, 0,1.2f,0,0,-23f, 0,0,1.2f,0,-23f, 0,0,0,1,0
        });grey.postConcat(contrast);
        paint.setColorFilter(new ColorMatrixColorFilter(grey));
        canvas.drawBitmap(source,null,new android.graphics.Rect(0,0,w,h),paint);
        return dst;
    }
}
