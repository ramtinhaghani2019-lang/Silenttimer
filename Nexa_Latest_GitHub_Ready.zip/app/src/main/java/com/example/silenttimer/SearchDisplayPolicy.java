package com.example.silenttimer;

/** Pure presentation policy for the universal search; never reads private data. */
public final class SearchDisplayPolicy {
    private SearchDisplayPolicy(){}
    public static final int ALL=0,TASKS=1,FINANCE=2,HEALTH=3,CARE=4,OTHER=5;
    public static final String[] FILTERS={"همه","کارها","مالی","سلامت","وسایل","سایر"};
    public static boolean matches(int selected,int group){return selected==ALL || selected==group;}
    public static int compare(int score1,int order1,int score2,int order2){
        int relevance=Integer.compare(score2,score1);
        return relevance!=0?relevance:Integer.compare(order1,order2);
    }
    public static String countLabel(int shown,int total,int group){
        return group==ALL?shown+" نتیجه پیدا شد":shown+" از "+total+" نتیجه";
    }
}
