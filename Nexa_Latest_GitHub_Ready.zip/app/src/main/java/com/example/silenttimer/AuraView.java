package com.example.silenttimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

public class AuraView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int accent;
    private int accent2;

    public AuraView(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        accent = 0xFF8B5CF6;
        accent2 = 0xFF22D3EE;
    }

    public void setColors(int primary, int secondary) {
        accent = primary;
        accent2 = secondary;
        invalidate();
    }

    private static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | ((a & 0xFF) << 24);
    }

    private void glow(
            Canvas canvas,
            float x,
            float y,
            float radius,
            int center,
            int edge
    ) {
        paint.setStyle(Paint.Style.FILL);
        paint.setShader(
                new RadialGradient(
                        x,
                        y,
                        radius,
                        new int[]{center, edge, 0x00000000},
                        new float[]{0f, 0.58f, 1f},
                        Shader.TileMode.CLAMP
                )
        );
        canvas.drawCircle(x, y, radius, paint);
        paint.setShader(null);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float base = Math.min(getWidth(), getHeight());

        glow(canvas, cx - base * 0.18f, cy - base * 0.18f, base * 0.44f,
                alpha(accent, 0x66), alpha(accent, 0x22));

        glow(canvas, cx + base * 0.20f, cy - base * 0.07f, base * 0.40f,
                alpha(accent2, 0x55), alpha(accent2, 0x18));

        glow(canvas, cx + base * 0.10f, cy + base * 0.22f, base * 0.38f,
                alpha(accent2, 0x44), alpha(accent2, 0x12));

        glow(canvas, cx - base * 0.20f, cy + base * 0.20f, base * 0.34f,
                alpha(accent, 0x33), alpha(accent, 0x10));

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(UiKit.dp(getContext(), 1));

        paint.setColor(alpha(accent, 0x44));
        canvas.drawCircle(cx, cy, base * 0.39f, paint);

        paint.setColor(alpha(accent2, 0x33));
        canvas.drawCircle(cx, cy, base * 0.31f, paint);

        paint.setColor(alpha(accent2, 0x28));
        canvas.drawCircle(cx, cy, base * 0.24f, paint);
    }
}
