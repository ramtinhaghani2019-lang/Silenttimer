package com.example.silenttimer;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;

/** Shared persisted sound selection for all Nexa alarm profiles. */
public final class AlarmSoundSelection {
    private static final String PREF="nexa_alarm_sounds";
    private AlarmSoundSelection(){}
    public static boolean validProfile(int p){
        return p==NexaAudioController.SOUND_ALARM || p==NexaAudioController.SOUND_REMINDER
            || p==NexaAudioController.SOUND_BATTERY || p==NexaAudioController.SOUND_THEFT || p==NexaAudioController.SOUND_SILENT_EXIT;
    }
    public static String key(int profile){return "sound_"+profile;}
    public static void save(Context c,int profile,Uri uri){
        if(c==null || !validProfile(profile))return;
        if(uri!=null && !isSupportedUri(uri))return;
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
            .putString(key(profile),uri==null?"":uri.toString()).apply();
    }
    public static Uri chosen(Context c,int profile){
        if(c==null || !validProfile(profile))return null;
        String value=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(key(profile),"");
        if(value==null || value.isEmpty())return null;
        try {
            Uri uri=Uri.parse(value);
            return isSupportedUri(uri)?uri:null;
        }catch(Exception ignored){return null;}
    }
    public static boolean isSupportedUri(Uri uri){
        if(uri==null)return false;
        String scheme=uri.getScheme();
        return "content".equals(scheme)||"android.resource".equals(scheme);
    }
    /** The Android document provider may disappear when removable storage is detached. */
    public static boolean isReadable(Context c,Uri uri){
        if(c==null || !isSupportedUri(uri))return false;
        try(android.os.ParcelFileDescriptor fd=c.getContentResolver().openFileDescriptor(uri,"r")){
            return fd!=null;
        }catch(Exception ignored){return false;}
    }
    public static Uri fallback(Context c,int profile){
        if(profile==NexaAudioController.SOUND_BATTERY)
            return Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.nexa_charge_alarm);
        if(profile==NexaAudioController.SOUND_THEFT)
            return Uri.parse("android.resource://"+c.getPackageName()+"/"+R.raw.nexa_theft_siren);
        int type=profile==NexaAudioController.SOUND_SILENT_EXIT?
            RingtoneManager.TYPE_NOTIFICATION:
            profile==NexaAudioController.SOUND_REMINDER?
            RingtoneManager.TYPE_RINGTONE:RingtoneManager.TYPE_ALARM;
        Uri uri=RingtoneManager.getDefaultUri(type);
        return uri!=null?uri:RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
    }
    public static Uri resolve(Context c,int profile){
        Uri selected=chosen(c,profile);
        return selected!=null?selected:fallback(c,profile);
    }
    /** Only explicit, readable selections are used for a preview; fallback remains available. */
    public static Uri readableOrFallback(Context c,int profile){
        if(c==null || !validProfile(profile))return null;
        Uri chosen=chosen(c,profile);
        if(chosen!=null && isReadable(c,chosen))return chosen;
        return fallback(c,profile);
    }
    /** Existing Android notification channels retain user-managed sound settings. */
    public static Intent notificationSettingsIntent(Context c){
        Intent i=new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
        i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,c.getPackageName());
        return i;
    }
    /** Friendly selection label without exposing provider URIs or private file paths. */
    public static String displayName(Context c,int profile){
        if(c==null || !validProfile(profile))return "نامشخص";
        Uri uri=chosen(c,profile);
        if(uri==null)return "پیش‌فرض Nexa";
        if(!isReadable(c,uri))return "فایل انتخاب‌شده در دسترس نیست (صدای جایگزین)";
        try{
            android.media.Ringtone ringtone=RingtoneManager.getRingtone(c,uri);
            if(ringtone!=null){
                String title=ringtone.getTitle(c);
                if(title!=null && !title.trim().isEmpty())return title.trim();
            }
        }catch(Exception ignored){}
        try(android.database.Cursor cursor=c.getContentResolver().query(uri,
                new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(cursor!=null && cursor.moveToFirst()){
                String title=cursor.getString(0);
                if(title!=null && !title.trim().isEmpty())return title.trim();
            }
        }catch(Exception ignored){}
        return "صدای انتخابی";
    }
    public static boolean canPreview(int activePriority){
        return activePriority==0;
    }
    public static Intent audioDocumentIntent(){
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("audio/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        return i;
    }
}
