package com.example.silenttimer;

import android.app.*;
import android.content.*;
import android.hardware.biometrics.BiometricPrompt;
import android.os.*;
import android.text.InputType;
import android.view.*;
import android.widget.*;

/** Authentication gate for stopping the theft alarm. The alarm cannot be dismissed by merely opening this screen. */
public class TheftAlarmActivity extends Activity {
    private static final int REQ_DEVICE=9470;
    private CancellationSignal signal;
    private boolean biometricRunning=false;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();if(Build.VERSION.SDK_INT>=28&&NexaStore.biometricEnabled(this))getWindow().getDecorView().postDelayed(this::biometric,220);}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setPadding(UiKit.dp(this,26),UiKit.dp(this,26),UiKit.dp(this,26),UiKit.dp(this,26));root.setBackground(UiKit.screenBackground(this));
        TextView title=UiKit.title(this,"🚨 هشدار ضدسرقت");title.setGravity(Gravity.CENTER);root.addView(title,UiKit.matchWrap(this,0,8));
        TextView msg=UiKit.muted(this,"شارژر از دستگاه جدا شده است. برای توقف هشدار هویت را تأیید کنید.");msg.setGravity(Gravity.CENTER);root.addView(msg,UiKit.matchWrap(this,0,18));
        if(NexaStore.pinConfigured(this)){
            EditText pin=UiKit.styleField(this,new EditText(this),"PIN Nexa");pin.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);root.addView(pin,UiKit.matchWrap(this,0,10));
            Button ok=UiKit.primaryButton(this,"توقف با PIN");ok.setOnClickListener(v->{if(NexaStore.verifyPin(this,pin.getText().toString()))authenticatedStop();else Toast.makeText(this,"PIN نادرست است.",Toast.LENGTH_SHORT).show();});root.addView(ok,UiKit.matchWrap(this,0,8));
        }
        if(Build.VERSION.SDK_INT>=28&&NexaStore.biometricEnabled(this)){Button bio=UiKit.secondaryButton(this,"👆 توقف با اثر انگشت");bio.setOnClickListener(v->{biometricRunning=false;biometric();});root.addView(bio,UiKit.matchWrap(this,0,8));}
        Button device=UiKit.secondaryButton(this,"🔒 استفاده از قفل امن گوشی");device.setOnClickListener(v->deviceCredential());root.addView(device,UiKit.matchWrap(this,0,8));
        setContentView(root);
    }
    private void authenticatedStop(){TheftGuardManager.stop(this);Toast.makeText(this,"هشدار ضدسرقت متوقف شد.",Toast.LENGTH_SHORT).show();finish();}
    private void deviceCredential(){KeyguardManager km=(KeyguardManager)getSystemService(KEYGUARD_SERVICE);if(km==null||!km.isDeviceSecure()){Toast.makeText(this,"قفل امن گوشی فعال نیست؛ از PIN Nexa استفاده کنید.",Toast.LENGTH_LONG).show();return;}Intent i=km.createConfirmDeviceCredentialIntent("Nexa Theft Guard","برای توقف هشدار، قفل گوشی را تأیید کنید");if(i!=null)startActivityForResult(i,REQ_DEVICE);}
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);if(r==REQ_DEVICE&&result==RESULT_OK)authenticatedStop();}
    private void biometric(){if(Build.VERSION.SDK_INT<28||biometricRunning||isFinishing())return;biometricRunning=true;signal=new CancellationSignal();BiometricPrompt p=new BiometricPrompt.Builder(this).setTitle("Nexa Theft Guard").setSubtitle("برای توقف هشدار اثر انگشت را تأیید کنید").setNegativeButton("PIN / قفل گوشی",getMainExecutor(),(d,w)->biometricRunning=false).build();p.authenticate(signal,getMainExecutor(),new BiometricPrompt.AuthenticationCallback(){@Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){biometricRunning=false;authenticatedStop();}@Override public void onAuthenticationError(int c,CharSequence m){biometricRunning=false;}@Override public void onAuthenticationFailed(){Toast.makeText(TheftAlarmActivity.this,"اثر انگشت شناسایی نشد.",Toast.LENGTH_SHORT).show();}});}
    @Override protected void onDestroy(){if(signal!=null)try{signal.cancel();}catch(Exception ignored){}super.onDestroy();}
}
