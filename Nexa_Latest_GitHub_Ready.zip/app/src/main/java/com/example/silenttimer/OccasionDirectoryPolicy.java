package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Read-only directory filtering. The original event and yearly alarm remain untouched. */
public final class OccasionDirectoryPolicy {
    public static final String ALL="all", SOON="soon", BIRTHDAY="birthday", MARRIAGE="marriage",
            MEMORIAL="memorial", PERSONAL="personal", PAUSED="paused";
    private OccasionDirectoryPolicy() {}

    public static boolean matches(OccasionStore.Occasion e,String query,String filter,long now){
        if(e==null)return false;
        String f=filter==null?ALL:filter;
        if(SOON.equals(f)){
            if(!e.active)return false;
            long next=AnnualOccasionDates.next(e,now);
            if(next<=0||next>afterDays(now,30))return false;
        }else if(PAUSED.equals(f)){
            if(e.active)return false;
        }else if(!ALL.equals(f) && !f.equals(e.type))return false;
        String q=SearchQueryPolicy.normalize(query);
        return q.isEmpty()||SearchQueryPolicy.matches(
                e.title+" "+e.typeLabel()+" "+e.year+"/"+e.month+"/"+e.day,q);
    }

    public static long afterDays(long now,int days){
        Calendar c=Calendar.getInstance();c.setTimeInMillis(now);c.add(Calendar.DAY_OF_MONTH,days);
        return c.getTimeInMillis();
    }

    public static List<OccasionStore.Occasion> select(List<OccasionStore.Occasion> all,String query,String filter,long now){
        ArrayList<OccasionStore.Occasion> result=new ArrayList<>();
        if(all==null)return result;
        for(OccasionStore.Occasion e:all)if(matches(e,query,filter,now))result.add(e);
        Collections.sort(result,new Comparator<OccasionStore.Occasion>(){
            @Override public int compare(OccasionStore.Occasion a,OccasionStore.Occasion b){
                if(a.active!=b.active)return a.active?-1:1;
                long da=AnnualOccasionDates.next(a,now),db=AnnualOccasionDates.next(b,now);
                if(da<=0)da=Long.MAX_VALUE;if(db<=0)db=Long.MAX_VALUE;
                int cmp=Long.compare(da,db);
                if(cmp!=0)return cmp;
                return SearchQueryPolicy.normalize(a.title).compareTo(SearchQueryPolicy.normalize(b.title));
            }
        });
        return result;
    }
}
