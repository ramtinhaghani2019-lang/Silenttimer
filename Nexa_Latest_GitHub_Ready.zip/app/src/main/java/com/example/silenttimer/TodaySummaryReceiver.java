package com.example.silenttimer;
import android.content.BroadcastReceiver;import android.content.Context;import android.content.Intent;
public class TodaySummaryReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){TodayNotificationManager.refresh(c);} }
