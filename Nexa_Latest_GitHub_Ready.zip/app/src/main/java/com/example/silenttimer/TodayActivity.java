package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.view.Gravity;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;

/** Real calendar-day overview, with separate overdue and completed items. */
public class TodayActivity extends Activity {
    private static class Item {
        long at;String title,subtitle,icon;boolean done;Class<?> page;
        Item(long when,String icon,String title,String sub,boolean done,Class<?> page){
            this.at=when;this.icon=icon;this.title=title;this.subtitle=sub;this.done=done;this.page=page;}
    }
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();build();}
    private void add(List<Item> all,long when,String icon,String title,String sub,boolean done,Class<?> page){
        if(when>0)all.add(new Item(when,icon,title,sub,done,page));
    }
    private void build(){
        long now=System.currentTimeMillis();Calendar c=Calendar.getInstance();
        c.setTimeInMillis(now);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);
        c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);long start=c.getTimeInMillis();
        c.add(Calendar.DAY_OF_YEAR,1);long end=c.getTimeInMillis();
        c.add(Calendar.DAY_OF_YEAR,1);long tomorrowEnd=c.getTimeInMillis();
        List<Item> items=new ArrayList<>();
        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            if(!r.sourceKey.isEmpty())continue; // linked events are shown from their origin modules
            add(items,r.whenMillis,r.icon,r.title,r.category,!r.active,RemindersActivity.class);
        }
        for(NexaStore.Medicine m:NexaStore.medicines(this))if(m.active)
            add(items,m.nextDoseMillis,"💊",m.name,m.dose,false,MedicineActivity.class);
        for(NexaStore.CaseItem x:NexaStore.cases(this))
            add(items,x.whenMillis,"⚖️",x.title,"جلسه دادگاه • "+x.court,false,CaseActivity.class);
        for(NexaStore.BillItem x:NexaStore.bills(this))
            add(items,x.dueDate,"💳",x.title,x.type,x.paid,BillsActivity.class);
        for(NexaStore.DocumentItem x:NexaStore.documents(this))
            add(items,x.expiryDate,"📄",x.title,"انقضای مدرک",false,DocsActivity.class);
        for(NexaStore.HomeItem x:NexaStore.homeItems(this))
            add(items,x.nextDueDate,"🏠",x.title,x.category,false,HomeCareActivity.class);
        for(NexaStore.TodoItem x:NexaStore.todos(this))
            add(items,x.dueMillis,"✓",x.title,x.category,x.done,NexaListActivity.class);
        for(NexaStore.ServiceRecord x:NexaStore.services(this))if(x.nextDueDate>0)
            add(items,x.nextDueDate,"🚗",x.category,"سرویس خودرو",false,GarageActivity.class);
        List<Item> undone=new ArrayList<>(),completed=new ArrayList<>(),overdue=new ArrayList<>(),tomorrow=new ArrayList<>(),next7=new ArrayList<>();
        long next7End=start+8L*24*60*60*1000;
        for(Item i:items){
            if(i.done){if(i.at>=start&&i.at<end)completed.add(i);}
            else if(i.at<start)overdue.add(i);
            else if(i.at<end)undone.add(i);
            else if(i.at<tomorrowEnd)tomorrow.add(i);
            if(!i.done && i.at>=end && i.at<next7End)next7.add(i);
        }
        undone.sort(Comparator.comparingLong(i->i.at));
        completed.sort(Comparator.comparingLong(i->i.at));
        overdue.sort((a,b)->Long.compare(b.at,a.at));
        tomorrow.sort(Comparator.comparingLong(i->i.at));
        next7.sort(Comparator.comparingLong(i->i.at));
        ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,16),UiKit.dp(this,18),UiKit.dp(this,30));sc.addView(root);
        root.addView(UiKit.header(this,"امروز",v->finish()),UiKit.matchWrap(this,0,2));
        root.addView(UiKit.muted(this,"برنامه روز • "+PersianDateUtil.pretty(now)),UiKit.matchWrap(this,0,14));
        root.addView(NexaAgendaUi.stats(this,
                new String[]{"در انتظار امروز","معوق و پیگیری‌نشده","انجام‌شده"},
                new String[]{String.valueOf(undone.size()),String.valueOf(overdue.size()),String.valueOf(completed.size())},
                new int[]{UiKit.PURPLE,UiKit.RED,UiKit.GREEN}),UiKit.matchWrap(this,0,12));
        LinearLayout summary=UiKit.accentCardLayout(this);
        summary.addView(UiKit.sectionTitle(this,"✦ نگاه سریع"));
        summary.addView(UiKit.muted(this,"☀️ فردا: "+tomorrow.size()+"   •   📆 ۷ روز آینده: "+next7.size()),UiKit.matchWrap(this,7,0));
        Item next=null; for(Item i:items) if(!i.done && i.at>=now && (next==null || i.at<next.at)) next=i;
        if(next!=null) summary.addView(UiKit.muted(this,"⏭ نزدیک‌ترین: "+next.icon+" "+next.title+" • "+PersianDateUtil.pretty(next.at)),UiKit.matchWrap(this,7,0));
        int critical=overdue.size()+undone.size(); long unpaid=0;
        for(NexaStore.BillItem x:NexaStore.bills(this)) if(!x.paid && x.dueDate>0 && x.dueDate<next7End) unpaid+=x.amount;
        summary.addView(UiKit.muted(this,"⚡ نیازمند توجه: "+critical+"   •   💳 تعهد مالی تا ۷ روز: "+NumberFormatUtil.format(unpaid)+" تومان"),UiKit.matchWrap(this,4,0));
        root.addView(summary,UiKit.matchWrap(this,0,12));
        addSection(root,"⏳ انجام‌نشده امروز",undone,1,"کاری برای امروز ثبت نشده.");
        addSection(root,"🔴 معوق و پیگیری‌نشده",overdue,3,"مورد معوقی وجود ندارد.");
        addSection(root,"✓ انجام‌شده امروز",completed,2,"موردی برای امروز تکمیل نشده.");
        addSection(root,"☀️ پیش‌نمایش فردا",tomorrow,0,"برای فردا موردی ثبت نشده.");
        addSection(root,"📆 ۷ روز آینده",next7,6,"در ۷ روز آینده موردی ثبت نشده.");
        LinearLayout garage=UiKit.colorfulCardLayout(this,0);
        garage.addView(UiKit.sectionTitle(this,"🚗 هشدارهای کیلومتری"));int dueCount=0;
        for(NexaStore.Vehicle v:NexaStore.vehicles(this)){
            java.util.Map<String,NexaStore.ServiceRecord> newest=new java.util.HashMap<>();
            for(NexaStore.ServiceRecord r:NexaStore.servicesFor(this,v.id))
                if(r.nextDueKm>0&&!newest.containsKey(r.category))newest.put(r.category,r);
            for(NexaStore.ServiceRecord r:newest.values())if(v.currentKm>=r.nextDueKm){
                dueCount++;TextView t=UiKit.muted(this,v.name+" • "+r.category+" • "+(v.currentKm-r.nextDueKm)+" کیلومتر دیرکرد");
                t.setTextColor(UiKit.PINK);garage.addView(t,UiKit.matchWrap(this,7,0));
            }
        }
        if(dueCount==0)garage.addView(UiKit.muted(this,"سرویس کیلومتری معوق وجود ندارد."),UiKit.matchWrap(this,7,0));
        garage.setOnClickListener(v->startActivity(new Intent(this,GarageActivity.class)));
        root.addView(garage,UiKit.matchWrap(this,0,12));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        Button history=UiKit.secondaryButton(this,"◷ تاریخچه");history.setOnClickListener(v->startActivity(new Intent(this,TimelineActivity.class)));
        Button search=UiKit.secondaryButton(this,"⌕ جستجو");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        actions.addView(history,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams searchLp=new LinearLayout.LayoutParams(0,-2,1f);searchLp.setMargins(UiKit.dp(this,8),0,0,0);actions.addView(search,searchLp);
        root.addView(actions,UiKit.matchWrap(this,0,12));
        LinearLayout once=UiKit.cardLayout(this);once.addView(UiKit.sectionTitle(this,"🔓 یادداشت برای بازکردن بعدی گوشی"));
        EditText note=new EditText(this);note.setTextColor(UiKit.TEXT);note.setHintTextColor(UiKit.MUTED);
        note.setHint("یادداشت کوتاه...");note.setText(NexaStore.unlockNote(this));note.setBackground(UiKit.field(this));once.addView(note,UiKit.matchWrap(this,10,8));
        Button save=UiKit.secondaryButton(this,"ذخیره / به‌روزرسانی یادداشت");save.setOnClickListener(v->{NexaStore.setUnlockNote(this,note.getText().toString().trim());android.widget.Toast.makeText(this,"یادداشت ذخیره شد.",android.widget.Toast.LENGTH_SHORT).show();});
        once.addView(save);
        Button clear=UiKit.secondaryButton(this,"پاک کردن یادداشت");clear.setOnClickListener(v->{NexaStore.setUnlockNote(this,"");note.setText("");});
        once.addView(clear,UiKit.matchWrap(this,8,0));root.addView(once,UiKit.matchWrap(this,0,12));
        Button quick=UiKit.primaryButton(this,"＋ ثبت سریع");quick.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        root.addView(quick);setContentView(sc);
    }
    private void addSection(LinearLayout root,String header,List<Item> list,int variant,String empty){
        LinearLayout card=UiKit.colorfulCardLayout(this,variant);card.addView(UiKit.sectionTitle(this,header+" ("+list.size()+")"));
        if(list.isEmpty())card.addView(UiKit.muted(this,empty),UiKit.matchWrap(this,7,0));
        for(Item i:list){
            String status=i.done?"انجام‌شده":i.at<System.currentTimeMillis()?"معوق":"در انتظار";
            int tone=i.done?UiKit.GREEN:i.at<System.currentTimeMillis()?UiKit.RED:UiKit.PURPLE;
            LinearLayout row=NexaAgendaUi.event(this,i.icon,i.title,
                    PersianDateUtil.pretty(i.at)+" • "+i.subtitle,status,tone,true);
            row.setOnClickListener(v->startActivity(new Intent(this,i.page)));
            card.addView(row,UiKit.matchWrap(this,8,0));
        }
        root.addView(card,UiKit.matchWrap(this,0,12));
    }
}
