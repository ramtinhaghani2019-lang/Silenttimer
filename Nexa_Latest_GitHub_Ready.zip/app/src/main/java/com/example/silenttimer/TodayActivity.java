package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.view.Gravity;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;

/** Real calendar-day overview, with separate overdue and completed items. */
public class TodayActivity extends Activity {
    private static class Item {
        long at;String title,subtitle,icon;boolean done;Class<?> page;
        Item(long when,String icon,String title,String sub,boolean done,Class<?> page){
            this.at=when;this.icon=icon;this.title=title;this.subtitle=sub;this.done=done;this.page=page;}
    }
    private static final String KEY_NOTE_DRAFT="today_note_draft_222";
    private static final String KEY_SCROLL="today_scroll_222";
    private static final String KEY_COMPLETED="today_completed_222";
    private static final String KEY_TOMORROW="today_tomorrow_222";
    private static final String KEY_WEEK="today_week_222";
    private static final String KEY_OVERDUE="today_overdue_222";
    private static final String KEY_CURRENT="today_current_222";
    private ScrollView pageScroll;
    private EditText noteField;
    private String noteDraft;
    private boolean completedExpanded=false,tomorrowExpanded=false,weekExpanded=false;
    private boolean overdueExpanded=true,currentExpanded=true,firstResume=true;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);UiKit.applyWindow(this);
        if(state!=null){
            noteDraft=state.getString(KEY_NOTE_DRAFT);
            completedExpanded=state.getBoolean(KEY_COMPLETED,false);
            tomorrowExpanded=state.getBoolean(KEY_TOMORROW,false);
            weekExpanded=state.getBoolean(KEY_WEEK,false);
            overdueExpanded=state.getBoolean(KEY_OVERDUE,true);
            currentExpanded=state.getBoolean(KEY_CURRENT,true);
        }
        build();
        if(state!=null&&pageScroll!=null){
            int y=state.getInt(KEY_SCROLL,0);
            pageScroll.post(()->pageScroll.scrollTo(0,y));
        }
    }
    @Override protected void onResume(){
        super.onResume();
        if(firstResume){firstResume=false;return;}
        // Refresh deadlines after returning from an editor without losing the user's place or draft.
        captureDraft();
        int y=pageScroll==null?0:pageScroll.getScrollY();
        build();
        if(pageScroll!=null)pageScroll.post(()->pageScroll.scrollTo(0,y));
    }
    @Override protected void onSaveInstanceState(Bundle state){
        captureDraft();
        if(noteDraft!=null)state.putString(KEY_NOTE_DRAFT,noteDraft);
        state.putInt(KEY_SCROLL,pageScroll==null?0:pageScroll.getScrollY());
        state.putBoolean(KEY_COMPLETED,completedExpanded);
        state.putBoolean(KEY_TOMORROW,tomorrowExpanded);
        state.putBoolean(KEY_WEEK,weekExpanded);
        state.putBoolean(KEY_OVERDUE,overdueExpanded);
        state.putBoolean(KEY_CURRENT,currentExpanded);
        super.onSaveInstanceState(state);
    }
    private void captureDraft(){if(noteField!=null)noteDraft=noteField.getText().toString();}
    private void navigate(Class<?> target){startActivity(new Intent(this,target));finish();}
    private void add(List<Item> all,long when,String icon,String title,String sub,boolean done,Class<?> page){
        if(when>0)all.add(new Item(when,icon,title,sub,done,page));
    }
    private void build(){
        long now=System.currentTimeMillis();Calendar c=Calendar.getInstance();
        c.setTimeInMillis(now);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);
        c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);long start=c.getTimeInMillis();
        long end=AgendaDuePolicy.afterCalendarDays(start,1);
        long tomorrowEnd=AgendaDuePolicy.afterCalendarDays(start,2);
        long next7End=AgendaDuePolicy.afterCalendarDays(start,8);
        List<Item> items=new ArrayList<>();
        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            if(!r.sourceKey.isEmpty())continue; // linked events are shown from their origin modules
            if(!AgendaDuePolicy.includeReminder(r.active,r.done))continue;
            long shown=r.done?r.whenMillis:AgendaDuePolicy.shownDue(r.whenMillis,r.recurrence,start);
            add(items,shown,r.icon,r.title,r.category+ReminderRecurrence.labelSuffix(r.recurrence),
                    r.done,RemindersActivity.class);
        }
        for(OccasionStore.Occasion e:OccasionStore.all(this))if(e.active){
            long at=AnnualOccasionDates.next(e,start-1);
            add(items,at,e.icon(),e.title,e.typeLabel()+" • تکرار سالانه",false,AnnualOccasionsActivity.class);
        }
        for(NexaStore.Medicine m:NexaStore.medicines(this))if(m.active)
            add(items,m.nextDoseMillis,"💊",m.name,m.dose,false,MedicineActivity.class);
        for(NexaStore.CaseItem x:NexaStore.cases(this))
            add(items,x.whenMillis,"⚖️",x.title,"جلسه دادگاه • "+x.court,false,CaseActivity.class);
        for(NexaStore.BillItem x:NexaStore.bills(this))
            add(items,x.dueDate,"💳",x.title,x.type,x.paid,BillsActivity.class);
        for(NexaStore.DocumentItem x:NexaStore.documents(this))
            add(items,x.expiryDate,"📄",x.title,"انقضای مدرک",false,DocsActivity.class);
        for(NexaStore.HomeItem x:NexaStore.homeItems(this))
            add(items,x.nextDueDate,"🏠",x.title,x.category,false,HomeCareActivity.class);
        for(NexaStore.TodoItem x:NexaStore.todos(this))
            add(items,x.dueMillis,"✓",x.title,x.category,x.done,NexaListActivity.class);
        for(NexaStore.ServiceRecord x:NexaStore.services(this))if(x.nextDueDate>0)
            add(items,x.nextDueDate,"🚗",x.category,"سرویس خودرو",false,GarageActivity.class);
        List<Item> undone=new ArrayList<>(),completed=new ArrayList<>(),overdue=new ArrayList<>(),tomorrow=new ArrayList<>(),next7=new ArrayList<>();
        for(Item i:items){
            switch(AgendaDuePolicy.bucket(i.at,i.done,start,end,tomorrowEnd,next7End)){
                case AgendaDuePolicy.COMPLETED: completed.add(i);break;
                case AgendaDuePolicy.OVERDUE: overdue.add(i);break;
                case AgendaDuePolicy.TODAY: undone.add(i);break;
                case AgendaDuePolicy.TOMORROW: tomorrow.add(i);break;
                case AgendaDuePolicy.LATER_THIS_WEEK: next7.add(i);break;
                default:break;
            }
        }
        undone.sort(Comparator.comparingLong(i->i.at));
        completed.sort(Comparator.comparingLong(i->i.at));
        overdue.sort((a,b)->Long.compare(b.at,a.at));
        tomorrow.sort(Comparator.comparingLong(i->i.at));
        next7.sort(Comparator.comparingLong(i->i.at));
        LinearLayout frame=new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.setBackground(UiKit.screenBackground(this));
        ScrollView sc=new ScrollView(this);pageScroll=sc;
        sc.setFillViewport(true);sc.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,12),UiKit.dp(this,10),UiKit.dp(this,12),UiKit.dp(this,14));
        sc.addView(root);
        frame.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));
        root.addView(UiKit.header(this,"برنامه امروز",v->finish()),UiKit.matchWrap(this,0,1));
        TextView todayDate=UiKit.muted(this,PersianDateUtil.pretty(now));
        todayDate.setTextSize(11.5f);
        root.addView(todayDate,UiKit.matchWrap(this,0,7));

        // Keep the two most useful actions above the fold: no need to scroll to add work.
        LinearLayout topActions=new LinearLayout(this);
        boolean stackTop=HomeUi.compactGridNeedsStack(this);
        topActions.setOrientation(stackTop?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        topActions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button quick=UiKit.primaryButton(this,"＋ ثبت سریع");
        quick.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        Button newReminder=UiKit.secondaryButton(this,"یادآور جدید");
        newReminder.setOnClickListener(v->startActivity(new Intent(this,ReminderEditActivity.class)));
        if(stackTop){
            topActions.addView(quick,new LinearLayout.LayoutParams(-1,-2));
            topActions.addView(newReminder,UiKit.matchWrap(this,7,0));
        }else{
            topActions.addView(quick,new LinearLayout.LayoutParams(0,-2,1f));
            LinearLayout.LayoutParams actionLp=new LinearLayout.LayoutParams(0,-2,1f);
            actionLp.setMargins(UiKit.dp(this,8),0,0,0);
            topActions.addView(newReminder,actionLp);
        }
        root.addView(topActions,UiKit.matchWrap(this,0,9));
        root.addView(NexaAgendaUi.stats(this,
                new String[]{"امروز","معوق","انجام‌شده"},
                new String[]{String.valueOf(undone.size()),String.valueOf(overdue.size()),String.valueOf(completed.size())},
                new int[]{UiKit.GOLD,UiKit.RED,UiKit.GREEN}),UiKit.matchWrap(this,0,10));
        Item next=null; for(Item i:items) if(!i.done && i.at>=now && (next==null || i.at<next.at)) next=i;
        long unpaid=0;
        for(NexaStore.BillItem x:NexaStore.bills(this))
            if(!x.paid && x.dueDate>0 && x.dueDate<next7End) unpaid+=x.amount;
        if(next!=null||unpaid>0){
            LinearLayout summary=UiKit.cardLayout(this);
            if(next!=null){
                final Item upcoming=next;
                TextView nextLink=UiKit.muted(this,"موعد بعدی: "+next.title+" • "+PersianDateUtil.pretty(next.at));
                nextLink.setTextColor(UiKit.TEXT);nextLink.setMinHeight(UiKit.dp(this,48));
                nextLink.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
                nextLink.setClickable(true);nextLink.setFocusable(true);
                nextLink.setContentDescription("رفتن به "+next.title);
                nextLink.setOnClickListener(v->startActivity(new Intent(this,upcoming.page)));
                summary.addView(nextLink);
            }
            if(unpaid>0)summary.addView(UiKit.muted(this,"تعهد مالی تا ۷ روز: "+NumberFormatUtil.format(unpaid)+" تومان"),UiKit.matchWrap(this,6,0));
            root.addView(summary,UiKit.matchWrap(this,0,9));
        }
        if(undone.isEmpty()&&completed.isEmpty()&&overdue.isEmpty()&&tomorrow.isEmpty()&&next7.isEmpty()){
            root.addView(UiKit.emptyState(this,"برنامه‌ات خالی است","یک یادآور یا مناسبت جدید ثبت کن تا اینجا دیده شود."),
                    UiKit.matchWrap(this,0,12));
        }
        // Active work is visible first; completed and future lists are opt-in to avoid a wall of cards.
        addSection(root,"🔴 معوق و پیگیری‌نشده",overdue,3,"",overdueExpanded,"overdue");
        addSection(root,"⏳ انجام‌نشده امروز",undone,1,"",currentExpanded,"today");
        addSection(root,"✓ انجام‌شده امروز",completed,2,"",completedExpanded,"completed");
        addSection(root,"☀️ پیش‌نمایش فردا",tomorrow,0,"",tomorrowExpanded,"tomorrow");
        addSection(root,"📆 روزهای ۲ تا ۷ آینده",next7,6,"",weekExpanded,"week");
        LinearLayout garage=UiKit.colorfulCardLayout(this,0);
        garage.addView(UiKit.sectionTitle(this,"🚗 هشدارهای کیلومتری"));int dueCount=0;
        for(NexaStore.Vehicle v:NexaStore.vehicles(this)){
            java.util.Map<String,NexaStore.ServiceRecord> newest=new java.util.HashMap<>();
            for(NexaStore.ServiceRecord r:NexaStore.servicesFor(this,v.id))
                if(r.nextDueKm>0&&!newest.containsKey(r.category))newest.put(r.category,r);
            for(NexaStore.ServiceRecord r:newest.values())if(v.currentKm>=r.nextDueKm){
                dueCount++;TextView t=UiKit.muted(this,v.name+" • "+r.category+" • "+(v.currentKm-r.nextDueKm)+" کیلومتر دیرکرد");
                t.setTextColor(UiKit.PINK);garage.addView(t,UiKit.matchWrap(this,7,0));
            }
        }
        if(dueCount>0){
            garage.setOnClickListener(v->startActivity(new Intent(this,GarageActivity.class)));
            root.addView(garage,UiKit.matchWrap(this,0,12));
        }
        LinearLayout actions=new LinearLayout(this);
        boolean stackActions=HomeUi.compactGridNeedsStack(this);
        actions.setOrientation(stackActions?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button history=UiKit.secondaryButton(this,"🎂 مناسبت‌ها");history.setOnClickListener(v->startActivity(new Intent(this,AnnualOccasionsActivity.class)));
        Button search=UiKit.secondaryButton(this,"⌕ جستجو");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        if(stackActions){
            actions.addView(history,new LinearLayout.LayoutParams(-1,-2));
            LinearLayout.LayoutParams searchLp=UiKit.matchWrap(this,8,0);
            actions.addView(search,searchLp);
        }else{
            actions.addView(history,new LinearLayout.LayoutParams(0,-2,1f));
            LinearLayout.LayoutParams searchLp=new LinearLayout.LayoutParams(0,-2,1f);
            searchLp.setMargins(UiKit.dp(this,8),0,0,0);
            actions.addView(search,searchLp);
        }
        root.addView(actions,UiKit.matchWrap(this,0,8));
        LinearLayout once=new LinearLayout(this);
        once.setOrientation(LinearLayout.VERTICAL);
        once.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        EditText note=new EditText(this);noteField=note;
        note.setTextColor(UiKit.TEXT);note.setHintTextColor(UiKit.MUTED);
        note.setHint("یادداشت کوتاه...");
        note.setText(noteDraft==null?NexaStore.unlockNote(this):noteDraft);
        note.setBackground(UiKit.field(this));once.addView(note,UiKit.matchWrap(this,10,8));
        Button save=UiKit.secondaryButton(this,"ذخیره یادداشت");
        save.setOnClickListener(v->{
            String content=note.getText().toString().trim();
            NexaStore.setUnlockNote(this,content);noteDraft=content;
            android.widget.Toast.makeText(this,"یادداشت ذخیره شد.",android.widget.Toast.LENGTH_SHORT).show();
        });
        once.addView(save);
        Button clear=UiKit.secondaryButton(this,"پاک کردن یادداشت");
        clear.setOnClickListener(v->{NexaStore.setUnlockNote(this,"");noteDraft="";note.setText("");});
        once.addView(clear,UiKit.matchWrap(this,8,0));
        LinearLayout notePanel=UiKit.collapsible(this,"today_unlock_note_210",
                "🔓 یادداشت بازکردن گوشی","در صورت نیاز باز کن",4,false,once);
        root.addView(notePanel,UiKit.matchWrap(this,0,8));
        LinearLayout nav=UiKit.referenceBottomNav(this,1);
        LinearLayout.LayoutParams navLp=new LinearLayout.LayoutParams(-1,-2);
        navLp.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,12),UiKit.dp(this,9));
        frame.addView(nav,navLp);
        setContentView(frame);
    }
    /** Create a clean section with the first batch only, preserving all remaining entries. */
    private void addSection(LinearLayout root,String header,List<Item> list,int variant,String empty,
                            boolean initiallyExpanded,String savedState){
        if(list==null||list.isEmpty())return;
        LinearLayout card=UiKit.cardLayout(this);
        LinearLayout heading=new LinearLayout(this);
        heading.setOrientation(LinearLayout.HORIZONTAL);
        heading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.setMinimumHeight(UiKit.dp(this,44));
        TextView label=UiKit.sectionTitle(this,header+" ("+list.size()+")");
        label.setTextSize(14f);
        if(variant==3)label.setTextColor(UiKit.RED);
        else if(variant==2)label.setTextColor(UiKit.GREEN);
        heading.addView(label,new LinearLayout.LayoutParams(0,-2,1f));
        TextView arrow=UiKit.muted(this,initiallyExpanded?"⌃":"⌄");
        arrow.setTextSize(19f);arrow.setGravity(Gravity.CENTER);
        heading.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(this,30),UiKit.dp(this,44)));
        card.addView(heading);
        LinearLayout body=new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        body.setVisibility(initiallyExpanded?View.VISIBLE:View.GONE);
        card.addView(body);
        int[] displayed={0};
        Button more=UiKit.secondaryButton(this,"نمایش بیشتر");
        more.setOnClickListener(v->appendBatch(body,list,displayed,more));
        if(initiallyExpanded)appendBatch(body,list,displayed,more);
        heading.setClickable(true);heading.setFocusable(true);
        UiKit.touchFeedback(this,heading,UiKit.PURPLE,12);
        setHeadingDescription(heading,header,initiallyExpanded,list.size());
        heading.setOnClickListener(v->{
            boolean open=body.getVisibility()!=View.VISIBLE;
            body.setVisibility(open?View.VISIBLE:View.GONE);
            if(open&&displayed[0]==0)appendBatch(body,list,displayed,more);
            arrow.setText(open?"⌃":"⌄");
            setHeadingDescription(heading,header,open,list.size());
            if("completed".equals(savedState))completedExpanded=open;
            else if("tomorrow".equals(savedState))tomorrowExpanded=open;
            else if("week".equals(savedState))weekExpanded=open;
            else if("overdue".equals(savedState))overdueExpanded=open;
            else if("today".equals(savedState))currentExpanded=open;
        });
        card.setPadding(UiKit.dp(this,11),UiKit.dp(this,7),UiKit.dp(this,11),UiKit.dp(this,9));
        root.addView(card,UiKit.matchWrap(this,0,8));
    }
    private void setHeadingDescription(View heading,String title,boolean open,int count){
        heading.setContentDescription((open?"بستن ":"نمایش ")+title+"، "+count+" مورد");
    }
    private void appendBatch(LinearLayout body,List<Item> items,int[] displayed,Button more){
        body.removeView(more);
        int end=TodayPresentationPolicy.nextVisibleCount(items.size(),displayed[0]);
        for(int index=displayed[0];index<end;index++){
            Item i=items.get(index);
            String status=i.done?"انجام‌شده":i.at<System.currentTimeMillis()?"معوق":"در انتظار";
            int tone=i.done?UiKit.GREEN:i.at<System.currentTimeMillis()?UiKit.RED:UiKit.PURPLE;
            String detail=PersianDateUtil.pretty(i.at)+
                    (i.subtitle==null||i.subtitle.trim().isEmpty()?"":" • "+i.subtitle);
            LinearLayout row=NexaAgendaUi.event(this,i.icon,i.title,detail,"",tone,true);
            row.setContentDescription(status+"، "+i.title+"، "+PersianDateUtil.pretty(i.at));
            row.setClickable(true);row.setFocusable(true);
            row.setOnClickListener(v->startActivity(new Intent(this,i.page)));
            body.addView(row,UiKit.matchWrap(this,5,0));
        }
        displayed[0]=end;
        if(end<items.size()){
            more.setText("نمایش "+Math.min(TodayPresentationPolicy.PAGE_SIZE,items.size()-end)+" مورد دیگر");
            more.setContentDescription("نمایش رویدادهای بیشتر، "+(items.size()-end)+" مورد باقی‌مانده");
            body.addView(more,UiKit.matchWrap(this,7,0));
        }
    }
}
