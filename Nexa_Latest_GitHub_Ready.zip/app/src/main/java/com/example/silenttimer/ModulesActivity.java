package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Full-width RTL module directory: fixed filters, grouped short rows, real pictograms. */
public final class ModulesActivity extends Activity {
    private static final String KEY_QUERY="modules_query", KEY_GROUP="modules_group";
    private static final String[] SHORT_GROUPS={"همه", "مالی و اسناد", "زندگی و سلامت", "هشدارها", "ابزارها"};
    private static final int[] ACCENTS={0xFFE5BB62,0xFFF2CA75,0xFF65CBB4,0xFFC0A3E8,0xFF83C5E8};
    private int group=0;
    private EditText search;
    private LinearLayout results, filters;
    private HorizontalScrollView filterStrip;
    private ScrollView listScroll;
    private TextView count,clear;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        UiKit.applyWindow(this);
        if(state!=null)group=Math.max(0,Math.min(ModulesCatalog.GROUPS.length-1,state.getInt(KEY_GROUP,0)));
        build(state==null?"":state.getString(KEY_QUERY,""));
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putInt(KEY_GROUP,group);
        state.putString(KEY_QUERY,search==null?"":search.getText().toString());
        super.onSaveInstanceState(state);
    }
    private static GradientDrawable surface(int fill,int border,int radius,Activity a){
        GradientDrawable bg=UiKit.rounded(a,fill,radius);
        if(border!=0)bg.setStroke(UiKit.dp(a,1),border);
        return bg;
    }
    private void build(String priorQuery){
        LinearLayout frame=new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.setBackground(UiKit.screenBackground(this));
        frame.setPadding(UiKit.dp(this,12),0,UiKit.dp(this,12),0);
        frame.addView(UiKit.header(this,"بخش‌های نکسا",v->finish()),new LinearLayout.LayoutParams(-1,UiKit.dp(this,50)));

        // A single, calm search surface. The clear action is shown only for actual text.
        LinearLayout searchBar=new LinearLayout(this);
        searchBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(UiKit.dp(this,11),0,UiKit.dp(this,5),0);
        searchBar.setBackground(surface(0xFF10283C,0xFF465778,14,this));
        NexaOutlineIcon magnifier=new NexaOutlineIcon(this,"search",0xFFE5BB62);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(UiKit.dp(this,22),UiKit.dp(this,22));
        mp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,11),0);
        searchBar.addView(magnifier,mp);
        search=new EditText(this);
        search.setTag("nexa_directory_search_field");
        search.setTextSize(14.5f);search.setTypeface(UiKit.appFace(this,false));
        search.setSingleLine(true);search.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        search.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        search.setHint("جست‌وجو در بخش‌ها");
        search.setHintTextColor(0xFF9FADC2);search.setTextColor(0xFFF4F7FF);
        search.setPadding(0,0,0,0);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setContentDescription("جست‌وجوی بخش‌های نکسا");
        searchBar.addView(search,new LinearLayout.LayoutParams(0,UiKit.dp(this,44),1f));
        clear=new TextView(this);
        clear.setText("×");clear.setTextColor(0xFFD5E4F7);clear.setTextSize(22);
        clear.setGravity(Gravity.CENTER);clear.setClickable(true);clear.setFocusable(true);
        clear.setContentDescription("پاک کردن عبارت جست‌وجو");
        UiKit.touchFeedback(this,clear,0xFF8BABFF,10);
        clear.setOnClickListener(v->search.setText(""));
        searchBar.addView(clear,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,44)));
        frame.addView(searchBar,UiKit.matchWrap(this,3,9));

        // One horizontal category rail replaces two tall filter rows. The chosen
        // group remains visible when state is restored after rotation.
        filterStrip=new HorizontalScrollView(this);
        filterStrip.setHorizontalScrollBarEnabled(false);
        filterStrip.setFillViewport(false);
        filterStrip.setOverScrollMode(View.OVER_SCROLL_NEVER);
        filters=new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setGravity(Gravity.CENTER_VERTICAL);
        filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        filters.setPadding(UiKit.dp(this,1),0,UiKit.dp(this,1),0);
        filterStrip.addView(filters,new android.widget.FrameLayout.LayoutParams(-2,-2));
        frame.addView(filterStrip,UiKit.matchWrap(this,0,6));
        count=UiKit.muted(this,"");count.setTextSize(11f);
        count.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        frame.addView(count,UiKit.matchWrap(this,0,4));

        listScroll=new ScrollView(this);
        listScroll.setFillViewport(true);listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setClipToPadding(false);
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
        results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        results.setPadding(0,0,0,UiKit.dp(this,18));
        listScroll.addView(results);
        frame.addView(listScroll,new LinearLayout.LayoutParams(-1,0,1f));

        LinearLayout nav=UiKit.referenceBottomNav(this,3);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);
        np.setMargins(0,UiKit.dp(this,4),0,UiKit.dp(this,6));
        frame.addView(nav,np);
        setContentView(frame);

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int n,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int n){
                clear.setVisibility(s.length()>0?View.VISIBLE:View.GONE);
                redraw();listScroll.scrollTo(0,0);
            }
            public void afterTextChanged(Editable s){}
        });
        search.setText(priorQuery);
        clear.setVisibility(priorQuery.isEmpty()?View.GONE:View.VISIBLE);
        redrawFilters();redraw();
    }
    private void navigate(Class<?> target){startActivity(new Intent(this,target));finish();}
    private void redrawFilters(){
        filters.removeAllViews();
        for(int next=0;next<SHORT_GROUPS.length;next++){
            final int selectedGroup=next;
            boolean active=next==group;
            TextView chip=new TextView(this);
            chip.setText(SHORT_GROUPS[next]);
            chip.setTextSize(11.5f);
            chip.setTypeface(UiKit.appFace(this,active));
            chip.setGravity(Gravity.CENTER);
            chip.setSingleLine(true);
            chip.setMinHeight(UiKit.dp(this,38));
            chip.setPadding(UiKit.dp(this,13),0,UiKit.dp(this,13),0);
            chip.setTextColor(active?0xFF092037:0xFFCDD7E5);
            chip.setBackground(surface(active?0xFFE5BB62:0xFF142B44,
                    active?0xFFE5BB62:0xFF3C506C,12,this));
            chip.setClickable(true);chip.setFocusable(true);
            chip.setContentDescription(ModulesCatalog.GROUPS[next]+
                    (active?"، انتخاب‌شده":"، نمایش دسته"));
            chip.setOnClickListener(v->{
                group=selectedGroup;
                redrawFilters();redraw();listScroll.scrollTo(0,0);
            });
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,38));
            lp.setMargins(0,0,UiKit.dp(this,7),0);
            filters.addView(chip,lp);
            if(active){
                filterStrip.post(()->{
                    // Ignore a stale posted chip after a rapid filter change.
                    if(chip.getParent()!=filters)return;
                    android.graphics.Rect rect=new android.graphics.Rect();
                    chip.getDrawingRect(rect);
                    filterStrip.requestChildRectangleOnScreen(chip,rect,true);
                });
            }
        }
    }
    private LinearLayout moduleRow(ModulesCatalog.Item item){
        int color=ACCENTS[item.group];
        LinearLayout line=new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);line.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setMinimumHeight(UiKit.dp(this,60));
        line.setPadding(UiKit.dp(this,12),UiKit.dp(this,7),UiKit.dp(this,10),UiKit.dp(this,7));
        LinearLayout tile=new LinearLayout(this);
        tile.setGravity(Gravity.CENTER);tile.setBackground(surface(UiKit.withAlpha(color,0x26),0,12,this));
        NexaOutlineIcon icon=new NexaOutlineIcon(this,iconKind(item),color);
        tile.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,24),UiKit.dp(this,24)));
        line.addView(tile,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));
        TextView label=UiKit.sectionTitle(this,item.title);label.setTextSize(14.5f);
        label.setTextColor(0xFFF4F7FB);label.setMaxLines(2);
        label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        lp.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,7),0);
        line.addView(label,lp);
        TextView arrow=UiKit.muted(this,"‹");arrow.setTextSize(22f);arrow.setGravity(Gravity.CENTER);
        line.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(this,22),UiKit.dp(this,40)));
        line.setContentDescription(item.title+"، "+moduleSubtitle(item)+"، باز کردن");
        line.setClickable(true);line.setFocusable(true);
        UiKit.touchFeedback(this,line,color,14);
        line.setOnClickListener(v->startActivity(new Intent(this,item.destination)));
        return line;
    }
    private String moduleSubtitle(ModulesCatalog.Item item){
        Class<?> type=item.destination;
        if(type==AssetsActivity.class)return "دارایی و سرمایه";
        if(type==LedgerActivity.class)return "بدهی، طلب و پرداخت";
        if(type==BillsActivity.class)return "قبض، قسط و سررسید";
        if(type==DocsActivity.class)return "مدارک و انقضا";
        if(type==SharedEntitiesActivity.class)return "اشخاص و حساب‌ها";
        if(type==MedicineActivity.class)return "ثبت و پیگیری دارو";
        if(type==GarageActivity.class)return "سرویس و سوخت";
        if(type==HomeCareActivity.class)return "نگهداری خانه";
        if(type==CaseActivity.class)return "پرونده‌های حقوقی";
        if(type==WeatherActivity.class)return "وضعیت و پیش‌بینی";
        if(type==RemindersActivity.class)return "هشدار و تکرار";
        if(type==AnnualOccasionsActivity.class)return "تولد و سالگرد";
        if(type==SilentHubActivity.class)return "سکوت و تمرکز";
        if(type==BatteryGuardActivity.class)return "مدیریت هشدار شارژ";
        if(type==EmergencyActivity.class)return "دسترسی اضطراری";
        if(type==VaultActivity.class)return "حریم خصوصی";
        if(type==FileCenterActivity.class)return "فایل‌ها و فاکتورها";
        if(type==SearchActivity.class)return "پیدا کردن موارد";
        if(type==TimelineActivity.class)return "رویدادهای زمانی";
        if(type==HistoryActivity.class)return "سوابق فعالیت";
        if(type==SettingsActivity.class)return "تنظیمات برنامه";
        if(type==NexaListActivity.class)return "خریدها و کارها";
        return ModulesCatalog.GROUPS[item.group];
    }
    private String iconKind(ModulesCatalog.Item item){
        Class<?> type=item.destination;
        if(type==AssetsActivity.class)return "assets";
        if(type==LedgerActivity.class)return "ledger";
        if(type==BillsActivity.class)return "bills";
        if(type==DocsActivity.class)return "docs";
        if(type==SharedEntitiesActivity.class)return "shared";
        if(type==MedicineActivity.class)return "medicine";
        if(type==GarageActivity.class)return "vehicle";
        if(type==HomeCareActivity.class)return "home";
        if(type==CaseActivity.class)return "case";
        if(type==WeatherActivity.class)return "weather";
        if(type==RemindersActivity.class)return "reminders";
        if(type==AnnualOccasionsActivity.class)return "occasions";
        if(type==SilentHubActivity.class)return "silent";
        if(type==BatteryGuardActivity.class)return "battery";
        if(type==EmergencyActivity.class)return "emergency";
        if(type==VaultActivity.class)return "vault";
        if(type==FileCenterActivity.class)return "files";
        if(type==SearchActivity.class)return "search";
        if(type==TimelineActivity.class)return "timeline";
        if(type==HistoryActivity.class)return "history";
        if(type==SettingsActivity.class)return "settings";
        if(type==NexaListActivity.class)return "lists";
        return "docs";
    }
    private View divider(){
        View line=new View(this);
        line.setBackgroundColor(0xFF2D3B4E);
        return line;
    }
    private void redraw(){
        if(results==null||search==null)return;
        results.removeAllViews();
        List<ModulesCatalog.Item> visible=ModulesCatalog.filter(search.getText().toString(),group);
        count.setText(visible.size()+" بخش"+(group==0?"":" • "+ModulesCatalog.GROUPS[group]));
        // Native three-column design matches the reference on normal phones.
        // Bigger accessibility fonts still get wide, readable rows.
        float density=getResources().getDisplayMetrics().density;
        float availableDp=getResources().getDisplayMetrics().widthPixels/density-24f;
        float fontScale=getResources().getConfiguration().fontScale;
        int columns=(availableDp<295f || fontScale>=1.40f)?1:
                ((availableDp>=326f && fontScale<1.22f)?3:2);
        if(columns==1){
            for(ModulesCatalog.Item item:visible){
                LinearLayout row=moduleRow(item);
                row.setBackground(surface(0xFF11243D,0xFF354C68,13,this));
                results.addView(row,UiKit.matchWrap(this,0,7));
            }
        }else{
            LinearLayout tileRow=null;
            for(int i=0;i<visible.size();i++){
                if(i%columns==0){
                    tileRow=new LinearLayout(this);
                    tileRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                    tileRow.setGravity(Gravity.TOP);
                    results.addView(tileRow,UiKit.matchWrap(this,0,7));
                }
                ModulesCatalog.Item item=visible.get(i);
                LinearLayout tile=new LinearLayout(this);
                tile.setOrientation(LinearLayout.VERTICAL);
                tile.setGravity(Gravity.CENTER);
                tile.setPadding(UiKit.dp(this,3),UiKit.dp(this,8),
                        UiKit.dp(this,3),UiKit.dp(this,7));
                GradientDrawable card=new GradientDrawable(
                        GradientDrawable.Orientation.TL_BR,
                        new int[]{0xFF24303A,0xFF0A1D2C,0xFF0C1620});
                card.setCornerRadius(UiKit.dp(this,15));
                card.setStroke(UiKit.dp(this,1),0xFFA0814B);
                tile.setBackground(card);
                int accent=ACCENTS[item.group];
                NexaOutlineIcon icon=new NexaOutlineIcon(this,iconKind(item),UiKit.GOLD);
                tile.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,columns==3?32:29),UiKit.dp(this,columns==3?32:29)));
                TextView label=UiKit.sectionTitle(this,item.title);
                label.setTextColor(0xFFF7F5ED);label.setTextSize(columns==3?11.2f:13f);
                label.setGravity(Gravity.CENTER);label.setMaxLines(2);
                label.setEllipsize(android.text.TextUtils.TruncateAt.END);
                tile.addView(label,UiKit.matchWrap(this,5,0));
                TextView details=UiKit.muted(this,moduleSubtitle(item));
                details.setTextSize(10.5f);details.setGravity(Gravity.CENTER);
                details.setTextColor(0xFFABB9CE);details.setSingleLine(true);
                details.setEllipsize(android.text.TextUtils.TruncateAt.END);
                if(columns!=3)tile.addView(details,UiKit.matchWrap(this,1,0));
                tile.setContentDescription(item.title+"، "+moduleSubtitle(item)+"، باز کردن");
                tile.setClickable(true);tile.setFocusable(true);
                UiKit.touchFeedback(this,tile,accent,15);
                tile.setOnClickListener(v->startActivity(new Intent(this,item.destination)));
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,UiKit.dp(this,columns==3?93:96),1f);
                lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
                tileRow.addView(tile,lp);
                if(i==visible.size()-1 && (i+1)%columns!=0){
                    int missing=columns-(i+1)%columns;
                    for(int k=0;k<missing;k++){
                        View spacer=new View(this);
                        tileRow.addView(spacer,new LinearLayout.LayoutParams(0,1,1f));
                    }
                }
            }
        }
        if(visible.isEmpty()){
            TextView empty=UiKit.emptyState(this,"بخشی پیدا نشد","جست‌وجو یا دسته را تغییر بده.");
            results.addView(empty,UiKit.matchWrap(this,12,8));
            TextView showAll=UiKit.chip(this,"نمایش همه بخش‌ها",true);
            showAll.setMinimumHeight(UiKit.dp(this,48));
            showAll.setClickable(true);showAll.setFocusable(true);
            showAll.setOnClickListener(v->{group=0;search.setText("");redrawFilters();redraw();});
            results.addView(showAll,UiKit.matchWrap(this,4,10));
        }
    }
}
