package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Dedicated, searchable module directory. Back returns to this exact list after visiting a tool. */
public final class ModulesActivity extends Activity {
    private static final String KEY_QUERY="modules_query",KEY_GROUP="modules_group";
    private int group=0;
    private EditText search;
    private LinearLayout results,filters;
    private TextView count;
    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        UiKit.applyWindow(this);
        if(state!=null)group=Math.max(0,Math.min(ModulesCatalog.GROUPS.length-1,state.getInt(KEY_GROUP,0)));
        build(state==null?"":state.getString(KEY_QUERY,""));
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putInt(KEY_GROUP,group);
        state.putString(KEY_QUERY,search==null?"":search.getText().toString());
        super.onSaveInstanceState(state);
    }
    private void build(String priorQuery){
        LinearLayout frame=new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.setBackground(UiKit.screenBackground(this));
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        content.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,14));
        frame.addView(UiKit.header(this,"بخش‌های نکسا",v->finish()),new LinearLayout.LayoutParams(-1,UiKit.dp(this,64)));
        LinearLayout inputRow=new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        inputRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        search=UiKit.styleField(this,new EditText(this),"جست‌وجوی بخش؛ مثل قسط، دارو، کارت");
        search.setSingleLine(true);
        search.setTextSize(14f);
        search.setContentDescription("جست‌وجوی بخش‌های نکسا");
        inputRow.addView(search,new LinearLayout.LayoutParams(0,-2,1f));
        TextView clear=UiKit.chip(this,"×",false);
        clear.setTextSize(24f);clear.setMinWidth(UiKit.dp(this,48));clear.setMinimumWidth(UiKit.dp(this,48));
        clear.setMinHeight(UiKit.dp(this,48));clear.setMinimumHeight(UiKit.dp(this,48));
        clear.setClickable(true);clear.setFocusable(true);
        clear.setContentDescription("پاک کردن عبارت جست‌وجو");
        clear.setOnClickListener(v->search.setText(""));
        LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        cp.setMargins(UiKit.dp(this,8),0,0,0);inputRow.addView(clear,cp);
        content.addView(inputRow,UiKit.matchWrap(this,4,9));
        HorizontalScrollView categoryScroll=new HorizontalScrollView(this);
        categoryScroll.setHorizontalScrollBarEnabled(false);
        filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        categoryScroll.addView(filters);
        content.addView(categoryScroll,UiKit.matchWrap(this,0,8));
        count=UiKit.muted(this,"");count.setTextSize(12.5f);
        content.addView(count,UiKit.matchWrap(this,0,9));
        frame.addView(content,new LinearLayout.LayoutParams(-1,-2));
        ScrollView listScroll=new ScrollView(this);
        listScroll.setFillViewport(true);
        listScroll.setVerticalScrollBarEnabled(false);
        results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        results.setPadding(UiKit.dp(this,16),0,UiKit.dp(this,16),UiKit.dp(this,24));
        listScroll.addView(results);
        frame.addView(listScroll,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout nav=UiKit.bottomNav(this,-1,
            v->navigate(MainActivity.class),v->navigate(TodayActivity.class),
            v->navigate(QuickAddActivity.class),v->navigate(TimelineActivity.class));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);
        np.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,12),UiKit.dp(this,9));
        frame.addView(nav,np);
        setContentView(frame);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){redraw();}
            public void afterTextChanged(Editable e){}
        });
        search.setText(priorQuery);
        redrawFilters();redraw();
    }
    private void navigate(Class<?> target){startActivity(new Intent(this,target));finish();}
    private void redrawFilters(){
        filters.removeAllViews();
        for(int i=0;i<ModulesCatalog.GROUPS.length;i++){
            final int next=i;
            TextView chip=UiKit.chip(this,ModulesCatalog.GROUPS[i],i==group);
            chip.setMinHeight(UiKit.dp(this,48));chip.setMinimumHeight(UiKit.dp(this,48));
            chip.setClickable(true);chip.setFocusable(true);
            chip.setContentDescription(ModulesCatalog.GROUPS[i]+(i==group?"، انتخاب‌شده":"، نمایش دسته"));
            chip.setOnClickListener(v->{group=next;redrawFilters();redraw();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);
            if(i>0)lp.setMargins(UiKit.dp(this,7),0,0,0);
            filters.addView(chip,lp);
        }
    }
    private void redraw(){
        if(results==null||search==null)return;
        results.removeAllViews();
        List<ModulesCatalog.Item> visible=ModulesCatalog.filter(search.getText().toString(),group);
        count.setText(visible.size()+" بخش برای نمایش");
        int lastGroup=-1;
        for(ModulesCatalog.Item item:visible){
            if(group==0 && item.group!=lastGroup){
                TextView heading=UiKit.sectionTitle(this,ModulesCatalog.GROUPS[item.group]);
                heading.setTextSize(14f);
                results.addView(heading,UiKit.matchWrap(this,lastGroup==-1?0:12,8));
                lastGroup=item.group;
            }
            LinearLayout row=UiKit.featureDirectoryRow(this,item.mark,item.title,item.group);
            row.setMinimumHeight(UiKit.dp(this,60));
            row.setOnClickListener(v->startActivity(new Intent(this,item.destination)));
            results.addView(row,UiKit.matchWrap(this,0,7));
        }
        if(visible.isEmpty()){
            TextView empty=UiKit.emptyState(this,"بخشی پیدا نشد","جست‌وجو یا دسته را تغییر بده.");
            results.addView(empty,UiKit.matchWrap(this,10,8));
            TextView showAll=UiKit.chip(this,"نمایش همه بخش‌ها",true);
            showAll.setMinHeight(UiKit.dp(this,48));showAll.setMinimumHeight(UiKit.dp(this,48));
            showAll.setClickable(true);showAll.setFocusable(true);
            showAll.setOnClickListener(v->{group=0;search.setText("");redrawFilters();redraw();});
            results.addView(showAll,UiKit.matchWrap(this,4,10));
        }
    }
}
