package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Full-width RTL module directory: fixed filters, grouped short rows, real pictograms. */
public final class ModulesActivity extends Activity {
    private static final String KEY_QUERY="modules_query", KEY_GROUP="modules_group";
    private static final String[] SHORT_GROUPS={"همه", "مالی و اسناد", "زندگی و سلامت", "هشدارها", "ابزارها"};
    private static final int[] ACCENTS={0xFF8BABFF,0xFFF3BD75,0xFF62D6B8,0xFFB3A1FF,0xFF76BDF2};
    private int group=0;
    private EditText search;
    private LinearLayout results, filters;
    private ScrollView listScroll;
    private TextView count,clear;

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        UiKit.applyWindow(this);
        if(state!=null)group=Math.max(0,Math.min(ModulesCatalog.GROUPS.length-1,state.getInt(KEY_GROUP,0)));
        build(state==null?"":state.getString(KEY_QUERY,""));
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putInt(KEY_GROUP,group);
        state.putString(KEY_QUERY,search==null?"":search.getText().toString());
        super.onSaveInstanceState(state);
    }
    private static GradientDrawable surface(int fill,int border,int radius,Activity a){
        GradientDrawable bg=UiKit.rounded(a,fill,radius);
        if(border!=0)bg.setStroke(UiKit.dp(a,1),border);
        return bg;
    }
    private void build(String priorQuery){
        LinearLayout frame=new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.setBackground(UiKit.screenBackground(this));
        frame.setPadding(UiKit.dp(this,14),0,UiKit.dp(this,14),0);
        frame.addView(UiKit.header(this,"بخش‌های نکسا",v->finish()),new LinearLayout.LayoutParams(-1,UiKit.dp(this,56)));

        // A single, calm search surface. The clear action is shown only for actual text.
        LinearLayout searchBar=new LinearLayout(this);
        searchBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setPadding(UiKit.dp(this,11),0,UiKit.dp(this,5),0);
        searchBar.setBackground(surface(0xFF1D2D43,0xFF40536D,14,this));
        NexaOutlineIcon magnifier=new NexaOutlineIcon(this,"search",0xFF8FB6EE);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(UiKit.dp(this,22),UiKit.dp(this,22));
        mp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,11),0);
        searchBar.addView(magnifier,mp);
        search=new EditText(this);
        search.setTag("nexa_directory_search_field");
        search.setTextSize(14.5f);search.setTypeface(UiKit.appFace(this,false));
        search.setSingleLine(true);search.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        search.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
        search.setHint("جست‌وجو در بخش‌ها");
        search.setHintTextColor(0xFF9FADC2);search.setTextColor(0xFFF4F7FF);
        search.setPadding(0,0,0,0);
        search.setBackgroundColor(Color.TRANSPARENT);
        search.setContentDescription("جست‌وجوی بخش‌های نکسا");
        searchBar.addView(search,new LinearLayout.LayoutParams(0,UiKit.dp(this,50),1f));
        clear=new TextView(this);
        clear.setText("×");clear.setTextColor(0xFFD5E4F7);clear.setTextSize(22);
        clear.setGravity(Gravity.CENTER);clear.setClickable(true);clear.setFocusable(true);
        clear.setContentDescription("پاک کردن عبارت جست‌وجو");
        UiKit.touchFeedback(this,clear,0xFF8BABFF,10);
        clear.setOnClickListener(v->search.setText(""));
        searchBar.addView(clear,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,48)));
        frame.addView(searchBar,UiKit.matchWrap(this,9,12));

        // Exactly two rows, entirely within screen width: no clipped chips on small phones.
        filters=new LinearLayout(this);filters.setOrientation(LinearLayout.VERTICAL);
        filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.addView(filters,UiKit.matchWrap(this,0,10));
        count=UiKit.muted(this,"");count.setTextSize(12.5f);
        count.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        frame.addView(count,UiKit.matchWrap(this,0,6));

        listScroll=new ScrollView(this);
        listScroll.setFillViewport(true);listScroll.setVerticalScrollBarEnabled(false);
        listScroll.setClipToPadding(false);
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
        results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        results.setPadding(0,0,0,UiKit.dp(this,20));
        listScroll.addView(results);
        frame.addView(listScroll,new LinearLayout.LayoutParams(-1,0,1f));

        LinearLayout nav=UiKit.bottomNav(this,-1,
            v->navigate(MainActivity.class),v->navigate(TodayActivity.class),
            v->navigate(QuickAddActivity.class),v->navigate(TimelineActivity.class));
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);
        np.setMargins(0,UiKit.dp(this,4),0,UiKit.dp(this,8));
        frame.addView(nav,np);
        setContentView(frame);

        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int n,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int n){
                clear.setVisibility(s.length()>0?View.VISIBLE:View.GONE);
                redraw();listScroll.scrollTo(0,0);
            }
            public void afterTextChanged(Editable s){}
        });
        search.setText(priorQuery);
        clear.setVisibility(priorQuery.isEmpty()?View.GONE:View.VISIBLE);
        redrawFilters();redraw();
    }
    private void navigate(Class<?> target){startActivity(new Intent(this,target));finish();}
    private void redrawFilters(){
        filters.removeAllViews();
        int[][] indexes={{0,1,2},{3,4}};
        for(int[] rowIndexes:indexes){
            LinearLayout row=new LinearLayout(this);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            for(int i=0;i<rowIndexes.length;i++){
                final int next=rowIndexes[i];
                TextView chip=new TextView(this);
                chip.setText(SHORT_GROUPS[next]);chip.setTextSize(12.5f);
                chip.setTypeface(UiKit.appFace(this,next==group));
                chip.setGravity(Gravity.CENTER);chip.setSingleLine(true);
                chip.setTextColor(next==group?Color.WHITE:0xFFC4D3E4);
                chip.setBackground(surface(next==group?0xFF365E95:0xFF1C293B,
                    next==group?0xFF6996D2:0xFF34445B,12,this));
                chip.setClickable(true);chip.setFocusable(true);
                chip.setContentDescription(ModulesCatalog.GROUPS[next]+(next==group?"، انتخاب‌شده":"، نمایش دسته"));
                chip.setOnClickListener(v->{group=next;redrawFilters();redraw();listScroll.scrollTo(0,0);});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,UiKit.dp(this,42),1f);
                if(i>0)lp.setMargins(UiKit.dp(this,6),0,0,0);
                row.addView(chip,lp);
            }
            filters.addView(row,UiKit.matchWrap(this,0,6));
        }
    }
    private LinearLayout moduleRow(ModulesCatalog.Item item){
        int color=ACCENTS[item.group];
        LinearLayout line=new LinearLayout(this);
        line.setOrientation(LinearLayout.HORIZONTAL);line.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        line.setGravity(Gravity.CENTER_VERTICAL);
        line.setMinimumHeight(UiKit.dp(this,62));
        line.setPadding(UiKit.dp(this,12),UiKit.dp(this,7),UiKit.dp(this,10),UiKit.dp(this,7));
        LinearLayout tile=new LinearLayout(this);
        tile.setGravity(Gravity.CENTER);tile.setBackground(surface(UiKit.withAlpha(color,0x26),0,12,this));
        NexaOutlineIcon icon=new NexaOutlineIcon(this,iconKind(item),color);
        tile.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,24),UiKit.dp(this,24)));
        line.addView(tile,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));
        TextView label=UiKit.sectionTitle(this,item.title);label.setTextSize(14.5f);
        label.setTextColor(0xFFF4F7FB);label.setMaxLines(2);
        label.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        lp.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,7),0);
        line.addView(label,lp);
        TextView arrow=UiKit.muted(this,"‹");arrow.setTextSize(22f);arrow.setGravity(Gravity.CENTER);
        line.addView(arrow,new LinearLayout.LayoutParams(UiKit.dp(this,22),UiKit.dp(this,40)));
        line.setContentDescription("باز کردن "+item.title);
        line.setClickable(true);line.setFocusable(true);
        UiKit.touchFeedback(this,line,color,14);
        line.setOnClickListener(v->startActivity(new Intent(this,item.destination)));
        return line;
    }
    private String iconKind(ModulesCatalog.Item item){
        Class<?> type=item.destination;
        if(type==AssetsActivity.class)return "assets";
        if(type==LedgerActivity.class)return "ledger";
        if(type==BillsActivity.class)return "bills";
        if(type==DocsActivity.class)return "docs";
        if(type==SharedEntitiesActivity.class)return "shared";
        if(type==MedicineActivity.class)return "medicine";
        if(type==GarageActivity.class)return "vehicle";
        if(type==HomeCareActivity.class)return "home";
        if(type==CaseActivity.class)return "case";
        if(type==WeatherActivity.class)return "weather";
        if(type==RemindersActivity.class)return "reminders";
        if(type==AnnualOccasionsActivity.class)return "occasions";
        if(type==SilentHubActivity.class)return "silent";
        if(type==BatteryGuardActivity.class)return "battery";
        if(type==EmergencyActivity.class)return "emergency";
        if(type==VaultActivity.class)return "vault";
        if(type==FileCenterActivity.class)return "files";
        if(type==SearchActivity.class)return "search";
        if(type==TimelineActivity.class)return "timeline";
        if(type==HistoryActivity.class)return "history";
        if(type==SettingsActivity.class)return "settings";
        if(type==NexaListActivity.class)return "lists";
        return "docs";
    }
    private View divider(){
        View line=new View(this);
        line.setBackgroundColor(0xFF2D3B4E);
        return line;
    }
    private void redraw(){
        if(results==null||search==null)return;
        results.removeAllViews();
        List<ModulesCatalog.Item> visible=ModulesCatalog.filter(search.getText().toString(),group);
        count.setText(visible.size()+" بخش"+(group==0?"":" • "+ModulesCatalog.GROUPS[group]));
        int lastGroup=-1;
        LinearLayout section=null;
        for(ModulesCatalog.Item item:visible){
            if(item.group!=lastGroup){
                if(group==0){
                    TextView heading=UiKit.sectionTitle(this,ModulesCatalog.GROUPS[item.group]);
                    heading.setTextColor(ACCENTS[item.group]);heading.setTextSize(14f);
                    results.addView(heading,UiKit.matchWrap(this,lastGroup==-1?4:15,8));
                }
                section=new LinearLayout(this);section.setOrientation(LinearLayout.VERTICAL);
                section.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                section.setBackground(surface(0xFF182539,0xFF35455B,16,this));
                results.addView(section,UiKit.matchWrap(this,0,1));
                lastGroup=item.group;
            } else if(section!=null){
                LinearLayout dividerWrapper=new LinearLayout(this);
                dividerWrapper.setPadding(UiKit.dp(this,64),0,UiKit.dp(this,12),0);
                dividerWrapper.addView(divider(),new LinearLayout.LayoutParams(-1,UiKit.dp(this,1)));
                section.addView(dividerWrapper);
            }
            if(section!=null)section.addView(moduleRow(item),new LinearLayout.LayoutParams(-1,-2));
        }
        if(visible.isEmpty()){
            TextView empty=UiKit.emptyState(this,"بخشی پیدا نشد","جست‌وجو یا دسته را تغییر بده.");
            results.addView(empty,UiKit.matchWrap(this,12,8));
            TextView showAll=UiKit.chip(this,"نمایش همه بخش‌ها",true);
            showAll.setMinimumHeight(UiKit.dp(this,48));
            showAll.setClickable(true);showAll.setFocusable(true);
            showAll.setOnClickListener(v->{group=0;search.setText("");redrawFilters();redraw();});
            results.addView(showAll,UiKit.matchWrap(this,4,10));
        }
    }
}
