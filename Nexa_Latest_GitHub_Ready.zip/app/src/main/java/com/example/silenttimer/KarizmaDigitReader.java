package com.example.silenttimer;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

/**
 * Offline, provider-specific OCR for Karizma's transaction screenshot format.
 * Recognizes isolated Persian numeral shapes in the left column, not the provider's
 * account-wide balances. The existing financial reconciliation MUST still validate
 * all recognized candidates before any purchase form fields are populated.
 * Never use this as a generic screenshot reader.
 */
public final class KarizmaDigitReader {
    private KarizmaDigitReader() {}
    private static final int W=32,H=40;
    private static final String TEMPLATE_FILE="karizma_digits_v1.dat.gz";
    private static final double MAX_SCORE=.34, MIN_GAP=.040;

    private static final class Glyph {
        char label; int w,h;byte[] mask;
        Glyph(char c,int width,int height,byte[] pixels){label=c;w=width;h=height;mask=pixels;}
    }
    private static final class Band {
        int top,bottom;
        Band(int t,int b){top=t;bottom=b;}
    }
    private static final class Read {
        String value="";
        boolean good;
        Read(String value,boolean good){this.value=value;this.good=good;}
    }
    public static final class Scan {
        public final AssetReceiptFieldFusion.Candidates values=new AssetReceiptFieldFusion.Candidates();
        public int jalaliYear,jalaliMonth,jalaliDay,hour,minute;
        public boolean hasDate,hasTime;
        public int recognizedFieldCount;
        public final List<String> balanceDeltas=new ArrayList<>();
        public boolean providerLayoutFound;
    }

    public static Scan scan(int[] argb,int width,int height,InputStream compressedTemplates) throws IOException {
        Scan output=new Scan();
        if(argb==null||width<300||height<500||(long)width*height>argb.length||compressedTemplates==null)
            return output;
        List<Glyph> model=readModel(compressedTemplates);
        if(model.size()<30)return output;
        List<Band> bands=receiptBands(argb,width,height);
        if(bands.size()<6||bands.size()>9)return output;
        output.providerLayoutFound=true;
        for(int offset:new int[]{0,2}){
            int amtBand=offset==0?2:1;
            if(amtBand>=bands.size())continue;
            int dateY=(bands.get(amtBand-1).bottom+bands.get(amtBand).top)/2;
            Read date=readField(argb,width,height,dateY,(int)(width*.145),
                (int)(width*.314),model);
            Read time=readField(argb,width,height,dateY,(int)(width*.330),
                (int)(width*.462),model);
            if(date.good&&date.value.matches("1[34][0-9]{2}/[0-9]{2}/[0-9]{2}")){
                try{
                    String[] d=date.value.split("/");
                    int y=Integer.parseInt(d[0]),m=Integer.parseInt(d[1]),day=Integer.parseInt(d[2]);
                    if(y>=1350&&y<=1500&&m>=1&&m<=12&&day>=1&&day<=31){
                        output.hasDate=true;output.jalaliYear=y;output.jalaliMonth=m;
                        output.jalaliDay=day;
                    }
                }catch(NumberFormatException ignored){}
            }
            if(time.good&&time.value.matches("[0-9]{2}:[0-9]{2}:[0-9]{2}")){
                try{
                    String[] parts=time.value.split(":");
                    int h=Integer.parseInt(parts[0]),m=Integer.parseInt(parts[1]);
                    if(h<24&&m<60){output.hasTime=true;output.hour=h;output.minute=m;}
                }catch(NumberFormatException ignored){}
            }
            // The receipt shows account balance BEFORE and AFTER this transaction.
            // Their difference may provide more precision than the rounded gram fee.
            // This is *not* directly a lot quantity until the independent gross/fee
            // relationship has also verified it.
            int beforeIndex=(10-offset)/2,afterIndex=(12-offset)/2;
            if(beforeIndex>=0 && afterIndex<bands.size()){
                Read before=readField(argb,width,height,
                    (bands.get(beforeIndex).top+bands.get(beforeIndex).bottom)/2,
                    (int)(width*.181),(int)(width*.425),model,1);
                Read after=readField(argb,width,height,
                    (bands.get(afterIndex).top+bands.get(afterIndex).bottom)/2,
                    (int)(width*.181),(int)(width*.425),model,1);
                if(before.good&&after.good&&before.value.matches("[0-9]{1,5}/[0-9]{4,9}|0") &&
                    after.value.matches("[0-9]{1,5}/[0-9]{4,9}")){
                    try{
                        BigDecimal old=new BigDecimal(before.value.replace('/','.'));
                        BigDecimal next=new BigDecimal(after.value.replace('/','.'));
                        BigDecimal delta=next.subtract(old);
                        if(delta.signum()>0 && !output.balanceDeltas.contains(delta.toPlainString()))
                            output.balanceDeltas.add(delta.toPlainString());
                    }catch(NumberFormatException ignored){}
                }
            }
            for(int k=0;k<bands.size();k++){
                int row=offset+2*k;
                String kind=fieldForRow(row);
                if(kind!=null)putField(output,argb,width,height,
                    (bands.get(k).top+bands.get(k).bottom)/2,kind,model);
                if(k+1<bands.size()){
                    kind=fieldForRow(row+1);
                    if(kind!=null)putField(output,argb,width,height,
                        (bands.get(k).bottom+bands.get(k+1).top)/2,kind,model);
                }
            }
        }
        return output;
    }
    private static String fieldForRow(int row){
        switch(row){
            case 4:return "amount";
            case 5:return "gross";
            case 6:return "price";
            case 7:return "cashFee";
            case 8:return "gramFee";
            default:return null;
        }
    }
    private static void putField(Scan out,int[] argb,int w,int h,int cy,
            String kind,List<Glyph> model){
        int left=(int)(w*.181),right=(int)(w*("gross".equals(kind)?.455:
            "amount".equals(kind)?.430:"price".equals(kind)?.380:.400));
        Read r=readField(argb,w,h,cy,left,right,model);
        if(!r.good)return;
        String s=r.value;
        boolean monetary="amount".equals(kind)||"price".equals(kind)||"cashFee".equals(kind);
        if(monetary){
            if(!s.matches("[1-9][0-9]{0,2}(,[0-9]{3}){1,5}"))return;
        }else if(!s.matches("[0-9]{1,5}/[0-9]{4,9}"))return;
        String parsed=AssetReceiptParser.numericCandidate(s,kind);
        if(parsed.isEmpty())return;
        out.values.add(kind,s);
        out.recognizedFieldCount++;
    }
    private static Read readField(int[] pixels,int width,int height,int center,
            int left,int right,List<Glyph> model){
        return readField(pixels,width,height,center,left,right,model,3);
    }
    private static Read readField(int[] pixels,int width,int height,int center,
            int left,int right,List<Glyph> model,int minChars){
        int half=Math.max(12,(int)(width*.033));
        int top=Math.max(0,center-half),bottom=Math.min(height,center+half);
        left=Math.max(0,left);right=Math.min(width,right);
        if(bottom-top<8||right-left<12)return new Read("",false);
        int cw=right-left,ch=bottom-top;
        boolean[] pix=new boolean[cw*ch];
        int[] columns=new int[cw];
        for(int y=0;y<ch;y++)for(int x=0;x<cw;x++){
            int c=pixels[(top+y)*width+left+x];
            int r=(c>>16)&255,g=(c>>8)&255,b=c&255;
            boolean black=(3*r+6*g+b)<1650;
            pix[y*cw+x]=black;
            if(black)columns[x]++;
        }
        StringBuilder result=new StringBuilder();
        int count=0;
        for(int x=0;x<cw;){
            if(columns[x]==0){x++;continue;}
            int start=x;
            while(x<cw&&columns[x]>0)x++;
            int end=x,y1=ch,y2=-1,ink=0;
            for(int yy=0;yy<ch;yy++)for(int xx=start;xx<end;xx++)if(pix[yy*cw+xx]){
                y1=Math.min(y1,yy);y2=Math.max(y2,yy);ink++;
            }
            if(ink<2||y2<y1)continue;
            int gw=end-start,gh=y2-y1+1;
            byte[] norm=normalize(pix,cw,start,end,y1,y2+1);
            char best='\0';double bestScore=Double.POSITIVE_INFINITY,second=Double.POSITIVE_INFINITY;
            for(char label:"0123456789,/:".toCharArray()){
                double candidate=Double.POSITIVE_INFINITY;
                for(Glyph ref:model)if(ref.label==label){
                    double d=distance(norm,gw,gh,ref);
                    if(d<candidate)candidate=d;
                }
                if(candidate<bestScore){second=bestScore;bestScore=candidate;best=label;}
                else if(candidate<second)second=candidate;
            }
            if(best=='\0'||bestScore>MAX_SCORE||second-bestScore<MIN_GAP)
                return new Read("",false);
            result.append(best);count++;
            if(count>30)return new Read("",false);
        }
        return new Read(result.toString(),count>=minChars);
    }
    private static byte[] normalize(boolean[] src,int stride,int start,int end,
            int top,int bottom){
        int w=end-start,h=bottom-top;
        double scale=Math.min(24.0/w,32.0/h);
        int nw=Math.max(1,(int)(w*scale)),nh=Math.max(1,(int)(h*scale));
        int x0=(W-nw)/2,y0=(H-nh)/2;
        byte[] result=new byte[W*H];
        for(int y=0;y<nh;y++)for(int x=0;x<nw;x++){
            int sy=top+Math.min(h-1,(int)(y*(h/(double)nh)));
            int sx=start+Math.min(w-1,(int)(x*(w/(double)nw)));
            result[(y0+y)*W+x0+x]=(byte)(src[sy*stride+sx]?1:0);
        }
        return result;
    }
    private static double distance(byte[] sample,int w,int h,Glyph ref){
        int diff=0,intersection=0,union=0;
        for(int i=0;i<sample.length;i++){
            int a=sample[i]&255,b=ref.mask[i]&255;
            if(a!=b)diff++;
            if(a!=0&&b!=0)intersection++;
            if(a!=0||b!=0)union++;
        }
        return .35*(diff/(double)sample.length)
            +.55*(1.0-(union==0?0:intersection/(double)union))
            +.10*Math.abs(Math.log((w/(double)h)/(ref.w/(double)ref.h)));
    }
    private static List<Glyph> readModel(InputStream gzip)throws IOException{
        List<Glyph> list=new ArrayList<>();
        try(DataInputStream in=new DataInputStream(new GZIPInputStream(gzip))){
            int count=in.readUnsignedShort();
            if(count<20||count>1000)throw new IOException("Invalid digit model");
            for(int i=0;i<count;i++){
                char c=(char)in.readUnsignedByte();int w=in.readUnsignedByte(),h=in.readUnsignedByte();
                byte[] pixels=new byte[W*H];in.readFully(pixels);
                if("0123456789,/:".indexOf(c)<0||w<=0||h<=0)throw new IOException("Invalid glyph");
                list.add(new Glyph(c,w,h,pixels));
            }
        }
        return list;
    }
    private static List<Band> receiptBands(int[] pixels,int w,int h){
        List<Band> bands=new ArrayList<>();int x=Math.round(w*.13f);
        int begin=Math.round(h*.20f),end=Math.round(h*.92f),run=-1;
        for(int y=begin;y<=end;y++){
            boolean gray=false;
            if(y<end){
                int c=pixels[y*w+x];int r=(c>>16)&255,g=(c>>8)&255,b=c&255;
                gray=r>=216&&r<=249&&Math.abs(r-g)<16&&b>=g&&(b-r)<30;
            }
            if(gray&&run<0)run=y;
            if(!gray&&run>=0){
                int length=y-run;
                if(length>w*.075&&length<w*.175)bands.add(new Band(run,y));
                run=-1;
            }
        }
        if(bands.size()<6||bands.size()>9)return new ArrayList<>();
        for(int i=1;i<bands.size();i++){
            int period=bands.get(i).top-bands.get(i-1).top;
            if(period<w*.15||period>w*.30)return new ArrayList<>();
        }
        return bands;
    }
}
