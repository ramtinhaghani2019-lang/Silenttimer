package com.example.silenttimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Responsive Persian RTL market chart with accurate non-zero y-axis scaling.
 * Values are never interpolated, normalized to zero, or substituted. */
public final class MarketHistoryView extends View {
    public interface OnPointSelectedListener { void onSelect(long time,double price); }
    private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint axis=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dot=new Paint(Paint.ANTI_ALIAS_FLAG);
    private final List<Double> values=new ArrayList<>();
    private final List<Long> times=new ArrayList<>();
    private OnPointSelectedListener listener;
    private int highlighted=-1;
    private float left,top,right,bottom;
    public MarketHistoryView(Context c){
        super(c);
        line.setColor(UiKit.GOLD);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(UiKit.dp(c,2));
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setStrokeJoin(Paint.Join.ROUND);
        dot.setColor(UiKit.GOLD);
        dot.setStyle(Paint.Style.FILL);
        axis.setColor(0x335C7796);
        axis.setStrokeWidth(UiKit.dp(c,1));
        label.setColor(UiKit.MUTED);
        label.setTextSize(UiKit.dp(c,10));
        setMinimumHeight(UiKit.dp(c,225));
        setContentDescription("نمودار تغییرات قیمت؛ با لمس نمودار تاریخ و نرخ هر نقطه نشان داده می‌شود.");
    }
    public void setOnPointSelectedListener(OnPointSelectedListener l){listener=l;}
    public void setValues(List<Double> points){setSeries(points,null);}
    public void setSeries(List<Double> points,List<Long> dates){
        values.clear();times.clear();
        if(points!=null)for(int i=0;i<points.size();i++){
            double v=points.get(i);
            if(!Double.isFinite(v)||v<=0)continue;
            values.add(v);
            times.add(dates!=null&&i<dates.size()?dates.get(i):(long)i);
        }
        highlighted=-1;invalidate();
    }
    private String compact(double v){
        if(!Double.isFinite(v))return "—";
        if(Math.abs(v)>=1000000000d)return PersianFinancialDisplay.digits(String.format(Locale.US,"%.2f",v/1000000000d))+"B";
        if(Math.abs(v)>=1000000d)return PersianFinancialDisplay.digits(String.format(Locale.US,"%.2f",v/1000000d))+"M";
        if(Math.abs(v)>=1000d)return PersianFinancialDisplay.digits(String.format(Locale.US,"%.1f",v/1000d))+"K";
        return PersianFinancialDisplay.amount2(v);
    }
    private float chartX(int i){
        if(values.size()<2)return left+(right-left)*0.5f;
        long start=times.get(0),end=times.get(times.size()-1);
        if(start<end){return left+(right-left)*(times.get(i)-start)/(float)(end-start);}
        return left+(right-left)*i/(float)(values.size()-1);
    }
    private float chartY(double v,double min,double max){
        return (float)(bottom-(bottom-top)*(v-min)/(max-min));
    }
    @Override protected void onDraw(Canvas c){
        super.onDraw(c);
        float w=getWidth(),h=getHeight();
        left=UiKit.dp(getContext(),10);right=w-UiKit.dp(getContext(),70);
        top=UiKit.dp(getContext(),14);bottom=h-UiKit.dp(getContext(),32);
        if(right<=left||bottom<=top)return;
        for(int i=0;i<=4;i++){
            float y=top+(bottom-top)*i/4f;
            c.drawLine(left,y,right,y,axis);
        }
        if(values.isEmpty()){
            label.setTextAlign(Paint.Align.CENTER);
            c.drawText("داده‌ای برای این بازه ثبت نشده",w/2,h/2,label);
            return;
        }
        double min=Double.POSITIVE_INFINITY,max=Double.NEGATIVE_INFINITY;
        for(double v:values){min=Math.min(min,v);max=Math.max(max,v);}
        double diff=max-min;
        double padding=diff>0?diff*0.09d:Math.max(Math.abs(min)*0.01d,1d);
        min=Math.max(0,min-padding);max=max+padding;
        if(max<=min)max=min+1d;
        label.setTextAlign(Paint.Align.LEFT);
        for(int i=0;i<=4;i++){
            double v=max-(max-min)*i/4d;
            float y=top+(bottom-top)*i/4f;
            c.drawText(compact(v),right+UiKit.dp(getContext(),5),y+UiKit.dp(getContext(),4),label);
        }
        if(values.size()==1){
            float x=chartX(0),y=chartY(values.get(0),min,max);
            c.drawCircle(x,y,UiKit.dp(getContext(),4),dot);
            return;
        }
        Path path=new Path();
        for(int i=0;i<values.size();i++){
            float x=chartX(i),y=chartY(values.get(i),min,max);
            if(i==0)path.moveTo(x,y);else path.lineTo(x,y);
        }
        Path area=new Path(path);
        area.lineTo(chartX(values.size()-1),bottom);
        area.lineTo(chartX(0),bottom);
        area.close();
        fill.setShader(new LinearGradient(0,top,0,bottom,0x50E8BC6B,0x00E8BC6B,Shader.TileMode.CLAMP));
        c.drawPath(area,fill);
        fill.setShader(null);
        c.drawPath(path,line);
        int tip=highlighted>=0&&highlighted<values.size()?highlighted:values.size()-1;
        float x=chartX(tip),y=chartY(values.get(tip),min,max);
        c.drawCircle(x,y,UiKit.dp(getContext(),5),dot);
        if(highlighted>=0){
            c.drawLine(x,top,x,bottom,axis);
            dot.setColor(UiKit.CARD_2);c.drawCircle(x,y,UiKit.dp(getContext(),2),dot);
            dot.setColor(UiKit.GOLD);
        }
        label.setTextAlign(Paint.Align.LEFT);
        c.drawText("شروع",left,bottom+UiKit.dp(getContext(),19),label);
        label.setTextAlign(Paint.Align.RIGHT);
        c.drawText("آخرین",right,bottom+UiKit.dp(getContext(),19),label);
    }
    @Override public boolean onTouchEvent(MotionEvent e){
        if(values.isEmpty())return super.onTouchEvent(e);
        if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE){
            int index=0;float best=Float.POSITIVE_INFINITY;
            for(int i=0;i<values.size();i++){
                float d=Math.abs(e.getX()-chartX(i));if(d<best){best=d;index=i;}
            }
            highlighted=index;invalidate();
            if(listener!=null)listener.onSelect(times.get(index),values.get(index));
            return true;
        }
        return e.getAction()==MotionEvent.ACTION_UP||super.onTouchEvent(e);
    }
}
