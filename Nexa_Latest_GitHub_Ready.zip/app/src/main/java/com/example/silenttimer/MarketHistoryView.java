package com.example.silenttimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.ArrayList;
import java.util.List;

/** Lightweight offline chart for locally captured Iranian-market snapshots. */
public final class MarketHistoryView extends View {
    private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG), grid=new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Double> values=new ArrayList<>();
    public MarketHistoryView(Context c){super(c);line.setStyle(Paint.Style.STROKE);line.setStrokeWidth(4f);line.setColor(UiKit.TEXT);grid.setStrokeWidth(1f);grid.setColor(UiKit.MUTED);setMinimumHeight(UiKit.dp(c,220));}
    public void setValues(List<Double> v){values=v==null?new ArrayList<>():v;invalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),pad=24f;c.drawLine(pad,h-pad,w-pad,h-pad,grid);c.drawLine(pad,pad,pad,h-pad,grid);if(values.size()<2)return;double min=Double.MAX_VALUE,max=-Double.MAX_VALUE;for(double v:values)if(v>0){min=Math.min(min,v);max=Math.max(max,v);}if(min==Double.MAX_VALUE)return;if(max<=min)max=min+1;float px=0,py=0;boolean first=true;for(int i=0;i<values.size();i++){double v=values.get(i);if(v<=0)continue;float x=pad+(w-2*pad)*i/Math.max(1,values.size()-1);float y=(float)(h-pad-(h-2*pad)*(v-min)/(max-min));if(!first)c.drawLine(px,py,x,y,line);px=x;py=y;first=false;}}
}
