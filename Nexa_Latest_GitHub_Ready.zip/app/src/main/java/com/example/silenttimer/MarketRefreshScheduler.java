package com.example.silenttimer;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Context;

/** Best effort background refresh: the OS controls the exact execution time. */
final class MarketRefreshScheduler {
    static final int JOB_ID=754237;
    static final long FOREGROUND_PERIOD_MS=5*60_000L;
    static final long BACKGROUND_PERIOD_MS=6*60*60_000L;
    private MarketRefreshScheduler(){}
    static void sync(Context c){
        JobScheduler s=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
        if(s==null)return;
        if(NexaStore.marketRefreshMode(c)!=2){s.cancel(JOB_ID);return;}
        // 6-hour target = four jobs/day; Android can postpone under Doze/battery saver.
        if(s.getPendingJob(JOB_ID)!=null)return;
        JobInfo job=new JobInfo.Builder(JOB_ID,new ComponentName(c,MarketRefreshJobService.class))
            .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
            .setPeriodic(BACKGROUND_PERIOD_MS,60*60_000L)
            .setPersisted(true)
            .build();
        s.schedule(job);
    }
    static void refreshIfDue(Context c){
        if(NexaStore.marketRefreshMode(c)!=2)return;
        long now=System.currentTimeMillis();
        long attempt=NexaStore.marketLastAttempt(c);
        // Do not hammer provider after network failures or while the last request is in flight.
        if(attempt>0&&now-attempt>=0&&now-attempt<FOREGROUND_PERIOD_MS)return;
        MarketDataHelper.refresh(c,(ok,msg)->{
            if(ok){AssetMarketEngine.updateOnlineAssets(c);AssetMarketEngine.checkAlerts(c);}
        });
    }
}
