package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.Toast;

public class EmergencyActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"Nexa Emergency"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"کارت اضطراری اختیاری برای صفحه قفل"),UiKit.matchWrap(this,0,14));

        LinearLayout card=UiKit.colorfulCardLayout(this,5);
        card.addView(UiKit.sectionTitle(this,"🆘 اطلاعات اضطراری"));
        card.addView(UiKit.muted(this,"فقط اطلاعاتی را وارد کن که با نمایش روی Lock Screen مشکلی نداری. اطلاعات حساس پزشکی یا بانکی وارد نکن."),UiKit.matchWrap(this,6,12));

        Switch enabled=new Switch(this);
        enabled.setText("نمایش کارت اضطراری روی صفحه قفل");
        enabled.setTextColor(UiKit.TEXT);
        enabled.setChecked(NexaStore.emergencyEnabled(this));
        card.addView(enabled);

        EditText name=field("نام نمایشی");
        name.setText(NexaStore.emergencyName(this));
        EditText label1=field("عنوان مخاطب ۱؛ مثلاً مادر");
        label1.setText(NexaStore.emergencyLabel1(this));
        EditText phone1=field("شماره تماس اضطراری ۱");
        phone1.setInputType(InputType.TYPE_CLASS_PHONE);
        phone1.setText(NexaStore.emergencyPhone1(this));
        EditText label2=field("عنوان مخاطب ۲؛ مثلاً پدر");
        label2.setText(NexaStore.emergencyLabel2(this));
        EditText phone2=field("شماره تماس اضطراری ۲");
        phone2.setInputType(InputType.TYPE_CLASS_PHONE);
        phone2.setText(NexaStore.emergencyPhone2(this));
        EditText note=field("یادداشت کوتاه عمومی");
        note.setText(NexaStore.emergencyNote(this));

        card.addView(name,UiKit.matchWrap(this,10,6));
        card.addView(label1,UiKit.matchWrap(this,0,6));
        card.addView(phone1,UiKit.matchWrap(this,0,6));
        card.addView(label2,UiKit.matchWrap(this,0,6));
        card.addView(phone2,UiKit.matchWrap(this,0,6));
        card.addView(note,UiKit.matchWrap(this,0,10));

        Button save=UiKit.primaryButton(this,"ذخیره کارت اضطراری");
        save.setOnClickListener(v->{
            NexaStore.setEmergencyEnabled(this,enabled.isChecked());
            NexaStore.setEmergencyName(this,name.getText().toString().trim());
            NexaStore.setEmergencyLabel1(this,label1.getText().toString().trim());
            NexaStore.setEmergencyPhone1(this,phone1.getText().toString().trim());
            NexaStore.setEmergencyLabel2(this,label2.getText().toString().trim());
            NexaStore.setEmergencyPhone2(this,phone2.getText().toString().trim());
            NexaStore.setEmergencyNote(this,note.getText().toString().trim());
            EmergencyCardManager.refresh(this);
            Toast.makeText(this,"کارت اضطراری ذخیره شد.",Toast.LENGTH_SHORT).show();
        });
        card.addView(save);

        root.addView(card,UiKit.matchWrap(this,0,12));

        LinearLayout quick=UiKit.cardLayout(this);
        quick.addView(UiKit.sectionTitle(this,"تماس سریع"));
        Button call1=UiKit.secondaryButton(this,"تماس با "+NexaStore.emergencyLabel1(this));
        call1.setOnClickListener(v->dial(NexaStore.emergencyPhone1(this)));
        quick.addView(call1,UiKit.matchWrap(this,10,6));
        Button call2=UiKit.secondaryButton(this,"تماس با "+NexaStore.emergencyLabel2(this));
        call2.setOnClickListener(v->dial(NexaStore.emergencyPhone2(this)));
        quick.addView(call2);
        root.addView(quick);

        setContentView(sc);
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void dial(String number) {
        if(number==null||number.trim().isEmpty())return;
        startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:"+Uri.encode(number.trim()))));
    }
}
