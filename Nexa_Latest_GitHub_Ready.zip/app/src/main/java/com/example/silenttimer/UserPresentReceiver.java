package com.example.silenttimer;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
public class UserPresentReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){String note=NexaStore.unlockNote(c);if(note.trim().isEmpty())return;ReminderScheduler.createChannels(c);Intent open=new Intent(c,TodayActivity.class);PendingIntent pi=PendingIntent.getActivity(c,9393,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,ReminderScheduler.CHANNEL):new Notification.Builder(c);Notification n=b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("یادآوری بعد از بازکردن گوشی").setContentText(note).setContentIntent(pi).setAutoCancel(true).setVisibility(Notification.VISIBILITY_PUBLIC).build();((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(9393,n);NexaStore.setUnlockNote(c,"");}}
