package com.example.silenttimer;

/**
 * Restores the colorful, user-recognizable emoji used in Nexa's original
 * feature cards. The index order is the existing, unchanged destination
 * order in MainActivity. No route or persistence behavior lives here.
 */
public final class FeatureEmoji {
    private FeatureEmoji() {}
    private static final String[] DIRECTORY = {
        "💊", // دارو و سلامت
        "💰", // دارایی‌ها
        "🧾", // قبوض و اقساط
        "📄", // اسناد و مدارک
        "🚗", // سرویس خودرو
        "🏠", // سرویس خانه
        "⚖️", // پرونده‌ها — original scales emoji
        "☁️", // هواشناسی — original cloud emoji
        "🔕", // صدا و اعلان‌ها — original silenced bell emoji
        "🔋", // باتری و شارژ — original battery emoji
        "🔐", // امنیت و حریم خصوصی — original lock-and-key emoji
        "🆘", // اضطراری — original SOS emoji
        "⚙️", // تنظیمات
        "🔎", // جستجوی سراسری — original magnifying glass emoji
        "🕒", // خط زمانی — original clock emoji
        "📜", // سوابق
        "📁", // فایل‌ها
        "👥"  // دفتر مشترک
    };

    public static String[] directoryIcons() { return DIRECTORY.clone(); }
    public static int count() { return DIRECTORY.length; }
}
