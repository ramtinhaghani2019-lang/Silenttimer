package com.example.silenttimer;

/** Rules shared by the reminder bulk-action toolbar and Android regression tests. */
public final class ReminderBatchManager {
    public static final String PAUSE = "pause";
    public static final String RESUME = "resume";
    public static final String DONE = "done";
    private ReminderBatchManager() {}

    public static boolean eligible(NexaStore.Reminder r, String action, long now) {
        if (r == null || action == null) return false;
        if (PAUSE.equals(action)) return !r.done && r.active;
        if (RESUME.equals(action)) return !r.done && !r.active && r.whenMillis > now;
        if (DONE.equals(action)) return !r.done;
        return false;
    }

    /** Applies only eligible changes; caller cancels old alarms before, then persists/schedules. */
    public static boolean apply(NexaStore.Reminder r, String action, long now) {
        if (!eligible(r,action,now)) return false;
        if (PAUSE.equals(action)) {
            r.active = false;
        } else if (RESUME.equals(action)) {
            r.active = true;
        } else if (DONE.equals(action)) {
            ReminderRecurrence.recordCompleted(r);
            if (!ReminderRecurrence.advanceAfterDone(r,now)) {
                r.done = true;
                r.active = false;
            }
        }
        return true;
    }
}
