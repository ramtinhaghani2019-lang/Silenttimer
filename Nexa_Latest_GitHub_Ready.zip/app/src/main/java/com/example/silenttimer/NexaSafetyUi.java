package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Presentation-only widgets for trusted calls and the optional emergency card. */
final class NexaSafetyUi {
    private NexaSafetyUi() { }

    static HorizontalScrollView callMetrics(Context c,int contacts,boolean allowed,boolean missed) {
        HorizontalScrollView scroll=new HorizontalScrollView(c);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addMetric(c,row,"مخاطبان مجاز",String.valueOf(contacts),UiKit.PURPLE);
        addMetric(c,row,"زنگ مجاز",allowed?"روشن":"خاموش",allowed?UiKit.GREEN:UiKit.MUTED);
        addMetric(c,row,"اعلان تماس",missed?"روشن":"خاموش",missed?UiKit.BLUE:UiKit.MUTED);
        scroll.addView(row);
        scroll.setContentDescription("خلاصه تماس‌های مجاز: "+contacts+" مخاطب");
        return scroll;
    }

    static HorizontalScrollView emergencyMetrics(Context c,boolean enabled,boolean first,boolean second){
        HorizontalScrollView scroll=new HorizontalScrollView(c);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout row=new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addMetric(c,row,"کارت اضطراری",enabled?"فعال":"غیرفعال",enabled?UiKit.GREEN:UiKit.MUTED);
        addMetric(c,row,"مخاطب اول",first?"ثبت‌شده":"خالی",first?UiKit.BLUE:UiKit.MUTED);
        addMetric(c,row,"مخاطب دوم",second?"ثبت‌شده":"خالی",second?UiKit.PURPLE:UiKit.MUTED);
        scroll.addView(row);
        scroll.setContentDescription("خلاصه کارت اضطراری بدون نمایش شماره تماس");
        return scroll;
    }

    private static void addMetric(Context c,LinearLayout row,String title,String value,int tone){
        LinearLayout item=UiKit.financialMetric(c,title,value,tone);
        item.setMinimumHeight(UiKit.dp(c,85));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(UiKit.dp(c,144),-2);
        lp.setMargins(UiKit.dp(c,2),0,UiKit.dp(c,8),0);
        row.addView(item,lp);
    }

    static LinearLayout contactCard(Context c,String displayName,String number){
        LinearLayout card=UiKit.cardLayout(c);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setMinimumHeight(UiKit.dp(c,84));
        LinearLayout info=new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        TextView heading=UiKit.sectionTitle(c,displayName==null||displayName.trim().isEmpty()?"بدون نام":displayName.trim());
        heading.setMaxLines(2);
        info.addView(heading);
        TextView phone=UiKit.muted(c,number==null?"":number);
        phone.setTextDirection(View.TEXT_DIRECTION_LTR);
        phone.setGravity(Gravity.RIGHT);
        phone.setTextSize(14f);
        info.addView(phone,UiKit.matchWrap(c,5,0));
        card.addView(info,new LinearLayout.LayoutParams(0,-2,1f));
        card.setContentDescription("مخاطب مجاز: "+heading.getText());
        return card;
    }

    static TextView subheading(Context c,String text) {
        TextView t=UiKit.sectionTitle(c,text);
        t.setTextSize(15f);
        t.setPadding(0,UiKit.dp(c,7),0,UiKit.dp(c,5));
        return t;
    }

    static LinearLayout empty(Context c){
        LinearLayout card=UiKit.cardLayout(c);
        card.setMinimumHeight(UiKit.dp(c,100));
        card.setGravity(Gravity.CENTER);
        TextView headline=UiKit.sectionTitle(c,"هنوز شماره‌ای ثبت نشده");
        headline.setGravity(Gravity.CENTER);
        card.addView(headline);
        TextView hint=UiKit.muted(c,"برای عبور تماس‌های ضروری از حالت سکوت، مخاطب اضافه کن.");
        hint.setGravity(Gravity.CENTER);
        card.addView(hint,UiKit.matchWrap(c,8,0));
        return card;
    }
}
