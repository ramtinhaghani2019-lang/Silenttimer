package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class MedicineAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL="nexa_medicine_alarm_v5";
    @Override public void onReceive(Context c,Intent i){
        String id=i.getStringExtra("id");NexaStore.Medicine m=NexaStore.medicine(c,id);if(m==null||!m.active)return;
        NotificationChannelHelper.ensureMedicine(c);
        AlarmSoundPlayer.start(c);
        PendingIntent onTime=action(c,m.id,"TAKEN_ON_TIME","on");
        PendingIntent now=action(c,m.id,"TAKEN_NOW","now");
        PendingIntent snooze=action(c,m.id,"SNOOZE","s");
        Intent ring=new Intent(c,MedicineRingActivity.class);ring.putExtra("id",m.id);ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent ringPi=PendingIntent.getActivity(c,(m.id+"ring").hashCode(),ring,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
        Notification n=b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("💊 زمان مصرف "+m.name)
            .setContentText((m.dose.isEmpty()?"نوبت دارو رسیده":m.dose)+" • "+PersianDateUtil.pretty(m.nextDoseMillis))
            .setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true).setAutoCancel(false).setOnlyAlertOnce(false).setFullScreenIntent(ringPi,true)
            .addAction(new Notification.Action.Builder(android.R.drawable.checkbox_on_background,"سر وقت خوردم",onTime).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_recent_history,"الان خوردم",now).build())
            .addAction(new Notification.Action.Builder(android.R.drawable.ic_popup_reminder,"۵ دقیقه بعد",snooze).build()).build();
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(("med"+id).hashCode(),n);
        NexaStore.addHistory(c,"دارو","هشدار: "+m.name);
        int repeat=m.repeatMinutes>0?m.repeatMinutes:5;MedicineScheduler.scheduleAt(c,id,System.currentTimeMillis()+repeat*60_000L);
    }
    private PendingIntent action(Context c,String id,String action,String suffix){Intent x=new Intent(c,MedicineActionReceiver.class);x.putExtra("id",id);x.setAction(action);return PendingIntent.getBroadcast(c,(id+suffix).hashCode(),x,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
}
