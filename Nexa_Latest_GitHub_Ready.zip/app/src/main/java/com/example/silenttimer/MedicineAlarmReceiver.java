package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MedicineAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "nexa_medicine_alarm_v7";

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String id = intent.getStringExtra("id");
        if (id == null || id.trim().isEmpty()) return;
        NexaStore.Medicine medicine = NexaStore.medicine(context, id);
        if (!MedicineScheduler.canSchedule(medicine, System.currentTimeMillis())) {
            if (medicine != null) MedicineScheduler.cancel(context, medicine.id);
            return;
        }

        // Ignore only accidental immediate duplicate receiver deliveries.
        // Normal medicine repeats (minutes later) are intentionally allowed.
        if (!NexaNotificationEngine.acquireDelivery(context, "medicine:" + medicine.id)) return;

        AlarmSoundPlayer.start(context, "medicine:" + medicine.id, NexaAudioController.PRIORITY_MEDICINE, NexaAudioController.SOUND_ALARM);

        PendingIntent onTime = action(context, medicine.id, "TAKEN_ON_TIME", "on");
        PendingIntent now = action(context, medicine.id, "TAKEN_NOW", "now");
        PendingIntent snooze = action(context, medicine.id, "SNOOZE", "s");
        PendingIntent stopSound = action(context, medicine.id, "STOP_SOUND", "stop");

        Intent ring = new Intent(context, MedicineRingActivity.class);
        ring.putExtra("id", medicine.id);
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent ringPi = PendingIntent.getActivity(
                context,
                (medicine.id + "ring").hashCode(),
                ring,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NexaNotificationEngine.showMedicineNotification(
                context, medicine, ringPi, onTime, now, snooze, stopSound);

        NexaStore.addHistory(context, "دارو", "هشدار: " + medicine.name);
        long next = MedicineScheduler.nextRepeatAt(System.currentTimeMillis(), medicine.repeatMinutes);
        if (MedicineScheduler.canSchedule(medicine, next)) {
            MedicineScheduler.scheduleAt(context, id, next);
        } else {
            MedicineScheduler.cancel(context, id);
        }
    }

    private PendingIntent action(Context context, String id, String action, String suffix) {
        Intent intent = new Intent(context, MedicineActionReceiver.class);
        intent.putExtra("id", id);
        intent.setAction(action);
        return PendingIntent.getBroadcast(
                context,
                (id + suffix).hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
