package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MedicineAlarmReceiver extends BroadcastReceiver {
    public static final String CHANNEL = "nexa_medicine_alarm_v7";

    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        NexaStore.Medicine medicine = NexaStore.medicine(context, id);
        if (medicine == null || !medicine.active) return;

        // Ignore only accidental immediate duplicate receiver deliveries.
        // Normal medicine repeats (minutes later) are intentionally allowed.
        if (!NexaNotificationEngine.acquireDelivery(context, "medicine:" + medicine.id)) return;

        AlarmSoundPlayer.start(context, "medicine:" + medicine.id, NexaAudioController.PRIORITY_MEDICINE);

        PendingIntent onTime = action(context, medicine.id, "TAKEN_ON_TIME", "on");
        PendingIntent now = action(context, medicine.id, "TAKEN_NOW", "now");
        PendingIntent snooze = action(context, medicine.id, "SNOOZE", "s");

        Intent ring = new Intent(context, MedicineRingActivity.class);
        ring.putExtra("id", medicine.id);
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent ringPi = PendingIntent.getActivity(
                context,
                (medicine.id + "ring").hashCode(),
                ring,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NexaNotificationEngine.showMedicineNotification(
                context, medicine, ringPi, onTime, now, snooze);

        NexaStore.addHistory(context, "دارو", "هشدار: " + medicine.name);
        int repeat = medicine.repeatMinutes > 0 ? medicine.repeatMinutes : 5;
        MedicineScheduler.scheduleAt(
                context,
                id,
                System.currentTimeMillis() + repeat * 60_000L);
    }

    private PendingIntent action(Context context, String id, String action, String suffix) {
        Intent intent = new Intent(context, MedicineActionReceiver.class);
        intent.putExtra("id", id);
        intent.setAction(action);
        return PendingIntent.getBroadcast(
                context,
                (id + suffix).hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
