package com.example.silenttimer;

import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public final class UiKit {
    private UiKit() {}
    public static int BG_1=0xFF020807,BG_2=0xFF06110E,BG_3=0xFF0A1713,CARD_1=0xFF091512,CARD_2=0xFF0D1D18,TEXT=0xFFF7F3E8,MUTED=0xFFB8B8B0,FIELD=0xFF10211C;
    public static final int PURPLE=0xFFD6A93A,VIOLET=0xFFB88925,CYAN=0xFF39D6C0,TEAL=0xFF0F8B6D,PINK=0xFFD9789C,BLUE=0xFF67A9D8,GOLD=0xFFF2C75C,ORANGE=0xFFE49B45,RED=0xFFE45B64,GREEN=0xFF35C978,INDIGO=0xFF8A83D8;
    private static int bg1(Context c){return BG_1;} private static int bg2(Context c){return BG_2;} private static int cardColor(Context c){return CARD_1;} private static int card2(Context c){return CARD_2;} private static int textColor(Context c){return TEXT;} private static int mutedColor(Context c){return MUTED;} private static int fieldColor(Context c){return FIELD;} private static int accent(Context c){return PURPLE;} private static int accent2(Context c){return TEAL;}
    public static int[] palette(Context c){return new int[]{bg1(c),bg2(c),cardColor(c),textColor(c),accent(c),mutedColor(c),fieldColor(c),accent2(c)};}
    public static int dp(Context c,int value){return Math.round(value*c.getResources().getDisplayMetrics().density);} public static int withAlpha(int color,int alpha){return Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));}
    private static int blend(int a,int b,float t){int r=(int)(Color.red(a)*(1-t)+Color.red(b)*t),g=(int)(Color.green(a)*(1-t)+Color.green(b)*t),bl=(int)(Color.blue(a)*(1-t)+Color.blue(b)*t);return Color.rgb(r,g,bl);}

    public static Drawable screenBackground(Context c){
        // Master UI: deterministic black/emerald background; never fall back to legacy theme artwork.
        return new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{bg1(c),blend(bg1(c),accent2(c),0.075f),blend(bg2(c),accent(c),0.055f),bg2(c)});
    }
    public static GradientDrawable rounded(Context c,int color,int radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radiusDp));return g;}
    private static Drawable layeredPanel(Context c,int[] borderColors,int[] fillColors,int radiusDp,int borderDp){GradientDrawable outer=new GradientDrawable(GradientDrawable.Orientation.TL_BR,borderColors);outer.setCornerRadius(dp(c,radiusDp));GradientDrawable inner=new GradientDrawable(GradientDrawable.Orientation.TL_BR,fillColors);inner.setCornerRadius(dp(c,Math.max(1,radiusDp-2)));LayerDrawable layers=new LayerDrawable(new Drawable[]{outer,inner});int inset=dp(c,borderDp);layers.setLayerInset(1,inset,inset,inset,inset);return layers;}
    private static int radius(Context c){return 24;} private static int elevation(Context c){return 4;} private static int buttonRadius(Context c){return 16;} private static String style(Context c){return "nexa_lux";}
    public static Drawable card(Context c){int a=accent(c),a2=accent2(c),base=cardColor(c);String s=style(c);int borderA=0xA0;return layeredPanel(c,new int[]{withAlpha(a,borderA),withAlpha(a2,borderA)},new int[]{blend(base,a,s.equals("neon")?0.055f:0.022f),base,blend(base,a2,0.018f)},radius(c),1);}
    public static Drawable colorfulCard(Context c,int variant){
        int a=accent(c),a2=accent2(c),base=cardColor(c);int[] accents={a,a2,BLUE,GREEN,PINK,GOLD,INDIGO,ORANGE};int x=accents[Math.floorMod(variant,accents.length)],y=accents[Math.floorMod(variant+2,accents.length)];String s=style(c);
        if("editorial".equals(s)&&variant%2==0){base=card2(c);x=blend(a,0xFF202823,.35f);y=a;}
        
        float tint=.055f;int alpha=0xA8;
        return layeredPanel(c,new int[]{withAlpha(x,alpha),withAlpha(y,alpha),withAlpha(a2,0x58)},new int[]{blend(base,x,tint),base,blend(base,y,tint*.45f)},radius(c),1);
    }
    public static Drawable field(Context c){return layeredPanel(c,new int[]{withAlpha(accent(c),0x4C),withAlpha(accent2(c),0x38)},new int[]{fieldColor(c),blend(fieldColor(c),accent(c),0.02f)},Math.max(12,radius(c)-7),1);}
    public static Drawable heroSurface(Context c){return layeredPanel(c,new int[]{withAlpha(GOLD,0xD8),withAlpha(TEAL,0xA8),withAlpha(GOLD,0x78)},new int[]{blend(BG_2,TEAL,.18f),blend(CARD_1,GOLD,.07f),blend(BG_1,TEAL,.10f)},26,1);}
    public static Drawable accentCard(Context c){int a=accent(c),a2=accent2(c);return layeredPanel(c,new int[]{a,a2,blend(a,a2,.5f)},new int[]{blend(cardColor(c),a,.09f),blend(cardColor(c),a2,.055f),cardColor(c)},radius(c)+3,1);}
    public static Drawable bottomNavBackground(Context c){return layeredPanel(c,new int[]{withAlpha(accent(c),0x78),withAlpha(accent2(c),0x66)},new int[]{withAlpha(cardColor(c),0xF4),withAlpha(bg2(c),0xF4)},radius(c)+1,1);}

    private static Typeface bodyFace(boolean bold){return Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL);} private static Typeface mediumFace(){return Typeface.create("sans-serif-medium",Typeface.NORMAL);}
    public static TextView title(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(GOLD);tv.setTextSize(25f);tv.setTypeface(bodyFace(true));tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(0f,1.10f);return tv;}
    public static TextView sectionTitle(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(GOLD);tv.setTextSize(17f);tv.setTypeface(mediumFace());tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(0f,1.16f);return tv;}
    public static TextView muted(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(mutedColor(c));tv.setTextSize(14.5f);tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(dp(c,2),1.12f);return tv;}
    /** Uses the approved per-screen artwork as the visual focal panel. Business data stays native below it. */
    public static LinearLayout referenceHero(Context c,int drawableRes,String title,String subtitle){
        LinearLayout box=accentCardLayout(c);
        box.setPadding(dp(c,8),dp(c,8),dp(c,8),dp(c,12));
        ImageView art=new ImageView(c); art.setImageResource(drawableRes); art.setScaleType(ImageView.ScaleType.CENTER_CROP); art.setAdjustViewBounds(true);
        GradientDrawable frame=new GradientDrawable(); frame.setColor(CARD_2); frame.setCornerRadius(dp(c,22)); frame.setStroke(dp(c,1),withAlpha(GOLD,0xA8)); art.setBackground(frame); art.setClipToOutline(Build.VERSION.SDK_INT>=21);
        box.addView(art,new LinearLayout.LayoutParams(-1,dp(c,190)));
        if(title!=null&&!title.isEmpty()){TextView t=sectionTitle(c,title);t.setGravity(Gravity.CENTER);t.setTextSize(18f);box.addView(t,matchWrap(c,10,2));}
        if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=muted(c,subtitle);sub.setGravity(Gravity.CENTER);sub.setTextSize(13f);box.addView(sub,matchWrap(c,2,0));}
        return box;
    }

    /** Native reference-inspired feature hero. No mockup/screenshot assets are embedded in the app. */
    public static LinearLayout featureHero(Context c,String kind,String title,String subtitle){
        LinearLayout box=accentCardLayout(c);box.setGravity(Gravity.CENTER);box.setPadding(dp(c,10),dp(c,10),dp(c,10),dp(c,14));
        FeatureArtView art=new FeatureArtView(c,kind);box.addView(art,new LinearLayout.LayoutParams(-1,dp(c,150)));
        TextView t=sectionTitle(c,title);t.setGravity(Gravity.CENTER);t.setTextSize(19f);box.addView(t,matchWrap(c,10,3));
        if(subtitle!=null&&!subtitle.trim().isEmpty()){TextView sub=muted(c,subtitle);sub.setGravity(Gravity.CENTER);sub.setTextSize(13.5f);box.addView(sub,matchWrap(c,1,0));}
        return box;
    }
    private static final class FeatureArtView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final String kind;
        FeatureArtView(Context c,String k){super(c);kind=k==null?"":k;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas x){super.onDraw(x);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;
            p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,0,w,h,new int[]{0xFF06130F,0xFF0A241C,0xFF07110E},null,Shader.TileMode.CLAMP));x.drawRoundRect(0,0,w,h,dp(getContext(),22),dp(getContext(),22),p);p.setShader(null);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(getContext(),1));p.setColor(withAlpha(GOLD,0x80));x.drawRoundRect(1,1,w-1,h-1,dp(getContext(),22),dp(getContext(),22),p);
            p.setShadowLayer(dp(getContext(),16),0,0,withAlpha(GOLD,0x55));p.setStrokeWidth(dp(getContext(),5));p.setStrokeCap(Paint.Cap.ROUND);p.setColor(GOLD);
            if(kind.equals("weather")){x.drawCircle(cx-28,cy+5,24,p);x.drawCircle(cx+4,cy-4,34,p);x.drawCircle(cx+38,cy+8,22,p);x.drawLine(cx-45,cy+36,cx+55,cy+36,p);p.setColor(CYAN);for(int i=-1;i<=1;i++)x.drawLine(cx+i*30,cy+50,cx-8+i*30,cy+66,p);}
            else if(kind.equals("market")){x.drawLine(cx-72,cy+48,cx-72,cy-46,p);x.drawLine(cx-72,cy+48,cx+76,cy+48,p);Path q=new Path();q.moveTo(cx-58,cy+26);q.lineTo(cx-28,cy-8);q.lineTo(cx+2,cy+10);q.lineTo(cx+34,cy-38);q.lineTo(cx+66,cy-18);x.drawPath(q,p);p.setColor(GREEN);x.drawCircle(cx+34,cy-38,9,p);p.setColor(GOLD);x.drawCircle(cx-28,cy-8,7,p);}
            else if(kind.equals("battery")){x.drawRoundRect(cx-74,cy-42,cx+62,cy+42,16,16,p);x.drawRoundRect(cx+64,cy-17,cx+78,cy+17,5,5,p);Path q=new Path();q.moveTo(cx+6,cy-30);q.lineTo(cx-20,cy+5);q.lineTo(cx+2,cy+5);q.lineTo(cx-10,cy+32);q.lineTo(cx+30,cy-10);q.lineTo(cx+8,cy-10);q.close();p.setStyle(Paint.Style.FILL);p.setColor(GREEN);x.drawPath(q,p);p.setStyle(Paint.Style.STROKE);p.setColor(GOLD);}
            else if(kind.equals("vehicle")){x.drawRoundRect(cx-78,cy-18,cx+78,cy+28,18,18,p);x.drawLine(cx-52,cy-18,cx-28,cy-45,p);x.drawLine(cx-28,cy-45,cx+38,cy-45,p);x.drawLine(cx+38,cy-45,cx+60,cy-18,p);x.drawCircle(cx-48,cy+32,15,p);x.drawCircle(cx+48,cy+32,15,p);}
            else if(kind.equals("ledger")){x.drawRoundRect(cx-76,cy-48,cx+76,cy+48,18,18,p);x.drawLine(cx-58,cy-18,cx+38,cy-18,p);x.drawLine(cx-58,cy+4,cx+18,cy+4,p);x.drawLine(cx-58,cy+26,cx+48,cy+26,p);p.setColor(GREEN);x.drawCircle(cx+54,cy-17,10,p);}
            else if(kind.equals("bills")){x.drawRoundRect(cx-58,cy-58,cx+58,cy+58,12,12,p);for(int i=0;i<4;i++)x.drawLine(cx-36,cy-30+i*20,cx+36,cy-30+i*20,p);p.setColor(GREEN);x.drawCircle(cx+62,cy+42,18,p);x.drawLine(cx+53,cy+42,cx+60,cy+50,p);x.drawLine(cx+60,cy+50,cx+73,cy+33,p);}
            else if(kind.equals("home")){Path q=new Path();q.moveTo(cx-78,cy-4);q.lineTo(cx,cy-66);q.lineTo(cx+78,cy-4);q.moveTo(cx-56,cy-18);q.lineTo(cx-56,cy+58);q.lineTo(cx+56,cy+58);q.lineTo(cx+56,cy-18);x.drawPath(q,p);x.drawRoundRect(cx-15,cy+12,cx+18,cy+58,4,4,p);}
            else if(kind.equals("security")||kind.equals("vault")){Path q=new Path();q.moveTo(cx,cy-62);q.lineTo(cx+58,cy-38);q.lineTo(cx+48,cy+26);q.quadTo(cx,cy+70,cx-48,cy+26);q.lineTo(cx-58,cy-38);q.close();x.drawPath(q,p);x.drawCircle(cx,cy-4,12,p);x.drawLine(cx,cy+8,cx,cy+30,p);}
            else if(kind.equals("emergency")){x.drawCircle(cx,cy,62,p);x.drawLine(cx-34,cy,cx+34,cy,p);x.drawLine(cx,cy-34,cx,cy+34,p);}
            else if(kind.equals("timeline")){x.drawLine(cx,cy-62,cx,cy+62,p);for(int i=-2;i<=2;i++){float yy=cy+i*28;x.drawCircle(cx,yy,8,p);x.drawLine(cx+14,yy,cx+64,yy,p);}}
            else if(kind.equals("reminder")){x.drawCircle(cx,cy+4,52,p);x.drawLine(cx,cy+4,cx,cy-28,p);x.drawLine(cx,cy+4,cx+28,cy+18,p);x.drawLine(cx-34,cy-48,cx-52,cy-62,p);x.drawLine(cx+34,cy-48,cx+52,cy-62,p);}
            else if(kind.equals("legal")){x.drawLine(cx,cy-54,cx,cy+46,p);x.drawLine(cx-62,cy-32,cx+62,cy-32,p);x.drawLine(cx-42,cy-32,cx-66,cy+18,p);x.drawLine(cx+42,cy-32,cx+66,cy+18,p);x.drawLine(cx-82,cy+18,cx-50,cy+18,p);x.drawLine(cx+50,cy+18,cx+82,cy+18,p);x.drawLine(cx-40,cy+50,cx+40,cy+50,p);}
            else if(kind.equals("files")){x.drawRoundRect(cx-70,cy-46,cx+70,cy+54,12,12,p);x.drawLine(cx-48,cy-18,cx+48,cy-18,p);x.drawLine(cx-48,cy+6,cx+34,cy+6,p);x.drawLine(cx-48,cy+30,cx+18,cy+30,p);}
            else if(kind.equals("silent")){x.drawCircle(cx,cy-2,44,p);x.drawLine(cx-54,cy-48,cx+54,cy+48,p);x.drawLine(cx-72,cy-2,cx-48,cy-2,p);x.drawLine(cx+48,cy-2,cx+72,cy-2,p);}
            else if(kind.equals("quick")){x.drawCircle(cx,cy,56,p);x.drawLine(cx-28,cy,cx+28,cy,p);x.drawLine(cx,cy-28,cx,cy+28,p);}
            else if(kind.equals("today")){x.drawCircle(cx,cy,54,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;x.drawLine(cx+(float)Math.cos(a)*68,cy+(float)Math.sin(a)*68,cx+(float)Math.cos(a)*82,cy+(float)Math.sin(a)*82,p);}}
            else {p.setStyle(Paint.Style.FILL);x.drawCircle(cx,cy,48,p);p.setColor(BG_1);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(getContext(),34));p.setTypeface(Typeface.DEFAULT_BOLD);x.drawText("N",cx,cy+12,p);}
            p.clearShadowLayer();
        }
    }

    /** Pixel-UI master hero shared by feature screens: a visual focal panel followed by concise Persian context. */
    public static LinearLayout masterHero(Context c,String icon,String title,String subtitle,int variant){
        LinearLayout box=colorfulCardLayout(c,variant);
        box.setGravity(Gravity.CENTER);
        box.setPadding(dp(c,18),dp(c,18),dp(c,18),dp(c,16));
        TextView art=new TextView(c);art.setText(icon);art.setTextSize(54f);art.setGravity(Gravity.CENTER);art.setMinHeight(dp(c,82));art.setTextColor(GOLD);
        GradientDrawable halo=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{withAlpha(GOLD,0x18),withAlpha(TEAL,0x20),withAlpha(CARD_2,0xF2)});halo.setCornerRadius(dp(c,22));halo.setStroke(dp(c,1),withAlpha(GOLD,0x80));art.setBackground(halo);
        box.addView(art,new LinearLayout.LayoutParams(-1,dp(c,96)));
        TextView t=sectionTitle(c,title);t.setGravity(Gravity.CENTER);t.setTextSize(18f);box.addView(t,matchWrap(c,12,4));
        if(subtitle!=null&&!subtitle.trim().isEmpty()){TextView sub=muted(c,subtitle);sub.setGravity(Gravity.CENTER);sub.setTextSize(13.5f);box.addView(sub,matchWrap(c,2,0));}
        return box;
    }

    public static LinearLayout cardLayout(Context c){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));card.setBackground(card(c));card.setElevation(dp(c,elevation(c)));return card;}
    public static LinearLayout accentCardLayout(Context c){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,17),dp(c,15),dp(c,17),dp(c,15));card.setBackground(accentCard(c));card.setElevation(dp(c,elevation(c)+1));return card;}
    public static LinearLayout colorfulCardLayout(Context c,int variant){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));card.setBackground(colorfulCard(c,variant));card.setElevation(dp(c,elevation(c)));return card;}

    public static Button primaryButton(Context c,String text){Button b=new Button(c);b.setTag("nexa_primary");b.setAllCaps(false);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(14.5f);b.setTypeface(mediumFace());int h=48;b.setMinHeight(dp(c,h));b.setMinimumHeight(dp(c,h));String t=text==null?"":text.trim();int a=accent(c),a2=accent2(c);int[] colors;if(t.contains("حذف")||t.contains("پاک")||t.contains("خاموش"))colors=new int[]{0xFFB42318,RED};else if(t.contains("افزود")||t.contains("جدید")||t.startsWith("＋")||t.startsWith("➕"))colors=new int[]{blend(a2,GREEN,.30f),a2};else if(t.contains("باز")||t.contains("مشاهده"))colors=new int[]{blend(a2,BLUE,.38f),BLUE};else colors=new int[]{a,blend(a,a2,.55f),a2};GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(c,buttonRadius(c)));b.setBackground(g);b.setPadding(dp(c,14),dp(c,4),dp(c,14),dp(c,4));b.setElevation(dp(c,2));return b;}
    public static Button secondaryButton(Context c,String text){Button b=new Button(c);b.setTag("nexa_secondary");b.setAllCaps(false);b.setText(text);b.setTextColor(textColor(c));b.setTextSize(14f);b.setTypeface(mediumFace());b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));b.setPadding(dp(c,11),dp(c,4),dp(c,11),dp(c,4));b.setElevation(dp(c,1));String t=text==null?"":text.trim();int fill=blend(fieldColor(c),cardColor(c),.30f),stroke=withAlpha(accent2(c),0x55);if(t.contains("حذف")||t.contains("پاک")||t.contains("🗑")){fill=blend(fieldColor(c),RED,.13f);stroke=withAlpha(RED,0xB0);}else if(t.contains("ویرایش")||t.contains("✎")||t.contains("✏")){stroke=withAlpha(INDIGO,0xA0);}else if(t.contains("باز")||t.contains("مشاهده")){stroke=withAlpha(accent2(c),0xB0);}else if(t.contains("افزود")||t.contains("جدید")||t.equals("+")||t.equals("＋")){stroke=withAlpha(GREEN,0xB0);}GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setStroke(dp(c,1),stroke);g.setCornerRadius(dp(c,Math.max(11,buttonRadius(c)-1)));b.setBackground(g);return b;}
    public static Button iconButton(Context c,String icon,String desc,int a){Button b=new Button(c);b.setTag("nexa_icon");b.setAllCaps(false);b.setText(icon);b.setContentDescription(desc);b.setTextColor(textColor(c));b.setTextSize(18f);b.setGravity(Gravity.CENTER);b.setMinWidth(dp(c,48));b.setMinimumWidth(dp(c,48));b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));GradientDrawable g=new GradientDrawable();g.setColor(withAlpha(cardColor(c),0xED));g.setStroke(dp(c,1),withAlpha(a,0x82));g.setCornerRadius(dp(c,Math.max(10,buttonRadius(c)-2)));b.setBackground(g);b.setPadding(0,0,0,0);b.setElevation(dp(c,1));return b;}
    public static Button editIconButton(Context c){return iconButton(c,"✎","ویرایش",INDIGO);} public static Button deleteIconButton(Context c){return iconButton(c,"🗑","حذف",RED);} public static Button addIconButton(Context c){return iconButton(c,"＋","افزودن",GREEN);} public static Button openIconButton(Context c){return iconButton(c,"›","باز کردن",CYAN);}
    public static Button backButton(Context c){Button b=new Button(c);b.setTag("nexa_back");b.setAllCaps(false);b.setText("→");b.setContentDescription("بازگشت");b.setTextColor(textColor(c));b.setTextSize(25f);b.setGravity(Gravity.CENTER);b.setMinWidth(dp(c,48));b.setMinimumWidth(dp(c,48));b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);b.setElevation(0);return b;}
    public static LinearLayout header(Context c,String title,View.OnClickListener back){LinearLayout h=new LinearLayout(c);h.setGravity(Gravity.CENTER_VERTICAL);h.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);TextView t=title(c,title);h.addView(t,new LinearLayout.LayoutParams(0,-2,1f));Button b=backButton(c);b.setOnClickListener(back);h.addView(b,new LinearLayout.LayoutParams(dp(c,48),dp(c,48)));return h;}
    public static Switch styledSwitch(Context c){Switch s=new Switch(c);s.setTextColor(textColor(c));s.setTextSize(14.5f);s.setGravity(Gravity.CENTER_VERTICAL);s.setMinHeight(dp(c,48));s.setMinimumHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21){int[][] states=new int[][]{new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}};int[] thumb=new int[]{GOLD,0xFF6F7C76};int[] track=new int[]{withAlpha(TEAL,0xA0),withAlpha(MUTED,0x50)};s.setThumbTintList(new android.content.res.ColorStateList(states,thumb));s.setTrackTintList(new android.content.res.ColorStateList(states,track));}return s;}
    public static Spinner styledSpinner(Context c){Spinner s=new Spinner(c);s.setMinimumHeight(dp(c,48));s.setBackground(field(c));s.setPadding(dp(c,12),0,dp(c,12),0);s.setPopupBackgroundDrawable(rounded(c,CARD_2,14));return s;}
    public static EditText styleField(Context c,EditText e,String hint){e.setMinHeight(dp(c,48));e.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);e.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);e.setHint(hint);e.setHintTextColor(mutedColor(c));e.setTextColor(textColor(c));e.setBackground(field(c));e.setPadding(dp(c,13),dp(c,9),dp(c,13),dp(c,9));e.setTextSize(16f);return e;}
    public static LinearLayout dialogPanel(Context c){LinearLayout box=new LinearLayout(c);box.setOrientation(LinearLayout.VERTICAL);box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);box.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,10));box.setBackground(accentCard(c));box.setElevation(dp(c,5));return box;}
    public static TextView fieldLabel(Context c,String text){TextView tv=muted(c,text);tv.setTextColor(withAlpha(GOLD,0xE8));tv.setTextSize(13f);tv.setTypeface(mediumFace());tv.setPadding(dp(c,2),dp(c,8),dp(c,2),dp(c,4));return tv;}
    public static LinearLayout formSection(Context c,String title,String subtitle){LinearLayout box=colorfulCardLayout(c,5);box.addView(sectionTitle(c,title));if(subtitle!=null&&!subtitle.trim().isEmpty())box.addView(muted(c,subtitle),matchWrap(c,4,8));return box;}
    public static TextView navCard(Context c,String icon,String title,String subtitle){TextView tv=new TextView(c);tv.setText(icon+"   "+title+"\n      "+subtitle);tv.setTextColor(textColor(c));tv.setTextSize(16f);tv.setTypeface(mediumFace());tv.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);tv.setLineSpacing(0f,1.25f);tv.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));tv.setBackground(colorfulCard(c,title.contains("تماس")?2:0));tv.setElevation(dp(c,elevation(c)));return tv;}
    public static TextView chip(Context c,String text,boolean active){TextView tv=new TextView(c);tv.setText(text);tv.setTextSize(13f);tv.setGravity(Gravity.CENTER);tv.setPadding(dp(c,12),dp(c,7),dp(c,12),dp(c,7));if(active){tv.setTextColor(Color.WHITE);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent(c),accent2(c)});g.setCornerRadius(dp(c,100));tv.setBackground(g);}else{tv.setTextColor(textColor(c));tv.setBackground(field(c));}return tv;}

    public static LinearLayout collapsible(Context c,String key,String title,String subtitle,int variant,boolean important,View content){LinearLayout outer=colorfulCardLayout(c,variant);android.content.SharedPreferences prefs=c.getSharedPreferences("nexa_ui_sections",Context.MODE_PRIVATE);boolean pinned=important||prefs.getBoolean(key+"_pinned",false);boolean open=important||prefs.getBoolean(key+"_open",false)||pinned;LinearLayout head=new LinearLayout(c);head.setGravity(Gravity.CENTER_VERTICAL);TextView tt=sectionTitle(c,title);head.addView(tt,new LinearLayout.LayoutParams(0,-2,1f));TextView arrow=new TextView(c);arrow.setText(open?"⌃":"⌄");arrow.setTextColor(mutedColor(c));arrow.setTextSize(21);arrow.setGravity(Gravity.CENTER);head.addView(arrow,new LinearLayout.LayoutParams(dp(c,36),dp(c,36)));outer.addView(head);if(subtitle!=null&&!subtitle.isEmpty())outer.addView(muted(c,subtitle),matchWrap(c,4,6));LinearLayout body=new LinearLayout(c);body.setOrientation(LinearLayout.VERTICAL);body.addView(content);body.setVisibility(open?View.VISIBLE:View.GONE);outer.addView(body);if(!important){TextView pin=muted(c,pinned?"✓ همیشه باز":"○ همیشه باز");pin.setTextSize(12.5f);pin.setPadding(0,dp(c,7),0,0);outer.addView(pin);pin.setOnClickListener(v->{boolean now=!prefs.getBoolean(key+"_pinned",false);prefs.edit().putBoolean(key+"_pinned",now).apply();pin.setText(now?"✓ همیشه باز":"○ همیشه باز");if(now){body.setVisibility(View.VISIBLE);arrow.setText("⌃");prefs.edit().putBoolean(key+"_open",true).apply();}});}if(!important)head.setOnClickListener(v->{boolean now=body.getVisibility()!=View.VISIBLE;body.setVisibility(now?View.VISIBLE:View.GONE);arrow.setText(now?"⌃":"⌄");prefs.edit().putBoolean(key+"_open",now).apply();});return outer;}
    public static LinearLayout bottomNav(Context c,int selected,View.OnClickListener home,View.OnClickListener today,View.OnClickListener add,View.OnClickListener history){LinearLayout nav=new LinearLayout(c);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(c,6),dp(c,5),dp(c,6),dp(c,5));nav.setBackground(bottomNavBackground(c));nav.setElevation(dp(c,5));TextView[] tabs={navTab(c,"⌂\nخانه",selected==0,accent(c)),navTab(c,"✦\nامروز",selected==1,accent2(c)),navTab(c,"＋\nثبت سریع",selected==2,GREEN),navTab(c,"☷\nتاریخچه",selected==3,INDIGO)};View.OnClickListener[] ls={home,today,add,history};LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);for(int i=0;i<tabs.length;i++){tabs[i].setOnClickListener(ls[i]);nav.addView(tabs[i],lp);}return nav;}
    private static TextView navTab(Context c,String text,boolean selected,int a){TextView tv=new TextView(c);tv.setText(text);tv.setGravity(Gravity.CENTER);tv.setTextSize(11.5f);tv.setTextColor(selected?a:mutedColor(c));tv.setTypeface(Typeface.create("sans-serif-medium",selected?Typeface.BOLD:Typeface.NORMAL));tv.setMinHeight(dp(c,48));tv.setPadding(dp(c,5),dp(c,4),dp(c,5),dp(c,4));return tv;}
    public static TextView emptyState(Context c,String title,String detail){TextView tv=new TextView(c);tv.setText("◇  "+title+(detail==null||detail.trim().isEmpty()?"":"\n"+detail));tv.setTextColor(mutedColor(c));tv.setTextSize(14.5f);tv.setGravity(Gravity.CENTER);tv.setLineSpacing(dp(c,3),1.15f);tv.setPadding(dp(c,18),dp(c,22),dp(c,18),dp(c,22));tv.setBackground(field(c));return tv;}
    public static TextView statusBadge(Context c,String text,int color){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(textColor(c));tv.setTextSize(12.5f);tv.setGravity(Gravity.CENTER);tv.setPadding(dp(c,10),dp(c,6),dp(c,10),dp(c,6));GradientDrawable g=new GradientDrawable();g.setColor(withAlpha(color,0x24));g.setStroke(dp(c,1),withAlpha(color,0xA0));g.setCornerRadius(dp(c,100));tv.setBackground(g);return tv;}

    /** Applies the approved Nexa luxury visual language to legacy controls too, so old screens
     * inherit the same RTL spacing, touch targets and black/emerald/gold hierarchy without
     * rewriting their business logic. */
    public static void polishTree(Context c, View v){
        if(v==null)return;
        v.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if(v instanceof TextView){TextView tv=(TextView)v;tv.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);tv.setIncludeFontPadding(false);tv.setLineSpacing(dp(c,1),1.08f);}
        if(v instanceof EditText){EditText e=(EditText)v;if(e.getBackground()==null || e.getBackground().getClass().getName().contains("ColorDrawable")){e.setBackground(field(c));}e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setMinHeight(dp(c,48));e.setPadding(dp(c,13),dp(c,9),dp(c,13),dp(c,9));}
        else if(v instanceof Switch){Switch sw=(Switch)v;sw.setTextColor(TEXT);sw.setMinHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21){int[][] st={new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}};sw.setThumbTintList(new android.content.res.ColorStateList(st,new int[]{GOLD,0xFF6F7C76}));sw.setTrackTintList(new android.content.res.ColorStateList(st,new int[]{withAlpha(TEAL,0xA0),withAlpha(MUTED,0x50)}));}}
        else if(v instanceof Spinner){Spinner sp=(Spinner)v;sp.setMinimumHeight(dp(c,48));sp.setPadding(dp(c,12),0,dp(c,12),0);try{sp.setPopupBackgroundDrawable(rounded(c,CARD_2,14));}catch(Exception ignored){}}
        else if(v instanceof CheckBox){CheckBox cb=(CheckBox)v;cb.setTextColor(TEXT);cb.setMinHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21)cb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}},new int[]{GOLD,MUTED}));}
        else if(v instanceof RadioButton){RadioButton rb=(RadioButton)v;rb.setTextColor(TEXT);rb.setMinHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21)rb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}},new int[]{GOLD,MUTED}));}
        else if(v instanceof SeekBar){SeekBar sb=(SeekBar)v;if(Build.VERSION.SDK_INT>=21){sb.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));sb.setThumbTintList(android.content.res.ColorStateList.valueOf(TEAL));}}
        else if(v instanceof ProgressBar){ProgressBar pb=(ProgressBar)v;if(Build.VERSION.SDK_INT>=21)pb.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));}
        else if(v instanceof AutoCompleteTextView){AutoCompleteTextView ac=(AutoCompleteTextView)v;ac.setDropDownBackgroundDrawable(rounded(c,CARD_2,14));ac.setDropDownVerticalOffset(dp(c,4));}
        else if(v instanceof ListView){ListView lv=(ListView)v;lv.setDivider(rounded(c,withAlpha(GOLD,0x28),1));lv.setDividerHeight(dp(c,1));lv.setCacheColorHint(Color.TRANSPARENT);}
        else if(v instanceof NumberPicker){NumberPicker np=(NumberPicker)v;np.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);}
        else if(v instanceof Button){Button b=(Button)v;b.setAllCaps(false);b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));if(b.getTag()!=null && b.getTag().toString().startsWith("nexa_")){/* keep intentional Master UI styling */}else{b.setTypeface(mediumFace());b.setTextColor(TEXT);b.setPadding(dp(c,12),dp(c,5),dp(c,12),dp(c,5));String bt=b.getText()==null?"":b.getText().toString();int stroke=withAlpha(GOLD,0x82),fill=blend(FIELD,CARD_1,.28f);if(bt.contains("حذف")||bt.contains("پاک")||bt.contains("لغو")){stroke=withAlpha(RED,0xA8);fill=blend(FIELD,RED,.10f);}else if(bt.contains("افزود")||bt.contains("ثبت")||bt.contains("ذخیره")||bt.contains("تأیید")||bt.contains("اعمال")){stroke=withAlpha(TEAL,0xB8);fill=blend(FIELD,TEAL,.13f);}GradientDrawable bg=new GradientDrawable();bg.setColor(fill);bg.setStroke(dp(c,1),stroke);bg.setCornerRadius(dp(c,16));b.setBackground(bg);b.setElevation(dp(c,1));}}
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;g.setClipToPadding(false);if(g instanceof LinearLayout && g.getChildCount()>1 && g.getPaddingLeft()==0 && g.getPaddingRight()==0){g.setPadding(dp(c,2),dp(c,2),dp(c,2),dp(c,2));}for(int i=0;i<g.getChildCount();i++)polishTree(c,g.getChildAt(i));}
    }
    private static void installLuxuryPolish(Activity a){
        final View decor=a.getWindow().getDecorView();
        decor.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener(){
            boolean busy=false; public void onGlobalLayout(){if(busy)return;busy=true;try{polishTree(a,decor);}finally{busy=false;}}
        });
    }

    public static void applyWindow(Activity a){BG_1=bg1(a);BG_2=bg2(a);CARD_1=cardColor(a);CARD_2=card2(a);TEXT=textColor(a);MUTED=mutedColor(a);FIELD=fieldColor(a);int bg=bg1(a);a.getWindow().setStatusBarColor(bg);a.getWindow().setNavigationBarColor(bg);a.getWindow().getDecorView().setBackgroundColor(bg);a.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);if(Build.VERSION.SDK_INT>=29)a.getWindow().setNavigationBarContrastEnforced(false);installLuxuryPolish(a);int flags=a.getWindow().getDecorView().getSystemUiVisibility();flags&=~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;if(Build.VERSION.SDK_INT>=26)flags&=~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;a.getWindow().getDecorView().setSystemUiVisibility(flags);}
    public static LinearLayout.LayoutParams matchWrap(Context c){return new LinearLayout.LayoutParams(-1,-2);} public static LinearLayout.LayoutParams matchWrap(Context c,int top,int bottom){LinearLayout.LayoutParams p=matchWrap(c);p.setMargins(0,dp(c,top),0,dp(c,bottom));return p;}
}
