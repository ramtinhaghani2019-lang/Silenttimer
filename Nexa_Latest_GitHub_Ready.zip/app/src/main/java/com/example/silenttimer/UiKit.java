package com.example.silenttimer;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class UiKit {
    private UiKit() {}

    // Compatibility constants used by older modules. New surfaces read the active ThemeManager palette.
    public static int BG_1=0xFF04050A,BG_2=0xFF090A12,BG_3=0xFF0D101A,CARD_1=0xFF12141D,CARD_2=0xFF181A25,TEXT=0xFFF8F9FF,MUTED=0xFF9DA3B5,FIELD=0xFF1E202B;
    public static final int PURPLE=0xFF8B5CF6,VIOLET=0xFF6D5DFB,CYAN=0xFF22D3EE,TEAL=0xFF2DD4BF,PINK=0xFFF472B6,BLUE=0xFF60A5FA,GOLD=0xFFFBBF24,ORANGE=0xFFFB923C,RED=0xFFFB7185,GREEN=0xFF34D399,INDIGO=0xFF818CF8;

    private static int bg1(Context c){return ThemeManager.color(c,"bg1",BG_1);} private static int bg2(Context c){return ThemeManager.color(c,"bg2",BG_2);} private static int cardColor(Context c){return ThemeManager.color(c,"card",CARD_1);} private static int textColor(Context c){return ThemeManager.color(c,"text",TEXT);} private static int mutedColor(Context c){return ThemeManager.color(c,"muted",MUTED);} private static int fieldColor(Context c){return ThemeManager.color(c,"field",FIELD);} private static int accent(Context c){return ThemeManager.color(c,"accent",PURPLE);} private static int accent2(Context c){return ThemeManager.color(c,"accent2",TEAL);}
    public static int[] palette(Context c){return new int[]{bg1(c),bg2(c),cardColor(c),textColor(c),accent(c),mutedColor(c),fieldColor(c),accent2(c)};}
    public static int dp(Context c,int value){return Math.round(value*c.getResources().getDisplayMetrics().density);} public static int withAlpha(int color,int alpha){return Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));}

    public static GradientDrawable screenBackground(Context c){return new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{bg1(c),blend(bg1(c),accent2(c),0.07f),blend(bg2(c),accent(c),0.06f),bg2(c)});}
    public static GradientDrawable rounded(Context c,int color,int radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radiusDp));return g;}
    private static int blend(int a,int b,float t){int r=(int)(Color.red(a)*(1-t)+Color.red(b)*t),g=(int)(Color.green(a)*(1-t)+Color.green(b)*t),bl=(int)(Color.blue(a)*(1-t)+Color.blue(b)*t);return Color.rgb(r,g,bl);}
    private static Drawable layeredPanel(Context c,int[] borderColors,int[] fillColors,int radiusDp,int borderDp){GradientDrawable outer=new GradientDrawable(GradientDrawable.Orientation.TL_BR,borderColors);outer.setCornerRadius(dp(c,radiusDp));GradientDrawable inner=new GradientDrawable(GradientDrawable.Orientation.TL_BR,fillColors);inner.setCornerRadius(dp(c,Math.max(1,radiusDp-2)));LayerDrawable layers=new LayerDrawable(new Drawable[]{outer,inner});int inset=dp(c,borderDp);layers.setLayerInset(1,inset,inset,inset,inset);return layers;}
    public static Drawable card(Context c){int a=accent(c),a2=accent2(c),base=cardColor(c);return layeredPanel(c,new int[]{withAlpha(a,0x72),withAlpha(a2,0x66)},new int[]{blend(base,a,0.03f),base,blend(base,a2,0.025f)},22,1);}
    public static Drawable colorfulCard(Context c,int variant){int a=accent(c),a2=accent2(c),base=cardColor(c);int[] accents={a,a2,BLUE,GREEN,PINK,GOLD,INDIGO,ORANGE};int x=accents[Math.floorMod(variant,accents.length)];int y=accents[Math.floorMod(variant+2,accents.length)];if(!ThemeManager.dark(c)){x=blend(x,Color.WHITE,0.18f);y=blend(y,Color.WHITE,0.28f);}return layeredPanel(c,new int[]{withAlpha(x,0xA0),withAlpha(y,0x72),withAlpha(a2,0x50)},new int[]{blend(base,x,ThemeManager.dark(c)?0.08f:0.04f),base,blend(base,y,0.025f)},24,1);}
    public static Drawable field(Context c){return layeredPanel(c,new int[]{withAlpha(accent(c),0x55),withAlpha(accent2(c),0x42)},new int[]{fieldColor(c),blend(fieldColor(c),accent(c),0.025f)},15,1);}
    public static Drawable accentCard(Context c){int a=accent(c),a2=accent2(c);return layeredPanel(c,new int[]{a,a2,blend(a,a2,.5f)},new int[]{blend(cardColor(c),a,.10f),blend(cardColor(c),a2,.06f),cardColor(c)},27,1);}
    public static Drawable bottomNavBackground(Context c){return layeredPanel(c,new int[]{withAlpha(accent(c),0x8A),withAlpha(accent2(c),0x72)},new int[]{withAlpha(cardColor(c),0xFA),withAlpha(bg2(c),0xFA)},23,1);}

    private static Typeface bodyFace(boolean bold){return Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL);} private static Typeface mediumFace(){return Typeface.create("sans-serif-medium",Typeface.NORMAL);}
    public static TextView title(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(textColor(c));tv.setTextSize(29f);tv.setTypeface(bodyFace(true));tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(0f,1.12f);return tv;}
    public static TextView sectionTitle(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(textColor(c));tv.setTextSize(18f);tv.setTypeface(mediumFace());tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(0f,1.18f);return tv;}
    public static TextView muted(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(mutedColor(c));tv.setTextSize(14.5f);tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(dp(c,2),1.12f);return tv;}
    public static LinearLayout cardLayout(Context c){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));card.setBackground(card(c));card.setElevation(dp(c,3));return card;}
    public static LinearLayout colorfulCardLayout(Context c,int variant){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));card.setBackground(colorfulCard(c,variant));card.setElevation(dp(c,3));return card;}

    public static Button primaryButton(Context c,String text){Button b=new Button(c);b.setAllCaps(false);b.setText(text);b.setTextColor(Color.WHITE);b.setTextSize(14.5f);b.setTypeface(mediumFace());b.setMinHeight(dp(c,44));b.setMinimumHeight(dp(c,44));String t=text==null?"":text.trim();int a=accent(c),a2=accent2(c);int[] colors;if(t.contains("حذف")||t.contains("پاک")||t.contains("خاموش"))colors=new int[]{0xFFB42318,RED};else if(t.contains("افزود")||t.contains("جدید")||t.startsWith("＋")||t.startsWith("➕"))colors=new int[]{blend(a2,GREEN,.35f),a2};else if(t.contains("باز")||t.contains("مشاهده"))colors=new int[]{blend(a2,BLUE,.4f),BLUE};else colors=new int[]{a,blend(a,a2,.55f),a2};GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,colors);g.setCornerRadius(dp(c,14));b.setBackground(g);b.setPadding(dp(c,14),dp(c,6),dp(c,14),dp(c,6));b.setElevation(dp(c,2));return b;}
    public static Button secondaryButton(Context c,String text){Button b=new Button(c);b.setAllCaps(false);b.setText(text);b.setTextColor(textColor(c));b.setTextSize(14f);b.setTypeface(mediumFace());b.setMinHeight(dp(c,40));b.setMinimumHeight(dp(c,40));b.setPadding(dp(c,12),dp(c,5),dp(c,12),dp(c,5));b.setElevation(dp(c,1));String t=text==null?"":text.trim();int fill=blend(fieldColor(c),cardColor(c),.3f),stroke=withAlpha(accent2(c),0x55);if(t.contains("حذف")||t.contains("پاک")||t.contains("🗑")){fill=blend(fieldColor(c),RED,.13f);stroke=withAlpha(RED,0xB0);}else if(t.contains("ویرایش")||t.contains("✎")||t.contains("✏")){stroke=withAlpha(INDIGO,0xA0);}else if(t.contains("باز")||t.contains("مشاهده")){stroke=withAlpha(accent2(c),0xB0);}else if(t.contains("افزود")||t.contains("جدید")||t.equals("+")||t.equals("＋")){stroke=withAlpha(GREEN,0xB0);}GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setStroke(dp(c,1),stroke);g.setCornerRadius(dp(c,13));b.setBackground(g);return b;}
    public static Button iconButton(Context c,String icon,String desc,int a){Button b=new Button(c);b.setAllCaps(false);b.setText(icon);b.setContentDescription(desc);b.setTextColor(textColor(c));b.setTextSize(18f);b.setGravity(Gravity.CENTER);b.setMinWidth(dp(c,40));b.setMinimumWidth(dp(c,40));b.setMinHeight(dp(c,40));b.setMinimumHeight(dp(c,40));GradientDrawable g=new GradientDrawable();g.setColor(withAlpha(cardColor(c),0xF0));g.setStroke(dp(c,1),withAlpha(a,0x90));g.setCornerRadius(dp(c,12));b.setBackground(g);b.setPadding(0,0,0,0);b.setElevation(dp(c,1));return b;}
    public static Button editIconButton(Context c){return iconButton(c,"✎","ویرایش",INDIGO);} public static Button deleteIconButton(Context c){return iconButton(c,"🗑","حذف",RED);} public static Button addIconButton(Context c){return iconButton(c,"＋","افزودن",GREEN);} public static Button openIconButton(Context c){return iconButton(c,"›","باز کردن",CYAN);}
    public static Button backButton(Context c){Button b=new Button(c);b.setAllCaps(false);b.setText("←");b.setContentDescription("بازگشت");b.setTextColor(textColor(c));b.setTextSize(24f);b.setGravity(Gravity.CENTER);b.setMinWidth(dp(c,40));b.setMinimumWidth(dp(c,40));b.setMinHeight(dp(c,40));b.setMinimumHeight(dp(c,40));b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);b.setElevation(0);b.setLayoutParams(new LinearLayout.LayoutParams(dp(c,40),dp(c,40)));return b;}
    public static LinearLayout header(Context c,String title,View.OnClickListener back){LinearLayout h=new LinearLayout(c);h.setGravity(Gravity.CENTER_VERTICAL);h.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);TextView t=title(c,title);h.addView(t,new LinearLayout.LayoutParams(0,-2,1f));Button b=backButton(c);b.setOnClickListener(back);h.addView(b,new LinearLayout.LayoutParams(dp(c,40),dp(c,40)));return h;}
    public static EditText styleField(Context c,EditText e,String hint){e.setHint(hint);e.setHintTextColor(mutedColor(c));e.setTextColor(textColor(c));e.setBackground(field(c));e.setPadding(dp(c,13),dp(c,10),dp(c,13),dp(c,10));e.setTextSize(16f);return e;}
    public static LinearLayout dialogPanel(Context c){LinearLayout box=new LinearLayout(c);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(c,16),dp(c,12),dp(c,16),dp(c,8));box.setBackground(colorfulCard(c,6));return box;}
    public static TextView navCard(Context c,String icon,String title,String subtitle){TextView tv=new TextView(c);tv.setText(icon+"   "+title+"\n      "+subtitle);tv.setTextColor(textColor(c));tv.setTextSize(16f);tv.setTypeface(mediumFace());tv.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);tv.setLineSpacing(0f,1.25f);tv.setPadding(dp(c,16),dp(c,16),dp(c,16),dp(c,16));tv.setBackground(colorfulCard(c,title.contains("تماس")?2:0));tv.setElevation(dp(c,3));return tv;}
    public static TextView chip(Context c,String text,boolean active){TextView tv=new TextView(c);tv.setText(text);tv.setTextSize(13f);tv.setGravity(Gravity.CENTER);tv.setPadding(dp(c,12),dp(c,8),dp(c,12),dp(c,8));if(active){tv.setTextColor(Color.WHITE);GradientDrawable g=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{accent(c),accent2(c)});g.setCornerRadius(dp(c,100));tv.setBackground(g);}else{tv.setTextColor(textColor(c));tv.setBackground(field(c));}return tv;}

    /** Collapsible section with a per-section "always open" preference. Important summary sections can bypass collapse. */
    public static LinearLayout collapsible(Context c,String key,String title,String subtitle,int variant,boolean important,View content){
        LinearLayout outer=colorfulCardLayout(c,variant);
        android.content.SharedPreferences prefs=c.getSharedPreferences("nexa_ui_sections",Context.MODE_PRIVATE);
        boolean pinned=important||prefs.getBoolean(key+"_pinned",false);
        boolean open=important||prefs.getBoolean(key+"_open",false)||pinned;
        LinearLayout head=new LinearLayout(c);head.setGravity(Gravity.CENTER_VERTICAL);
        TextView tt=sectionTitle(c,title);head.addView(tt,new LinearLayout.LayoutParams(0,-2,1f));
        TextView arrow=new TextView(c);arrow.setText(open?"⌃":"⌄");arrow.setTextColor(mutedColor(c));arrow.setTextSize(21);arrow.setGravity(Gravity.CENTER);head.addView(arrow,new LinearLayout.LayoutParams(dp(c,36),dp(c,36)));outer.addView(head);
        if(subtitle!=null&&!subtitle.isEmpty())outer.addView(muted(c,subtitle),matchWrap(c,4,6));
        LinearLayout body=new LinearLayout(c);body.setOrientation(LinearLayout.VERTICAL);body.addView(content);body.setVisibility(open?View.VISIBLE:View.GONE);outer.addView(body);
        if(!important){TextView pin=muted(c,pinned?"✓ همیشه باز":"○ همیشه باز");pin.setTextSize(12.5f);pin.setPadding(0,dp(c,7),0,0);outer.addView(pin);pin.setOnClickListener(v->{boolean now=!prefs.getBoolean(key+"_pinned",false);prefs.edit().putBoolean(key+"_pinned",now).apply();pin.setText(now?"✓ همیشه باز":"○ همیشه باز");if(now){body.setVisibility(View.VISIBLE);arrow.setText("⌃");prefs.edit().putBoolean(key+"_open",true).apply();}});}
        if(!important)head.setOnClickListener(v->{boolean now=body.getVisibility()!=View.VISIBLE;body.setVisibility(now?View.VISIBLE:View.GONE);arrow.setText(now?"⌃":"⌄");prefs.edit().putBoolean(key+"_open",now).apply();});
        return outer;
    }

    /** New compact global navigation: Home / Today / Quick Add / History. */
    public static LinearLayout bottomNav(Context c,int selected,View.OnClickListener home,View.OnClickListener today,View.OnClickListener add,View.OnClickListener history){LinearLayout nav=new LinearLayout(c);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setGravity(Gravity.CENTER);nav.setPadding(dp(c,6),dp(c,6),dp(c,6),dp(c,6));nav.setBackground(bottomNavBackground(c));nav.setElevation(dp(c,5));TextView[] tabs={navTab(c,"⌂\nخانه",selected==0,accent(c)),navTab(c,"✦\nامروز",selected==1,accent2(c)),navTab(c,"＋\nثبت سریع",selected==2,GREEN),navTab(c,"☷\nتاریخچه",selected==3,INDIGO)};View.OnClickListener[] ls={home,today,add,history};LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);for(int i=0;i<tabs.length;i++){tabs[i].setOnClickListener(ls[i]);nav.addView(tabs[i],lp);}return nav;}
    private static TextView navTab(Context c,String text,boolean selected,int a){TextView tv=new TextView(c);tv.setText(text);tv.setGravity(Gravity.CENTER);tv.setTextSize(11.5f);tv.setTextColor(selected?a:mutedColor(c));tv.setTypeface(Typeface.create("sans-serif-medium",selected?Typeface.BOLD:Typeface.NORMAL));tv.setPadding(dp(c,6),dp(c,5),dp(c,6),dp(c,5));return tv;}
    public static void applyWindow(Activity a){BG_1=bg1(a);BG_2=bg2(a);CARD_1=cardColor(a);CARD_2=cardColor(a);TEXT=textColor(a);MUTED=mutedColor(a);FIELD=fieldColor(a);int bg=bg1(a);a.getWindow().setStatusBarColor(bg);a.getWindow().setNavigationBarColor(bg);a.getWindow().getDecorView().setBackgroundColor(bg);if(Build.VERSION.SDK_INT>=29)a.getWindow().setNavigationBarContrastEnforced(false);int flags=a.getWindow().getDecorView().getSystemUiVisibility();if(!ThemeManager.dark(a)){flags|=View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;if(Build.VERSION.SDK_INT>=26)flags|=View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;}else{flags&=~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;if(Build.VERSION.SDK_INT>=26)flags&=~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;}a.getWindow().getDecorView().setSystemUiVisibility(flags);}
    public static LinearLayout.LayoutParams matchWrap(Context c){return new LinearLayout.LayoutParams(-1,-2);} public static LinearLayout.LayoutParams matchWrap(Context c,int top,int bottom){LinearLayout.LayoutParams p=matchWrap(c);p.setMargins(0,dp(c,top),0,dp(c,bottom));return p;}
}
