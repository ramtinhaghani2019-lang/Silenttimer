package com.example.silenttimer;

import android.app.Activity;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

public final class UiKit {
    private UiKit() {}
    public static int BG_1=0xFF0C1320,BG_2=0xFF101A2A,BG_3=0xFF142033,CARD_1=0xFF192436,CARD_2=0xFF202D42,TEXT=0xFFF5F7FC,MUTED=0xFFAFBED1,FIELD=0xFF263349;
    public static final int PURPLE=0xFFB493EF,VIOLET=0xFF9474D5,CYAN=0xFF64BFE8,TEAL=0xFF30C1B1,PINK=0xFFE9A1BA,BLUE=0xFF739DFF,GOLD=0xFFF1C65F,ORANGE=0xFFEEB266,RED=0xFFFA8091,GREEN=0xFF4FD1A3,INDIGO=0xFF9AA5F5;
    private static int bg1(Context c){return BG_1;} private static int bg2(Context c){return BG_2;} private static int cardColor(Context c){return CARD_1;} private static int card2(Context c){return CARD_2;} private static int textColor(Context c){return TEXT;} private static int mutedColor(Context c){return MUTED;} private static int fieldColor(Context c){return FIELD;} private static int accent(Context c){return BLUE;} private static int accent2(Context c){return INDIGO;}
    public static int[] palette(Context c){return new int[]{bg1(c),bg2(c),cardColor(c),textColor(c),accent(c),mutedColor(c),fieldColor(c),accent2(c)};}
    public static int dp(Context c,int value){return Math.round(value*c.getResources().getDisplayMetrics().density);} public static int withAlpha(int color,int alpha){return Color.argb(alpha,Color.red(color),Color.green(color),Color.blue(color));}
    private static int blend(int a,int b,float t){int r=(int)(Color.red(a)*(1-t)+Color.red(b)*t),g=(int)(Color.green(a)*(1-t)+Color.green(b)*t),bl=(int)(Color.blue(a)*(1-t)+Color.blue(b)*t);return Color.rgb(r,g,bl);}

    /** Build 193: quiet indigo / violet atmosphere, reusable across every native screen.
     * Draws gradients rather than bundling a large screenshot or bitmap background. */
    public static Drawable screenBackground(Context c){return new NexaAuroraDrawable();}
    public static GradientDrawable rounded(Context c,int color,int radiusDp){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp(c,radiusDp));return g;}
    private static Drawable layeredPanel(Context c,int[] borderColors,int[] fillColors,int radiusDp,int borderDp){GradientDrawable outer=new GradientDrawable(GradientDrawable.Orientation.TL_BR,borderColors);outer.setCornerRadius(dp(c,radiusDp));GradientDrawable inner=new GradientDrawable(GradientDrawable.Orientation.TL_BR,fillColors);inner.setCornerRadius(dp(c,Math.max(1,radiusDp-2)));LayerDrawable layers=new LayerDrawable(new Drawable[]{outer,inner});int inset=dp(c,borderDp);layers.setLayerInset(1,inset,inset,inset,inset);return layers;}
    private static int radius(Context c){return 16;} private static int elevation(Context c){return 0;} private static int buttonRadius(Context c){return 13;} private static String style(Context c){return "nexa_coherent";}
    /** Surfaces differ by hierarchy, not by eight competing rainbow gradients. */
    public static Drawable card(Context c){
        GradientDrawable g=rounded(c,CARD_1,radius(c));
        g.setStroke(dp(c,1),0xFF344257);
        return g;
    }
    public static Drawable colorfulCard(Context c,int variant){
        // Preserve category APIs and category color in badges/text, not full-card fills.
        return card(c);
    }
    public static Drawable subtlePastCard(Context c){
        GradientDrawable g=rounded(c,blend(CARD_1,RED,0.055f),radius(c));
        g.setStroke(dp(c,1),withAlpha(RED,0x65));
        return g;
    }
    public static Drawable subtlePastStripe(Context c){return rounded(c,withAlpha(RED,0x16),8);}
    public static Drawable field(Context c){
        GradientDrawable g=rounded(c,FIELD,12);
        g.setStroke(dp(c,1),0xFF47566B);
        return g;
    }
    public static Drawable heroSurface(Context c){
        GradientDrawable g=rounded(c,0xFF233554,19);
        g.setStroke(dp(c,1),0xFF4671AD);return g;
    }
    public static Drawable accentCard(Context c){
        GradientDrawable g=rounded(c,0xFF1D2D46,18);
        g.setStroke(dp(c,1),0xFF486CA0);return g;
    }
    public static Drawable bottomNavBackground(Context c){
        GradientDrawable g=rounded(c,0xFF1A283C,19);
        g.setStroke(dp(c,1),0xFF3C4B63);return g;
    }

    private static volatile Typeface regularCache,boldCache;
    public static Typeface appFace(Context c,boolean bold){
        Typeface known=bold?boldCache:regularCache;
        if(known!=null)return known;
        try{
            known=c.getResources().getFont(bold?R.font.nexa_fa_bold:R.font.nexa_fa_regular);
        }catch(Exception ignored){
            known=Typeface.create(bold?"sans-serif-medium":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL);
        }
        if(bold)boldCache=known;else regularCache=known;
        return known;
    }
    private static Typeface bodyFace(Context c,boolean bold){return appFace(c,bold);}
    private static Typeface mediumFace(Context c){return appFace(c,true);}
    public static TextView title(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(TEXT);tv.setTextSize(22f);tv.setTypeface(bodyFace(c,true));tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(0f,1.10f);return tv;}
    public static TextView sectionTitle(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(0xFFDBE6F7);tv.setTextSize(16f);tv.setTypeface(mediumFace(c));tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(0f,1.16f);return tv;}
    public static TextView muted(Context c,String text){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(mutedColor(c));tv.setTextSize(13f);tv.setGravity(Gravity.RIGHT);tv.setLineSpacing(dp(c,2),1.12f);return tv;}
    /** Uses the approved per-screen artwork as the visual focal panel. Business data stays native below it. */
    public static LinearLayout referenceHero(Context c,int drawableRes,String title,String subtitle){
        LinearLayout box=accentCardLayout(c);
        box.setPadding(dp(c,8),dp(c,8),dp(c,8),dp(c,12));
        ImageView art=new ImageView(c); art.setImageResource(drawableRes); art.setScaleType(ImageView.ScaleType.CENTER_CROP); art.setAdjustViewBounds(true);
        GradientDrawable frame=new GradientDrawable(); frame.setColor(CARD_2); frame.setCornerRadius(dp(c,22)); frame.setStroke(dp(c,1),withAlpha(GOLD,0xA8)); art.setBackground(frame); art.setClipToOutline(Build.VERSION.SDK_INT>=21);
        box.addView(art,new LinearLayout.LayoutParams(-1,dp(c,190)));
        if(title!=null&&!title.isEmpty()){TextView t=sectionTitle(c,title);t.setGravity(Gravity.CENTER);t.setTextSize(18f);box.addView(t,matchWrap(c,10,2));}
        if(subtitle!=null&&!subtitle.isEmpty()){TextView sub=muted(c,subtitle);sub.setGravity(Gravity.CENTER);sub.setTextSize(13f);box.addView(sub,matchWrap(c,2,0));}
        return box;
    }

    /** Native reference-inspired feature hero. No mockup/screenshot assets are embedded in the app. */
    /** Shared no-clutter design: feature pages already have a native title and functional content.
     * Old giant 150dp decorative illustrations only pushed actual records below the viewport.
     * Keep this API so every feature screen inherits the same clean look automatically.
     */
    public static LinearLayout featureHero(Context c,String kind,String title,String subtitle){
        LinearLayout purelyDecorative=new LinearLayout(c);
        purelyDecorative.setVisibility(View.GONE);
        return purelyDecorative;
    }
    private static final class FeatureArtView extends View{
        private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);private final String kind;
        FeatureArtView(Context c,String k){super(c);kind=k==null?"":k;setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        protected void onDraw(Canvas x){super.onDraw(x);float w=getWidth(),h=getHeight(),cx=w/2f,cy=h/2f;
            p.setStyle(Paint.Style.FILL);p.setShader(new LinearGradient(0,0,w,h,new int[]{0xFF06130F,0xFF0A241C,0xFF07110E},null,Shader.TileMode.CLAMP));x.drawRoundRect(0,0,w,h,dp(getContext(),22),dp(getContext(),22),p);p.setShader(null);
            p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(dp(getContext(),1));p.setColor(withAlpha(GOLD,0x80));x.drawRoundRect(1,1,w-1,h-1,dp(getContext(),22),dp(getContext(),22),p);
            p.setShadowLayer(dp(getContext(),16),0,0,withAlpha(GOLD,0x55));p.setStrokeWidth(dp(getContext(),5));p.setStrokeCap(Paint.Cap.ROUND);p.setColor(GOLD);
            if(kind.equals("weather")){x.drawCircle(cx-28,cy+5,24,p);x.drawCircle(cx+4,cy-4,34,p);x.drawCircle(cx+38,cy+8,22,p);x.drawLine(cx-45,cy+36,cx+55,cy+36,p);p.setColor(CYAN);for(int i=-1;i<=1;i++)x.drawLine(cx+i*30,cy+50,cx-8+i*30,cy+66,p);}
            else if(kind.equals("market")){x.drawLine(cx-72,cy+48,cx-72,cy-46,p);x.drawLine(cx-72,cy+48,cx+76,cy+48,p);Path q=new Path();q.moveTo(cx-58,cy+26);q.lineTo(cx-28,cy-8);q.lineTo(cx+2,cy+10);q.lineTo(cx+34,cy-38);q.lineTo(cx+66,cy-18);x.drawPath(q,p);p.setColor(GREEN);x.drawCircle(cx+34,cy-38,9,p);p.setColor(GOLD);x.drawCircle(cx-28,cy-8,7,p);}
            else if(kind.equals("battery")){x.drawRoundRect(cx-74,cy-42,cx+62,cy+42,16,16,p);x.drawRoundRect(cx+64,cy-17,cx+78,cy+17,5,5,p);Path q=new Path();q.moveTo(cx+6,cy-30);q.lineTo(cx-20,cy+5);q.lineTo(cx+2,cy+5);q.lineTo(cx-10,cy+32);q.lineTo(cx+30,cy-10);q.lineTo(cx+8,cy-10);q.close();p.setStyle(Paint.Style.FILL);p.setColor(GREEN);x.drawPath(q,p);p.setStyle(Paint.Style.STROKE);p.setColor(GOLD);}
            else if(kind.equals("vehicle")){x.drawRoundRect(cx-78,cy-18,cx+78,cy+28,18,18,p);x.drawLine(cx-52,cy-18,cx-28,cy-45,p);x.drawLine(cx-28,cy-45,cx+38,cy-45,p);x.drawLine(cx+38,cy-45,cx+60,cy-18,p);x.drawCircle(cx-48,cy+32,15,p);x.drawCircle(cx+48,cy+32,15,p);}
            else if(kind.equals("ledger")){x.drawRoundRect(cx-76,cy-48,cx+76,cy+48,18,18,p);x.drawLine(cx-58,cy-18,cx+38,cy-18,p);x.drawLine(cx-58,cy+4,cx+18,cy+4,p);x.drawLine(cx-58,cy+26,cx+48,cy+26,p);p.setColor(GREEN);x.drawCircle(cx+54,cy-17,10,p);}
            else if(kind.equals("bills")){x.drawRoundRect(cx-58,cy-58,cx+58,cy+58,12,12,p);for(int i=0;i<4;i++)x.drawLine(cx-36,cy-30+i*20,cx+36,cy-30+i*20,p);p.setColor(GREEN);x.drawCircle(cx+62,cy+42,18,p);x.drawLine(cx+53,cy+42,cx+60,cy+50,p);x.drawLine(cx+60,cy+50,cx+73,cy+33,p);}
            else if(kind.equals("home")){Path q=new Path();q.moveTo(cx-78,cy-4);q.lineTo(cx,cy-66);q.lineTo(cx+78,cy-4);q.moveTo(cx-56,cy-18);q.lineTo(cx-56,cy+58);q.lineTo(cx+56,cy+58);q.lineTo(cx+56,cy-18);x.drawPath(q,p);x.drawRoundRect(cx-15,cy+12,cx+18,cy+58,4,4,p);}
            else if(kind.equals("security")||kind.equals("vault")){Path q=new Path();q.moveTo(cx,cy-62);q.lineTo(cx+58,cy-38);q.lineTo(cx+48,cy+26);q.quadTo(cx,cy+70,cx-48,cy+26);q.lineTo(cx-58,cy-38);q.close();x.drawPath(q,p);x.drawCircle(cx,cy-4,12,p);x.drawLine(cx,cy+8,cx,cy+30,p);}
            else if(kind.equals("emergency")){x.drawCircle(cx,cy,62,p);x.drawLine(cx-34,cy,cx+34,cy,p);x.drawLine(cx,cy-34,cx,cy+34,p);}
            else if(kind.equals("timeline")){x.drawLine(cx,cy-62,cx,cy+62,p);for(int i=-2;i<=2;i++){float yy=cy+i*28;x.drawCircle(cx,yy,8,p);x.drawLine(cx+14,yy,cx+64,yy,p);}}
            else if(kind.equals("reminder")){x.drawCircle(cx,cy+4,52,p);x.drawLine(cx,cy+4,cx,cy-28,p);x.drawLine(cx,cy+4,cx+28,cy+18,p);x.drawLine(cx-34,cy-48,cx-52,cy-62,p);x.drawLine(cx+34,cy-48,cx+52,cy-62,p);}
            else if(kind.equals("legal")){x.drawLine(cx,cy-54,cx,cy+46,p);x.drawLine(cx-62,cy-32,cx+62,cy-32,p);x.drawLine(cx-42,cy-32,cx-66,cy+18,p);x.drawLine(cx+42,cy-32,cx+66,cy+18,p);x.drawLine(cx-82,cy+18,cx-50,cy+18,p);x.drawLine(cx+50,cy+18,cx+82,cy+18,p);x.drawLine(cx-40,cy+50,cx+40,cy+50,p);}
            else if(kind.equals("files")){x.drawRoundRect(cx-70,cy-46,cx+70,cy+54,12,12,p);x.drawLine(cx-48,cy-18,cx+48,cy-18,p);x.drawLine(cx-48,cy+6,cx+34,cy+6,p);x.drawLine(cx-48,cy+30,cx+18,cy+30,p);}
            else if(kind.equals("silent")){x.drawCircle(cx,cy-2,44,p);x.drawLine(cx-54,cy-48,cx+54,cy+48,p);x.drawLine(cx-72,cy-2,cx-48,cy-2,p);x.drawLine(cx+48,cy-2,cx+72,cy-2,p);}
            else if(kind.equals("quick")){x.drawCircle(cx,cy,56,p);x.drawLine(cx-28,cy,cx+28,cy,p);x.drawLine(cx,cy-28,cx,cy+28,p);}
            else if(kind.equals("today")){x.drawCircle(cx,cy,54,p);for(int i=0;i<8;i++){double a=i*Math.PI/4;x.drawLine(cx+(float)Math.cos(a)*68,cy+(float)Math.sin(a)*68,cx+(float)Math.cos(a)*82,cy+(float)Math.sin(a)*82,p);}}
            else {p.setStyle(Paint.Style.FILL);x.drawCircle(cx,cy,48,p);p.setColor(BG_1);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(dp(getContext(),34));p.setTypeface(Typeface.DEFAULT_BOLD);x.drawText("N",cx,cy+12,p);}
            p.clearShadowLayer();
        }
    }

    /** Pixel-UI master hero shared by feature screens: a visual focal panel followed by concise Persian context. */
    /** Compact, reusable feature header, leaving the first viewport for functional content. */
    public static LinearLayout masterHero(Context c,String icon,String title,String subtitle,int variant){
        LinearLayout panel=colorfulCardLayout(c,variant);
        panel.setOrientation(LinearLayout.HORIZONTAL);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        panel.setPadding(dp(c,14),dp(c,12),dp(c,14),dp(c,12));
        TextView glyph=new TextView(c);glyph.setText(symbolFor(icon));glyph.setTextSize(27f);
        glyph.setGravity(Gravity.CENTER);glyph.setContentDescription(title);
        glyph.setBackground(rounded(c,0xFF293B52,14));
        panel.addView(glyph,new LinearLayout.LayoutParams(dp(c,52),dp(c,52)));
        LinearLayout labels=new LinearLayout(c);labels.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);lp.setMargins(dp(c,12),0,0,0);
        TextView t=title(c,title);t.setTextSize(17f);t.setMaxLines(2);labels.addView(t);
        if(subtitle!=null&&!subtitle.trim().isEmpty()){
            TextView sub=muted(c,subtitle);sub.setTextSize(12f);sub.setMaxLines(2);
            labels.addView(sub,matchWrap(c,5,0));
        }
        panel.addView(labels,lp);
        return panel;
    }

    /** Compact financial metric: aligned type scale, native accessibility and meaning-first color. */
    public static LinearLayout financialMetric(Context c,String label,String value,int color){
        LinearLayout tile=new LinearLayout(c);
        tile.setOrientation(LinearLayout.VERTICAL);
        tile.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        tile.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        tile.setPadding(dp(c,14),dp(c,12),dp(c,14),dp(c,12));
        tile.setMinimumHeight(dp(c,92));
        GradientDrawable surface=rounded(c,CARD_1,16);
        surface.setStroke(dp(c,1),0xFF39485C);
        tile.setBackground(surface);
        TextView caption=muted(c,label);
        caption.setTextSize(12.5f);
        caption.setMaxLines(2);
        tile.addView(caption,matchWrap(c,0,5));
        TextView amount=title(c,value);
        amount.setTextColor(color);
        amount.setTextSize(19f);
        amount.setMaxLines(3);
        amount.setBreakStrategy(android.text.Layout.BREAK_STRATEGY_HIGH_QUALITY);
        tile.addView(amount,matchWrap(c,0,0));
        tile.setContentDescription(label+"، "+value);
        return tile;
    }

    public static LinearLayout cardLayout(Context c){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,15),dp(c,13),dp(c,15),dp(c,13));card.setBackground(card(c));card.setElevation(dp(c,elevation(c)));return card;}
    public static LinearLayout accentCardLayout(Context c){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,15),dp(c,13),dp(c,15),dp(c,13));card.setBackground(accentCard(c));card.setElevation(dp(c,elevation(c)+1));return card;}
    public static LinearLayout colorfulCardLayout(Context c,int variant){LinearLayout card=new LinearLayout(c);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(c,15),dp(c,13),dp(c,15),dp(c,13));card.setBackground(colorfulCard(c,variant));card.setElevation(dp(c,elevation(c)));return card;}

    /** Foreground ripple retains existing backgrounds, callbacks and accessibility semantics. */
    public static void touchFeedback(Context c,View view,int color,int radiusDp){
        GradientDrawable mask=rounded(c,Color.WHITE,radiusDp);
        view.setForeground(new RippleDrawable(android.content.res.ColorStateList.valueOf(withAlpha(color,0x26)),null,mask));
    }
    /** One compact RTL destination row instead of giant emoji tiles. */
    /** Settings destination: compact, accessible, RTL with its own icon and hint. */
    public static LinearLayout settingsDirectoryRow(Context c,String emoji,String heading,String summary){
        LinearLayout row=new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setMinimumHeight(dp(c,70));
        row.setPadding(dp(c,13),dp(c,10),dp(c,13),dp(c,10));
        row.setBackground(card(c));
        TextView glyph=new TextView(c);
        glyph.setText(symbolFor(emoji));glyph.setTextSize(22f);glyph.setGravity(Gravity.CENTER);
        glyph.setBackground(rounded(c,0xFF293B52,13));
        row.addView(glyph,new LinearLayout.LayoutParams(dp(c,46),dp(c,46)));
        LinearLayout words=new LinearLayout(c);
        words.setOrientation(LinearLayout.VERTICAL);
        words.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams textParams=new LinearLayout.LayoutParams(0,-2,1f);
        textParams.setMargins(dp(c,12),0,dp(c,6),0);
        TextView title=new TextView(c);title.setText(heading);title.setTextColor(TEXT);
        title.setTextSize(14.5f);title.setTypeface(mediumFace(c));title.setMaxLines(2);
        title.setGravity(Gravity.RIGHT);
        words.addView(title);
        TextView sub=muted(c,summary);sub.setTextSize(11.5f);sub.setMaxLines(2);
        words.addView(sub,matchWrap(c,3,0));
        row.addView(words,textParams);
        TextView arrow=new TextView(c);arrow.setText("⌄");arrow.setTextSize(22f);
        arrow.setTextColor(MUTED);arrow.setGravity(Gravity.CENTER);
        row.addView(arrow,new LinearLayout.LayoutParams(dp(c,30),dp(c,46)));
        touchFeedback(c,row,PURPLE,16);
        row.setClickable(true);row.setFocusable(true);
        row.setContentDescription("باز کردن تنظیمات "+heading);
        return row;
    }

    /** Visual marks for navigation only: never replaces names or accessible labels. */
    public static String symbolFor(String emoji){
        if(emoji==null)return "◈";
        if(emoji.contains("🎙")||emoji.contains("🎤"))return "◉";
        if(emoji.contains("📅")||emoji.contains("🎂")||emoji.contains("⏰"))return "▦";
        if(emoji.contains("💳")||emoji.contains("💰"))return "▤";
        if(emoji.contains("📈")||emoji.contains("📊"))return "⌁";
        if(emoji.contains("💊"))return "＋";
        if(emoji.contains("🛒"))return "▣";
        if(emoji.contains("🚗"))return "◇";
        if(emoji.contains("🏠"))return "⌂";
        if(emoji.contains("📄"))return "≡";
        if(emoji.contains("⚖"))return "⚖";
        if(emoji.contains("✓")||emoji.contains("✔"))return "✓";
        return "◈";
    }
    public static LinearLayout featureDirectoryRow(Context c,String emoji,String label,int variant){
        LinearLayout row=new LinearLayout(c);row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setMinimumHeight(dp(c,62));row.setPadding(dp(c,12),dp(c,8),dp(c,12),dp(c,8));
        row.setBackground(card(c));
        TextView pict=new TextView(c);pict.setText(symbolFor(emoji));pict.setTextSize(24f);
        pict.setGravity(Gravity.CENTER);pict.setTextDirection(View.TEXT_DIRECTION_LTR);
        pict.setBackground(rounded(c,0xFF293B52,12));
        row.addView(pict,new LinearLayout.LayoutParams(dp(c,46),dp(c,46)));
        TextView name=sectionTitle(c,label);name.setTextColor(TEXT);name.setTextSize(14.5f);
        name.setMaxLines(2);name.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams textLp=new LinearLayout.LayoutParams(0,-2,1f);
        textLp.setMargins(dp(c,12),0,dp(c,5),0);row.addView(name,textLp);
        TextView arrow=muted(c,"‹");arrow.setTextSize(26f);arrow.setGravity(Gravity.CENTER);
        row.addView(arrow,new LinearLayout.LayoutParams(dp(c,27),dp(c,42)));
        touchFeedback(c,row,PURPLE,16);
        row.setClickable(true);row.setFocusable(true);row.setContentDescription("باز کردن "+label);
        return row;
    }

    public static Button primaryButton(Context c,String text){
        Button b=new Button(c);b.setTag("nexa_primary");b.setAllCaps(false);b.setText(text);
        b.setTextSize(14f);b.setTypeface(mediumFace(c));b.setMinHeight(dp(c,50));
        b.setMinimumHeight(dp(c,50));b.setPadding(dp(c,14),dp(c,6),dp(c,14),dp(c,6));
        String t=text==null?"":text.trim();
        boolean destructive=t.contains("حذف")||t.contains("پاک")||t.contains("خاموش");
        GradientDrawable primary=rounded(c,destructive?0xFFAD4B60:0xFF3F73DE,buttonRadius(c));
        b.setTextColor(Color.WHITE);b.setBackground(primary);
        touchFeedback(c,b,Color.WHITE,buttonRadius(c));return b;
    }
    public static Button secondaryButton(Context c,String text){
        Button b=new Button(c);b.setTag("nexa_secondary");b.setAllCaps(false);b.setText(text);
        b.setTextColor(textColor(c));b.setTextSize(14f);b.setTypeface(mediumFace(c));
        b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));
        b.setPadding(dp(c,12),dp(c,5),dp(c,12),dp(c,5));
        String t=text==null?"":text.trim();boolean destructive=t.contains("حذف")||t.contains("پاک")||t.contains("🗑");
        GradientDrawable g=rounded(c,destructive?0xFF382735:0xFF27354A,buttonRadius(c));
        g.setStroke(dp(c,1),destructive?withAlpha(RED,0x88):0xFF465773);
        b.setBackground(g);touchFeedback(c,b,destructive?RED:BLUE,buttonRadius(c));return b;
    }
    public static Button iconButton(Context c,String icon,String desc,int a){Button b=new Button(c);b.setTag("nexa_icon");b.setAllCaps(false);b.setText(icon);b.setContentDescription(desc);b.setTextColor(textColor(c));b.setTextSize(18f);b.setGravity(Gravity.CENTER);b.setMinWidth(dp(c,48));b.setMinimumWidth(dp(c,48));b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));GradientDrawable g=new GradientDrawable();g.setColor(withAlpha(cardColor(c),0xED));g.setStroke(dp(c,1),withAlpha(a,0x82));g.setCornerRadius(dp(c,Math.max(10,buttonRadius(c)-2)));b.setBackground(g);b.setPadding(0,0,0,0);b.setElevation(0);touchFeedback(c,b,a,buttonRadius(c));return b;}
    public static Button editIconButton(Context c){return iconButton(c,"✎","ویرایش",INDIGO);} public static Button deleteIconButton(Context c){return iconButton(c,"🗑","حذف",RED);} public static Button addIconButton(Context c){return iconButton(c,"＋","افزودن",GREEN);} public static Button openIconButton(Context c){return iconButton(c,"›","باز کردن",CYAN);}
    public static Button backButton(Context c){Button b=new Button(c);b.setTag("nexa_back");b.setAllCaps(false);b.setText("→");b.setContentDescription("بازگشت");b.setTextColor(textColor(c));b.setTextSize(25f);b.setGravity(Gravity.CENTER);b.setMinWidth(dp(c,48));b.setMinimumWidth(dp(c,48));b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));b.setBackgroundColor(Color.TRANSPARENT);b.setPadding(0,0,0,0);b.setElevation(0);touchFeedback(c,b,PURPLE,buttonRadius(c));return b;}
    public static LinearLayout header(Context c,String title,View.OnClickListener back){LinearLayout h=new LinearLayout(c);h.setGravity(Gravity.CENTER_VERTICAL);h.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);h.setMinimumHeight(dp(c,56));TextView t=title(c,title);t.setMaxLines(2);h.addView(t,new LinearLayout.LayoutParams(0,-2,1f));Button b=backButton(c);b.setOnClickListener(back);h.addView(b,new LinearLayout.LayoutParams(dp(c,48),dp(c,48)));return h;}
    public static Switch styledSwitch(Context c){Switch s=new Switch(c);s.setTextColor(textColor(c));s.setTextSize(14.5f);s.setGravity(Gravity.CENTER_VERTICAL);s.setMinHeight(dp(c,48));s.setMinimumHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21){int[][] states=new int[][]{new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}};int[] thumb=new int[]{PURPLE,0xFF74718D};int[] track=new int[]{withAlpha(VIOLET,0xB2),withAlpha(MUTED,0x50)};s.setThumbTintList(new android.content.res.ColorStateList(states,thumb));s.setTrackTintList(new android.content.res.ColorStateList(states,track));}return s;}
    public static Spinner styledSpinner(Context c){Spinner s=new Spinner(c);s.setMinimumHeight(dp(c,48));s.setBackground(field(c));s.setPadding(dp(c,12),0,dp(c,12),0);s.setPopupBackgroundDrawable(rounded(c,CARD_2,14));return s;}
    public static EditText styleField(Context c,EditText e,String hint){e.setMinHeight(dp(c,48));e.setMinimumHeight(dp(c,48));e.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);e.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);e.setHint(hint);e.setHintTextColor(mutedColor(c));e.setTextColor(textColor(c));e.setBackground(field(c));e.setPadding(dp(c,14),dp(c,10),dp(c,14),dp(c,10));e.setTextSize(15f);e.setTypeface(appFace(c,false));return e;}
    public static LinearLayout dialogPanel(Context c){LinearLayout box=new LinearLayout(c);box.setOrientation(LinearLayout.VERTICAL);box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);box.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,10));box.setBackground(accentCard(c));box.setElevation(dp(c,5));return box;}
    public static TextView fieldLabel(Context c,String text){TextView tv=muted(c,text);tv.setTextColor(0xFFCFDCED);tv.setTextSize(13f);tv.setTypeface(mediumFace(c));tv.setPadding(dp(c,2),dp(c,8),dp(c,2),dp(c,4));return tv;}
    public static LinearLayout formSection(Context c,String title,String subtitle){LinearLayout box=colorfulCardLayout(c,5);box.addView(sectionTitle(c,title));if(subtitle!=null&&!subtitle.trim().isEmpty())box.addView(muted(c,subtitle),matchWrap(c,4,8));return box;}
    public static TextView navCard(Context c,String icon,String title,String subtitle){TextView tv=new TextView(c);tv.setText(icon+"   "+title+"\n      "+subtitle);tv.setTextColor(textColor(c));tv.setTextSize(16f);tv.setTypeface(mediumFace(c));tv.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);tv.setLineSpacing(0f,1.25f);tv.setPadding(dp(c,16),dp(c,14),dp(c,16),dp(c,14));tv.setBackground(colorfulCard(c,title.contains("تماس")?2:0));tv.setElevation(dp(c,elevation(c)));return tv;}
    public static TextView chip(Context c,String text,boolean active){TextView tv=new TextView(c);tv.setText(text);tv.setTextSize(13f);tv.setGravity(Gravity.CENTER);tv.setPadding(dp(c,10),dp(c,6),dp(c,10),dp(c,6));if(active){tv.setTextColor(Color.WHITE);GradientDrawable g=rounded(c,0xFF395F9E,100);g.setStroke(dp(c,1),0xFF6B9FF2);tv.setBackground(g);}else{tv.setTextColor(textColor(c));tv.setBackground(field(c));}return tv;}

    /** Progressive disclosure. Detail text and pin action live inside the expanded panel. */
    public static LinearLayout collapsible(Context c,String key,String title,String subtitle,int variant,boolean important,View content){
        LinearLayout outer=cardLayout(c);
        android.content.SharedPreferences prefs=c.getSharedPreferences("nexa_ui_sections",Context.MODE_PRIVATE);
        boolean pinned=important||prefs.getBoolean(key+"_pinned",false);
        boolean open=important||prefs.getBoolean(key+"_open",false)||pinned;
        LinearLayout head=new LinearLayout(c);head.setGravity(Gravity.CENTER_VERTICAL);
        head.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);head.setMinimumHeight(dp(c,52));
        TextView tt=sectionTitle(c,title);tt.setMaxLines(2);head.addView(tt,new LinearLayout.LayoutParams(0,-2,1f));
        TextView arrow=new TextView(c);arrow.setText(open?"⌃":"⌄");arrow.setTextColor(mutedColor(c));
        arrow.setTextSize(20);arrow.setGravity(Gravity.CENTER);
        head.addView(arrow,new LinearLayout.LayoutParams(dp(c,40),dp(c,44)));
        outer.addView(head);
        LinearLayout body=new LinearLayout(c);body.setOrientation(LinearLayout.VERTICAL);
        if(subtitle!=null&&!subtitle.trim().isEmpty()){
            TextView detail=muted(c,subtitle);detail.setTextSize(12.5f);
            body.addView(detail,matchWrap(c,0,9));
        }
        body.addView(content);body.setVisibility(open?View.VISIBLE:View.GONE);
        if(!important){
            TextView pin=muted(c,pinned?"✓ همیشه باز":"○ همیشه باز");
            pin.setTextSize(12.5f);pin.setMinHeight(dp(c,44));
            pin.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            pin.setContentDescription("ثابت نگه داشتن بخش "+title);
            body.addView(pin,matchWrap(c,8,0));
            pin.setOnClickListener(v->{boolean now=!prefs.getBoolean(key+"_pinned",false);
                prefs.edit().putBoolean(key+"_pinned",now).apply();
                pin.setText(now?"✓ همیشه باز":"○ همیشه باز");
                if(now){body.setVisibility(View.VISIBLE);arrow.setText("⌃");
                    prefs.edit().putBoolean(key+"_open",true).apply();}
            });
        }
        outer.addView(body);
        if(!important){
            head.setClickable(true);head.setFocusable(true);
            head.setContentDescription((open?"بستن":"باز کردن")+" بخش "+title);
            touchFeedback(c,head,BLUE,12);
            head.setOnClickListener(v->{boolean now=body.getVisibility()!=View.VISIBLE;
                body.setVisibility(now?View.VISIBLE:View.GONE);
                arrow.setText(now?"⌃":"⌄");
                head.setContentDescription((now?"بستن":"باز کردن")+" بخش "+title);
                prefs.edit().putBoolean(key+"_open",now).apply();});
        }
        return outer;
    }
    /** Shared four-destination navigation. The visible label and TalkBack destination
     * must agree on every feature screen; a selected tab is announced explicitly. */
    public static LinearLayout bottomNav(Context c,int selected,View.OnClickListener home,
                                         View.OnClickListener today,View.OnClickListener add,
                                         View.OnClickListener history){
        LinearLayout nav=new LinearLayout(c);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(dp(c,6),dp(c,5),dp(c,6),dp(c,5));
        nav.setBackground(bottomNavBackground(c));
        nav.setElevation(dp(c,5));
        String[] symbols={"⌂", "✦", "＋", "☷"};
        String[] labels={"خانه", "امروز", "ثبت سریع", "تاریخچه"};
        int[] colors={BLUE,BLUE,BLUE,BLUE};
        View.OnClickListener[] actions={home,today,add,history};
        for(int i=0;i<labels.length;i++){
            TextView tab=navTab(c,symbols[i],labels[i],selected==i,colors[i]);
            tab.setOnClickListener(actions[i]);
            nav.addView(tab,new LinearLayout.LayoutParams(0,-2,1f));
        }
        return nav;
    }
    private static TextView navTab(Context c,String symbol,String label,boolean selected,int color){
        TextView tv=new TextView(c);
        tv.setText(symbol+"\n"+label);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(12.5f);
        tv.setTextColor(selected?Color.WHITE:mutedColor(c));
        tv.setTypeface(appFace(c,selected));
        tv.setMinHeight(dp(c,56));
        tv.setMinimumHeight(dp(c,56));
        tv.setPadding(dp(c,3),dp(c,6),dp(c,3),dp(c,6));
        tv.setMaxLines(2);
        tv.setLineSpacing(dp(c,2),1.0f);
        tv.setSelected(selected);
        tv.setClickable(true);
        tv.setFocusable(true);
        tv.setContentDescription(label+(selected?"، برگه انتخاب‌شده":"، باز کردن"));
        if(selected){
            GradientDrawable background=rounded(c,0xFF32558C,16);
            background.setCornerRadius(dp(c,18));
            tv.setBackground(background);
        }else{
            tv.setBackground(rounded(c,Color.TRANSPARENT,18));
        }
        touchFeedback(c,tv,color,18);
        return tv;
    }
    public static TextView emptyState(Context c,String title,String detail){TextView tv=new TextView(c);tv.setText(title+(detail==null||detail.trim().isEmpty()?"":"\n"+detail));tv.setTextColor(mutedColor(c));tv.setTextSize(14.5f);tv.setGravity(Gravity.CENTER);tv.setLineSpacing(dp(c,3),1.15f);tv.setPadding(dp(c,18),dp(c,22),dp(c,18),dp(c,22));tv.setBackground(field(c));return tv;}
    public static TextView statusBadge(Context c,String text,int color){TextView tv=new TextView(c);tv.setText(text);tv.setTextColor(textColor(c));tv.setTextSize(12.5f);tv.setGravity(Gravity.CENTER);tv.setPadding(dp(c,10),dp(c,6),dp(c,10),dp(c,6));GradientDrawable g=new GradientDrawable();g.setColor(withAlpha(color,0x24));g.setStroke(dp(c,1),withAlpha(color,0xA0));g.setCornerRadius(dp(c,100));tv.setBackground(g);return tv;}

    /** Applies the approved Nexa luxury visual language to legacy controls too, so old screens
     * inherit the same RTL spacing, touch targets and black/emerald/gold hierarchy without
     * rewriting their business logic. */
    private static final java.util.Set<View> POLISHED = java.util.Collections.newSetFromMap(new java.util.WeakHashMap<View,Boolean>());
    public static void polishTree(Context c, View v){
        if(v==null)return;
        boolean first=POLISHED.add(v);
        if(!first){
            if(v instanceof ViewGroup){ViewGroup group=(ViewGroup)v;
                for(int i=0;i<group.getChildCount();i++)polishTree(c,group.getChildAt(i));}
            return;
        }
        // Persian prose stays RTL, while numbered inputs (amounts, card numbers and
        // phone fields) preserve their entered digit sequence and cursor direction.
        boolean numericInput=v instanceof EditText &&
            ((((EditText)v).getInputType() & android.text.InputType.TYPE_MASK_CLASS)
                == android.text.InputType.TYPE_CLASS_NUMBER ||
             (((EditText)v).getInputType() & android.text.InputType.TYPE_MASK_CLASS)
                == android.text.InputType.TYPE_CLASS_PHONE);
        v.setLayoutDirection(numericInput?View.LAYOUT_DIRECTION_LTR:View.LAYOUT_DIRECTION_RTL);
        if(v instanceof TextView){
            TextView tv=(TextView)v;
            tv.setTextDirection(numericInput?View.TEXT_DIRECTION_LTR:View.TEXT_DIRECTION_FIRST_STRONG_RTL);
            tv.setIncludeFontPadding(false);tv.setLineSpacing(dp(c,1),1.12f);
            Typeface previous=tv.getTypeface();boolean bold=previous!=null && (previous.getStyle()&Typeface.BOLD)!=0;
            tv.setTypeface(appFace(c,bold));
        }
        if(v instanceof EditText){EditText e=(EditText)v;if(e.getBackground()==null || e.getBackground().getClass().getName().contains("ColorDrawable")){e.setBackground(field(c));}e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setMinHeight(dp(c,48));e.setPadding(dp(c,13),dp(c,9),dp(c,13),dp(c,9));}
        else if(v instanceof Switch){Switch sw=(Switch)v;sw.setTextColor(TEXT);sw.setMinHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21){int[][] st={new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}};sw.setThumbTintList(new android.content.res.ColorStateList(st,new int[]{GOLD,0xFF6F7C76}));sw.setTrackTintList(new android.content.res.ColorStateList(st,new int[]{withAlpha(TEAL,0xA0),withAlpha(MUTED,0x50)}));}}
        else if(v instanceof Spinner){Spinner sp=(Spinner)v;sp.setMinimumHeight(dp(c,48));sp.setPadding(dp(c,12),0,dp(c,12),0);try{sp.setPopupBackgroundDrawable(rounded(c,CARD_2,14));}catch(Exception ignored){}}
        else if(v instanceof CheckBox){CheckBox cb=(CheckBox)v;cb.setTextColor(TEXT);cb.setMinHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21)cb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}},new int[]{GOLD,MUTED}));}
        else if(v instanceof RadioButton){RadioButton rb=(RadioButton)v;rb.setTextColor(TEXT);rb.setMinHeight(dp(c,48));if(Build.VERSION.SDK_INT>=21)rb.setButtonTintList(new android.content.res.ColorStateList(new int[][]{new int[]{android.R.attr.state_checked},new int[]{-android.R.attr.state_checked}},new int[]{GOLD,MUTED}));}
        else if(v instanceof SeekBar){SeekBar sb=(SeekBar)v;if(Build.VERSION.SDK_INT>=21){sb.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));sb.setThumbTintList(android.content.res.ColorStateList.valueOf(TEAL));}}
        else if(v instanceof ProgressBar){ProgressBar pb=(ProgressBar)v;if(Build.VERSION.SDK_INT>=21)pb.setProgressTintList(android.content.res.ColorStateList.valueOf(GOLD));}
        else if(v instanceof AutoCompleteTextView){AutoCompleteTextView ac=(AutoCompleteTextView)v;ac.setDropDownBackgroundDrawable(rounded(c,CARD_2,14));ac.setDropDownVerticalOffset(dp(c,4));}
        else if(v instanceof ListView){ListView lv=(ListView)v;lv.setDivider(rounded(c,withAlpha(GOLD,0x28),1));lv.setDividerHeight(dp(c,1));lv.setCacheColorHint(Color.TRANSPARENT);}
        else if(v instanceof NumberPicker){NumberPicker np=(NumberPicker)v;np.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);}
        else if(v instanceof Button){Button b=(Button)v;b.setAllCaps(false);b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));if(b.getTag()!=null && b.getTag().toString().startsWith("nexa_")){/* keep intentional Master UI styling */}else{b.setTypeface(mediumFace(c));b.setTextColor(TEXT);b.setPadding(dp(c,12),dp(c,5),dp(c,12),dp(c,5));String bt=b.getText()==null?"":b.getText().toString();int stroke=withAlpha(GOLD,0x82),fill=blend(FIELD,CARD_1,.28f);if(bt.contains("حذف")||bt.contains("پاک")||bt.contains("لغو")){stroke=withAlpha(RED,0xA8);fill=blend(FIELD,RED,.10f);}else if(bt.contains("افزود")||bt.contains("ثبت")||bt.contains("ذخیره")||bt.contains("تأیید")||bt.contains("اعمال")){stroke=withAlpha(TEAL,0xB8);fill=blend(FIELD,TEAL,.13f);}GradientDrawable bg=new GradientDrawable();bg.setColor(fill);bg.setStroke(dp(c,1),stroke);bg.setCornerRadius(dp(c,13));b.setBackground(bg);b.setElevation(0);touchFeedback(c,b,GOLD,13);}}
        if(v instanceof ViewGroup){ViewGroup g=(ViewGroup)v;g.setClipToPadding(false);for(int i=0;i<g.getChildCount();i++)polishTree(c,g.getChildAt(i));}
    }
    private static void installLuxuryPolish(Activity a){
        final View decor=a.getWindow().getDecorView();
        decor.getViewTreeObserver().addOnGlobalLayoutListener(new android.view.ViewTreeObserver.OnGlobalLayoutListener(){
            boolean busy=false; public void onGlobalLayout(){if(busy)return;busy=true;try{polishTree(a,decor);}finally{busy=false;}}
        });
    }

    public static void applyWindow(Activity a){BG_1=bg1(a);BG_2=bg2(a);CARD_1=cardColor(a);CARD_2=card2(a);TEXT=textColor(a);MUTED=mutedColor(a);FIELD=fieldColor(a);int bg=bg1(a);a.getWindow().setStatusBarColor(bg);a.getWindow().setNavigationBarColor(bg);a.getWindow().getDecorView().setBackgroundColor(bg);a.getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);if(Build.VERSION.SDK_INT>=29)a.getWindow().setNavigationBarContrastEnforced(false);installLuxuryPolish(a);int flags=a.getWindow().getDecorView().getSystemUiVisibility();flags&=~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;if(Build.VERSION.SDK_INT>=26)flags&=~View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;a.getWindow().getDecorView().setSystemUiVisibility(flags);}
    public static LinearLayout.LayoutParams matchWrap(Context c){return new LinearLayout.LayoutParams(-1,-2);} public static LinearLayout.LayoutParams matchWrap(Context c,int top,int bottom){LinearLayout.LayoutParams p=matchWrap(c);p.setMargins(0,dp(c,top),0,dp(c,bottom));return p;}
}
