package com.example.silenttimer;

import android.app.*;import android.os.*;import android.content.*;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;import java.util.*;

public class ThemeStoreActivity extends Activity{
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        LinearLayout h=UiKit.header(this,"پوسته‌های Nexa",v->finish());root.addView(h,UiKit.matchWrap(this,0,10));
        root.addView(UiKit.muted(this,"۶ پوسته تأییدشده • یک پوسته داخلی + حداکثر ۲ پوسته دانلودی. پوسته فعال خودکار حذف نمی‌شود."),UiKit.matchWrap(this,0,14));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private void render(){list.removeAllViews();String active=ThemeManager.active(this);for(ThemeManager.ThemeMeta m:ThemeManager.catalog()){
        boolean installed=ThemeManager.isInstalled(this,m.id),isActive=active.equals(m.id);LinearLayout c=UiKit.colorfulCardLayout(this,Math.abs(m.id.hashCode())%8);
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView sw=new TextView(this);sw.setText("●");sw.setTextSize(34);sw.setTextColor(m.accent);row.addView(sw,new LinearLayout.LayoutParams(UiKit.dp(this,52),UiKit.dp(this,52)));
        LinearLayout txt=new LinearLayout(this);txt.setOrientation(LinearLayout.VERTICAL);TextView t=UiKit.sectionTitle(this,m.name+(isActive?"  ✓ فعال":""));txt.addView(t);txt.addView(UiKit.muted(this,m.subtitle));row.addView(txt,new LinearLayout.LayoutParams(0,-2,1f));c.addView(row);
        TextView st=UiKit.muted(this,m.id.equals(ThemeManager.BASE)?"داخلی • همیشه موجود":installed?"دانلود شده":"دانلود نشده");c.addView(st,UiKit.matchWrap(this,4,8));
        LinearLayout actions=new LinearLayout(this);if(!installed){Button d=UiKit.primaryButton(this,"دانلود");d.setOnClickListener(v->startDownload(m,d));actions.addView(d,new LinearLayout.LayoutParams(0,-2,1f));}
        else if(!isActive){Button a=UiKit.primaryButton(this,"فعال‌کردن");a.setOnClickListener(v->{ThemeManager.activate(this,m.id);recreate();});actions.addView(a,new LinearLayout.LayoutParams(0,-2,1f));if(!m.id.equals(ThemeManager.BASE)){Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف پوسته؟").setMessage("برای استفاده دوباره باید مجدداً از GitHub دانلود شود.").setPositiveButton("حذف",(x,w)->{ThemeManager.uninstall(this,m.id);render();}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));p.setMargins(UiKit.dp(this,8),0,0,0);actions.addView(del,p);}}
        else {TextView ok=UiKit.muted(this,"این پوسته در حال استفاده است");ok.setTextColor(ThemeManager.color(this,"accent",UiKit.TEAL));actions.addView(ok);}c.addView(actions);list.addView(c,UiKit.matchWrap(this,0,10));}}
    private void startDownload(ThemeManager.ThemeMeta m,Button button){
        if(ThemeManager.downloadedCount(this)>=2){
            java.util.ArrayList<String> ids=new java.util.ArrayList<>(),labels=new java.util.ArrayList<>();String active=ThemeManager.active(this);
            for(String id:ThemeManager.installed(this))if(!id.equals(active)){ids.add(id);labels.add(ThemeManager.meta(id).name);}
            if(ids.isEmpty()){Toast.makeText(this,"دو پوسته دانلودی موجودند و پوسته فعال قابل حذف خودکار نیست؛ ابتدا یک پوسته غیرفعال را فعال/حذف کن.",Toast.LENGTH_LONG).show();return;}
            new AlertDialog.Builder(this).setTitle("فضای پوسته‌ها پر است").setMessage("Nexa حداکثر ۲ پوسته دانلودی نگه می‌دارد. کدام پوسته غیرفعال حذف شود؟").setItems(labels.toArray(new String[0]),(d,w)->{ThemeManager.uninstall(this,ids.get(w));doDownload(m,button);}).setNegativeButton("انصراف",null).show();return;
        }
        doDownload(m,button);
    }
    private void doDownload(ThemeManager.ThemeMeta m,Button button){button.setEnabled(false);button.setText("در حال دانلود…");ThemeManager.download(this,m,(ok,msg)->{Toast.makeText(this,msg,Toast.LENGTH_LONG).show();render();});}
}
