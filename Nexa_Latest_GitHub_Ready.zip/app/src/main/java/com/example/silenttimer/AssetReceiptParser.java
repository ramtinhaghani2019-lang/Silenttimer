package com.example.silenttimer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Offline and conservative parser. Raw OCR is untrusted: every result needs user confirmation. */
public final class AssetReceiptParser {
    private AssetReceiptParser() {}
    private static final Pattern NUM = Pattern.compile("[0-9][0-9,.\\/\\u066B\\u066C]*");
    private static final Pattern JALALI = Pattern.compile("(1[34][0-9]{2})\\s*[/\\-]\\s*(0?[1-9]|1[0-2])\\s*[/\\-]\\s*([0-2]?[0-9]|3[01])");
    private static final Pattern CLOCK = Pattern.compile("(?:^|\\s)([01]?[0-9]|2[0-3]):([0-5][0-9])(?:\\s|$)");

    public static final class Result {
        public String assetType = "", group = "", tracking = "";
        public String amountRial = "", unitPriceRial = "", cashFeeRial = "";
        public String grossQuantity = "", gramFee = "", netQuantity = "";
        public int jalaliYear, jalaliMonth, jalaliDay, hour, minute;
        public boolean hasDate, isSale;
        public String rawText = "";
        public int recognizedCount() {
            int c=0;
            if(!amountRial.isEmpty())c++;
            if(!unitPriceRial.isEmpty())c++;
            if(!cashFeeRial.isEmpty())c++;
            if(!netQuantity.isEmpty())c++;
            if(hasDate)c++;
            return c;
        }
    }
    public static Result parse(String ocr) {
        Result out = new Result();
        if(ocr==null || ocr.trim().isEmpty())return out;
        out.rawText=ocr;
        String clean = normalizeLetters(ocr);
        if(clean.contains("نقره کاریزما") || clean.contains("پشتوانه نقره") || clean.contains("طرح نقره")){
            out.assetType="صندوق نقره کاریزما";out.group="بدون مجموعه";
        } else if(clean.contains("طلای ۱۸") || clean.contains("طلا 18")) out.assetType="طلای ۱۸ عیار";
        else if(clean.contains("طلای ۲۴") || clean.contains("طلا 24"))out.assetType="طلای ۲۴ عیار";
        else if(clean.contains("دلار"))out.assetType="دلار";
        else if(clean.contains("یورو"))out.assetType="یورو";
        else if(clean.contains("نقره"))out.assetType="نقره";
        out.isSale=clean.contains("نوع تراکنش فروش") || clean.contains("تراکنش: فروش");
        String[] lines=clean.split("\\R");
        for(int i=0;i<lines.length;i++) {
            String line=lines[i].trim();
            if(line.isEmpty())continue;
            String n=ascii(line);
            if(line.contains("نوع تراکنش") &&
                (line.contains("فروش") ||
                 (i+1<lines.length&&lines[i+1].trim().equals("فروش"))))out.isSale=true;
            if(line.contains("تاریخ تراکنش") || line.contains("تاریخ خرید") || line.contains("زمان تراکنش")){
                Matcher d=JALALI.matcher(n);
                if(d.find()){
                    int yy=Integer.parseInt(d.group(1)),mm=Integer.parseInt(d.group(2)),dd=Integer.parseInt(d.group(3));
                    if(yy>=1350&&yy<=1500&&mm>=1&&mm<=12&&dd>=1&&dd<=31){
                        out.hasDate=true;out.jalaliYear=yy;out.jalaliMonth=mm;out.jalaliDay=dd;
                    }
                }
                Matcher t=CLOCK.matcher(n);
                if(t.find()){out.hour=Integer.parseInt(t.group(1));out.minute=Integer.parseInt(t.group(2));}
            }
            if(line.contains("کد پیگیری") || line.contains("شماره پیگیری") || line.contains("شناسه تراکنش")) {
                String digits=n.replaceAll("[^0-9]","");
                if(digits.length()>=6&&digits.length()<=30)out.tracking=digits;
            }
            // Specific labels first. Do not confuse portfolio totals with receipt fields.
            if(line.contains("کارمزد گرمی") || line.contains("کارمزد وزنی"))out.gramFee=readLabel(lines,i,BigDecimal.ZERO,new BigDecimal("1000000"));
            else if(line.contains("کارمزد ریالی") || line.contains("کارمزد نقدی") || line.contains("کارمزد پرداختی"))out.cashFeeRial=readLabel(lines,i,BigDecimal.ZERO,new BigDecimal("100000000000000"));
            else if(line.contains("قیمت هر گرم") || line.contains("قیمت خرید هر واحد") || line.contains("قیمت واحد"))out.unitPriceRial=readLabel(lines,i,new BigDecimal("100"),new BigDecimal("10000000000000"));
            else if(line.matches(".*(?:مقدار خالص|خالص دریافتی|مقدار دریافتی|مقدار خرید خالص).*"))out.netQuantity=readLabel(lines,i,BigDecimal.ZERO,new BigDecimal("1000000000"));
            else if(line.contains("مقدار دارایی قبل") || line.contains("مقدار دارایی بعد")) { /* cumulative balance, never a purchase quantity */ }
            else if(line.contains("مقدار") && !line.contains("مبلغ"))out.grossQuantity=readLabel(lines,i,BigDecimal.ZERO,new BigDecimal("1000000000"));
            else if(line.contains("مبلغ") && !line.contains("کارمزد") && !line.contains("مانده"))out.amountRial=readLabel(lines,i,new BigDecimal("1000"),new BigDecimal("100000000000000"));
        }
        // Never charge the gram fee twice. The quantity stored in Nexa is NET units.
        if(out.netQuantity.isEmpty()&&!out.grossQuantity.isEmpty()){
            try{
                BigDecimal gross=new BigDecimal(out.grossQuantity);
                BigDecimal gram=out.gramFee.isEmpty()?BigDecimal.ZERO:new BigDecimal(out.gramFee);
                if(gross.compareTo(gram)>0)out.netQuantity=gross.subtract(gram).stripTrailingZeros().toPlainString();
            }catch(Exception ignored){}
        }
        // A mismatch within normal receipt rounding is expected; never override explicit net amount.
        return validateConsistency(out);
    }
    /**
     * Fail-closed OCR import guard for monetary data. This is not an OCR confidence score.
     * Recognized numbers must mathematically reconcile BEFORE they can pre-fill a purchase.
     * Any partial/mismatched receipt stays manual; nothing is silently guessed or saved.
     */
    public static boolean verifiedForAutomaticImport(Result r){
        return r!=null && !r.isSale && r.hasDate && !r.assetType.isEmpty()
            && financiallyConsistent(r);
    }
    /** Financial proof independent of OCR metadata (date/provider may be blurred). */
    public static boolean financiallyConsistent(Result r){
        if(r==null || r.isSale || r.assetType.isEmpty() ||
                r.amountRial.isEmpty() || r.unitPriceRial.isEmpty() ||
                r.grossQuantity.isEmpty() || r.netQuantity.isEmpty())return false;
        try{
            BigDecimal paid=new BigDecimal(r.amountRial);
            BigDecimal price=new BigDecimal(r.unitPriceRial);
            BigDecimal gross=new BigDecimal(r.grossQuantity);
            BigDecimal net=new BigDecimal(r.netQuantity);
            if(paid.signum()<=0 || price.signum()<=0 || gross.signum()<=0 || net.signum()<=0 ||
                    net.compareTo(gross)>0)return false;
            BigDecimal paidDeviation=gross.multiply(price).subtract(paid).abs()
                .divide(paid,8,RoundingMode.HALF_UP);
            if(paidDeviation.compareTo(new BigDecimal("0.005"))>0)return false;
            if("صندوق نقره کاریزما".equals(r.assetType)){
                // A Karizma silver receipt states both a weight fee and a cash fee.
                // Without BOTH, net quantity might be OCR's mistaken gross quantity.
                if(r.gramFee.isEmpty() || r.cashFeeRial.isEmpty())return false;
                BigDecimal weightFee=new BigDecimal(r.gramFee);
                BigDecimal rialFee=new BigDecimal(r.cashFeeRial);
                if(weightFee.signum()<0 || rialFee.signum()<0 ||
                        weightFee.compareTo(gross)>=0 || rialFee.compareTo(paid)>=0)return false;
                BigDecimal netDelta=gross.subtract(weightFee).subtract(net).abs();
                if(netDelta.compareTo(new BigDecimal("0.0001"))>0)return false;
                // Allow normal source price and weight rounding, but not OCR digit loss.
                BigDecimal feeDelta=weightFee.multiply(price).subtract(rialFee).abs();
                BigDecimal feeLimit=rialFee.multiply(new BigDecimal("0.01")).max(new BigDecimal("100"));
                if(feeDelta.compareTo(feeLimit)>0)return false;
            }else{
                // For other sources we have not validated a receipt-specific deduction formula.
                // Permit only a coherent, fee-free amount; never assume an unknown deduction.
                if(gross.subtract(net).abs().compareTo(new BigDecimal("0.0001"))>0)return false;
            }
            return true;
        }catch(Exception ignored){return false;}
    }

    /** Some OCR layouts put the number on the next line after the label. */
    private static String readLabel(String[] lines,int i,BigDecimal low,BigDecimal high){
        String value=read(lines[i],low,high);
        if(!value.isEmpty()||i+1>=lines.length)return value;
        String next=lines[i+1].trim();
        if(next.isEmpty()||next.contains("مقدار")||next.contains("قیمت")||
            next.contains("مبلغ")||next.contains("تراکنش")||next.contains("کارمزد")||
            next.contains("دارایی")||next.contains("خرید")||next.contains("پیگیری"))return "";
        return read(next,low,high);
    }
    /** Keep certain first-mode findings; add only information missing from a second OCR pass. */
    public static Result supplement(Result main,Result fallback){
        if(main==null)return fallback;
        if(fallback==null)return main;
        if(main.assetType.isEmpty())main.assetType=fallback.assetType;
        if(main.group.isEmpty())main.group=fallback.group;
        if(main.tracking.isEmpty())main.tracking=fallback.tracking;
        if(main.amountRial.isEmpty())main.amountRial=fallback.amountRial;
        if(main.unitPriceRial.isEmpty())main.unitPriceRial=fallback.unitPriceRial;
        if(main.cashFeeRial.isEmpty())main.cashFeeRial=fallback.cashFeeRial;
        if(main.grossQuantity.isEmpty())main.grossQuantity=fallback.grossQuantity;
        if(main.gramFee.isEmpty())main.gramFee=fallback.gramFee;
        if(main.netQuantity.isEmpty())main.netQuantity=fallback.netQuantity;
        if(!main.hasDate && fallback.hasDate){
            main.hasDate=true;main.jalaliYear=fallback.jalaliYear;
            main.jalaliMonth=fallback.jalaliMonth;main.jalaliDay=fallback.jalaliDay;
            main.hour=fallback.hour;main.minute=fallback.minute;
        }
        main.isSale|=fallback.isSale;
        return validateConsistency(main);
    }
    /** Reject gross/net quantities that contradict the total and price by more than 7%. */
    private static Result validateConsistency(Result r){
        if(r.amountRial.isEmpty()||r.unitPriceRial.isEmpty())return r;
        try{
            BigDecimal paid=new BigDecimal(r.amountRial),unit=new BigDecimal(r.unitPriceRial);
            if(paid.signum()<=0||unit.signum()<=0)return r;
            BigDecimal gross=!r.grossQuantity.isEmpty()?new BigDecimal(r.grossQuantity):null;
            BigDecimal net=!r.netQuantity.isEmpty()?new BigDecimal(r.netQuantity):null;
            BigDecimal cashFee=r.cashFeeRial.isEmpty()?BigDecimal.ZERO:new BigDecimal(r.cashFeeRial);
            if(cashFee.compareTo(paid)>=0){r.cashFeeRial="";cashFee=BigDecimal.ZERO;}
            BigDecimal estimate=gross!=null?gross.multiply(unit):
                (net!=null?net.multiply(unit).add(cashFee):null);
            if(estimate!=null){
                BigDecimal deviation=estimate.subtract(paid).abs().divide(paid,5,RoundingMode.HALF_UP);
                if(deviation.compareTo(new BigDecimal("0.07"))>0){
                    r.grossQuantity="";r.netQuantity="";r.gramFee="";
                }
            }
        }catch(Exception ignored){}
        return r;
    }
    private static String read(String line,BigDecimal lower,BigDecimal upper){
        Matcher m=NUM.matcher(repairClearOcrZeroInGrouping(ascii(line)));
        String last="";
        while(m.find()) {
            String raw=m.group();
            String canonical=number(raw);
            if(canonical.isEmpty())continue;
            try{
                BigDecimal v=new BigDecimal(canonical);
                if(v.compareTo(lower)>=0 && v.compareTo(upper)<=0)last=v.stripTrailingZeros().toPlainString();
            }catch(Exception ignored){}
        }
        return last;
    }
    private static String number(String raw){
        String s=raw.replace("\u066C",",").replace("\u066B",".");
        if(s.indexOf('/')>=0){
            String[] v=s.split("/");
            if(v.length==2 && v[1].length()>0 && v[1].length()<=9) s=v[0]+"."+v[1];
            else s=s.replace("/","");
        }
        // Commas are grouping marks; multiple dots with thousand groups are grouping marks too.
        s=s.replace(",","");
        if(s.indexOf('.')!=s.lastIndexOf('.') && s.indexOf('.')>=0){
            String[] chunks=s.split("\\.");
            boolean allGrouped=true;
            for(int i=1;i<chunks.length;i++)if(chunks[i].length()!=3)allGrouped=false;
            if(allGrouped)s=s.replace(".","");
            else {int last=s.lastIndexOf('.');s=s.substring(0,last).replace(".","")+s.substring(last);}
        }
        if(!s.matches("[0-9]+(?:\\.[0-9]+)?"))return "";
        return s;
    }
    /** Recognizes a single isolated value, not a portfolio balance from a nearby row. */
    public static String numericCandidate(String detected,String kind){
        if(detected==null || detected.isEmpty())return "";
        BigDecimal min=BigDecimal.ZERO,max=new BigDecimal("1000000000");
        if("amount".equals(kind)){min=new BigDecimal("1000");max=new BigDecimal("100000000000000");}
        else if("cashFee".equals(kind)){max=new BigDecimal("1000000000000");}
        else if("price".equals(kind)){min=new BigDecimal("100");max=new BigDecimal("10000000000000");}
        // OCR returns letters + values together. Only complete numeric tokens are accepted.
        String cleaned=repairClearOcrZeroInGrouping(ascii(detected)).replace('٬',',').replace('٫','.');
        String best="";
        Matcher m=NUM.matcher(cleaned);
        while(m.find()){
            String token=number(m.group());
            if(token.isEmpty())continue;
            try{
                BigDecimal n=new BigDecimal(token);
                if(n.compareTo(min)>=0 && n.compareTo(max)<=0 &&
                    (best.isEmpty() || n.compareTo(new BigDecimal(best))>0))
                    best=n.stripTrailingZeros().toPlainString();
            }catch(NumberFormatException ignored){}
        }
        return best;
    }
    /**
     * A common fas+eng artifact is "1,e00,000,000" for "1,000,000,000".
     * Replace only a single letter in a three-digit grouped token. This merely
     * creates an OCR candidate; financial reconciliation remains mandatory.
     */
    private static String repairClearOcrZeroInGrouping(String text){
        return text.replaceAll("(?i)(?<=,)[eo](?=[0-9]{2},)","0");
    }
    public static String ascii(String input){
        if(input==null)return "";
        StringBuilder b=new StringBuilder(input.length());
        for(int i=0;i<input.length();i++){
            char c=input.charAt(i);
            if(c>='\u06F0'&&c<='\u06F9') c=(char)('0'+c-'\u06F0');
            else if(c>='\u0660'&&c<='\u0669')c=(char)('0'+c-'\u0660');
            b.append(c);
        }
        return b.toString();
    }
    private static String normalizeLetters(String input){
        return input.replace('\u064A','\u06CC').replace('\u0643','\u06A9')
            .replace('\u200C',' ').replace('\u0640',' ').replace('\u0660','\u06F0');
    }
}
