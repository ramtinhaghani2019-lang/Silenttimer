package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SmartSilentActivity extends Activity {
    private TextView durationText;
    private TextView clockText;
    private TextView silentChip;
    private TextView vibrateChip;

    private int minutes = 30;
    private int targetMode = AudioManager.RINGER_MODE_SILENT;
    private long selectedEndAt = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        minutes = AppPrefs.getMinutes(this);
        buildUi();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 18)
        );
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        Button back = UiKit.secondaryButton(this, "‹");
        back.setTextSize(25f);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = UiKit.title(this, "سایلنت هوشمند و تمرکز");
        LinearLayout.LayoutParams tp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(UiKit.dp(this, 12), 0, 0, 0);
        header.addView(title, tp);

        root.addView(UiKit.featureHero(this,"focus","سایلنت هوشمند","تمرکز، زمان‌بندی و کنترل حالت صدا"),UiKit.matchWrap(this,0,14));

        LinearLayout modeCard = UiKit.cardLayout(this);
        root.addView(modeCard, UiKit.matchWrap(this, 0, 14));

        modeCard.addView(UiKit.sectionTitle(this, "حالت صدا"));
        modeCard.addView(
                UiKit.muted(this, "انتخاب کن تایمر روی Silent یا Vibrate اجرا شود."),
                UiKit.matchWrap(this, 5, 12)
        );

        LinearLayout modeRow = new LinearLayout(this);
        modeRow.setOrientation(LinearLayout.HORIZONTAL);
        modeCard.addView(modeRow, UiKit.matchWrap(this));

        silentChip = UiKit.chip(this, "Silent ✓", true);
        vibrateChip = UiKit.chip(this, "Vibrate", false);

        LinearLayout.LayoutParams half =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        half.setMargins(UiKit.dp(this, 4), 0, UiKit.dp(this, 4), 0);
        modeRow.addView(silentChip, half);
        modeRow.addView(vibrateChip, half);

        silentChip.setOnClickListener(v -> {
            targetMode = AudioManager.RINGER_MODE_SILENT;
            refreshModeChips();
        });

        vibrateChip.setOnClickListener(v -> {
            targetMode = AudioManager.RINGER_MODE_VIBRATE;
            refreshModeChips();
        });

        LinearLayout durationCard = UiKit.cardLayout(this);
        root.addView(durationCard, UiKit.matchWrap(this, 0, 14));

        durationCard.addView(UiKit.sectionTitle(this, "مدت زمان"));

        durationText = new TextView(this);
        durationText.setTextColor(p[3]);
        durationText.setTextSize(38f);
        durationText.setGravity(Gravity.CENTER);
        durationText.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        durationCard.addView(durationText, UiKit.matchWrap(this, 16, 14));

        LinearLayout step = new LinearLayout(this);
        step.setOrientation(LinearLayout.HORIZONTAL);
        durationCard.addView(step, UiKit.matchWrap(this, 0, 12));

        Button minus = UiKit.secondaryButton(this, "− 5");
        Button plus = UiKit.secondaryButton(this, "+ 5");

        LinearLayout.LayoutParams hp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        hp.setMargins(UiKit.dp(this, 4), 0, UiKit.dp(this, 4), 0);
        step.addView(minus, hp);
        step.addView(plus, hp);

        minus.setOnClickListener(v -> {
            selectedEndAt = 0L;
            minutes = Math.max(5, minutes - 5);
            updateDuration();
        });

        plus.setOnClickListener(v -> {
            selectedEndAt = 0L;
            minutes = Math.min(720, minutes + 5);
            updateDuration();
        });

        addPresetRow(durationCard, new int[]{5, 10, 15});
        addPresetRow(durationCard, new int[]{30, 45, 60});
        addPresetRow(durationCard, new int[]{90, 120, 180});

        LinearLayout clockCard = UiKit.cardLayout(this);
        root.addView(clockCard, UiKit.matchWrap(this, 0, 14));
        clockCard.addView(UiKit.sectionTitle(this, "خروج در ساعت مشخص"));
        clockCard.addView(
                UiKit.muted(this, "مثلاً رأس ساعت 13:45 گوشی دوباره صدادار شود."),
                UiKit.matchWrap(this, 5, 12)
        );

        clockText = new TextView(this);
        clockText.setTextColor(p[3]);
        clockText.setTextSize(23f);
        clockText.setGravity(Gravity.CENTER);
        clockText.setText("ساعت مشخص نشده");
        clockCard.addView(clockText, UiKit.matchWrap(this, 4, 12));

        Button chooseClock = UiKit.secondaryButton(this, "انتخاب ساعت پایان");
        chooseClock.setOnClickListener(v -> chooseClock());
        clockCard.addView(chooseClock);

        Button start = UiKit.primaryButton(this, "شروع تایمر");
        start.setOnClickListener(v -> startTimer());
        root.addView(start, UiKit.matchWrap(this, 0, 10));

        Button stop = UiKit.secondaryButton(this, "پایان تایمر و بازگشت صدا");
        stop.setOnClickListener(v -> stopTimer());
        root.addView(stop, UiKit.matchWrap(this, 0, 12));

        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        LinearLayout bottom = UiKit.bottomNav(
                this, -1,
                v -> { startActivity(new Intent(this, MainActivity.class)); finish(); },
                v -> startActivity(new Intent(this, TodayActivity.class)),
                v -> startActivity(new Intent(this, QuickAddActivity.class)),
                v -> startActivity(new Intent(this, HistoryActivity.class))
        );
        LinearLayout.LayoutParams bottomLp = UiKit.matchWrap(this);
        bottomLp.setMargins(
                UiKit.dp(this, 16),
                0,
                UiKit.dp(this, 16),
                UiKit.dp(this, 12)
        );
        screen.addView(bottom, bottomLp);

        setContentView(screen);
        updateDuration();
    }

    private void addPresetRow(LinearLayout parent, int[] values) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(row, UiKit.matchWrap(this, 0, 8));

        for (int value : values) {
            TextView chip = UiKit.chip(this, formatMinutes(value), false);
            LinearLayout.LayoutParams lp =
                    new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(UiKit.dp(this, 3), 0, UiKit.dp(this, 3), 0);
            row.addView(chip, lp);

            chip.setOnClickListener(v -> {
                selectedEndAt = 0L;
                minutes = value;
                updateDuration();
            });
        }
    }

    private void refreshModeChips() {
        LinearLayout parent = (LinearLayout) silentChip.getParent();
        int silentIndex = parent.indexOfChild(silentChip);
        int vibrateIndex = parent.indexOfChild(vibrateChip);
        parent.removeView(silentChip);
        parent.removeView(vibrateChip);

        silentChip = UiKit.chip(this, targetMode == AudioManager.RINGER_MODE_SILENT ? "Silent ✓" : "Silent",
                targetMode == AudioManager.RINGER_MODE_SILENT);
        vibrateChip = UiKit.chip(this, targetMode == AudioManager.RINGER_MODE_VIBRATE ? "Vibrate ✓" : "Vibrate",
                targetMode == AudioManager.RINGER_MODE_VIBRATE);

        LinearLayout.LayoutParams half =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        half.setMargins(UiKit.dp(this, 4), 0, UiKit.dp(this, 4), 0);

        parent.addView(silentChip, Math.min(silentIndex, parent.getChildCount()), half);
        parent.addView(vibrateChip, Math.min(vibrateIndex, parent.getChildCount()), half);

        silentChip.setOnClickListener(v -> {
            targetMode = AudioManager.RINGER_MODE_SILENT;
            refreshModeChips();
        });
        vibrateChip.setOnClickListener(v -> {
            targetMode = AudioManager.RINGER_MODE_VIBRATE;
            refreshModeChips();
        });
    }

    private void chooseClock() {
        Calendar now = Calendar.getInstance();

        PersianDatePickerHelper.pickTime(this,now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),"ساعت پایان",(hourOfDay,minuteOfHour)->{
            Calendar end = Calendar.getInstance();
            end.set(Calendar.HOUR_OF_DAY, hourOfDay);
            end.set(Calendar.MINUTE, minuteOfHour);
            end.set(Calendar.SECOND, 0);
            end.set(Calendar.MILLISECOND, 0);
            if (end.getTimeInMillis() <= System.currentTimeMillis()) end.add(Calendar.DAY_OF_YEAR, 1);
            selectedEndAt = end.getTimeInMillis();
            SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.getDefault());
            clockText.setText("پایان در " + f.format(new Date(selectedEndAt)));
        });
    }

    private void startTimer() {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_START);
        i.putExtra(SilentTimerService.EXTRA_TARGET_MODE, targetMode);

        if (selectedEndAt > 0L) {
            i.putExtra(SilentTimerService.EXTRA_END_AT, selectedEndAt);
        } else {
            i.putExtra(SilentTimerService.EXTRA_MINUTES, minutes);
        }

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }

        AppPrefs.setMinutes(this, minutes);
        finish();
    }

    private void stopTimer() {
        Intent i = new Intent(this, SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_STOP);

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }
        finish();
    }

    private void updateDuration() {
        durationText.setText(formatMinutes(minutes));
        if (selectedEndAt == 0L) {
            clockText.setText("ساعت مشخص نشده");
        }
    }

    private String formatMinutes(int value) {
        if (value < 60) return value + " دقیقه";
        int h = value / 60;
        int m = value % 60;
        return m == 0 ? h + " ساعت" : h + " ساعت و " + m + " دقیقه";
    }
}
