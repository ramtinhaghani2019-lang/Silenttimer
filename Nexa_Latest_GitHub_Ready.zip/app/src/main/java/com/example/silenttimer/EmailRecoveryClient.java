package com.example.silenttimer;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class EmailRecoveryClient {
    private EmailRecoveryClient(){}
    public interface Callback { void done(boolean ok,String message); }

    public static void sendOtp(Context c,String email,Callback cb){
        String base=NexaStore.emailSupabaseUrl(c).trim();String key=NexaStore.emailSupabaseAnon(c).trim();
        if(base.isEmpty()||key.isEmpty()){post(cb,false,"ابتدا آدرس Supabase و Anon Key را در تنظیمات ایمیل وارد کن.");return;}
        long left=60000L-(System.currentTimeMillis()-NexaStore.emailOtpLastSent(c));
        if(left>0){post(cb,false,"برای ارسال دوباره "+Math.max(1,left/1000)+" ثانیه صبر کن.");return;}
        new Thread(()->{
            HttpURLConnection con=null;
            try{
                String endpoint=base.replaceAll("/+$","")+"/auth/v1/otp";
                con=(HttpURLConnection)new URL(endpoint).openConnection();con.setRequestMethod("POST");con.setConnectTimeout(12000);con.setReadTimeout(12000);con.setDoOutput(true);
                con.setRequestProperty("Content-Type","application/json");con.setRequestProperty("apikey",key);con.setRequestProperty("Authorization","Bearer "+key);
                JSONObject body=new JSONObject();body.put("email",email);body.put("create_user",true);
                byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);try(OutputStream out=con.getOutputStream()){out.write(bytes);}int code=con.getResponseCode();
                if(code>=200&&code<300){NexaStore.markEmailOtpSent(c);post(cb,true,"کد تأیید به ایمیل ارسال شد. کد طبق تنظیمات Supabase منقضی می‌شود.");}
                else{BufferedReader br=new BufferedReader(new InputStreamReader(con.getErrorStream()!=null?con.getErrorStream():con.getInputStream()));StringBuilder x=new StringBuilder();String line;while((line=br.readLine())!=null)x.append(line);post(cb,false,"ارسال انجام نشد ("+code+"). "+x.toString());}
            }catch(Exception e){post(cb,false,"خطا در اتصال به پنل ایمیل: "+e.getMessage());}finally{if(con!=null)con.disconnect();}
        }).start();
    }

    public static void verifyOtp(Context c,String email,String token,Callback cb){
        String base=NexaStore.emailSupabaseUrl(c).trim();String key=NexaStore.emailSupabaseAnon(c).trim();
        if(base.isEmpty()||key.isEmpty()){post(cb,false,"پنل ایمیل تنظیم نشده است.");return;}
        new Thread(()->{HttpURLConnection con=null;try{String endpoint=base.replaceAll("/+$","")+"/auth/v1/verify";con=(HttpURLConnection)new URL(endpoint).openConnection();con.setRequestMethod("POST");con.setConnectTimeout(12000);con.setReadTimeout(12000);con.setDoOutput(true);con.setRequestProperty("Content-Type","application/json");con.setRequestProperty("apikey",key);con.setRequestProperty("Authorization","Bearer "+key);JSONObject body=new JSONObject();body.put("email",email);body.put("token",token);body.put("type","email");try(OutputStream out=con.getOutputStream()){out.write(body.toString().getBytes(StandardCharsets.UTF_8));}int code=con.getResponseCode();if(code>=200&&code<300){NexaStore.markEmailVerified(c,email);post(cb,true,"کد تأیید شد و ایمیل بازیابی معتبر است.");}else post(cb,false,"کد نادرست یا منقضی شده است.");}catch(Exception e){post(cb,false,"خطا در بررسی کد: "+e.getMessage());}finally{if(con!=null)con.disconnect();}}).start();
    }

    private static void post(Callback cb,boolean ok,String msg){new Handler(Looper.getMainLooper()).post(()->cb.done(ok,msg));}
}
