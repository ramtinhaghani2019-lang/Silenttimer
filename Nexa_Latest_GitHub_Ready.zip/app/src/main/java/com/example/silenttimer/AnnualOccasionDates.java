package com.example.silenttimer;

import java.util.Calendar;

/** Stable-year anniversaries: never derive next year from an already clamped Feb-28/Esfand-29. */
public final class AnnualOccasionDates {
    private AnnualOccasionDates() {}
    public static boolean valid(String calendar, int year, int month, int day) {
        if(year<1200 || year>2200 || month<1 || month>12 || day<1) return false;
        if("gregorian".equals(calendar))return year>=1800 && day<=gregorianDays(year,month);
        return "jalali".equals(calendar) && year<=1700 && day<=PersianDateUtil.monthLength(year,month);
    }
    static int gregorianDays(int year,int month) {
        if(month==2) return year%4==0 && (year%100!=0 || year%400==0)?29:28;
        return month==4||month==6||month==9||month==11?30:31;
    }
    public static long yearDate(String calendar,int year,int month,int day,int hour,int minute){
        if(month<1||month>12||day<1||day>31||hour<0||hour>23||minute<0||minute>59)return 0;
        if("gregorian".equals(calendar)){
            int actualDay=Math.min(day,gregorianDays(year,month));
            Calendar c=Calendar.getInstance();c.clear();c.setLenient(false);
            c.set(year,month-1,actualDay,hour,minute,0);
            return c.getTimeInMillis();
        }
        if(!"jalali".equals(calendar))return 0;
        int actualDay=Math.min(day,PersianDateUtil.monthLength(year,month));
        return PersianDateUtil.toMillis(year,month,actualDay,hour,minute);
    }
    public static long next(OccasionStore.Occasion event,long after){
        if(event==null || !valid(event.calendar,event.year,event.month,event.day))return 0;
        Calendar now=Calendar.getInstance();now.setTimeInMillis(after);
        int year="gregorian".equals(event.calendar)?now.get(Calendar.YEAR):PersianDateUtil.fromMillis(after)[0];
        year=Math.max(year,event.year);
        for(int i=0;i<30;i++,year++){
            long at=yearDate(event.calendar,year,event.month,event.day,event.hour,event.minute);
            if(at>after)return at;
        }
        return 0;
    }
    public static long beforeDays(long at,int days){
        Calendar c=Calendar.getInstance();c.setTimeInMillis(at);c.add(Calendar.DAY_OF_MONTH,-days);
        return c.getTimeInMillis();
    }
    public static String dateLabel(OccasionStore.Occasion e){
        String cal="gregorian".equals(e.calendar)?"میلادی":"شمسی";
        return e.year+"/"+String.format(java.util.Locale.US,"%02d/%02d",e.month,e.day)+" ("+cal+")";
    }
}
