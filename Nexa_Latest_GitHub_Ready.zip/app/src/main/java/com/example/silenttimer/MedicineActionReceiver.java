package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class MedicineActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        if(i==null)return;
        String id=i.getStringExtra("id");
        if(id==null || id.trim().isEmpty())return;
        NexaStore.Medicine m=NexaStore.medicine(c,id);
        if(m==null){MedicineScheduler.cancel(c,id);return;}
        String requestedAction=i.getAction();
        if(!"STOP_SOUND".equals(requestedAction) && !"SNOOZE".equals(requestedAction)
                && !"TAKEN_ON_TIME".equals(requestedAction) && !"TAKEN_NOW".equals(requestedAction)
                && !"SKIPPED".equals(requestedAction))return;
        NexaAudioController.stopOwner("medicine:"+id);
        if(!MedicineScheduler.canAct(m,System.currentTimeMillis())){
            MedicineScheduler.cancel(c,id);
            ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(("med"+id).hashCode());
            return;
        }
        String action=i.getAction();
        if("STOP_SOUND".equals(action)){ NexaNotificationEngine.showMedicineSilencedNotification(c,m); return; }
        ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(("med"+id).hashCode());
        long now=System.currentTimeMillis(),scheduled=m.nextDoseMillis;
        if("SNOOZE".equals(action)){
            int min=m.repeatMinutes>0?m.repeatMinutes:5;
            long at=MedicineScheduler.nextRepeatAt(now,min);
            if(MedicineScheduler.canSchedule(m,at)){
                MedicineScheduler.scheduleAt(c,id,at);
                NexaStore.addHistory(c,"دارو",m.name+" • "+min+" دقیقه بعد");
            }else{
                MedicineScheduler.cancel(c,id);
                NexaStore.addHistory(c,"دارو",m.name+" • تعویق خارج از دوره مصرف");
            }
            return;
        }
        NexaStore.MedicineDoseLog log=new NexaStore.MedicineDoseLog();log.medicineId=m.id;log.scheduledAt=scheduled;
        if("TAKEN_ON_TIME".equals(action)){
            log.status="taken_on_time";log.takenAt=scheduled>0?scheduled:now;m.nextDoseMillis=MedicineScheduler.nextDoseAt(scheduled>0?scheduled:now,m.intervalHours);
            NexaStore.addHistory(c,"دارو",m.name+" • سر وقت خوردم");
        }else if("TAKEN_NOW".equals(action)){
            log.status="taken_now";log.takenAt=now;m.nextDoseMillis=MedicineScheduler.nextDoseAt(now,m.intervalHours);
            NexaStore.addHistory(c,"دارو",m.name+" • الان خوردم");
        }else if("SKIPPED".equals(action)){
            log.status="skipped";log.takenAt=0;m.nextDoseMillis=MedicineScheduler.nextDoseAt(scheduled>0?scheduled:now,m.intervalHours);
            NexaStore.addHistory(c,"دارو",m.name+" • این نوبت مصرف نشد");
        }else return;
        NexaStore.addMedicineDoseLog(c,log);
        if(!MedicineScheduler.canSchedule(m,m.nextDoseMillis))m.active=false;
        java.util.List<NexaStore.Medicine>l=NexaStore.medicines(c);for(int x=0;x<l.size();x++)if(l.get(x).id.equals(m.id))l.set(x,m);NexaStore.saveMedicines(c,l);
        if(m.active)MedicineScheduler.schedule(c,m);
        else MedicineScheduler.cancel(c,m.id);
        TodayNotificationManager.refresh(c);
    }
}
