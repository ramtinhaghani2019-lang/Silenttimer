package com.example.silenttimer;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.DateTimeException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** A deliberately conservative, offline-only iCalendar importer.
 * Unsupported recurrence/time zone constructs are skipped instead of silently
 * creating reminders at an incorrect date. Preview does not change storage.
 */
public final class ReminderCalendarImporter {
    private ReminderCalendarImporter() {}
    public static final int MAX_BYTES = 1024 * 1024;
    public static final int MAX_EVENTS = 200;
    private static final int MAX_LINES = 12000;
    private static final int MAX_LINE_CHARS = 8192;
    private static final DateTimeFormatter STAMP = DateTimeFormatter
            .ofPattern("uuuuMMdd'T'HHmmss", Locale.US).withResolverStyle(ResolverStyle.STRICT);

    public static final class Candidate {
        public final NexaStore.Reminder reminder;
        public final String sourceUid;
        public final String description;
        Candidate(NexaStore.Reminder r, String uid, String note) { reminder = r; sourceUid = uid; description = note; }
    }
    public static final class Preview {
        public final List<Candidate> candidates = new ArrayList<>();
        public int total, duplicates, past, unsupported, cancelled, alarmsDropped;
        public String error = "";
        public boolean valid() { return error.isEmpty(); }
    }
    private static final class Event {
        final Map<String,String> props = new HashMap<>();
        final Set<String> unsupported = new HashSet<>();
        final List<String> alarms = new ArrayList<>();
        boolean inAlarm = false, alarmInvalid = false, alarmHasTrigger = false;
        String trigger = "", triggerParams = "", alarmAction = "";
        String dateParams = "";
        void add(String line) {
            int colon = line.indexOf(':');
            if (colon <= 0) return;
            String header=line.substring(0,colon);
            String key=header.split(";",2)[0].toUpperCase(Locale.ROOT);
            String value=line.substring(colon+1);
            if (inAlarm) {
                if ("TRIGGER".equals(key)) { trigger=value; triggerParams=header; alarmHasTrigger=true; }
                if ("ACTION".equals(key))alarmAction=value;
                return;
            }
            if ("DTSTART".equals(key)) dateParams=header;
            if ("EXDATE".equals(key)||"RDATE".equals(key)||"RECURRENCE-ID".equals(key)
                    ||"EXRULE".equals(key)) unsupported.add(key);
            // Repeated critical values are ambiguous; never guess which to trust.
            if (("UID".equals(key)||"DTSTART".equals(key)||"RRULE".equals(key)) && props.containsKey(key))
                unsupported.add(key);
            props.put(key,value);
        }
    }

    public static Preview inspect(String ics, long now, List<NexaStore.Reminder> existing) {
        Preview preview = new Preview();
        if (ics==null || ics.getBytes(StandardCharsets.UTF_8).length > MAX_BYTES) {
            preview.error="حجم فایل تقویم بیش از حد مجاز است (۱ مگابایت)."; return preview;
        }
        String text=ics.startsWith("\uFEFF")?ics.substring(1):ics;
        // Unfold lines according to RFC 5545; cap both physical and unfolded input.
        String[] physical=text.split("\r\n|\n|\r",-1);
        if (physical.length>MAX_LINES) { preview.error="تعداد خطوط فایل بیش از حد مجاز است.";return preview; }
        List<String> lines=new ArrayList<>();
        for(String line:physical) {
            if(line.length()>MAX_LINE_CHARS) {preview.error="یکی از خطوط فایل طول غیرمجاز دارد.";return preview;}
            if((line.startsWith(" ")||line.startsWith("\t")) && !lines.isEmpty()) {
                int last=lines.size()-1;
                String joined=lines.get(last)+line.substring(1);
                if(joined.length()>MAX_LINE_CHARS) { preview.error="طول متن یک رویداد بیش از حد مجاز است.";return preview; }
                lines.set(last,joined);
            } else lines.add(line);
        }
        if(lines.isEmpty() || !"BEGIN:VCALENDAR".equalsIgnoreCase(lines.get(0).trim())) {
            preview.error="این فایل تقویم استاندارد ICS نیست.";return preview;
        }
        Set<String> known=existingKeys(existing);
        Set<String> seen=new HashSet<>();
        int calendars=0, depth=0;
        Event event=null;
        for(String line:lines) {
            String l=line.trim();
            if(l.equalsIgnoreCase("BEGIN:VCALENDAR")) { calendars++;depth++; continue; }
            if(l.equalsIgnoreCase("END:VCALENDAR")) { depth--;continue; }
            if(l.equalsIgnoreCase("BEGIN:VEVENT")) {
                if(depth!=1 || event!=null) { preview.error="ساختار رویدادهای ICS نامعتبر است.";return preview; }
                event=new Event();continue;
            }
            if(l.equalsIgnoreCase("END:VEVENT")) {
                if(event==null) {preview.error="ساختار فایل تقویم ناقص است.";return preview;}
                preview.total++;
                if(preview.total>MAX_EVENTS){ preview.error="فایل بیش از ۲۰۰ رویداد دارد؛ آن را به فایل‌های کوچک‌تر تقسیم کنید."; return preview; }
                accept(event,now,known,seen,preview);
                event=null;continue;
            }
            if(event!=null) {
                if(l.equalsIgnoreCase("BEGIN:VALARM")) {
                    if(event.inAlarm) event.alarmInvalid=true;
                    event.inAlarm=true;event.trigger="";event.triggerParams="";event.alarmAction="";event.alarmHasTrigger=false;
                } else if(l.equalsIgnoreCase("END:VALARM")) {
                    if(event.inAlarm) {
                        String offset="DISPLAY".equalsIgnoreCase(event.alarmAction)
                                ?alarmMinutes(event.triggerParams,event.trigger):null;
                        if(offset!=null)event.alarms.add(offset);
                        else if(event.alarmHasTrigger)event.alarmInvalid=true;
                    }
                    event.inAlarm=false;
                } else if(l.startsWith("BEGIN:")||l.startsWith("END:")) {
                    // Components such as nested sub-events are not representable.
                    event.unsupported.add("nested");
                } else event.add(line);
            }
        }
        if(calendars!=1 || depth!=0 || event!=null || !text.trim().endsWith("END:VCALENDAR")) {
            preview.error="فایل ICS ناقص یا دارای چند تقویم است.";
            preview.candidates.clear();
        }
        if(preview.valid())removeContentDuplicates(preview,existing);
        return preview;
    }

    /** Also hide duplicates with different UIDs but the same existing local occurrence. */
    private static void removeContentDuplicates(Preview preview,List<NexaStore.Reminder> existing) {
        Set<String> content=new HashSet<>();
        if(existing!=null)for(NexaStore.Reminder reminder:existing) {
            if(reminder!=null && reminder.title!=null)content.add(contentKey(reminder));
        }
        java.util.Iterator<Candidate> it=preview.candidates.iterator();
        while(it.hasNext()){
            if(!content.add(contentKey(it.next().reminder))){it.remove();preview.duplicates++;}
        }
    }

    private static String contentKey(NexaStore.Reminder r){
        return (r.title==null?"":r.title)+"\u0000"+r.whenMillis+"\u0000"+r.recurrence;
    }

    private static void accept(Event e, long now, Set<String> known, Set<String> seen, Preview p) {
        String status=e.props.get("STATUS");
        if(status!=null && ("CANCELLED".equalsIgnoreCase(status)||"DECLINED".equalsIgnoreCase(status))) {
            p.cancelled++;return;
        }
        if(!e.unsupported.isEmpty()) {p.unsupported++;return;}
        String title=unescape(e.props.get("SUMMARY")).trim();
        if(title.isEmpty() || title.length()>240) {p.unsupported++;return;}
        String raw=e.props.get("DTSTART");
        if(raw==null) {p.unsupported++;return;}
        if(java.util.regex.Pattern.compile("(?:^|;)VALUE=DATE(?:;|$)",java.util.regex.Pattern.CASE_INSENSITIVE)
                .matcher(e.dateParams).find() || raw.length()==8) {p.unsupported++;return;}
        ZonedDateTime start=parseStart(raw,e.dateParams);
        if(start==null){p.unsupported++;return;}
        String recurrence=recurrence(e.props.get("RRULE"),start);
        if(recurrence==null) {p.unsupported++;return;}
        // External time zones for recurring events can diverge at DST boundaries.
        if(!"none".equals(recurrence) && !start.getZone().equals(ZoneId.systemDefault())) {
            p.unsupported++;return;
        }
        // A past recurring start can be advanced without silently importing a past alarm.
        if(start.toInstant().toEpochMilli()<=now && !"none".equals(recurrence)) {
            int stepDays="daily".equals(recurrence)?1:"weekly".equals(recurrence)?7:
                    "biweekly".equals(recurrence)?14:0;
            if(stepDays>0) {
                long oldDays=java.time.temporal.ChronoUnit.DAYS.between(start.toLocalDate(),
                        java.time.Instant.ofEpochMilli(now).atZone(start.getZone()).toLocalDate());
                if(oldDays>0)start=start.plusDays((oldDays/stepDays)*stepDays);
                while(start.toInstant().toEpochMilli()<=now)start=start.plusDays(stepDays);
            } else {
                long months=java.time.temporal.ChronoUnit.MONTHS.between(start.toLocalDate().withDayOfMonth(1),
                        java.time.Instant.ofEpochMilli(now).atZone(start.getZone()).toLocalDate().withDayOfMonth(1));
                if(months>0)start=start.plusMonths(months);
                while(start.toInstant().toEpochMilli()<=now)start=start.plusMonths(1);
            }
        }
        long millis=start.toInstant().toEpochMilli();
        if(millis<=now) {p.past++;return;}
        String uid=e.props.get("UID");
        if(uid==null || uid.trim().isEmpty()) uid="no-uid:"+title+":"+raw+":"+recurrence;
        uid=uid.trim();
        if(uid.length()>512){p.unsupported++;return;}
        String key=sourceKey(uid);
        if(known.contains(key) || !seen.add(key)) {p.duplicates++;return;}
        // Files previously exported by Nexa should not import existing Nexa entries.
        if(known.contains("nexa-uid:"+uid)) {p.duplicates++;return;}
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.title=title;
        r.whenMillis=millis;
        r.recurrence=recurrence;
        r.sourceKey=key;
        r.category="قرار";
        r.icon="📅";
        r.offsetsMinutes=e.alarms.isEmpty()?"0":String.join(",",new LinkedHashSet<>(e.alarms));
        r.repeatMinutes=5;
        if(e.alarmInvalid)p.alarmsDropped++;
        String description=unescape(e.props.get("DESCRIPTION"));
        if(description.length()>1500)description=description.substring(0,1500);
        p.candidates.add(new Candidate(r,uid,description));
    }

    private static ZonedDateTime parseStart(String value, String header) {
        try {
            if(!value.matches("[0-9]{8}T[0-9]{6}Z?"))return null;
            boolean z=value.endsWith("Z");
            LocalDateTime date=LocalDateTime.parse(z?value.substring(0,value.length()-1):value,STAMP);
            ZoneId zone=z?ZoneOffset.UTC:ZoneId.systemDefault();
            for(String param:header.split(";")) {
                if(param.toUpperCase(Locale.ROOT).startsWith("TZID=")) {
                    if(z)return null;
                    String id=param.substring(5).replace("\"","");
                    if(id.isEmpty() || id.length()>120 || id.startsWith("/"))return null;
                    zone=ZoneId.of(id);
                }
                if(param.toUpperCase(Locale.ROOT).startsWith("VALUE=") && !param.equalsIgnoreCase("VALUE=DATE-TIME"))return null;
            }
            // Reject nonexistent DST wall-clock times instead of shifting them silently.
            List<ZoneOffset> offsets=zone.getRules().getValidOffsets(date);
            if(offsets.size()!=1)return null;
            return ZonedDateTime.ofStrict(date,offsets.get(0),zone);
        } catch (DateTimeException | IllegalArgumentException ex) {return null;}
    }

    /** Only unlimited recurrences Nexa can represent exactly. */
    private static String recurrence(String rule,ZonedDateTime start) {
        if(rule==null || rule.trim().isEmpty())return "none";
        String freq="",interval="1",day="",weekStart="";
        for(String field:rule.toUpperCase(Locale.ROOT).split(";")) {
            String[] p=field.split("=",-1);
            if(p.length!=2)return null;
            if("FREQ".equals(p[0])) {if(!freq.isEmpty())return null;freq=p[1];}
            else if("INTERVAL".equals(p[0]))interval=p[1];
            else if("BYDAY".equals(p[0]))day=p[1];
            else if("WKST".equals(p[0]))weekStart=p[1];
            else return null; // COUNT, UNTIL, BYMONTHDAY, EXDATE etc. cannot map safely
        }
        if(!weekStart.isEmpty() && !(weekStart.equals("MO")||weekStart.equals("TU")||weekStart.equals("WE")||
                weekStart.equals("TH")||weekStart.equals("FR")||weekStart.equals("SA")||weekStart.equals("SU")))return null;
        if(!day.isEmpty()) {
            // A weekly single-day BYDAY equal to DTSTART is representable;
            // multiple weekdays or positional weekdays are not.
            if(!"WEEKLY".equals(freq))return null;
            String expected=new String[]{"MO","TU","WE","TH","FR","SA","SU"}[start.getDayOfWeek().getValue()-1];
            if(!expected.equals(day))return null;
        }
        if("DAILY".equals(freq)&&"1".equals(interval))return "daily";
        if("WEEKLY".equals(freq)&&"1".equals(interval))return "weekly";
        if("WEEKLY".equals(freq)&&"2".equals(interval))return "biweekly";
        if("MONTHLY".equals(freq)&&"1".equals(interval))return "monthly";
        return null;
    }

    /** DTSTART-relative triggers: minutes/hours/days before start only. */
    private static String alarmMinutes(String header,String value) {
        if(header==null || header.toUpperCase(Locale.ROOT).contains("RELATED=END") ||
                header.toUpperCase(Locale.ROOT).contains("VALUE=DATE-TIME") ||value==null)return null;
        String v=value.trim().toUpperCase(Locale.ROOT);
        if("PT0M".equals(v))return "0";
        if(!v.startsWith("-P"))return null;
        String body=v.substring(2);
        java.util.regex.Matcher m=java.util.regex.Pattern.compile("^(?:(\\d+)D)?(?:T(?:(\\d+)H)?(?:(\\d+)M)?)?$").matcher(body);
        if(!m.matches() || body.isEmpty())return null;
        if(m.group(1)==null && m.group(2)==null && m.group(3)==null)return null;
        try {
            long days=m.group(1)==null?0:Long.parseLong(m.group(1));
            long hours=m.group(2)==null?0:Long.parseLong(m.group(2));
            long mins=m.group(3)==null?0:Long.parseLong(m.group(3));
            if(days>365 || hours>8760 || mins>525600)return null;
            long result=days*1440L + hours*60L + mins;
            return result<=525600L?Long.toString(result):null;
        } catch(NumberFormatException ex){return null;}
    }

    static String unescape(String value) {
        if(value==null)return "";
        StringBuilder out=new StringBuilder();
        for(int i=0;i<value.length();i++){
            char ch=value.charAt(i);
            if(ch=='\\'&&i+1<value.length()){
                char next=value.charAt(++i);
                if(next=='n'||next=='N')out.append('\n');
                else if(next=='\\'||next==','||next==';')out.append(next);
                else {out.append('\\').append(next);}
            }else out.append(ch);
        }
        return out.toString();
    }

    static String sourceKey(String uid) {
        try {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(uid.getBytes(StandardCharsets.UTF_8));
            StringBuilder builder=new StringBuilder("ics:");
            for(byte b:digest)builder.append(String.format(Locale.ROOT,"%02x",b&255));
            return builder.toString();
        }catch(Exception e){throw new IllegalStateException("Missing SHA-256",e);}
    }

    public static Set<String> existingKeys(List<NexaStore.Reminder> existing) {
        Set<String> keys=new HashSet<>();
        if(existing==null)return keys;
        for(NexaStore.Reminder r:existing) {
            if(r==null)continue;
            if(r.sourceKey!=null && r.sourceKey.startsWith("ics:"))keys.add(r.sourceKey);
            if(r.id!=null) {
                String uid=UUID.nameUUIDFromBytes(r.id.getBytes(StandardCharsets.UTF_8))+"@nexa.local";
                keys.add("nexa-uid:"+uid);
            }
        }
        return keys;
    }

    /** Revalidate at commit time to prevent duplicate imports after preview. */
    public static List<NexaStore.Reminder> choose(Preview preview,boolean[] checks,
                       List<NexaStore.Reminder> current,long now,boolean includeNotes) {
        if(preview==null || !preview.valid() || checks==null)return Collections.emptyList();
        Set<String> keys=existingKeys(current);
        List<NexaStore.Reminder> accepted=new ArrayList<>();
        for(int i=0;i<preview.candidates.size() && i<checks.length;i++){
            if(!checks[i])continue;
            Candidate c=preview.candidates.get(i);
            NexaStore.Reminder r=c.reminder;
            if(r.whenMillis<=now || keys.contains(r.sourceKey) || keys.contains("nexa-uid:"+c.sourceUid))continue;
            boolean existingDuplicate=false;
            if(current!=null)for(NexaStore.Reminder old:current){
                if(old!=null && r.title.equals(old.title) && old.whenMillis==r.whenMillis
                    && r.recurrence.equals(old.recurrence)){ existingDuplicate=true;break; }
            }
            if(!existingDuplicate)for(NexaStore.Reminder prior:accepted){
                if(r.title.equals(prior.title) && r.whenMillis==prior.whenMillis
                        && r.recurrence.equals(prior.recurrence)){existingDuplicate=true;break;}
            }
            if(existingDuplicate)continue;
            r.note=includeNotes?c.description:"";
            accepted.add(r);keys.add(r.sourceKey);
        }
        return accepted;
    }
}
