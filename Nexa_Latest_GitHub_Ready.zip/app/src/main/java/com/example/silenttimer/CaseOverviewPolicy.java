package com.example.silenttimer;

/** View-only case dates and filters. Never advances a stored case or alarm. */
final class CaseOverviewPolicy {
    private CaseOverviewPolicy() { }

    static long shownDate(long savedDate, String recurrence, long now) {
        if (savedDate <= 0) return savedDate;
        if (savedDate < now && ReminderRecurrence.isRecurring(recurrence)) {
            return ReminderRecurrence.next(savedDate, recurrence, now);
        }
        return savedDate;
    }

    static boolean isPast(long shownDate, long now) {
        return shownDate > 0 && shownDate < now;
    }

    static boolean matches(String filter, long shownDate, long now) {
        if ("آینده".equals(filter)) return shownDate >= now;
        if ("گذشته".equals(filter)) return isPast(shownDate, now);
        return true;
    }
}
