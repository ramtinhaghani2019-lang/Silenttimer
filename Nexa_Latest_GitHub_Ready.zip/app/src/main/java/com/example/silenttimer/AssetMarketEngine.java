package com.example.silenttimer;

import android.content.Context;
import java.util.List;

/** Shared market-price application and alert evaluation for Assets UI/background monitor. */
public final class AssetMarketEngine {
    private AssetMarketEngine() {}
    public static double marketPrice(Context c,String type){
        if(type==null)return 0;
        if(type.contains("۱۸"))return NexaStore.iranGold18(c);
        if(type.contains("۲۴"))return NexaStore.iranGold24(c);
        if(type.equals("دلار"))return NexaStore.iranUsd(c);
        if(type.equals("یورو"))return NexaStore.iranEur(c);
        if(type.contains("نیم"))return NexaStore.iranHalf(c);
        if(type.contains("ربع"))return NexaStore.iranQuarter(c);
        if(type.contains("بهار"))return NexaStore.iranBahar(c);
        if(type.contains("گرمی"))return NexaStore.iranGerami(c);
        return 0;
    }
    public static void updateOnlineAssets(Context c){
        List<NexaStore.AssetEntry> data=NexaStore.assets(c);
        boolean changed=false;
        for(NexaStore.AssetEntry x:data)if(x.autoPrice){double v=marketPrice(c,x.type);if(Double.isFinite(v)&&v>0&&x.currentUnitPrice!=v){x.currentUnitPrice=v;changed=true;}}
        if(changed)NexaStore.saveAssets(c,data);
    }
    public static void checkAlerts(Context c){
        List<NexaStore.AssetEntry> data=NexaStore.assets(c);boolean changed=false;long now=System.currentTimeMillis();
        for(NexaStore.AssetEntry x:data){
            double target=x.alertTarget>0?x.alertTarget:(x.alertAtBuy?x.buyUnitPrice:0);
            if(!Double.isFinite(target)||!Double.isFinite(x.currentUnitPrice)||target<=0||x.currentUnitPrice<=0)continue;
            double tolerance=Math.max(1,target*0.001d),reset=Math.max(1,target*0.01d);
            boolean hit;
            if("up".equals(x.alertDirection)) hit=x.currentUnitPrice>=target;
            else if("down".equals(x.alertDirection)) hit=x.currentUnitPrice<=target;
            else if("exact".equals(x.alertDirection)) hit=Math.abs(x.currentUnitPrice-target)<=tolerance;
            else hit=Math.abs(x.currentUnitPrice-target)<=tolerance || ((x.lastAlertObservedPrice>0)&&(x.lastAlertObservedPrice-target)*(x.currentUnitPrice-target)<=0);
            boolean cooldown=now-x.alertLastNotifiedAt>=30*60_000L;
            if(hit&&!x.alertTriggered&&cooldown){PriceAlertNotifier.show(c,x.type,x.currentUnitPrice,target);x.alertTriggered=true;x.alertLastNotifiedAt=now;changed=true;}
            else if(!hit&&x.alertTriggered&&Math.abs(x.currentUnitPrice-target)>reset){x.alertTriggered=false;changed=true;}
            if(x.lastAlertObservedPrice!=x.currentUnitPrice){x.lastAlertObservedPrice=x.currentUnitPrice;changed=true;}
        }
        if(changed)NexaStore.saveAssets(c,data);
    }
    public static boolean hasActiveAlerts(Context c){for(NexaStore.AssetEntry x:NexaStore.assets(c))if(x.alertTarget>0||x.alertAtBuy)return true;return false;}
}
