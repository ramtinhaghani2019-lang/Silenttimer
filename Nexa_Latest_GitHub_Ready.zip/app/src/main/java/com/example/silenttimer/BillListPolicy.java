package com.example.silenttimer;

import java.util.List;

/** Pure view policy: read-only ordering and seven-day grouping for bills. */
final class BillListPolicy {
    static final String SEVEN_DAY_FILTER = "۷ روز آینده";
    private static final long DAY_MS = 24L * 60L * 60L * 1000L;
    private static final long WEEK_MS = 7L * DAY_MS;
    private BillListPolicy() { }

    static boolean overdue(boolean paid, long due, long now) {
        return !paid && due < now;
    }

    static long horizon(long now) {
        return now > Long.MAX_VALUE - WEEK_MS ? Long.MAX_VALUE : now + WEEK_MS;
    }

    static boolean soon(boolean paid, long due, long now) {
        return !paid && due >= now && due <= horizon(now);
    }

    static boolean matches(String filter, boolean paid, long due, long now) {
        if ("معوق".equals(filter)) return overdue(paid, due, now);
        if (SEVEN_DAY_FILTER.equals(filter)) return soon(paid, due, now);
        if ("آینده".equals(filter)) return !paid && due >= now;
        if ("پرداخت‌شده".equals(filter)) return paid;
        return true;
    }

    static int priority(boolean paid, long due, long now) {
        if (paid) return 3;
        if (due < now) return 0;
        if (due <= horizon(now)) return 1;
        return 2;
    }

    static int compare(boolean paidA, long dueA, boolean paidB, long dueB, long now) {
        int group = Integer.compare(priority(paidA, dueA, now),priority(paidB, dueB, now));
        if (group != 0) return group;
        // Overdue, near and future: earliest first. Paid: most recently due first.
        return paidA ? Long.compare(dueB, dueA) : Long.compare(dueA, dueB);
    }

    static long plusNonNegative(long total, long amount) {
        if (amount <= 0) return total;
        if (total > Long.MAX_VALUE - amount) return Long.MAX_VALUE;
        return total + amount;
    }

    static final class Entry {
        final boolean paid;
        final long due, amount;
        Entry(boolean paid, long due, long amount) {
            this.paid = paid;
            this.due = due;
            this.amount = amount;
        }
    }

    static final class Summary {
        long pendingAmount;
        long overdueAmount;
        long soonAmount;
        int overdueCount;
        int soonCount;
        int upcomingCount;
        int paidCount;
    }

    static Summary summarize(List<Entry> rows, long now) {
        Summary total = new Summary();
        if (rows == null) return total;
        for (Entry row : rows) {
            if (row == null) continue;
            if (row.paid) { total.paidCount++; continue; }
            total.pendingAmount = plusNonNegative(total.pendingAmount, row.amount);
            if (overdue(false, row.due, now)) {
                total.overdueCount++;
                total.overdueAmount = plusNonNegative(total.overdueAmount, row.amount);
            } else {
                total.upcomingCount++;
                if (soon(false, row.due, now)) {
                    total.soonCount++;
                    total.soonAmount = plusNonNegative(total.soonAmount, row.amount);
                }
            }
        }
        return total;
    }
}
