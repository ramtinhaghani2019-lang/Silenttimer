package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Explicit user action for silencing the active battery threshold alarm. */
public class BatteryAlarmActionReceiver extends BroadcastReceiver {
    public static final String ACTION_STOP = "com.example.silenttimer.BATTERY_ALARM_STOP";
    public static final String OWNER_CHARGE = "battery_charge_limit";
    @Override public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null || !ACTION_STOP.equals(intent.getAction())) return;
        NexaAudioController.stopOwner(OWNER_CHARGE);
        NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null) nm.cancel(BatteryAlertManager.CHARGE_ID);
    }
}
