package com.example.silenttimer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * Provider-specific, finite reconciliation of independently read receipt cells.
 * OCR strings are guesses; arithmetic is evidence, never a source of fabricated digits.
 * Works with incomplete receipts: one unreadable fee no longer erases a verified trio.
 */
public final class AssetReceiptFieldFusion {
    private AssetReceiptFieldFusion() { }
    private static final int MAX_COMBINATIONS=20000;
    private static final BigDecimal PAID_TOLERANCE=new BigDecimal("0.005");
    private static final BigDecimal FEE_TOLERANCE=new BigDecimal("0.015");
    private static final BigDecimal FEE_PERCENT=new BigDecimal("0.005");

    public static final class Candidates {
        public final List<String> amount=new ArrayList<>(), gross=new ArrayList<>(),
                price=new ArrayList<>(), cashFee=new ArrayList<>(), gramFee=new ArrayList<>();
        public void add(String kind,String text) {
            String value=AssetReceiptParser.numericCandidate(text,kind);
            if(value.isEmpty())return;
            List<String> list=forKind(kind);
            if(list!=null&&!list.contains(value)&&list.size()<6)list.add(value);
        }
        private List<String> forKind(String kind){
            switch(kind){
                case "amount":return amount;
                case "gross":return gross;
                case "price":return price;
                case "cashFee":return cashFee;
                case "gramFee":return gramFee;
                default:return null;
            }
        }
    }
    private static BigDecimal positive(String value){
        if(value==null||value.trim().isEmpty())return null;
        try{BigDecimal d=new BigDecimal(value);return d.signum()>0?d:null;}
        catch(NumberFormatException ex){return null;}
    }
    private static boolean close(BigDecimal actual,BigDecimal expected,BigDecimal tolerance){
        return actual!=null&&expected!=null&&expected.signum()>0&&
            actual.subtract(expected).abs().divide(expected,12,RoundingMode.HALF_UP)
                .compareTo(tolerance)<=0;
    }
    private static List<String> candidates(String original,List<String> extra){
        LinkedHashSet<String> set=new LinkedHashSet<>();
        if(original!=null&&!original.isEmpty())set.add(original);
        set.addAll(extra);
        // An illegible field must never suppress verification of other pairs.
        set.add("");
        return new ArrayList<>(set);
    }
    private static AssetReceiptParser.Result meta(AssetReceiptParser.Result old){
        AssetReceiptParser.Result n=new AssetReceiptParser.Result();
        n.assetType=old.assetType;n.group=old.group;n.tracking=old.tracking;
        n.rawText=old.rawText;n.isSale=old.isSale;n.hasDate=old.hasDate;
        n.jalaliYear=old.jalaliYear;n.jalaliMonth=old.jalaliMonth;
        n.jalaliDay=old.jalaliDay;n.hour=old.hour;n.minute=old.minute;
        return n;
    }

    public static AssetReceiptParser.Result fuse(AssetReceiptParser.Result base,Candidates values){
        if(base==null)base=new AssetReceiptParser.Result();
        if(values==null||base.isSale||!"صندوق نقره کاریزما".equals(base.assetType))return base;
        List<String> amounts=candidates(base.amountRial,values.amount);
        List<String> grosses=candidates(base.grossQuantity,values.gross);
        List<String> prices=candidates(base.unitPriceRial,values.price);
        List<String> rialFees=candidates(base.cashFeeRial,values.cashFee);
        List<String> gramFees=candidates(base.gramFee,values.gramFee);
        AssetReceiptParser.Result best=null;
        int bestScore=0,attempts=0;
        for(String amount:amounts)for(String gross:grosses)for(String price:prices)
            for(String cash:rialFees)for(String grams:gramFees){
            if(++attempts>MAX_COMBINATIONS)return best==null?base:best;
            BigDecimal a=positive(amount),g=positive(gross),p=positive(price),
                f=positive(cash),w=positive(grams);
            boolean trio=a!=null&&g!=null&&p!=null&&close(g.multiply(p),a,PAID_TOLERANCE);
            boolean cashPair=a!=null&&f!=null&&f.compareTo(a)<0&&
                close(f,a.multiply(FEE_PERCENT),FEE_TOLERANCE);
            boolean gramPair=g!=null&&w!=null&&w.compareTo(g)<0&&
                close(w,g.multiply(FEE_PERCENT),FEE_TOLERANCE);
            // A complete contradictory trio is a red flag, not justification
            // for accepting a coincidentally matching fee pair.
            boolean contradictory=a!=null&&g!=null&&p!=null&&!trio;
            if(contradictory)continue;
            // Each verified relationship adds evidence. The source's rate and
            // quantity must agree before their values are moved to the form.
            if(!trio&&!cashPair&&!gramPair)continue;
            AssetReceiptParser.Result r=meta(base);
            int score=0;
            if(trio){r.amountRial=amount;r.grossQuantity=gross;r.unitPriceRial=price;score+=6;}
            if(cashPair){r.amountRial=amount;r.cashFeeRial=cash;score+=2;}
            if(gramPair){
                r.grossQuantity=gross;r.gramFee=grams;
                r.netQuantity=g.subtract(w).stripTrailingZeros().toPlainString();score+=2;
            }
            // Partial readings are allowed only if the missing fields are
            // genuinely missing, not if their OCR values already conflict.
            if(score>bestScore){best=r;bestScore=score;}
            if(trio&&cashPair&&gramPair&&AssetReceiptParser.financiallyConsistent(r))return r;
        }
        return best==null?base:best;
    }
}
