package com.example.silenttimer;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * Finite, deterministic reconciliation of independently recognized receipt fields.
 * OCR text is untrusted. No missing purchase quantity is manufactured from a price.
 * Package-private pure Java for desktop + Android regression tests.
 */
public final class AssetReceiptFieldFusion {
    private AssetReceiptFieldFusion() { }
    private static final String[] FIELDS={"amountRial","grossQuantity","unitPriceRial","cashFeeRial","gramFee"};
    private static final int LIMIT=300; // Bound OCR combinations and CPU time.

    public static final class Candidates {
        public final List<String> amount=new ArrayList<>(), gross=new ArrayList<>(),
                price=new ArrayList<>(), cashFee=new ArrayList<>(), gramFee=new ArrayList<>();
        public void add(String kind,String text){
            String value=AssetReceiptParser.numericCandidate(text,kind);
            if(value.isEmpty())return;
            List<String> list=forKind(kind);
            if(list!=null&&!list.contains(value)&&list.size()<3)list.add(value);
        }
        private List<String> forKind(String kind){
            switch(kind){
                case "amount": return amount;
                case "gross": return gross;
                case "price": return price;
                case "cashFee": return cashFee;
                case "gramFee": return gramFee;
                default:return null;
            }
        }
    }
    public static AssetReceiptParser.Result fuse(AssetReceiptParser.Result base,Candidates values){
        if(base==null)base=new AssetReceiptParser.Result();
        if(values==null)return base;
        if(!"صندوق نقره کاریزما".equals(base.assetType)||base.isSale)return base;
        // A receipt with incomplete or incorrect date is for manual review, not silent import.
        if(!base.hasDate)return base;
        List<String> amounts=withOriginal(base.amountRial,values.amount),
                grosses=withOriginal(base.grossQuantity,values.gross),
                prices=withOriginal(base.unitPriceRial,values.price),
                cashFees=withOriginal(base.cashFeeRial,values.cashFee),
                gramFees=withOriginal(base.gramFee,values.gramFee);
        int attempts=0;
        for(String amount:amounts)for(String gross:grosses)for(String price:prices)
            for(String fee:cashFees)for(String weight:gramFees){
            if(++attempts>LIMIT)return base;
            if(amount.isEmpty()||gross.isEmpty()||price.isEmpty()||fee.isEmpty()||weight.isEmpty())continue;
            try {
                AssetReceiptParser.Result r=copyMetadata(base);
                r.amountRial=amount;r.grossQuantity=gross;r.unitPriceRial=price;
                r.cashFeeRial=fee;r.gramFee=weight;
                BigDecimal g=new BigDecimal(gross),f=new BigDecimal(weight);
                if(g.compareTo(f)<=0)continue;
                r.netQuantity=g.subtract(f).stripTrailingZeros().toPlainString();
                if(AssetReceiptParser.verifiedForAutomaticImport(r))return r;
            }catch(NumberFormatException ignored){}
        }
        return base;
    }
    private static List<String> withOriginal(String original,List<String> newValues){
        LinkedHashSet<String> set=new LinkedHashSet<>();
        if(original!=null&&!original.isEmpty())set.add(original);
        set.addAll(newValues);
        if(set.isEmpty())set.add("");
        return new ArrayList<>(set);
    }
    private static AssetReceiptParser.Result copyMetadata(AssetReceiptParser.Result r){
        AssetReceiptParser.Result n=new AssetReceiptParser.Result();
        n.assetType=r.assetType;n.group=r.group;n.tracking=r.tracking;n.rawText=r.rawText;
        n.hasDate=r.hasDate;n.jalaliYear=r.jalaliYear;n.jalaliMonth=r.jalaliMonth;
        n.jalaliDay=r.jalaliDay;n.hour=r.hour;n.minute=r.minute;n.isSale=r.isSale;
        return n;
    }
}
