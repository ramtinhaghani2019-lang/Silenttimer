package com.example.silenttimer;

import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.UUID;

/** Stateless RFC 5545 calendar writer. Never changes NexaStore or the device calendar. */
public final class ReminderCalendarExport {
    private static final long DURATION_MILLIS = 30L * 60_000L;
    private ReminderCalendarExport() {}

    /** Only current enabled reminders become external calendar events. */
    public static boolean eligible(NexaStore.Reminder r) {
        return r != null && r.active && !r.done && r.whenMillis > 0L;
    }

    public static List<NexaStore.Reminder> eligible(List<NexaStore.Reminder> input) {
        List<NexaStore.Reminder> result = new ArrayList<>();
        if (input == null) return result;
        Set<String> ids = new HashSet<>();
        for (NexaStore.Reminder r : input) {
            if (eligible(r) && ids.add(r.id == null ? "" : r.id)) result.add(r);
        }
        return result;
    }

    /** Create an RFC 5545 UTF-8 iCalendar document with CRLF and 75-octet folding. */
    public static String generate(List<NexaStore.Reminder> source, long generatedAt, boolean includeDetails) {
        StringBuilder out = new StringBuilder(2048);
        line(out, "BEGIN:VCALENDAR");
        line(out, "VERSION:2.0");
        line(out, "PRODID:-//Nexa//Reminders 5.4.141//FA");
        line(out, "CALSCALE:GREGORIAN");
        line(out, "X-WR-CALNAME:" + escape("Nexa یادآورها"));
        for (NexaStore.Reminder r : eligible(source)) {
            line(out, "BEGIN:VEVENT");
            // Stable opaque UID permits destination calendars to identify repeated exports.
            String uid = UUID.nameUUIDFromBytes(("nexa-reminder:" + safe(r.id))
                    .getBytes(StandardCharsets.UTF_8)).toString() + "@nexa.local";
            line(out, "UID:" + uid);
            line(out, "DTSTAMP:" + dateUtc(generatedAt));
            String rrule = recurrenceRule(r.recurrence);
            if (!rrule.isEmpty()) {
                // Floating local date-time preserves the configured wall-clock time at DST changes.
                // Receiving calendar's timezone controls the interpretation after import.
                line(out, "DTSTART:" + dateLocal(r.whenMillis));
                // Duration avoids a negative-looking end time during autumn DST rollback.
                line(out, "DURATION:PT30M");
                line(out, "RRULE:" + rrule);
            } else {
                // One-time event always preserves the exact instant across timezones.
                line(out, "DTSTART:" + dateUtc(r.whenMillis));
                line(out, "DTEND:" + dateUtc(safeEnd(r.whenMillis)));
            }
            line(out, "SUMMARY:" + escape(safe(r.title).isEmpty() ? "یادآور Nexa" : r.title));
            if (includeDetails) {
                if (!safe(r.category).isEmpty()) line(out, "CATEGORIES:" + escape(r.category));
                String details = description(r);
                if (!details.isEmpty()) line(out, "DESCRIPTION:" + escape(details));
                if (!safe(r.doctorAddress).isEmpty()) line(out, "LOCATION:" + escape(r.doctorAddress));
            }
            line(out, "TRANSP:TRANSPARENT");
            // Numeric offset rules translate exactly to calendar alarms. Calendar-specific
            // D3@09:00 rules cannot be represented by a fixed relative VALARM and are omitted.
            Set<Long> exportedAlarms = new HashSet<>();
            for (String rule : AlertRules.split(r.offsetsMinutes)) {
                Long minutes = alarmOffsetMinutes(rule);
                if (minutes == null || !exportedAlarms.add(minutes)) continue;
                line(out, "BEGIN:VALARM");
                line(out, "ACTION:DISPLAY");
                line(out, "DESCRIPTION:" + escape(safe(r.title).isEmpty() ? "یادآور Nexa" : r.title));
                line(out, "TRIGGER:" + (minutes == 0 ? "PT0M" : "-PT" + minutes + "M"));
                line(out, "END:VALARM");
            }
            line(out, "END:VEVENT");
        }
        line(out, "END:VCALENDAR");
        return out.toString();
    }

    static String recurrenceRule(String recurrence) {
        if ("daily".equals(recurrence)) return "FREQ=DAILY";
        if ("weekly".equals(recurrence)) return "FREQ=WEEKLY";
        if ("biweekly".equals(recurrence)) return "FREQ=WEEKLY;INTERVAL=2";
        if ("monthly".equals(recurrence)) return "FREQ=MONTHLY";
        return "";
    }

    static Long alarmOffsetMinutes(String rule) {
        if (rule == null || !rule.matches("[0-9]{1,8}")) return null;
        try {
            long minutes = Long.parseLong(rule);
            return minutes <= 52_560_000L ? minutes : null;
        } catch (NumberFormatException ignored) { return null; }
    }

    private static String description(NexaStore.Reminder r) {
        StringBuilder d = new StringBuilder();
        descriptionPart(d, "توضیحات", r.note);
        descriptionPart(d, "پزشک", r.doctorName);
        descriptionPart(d, "شماره پرونده", r.doctorFileNumber);
        descriptionPart(d, "مرکز", r.doctorCenter);
        descriptionPart(d, "شماره تماس", r.doctorPhone);
        descriptionPart(d, "نشانی", r.doctorAddress);
        return d.toString();
    }

    private static void descriptionPart(StringBuilder b, String label, String value) {
        if (value == null || value.trim().isEmpty()) return;
        if (b.length() > 0) b.append('\n');
        b.append(label).append(": ").append(value);
    }

    static String escape(String raw) {
        String s = safe(raw).replace("\r\n", "\n").replace('\r', '\n')
                .replace('\u2028', '\n').replace('\u2029', '\n');
        StringBuilder out = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\') out.append("\\\\");
            else if (c == ';') out.append("\\;");
            else if (c == ',') out.append("\\,");
            else if (c == '\n') out.append("\\n");
            else if (c < 32 || c == 127) out.append(' ');
            else out.append(c);
        }
        return out.toString();
    }

    private static String safe(String s) { return s == null ? "" : s; }

    private static long safeEnd(long begin) {
        return begin <= Long.MAX_VALUE - DURATION_MILLIS ? begin + DURATION_MILLIS : begin;
    }

    private static String dateUtc(long millis) {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd'T'HHmmss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(millis));
    }

    private static String dateLocal(long millis) {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd'T'HHmmss", Locale.US);
        f.setTimeZone(TimeZone.getDefault());
        return f.format(new Date(millis));
    }

    /** Every physical content line, including continuation lines, is at most 75 UTF-8 bytes. */
    static void line(StringBuilder out, String content) {
        int bytes = 0;
        for (int i = 0; i < content.length();) {
            int cp = content.codePointAt(i);
            String symbol = new String(Character.toChars(cp));
            int size = symbol.getBytes(StandardCharsets.UTF_8).length;
            if (bytes + size > 75) {
                out.append("\r\n ");
                bytes = 1;
            }
            out.append(symbol);
            bytes += size;
            i += Character.charCount(cp);
        }
        out.append("\r\n");
    }
}
