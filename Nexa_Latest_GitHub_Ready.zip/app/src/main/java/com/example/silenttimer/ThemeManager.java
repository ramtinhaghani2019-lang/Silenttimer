package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Nexa downloadable theme engine.
 * Theme packs are data-only: JSON + image assets. No executable code is loaded from a theme pack.
 */
public final class ThemeManager {
    private ThemeManager() {}
    private static final String PREF="nexa_theme_store_v2";
    private static final String KEY_ACTIVE="active";
    private static final String KEY_INSTALLED="installed";
    public static final String BASE="graphite_teal";
    private static final int MAX_DOWNLOADS=2;

    public static final class ThemeMeta {
        public final String id,name,subtitle,url;
        public final int accent;
        public ThemeMeta(String id,String name,String subtitle,String url,int accent){this.id=id;this.name=name;this.subtitle=subtitle;this.url=url;this.accent=accent;}
    }

    public static List<ThemeMeta> catalog(){
        String base="https://github.com/ramtinhaghani2019-lang/Silenttimer/releases/download/nexa-themes-v1/";
        return Arrays.asList(
            new ThemeMeta(BASE,"Graphite Teal","تیره سازمانی • فیروزه‌ای", "",0xFF22D3C5),
            new ThemeMeta("pastel_coral","Pastel Coral","روشن • مرجانی، آبی و سبز",base+"theme_pastel_coral.zip",0xFFFF6255),
            new ThemeMeta("ice_glass","Ice Glass","شیشه‌ای روشن • آبی یخی",base+"theme_ice_glass.zip",0xFF2F7CF6),
            new ThemeMeta("cosmic_neon","Cosmic Neon","تیره نئونی • آبی، بنفش و فیروزه‌ای",base+"theme_cosmic_neon.zip",0xFF7447FF),
            new ThemeMeta("holo_lilac","Holo Lilac","روشن هولوگرافیک • یاسی و آبی",base+"theme_holo_lilac.zip",0xFF8258F4),
            new ThemeMeta("copper_editorial","Copper Editorial","کرم، ذغالی و مسی",base+"theme_copper_editorial.zip",0xFFB86F47)
        );
    }

    public static ThemeMeta meta(String id){for(ThemeMeta m:catalog())if(m.id.equals(id))return m;return catalog().get(0);}
    private static SharedPreferences p(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public static String active(Context c){String x=p(c).getString(KEY_ACTIVE,BASE);return isInstalled(c,x)?x:BASE;}
    public static boolean isInstalled(Context c,String id){return BASE.equals(id)||installed(c).contains(id);}
    public static Set<String> installed(Context c){return new LinkedHashSet<>(p(c).getStringSet(KEY_INSTALLED,new LinkedHashSet<>()));}
    public static int downloadedCount(Context c){return installed(c).size();}
    public static int maxDownloads(){return MAX_DOWNLOADS;}
    public static boolean activate(Context c,String id){if(!isInstalled(c,id))return false;p(c).edit().putString(KEY_ACTIVE,id).apply();return true;}

    private static File root(Context c){File d=new File(c.getFilesDir(),"themes");if(!d.exists())d.mkdirs();return d;}
    private static File dir(Context c,String id){return new File(root(c),id);}
    private static void deleteRecursive(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[] kids=f.listFiles();if(kids!=null)for(File k:kids)deleteRecursive(k);}f.delete();}
    public static boolean uninstall(Context c,String id){
        if(BASE.equals(id)||active(c).equals(id))return false;
        Set<String>s=installed(c);if(!s.remove(id))return false;
        p(c).edit().putStringSet(KEY_INSTALLED,s).apply();deleteRecursive(dir(c,id));return true;
    }

    public interface DownloadCallback{void done(boolean ok,String message);}
    public static void download(Context c, ThemeMeta meta, DownloadCallback cb){
        new Thread(()->{
            boolean ok=false;String msg;
            File tmp=null;
            try{
                if(meta.url==null||meta.url.isEmpty())throw new IOException("این پوسته داخلی است.");
                if(!isInstalled(c,meta.id)&&downloadedCount(c)>=MAX_DOWNLOADS)throw new IOException("حداکثر ۲ پوسته دانلودی نگه‌داری می‌شود؛ ابتدا یک پوسته غیرفعال را حذف کن.");
                HttpURLConnection con=(HttpURLConnection)new URL(meta.url).openConnection();
                con.setConnectTimeout(20000);con.setReadTimeout(30000);con.setInstanceFollowRedirects(true);con.setRequestProperty("User-Agent","Nexa/5.4.2 ThemeStore");
                if(con.getResponseCode()/100!=2)throw new IOException("فایل پوسته در GitHub Release پیدا نشد یا اتصال برقرار نشد.");
                tmp=new File(root(c),".__"+meta.id+"_tmp");deleteRecursive(tmp);tmp.mkdirs();
                boolean hasJson=false;long total=0;
                try(ZipInputStream zin=new ZipInputStream(new BufferedInputStream(con.getInputStream()))){
                    ZipEntry e;byte[] buf=new byte[8192];
                    while((e=zin.getNextEntry())!=null){
                        String n=e.getName().replace('\\','/');
                        if(e.isDirectory())continue;
                        if(n.startsWith("/")||n.contains("../")||n.contains(":"))throw new IOException("ساختار بسته پوسته امن نیست.");
                        // Only known data asset types are accepted.
                        if(!(n.equals("theme.json")||n.endsWith(".png")||n.endsWith(".webp")||n.endsWith(".jpg")||n.endsWith(".jpeg")))continue;
                        File out=new File(tmp,n);String rootPath=tmp.getCanonicalPath()+File.separator;if(!out.getCanonicalPath().startsWith(rootPath))throw new IOException("مسیر فایل پوسته معتبر نیست.");
                        File par=out.getParentFile();if(par!=null)par.mkdirs();
                        try(FileOutputStream fos=new FileOutputStream(out)){int x;while((x=zin.read(buf))>0){fos.write(buf,0,x);total+=x;if(total>12L*1024L*1024L)throw new IOException("حجم پوسته بیش از حد مجاز است.");}}
                        if(n.equals("theme.json"))hasJson=true;
                    }
                }
                if(!hasJson)throw new IOException("theme.json داخل بسته پیدا نشد.");
                JSONObject o=readJson(new File(tmp,"theme.json"));
                if(!meta.id.equals(o.optString("id")))throw new IOException("شناسه پوسته معتبر نیست.");
                if(o.optInt("schema",0)<2)throw new IOException("این بسته برای Theme Engine جدید Nexa ساخته نشده است.");
                String bg=o.optString("background","");if(!bg.isEmpty()&&!new File(tmp,bg).isFile())throw new IOException("پس‌زمینه پوسته ناقص است.");
                String prev=o.optString("preview","");if(!prev.isEmpty()&&!new File(tmp,prev).isFile())throw new IOException("پیش‌نمایش پوسته ناقص است.");
                File finalDir=dir(c,meta.id);deleteRecursive(finalDir);if(!tmp.renameTo(finalDir))throw new IOException("ذخیره پوسته انجام نشد.");tmp=null;
                Set<String>s=installed(c);s.add(meta.id);p(c).edit().putStringSet(KEY_INSTALLED,s).apply();ok=true;msg="پوسته کامل دانلود و نصب شد ✓";
            }catch(Exception e){msg=e.getMessage()==null?"خطا در دانلود پوسته":e.getMessage();}
            finally{if(tmp!=null)deleteRecursive(tmp);}
            final boolean result=ok;final String text=msg;new android.os.Handler(android.os.Looper.getMainLooper()).post(()->cb.done(result,text));
        }).start();
    }

    private static JSONObject readJson(File f)throws Exception{ByteArrayOutputStream b=new ByteArrayOutputStream();try(FileInputStream in=new FileInputStream(f)){byte[]buf=new byte[4096];int n;while((n=in.read(buf))>0)b.write(buf,0,n);}return new JSONObject(new String(b.toByteArray(),"UTF-8"));}
    private static JSONObject load(Context c,String id){
        try{File f=new File(dir(c,id),"theme.json");if(f.isFile())return readJson(f);}catch(Exception ignored){}
        return builtIn(id);
    }
    private static JSONObject builtIn(String id){
        try{
            JSONObject o=new JSONObject();o.put("schema",2);o.put("id",id);
            if("pastel_coral".equals(id)){put(o,"#F9FBFF","#EEF6FF","#FFFFFF","#F8FAFF","#102044","#667085","#F2F5FA","#FF6255","#2386F5",false,"pastel",22,14,3,44,17.5,14.5);}
            else if("ice_glass".equals(id)){put(o,"#F4FAFF","#E8F2FF","#F8FCFF","#EEF7FF","#10274A","#697B94","#EDF5FC","#2F7CF6","#70C5FF",false,"glass",24,16,4,44,17.5,14.5);}
            else if("cosmic_neon".equals(id)){put(o,"#030914","#071428","#0B1830","#101D37","#F8FAFF","#AAB7CD","#111E38","#7447FF","#19D7E8",true,"neon",22,14,3,44,17.5,14.5);}
            else if("holo_lilac".equals(id)){put(o,"#FCFBFF","#F1EEFF","#FFFFFF","#F7F4FF","#1E1B4B","#777395","#F3F0FF","#8258F4","#62A9FF",false,"holo",24,16,4,44,17.5,14.5);}
            else if("copper_editorial".equals(id)){put(o,"#F7F1E8","#EFE6DA","#FBF7F1","#202823","#20211F","#766D64","#F0E7DB","#B86F47","#26332D",false,"editorial",22,14,3,44,17.5,14.5);}
            else {o.put("id",BASE);put(o,"#061012","#0A1719","#0E1C1F","#12272A","#F5FBFB","#A6B7B7","#102326","#18BFB2","#31D6E6",true,"graphite",22,14,3,44,17.5,14.5);}
            return o;
        }catch(Exception e){return new JSONObject();}
    }
    private static void put(JSONObject o,String bg1,String bg2,String card,String card2,String text,String muted,String field,String accent,String accent2,boolean dark,String style,int radius,int buttonRadius,int elevation,int buttonHeight,double title,double body)throws Exception{
        o.put("bg1",bg1);o.put("bg2",bg2);o.put("card",card);o.put("card2",card2);o.put("text",text);o.put("muted",muted);o.put("field",field);o.put("accent",accent);o.put("accent2",accent2);o.put("dark",dark);o.put("style",style);o.put("cardRadius",radius);o.put("buttonRadius",buttonRadius);o.put("cardElevation",elevation);o.put("buttonHeight",buttonHeight);o.put("sectionTitleSize",title);o.put("bodySize",body);
    }

    public static int color(Context c,String key,int fallback){try{return Color.parseColor(load(c,active(c)).optString(key,String.format("#%06X",0xFFFFFF&fallback)));}catch(Exception e){return fallback;}}
    public static boolean dark(Context c){return load(c,active(c)).optBoolean("dark",true);}
    public static int integer(Context c,String key,int fallback){return load(c,active(c)).optInt(key,fallback);}
    public static float number(Context c,String key,float fallback){return (float)load(c,active(c)).optDouble(key,fallback);}
    public static String text(Context c,String key,String fallback){return load(c,active(c)).optString(key,fallback);}
    public static File asset(Context c,String key){try{String n=load(c,active(c)).optString(key,"");if(n.isEmpty()||BASE.equals(active(c)))return null;File f=new File(dir(c,active(c)),n);return f.isFile()?f:null;}catch(Exception e){return null;}}
    public static File previewFile(Context c,String id){try{File f=new File(dir(c,id),"theme.json");if(!f.isFile())return null;JSONObject o=readJson(f);String n=o.optString("preview","");if(n.isEmpty())return null;File x=new File(dir(c,id),n);return x.isFile()?x:null;}catch(Exception e){return null;}}
}
