package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Lightweight downloadable theme packs. Theme packs contain only JSON styling metadata, never executable code. */
public final class ThemeManager {
    private ThemeManager() {}
    private static final String PREF="nexa_theme_store_v1";
    private static final String KEY_ACTIVE="active";
    private static final String KEY_INSTALLED="installed";
    public static final String BASE="graphite_teal";

    public static final class ThemeMeta {
        public final String id,name,subtitle,url;
        public final int accent;
        public ThemeMeta(String id,String name,String subtitle,String url,int accent){this.id=id;this.name=name;this.subtitle=subtitle;this.url=url;this.accent=accent;}
    }

    public static List<ThemeMeta> catalog(){
        String base="https://github.com/ramtinhaghani2019-lang/Silenttimer/releases/download/nexa-themes-v1/";
        return Arrays.asList(
            new ThemeMeta(BASE,"Graphite Teal","تیره حرفه‌ای • فیروزه‌ای", "",0xFF22D3C5),
            new ThemeMeta("pastel_coral","Pastel Coral","روشن • مرجانی و آبی",base+"theme_pastel_coral.zip",0xFFFF6F61),
            new ThemeMeta("ice_glass","Ice Glass","شیشه‌ای روشن • آبی یخی",base+"theme_ice_glass.zip",0xFF3B82F6),
            new ThemeMeta("cosmic_neon","Cosmic Neon","تیره نئونی • آبی و بنفش",base+"theme_cosmic_neon.zip",0xFF7C3AED),
            new ThemeMeta("holo_lilac","Holo Lilac","روشن هولوگرافیک • یاسی",base+"theme_holo_lilac.zip",0xFF8B5CF6),
            new ThemeMeta("copper_editorial","Copper Editorial","کرم و ذغالی • مسی",base+"theme_copper_editorial.zip",0xFFB76E4A)
        );
    }

    public static ThemeMeta meta(String id){for(ThemeMeta m:catalog())if(m.id.equals(id))return m;return catalog().get(0);}
    private static SharedPreferences p(Context c){return c.getSharedPreferences(PREF,Context.MODE_PRIVATE);}
    public static String active(Context c){String x=p(c).getString(KEY_ACTIVE,BASE);return isInstalled(c,x)?x:BASE;}
    public static boolean isInstalled(Context c,String id){return BASE.equals(id)||installed(c).contains(id);}
    public static Set<String> installed(Context c){return new LinkedHashSet<>(p(c).getStringSet(KEY_INSTALLED,new LinkedHashSet<>()));}
    public static int downloadedCount(Context c){return installed(c).size();}
    public static boolean activate(Context c,String id){if(!isInstalled(c,id))return false;p(c).edit().putString(KEY_ACTIVE,id).apply();return true;}
    public static boolean uninstall(Context c,String id){if(BASE.equals(id)||active(c).equals(id))return false;Set<String>s=installed(c);if(!s.remove(id))return false;p(c).edit().putStringSet(KEY_INSTALLED,s).apply();File f=new File(new File(c.getFilesDir(),"themes"),id+".json");if(f.exists())f.delete();return true;}

    public interface DownloadCallback{void done(boolean ok,String message);}
    public static void download(Context c, ThemeMeta meta, DownloadCallback cb){
        new Thread(()->{
            boolean ok=false;String msg;
            try{
                if(meta.url==null||meta.url.isEmpty())throw new IOException("این پوسته داخلی است.");
                if(!isInstalled(c,meta.id)&&downloadedCount(c)>=2)throw new IOException("حداکثر ۲ پوسته دانلودی نگه‌داری می‌شود؛ ابتدا یکی از پوسته‌های غیرفعال را حذف کن.");
                HttpURLConnection con=(HttpURLConnection)new URL(meta.url).openConnection();con.setConnectTimeout(15000);con.setReadTimeout(20000);con.setRequestProperty("User-Agent","Nexa/5.4.2");
                if(con.getResponseCode()/100!=2)throw new IOException("دانلود پوسته در GitHub آماده نیست یا اتصال برقرار نشد.");
                byte[] json=null;try(ZipInputStream zin=new ZipInputStream(con.getInputStream())){ZipEntry e;while((e=zin.getNextEntry())!=null){if("theme.json".equals(e.getName())){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[]buf=new byte[4096];int n;while((n=zin.read(buf))>0)b.write(buf,0,n);json=b.toByteArray();break;}}}
                if(json==null)throw new IOException("theme.json داخل بسته پیدا نشد.");
                JSONObject o=new JSONObject(new String(json,"UTF-8"));if(!meta.id.equals(o.optString("id")))throw new IOException("شناسه پوسته معتبر نیست.");
                File dir=new File(c.getFilesDir(),"themes");if(!dir.exists())dir.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(dir,meta.id+".json"))){out.write(json);}Set<String>s=installed(c);s.add(meta.id);p(c).edit().putStringSet(KEY_INSTALLED,s).apply();ok=true;msg="پوسته دانلود شد ✓";
            }catch(Exception e){msg=e.getMessage()==null?"خطا در دانلود پوسته":e.getMessage();}
            final boolean result=ok;final String text=msg;new android.os.Handler(android.os.Looper.getMainLooper()).post(()->cb.done(result,text));
        }).start();
    }

    private static JSONObject load(Context c,String id){
        try{
            File f=new File(new File(c.getFilesDir(),"themes"),id+".json");if(!f.exists())return builtIn(id);
            byte[] d=new byte[(int)f.length()];try(FileInputStream in=new FileInputStream(f)){int off=0,n;while((n=in.read(d,off,d.length-off))>0)off+=n;}
            return new JSONObject(new String(d,"UTF-8"));
        }catch(Exception e){return builtIn(id);}
    }
    private static JSONObject builtIn(String id){
        try{
            // All six definitions are kept here as safe fallbacks; remote packs can refine them without shipping executable code.
            JSONObject o=new JSONObject();o.put("id",id);
            if("pastel_coral".equals(id)){o.put("bg1","#F7FAFF");o.put("bg2","#EEF6FF");o.put("card","#FFFFFF");o.put("text","#102044");o.put("muted","#667085");o.put("field","#F3F6FA");o.put("accent","#FF6F61");o.put("accent2","#2F80ED");o.put("dark",false);}
            else if("ice_glass".equals(id)){o.put("bg1","#F4FAFF");o.put("bg2","#EAF4FF");o.put("card","#F8FCFF");o.put("text","#0F2747");o.put("muted","#6A7D95");o.put("field","#EDF5FC");o.put("accent","#3B82F6");o.put("accent2","#7DD3FC");o.put("dark",false);}
            else if("cosmic_neon".equals(id)){o.put("bg1","#050816");o.put("bg2","#071326");o.put("card","#0E1730");o.put("text","#F7FAFF");o.put("muted","#A7B0C7");o.put("field","#111B35");o.put("accent","#7C3AED");o.put("accent2","#22D3EE");o.put("dark",true);}
            else if("holo_lilac".equals(id)){o.put("bg1","#FBFAFF");o.put("bg2","#F1EEFF");o.put("card","#FFFFFF");o.put("text","#1E1B4B");o.put("muted","#7C789A");o.put("field","#F4F1FF");o.put("accent","#8B5CF6");o.put("accent2","#60A5FA");o.put("dark",false);}
            else if("copper_editorial".equals(id)){o.put("bg1","#F7F1E8");o.put("bg2","#EEE5D8");o.put("card","#FBF7F1");o.put("text","#20211F");o.put("muted","#756E67");o.put("field","#F1E9DE");o.put("accent","#B76E4A");o.put("accent2","#26332D");o.put("dark",false);}
            else {o.put("id",BASE);o.put("bg1","#071113");o.put("bg2","#0A1719");o.put("card","#102023");o.put("text","#F5FBFB");o.put("muted","#A6B7B7");o.put("field","#12272A");o.put("accent","#14B8A6");o.put("accent2","#22D3EE");o.put("dark",true);}
            return o;
        }catch(Exception e){return new JSONObject();}
    }
    public static int color(Context c,String key,int fallback){try{return Color.parseColor(load(c,active(c)).optString(key,String.format("#%06X",0xFFFFFF&fallback)));}catch(Exception e){return fallback;}}
    public static boolean dark(Context c){return load(c,active(c)).optBoolean("dark",true);}
}
