package com.example.silenttimer;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

/**
 * Lock-screen surface for missed calls. It is opened by the missed-call
 * full-screen notification when Android allows full-screen intents. When the
 * platform blocks full-screen intents, the same notification remains visible
 * as a high-priority public lock-screen notification.
 */
public class MissedCallLockActivity extends Activity {
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_TEXT = "text";
    public static final String EXTRA_NUMBER = "number";

    private static final long AUTO_CLOSE_MS = 12_000L;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable autoClose = () -> { if (!isFinishing()) finish(); };
    private String number = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        } else {
            getWindow().addFlags(
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                            | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
                            | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        // Do not KEEP_SCREEN_ON: the card may wake the screen, but must never defeat the phone timeout.
        UiKit.applyWindow(this);
        render(getIntent());
        // Wake only for presentation. Do not keep requesting screen-on after the card is visible.
        handler.postDelayed(() -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) setTurnScreenOn(false);
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON);
        }, 750L);
        scheduleAutoClose();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        render(intent);
        scheduleAutoClose();
    }

    private void render(Intent intent) {
        String title = intent == null ? "" : intent.getStringExtra(EXTRA_TITLE);
        String text = intent == null ? "" : intent.getStringExtra(EXTRA_TEXT);
        number = intent == null ? "" : intent.getStringExtra(EXTRA_NUMBER);
        if (title == null || title.trim().isEmpty()) title = "📞 تماس از دست‌رفته";
        if (text == null || text.trim().isEmpty()) text = "تماس پاسخ داده نشد";
        if (number == null) number = "";

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setGravity(Gravity.CENTER);
        screen.setPadding(UiKit.dp(this, 24), UiKit.dp(this, 36), UiKit.dp(this, 24), UiKit.dp(this, 36));
        screen.setBackground(UiKit.screenBackground(this));
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout card = UiKit.cardLayout(this);
        card.setPadding(UiKit.dp(this, 22), UiKit.dp(this, 24), UiKit.dp(this, 22), UiKit.dp(this, 24));

        TextView icon = UiKit.title(this, "📞");
        icon.setTextSize(42f);
        icon.setGravity(Gravity.CENTER);
        card.addView(icon, UiKit.matchWrap(this, 0, 8));

        TextView titleView = UiKit.title(this, title);
        titleView.setGravity(Gravity.CENTER);
        card.addView(titleView, UiKit.matchWrap(this, 0, 12));

        TextView textView = UiKit.sectionTitle(this, text);
        textView.setGravity(Gravity.CENTER);
        textView.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        card.addView(textView, UiKit.matchWrap(this, 0, 20));

        if (!number.trim().isEmpty()) {
            Button call = UiKit.primaryButton(this, "تماس");
            call.setOnClickListener(v -> callBack());
            card.addView(call, UiKit.matchWrap(this, 0, 10));
        }

        Button dismiss = UiKit.secondaryButton(this, "بستن");
        dismiss.setOnClickListener(v -> closeCard());
        card.addView(dismiss);

        screen.addView(new Space(this), new LinearLayout.LayoutParams(1, 0, 1f));
        screen.addView(card, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        screen.addView(new Space(this), new LinearLayout.LayoutParams(1, 0, 1f));
        setContentView(screen);
    }

    private void scheduleAutoClose() {
        handler.removeCallbacks(autoClose);
        handler.postDelayed(autoClose, AUTO_CLOSE_MS);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(autoClose);
        super.onDestroy();
    }

    private void callBack() {
        clearNotificationState();
        Intent dial = new Intent(Intent.ACTION_DIAL);
        if (!number.trim().isEmpty()) {
            dial.setData(Uri.fromParts("tel", number.trim(), null));
        }
        try {
            startActivity(dial);
        } catch (Exception ignored) {
        }
        finish();
    }

    private void closeCard() {
        clearNotificationState();
        finish();
    }

    private void clearNotificationState() {
        MissedCallGuard.resetMissedCount(this);
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
    }

    @Override
    public void onBackPressed() {
        closeCard();
    }
}
