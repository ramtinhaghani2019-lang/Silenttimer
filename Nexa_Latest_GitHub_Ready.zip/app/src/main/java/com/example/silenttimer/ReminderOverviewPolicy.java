package com.example.silenttimer;

import java.util.List;

/** Pure, read-only reminder overview for the compact, accessible directory. */
public final class ReminderOverviewPolicy {
    private ReminderOverviewPolicy() {}

    public static final class Counts {
        public final int pending, overdue, paused, completed;
        Counts(int p,int o,int a,int c){pending=p;overdue=o;paused=a;completed=c;}
    }

    public static Counts count(List<NexaStore.Reminder> reminders,long now){
        int pending=0,overdue=0,paused=0,completed=0;
        if(reminders!=null)for(NexaStore.Reminder r:reminders){
            if(r==null)continue;
            if(r.done)completed++;
            else if(!r.active)paused++;
            else if(ReminderOrganizer.effectiveDue(r,now)<now)overdue++;
            else pending++;
        }
        return new Counts(pending,overdue,paused,completed);
    }

    /** Keeps the actionable counts readable even when the expanded tiles are hidden. */
    public static String toggleLabel(Counts c,boolean expanded){
        if(c==null)c=new Counts(0,0,0,0);
        return (expanded?"▴ بستن آمار":"▾ مشاهده آمار")+" · "+c.pending+" در انتظار · "+c.overdue+" معوق";
    }
    public static String toggleDescription(Counts c,boolean expanded){
        if(c==null)c=new Counts(0,0,0,0);
        return (expanded?"بستن آمار":"نمایش آمار")+" یادآورها؛ "+c.pending+" در انتظار، "+c.overdue+
                " معوق، "+c.paused+" متوقف و "+c.completed+" انجام‌شده";
    }
}
