package com.example.silenttimer;

import android.content.Context;

/** Pure density-aware layout decision for quick entry. No storage or alarms. */
final class QuickAddLayoutPolicy {
    private QuickAddLayoutPolicy(){}
    static boolean shouldStack(float widthDp,float fontScale){
        return widthDp<390f || fontScale>=1.20f;
    }
    static boolean stack(Context context){
        float density=context.getResources().getDisplayMetrics().density;
        float widthDp=context.getResources().getDisplayMetrics().widthPixels/Math.max(0.1f,density);
        return shouldStack(widthDp,context.getResources().getConfiguration().fontScale);
    }
}
