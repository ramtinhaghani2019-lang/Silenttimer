package com.example.silenttimer;

import java.util.Calendar;

/** Read-only day-window policy shared by the home dashboard and Today's agenda.
 * It never rewrites alarms, saved dates, recurrence rules or completion data.
 */
public final class AgendaDuePolicy {
    private AgendaDuePolicy() { }

    public static final int OUTSIDE=-1;
    public static final int OVERDUE=0;
    public static final int TODAY=1;
    public static final int COMPLETED=2;
    public static final int TOMORROW=3;
    public static final int LATER_THIS_WEEK=4;

    public static long startOfDay(long millis) {
        Calendar calendar=Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        calendar.set(Calendar.HOUR_OF_DAY,0);
        calendar.set(Calendar.MINUTE,0);
        calendar.set(Calendar.SECOND,0);
        calendar.set(Calendar.MILLISECOND,0);
        return calendar.getTimeInMillis();
    }

    /** Use wall-clock days, not 24-hour milliseconds (DST is not always 24h). */
    public static long afterCalendarDays(long startOfDay,int days) {
        Calendar calendar=Calendar.getInstance();
        calendar.setTimeInMillis(startOfDay);
        calendar.add(Calendar.DAY_OF_YEAR,days);
        return calendar.getTimeInMillis();
    }

    /** Pick the recurrence on/after today's midnight, not one skipped after now.
     * This allows today's missed occurrence to appear as overdue until midnight,
     * without repeatedly showing old occurrences from months ago as overdue.
     */
    public static long shownDue(long storedDue,String recurrence,long todayStart) {
        if(storedDue<=0)return 0;
        if(!ReminderRecurrence.isRecurring(recurrence))return storedDue;
        return ReminderRecurrence.next(storedDue,recurrence,todayStart-1L);
    }

    public static boolean overdueForAttention(long storedDue,String recurrence,long now) {
        long shown=shownDue(storedDue,recurrence,startOfDay(now));
        return shown>0 && shown<now;
    }

    /** A paused reminder is not completed and is not an actionable deadline. */
    public static boolean includeReminder(boolean active,boolean done) {
        return active||done;
    }

    /** Exclusive end boundaries ensure an event occurs in just one section. */
    public static int bucket(long at,boolean done,long start,long tomorrowStart,
                             long dayAfterTomorrowStart,long endOfWeek) {
        if(at<=0)return OUTSIDE;
        if(done)return at>=start && at<tomorrowStart?COMPLETED:OUTSIDE;
        if(at<start)return OVERDUE;
        if(at<tomorrowStart)return TODAY;
        if(at<dayAfterTomorrowStart)return TOMORROW;
        return at<endOfWeek?LATER_THIS_WEEK:OUTSIDE;
    }
}
