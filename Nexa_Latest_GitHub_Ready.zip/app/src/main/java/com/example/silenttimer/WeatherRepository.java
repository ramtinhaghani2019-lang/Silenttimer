package com.example.silenttimer;

import android.content.Context;
import org.json.*;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.*;

public final class WeatherRepository {
    private WeatherRepository(){}
    public static final long FRESH_MS=15*60*1000L;
    public static class Hazard { public String type="",time=""; public int probability; public double value; }
    public static class Data { public String city="",source="",summary=""; public double lat,lon,temp,feels,wind,humidity,min,max; public int code,precip; public long updatedAt; public ArrayList<Hazard> hazards=new ArrayList<>(); }
    public interface Callback{void done(Data d,String error);}
    /** Only show offline forecasts for the location the user requested. */
    public static boolean matchesCity(Data data,String requested) {
        return data!=null && requested!=null
                && data.city!=null && data.city.trim().equalsIgnoreCase(requested.trim());
    }
    /** Reject forecasts with missing timestamps or from a future clock skew. */
    public static boolean usableCache(Data data,long now) {
        return data!=null && data.updatedAt>0 && data.updatedAt<=now+60000L;
    }
    public static void fetch(Context c,String city,Callback cb){new Thread(()->{Data d=null;String err=null;try{double[] ll=geocode(city);d=openMeteo(city,ll[0],ll[1]);}catch(Exception first){try{double[] ll=geocode(city);d=metNo(city,ll[0],ll[1]);}catch(Exception second){err=second.getMessage();}} if(d!=null)saveIfCurrentCity(c,d);Data out=d;String e=err;new android.os.Handler(android.os.Looper.getMainLooper()).post(()->cb.done(out,e));}).start();}
    private static double[] geocode(String city)throws Exception{String u="https://geocoding-api.open-meteo.com/v1/search?count=1&language=fa&format=json&name="+URLEncoder.encode(city,"UTF-8");JSONObject j=json(u,null);JSONArray a=j.optJSONArray("results");if(a==null||a.length()==0)throw new IOException("شهر یا محله پیدا نشد");JSONObject x=a.getJSONObject(0);return new double[]{x.getDouble("latitude"),x.getDouble("longitude")};}
    private static Data openMeteo(String city,double lat,double lon)throws Exception{
        String u="https://api.open-meteo.com/v1/forecast?latitude="+lat+"&longitude="+lon+"&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m&hourly=weather_code,precipitation_probability,wind_gusts_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&forecast_days=3&timezone=auto";
        JSONObject j=json(u,null),cur=j.getJSONObject("current"),day=j.getJSONObject("daily");Data d=new Data();d.city=city;d.lat=lat;d.lon=lon;d.temp=cur.optDouble("temperature_2m");d.feels=cur.optDouble("apparent_temperature");d.humidity=cur.optDouble("relative_humidity_2m");d.code=cur.optInt("weather_code");d.wind=cur.optDouble("wind_speed_10m");d.max=day.getJSONArray("temperature_2m_max").optDouble(0);d.min=day.getJSONArray("temperature_2m_min").optDouble(0);d.precip=day.getJSONArray("precipitation_probability_max").optInt(0);d.source="Open-Meteo";d.summary=label(d.code);d.updatedAt=System.currentTimeMillis();
        JSONObject h=j.optJSONObject("hourly"); if(h!=null){JSONArray times=h.optJSONArray("time"),codes=h.optJSONArray("weather_code"),probs=h.optJSONArray("precipitation_probability"),gusts=h.optJSONArray("wind_gusts_10m");int n=times==null?0:Math.min(times.length(),36);for(int i=0;i<n;i++){String tm=times.optString(i);int code=codes==null?0:codes.optInt(i);int p=probs==null?0:probs.optInt(i);double g=gusts==null?0:gusts.optDouble(i);String type=null;if(code==96||code==99)type="hail";else if(code>=71&&code<=77)type="snow";else if((code>=51&&code<=67)||(code>=80&&code<=82)||code>=95)type="rain";if(type!=null&&p>=20)addHazard(d,type,tm,p,0);if(g>=50)addHazard(d,"wind",tm,0,g);}}
        return d;
    }
    private static void addHazard(Data d,String type,String time,int p,double value){Hazard z=new Hazard();z.type=type;z.time=time.length()>=16?time.substring(11,16):time;z.probability=p;z.value=value;d.hazards.add(z);}
    private static Data metNo(String city,double lat,double lon)throws Exception{String u="https://api.met.no/weatherapi/locationforecast/2.0/compact?lat="+lat+"&lon="+lon;JSONObject j=json(u,"Nexa/5.4 weather client");JSONObject ts=j.getJSONObject("properties").getJSONArray("timeseries").getJSONObject(0).getJSONObject("data");JSONObject det=ts.getJSONObject("instant").getJSONObject("details");Data d=new Data();d.city=city;d.lat=lat;d.lon=lon;d.temp=det.optDouble("air_temperature");d.feels=d.temp;d.humidity=det.optDouble("relative_humidity");d.wind=det.optDouble("wind_speed")*3.6;d.source="MET Norway";d.summary="وضعیت فعلی";d.updatedAt=System.currentTimeMillis();return d;}
    private static JSONObject json(String url,String agent)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(url).openConnection();h.setConnectTimeout(8000);h.setReadTimeout(10000);h.setRequestProperty("Accept","application/json");if(agent!=null)h.setRequestProperty("User-Agent",agent);int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream(),StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();String s;while((s=r.readLine())!=null&&b.length()<500000)b.append(s);r.close();return new JSONObject(b.toString());}
    public static String label(int c){if(c==0)return "صاف";if(c<=3)return "نیمه‌ابری";if(c==45||c==48)return "مه";if(c>=51&&c<=67)return "بارانی";if(c>=71&&c<=77)return "برفی";if(c>=80&&c<=82)return "رگبار";if(c>=95)return "رعدوبرق";return "متغیر";}
    /** Do not allow a delayed weather response to overwrite a newer city selection. */
    public static boolean shouldSaveResult(String selectedCity,Data result) {
        return matchesCity(result,selectedCity) && !selectedCity.trim().isEmpty();
    }
    public static void saveIfCurrentCity(Context c,Data d) {
        if(c!=null && shouldSaveResult(savedCity(c),d)) save(c,d);
    }
    public static void save(Context c,Data d){try{JSONObject j=new JSONObject();j.put("city",d.city);j.put("source",d.source);j.put("summary",d.summary);j.put("lat",d.lat);j.put("lon",d.lon);j.put("temp",d.temp);j.put("feels",d.feels);j.put("humidity",d.humidity);j.put("wind",d.wind);j.put("min",d.min);j.put("max",d.max);j.put("precip",d.precip);j.put("code",d.code);j.put("updated",d.updatedAt);JSONArray hs=new JSONArray();for(Hazard z:d.hazards){JSONObject x=new JSONObject();x.put("type",z.type);x.put("time",z.time);x.put("probability",z.probability);x.put("value",z.value);hs.put(x);}j.put("hazards",hs);c.getSharedPreferences("nexa_weather",0).edit().putString("last",j.toString()).putString("city",d.city).apply();}catch(Exception ignored){}}
    public static Data cached(Context c){try{String s=c.getSharedPreferences("nexa_weather",0).getString("last","");if(s.isEmpty())return null;JSONObject j=new JSONObject(s);Data d=new Data();d.city=j.optString("city");d.source=j.optString("source");d.summary=j.optString("summary");d.lat=j.optDouble("lat");d.lon=j.optDouble("lon");d.temp=j.optDouble("temp");d.feels=j.optDouble("feels");d.humidity=j.optDouble("humidity");d.wind=j.optDouble("wind");d.min=j.optDouble("min");d.max=j.optDouble("max");d.precip=j.optInt("precip");d.code=j.optInt("code");d.updatedAt=j.optLong("updated");JSONArray hs=j.optJSONArray("hazards");if(hs!=null)for(int i=0;i<hs.length();i++){JSONObject x=hs.optJSONObject(i);if(x!=null){Hazard z=new Hazard();z.type=x.optString("type");z.time=x.optString("time");z.probability=x.optInt("probability");z.value=x.optDouble("value");d.hazards.add(z);}}return d;}catch(Exception e){return null;}}
    public static void saveCityOnly(Context c,String city){if(c!=null&&city!=null&&!city.trim().isEmpty())c.getSharedPreferences("nexa_weather",0).edit().putString("city",city.trim()).apply();}
    public static String savedCity(Context c){return c.getSharedPreferences("nexa_weather",0).getString("city","");}
    public static ArrayList<String> savedPlaces(Context c){ArrayList<String> out=new ArrayList<>();String raw=c.getSharedPreferences("nexa_weather",0).getString("places","");for(String s:raw.split("\\|"))if(!s.trim().isEmpty())out.add(s.trim());return out;}
    public static void addPlace(Context c,String place){place=place==null?"":place.trim();if(place.isEmpty())return;ArrayList<String> a=savedPlaces(c);if(!a.contains(place))a.add(place);StringBuilder b=new StringBuilder();for(String s:a){if(b.length()>0)b.append('|');b.append(s);}c.getSharedPreferences("nexa_weather",0).edit().putString("places",b.toString()).apply();}
    public static void removePlace(Context c,String place){ArrayList<String>a=savedPlaces(c);a.remove(place);StringBuilder b=new StringBuilder();for(String s:a){if(b.length()>0)b.append('|');b.append(s);}c.getSharedPreferences("nexa_weather",0).edit().putString("places",b.toString()).apply();}
}
