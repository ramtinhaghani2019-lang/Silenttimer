package com.example.silenttimer;

/** Presentation limits only. Does not change recurrence, alarm deadlines or stored events. */
public final class TodayPresentationPolicy {
    private TodayPresentationPolicy() {}
    public static final int PAGE_SIZE=8;
    /** Inclusive of zero displayed, exclusive end index. */
    public static int nextVisibleCount(int total,int displayed){
        int safeTotal=Math.max(0,total);
        int safeShown=Math.max(0,Math.min(safeTotal,displayed));
        return (int)Math.min((long)safeTotal,(long)safeShown+PAGE_SIZE);
    }
}
