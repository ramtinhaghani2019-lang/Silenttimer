package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class OccasionDismissReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c,Intent i){
        if(i==null)return;
        String owner=i.getStringExtra("owner");if(owner==null||!owner.startsWith("nexa:occasion:"))return;
        NexaAudioController.stopOwner(owner);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)nm.cancel(i.getIntExtra("notificationId",0));
    }
}
