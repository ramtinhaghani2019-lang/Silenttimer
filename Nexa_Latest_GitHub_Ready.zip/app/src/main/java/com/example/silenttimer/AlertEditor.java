package com.example.silenttimer;

import android.app.AlertDialog;
import android.app.Activity;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Human friendly reusable alert editor. Internal rule syntax never leaks into the UI. */
public final class AlertEditor {
    private final Activity c;
    private final LinearLayout rows;
    private final Spinner repeat;
    private final List<RuleRow> data=new ArrayList<>();
    private static final int[] MINUTES={0,5,10,15,30,60};
    private static final String[] OFFSET_LABELS={"زمان اصلی","۵ دقیقه قبل","۱۰ دقیقه قبل","۳۰ دقیقه قبل","۱ ساعت قبل","۱ روز قبل","۳ روز قبل","۷ روز قبل"};
    private static final int[] OFFSET_VALUES={0,5,10,30,60,1440,4320,10080};

    private static final class RuleRow { int minutes; int hour=-1,minute=-1; LinearLayout view; }

    public AlertEditor(Activity c,LinearLayout box,String initial,int repeatInitial){
        this.c=c;
        box.addView(UiKit.sectionTitle(c,"🔔 هشدارها"),UiKit.matchWrap(c,10,5));
        box.addView(UiKit.muted(c,"هشدارها را ساده اضافه کن؛ مثلاً «۱ روز قبل، ساعت ۹»."),UiKit.matchWrap(c,0,8));
        rows=new LinearLayout(c);rows.setOrientation(LinearLayout.VERTICAL);box.addView(rows);
        parse(initial);
        if(data.isEmpty())addRule(0,-1,-1);
        renderRows();
        Button add=UiKit.secondaryButton(c,"＋ افزودن هشدار");add.setOnClickListener(v->showAddDialog());box.addView(add,UiKit.matchWrap(c,4,8));
        repeat=UiKit.styledSpinner(c);
        ArrayAdapter<String>a=new ArrayAdapter<String>(c,android.R.layout.simple_spinner_item,Arrays.asList("تکرار نشود","هر ۵ دقیقه تا تأیید","هر ۱۰ دقیقه تا تأیید","هر ۱۵ دقیقه تا تأیید","هر ۳۰ دقیقه تا تأیید","هر ۶۰ دقیقه تا تأیید")){
            @Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);t.setPadding(UiKit.dp(c,12),UiKit.dp(c,12),UiKit.dp(c,12),UiKit.dp(c,12));return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);t.setPadding(UiKit.dp(c,14),UiKit.dp(c,12),UiKit.dp(c,14),UiKit.dp(c,12));return t;}
        };repeat.setAdapter(a);for(int i=0;i<MINUTES.length;i++)if(MINUTES[i]==repeatInitial)repeat.setSelection(i);
        box.addView(repeat,UiKit.matchWrap(c,0,8));
    }

    private void parse(String initial){
        for(String raw:AlertRules.split(initial==null?"":initial)){
            raw=raw.trim();if(raw.isEmpty())continue;
            try{
                if(raw.startsWith("D")&&raw.contains("@")){
                    int at=raw.indexOf('@');int days=Integer.parseInt(raw.substring(1,at));String[]hm=raw.substring(at+1).split(":");addRule(days*1440,Integer.parseInt(hm[0]),Integer.parseInt(hm[1]));
                }else addRule(Integer.parseInt(raw),-1,-1);
            }catch(Exception ignored){}
        }
    }
    private void addRule(int minutes,int h,int m){RuleRow r=new RuleRow();r.minutes=Math.max(0,minutes);r.hour=h;r.minute=m;data.add(r);}

    private String label(RuleRow r){
        if(r.minutes==0)return "زمان اصلی";
        String base;
        if(r.minutes%1440==0)base=(r.minutes/1440)+" روز قبل";
        else if(r.minutes%60==0)base=(r.minutes/60)+" ساعت قبل";
        else base=r.minutes+" دقیقه قبل";
        if(r.minutes>=1440&&r.hour>=0)return base+String.format(Locale.US," • ساعت %02d:%02d",r.hour,r.minute);
        return base;
    }

    private void renderRows(){
        rows.removeAllViews();
        for(RuleRow r:new ArrayList<>(data)){
            LinearLayout line=UiKit.cardLayout(c);line.setOrientation(LinearLayout.HORIZONTAL);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(UiKit.dp(c,12),UiKit.dp(c,8),UiKit.dp(c,12),UiKit.dp(c,8));
            TextView text=UiKit.sectionTitle(c,label(r));line.addView(text,new LinearLayout.LayoutParams(0,-2,1f));
            Button edit=UiKit.editIconButton(c);edit.setOnClickListener(v->editRule(r));line.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(c,48),UiKit.dp(c,48)));
            Button del=UiKit.deleteIconButton(c);del.setOnClickListener(v->{data.remove(r);renderRows();});line.addView(del,new LinearLayout.LayoutParams(UiKit.dp(c,48),UiKit.dp(c,48)));
            r.view=line;rows.addView(line,UiKit.matchWrap(c,0,5));
        }
        if(data.isEmpty()){TextView t=UiKit.muted(c,"هشداری تنظیم نشده.");t.setGravity(Gravity.CENTER);rows.addView(t,UiKit.matchWrap(c,4,6));}
    }

    private void showAddDialog(){
        Spinner s=offsetSpinner(0);new AlertDialog.Builder(c).setTitle("افزودن هشدار").setView(s).setPositiveButton("ادامه",(d,w)->{
            int pos=s.getSelectedItemPosition(),minutes=OFFSET_VALUES[pos];RuleRow r=new RuleRow();r.minutes=minutes;
            if(minutes>=1440)pickTime(r,true);else{data.add(r);renderRows();}
        }).setNegativeButton("انصراف",null).show();
    }

    private Spinner offsetSpinner(int current){
        Spinner s=UiKit.styledSpinner(c);ArrayAdapter<String>a=new ArrayAdapter<String>(c,android.R.layout.simple_spinner_item,OFFSET_LABELS){
            @Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);return t;}
        };s.setAdapter(a);int best=0;for(int i=0;i<OFFSET_VALUES.length;i++)if(OFFSET_VALUES[i]==current)best=i;s.setSelection(best);return s;
    }

    private void editRule(RuleRow r){
        Spinner s=offsetSpinner(r.minutes);new AlertDialog.Builder(c).setTitle("ویرایش هشدار").setView(s).setPositiveButton("ادامه",(d,w)->{r.minutes=OFFSET_VALUES[s.getSelectedItemPosition()];if(r.minutes>=1440)pickTime(r,false);else{r.hour=-1;r.minute=-1;renderRows();}}).setNegativeButton("انصراف",null).show();
    }

    private void pickTime(RuleRow r,boolean adding){
        int h=r.hour>=0?r.hour:9,m=r.minute>=0?r.minute:0;
        PersianDatePickerHelper.pickTime(c,h,m,"ساعت هشدار",(hh,mm)->{r.hour=hh;r.minute=mm;if(adding)data.add(r);renderRows();});
    }

    public String rules(){
        List<String>out=new ArrayList<>();for(RuleRow r:data){if(r.minutes>=1440&&r.minutes%1440==0&&r.hour>=0)out.add("D"+(r.minutes/1440)+String.format(Locale.US,"@%02d:%02d",r.hour,r.minute));else out.add(String.valueOf(r.minutes));}
        return android.text.TextUtils.join(",",out);
    }
    public int repeatMinutes(){return MINUTES[repeat.getSelectedItemPosition()];}
    public boolean valid(long due){for(String r:AlertRules.split(rules()))if(AlertRules.trigger(due,r)<=0)return false;return true;}
}
