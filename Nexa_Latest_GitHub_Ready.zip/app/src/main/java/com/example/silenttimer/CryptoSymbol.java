package com.example.silenttimer;
import java.util.Locale;
import java.util.Set;
/** Normalizes symbols without claiming any provider supports them. */
public final class CryptoSymbol {
 private CryptoSymbol() {}
 public static String normalize(String raw) {
  if(raw==null)return "";
  String value=raw.trim().toUpperCase(Locale.ROOT);
  return value.matches("[A-Z0-9]{2,15}")?value:"";
 }
 public static boolean isSupportedByProvider(String raw,Set<String> available) {
  String symbol=normalize(raw);
  return !symbol.isEmpty()&&available!=null&&available.contains(symbol);
 }
}
