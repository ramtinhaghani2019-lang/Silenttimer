package com.example.silenttimer;

import java.util.Calendar;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/** Safe, backward-compatible parsing of multiple independent reminder rules.
 * Legacy offsets are minutes before due. D3@09:00 is 3 calendar days before at 09:00.
 */
public final class AlertRules {
    private AlertRules(){}
    public static long trigger(long due,String rule){
        if(due<=0)return -1L;
        try{
            rule=rule.trim();
            if(rule.matches("D[0-9]{1,4}@[0-9]{1,2}:[0-9]{2}")){
                String[] parts=rule.substring(1).split("@");int days=Integer.parseInt(parts[0]);
                String[] clock=parts[1].split(":");int hour=Integer.parseInt(clock[0]),min=Integer.parseInt(clock[1]);
                if(hour>23||min>59)return -1L;
                Calendar c=Calendar.getInstance();c.setTimeInMillis(due);
                c.add(Calendar.DAY_OF_YEAR,-days);c.set(Calendar.HOUR_OF_DAY,hour);
                c.set(Calendar.MINUTE,min);c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
                return c.getTimeInMillis();
            }
            long offset=Long.parseLong(rule);
            if(offset<0||offset>52560000L)return -1L;
            return due-offset*60000L;
        }catch(Exception e){return -1L;}
    }
    public static List<String> split(String source){
        LinkedHashSet<String> out=new LinkedHashSet<>();
        if(source!=null)for(String part:source.split(",")){
            String p=part.trim();if(!p.isEmpty())out.add(p);
        }
        return new ArrayList<>(out);
    }
}
