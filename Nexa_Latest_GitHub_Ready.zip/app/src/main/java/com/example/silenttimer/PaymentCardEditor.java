package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputFilter;
import android.text.InputType;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import java.util.function.Consumer;

/** One reusable, validated destination-card form. */
public final class PaymentCardEditor {
    private PaymentCardEditor(){}
    public static void show(Activity activity,NexaStore.BankCard current,Consumer<NexaStore.BankCard> saved){
        LinearLayout body=UiKit.dialogPanel(activity);
        EditText owner=field(activity,"نام صاحب کارت / دریافت‌کننده");
        EditText bank=field(activity,"نام بانک");
        EditText label=field(activity,"عنوان دلخواه (اختیاری)");
        EditText number=field(activity,"شماره کارت ۱۶ رقمی مقصد");
        number.setInputType(InputType.TYPE_CLASS_NUMBER);
        number.setFilters(new InputFilter[]{new InputFilter.LengthFilter(23)});
        number.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_LTR);
        number.setTextDirection(android.view.View.TEXT_DIRECTION_LTR);
        if(current!=null){
            owner.setText(current.owner);bank.setText(current.bank);label.setText(current.label);
            number.setText(PaymentCardSecrets.load(activity,current.id));
        }
        body.addView(owner,UiKit.matchWrap(activity,0,6));
        body.addView(bank,UiKit.matchWrap(activity,0,6));
        body.addView(number,UiKit.matchWrap(activity,0,6));
        body.addView(label,UiKit.matchWrap(activity,0,6));
        body.addView(UiKit.muted(activity,"شماره کارت با رمزنگاری دستگاه ذخیره می‌شود؛ رمز دوم، CVV2 و تاریخ انقضا لازم نیست.\nکپی کارت فقط هنگام درخواست شما انجام می‌شود."));
        AlertDialog dialog=new AlertDialog.Builder(activity)
            .setTitle(current==null?"افزودن کارت مقصد":"ویرایش کارت مقصد")
            .setView(body).setPositiveButton("ذخیره",null).setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String name=owner.getText().toString().trim();
            String b=bank.getText().toString().trim();
            String raw=number.getText().toString().trim();
            if(name.isEmpty()){owner.setError("نام صاحب کارت را وارد کن");return;}
            if(b.isEmpty()){bank.setError("نام بانک را وارد کن");return;}
            // Previously saved last-four-only cards remain editable without data loss.
            if(!raw.isEmpty()&&!PaymentCardSecrets.isValid(raw)){
                number.setError("شماره کارت باید دقیقاً ۱۶ رقم باشد");return;
            }
            if(current==null && raw.isEmpty()){
                number.setError("شماره کارت مقصد را وارد کن");return;
            }
            NexaStore.BankCard c=current==null?new NexaStore.BankCard():current;
            if(!raw.isEmpty()&&!PaymentCardSecrets.save(activity,c.id,raw)){
                Toast.makeText(activity,"ذخیره امن شماره کارت ناموفق بود.",Toast.LENGTH_LONG).show();return;
            }
            c.owner=name;c.bank=b;c.label=label.getText().toString().trim();
            if(!raw.isEmpty())c.last4=PaymentCardSecrets.digits(raw).substring(12);
            NexaStore.upsertBankCard(activity,c);
            dialog.dismiss();if(saved!=null)saved.accept(c);
        }));
        dialog.show();
    }
    private static EditText field(Activity a,String hint){return UiKit.styleField(a,new EditText(a),hint);}
}
