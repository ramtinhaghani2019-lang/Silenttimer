package com.example.silenttimer;

/** Pure timer-session guard. A zero/negative end time means no owned timer,
 * even if the phone is currently in manual Silent/Vibrate mode. */
public final class TimerSessionGuard {
    private TimerSessionGuard() {}

    public static boolean hasSession(long memoryEndAt, long persistedEndAt) {
        return memoryEndAt > 0L || persistedEndAt > 0L;
    }
}
