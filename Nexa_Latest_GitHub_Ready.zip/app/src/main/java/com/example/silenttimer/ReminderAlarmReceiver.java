package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        String token = intent.getStringExtra("token");
        int repeat = intent.getIntExtra("repeat", 5);
        if (id == null || token == null || NexaStore.tokenDismissed(context, token)) return;

        NexaStore.Reminder reminder = NexaStore.reminder(context, id);
        if (reminder == null || !reminder.active || reminder.done) return;

        // One-shot reminders get a bounded sound-only retry while a call is active.
        // Existing repeating reminders already have their own scheduled follow-up.
        int callRetry = intent.getIntExtra("call_retry", 0);
        if (callRetry > 0) {
            if (repeat != 0 || NexaStore.tokenDismissed(context, token)) return;
            if (NexaAudioController.isCallAudioMode(context)) {
                if (shouldRetryCallAudio(repeat, callRetry))
                    ReminderScheduler.scheduleCallAudioRetry(context, id, token, callRetry + 1);
            } else {
                AlarmSoundPlayer.start(context, "reminder:" + token,
                        NexaAudioController.PRIORITY_REMINDER, NexaAudioController.SOUND_REMINDER);
            }
            return; // Never repost notification or duplicate reminder history.
        }

        // A receiver can occasionally be delivered twice in quick succession.
        // Keep one logical alarm delivery, while scheduled repeats minutes later still fire normally.
        if (!NexaNotificationEngine.acquireDelivery(context, "reminder:" + token)) return;

        if (NexaAudioController.isCallAudioMode(context) && repeat == 0)
            ReminderScheduler.scheduleCallAudioRetry(context, id, token, 1);
        else
            AlarmSoundPlayer.start(context, "reminder:" + token, NexaAudioController.PRIORITY_REMINDER, NexaAudioController.SOUND_REMINDER);

        Intent dismiss = new Intent(context, ReminderActionReceiver.class);
        dismiss.setAction("DISMISS");
        dismiss.putExtra("token", token);
        PendingIntent dismissPi = PendingIntent.getBroadcast(
                context,
                (token + "d").hashCode(),
                dismiss,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent done = new Intent(context, ReminderActionReceiver.class);
        done.setAction("DONE");
        done.putExtra("token", token);
        done.putExtra("id", id);
        PendingIntent donePi = PendingIntent.getBroadcast(
                context,
                (token + "done").hashCode(),
                done,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent snooze = new Intent(context, ReminderActionReceiver.class);
        snooze.setAction("SNOOZE");
        snooze.putExtra("token", token);
        snooze.putExtra("id", id);
        snooze.putExtra("repeat", repeat);
        PendingIntent snoozePi = PendingIntent.getBroadcast(
                context,
                (token + "s").hashCode(),
                snooze,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent open = new Intent(context, RemindersActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                context,
                token.hashCode(),
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent ring = new Intent(context, ReminderRingActivity.class);
        ring.putExtra("id", id);
        ring.putExtra("token", token);
        ring.putExtra("repeat", repeat);
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent ringPi = PendingIntent.getActivity(
                context,
                (token + "ring").hashCode(),
                ring,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NexaNotificationEngine.showReminderNotification(
                context,
                reminder,
                token,
                openPi,
                ringPi,
                donePi,
                dismissPi,
                snoozePi);

        NexaStore.addHistory(context, "یادآور", "هشدار: " + reminder.title);
        if (repeat > 0) {
            ReminderScheduler.scheduleToken(
                    context,
                    id,
                    token,
                    System.currentTimeMillis() + repeat * 60_000L,
                    repeat);
        }
        ReminderScheduler.updateLockCard(context);
    }
    /** A maximum of five sound-only retries, one minute apart. */
    public static boolean shouldRetryCallAudio(int repeatMinutes, int attempt) {
        return repeatMinutes == 0 && attempt >= 1 && attempt < 5;
    }

}
