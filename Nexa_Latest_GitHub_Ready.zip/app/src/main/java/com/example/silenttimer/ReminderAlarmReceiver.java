package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String id = intent.getStringExtra("id");
        String token = intent.getStringExtra("token");
        int repeat = intent.getIntExtra("repeat", 5);
        if (id == null || token == null || NexaStore.tokenDismissed(context, token)) return;

        NexaStore.Reminder reminder = NexaStore.reminder(context, id);
        if (reminder == null || !reminder.active) return;

        // A receiver can occasionally be delivered twice in quick succession.
        // Keep one logical alarm delivery, while scheduled repeats minutes later still fire normally.
        if (!NexaNotificationEngine.acquireDelivery(context, "reminder:" + token)) return;

        AlarmSoundPlayer.start(context, "reminder:" + token, NexaAudioController.PRIORITY_REMINDER, NexaAudioController.SOUND_REMINDER);

        Intent dismiss = new Intent(context, ReminderActionReceiver.class);
        dismiss.setAction("DISMISS");
        dismiss.putExtra("token", token);
        PendingIntent dismissPi = PendingIntent.getBroadcast(
                context,
                (token + "d").hashCode(),
                dismiss,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent snooze = new Intent(context, ReminderActionReceiver.class);
        snooze.setAction("SNOOZE");
        snooze.putExtra("token", token);
        snooze.putExtra("id", id);
        snooze.putExtra("repeat", repeat);
        PendingIntent snoozePi = PendingIntent.getBroadcast(
                context,
                (token + "s").hashCode(),
                snooze,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent open = new Intent(context, RemindersActivity.class);
        PendingIntent openPi = PendingIntent.getActivity(
                context,
                token.hashCode(),
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent ring = new Intent(context, ReminderRingActivity.class);
        ring.putExtra("id", id);
        ring.putExtra("token", token);
        ring.putExtra("repeat", repeat);
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent ringPi = PendingIntent.getActivity(
                context,
                (token + "ring").hashCode(),
                ring,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        NexaNotificationEngine.showReminderNotification(
                context,
                reminder,
                token,
                openPi,
                ringPi,
                dismissPi,
                snoozePi);

        NexaStore.addHistory(context, "یادآور", "هشدار: " + reminder.title);
        if (repeat > 0) {
            ReminderScheduler.scheduleToken(
                    context,
                    id,
                    token,
                    System.currentTimeMillis() + repeat * 60_000L,
                    repeat);
        }
        ReminderScheduler.updateLockCard(context);
    }
}
