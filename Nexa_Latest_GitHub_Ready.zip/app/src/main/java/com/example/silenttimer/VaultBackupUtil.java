package com.example.silenttimer;

import android.content.Context;
import android.util.Base64;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public final class VaultBackupUtil {
    private VaultBackupUtil(){}
    private static SecretKey key(String pass,byte[] salt)throws Exception{KeySpec spec=new PBEKeySpec(pass.toCharArray(),salt,150000,256);byte[] raw=SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();return new SecretKeySpec(raw,"AES");}
    public static String exportVault(Context c,String pass)throws Exception{
        if(pass==null||pass.length()<8)throw new IllegalArgumentException("pass");
        JSONArray arr=new JSONArray();
        for(NexaStore.VaultEntry x:NexaStore.vault(c)){
            JSONObject o=new JSONObject();o.put("id",x.id);o.put("type",x.type);o.put("title",x.title);
            o.put("username",VaultCrypto.decrypt(x.usernameEncrypted));o.put("secret",VaultCrypto.decrypt(x.secretEncrypted));o.put("note",VaultCrypto.decrypt(x.noteEncrypted));arr.put(o);
        }
        JSONObject plain=new JSONObject();plain.put("schema",1);plain.put("vault",arr);
        SecureRandom r=new SecureRandom();byte[] salt=new byte[16],iv=new byte[12];r.nextBytes(salt);r.nextBytes(iv);
        Cipher cp=Cipher.getInstance("AES/GCM/NoPadding");cp.init(Cipher.ENCRYPT_MODE,key(pass,salt),new GCMParameterSpec(128,iv));byte[] enc=cp.doFinal(plain.toString().getBytes(StandardCharsets.UTF_8));
        ByteBuffer bb=ByteBuffer.allocate(4+salt.length+4+iv.length+enc.length);bb.putInt(salt.length).put(salt).putInt(iv.length).put(iv).put(enc);
        JSONObject wrap=new JSONObject();wrap.put("type","NEXA_VAULT_BACKUP");wrap.put("v",1);wrap.put("data",Base64.encodeToString(bb.array(),Base64.NO_WRAP));return wrap.toString();
    }
    public static boolean importVault(Context c,String raw,String pass){try{
        JSONObject wrap=new JSONObject(raw);if(!"NEXA_VAULT_BACKUP".equals(wrap.optString("type")))return false;byte[] all=Base64.decode(wrap.getString("data"),Base64.NO_WRAP);ByteBuffer bb=ByteBuffer.wrap(all);int sl=bb.getInt();if(sl<12||sl>32)return false;byte[] salt=new byte[sl];bb.get(salt);int il=bb.getInt();if(il<12||il>16)return false;byte[] iv=new byte[il];bb.get(iv);byte[] enc=new byte[bb.remaining()];bb.get(enc);Cipher cp=Cipher.getInstance("AES/GCM/NoPadding");cp.init(Cipher.DECRYPT_MODE,key(pass,salt),new GCMParameterSpec(128,iv));String plain=new String(cp.doFinal(enc),StandardCharsets.UTF_8);JSONArray a=new JSONObject(plain).getJSONArray("vault");List<NexaStore.VaultEntry> out=new ArrayList<>();for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);NexaStore.VaultEntry x=new NexaStore.VaultEntry();x.id=o.optString("id",x.id);x.type=o.optString("type","عمومی");x.title=o.optString("title","");x.usernameEncrypted=VaultCrypto.encrypt(o.optString("username",""));x.secretEncrypted=VaultCrypto.encrypt(o.optString("secret",""));x.noteEncrypted=VaultCrypto.encrypt(o.optString("note",""));out.add(x);}NexaStore.replaceVault(c,out);return true;
    }catch(Exception e){return false;}}
}
