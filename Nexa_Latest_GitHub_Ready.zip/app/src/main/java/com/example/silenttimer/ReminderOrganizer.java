package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Pure reminder-dashboard rules: search, sorting and safe future deadlines. */
public final class ReminderOrganizer {
    private ReminderOrganizer() {}

    /** Persian and Arabic keyboard variants, digits and zero-width separators match. */
    static String normalized(String input) {
        if (input == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (c == 'ي' || c == 'ى') c = 'ی';
            else if (c == 'ك') c = 'ک';
            else if (c == 'ة' || c == 'ۀ') c = 'ه';
            else if (c == '\u200c' || c == '\u200f' || c == '\u200e') c = ' ';
            else if (c >= '۰' && c <= '۹') c = (char) ('0' + c - '۰');
            else if (c >= '٠' && c <= '٩') c = (char) ('0' + c - '٠');
            if ((c >= '\u064b' && c <= '\u065f') || c == '\u0670') continue;
            b.append(c);
        }
        return b.toString().toLowerCase(Locale.ROOT).trim().replaceAll("\\s+", " ");
    }

    public static boolean matches(NexaStore.Reminder r, String query) {
        if (r == null) return false;
        String wanted = normalized(query);
        if (wanted.isEmpty()) return true;
        String all = normalized(safe(r.title) + " " + safe(r.category) + " " + safe(r.note)
                + " " + safe(r.doctorName) + " " + safe(r.doctorCenter)
                + " " + safe(r.doctorPhone) + " " + safe(r.doctorAddress)
                + " " + safe(r.doctorFileNumber));
        for (String word : wanted.split(" ")) {
            if (!all.contains(word)) return false;
        }
        return true;
    }

    private static String safe(String s) { return s == null ? "" : s; }

    public static boolean visible(NexaStore.Reminder r, String filter, long now) {
        if (r == null) return false;
        if ("done".equals(filter)) return r.done;
        if ("paused".equals(filter)) return !r.done && !r.active;
        if ("overdue".equals(filter)) return !r.done && r.active && r.whenMillis < now;
        if ("pending".equals(filter)) return !r.done && r.active && r.whenMillis >= now;
        return true;
    }

    /** Smart ordering: overdue, pending, paused, completed. Other modes are explicit. */
    public static List<NexaStore.Reminder> ordered(List<NexaStore.Reminder> source,
                                                    String order, long now) {
        List<NexaStore.Reminder> out = new ArrayList<>();
        if (source == null) return out;
        for (NexaStore.Reminder r : source) if (r != null) out.add(r);
        Comparator<NexaStore.Reminder> cmp;
        if ("due".equals(order)) cmp = Comparator.comparingLong(r -> r.whenMillis);
        else if ("recent".equals(order)) cmp = (a,b) -> Long.compare(b.whenMillis,a.whenMillis);
        else if ("title".equals(order)) cmp = (a,b) -> normalized(a.title).compareTo(normalized(b.title));
        else cmp = (a,b) -> {
            int priority = Integer.compare(rank(a,now),rank(b,now));
            return priority != 0 ? priority : Long.compare(a.whenMillis,b.whenMillis);
        };
        out.sort(cmp.thenComparing(r -> safe(r.id)));
        return out;
    }

    private static int rank(NexaStore.Reminder r,long now) {
        if (r.done) return 3;
        if (!r.active) return 2;
        return r.whenMillis < now ? 0 : 1;
    }

    /** 15 minutes, one hour, or tomorrow at the reminder's previous wall-clock time. */
    public static long postponedUntil(long oldDue, long now, int selection) {
        if (selection == 0) return now + 15L * 60_000L;
        if (selection == 1) return now + 60L * 60_000L;
        if (selection != 2) throw new IllegalArgumentException("Unknown postpone option");
        Calendar old = Calendar.getInstance();
        old.setTimeInMillis(oldDue > 0 ? oldDue : now);
        Calendar next = Calendar.getInstance();
        next.setTimeInMillis(now);
        next.add(Calendar.DAY_OF_YEAR,1);
        next.set(Calendar.HOUR_OF_DAY,old.get(Calendar.HOUR_OF_DAY));
        next.set(Calendar.MINUTE,old.get(Calendar.MINUTE));
        next.set(Calendar.SECOND,0);
        next.set(Calendar.MILLISECOND,0);
        return next.getTimeInMillis();
    }

    /** Duplicating a very old reminder must still produce a future scheduled reminder. */
    public static long copiedDue(long oldDue, long now) {
        if (oldDue > now) {
            Calendar next = Calendar.getInstance();
            next.setTimeInMillis(oldDue);
            next.add(Calendar.DAY_OF_YEAR,1);
            return next.getTimeInMillis();
        }
        return postponedUntil(oldDue,now,2);
    }
}
