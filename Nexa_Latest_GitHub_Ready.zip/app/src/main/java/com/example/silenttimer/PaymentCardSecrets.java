package com.example.silenttimer;

import android.content.Context;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

/** Full card numbers are never written to ordinary Nexa JSON/backup or logging. */
public final class PaymentCardSecrets {
    private PaymentCardSecrets(){}
    private static final String ALIAS="nexa.payment_cards.v1";
    private static final String PREF="nexa_payment_card_ciphertexts";
    public static String digits(String value){
        StringBuilder result=new StringBuilder();
        if(value==null)return "";
        for(int i=0;i<value.length();i++){
            int d=Character.digit(value.charAt(i),10);
            if(d>=0)result.append((char)('0'+d));
            else if(!Character.isWhitespace(value.charAt(i))&&value.charAt(i)!='-')return "";
        }
        return result.toString();
    }
    public static boolean isValid(String value){return digits(value).matches("[0-9]{16}");}
    private static SecretKey key() throws Exception {
        KeyStore ks=KeyStore.getInstance("AndroidKeyStore");ks.load(null);
        java.security.Key k=ks.getKey(ALIAS,null);
        if(k instanceof SecretKey)return (SecretKey)k;
        KeyGenerator gen=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore");
        gen.init(new KeyGenParameterSpec.Builder(ALIAS,
            KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256).build());
        return gen.generateKey();
    }
    public static boolean save(Context context,String id,String number){
        if(id==null||id.isEmpty()||!isValid(number))return false;
        try {
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE,key());
            byte[] encrypted=cipher.doFinal(digits(number).getBytes(StandardCharsets.US_ASCII));
            byte[] nonce=cipher.getIV();
            byte[] data=new byte[nonce.length+encrypted.length];
            System.arraycopy(nonce,0,data,0,nonce.length);
            System.arraycopy(encrypted,0,data,nonce.length,encrypted.length);
            return context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit()
                .putString(id,Base64.encodeToString(data,Base64.NO_WRAP)).commit();
        }catch(Exception e){return false;}
    }
    public static String load(Context context,String id){
        if(id==null||id.isEmpty())return "";
        try {
            String raw=context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(id,"");
            if(raw.isEmpty())return "";
            byte[] data=Base64.decode(raw,Base64.DEFAULT);
            if(data.length<29)return "";
            Cipher cipher=Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE,key(),new GCMParameterSpec(128,data,0,12));
            return new String(cipher.doFinal(data,12,data.length-12),StandardCharsets.US_ASCII);
        }catch(Exception e){return "";}
    }
    public static void delete(Context context,String id){
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().remove(id).apply();
    }
    public static boolean copy(Context context,String id){
        String number=load(context,id);
        if(!isValid(number))return false;
        ClipboardManager cm=(ClipboardManager)context.getSystemService(Context.CLIPBOARD_SERVICE);
        if(cm==null)return false;
        ClipData clip=ClipData.newPlainText("شماره کارت مقصد",number);
        if(android.os.Build.VERSION.SDK_INT>=33){
            android.os.PersistableBundle opts=new android.os.PersistableBundle();
            opts.putBoolean("android.content.extra.IS_SENSITIVE",true);
            clip.getDescription().setExtras(opts);
        }
        cm.setPrimaryClip(clip);
        return true;
    }
    public static String masked(Context context,String id){
        String number=load(context,id);
        return isValid(number)?"•••• •••• •••• "+number.substring(12):"شماره کامل ثبت نشده";
    }
}
