package com.example.silenttimer;

import java.util.Calendar;
import java.util.Locale;

/** Shared repeat rules for time-based pages; legacy rules are kept readable. */
public final class ReminderRecurrence {
    private ReminderRecurrence(){}
    public static boolean isRecurring(String rule){ return !"none".equals(normalize(rule)); }
    public static String normalize(String rule){
        if(rule==null||rule.trim().isEmpty()||"none".equals(rule)||"یک‌بار".equals(rule))return "none";
        if("daily".equals(rule))return "every:1:day";
        if("weekly".equals(rule))return "every:1:week";
        if("biweekly".equals(rule))return "every:2:week";
        if("monthly".equals(rule))return "monthly"; // Historical Gregorian-month schedule: do not silently change.
        if("ماهانه".equals(rule))return "every:1:month";
        if("سالانه".equals(rule))return "every:1:year";
        String[] x=rule.split(":",-1);
        if(x.length==3 && "every".equals(x[0]) && ("day".equals(x[2])||"week".equals(x[2])||"month".equals(x[2])||"year".equals(x[2]))){
            try {int n=Integer.parseInt(x[1]);int max="day".equals(x[2])?3650:"week".equals(x[2])?520:"month".equals(x[2])?120:20;
                if(n>=1 && n<=max)return "every:"+n+":"+x[2];}catch(NumberFormatException ignored){}
        }
        return "none";
    }
    public static int interval(String raw){String r=normalize(raw);if("monthly".equals(r))return 1;if("none".equals(r))return 0;return Integer.parseInt(r.split(":")[1]);}
    public static String unit(String raw){String r=normalize(raw);if("monthly".equals(r))return "gregorian-month";if("none".equals(r))return "none";return r.split(":")[2];}
    public static String label(String raw){
        String r=normalize(raw);if("none".equals(r))return "بدون تکرار";
        if("monthly".equals(r))return "ماهانه (نسخه قدیمی)";
        int n=interval(r);String u=unit(r);
        if("day".equals(u))return n==1?"روزانه":"هر "+n+" روز";
        if("week".equals(u))return n==1?"هفتگی":"هر "+n+" هفته";
        if("month".equals(u))return n==1?"ماهانه (شمسی)":"هر "+n+" ماه شمسی";
        return n==1?"سالانه (شمسی)":"هر "+n+" سال شمسی";
    }
    public static String labelSuffix(String r){return isRecurring(r)?" • 🔁 "+label(r):"";}
    /** One step from a due date; calendar days/weeks keep wall-clock time across DST. */
    public static long oneStep(long base,String raw){
        String r=normalize(raw);if("none".equals(r))return base;
        Calendar c=Calendar.getInstance();c.setTimeInMillis(base);
        if("monthly".equals(r)){c.add(Calendar.MONTH,1);return c.getTimeInMillis();}
        int n=interval(r);String u=unit(r);
        if("day".equals(u))c.add(Calendar.DAY_OF_YEAR,n);
        else if("week".equals(u))c.add(Calendar.DAY_OF_YEAR,7*n);
        else if("month".equals(u))return PersianDateUtil.addJalaliMonths(base,n);
        else if("year".equals(u))return PersianDateUtil.addJalaliYears(base,n);
        return c.getTimeInMillis();
    }
    /** Always returns a future time for valid repeating rules, even after multiple missed periods. */
    public static long next(long base,String raw,long now){
        if(base<=0 || !isRecurring(raw))return base;
        long at=base;
        for(int guard=0;guard<100000 && at<=now;guard++){
            long following=oneStep(at,raw);
            if(following<=at)return at;
            at=following;
        }
        return at;
    }
    /** From the current occurrence, take at least one step, skipping missed dates. */
    public static long after(long base,String raw,long now){
        if(!isRecurring(raw))return base;
        long at=oneStep(base,raw);
        return at>now?at:next(at,raw,now);
    }
    public static boolean advanceAfterDone(NexaStore.Reminder r,long now){
        if(r==null||!isRecurring(r.recurrence))return false;
        long at=after(r.whenMillis,r.recurrence,now);
        if(at<=now)return false;
        r.whenMillis=at;r.done=false;r.active=true;return true;
    }
}
