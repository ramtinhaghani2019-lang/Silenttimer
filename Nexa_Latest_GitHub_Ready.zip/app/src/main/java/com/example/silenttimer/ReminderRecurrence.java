package com.example.silenttimer;

import java.util.Calendar;

public final class ReminderRecurrence {
    private ReminderRecurrence(){}
    public static boolean isRecurring(String r){return r!=null&&!"none".equals(r)&&!r.isEmpty();}
    public static String labelSuffix(String r){
        if("daily".equals(r))return " • 🔁 روزانه";
        if("weekly".equals(r))return " • 🔁 هفتگی";
        if("biweekly".equals(r))return " • 🔁 هر دو هفته";
        if("monthly".equals(r))return " • 🔁 ماهانه";
        return "";
    }
    public static long next(long base,String recurrence,long now){
        Calendar c=Calendar.getInstance();c.setTimeInMillis(base);int guard=0;
        do{
            if("daily".equals(recurrence))c.add(Calendar.DAY_OF_YEAR,1);
            else if("weekly".equals(recurrence))c.add(Calendar.DAY_OF_YEAR,7);
            else if("biweekly".equals(recurrence))c.add(Calendar.DAY_OF_YEAR,14);
            else if("monthly".equals(recurrence))c.add(Calendar.MONTH,1);
            else return base;
        }while(c.getTimeInMillis()<=now&&++guard<400);
        return c.getTimeInMillis();
    }

    /** Advances a recurring reminder to its first future occurrence. */
    public static boolean advanceAfterDone(NexaStore.Reminder reminder,long now){
        if(reminder==null || !isRecurring(reminder.recurrence)) return false;
        reminder.whenMillis=next(reminder.whenMillis,reminder.recurrence,now);
        reminder.done=false;
        reminder.active=true;
        return true;
    }
}

