package com.example.silenttimer;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.Path;
import android.graphics.drawable.Drawable;

/** Non-interactive, allocation-light background for the Nexa premium design system. */
public final class NexaAuroraDrawable extends Drawable {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private int alpha=255;
    private int cachedWidth=-1,cachedHeight=-1;
    private Shader base,blue,violet;
    private float blueX,blueY,blueRadius,violetX,violetY,violetRadius;

    private void prepare(int w,int h){
        if(w==cachedWidth && h==cachedHeight)return;
        cachedWidth=w;cachedHeight=h;
        // Flat neutral base and subtle top illumination; no saturated purple fog.
        base=new LinearGradient(0,0,0,h,
                new int[]{0xFF061625,0xFF071727,0xFF03101C},
                new float[]{0f,.43f,1f},Shader.TileMode.CLAMP);
        blueX=w*.65f;blueY=-h*.04f;blueRadius=Math.max(w*1.2f,1f);
        blue=new RadialGradient(blueX,blueY,blueRadius,
                new int[]{0x0F53799B,0x09234467,0x00285374},
                new float[]{0f,.55f,1f},Shader.TileMode.CLAMP);
        violetX=-w*.5f;violetY=h*.65f;violetRadius=Math.max(w*.85f,1f);
        violet=new RadialGradient(violetX,violetY,violetRadius,
                new int[]{0x11C39A50,0x06B88D4A,0x00B88D4A},
                new float[]{0f,.45f,1f},Shader.TileMode.CLAMP);
    }
    @Override public void draw(Canvas canvas){
        Rect b=getBounds();int w=b.width(),h=b.height();if(w<=0||h<=0)return;
        prepare(w,h);int save=canvas.save();canvas.translate(b.left,b.top);
        paint.setAlpha(alpha);paint.setShader(base);canvas.drawRect(0,0,w,h,paint);
        paint.setShader(blue);canvas.drawCircle(blueX,blueY,blueRadius,paint);
        paint.setShader(violet);canvas.drawCircle(violetX,violetY,violetRadius,paint);
        paint.setShader(null);
        // Reference-style champagne-gold ribbon sweeping across the upper-left corner.
        // Only decorates the background; interactive widgets remain real Android views.
        float unit=Math.max(1f,w/400f);
        for(int stroke=0;stroke<3;stroke++){
            Path ribbon=new Path();
            float offset=stroke*7f*unit;
            ribbon.moveTo(-40f*unit,-24f*unit+offset);
            ribbon.cubicTo(55f*unit,46f*unit+offset,85f*unit,91f*unit+offset,
                    156f*unit,13f*unit+offset);
            ribbon.cubicTo(195f*unit,-26f*unit+offset,224f*unit,-11f*unit+offset,
                    249f*unit,-29f*unit+offset);
            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth((stroke==0?3.4f:1.1f)*unit);
            paint.setStrokeCap(Paint.Cap.ROUND);
            paint.setColor(stroke==0?0x80F4D28D:(stroke==1?0x46E2AE59:0x2BBE884C));
            canvas.drawPath(ribbon,paint);
        }
        paint.setStyle(Paint.Style.FILL);
        canvas.restoreToCount(save);
    }
    @Override public void setAlpha(int a){alpha=Math.max(0,Math.min(255,a));invalidateSelf();}
    @Override public void setColorFilter(ColorFilter f){paint.setColorFilter(f);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.OPAQUE;}
}
