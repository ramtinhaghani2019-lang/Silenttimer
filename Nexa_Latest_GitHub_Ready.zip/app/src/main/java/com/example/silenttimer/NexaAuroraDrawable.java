package com.example.silenttimer;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/** Non-interactive, allocation-light background for the Nexa premium design system. */
public final class NexaAuroraDrawable extends Drawable {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private int alpha=255;
    private int cachedWidth=-1,cachedHeight=-1;
    private Shader base,blue,violet;
    private float blueX,blueY,blueRadius,violetX,violetY,violetRadius;

    private void prepare(int w,int h){
        if(w==cachedWidth && h==cachedHeight)return;
        cachedWidth=w;cachedHeight=h;
        base=new LinearGradient(0,0,0,h,new int[]{0xFF10132B,0xFF15132F,0xFF0A1024},
                new float[]{0f,.46f,1f},Shader.TileMode.CLAMP);
        blueX=-w*.15f;blueY=h*.19f;blueRadius=Math.max(w*.97f,1f);
        blue=new RadialGradient(blueX,blueY,blueRadius,
                new int[]{0xCB0860B8,0x7B194A9C,0x00194A9C},new float[]{0f,.48f,1f},Shader.TileMode.CLAMP);
        violetX=w*1.02f;violetY=-h*.06f;violetRadius=Math.max(w*1.15f,1f);
        violet=new RadialGradient(violetX,violetY,violetRadius,
                new int[]{0xBD8941D7,0x6D5D2EA7,0x005D2EA7},new float[]{0f,.55f,1f},Shader.TileMode.CLAMP);
    }
    @Override public void draw(Canvas canvas){
        Rect b=getBounds();int w=b.width(),h=b.height();if(w<=0||h<=0)return;
        prepare(w,h);int save=canvas.save();canvas.translate(b.left,b.top);
        paint.setAlpha(alpha);paint.setShader(base);canvas.drawRect(0,0,w,h,paint);
        paint.setShader(blue);canvas.drawCircle(blueX,blueY,blueRadius,paint);
        paint.setShader(violet);canvas.drawCircle(violetX,violetY,violetRadius,paint);
        paint.setShader(null);canvas.restoreToCount(save);
    }
    @Override public void setAlpha(int a){alpha=Math.max(0,Math.min(255,a));invalidateSelf();}
    @Override public void setColorFilter(ColorFilter f){paint.setColorFilter(f);invalidateSelf();}
    @Override public int getOpacity(){return PixelFormat.OPAQUE;}
}
