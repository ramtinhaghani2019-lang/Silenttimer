package com.example.silenttimer;

/** Pure presentation classification; does not alter medication schedules or alarms. */
final class MedicineOverviewPolicy {
    static final int FINISHED=0;
    static final int OVERDUE=1;
    static final int SOON=2;
    static final int PLANNED=3;
    private static final long DAY=24L*60*60*1000;
    private MedicineOverviewPolicy(){}
    static int classify(boolean active,long nextDoseMillis,long now){
        if(!active)return FINISHED;
        if(nextDoseMillis<=0)return PLANNED;
        if(nextDoseMillis<=now)return OVERDUE;
        return nextDoseMillis-now<=DAY?SOON:PLANNED;
    }
}
