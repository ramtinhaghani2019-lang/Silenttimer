package com.example.silenttimer;

/** The amount of a payment obligation must be a positive whole-toman value. */
public final class BillFormRules {
    private BillFormRules() {}
    public static boolean validAmount(long toman) {
        return toman > 0;
    }
}
