package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Build 199: native presentation helpers for the asset portfolio, with no storage or pricing side effects. */
final class NexaAssetsUi {
    private NexaAssetsUi() {}

    static LinearLayout hero(Context c){
        LinearLayout panel=UiKit.cardLayout(c);
        panel.setPadding(UiKit.dp(c,18),UiKit.dp(c,15),UiKit.dp(c,18),UiKit.dp(c,15));
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        panel.setMinimumHeight(UiKit.dp(c,118));
        // Neutral surface matches the rest of the screen.
        return panel;
    }

    static LinearLayout metrics(Context c,String[] labels,String[] values,int[] tones){
        if(labels.length!=values.length||labels.length!=tones.length)
            throw new IllegalArgumentException("Portfolio metric lengths must match");
        LinearLayout results=new LinearLayout(c);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        // One full-width metric per row: long Iranian Rial/Toman amounts must never clip.
        for(int i=0;i<labels.length;i++){
            LinearLayout tile=UiKit.cardLayout(c);
            tile.setPadding(UiKit.dp(c,12),UiKit.dp(c,9),UiKit.dp(c,12),UiKit.dp(c,9));
            TextView label=UiKit.muted(c,labels[i]);label.setTextSize(12f);tile.addView(label);
            TextView amount=UiKit.title(c,values[i]);
            amount.setTextColor(tones[i]);amount.setTextSize(17f);
            amount.setMaxLines(3);
            amount.setAutoSizeTextTypeUniformWithConfiguration(12,17,1,TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
            tile.addView(amount,UiKit.matchWrap(c,5,0));
            results.addView(tile,UiKit.matchWrap(c,0,i==labels.length-1?0:7));
        }
        return results;
    }

    static TextView filter(Context c,String text,boolean selected){
        TextView chip=UiKit.chip(c,text,selected);
        chip.setTextSize(12.5f);chip.setGravity(Gravity.CENTER);
        // TextView#setMinHeight affects text measurement but does not guarantee
        // View#getMinimumHeight. The filter is interactive, so declare both
        // the text and the View accessibility bounds (48dp minimum).
        chip.setMinWidth(UiKit.dp(c,76));chip.setMinimumWidth(UiKit.dp(c,76));
        chip.setMinHeight(UiKit.dp(c,48));chip.setMinimumHeight(UiKit.dp(c,48));
        chip.setContentDescription("فیلتر "+text+(selected?"، فعال":""));
        UiKit.touchFeedback(c,chip,UiKit.PURPLE,18);
        return chip;
    }

    static LinearLayout purchaseCard(Context c,double profit){
        LinearLayout item=UiKit.cardLayout(c);
        item.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        item.setPadding(UiKit.dp(c,13),UiKit.dp(c,11),UiKit.dp(c,13),UiKit.dp(c,12));
        // Profit color is expressed in text, not in a full colored card.
        item.setMinimumHeight(UiKit.dp(c,110));return item;
    }

    static TextView profitBadge(Context c,double profit,String label){
        int tone=profit>=0?UiKit.GREEN:UiKit.RED;
        TextView badge=UiKit.statusBadge(c,label,tone);
        badge.setTextColor(tone);badge.setTextSize(11.5f);
        badge.setMaxLines(2);badge.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        badge.setMinHeight(UiKit.dp(c,32));badge.setContentDescription(label);
        return badge;
    }

    static TextView formHeading(Context c,String label){
        TextView heading=UiKit.fieldLabel(c,label);heading.setTextSize(14f);
        heading.setTextColor(UiKit.GOLD);
        heading.setPadding(UiKit.dp(c,3),UiKit.dp(c,10),UiKit.dp(c,3),UiKit.dp(c,5));
        return heading;
    }
}
