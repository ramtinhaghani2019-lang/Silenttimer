package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Build 199: native presentation helpers for the asset portfolio, with no storage or pricing side effects. */
final class NexaAssetsUi {
    private NexaAssetsUi() {}

    static LinearLayout hero(Context c){
        LinearLayout panel=UiKit.cardLayout(c);
        panel.setPadding(UiKit.dp(c,18),UiKit.dp(c,15),UiKit.dp(c,18),UiKit.dp(c,15));
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        panel.setMinimumHeight(UiKit.dp(c,118));
        // Neutral surface matches the rest of the screen.
        return panel;
    }

    static HorizontalScrollView metrics(Context c,String[] labels,String[] values,int[] tones){
        if(labels.length!=values.length||labels.length!=tones.length)
            throw new IllegalArgumentException("Portfolio metric lengths must match");
        HorizontalScrollView scroll=new HorizontalScrollView(c);
        scroll.setHorizontalScrollBarEnabled(false);scroll.setFillViewport(false);
        scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout row=new LinearLayout(c);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<labels.length;i++){
            LinearLayout tile=UiKit.financialMetric(c,labels[i],values[i],tones[i]);
            tile.setPadding(UiKit.dp(c,11),UiKit.dp(c,9),UiKit.dp(c,11),UiKit.dp(c,9));
            tile.setMinimumHeight(UiKit.dp(c,108));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(UiKit.dp(c,186),-2);
            if(i>0)lp.leftMargin=UiKit.dp(c,8);
            row.addView(tile,lp);
        }
        scroll.addView(row);return scroll;
    }

    static TextView filter(Context c,String text,boolean selected){
        TextView chip=UiKit.chip(c,text,selected);
        chip.setTextSize(12.5f);chip.setGravity(Gravity.CENTER);
        // TextView#setMinHeight affects text measurement but does not guarantee
        // View#getMinimumHeight. The filter is interactive, so declare both
        // the text and the View accessibility bounds (48dp minimum).
        chip.setMinWidth(UiKit.dp(c,76));chip.setMinimumWidth(UiKit.dp(c,76));
        chip.setMinHeight(UiKit.dp(c,48));chip.setMinimumHeight(UiKit.dp(c,48));
        chip.setContentDescription("فیلتر "+text+(selected?"، فعال":""));
        UiKit.touchFeedback(c,chip,UiKit.PURPLE,18);
        return chip;
    }

    static LinearLayout purchaseCard(Context c,double profit){
        LinearLayout item=UiKit.cardLayout(c);
        item.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        item.setPadding(UiKit.dp(c,13),UiKit.dp(c,11),UiKit.dp(c,13),UiKit.dp(c,12));
        // Profit color is expressed in text, not in a full colored card.
        item.setMinimumHeight(UiKit.dp(c,110));return item;
    }

    static TextView profitBadge(Context c,double profit,String label){
        int tone=profit>=0?UiKit.GREEN:UiKit.RED;
        TextView badge=UiKit.statusBadge(c,label,tone);
        badge.setTextColor(tone);badge.setTextSize(11.5f);
        badge.setMaxLines(2);badge.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        badge.setMinHeight(UiKit.dp(c,32));badge.setContentDescription(label);
        return badge;
    }

    static TextView formHeading(Context c,String label){
        TextView heading=UiKit.fieldLabel(c,label);heading.setTextSize(14f);
        heading.setPadding(UiKit.dp(c,3),UiKit.dp(c,14),UiKit.dp(c,3),UiKit.dp(c,7));
        return heading;
    }
}
