package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NexaListActivity extends Activity {
    private static final int REQ_RECEIPT=887;
    private static final int REQ_LIST_CSV=888;
    private static final String STATE_EXPORT_CSV="list_export_csv";
    private String pendingCsv="";
    private LinearLayout shoppingBox,todoBox,shoppingHead,todoHead;
    private int selectedTab=0;
    private String pendingReceiptList="";
    private ArrayList<String> pendingReceiptItemIds=new ArrayList<>();
    private String pendingReceiptTitle="";
    private long pendingReceiptAmount=0;
    private String pendingReceiptSellerId="",pendingReceiptSellerName="";
    private String pendingReplaceReceiptId="";

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);if(b!=null)pendingCsv=b.getString(STATE_EXPORT_CSV,"");UiKit.applyWindow(this);build();
        String quick=getIntent().getStringExtra("quick_add");
        if("shopping".equals(quick))shoppingBox.postDelayed(()->addShoppingListDialog(null),250);
        else if("todo".equals(quick)){selectTab(1);todoBox.postDelayed(()->editTodoDialog(null),250);}
    }
    @Override protected void onResume(){super.onResume();render();}
    @Override protected void onSaveInstanceState(Bundle out){out.putString(STATE_EXPORT_CSV,pendingCsv);super.onSaveInstanceState(out);}

    private EditText field(String hint){return UiKit.styleField(this,new EditText(this),hint);}

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,32));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);

        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());head.addView(back);
        TextView title=UiKit.title(this,"لیست‌های نِکسا");LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,-2,1f);hp.setMargins(UiKit.dp(this,12),0,0,0);head.addView(title,hp);
        root.addView(head,UiKit.matchWrap(this,0,12));
        // List content stays above decoration; one compact header is enough.

        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
        Button shopTab=UiKit.secondaryButton(this,"🛒 خریدها");Button taskTab=UiKit.secondaryButton(this,"✓ کارها");
        shopTab.setOnClickListener(v->selectTab(0));taskTab.setOnClickListener(v->selectTab(1));
        tabs.addView(shopTab,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,-2,1f);tlp.setMargins(UiKit.dp(this,6),0,0,0);tabs.addView(taskTab,tlp);
        root.addView(tabs,UiKit.matchWrap(this,0,14));

        shoppingHead=UiKit.colorfulCardLayout(this,4);
        shoppingHead.addView(UiKit.sectionTitle(this,"🛒 لیست‌های خرید"));
        Button addList=UiKit.primaryButton(this,"＋ افزودن لیست خرید");addList.setOnClickListener(v->addShoppingListDialog(null));
        shoppingHead.addView(addList,UiKit.matchWrap(this,10,0));root.addView(shoppingHead,UiKit.matchWrap(this,0,12));
        shoppingBox=new LinearLayout(this);shoppingBox.setOrientation(LinearLayout.VERTICAL);root.addView(shoppingBox,UiKit.matchWrap(this,0,18));

        todoHead=UiKit.colorfulCardLayout(this,1);todoHead.addView(UiKit.sectionTitle(this,"✓ کارهای روزانه"));
        Button addTodo=UiKit.primaryButton(this,"＋ کار جدید");addTodo.setOnClickListener(v->editTodoDialog(null));todoHead.addView(addTodo,UiKit.matchWrap(this,10,0));
        Button todoExport=UiKit.secondaryButton(this,"↗ ارسال یا خروجی کارها");
        todoExport.setOnClickListener(v->exportListDialog("کارهای روزانه",todoEntries(),true));
        todoHead.addView(todoExport,UiKit.matchWrap(this,8,0));
        root.addView(todoHead,UiKit.matchWrap(this,0,12));todoBox=new LinearLayout(this);todoBox.setOrientation(LinearLayout.VERTICAL);root.addView(todoBox);

        setContentView(sc);render();selectTab(0);
    }

    private void selectTab(int tab){selectedTab=tab;
        if(shoppingHead!=null)shoppingHead.setVisibility(tab==0?View.VISIBLE:View.GONE);
        if(shoppingBox!=null)shoppingBox.setVisibility(tab==0?View.VISIBLE:View.GONE);
        if(todoHead!=null)todoHead.setVisibility(tab==1?View.VISIBLE:View.GONE);
        if(todoBox!=null)todoBox.setVisibility(tab==1?View.VISIBLE:View.GONE);
    }

    private void addShoppingListDialog(NexaStore.ShoppingList existing){
        LinearLayout box=UiKit.dialogPanel(this);EditText name=field("نام لیست؛ مثلاً خرید خانه");
        final long[] due={existing==null?0:existing.dueMillis};Button when=UiKit.secondaryButton(this,due[0]>0?"🕒 زمان خرید: "+PersianDateUtil.pretty(due[0]):"🕒 زمان خرید (اختیاری)");
        when.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,due[0]>0?due[0]:System.currentTimeMillis()+3600000L,"زمان خرید",ms->{due[0]=ms;when.setText("🕒 زمان خرید: "+PersianDateUtil.pretty(ms));}));
        if(existing!=null)name.setText(existing.name);
        else if("shopping".equals(getIntent().getStringExtra("quick_add"))){
            String fromVoice=getIntent().getStringExtra("voice_title");
            if(fromVoice!=null)name.setText(fromVoice);
        }
        box.addView(name);box.addView(when,UiKit.matchWrap(this,6,0));
        RepeatIntervalPicker shoppingRepeat=new RepeatIntervalPicker(this,box,existing==null?"none":existing.recurrence);
        new AlertDialog.Builder(this).setTitle(existing==null?"لیست خرید جدید":"ویرایش لیست خرید").setView(box)
            .setPositiveButton("ذخیره",(d,w)->{
                String n=name.getText().toString().trim();if(n.isEmpty())return;
                NexaStore.ShoppingList x=existing==null?new NexaStore.ShoppingList():existing;String old=existing==null?null:existing.name;x.name=n;x.dueMillis=due[0];x.recurrence=shoppingRepeat.rule();
                if(existing==null)NexaStore.addShoppingList(this,x);else NexaStore.updateShoppingList(this,x,old);
                if(x.dueMillis>System.currentTimeMillis())LinkedReminderHelper.upsert(this,"shopping:"+x.id,"خرید • "+x.name,"خرید","🛒","لیست خرید",x.dueMillis,"60,0",5,x.recurrence);else LinkedReminderHelper.remove(this,"shopping:"+x.id);
                TodayNotificationManager.refresh(this);render();
            }).setNegativeButton("انصراف",null).show();
    }

    private void addShoppingItemDialog(String listName,NexaStore.ShoppingItem existing){
        LinearLayout box=UiKit.dialogPanel(this);
        ArrayList<String> names=new ArrayList<>(NexaStore.shoppingItemNames(this));
        AutoCompleteTextView name=new AutoCompleteTextView(this);UiKit.styleField(this,name,"نام کالا؛ چند حرف تایپ کن");
        name.setThreshold(1);name.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,names));
        EditText qty=field("مقدار؛ مثلاً ۲");qty.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Spinner unit=UiKit.styledSpinner(this);unit.setAdapter(spinnerAdapter(new String[]{"عدد","کیلو","گرم","لیتر","میلی‌لیتر","بسته","متر","سایر"}));
        AutoCompleteTextView cat=new AutoCompleteTextView(this);UiKit.styleField(this,cat,"دسته؛ مثلاً خوراکی");cat.setThreshold(0);cat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,NexaStore.shoppingCategories(this)));
        Button categoryListBtn=UiKit.secondaryButton(this,"انتخاب از دسته‌ها");categoryListBtn.setOnClickListener(v->showShoppingCategoryDirectory(cat));
        CheckBox important=new CheckBox(this);important.setText("مهم ⭐");important.setTextColor(UiKit.TEXT);
        TextView last=UiKit.muted(this,"");
        box.addView(name,UiKit.matchWrap(this,0,6));box.addView(qty,UiKit.matchWrap(this,0,6));box.addView(unit,UiKit.matchWrap(this,0,6));box.addView(cat,UiKit.matchWrap(this,0,6));box.addView(categoryListBtn,UiKit.matchWrap(this,0,6));box.addView(last,UiKit.matchWrap(this,0,6));box.addView(important);

        TextWatcher watcher=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){
            String n=s.toString().trim();String suggested=NexaStore.suggestedShoppingCategory(n);if(!suggested.isEmpty()&&cat.getText().toString().trim().isEmpty())cat.setText(suggested);
            NexaStore.ShoppingItem prev=NexaStore.lastPurchasedItem(NexaListActivity.this,n);
            if(prev!=null){String seller=prev.store.isEmpty()?"بدون فروشنده ثبت‌شده":prev.store;long p=prev.unitPrice>0?prev.unitPrice:prev.price;
                last.setText("آخرین خرید: "+PersianDateUtil.pretty(prev.purchasedAt)+" • "+seller+(p>0?" • "+NumberFormatUtil.grouped(p)+" تومان":""));}
            else last.setText("");
        }public void afterTextChanged(Editable e){}};name.addTextChangedListener(watcher);

        if(existing!=null){name.setText(existing.name);qty.setText(existing.quantityValue>0?trimDouble(existing.quantityValue):existing.quantity);cat.setText(existing.category);important.setChecked(existing.important);setSpinnerTo(unit,existing.unit);}

        new AlertDialog.Builder(this).setTitle(existing==null?"افزودن قلم به «"+listName+"»":"ویرایش قلم").setView(box)
            .setPositiveButton("ذخیره",(d,w)->{
                String n=name.getText().toString().trim();if(n.isEmpty())return;
                NexaStore.ShoppingItem x=existing==null?new NexaStore.ShoppingItem():existing;x.listName=listName;x.name=n;
                x.quantityValue=parseDouble(qty.getText().toString());x.unit=String.valueOf(unit.getSelectedItem());
                x.quantity=(x.quantityValue>0?trimDouble(x.quantityValue)+" "+x.unit:qty.getText().toString().trim());
                x.category=cat.getText().toString().trim().isEmpty()?NexaStore.suggestedShoppingCategory(n):cat.getText().toString().trim();x.important=important.isChecked();
                if(existing==null)NexaStore.addShoppingItem(this,x);else NexaStore.updateShoppingItem(this,x);render();
            }).setNegativeButton("انصراف",null).show();
    }

    private ArrayAdapter<String> spinnerAdapter(String[] values){return new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
        @Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);t.setPadding(UiKit.dp(NexaListActivity.this,10),UiKit.dp(NexaListActivity.this,10),UiKit.dp(NexaListActivity.this,10),UiKit.dp(NexaListActivity.this,10));return t;}
        @Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);t.setPadding(UiKit.dp(NexaListActivity.this,12),UiKit.dp(NexaListActivity.this,12),UiKit.dp(NexaListActivity.this,12),UiKit.dp(NexaListActivity.this,12));return t;}
    };}
    private void setSpinnerTo(Spinner s,String value){for(int i=0;i<s.getCount();i++)if(String.valueOf(s.getItemAtPosition(i)).equals(value)){s.setSelection(i);break;}}
    private double parseDouble(String x){try{return Double.parseDouble(x.replace(',','.').replace("٬",""));}catch(Exception e){return 0;}}
    private String trimDouble(double v){if(Math.rint(v)==v)return String.valueOf((long)v);return String.format(Locale.US,"%.3f",v).replaceAll("0+$","").replaceAll("\\.$","");}

    private void showBoughtDialog(NexaStore.ShoppingItem item){
        LinearLayout box=UiKit.dialogPanel(this);
        EditText qty=field("وزن/تعداد واقعی");qty.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);if(item.quantityValue>0)qty.setText(trimDouble(item.quantityValue));
        Spinner unit=UiKit.styledSpinner(this);unit.setAdapter(spinnerAdapter(new String[]{"عدد","کیلو","گرم","لیتر","میلی‌لیتر","بسته","متر","سایر"}));setSpinnerTo(unit,item.unit);
        EditText unitPrice=field("قیمت واحد (تومان)");unitPrice.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(unitPrice);if(item.unitPrice>0)unitPrice.setText(NumberFormatUtil.grouped(item.unitPrice));
        EditText sellerQuoted=field("مبلغ اعلامی فروشنده (اختیاری)");sellerQuoted.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(sellerQuoted);if(item.sellerQuotedTotal>0)sellerQuoted.setText(NumberFormatUtil.grouped(item.sellerQuotedTotal));
        Button sellerBtn=UiKit.secondaryButton(this,item.store.isEmpty()?"👤 انتخاب فروشنده / تایپ دستی":"👤 "+item.store);
        EditText manualSeller=field("یا فقط نام فروشنده را دستی بنویس");manualSeller.setText(item.sellerId.isEmpty()?item.store:"");
        final String[] sellerId={item.sellerId};final String[] sellerName={item.store};
        sellerBtn.setOnClickListener(v->showSellerDirectory((id,name)->{sellerId[0]=id;sellerName[0]=name;sellerBtn.setText("👤 "+name);manualSeller.setText("");}));
        Spinner payment=UiKit.styledSpinner(this);payment.setAdapter(spinnerAdapter(new String[]{"روش پرداخت: ثبت نشود","نقدی","کارت بانکی","انتقال / کارت‌به‌کارت","سایر"}));
        Button bankBtn=UiKit.secondaryButton(this,"🏦 انتخاب کارت بانکی");final String[] bankId={item.bankCardId};
        bankBtn.setOnClickListener(v->showBankDirectory((id,label)->{bankId[0]=id;bankBtn.setText("🏦 "+label);}));
        CheckBox receipt=new CheckBox(this);receipt.setText("🧾 بعد از ثبت، تصویر فاکتور اضافه شود");receipt.setTextColor(UiKit.TEXT);
        TextView calc=UiKit.sectionTitle(this,"مبلغ محاسبه‌شده: —");TextView diff=UiKit.muted(this,"");
        Runnable recalc=()->{double q=parseDouble(qty.getText().toString());long up=NumberFormatUtil.longValue(unitPrice.getText());long expected=Math.round(q*up);calc.setText("مبلغ محاسبه‌شده: "+NumberFormatUtil.grouped(expected)+" تومان");long quoted=NumberFormatUtil.longValue(sellerQuoted.getText());if(quoted>0){long d=quoted-expected;if(d>0){diff.setText("⚠️ فروشنده "+NumberFormatUtil.grouped(d)+" تومان بیشتر گفته");diff.setTextColor(UiKit.RED);}else if(d<0){diff.setText("✓ مبلغ فروشنده "+NumberFormatUtil.grouped(-d)+" تومان کمتر است");diff.setTextColor(UiKit.GREEN);}else{diff.setText("✓ مبلغ فروشنده با محاسبه Nexa برابر است");diff.setTextColor(UiKit.GREEN);}}else diff.setText("");};
        TextWatcher tw=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){recalc.run();}public void afterTextChanged(Editable e){}};qty.addTextChangedListener(tw);unitPrice.addTextChangedListener(tw);sellerQuoted.addTextChangedListener(tw);
        box.addView(qty,UiKit.matchWrap(this,0,6));box.addView(unit,UiKit.matchWrap(this,0,6));box.addView(unitPrice,UiKit.matchWrap(this,0,6));box.addView(calc,UiKit.matchWrap(this,4,4));box.addView(sellerQuoted,UiKit.matchWrap(this,0,4));box.addView(diff,UiKit.matchWrap(this,0,8));box.addView(sellerBtn,UiKit.matchWrap(this,0,6));box.addView(manualSeller,UiKit.matchWrap(this,0,6));box.addView(payment,UiKit.matchWrap(this,0,6));box.addView(bankBtn,UiKit.matchWrap(this,0,8));box.addView(receipt);recalc.run();

        new AlertDialog.Builder(this).setTitle("ثبت خرید «"+item.name+"»").setView(box).setPositiveButton("خریدم ✓",(d,w)->{
            item.quantityValue=parseDouble(qty.getText().toString());item.unit=String.valueOf(unit.getSelectedItem());item.quantity=trimDouble(item.quantityValue)+" "+item.unit;
            item.unitPrice=NumberFormatUtil.longValue(unitPrice.getText());item.calculatedTotal=Math.round(item.quantityValue*item.unitPrice);item.sellerQuotedTotal=NumberFormatUtil.longValue(sellerQuoted.getText());
            item.price=item.sellerQuotedTotal>0?item.sellerQuotedTotal:item.calculatedTotal;
            String manual=manualSeller.getText().toString().trim();if(!manual.isEmpty()){item.sellerId="";item.store=manual;}else{item.sellerId=sellerId[0];item.store=sellerName[0];}
            String pay=String.valueOf(payment.getSelectedItem());item.paymentMethod=pay.startsWith("روش پرداخت")?"":pay;item.bankCardId="کارت بانکی".equals(item.paymentMethod)?bankId[0]:"";
            item.purchasedAt=System.currentTimeMillis();item.done=true;NexaStore.updateShoppingItem(this,item);NexaStore.addHistory(this,"خرید",item.name+" • "+NumberFormatUtil.grouped(item.price)+" تومان");TodayNotificationManager.refresh(this);
            if(receipt.isChecked())startReceiptImport(item.listName,new ArrayList<String>(){{add(item.id);}},item.name,item.price,item.sellerId,item.store);
            render();
        }).setNegativeButton("انصراف",null).show();
    }

    private void showShoppingCategoryDirectory(AutoCompleteTextView target){
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"دسته‌های خرید"),UiKit.matchWrap(this,0,8));
        final AlertDialog[] picker={null};
        for(String c:NexaStore.shoppingCategories(this)){Button b=UiKit.secondaryButton(this,c);b.setOnClickListener(v->{target.setText(c);if(picker[0]!=null)picker[0].dismiss();});box.addView(b,UiKit.matchWrap(this,0,5));}
        Button add=UiKit.addIconButton(this);add.setContentDescription("افزودن دسته خرید");add.setOnClickListener(v->{EditText input=field("نام دسته جدید");new AlertDialog.Builder(this).setTitle("دسته خرید جدید").setView(input).setPositiveButton("ثبت",(d,w)->{String c=input.getText().toString().trim();if(c.isEmpty())return;NexaStore.addShoppingCategory(this,c);target.setText(c);if(picker[0]!=null)picker[0].dismiss();target.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,NexaStore.shoppingCategories(this)));}).setNegativeButton("انصراف",null).show();});box.addView(add,UiKit.matchWrap(this,8,0));
        picker[0]=new AlertDialog.Builder(this).setTitle("انتخاب دسته").setView(box).setNegativeButton("بستن",null).show();
    }

    private interface SellerCallback{void picked(String id,String name);}    
    private void showSellerDirectory(SellerCallback cb){
        LinearLayout box=UiKit.dialogPanel(this);
        box.addView(UiKit.sectionTitle(this,"فروشنده‌ها"),UiKit.matchWrap(this,0,8));
        AutoCompleteTextView search=new AutoCompleteTextView(this);UiKit.styleField(this,search,"جستجوی فروشنده؛ چند حرف تایپ کن");search.setThreshold(1);
        LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
        List<NexaStore.ShoppingSeller> sellers=NexaStore.shoppingSellers(this);
        ArrayList<String> sellerNames=new ArrayList<>();for(NexaStore.ShoppingSeller s:sellers)sellerNames.add(s.name);
        search.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,sellerNames));
        box.addView(search,UiKit.matchWrap(this,0,8));box.addView(rows,UiKit.matchWrap(this,0,6));
        Runnable renderRows=()->{rows.removeAllViews();String q=search.getText().toString().trim().toLowerCase(Locale.ROOT);int shown=0;
            for(NexaStore.ShoppingSeller seller:sellers){String hay=(seller.name+" "+seller.phone+" "+seller.address).toLowerCase(Locale.ROOT);if(!q.isEmpty()&&!hay.contains(q))continue;shown++;
                LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);Button b=UiKit.secondaryButton(this,seller.name+(seller.address.isEmpty()?"":" • "+seller.address));b.setOnClickListener(v->cb.picked(seller.id,seller.name));row.addView(b,new LinearLayout.LayoutParams(0,-2,1f));
                Button e=UiKit.editIconButton(this);e.setOnClickListener(v->sellerEditDialog(cb,seller));row.addView(e,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));
                Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف فروشنده؟").setMessage(seller.name).setPositiveButton("حذف",(d,w)->{NexaStore.removeShoppingSeller(this,seller.id);showSellerDirectory(cb);}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42));dl.setMargins(UiKit.dp(this,4),0,0,0);row.addView(del,dl);rows.addView(row,UiKit.matchWrap(this,0,5));
            }
            if(shown==0)rows.addView(UiKit.muted(this,q.isEmpty()?"هنوز فروشنده‌ای ذخیره نشده.":"فروشنده‌ای با این عبارت پیدا نشد."),UiKit.matchWrap(this,4,6));
        };
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int st,int c,int a){}public void onTextChanged(CharSequence x,int st,int b,int c){renderRows.run();}public void afterTextChanged(Editable e){}});renderRows.run();
        Button add=UiKit.addIconButton(this);add.setContentDescription("افزودن فروشنده");add.setOnClickListener(v->sellerEditDialog(cb,null));box.addView(add,UiKit.matchWrap(this,8,0));
        new AlertDialog.Builder(this).setTitle("انتخاب فروشنده").setView(box).setNegativeButton("بستن",null).show();
    }
    private void sellerEditDialog(SellerCallback cb,NexaStore.ShoppingSeller existing){LinearLayout box=UiKit.dialogPanel(this);EditText n=field("نام فروشنده / فروشگاه");EditText cat=field("دسته؛ مثلاً فروشگاه، تعمیرگاه، خدمات");EditText p=field("شماره تماس");p.setInputType(InputType.TYPE_CLASS_PHONE);EditText a=field("آدرس");EditText note=field("توضیحات");if(existing!=null){n.setText(existing.name);cat.setText(existing.category);p.setText(existing.phone);a.setText(existing.address);note.setText(existing.note);}box.addView(n);box.addView(cat);box.addView(p);box.addView(a);box.addView(note);new AlertDialog.Builder(this).setTitle(existing==null?"فروشنده جدید":"ویرایش فروشنده").setView(box).setPositiveButton("ذخیره",(d,w)->{if(n.getText().toString().trim().isEmpty())return;NexaStore.ShoppingSeller s=existing==null?new NexaStore.ShoppingSeller():existing;s.name=n.getText().toString().trim();s.category=cat.getText().toString().trim().isEmpty()?"عمومی":cat.getText().toString().trim();s.phone=p.getText().toString().trim();s.address=a.getText().toString().trim();s.note=note.getText().toString().trim();NexaStore.upsertSeller(this,s);cb.picked(s.id,s.name);}).setNegativeButton("انصراف",null).show();}

    private interface BankCallback{void picked(String id,String label);}    
    private void showBankDirectory(BankCallback cb){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"کارت‌های بانکی"),UiKit.matchWrap(this,0,8));List<NexaStore.BankCard> cards=NexaStore.bankCards(this);if(cards.isEmpty())box.addView(UiKit.muted(this,"هنوز کارتی ثبت نشده."),UiKit.matchWrap(this,0,8));for(NexaStore.BankCard c:cards){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);Button b=UiKit.secondaryButton(this,c.display());b.setOnClickListener(v->cb.picked(c.id,c.display()));row.addView(b,new LinearLayout.LayoutParams(0,-2,1f));Button e=UiKit.editIconButton(this);e.setOnClickListener(v->bankEditDialog(cb,c));row.addView(e,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف کارت؟").setMessage(c.display()).setPositiveButton("حذف",(d,w)->{NexaStore.removeBankCard(this,c.id);showBankDirectory(cb);}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42));dl.setMargins(UiKit.dp(this,4),0,0,0);row.addView(del,dl);box.addView(row,UiKit.matchWrap(this,0,5));}Button add=UiKit.addIconButton(this);add.setOnClickListener(v->bankEditDialog(cb,null));box.addView(add,UiKit.matchWrap(this,8,0));new AlertDialog.Builder(this).setTitle("انتخاب کارت").setView(box).setNegativeButton("بستن",null).show();}
    private void bankEditDialog(BankCallback cb,NexaStore.BankCard existing){LinearLayout box=UiKit.dialogPanel(this);EditText bank=field("نام بانک");EditText label=field("عنوان؛ مثلاً کارت روزمره");EditText last4=field("۴ رقم آخر کارت (اختیاری)");last4.setInputType(InputType.TYPE_CLASS_NUMBER);if(existing!=null){bank.setText(existing.bank);label.setText(existing.label);last4.setText(existing.last4);}box.addView(bank);box.addView(label);box.addView(last4);new AlertDialog.Builder(this).setTitle(existing==null?"کارت بانکی جدید":"ویرایش کارت").setView(box).setPositiveButton("ذخیره",(d,w)->{if(bank.getText().toString().trim().isEmpty())return;NexaStore.BankCard c=existing==null?new NexaStore.BankCard():existing;c.bank=bank.getText().toString().trim();c.label=label.getText().toString().trim();String l=last4.getText().toString().trim();c.last4=l.length()>4?l.substring(l.length()-4):l;NexaStore.upsertBankCard(this,c);cb.picked(c.id,c.display());}).setNegativeButton("انصراف",null).show();}

    private void showItemReceiptGallery(String itemName,List<NexaStore.ShoppingReceipt> receipts){
        LinearLayout box=UiKit.dialogPanel(this);
        if(receipts.isEmpty()){box.addView(UiKit.muted(this,"فاکتوری برای این قلم ثبت نشده."));}
        for(NexaStore.ShoppingReceipt r:receipts){LinearLayout row=UiKit.cardLayout(this);row.addView(UiKit.sectionTitle(this,"🧾 "+(r.title.isEmpty()?itemName:r.title)));row.addView(UiKit.muted(this,PersianDateUtil.pretty(r.createdAt)+(r.amount>0?" • "+NumberFormatUtil.grouped(r.amount)+" تومان":"")));LinearLayout actions=new LinearLayout(this);Button view=UiKit.openIconButton(this);view.setOnClickListener(v->showReceiptImage(r));Button replace=UiKit.iconButton(this,"↻","تعویض تصویر",UiKit.GOLD);replace.setOnClickListener(v->startReceiptReplacement(r));actions.addView(view,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));rp.setMargins(UiKit.dp(this,5),0,0,0);actions.addView(replace,rp);row.addView(actions,UiKit.matchWrap(this,7,0));box.addView(row,UiKit.matchWrap(this,0,7));}
        new AlertDialog.Builder(this).setTitle("فاکتورهای «"+itemName+"»").setView(box).setNegativeButton("بستن",null).show();
    }

    private void showReceiptGallery(String listName,List<NexaStore.ShoppingItem> listItems){
        LinearLayout box=UiKit.dialogPanel(this);Button add=UiKit.secondaryButton(this,"＋ فاکتور مشترک");add.setOnClickListener(v->chooseItemsForSharedReceipt(listName,listItems));box.addView(add,UiKit.matchWrap(this,0,8));
        List<NexaStore.ShoppingReceipt> receipts=NexaStore.receiptsForList(this,listName);if(receipts.isEmpty())box.addView(UiKit.muted(this,"هنوز فاکتوری برای این لیست ثبت نشده."));
        for(NexaStore.ShoppingReceipt r:receipts){LinearLayout row=UiKit.cardLayout(this);row.addView(UiKit.sectionTitle(this,"🧾 "+(r.title.isEmpty()?"فاکتور":r.title)));row.addView(UiKit.muted(this,PersianDateUtil.pretty(r.createdAt)+(r.sellerName.isEmpty()?"":" • "+r.sellerName)+(r.amount>0?" • "+NumberFormatUtil.grouped(r.amount)+" تومان":"")));LinearLayout actions=new LinearLayout(this);Button view=UiKit.openIconButton(this);view.setOnClickListener(v->showReceiptImage(r));Button replace=UiKit.iconButton(this,"↻","تعویض تصویر",UiKit.GOLD);replace.setOnClickListener(v->startReceiptReplacement(r));Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف فاکتور از Nexa؟").setMessage("فقط نسخه داخل Nexa پاک می‌شود؛ عکس اصلی گالری دست‌نخورده می‌ماند.").setPositiveButton("حذف",(d,w)->{AttachmentStore.deletePath(r.localPath);NexaStore.removeShoppingReceipt(this,r.id);render();}).setNegativeButton("انصراف",null).show());actions.addView(view,new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46)));LinearLayout.LayoutParams rpl=new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46));rpl.setMargins(UiKit.dp(this,6),0,0,0);actions.addView(replace,rpl);LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46));dl.setMargins(UiKit.dp(this,6),0,0,0);actions.addView(del,dl);row.addView(actions,UiKit.matchWrap(this,8,0));box.addView(row,UiKit.matchWrap(this,0,7));}
        new AlertDialog.Builder(this).setTitle("فاکتورهای «"+listName+"»").setView(box).setNegativeButton("بستن",null).show();
    }

    private void chooseItemsForSharedReceipt(String listName,List<NexaStore.ShoppingItem> items){
        if(items.isEmpty()){Toast.makeText(this,"اول حداقل یک قلم به لیست اضافه کن.",Toast.LENGTH_SHORT).show();return;}
        String[] labels=new String[items.size()];boolean[] checked=new boolean[items.size()];for(int i=0;i<items.size();i++){labels[i]=items.get(i).name;checked[i]=true;}
        new AlertDialog.Builder(this).setTitle("این فاکتور مربوط به کدام اقلام است؟").setMultiChoiceItems(labels,checked,(d,w,c)->checked[w]=c).setPositiveButton("ادامه",(d,w)->{
            ArrayList<String> ids=new ArrayList<>();long sum=0;String firstName="";for(int i=0;i<items.size();i++)if(checked[i]){ids.add(items.get(i).id);sum+=items.get(i).price;if(firstName.isEmpty())firstName=items.get(i).name;}
            if(ids.isEmpty())return;String autoTitle=ids.size()==1?firstName:("فاکتور "+listName+" • "+ids.size()+" قلم");askReceiptMetaAndPick(listName,ids,autoTitle,sum,"","");
        }).setNegativeButton("انصراف",null).show();
    }

    private void askReceiptMetaAndPick(String listName,ArrayList<String> ids,String defaultTitle,long defaultAmount,String sellerId,String sellerName){
        LinearLayout box=UiKit.dialogPanel(this);EditText title=field("عنوان فاکتور");title.setText((defaultTitle==null||defaultTitle.trim().isEmpty()||defaultTitle.startsWith("فاکتور "))?autoReceiptTitle(sellerName,listName,defaultAmount,System.currentTimeMillis()):defaultTitle);EditText amount=field("مبلغ فاکتور (تومان)");amount.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(amount);if(defaultAmount>0)amount.setText(NumberFormatUtil.grouped(defaultAmount));TextView compare=UiKit.muted(this,defaultAmount>0?"جمع اقلام انتخابی: "+NumberFormatUtil.grouped(defaultAmount)+" تومان":"");amount.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){long invoice=NumberFormatUtil.longValue(amount.getText());long diff=invoice-defaultAmount;if(invoice<=0||defaultAmount<=0){compare.setText("");return;}compare.setText(diff==0?"✓ مبلغ فاکتور با جمع اقلام برابر است":(diff>0?"⚠️ فاکتور "+NumberFormatUtil.grouped(diff)+" تومان بیشتر است":"✓ فاکتور "+NumberFormatUtil.grouped(-diff)+" تومان کمتر است"));compare.setTextColor(diff>0?UiKit.RED:UiKit.GREEN);}public void afterTextChanged(Editable e){}});box.addView(title);box.addView(amount);box.addView(compare,UiKit.matchWrap(this,5,0));
        new AlertDialog.Builder(this).setTitle("مشخصات فاکتور").setView(box).setPositiveButton("انتخاب عکس",(d,w)->startReceiptImport(listName,ids,title.getText().toString().trim(),NumberFormatUtil.longValue(amount.getText()),sellerId,sellerName)).setNegativeButton("انصراف",null).show();
    }

    private void startReceiptImport(String listName,ArrayList<String> ids,String title,long amount,String sellerId,String sellerName){
        pendingReceiptList=listName;pendingReceiptItemIds=new ArrayList<>(ids);pendingReceiptTitle=(sellerName!=null&&!sellerName.trim().isEmpty())?autoReceiptTitle(sellerName,listName,amount,System.currentTimeMillis()):title;pendingReceiptAmount=amount;pendingReceiptSellerId=sellerId;pendingReceiptSellerName=sellerName;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_RECEIPT);
    }

    private void startReceiptReplacement(NexaStore.ShoppingReceipt r){
        pendingReplaceReceiptId=r.id;pendingReceiptList=r.listName;pendingReceiptItemIds=new ArrayList<>(r.itemIds);pendingReceiptTitle=r.title;pendingReceiptAmount=r.amount;pendingReceiptSellerId=r.sellerId;pendingReceiptSellerName=r.sellerName;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("image/*");i.addCategory(Intent.CATEGORY_OPENABLE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(i,REQ_RECEIPT);
    }

    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==REQ_LIST_CSV){
            if(result==RESULT_OK && data!=null && data.getData()!=null && !pendingCsv.isEmpty()){
                try(OutputStream out=getContentResolver().openOutputStream(data.getData(),"wt")){
                    if(out==null)throw new java.io.IOException("No output stream");
                    out.write(pendingCsv.getBytes(StandardCharsets.UTF_8));out.flush();
                    Toast.makeText(this,"فایل CSV ذخیره شد.",Toast.LENGTH_SHORT).show();
                }catch(Exception e){Toast.makeText(this,"ذخیره فایل ناموفق بود؛ دوباره تلاش کن.",Toast.LENGTH_LONG).show();}
            }
            pendingCsv="";return;
        }
        if(request!=REQ_RECEIPT||result!=RESULT_OK||data==null||data.getData()==null)return;try{
        AttachmentStore.ImportResult ir=AttachmentStore.importImage(this,data.getData(),"shopping");
        if(!pendingReplaceReceiptId.isEmpty()){NexaStore.ShoppingReceipt current=null;for(NexaStore.ShoppingReceipt rr:NexaStore.shoppingReceipts(this))if(rr.id.equals(pendingReplaceReceiptId)){current=rr;break;}if(current!=null){current.localPath=ir.path;current.sha256=ir.sha256;if(current.title.isEmpty())current.title=autoReceiptTitle(current.sellerName,current.listName,current.amount,System.currentTimeMillis());NexaStore.updateShoppingReceipt(this,current);Toast.makeText(this,"تصویر فاکتور تعویض شد.",Toast.LENGTH_SHORT).show();}}
        else{NexaStore.ShoppingReceipt old=NexaStore.receiptByHash(this,ir.sha256);
            if(old!=null){for(String id:pendingReceiptItemIds)if(!old.itemIds.contains(id))old.itemIds.add(id);if(old.listName.isEmpty())old.listName=pendingReceiptList;NexaStore.updateShoppingReceipt(this,old);Toast.makeText(this,"این عکس قبلاً در Nexa بود؛ به اقلام انتخابی لینک شد.",Toast.LENGTH_LONG).show();}
            else{NexaStore.ShoppingReceipt r=new NexaStore.ShoppingReceipt();r.listName=pendingReceiptList;r.itemIds.addAll(pendingReceiptItemIds);r.title=pendingReceiptTitle;r.amount=pendingReceiptAmount;r.localPath=ir.path;r.sha256=ir.sha256;r.sellerId=pendingReceiptSellerId;r.sellerName=pendingReceiptSellerName;r.title=r.title.isEmpty()?autoReceiptTitle(r.sellerName,r.listName,r.amount,r.createdAt):r.title;NexaStore.addShoppingReceipt(this,r);Toast.makeText(this,"فاکتور داخل حافظه اختصاصی Nexa ذخیره شد.",Toast.LENGTH_SHORT).show();}}
    }catch(Exception e){Toast.makeText(this,"ذخیره فاکتور انجام نشد.",Toast.LENGTH_LONG).show();}finally{pendingReceiptList="";pendingReceiptItemIds.clear();pendingReceiptTitle="";pendingReceiptAmount=0;pendingReplaceReceiptId="";render();}}

    private String autoReceiptTitle(String seller,String list,long amount,long when){String base=(seller==null||seller.trim().isEmpty())?(list==null||list.trim().isEmpty()?"فاکتور خرید":list.trim()):seller.trim();String value=amount>0?" • "+NumberFormatUtil.grouped(amount)+" تومان":"";return base+" • "+PersianDateUtil.pretty(when)+value;}

    private void showReceiptImage(NexaStore.ShoppingReceipt r){
        File f=new File(r.localPath);if(!f.exists()){Toast.makeText(this,"فایل فاکتور پیدا نشد.",Toast.LENGTH_LONG).show();return;}
        LinearLayout box=UiKit.dialogPanel(this);ZoomImageView iv=new ZoomImageView(this);iv.setAdjustViewBounds(true);iv.setImageBitmap(BitmapFactory.decodeFile(f.getAbsolutePath()));box.addView(iv,new LinearLayout.LayoutParams(-1,UiKit.dp(this,430)));box.addView(UiKit.muted(this,"برای زوم از دو انگشت استفاده کن."),UiKit.matchWrap(this,5,2));box.addView(UiKit.muted(this,(r.title.isEmpty()?"فاکتور":r.title)+(r.amount>0?" • "+NumberFormatUtil.grouped(r.amount)+" تومان":"")),UiKit.matchWrap(this,5,5));LinearLayout tools=new LinearLayout(this);Button rotate=UiKit.secondaryButton(this,"↻ چرخش");rotate.setOnClickListener(v->{if(AttachmentStore.rotate90(r.localPath)){iv.setImageBitmap(BitmapFactory.decodeFile(r.localPath));iv.resetZoom();Toast.makeText(this,"تصویر چرخانده شد.",Toast.LENGTH_SHORT).show();}});Button crop=UiKit.secondaryButton(this,"✂ برش");crop.setOnClickListener(v->{if(AttachmentStore.cropMargins(r.localPath)){iv.setImageBitmap(BitmapFactory.decodeFile(r.localPath));iv.resetZoom();Toast.makeText(this,"حاشیه‌های تصویر برش خورد.",Toast.LENGTH_SHORT).show();}});Button replace=UiKit.secondaryButton(this,"↻ تعویض");replace.setOnClickListener(v->startReceiptReplacement(r));tools.addView(rotate,new LinearLayout.LayoutParams(0,-2,1f));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1f);cp.setMargins(UiKit.dp(this,5),0,0,0);tools.addView(crop,cp);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,-2,1f);rp.setMargins(UiKit.dp(this,5),0,0,0);tools.addView(replace,rp);box.addView(tools);new AlertDialog.Builder(this).setView(box).setPositiveButton("بستن",null).show();
    }

    private NexaStore.ShoppingItem previousPurchase(String name,String currentId){NexaStore.ShoppingItem best=null;for(NexaStore.ShoppingItem x:NexaStore.shoppingItems(this))if(x.done&&!x.id.equals(currentId)&&x.name.equalsIgnoreCase(name)&&x.purchasedAt>0&&(best==null||x.purchasedAt>best.purchasedAt))best=x;return best;}

    private void editTodoDialog(NexaStore.TodoItem existing){
        LinearLayout box=UiKit.dialogPanel(this);EditText title=field("عنوان کار");EditText category=field("دسته؛ مثلاً خانه / کار");EditText note=field("توضیحات");Button due=UiKit.secondaryButton(this,"بدون تاریخ");final long[] dueMillis={0};
        due.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,System.currentTimeMillis()+3600000L,"موعد انجام",ms->{dueMillis[0]=ms;due.setText(PersianDateUtil.pretty(ms));}));
        box.addView(title);box.addView(category);box.addView(note);box.addView(due);
        RepeatIntervalPicker todoRepeat=new RepeatIntervalPicker(this,box,existing==null?"none":existing.recurrence);
        AlertEditor alerts=new AlertEditor(this,box,"60,0",5);
        if(existing!=null){title.setText(existing.title);category.setText(existing.category);note.setText(existing.note);dueMillis[0]=existing.dueMillis;if(existing.dueMillis>0)due.setText(PersianDateUtil.pretty(existing.dueMillis));}
        else if("todo".equals(getIntent().getStringExtra("quick_add"))){
            String fromVoice=getIntent().getStringExtra("voice_title");
            if(fromVoice!=null)title.setText(fromVoice);
        }
        new AlertDialog.Builder(this).setTitle(existing==null?"کار جدید":"ویرایش کار").setView(box).setPositiveButton("ذخیره",(d,w)->{String t=title.getText().toString().trim();if(t.isEmpty())return;NexaStore.TodoItem x=existing==null?new NexaStore.TodoItem():existing;x.title=t;x.category=category.getText().toString().trim().isEmpty()?"عمومی":category.getText().toString().trim();x.note=note.getText().toString().trim();x.dueMillis=dueMillis[0];x.recurrence=todoRepeat.rule();if(existing==null)NexaStore.addTodo(this,x);else NexaStore.updateTodo(this,x);if(x.dueMillis>System.currentTimeMillis())LinkedReminderHelper.upsert(this,"todo:"+x.id,x.title,"کار","✓",x.note,x.dueMillis,alerts.rules(),alerts.repeatMinutes(),x.recurrence);else LinkedReminderHelper.remove(this,"todo:"+x.id);TodayNotificationManager.refresh(this);render();}).setNegativeButton("انصراف",null).show();
    }

    private List<ListShareExport.Entry> shoppingEntries(String listName){
        List<ListShareExport.Entry> entries=new ArrayList<>();
        for(NexaStore.ShoppingItem x:NexaStore.shoppingItems(this))if(x.listName.equalsIgnoreCase(listName))
            entries.add(new ListShareExport.Entry(x.name,x.quantity,x.category,x.done,x.important));
        return entries;
    }

    private List<ListShareExport.Entry> todoEntries(){
        List<ListShareExport.Entry> entries=new ArrayList<>();
        for(NexaStore.TodoItem x:NexaStore.todos(this))
            entries.add(new ListShareExport.Entry(x.title,x.dueMillis>0?PersianDateUtil.pretty(x.dueMillis):"",x.category,x.done,false));
        return entries;
    }

    private void exportListDialog(String heading,List<ListShareExport.Entry> entries,boolean todo){
        if(entries.isEmpty()){Toast.makeText(this,"موردی برای خروجی وجود ندارد.",Toast.LENGTH_SHORT).show();return;}
        final boolean[] includeDone={false};
        new AlertDialog.Builder(this).setTitle("انتخاب موارد خروجی")
            .setSingleChoiceItems(new String[]{"فقط باقی‌مانده‌ها","همه موارد، شامل انجام‌شده‌ها"},0,(dialog,which)->includeDone[0]=which==1)
            .setPositiveButton("ادامه",(dialog,which)->{
                if(ListShareExport.select(entries,includeDone[0]).isEmpty()){
                    Toast.makeText(this,"مورد باقی‌مانده‌ای نیست؛ گزینه همه موارد را انتخاب کن.",Toast.LENGTH_LONG).show();return;
                }
                new AlertDialog.Builder(this).setTitle("ارسال یا ذخیره")
                    .setItems(new String[]{"ارسال متن در پیام‌رسان","ذخیره فایل CSV برای Excel"},(d,action)->{
                        if(action==0)shareListText(heading,entries,includeDone[0],todo);
                        else saveListCsv(heading,entries,includeDone[0],todo);
                    }).setNegativeButton("انصراف",null).show();
            }).setNegativeButton("انصراف",null).show();
    }

    private void shareListText(String heading,List<ListShareExport.Entry> entries,boolean includeDone,boolean todo){
        Intent share=new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT,ListShareExport.text(heading,entries,includeDone,todo));
        try{startActivity(Intent.createChooser(share,"اشتراک‌گذاری لیست"));}
        catch(Exception e){Toast.makeText(this,"برنامه‌ای برای اشتراک‌گذاری یافت نشد.",Toast.LENGTH_LONG).show();}
    }

    private void saveListCsv(String heading,List<ListShareExport.Entry> entries,boolean includeDone,boolean todo){
        pendingCsv=ListShareExport.csv(heading,entries,includeDone,todo);
        Intent doc=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        doc.addCategory(Intent.CATEGORY_OPENABLE);
        doc.setType("text/csv");
        doc.putExtra(Intent.EXTRA_TITLE,todo?"Nexa_Todos.csv":"Nexa_Shopping.csv");
        try{startActivityForResult(doc,REQ_LIST_CSV);}
        catch(Exception e){pendingCsv="";Toast.makeText(this,"انتخابگر ذخیره فایل در دسترس نیست.",Toast.LENGTH_LONG).show();}
    }

    private void render(){
        if(shoppingBox==null)return;shoppingBox.removeAllViews();todoBox.removeAllViews();
        List<NexaStore.ShoppingList> lists=NexaStore.shoppingLists(this);
        if(lists.isEmpty()){TextView e=UiKit.muted(this,"هنوز لیست خریدی نساختی. اول «افزودن لیست خرید» را بزن.");e.setGravity(Gravity.CENTER);shoppingBox.addView(e,UiKit.matchWrap(this,10,0));}
        for(NexaStore.ShoppingList list:lists){
            List<NexaStore.ShoppingItem> items=new ArrayList<>();for(NexaStore.ShoppingItem x:NexaStore.shoppingItems(this))if(x.listName.equalsIgnoreCase(list.name))items.add(x);
            LinearLayout group=UiKit.colorfulCardLayout(this,4);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setVisibility(View.GONE);
            LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);Button toggle=UiKit.secondaryButton(this,"▸ "+list.name+" ("+items.size()+")");header.addView(toggle,new LinearLayout.LayoutParams(0,-2,1f));
            Button add=UiKit.addIconButton(this);add.setContentDescription("افزودن قلم");add.setOnClickListener(v->addShoppingItemDialog(list.name,null));header.addView(add,new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46)));
            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->addShoppingListDialog(list));LinearLayout.LayoutParams ep=new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46));ep.setMargins(UiKit.dp(this,5),0,0,0);header.addView(edit,ep);
            Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف لیست؟").setMessage("اقلام این لیست هم حذف می‌شوند.").setPositiveButton("حذف",(d,w)->{LinkedReminderHelper.remove(this,"shopping:"+list.id);NexaStore.removeShoppingList(this,list.id);TodayNotificationManager.refresh(this);render();}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46));dp.setMargins(UiKit.dp(this,5),0,0,0);header.addView(del,dp);
            edit.setVisibility(View.GONE);del.setVisibility(View.GONE);
            Button moreList=UiKit.iconButton(this,"⋮","عملیات لیست",UiKit.GOLD);
            moreList.setOnClickListener(v->new AlertDialog.Builder(this).setTitle(list.name)
                .setItems(new String[]{"ویرایش لیست","حذف لیست"},(d,w)->{
                    if(w==0)edit.performClick();else del.performClick();
                }).show());
            header.addView(moreList,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            group.addView(header);
            long spent=0;for(NexaStore.ShoppingItem x:items)if(x.done)spent+=x.price;group.addView(UiKit.muted(this,"جمع خریدشده: "+NumberFormatUtil.grouped(spent)+" تومان"),UiKit.matchWrap(this,6,3));if(list.dueMillis>0)group.addView(UiKit.muted(this,"🕒 زمان خرید: "+PersianDateUtil.pretty(list.dueMillis)+ReminderRecurrence.labelSuffix(list.recurrence)),UiKit.matchWrap(this,0,6));
            Button share=UiKit.secondaryButton(this,"↗ ارسال یا خروجی لیست خرید");
            share.setOnClickListener(v->exportListDialog(list.name,shoppingEntries(list.name),false));
            body.addView(share,UiKit.matchWrap(this,0,5));
            Button receipts=UiKit.secondaryButton(this,"🧾 فاکتورها ("+NexaStore.receiptsForList(this,list.name).size()+")");receipts.setOnClickListener(v->showReceiptGallery(list.name,items));body.addView(receipts,UiKit.matchWrap(this,0,5));
            toggle.setOnClickListener(v->{boolean open=body.getVisibility()!=View.VISIBLE;body.setVisibility(open?View.VISIBLE:View.GONE);toggle.setText((open?"▾ ":"▸ ")+list.name+" ("+items.size()+")");});
            if(items.isEmpty())body.addView(UiKit.muted(this,"این لیست خالی است؛ با + قلم اضافه کن."),UiKit.matchWrap(this,8,0));
            for(NexaStore.ShoppingItem x:items){
                LinearLayout c=UiKit.cardLayout(this);c.setAlpha(x.done?0.62f:1f);TextView t=UiKit.sectionTitle(this,(x.important?"⭐ ":"")+x.name);if(x.done)t.setPaintFlags(t.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG);c.addView(t);
                String sub=(x.quantity.isEmpty()?"":x.quantity)+(x.category.isEmpty()?"":" • "+x.category)+(x.done&&x.price>0?" • "+NumberFormatUtil.grouped(x.price)+" تومان":"");c.addView(UiKit.muted(this,sub),UiKit.matchWrap(this,5,2));
                if(x.done){if(!x.store.isEmpty())c.addView(UiKit.muted(this,"فروشنده: "+x.store));if(!x.paymentMethod.isEmpty()){String pay=x.paymentMethod;NexaStore.BankCard bc=NexaStore.bankCardById(this,x.bankCardId);if(bc!=null)pay+=" • "+bc.display();c.addView(UiKit.muted(this,"پرداخت: "+pay));}
                    if(x.calculatedTotal>0&&x.sellerQuotedTotal>0){long dif=x.sellerQuotedTotal-x.calculatedTotal;TextView dv=UiKit.muted(this,dif==0?"✓ مبلغ فروشنده دقیق است":(dif>0?"⚠️ "+NumberFormatUtil.grouped(dif)+" تومان بیشتر از محاسبه Nexa":"✓ "+NumberFormatUtil.grouped(-dif)+" تومان کمتر از محاسبه Nexa"));dv.setTextColor(dif>0?UiKit.RED:UiKit.GREEN);c.addView(dv);}
                    NexaStore.ShoppingItem prev=previousPurchase(x.name,x.id);if(prev!=null){long old=prev.unitPrice>0?prev.unitPrice:prev.price;long cur=x.unitPrice>0?x.unitPrice:x.price;if(old>0&&cur>0){double pc=(cur-old)*100.0/old;c.addView(UiKit.muted(this,"نسبت به خرید قبلی: "+String.format(Locale.US,"%+.1f%%",pc)+" • قبلی "+NumberFormatUtil.grouped(old)+" تومان"));}}
                }
                List<NexaStore.ShoppingReceipt> rs=NexaStore.receiptsForItem(this,x.id);if(!rs.isEmpty()){Button rb=UiKit.secondaryButton(this,"🧾 فاکتور "+rs.size()+" عدد");rb.setOnClickListener(v->showItemReceiptGallery(x.name,rs));c.addView(rb,UiKit.matchWrap(this,7,0));}
                LinearLayout actions=new LinearLayout(this);actions.setGravity(Gravity.CENTER_VERTICAL);Button bought=UiKit.secondaryButton(this,x.done?"↩ برگرداندن":"خریدم ✓");bought.setOnClickListener(v->{if(x.done){x.done=false;NexaStore.updateShoppingItem(this,x);TodayNotificationManager.refresh(this);render();}else showBoughtDialog(x);});actions.addView(bought,new LinearLayout.LayoutParams(0,-2,1f));Button ei=UiKit.editIconButton(this);ei.setOnClickListener(v->addShoppingItemDialog(list.name,x));actions.addView(ei,new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46)));Button di=UiKit.deleteIconButton(this);di.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف کالا؟").setMessage(x.name).setPositiveButton("حذف",(d,w)->{NexaStore.removeShoppingItem(this,x.id);render();}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams dip=new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46));dip.setMargins(UiKit.dp(this,5),0,0,0);actions.addView(di,dip);c.addView(actions,UiKit.matchWrap(this,5,0));
                actions.setVisibility(View.GONE);
                c.setOnClickListener(v->actions.setVisibility(actions.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
                body.addView(c,UiKit.matchWrap(this,6,0));
            }
            group.addView(body);shoppingBox.addView(group,UiKit.matchWrap(this,0,10));
        }

        List<NexaStore.TodoItem> todos=NexaStore.todos(this);if(todos.isEmpty()){TextView e=UiKit.muted(this,"کاری ثبت نشده.");e.setGravity(Gravity.CENTER);todoBox.addView(e,UiKit.matchWrap(this,8,0));}
        for(NexaStore.TodoItem x:todos){LinearLayout c=UiKit.colorfulCardLayout(this,1);c.setAlpha(x.done?0.5f:1f);TextView t=UiKit.sectionTitle(this,x.title);if(x.done)t.setPaintFlags(t.getPaintFlags()|Paint.STRIKE_THRU_TEXT_FLAG);c.addView(t);String sub=x.category+(x.dueMillis>0?" • "+PersianDateUtil.pretty(x.dueMillis):"")+ReminderRecurrence.labelSuffix(x.recurrence);c.addView(UiKit.muted(this,sub),UiKit.matchWrap(this,5,2));LinearLayout actions=new LinearLayout(this);Button done=UiKit.secondaryButton(this,x.done?"↩ برگرداندن":"انجام شد ✓");done.setOnClickListener(v->{x.done=!x.done;NexaStore.updateTodo(this,x);if(x.done && x.dueMillis>0 && ReminderRecurrence.isRecurring(x.recurrence)){
            x.dueMillis=ReminderRecurrence.after(x.dueMillis,x.recurrence,System.currentTimeMillis());
            x.done=false;NexaStore.updateTodo(this,x);
            LinkedReminderHelper.upsert(this,"todo:"+x.id,x.title,"کار","✓",x.note,x.dueMillis,"60,0",5,x.recurrence);
        }else if(x.done)LinkedReminderHelper.remove(this,"todo:"+x.id);
        TodayNotificationManager.refresh(this);render();});actions.addView(done,new LinearLayout.LayoutParams(0,-2,1f));Button ei=UiKit.editIconButton(this);ei.setOnClickListener(v->editTodoDialog(x));actions.addView(ei,new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46)));Button di=UiKit.deleteIconButton(this);di.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف کار؟").setMessage(x.title).setPositiveButton("حذف",(d,w)->{LinkedReminderHelper.remove(this,"todo:"+x.id);NexaStore.removeTodo(this,x.id);TodayNotificationManager.refresh(this);render();}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46));lp.setMargins(UiKit.dp(this,5),0,0,0);actions.addView(di,lp);c.addView(actions,UiKit.matchWrap(this,5,0));
            actions.setVisibility(View.GONE);
            c.setOnClickListener(v->actions.setVisibility(actions.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));
            todoBox.addView(c,UiKit.matchWrap(this,0,6));}
    }
}
