package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.text.Editable;
import android.text.TextWatcher;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.text.method.PasswordTransformationMethod;
import android.view.inputmethod.InputMethodManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class VaultActivity extends Activity {
    private LinearLayout list,groupManagerList;
    private String vaultQuery="";
    private static final int VAULT_UNLOCK=701;
    private boolean authenticated=false;
    private boolean awaitingUnlock=false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        UiKit.applyWindow(this);

        // Never construct the secret-bearing UI before Vault-specific authentication.
        if(!NexaStore.pinConfigured(this)){
            Toast.makeText(this,"ابتدا PIN صندوق امن را در تنظیمات امنیت فعال کنید.",Toast.LENGTH_LONG).show();
            startActivity(new android.content.Intent(this,SecurityActivity.class));
            finish();return;
        }
        awaitingUnlock=true;
        startActivityForResult(new android.content.Intent(this, UnlockActivity.class),VAULT_UNLOCK);
    }
    @Override protected void onActivityResult(int request,int result,android.content.Intent data){
        super.onActivityResult(request,result,data);
        if(request==VAULT_UNLOCK){awaitingUnlock=false;
            if(result==RESULT_OK && SecurityGate.isUnlocked()){
                authenticated=true;build();getWindow().getDecorView().setVisibility(View.VISIBLE);
                if(getIntent().getBooleanExtra("quick_add",false))list.postDelayed(this::addDialog,300);
            }else finish();
        }
    }
    @Override protected void onStop(){super.onStop();
        // Relock when leaving this screen only when the setting is enabled.
        if(authenticated && NexaStore.vaultLockOnBackground(this)){
            authenticated=false;
            getWindow().getDecorView().setVisibility(View.INVISIBLE);
        }
    }
    @Override protected void onRestart(){super.onRestart();
        if(!awaitingUnlock && !authenticated && NexaStore.pinConfigured(this)){awaitingUnlock=true;
            startActivityForResult(new android.content.Intent(this,UnlockActivity.class),VAULT_UNLOCK);}
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"صندوق امن"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.masterHero(this,"🔐","صندوق امن","اطلاعات محرمانه با دسترسی محافظت‌شده",6),UiKit.matchWrap(this,8,14));
        root.addView(UiKit.muted(this,"رمزها و یادداشت‌های محرمانه؛ داده حساس با Android Keystore رمزگذاری می‌شود."),UiKit.matchWrap(this,0,14));

        LinearLayout security=UiKit.colorfulCardLayout(this,6);
        security.addView(UiKit.sectionTitle(this,"🔐 صندوق امن"));
        if(!NexaStore.lockEnabled(this)) {
            security.addView(UiKit.muted(this,"پیشنهاد: قبل از استفاده، قفل PIN/اثر انگشت Nexa را از تنظیمات فعال کن."),UiKit.matchWrap(this,6,10));
            Button openSec=UiKit.secondaryButton(this,"رفتن به تنظیمات امنیت");
            openSec.setOnClickListener(v->startActivity(new android.content.Intent(this,SecurityActivity.class)));
            security.addView(openSec);
        } else {
            security.addView(UiKit.muted(this,"قفل Nexa فعال است • اسکرین‌شات این صفحه غیرفعال است."),UiKit.matchWrap(this,6,0));
        }
        root.addView(security,UiKit.matchWrap(this,0,12));

        LinearLayout groups=UiKit.colorfulCardLayout(this,3);LinearLayout gh=new LinearLayout(this);gh.setGravity(Gravity.CENTER_VERTICAL);
        gh.addView(UiKit.sectionTitle(this,"مجموعه‌های صندوق امن"),new LinearLayout.LayoutParams(0,-2,1f));Button gp=UiKit.addIconButton(this);gp.setContentDescription("افزودن مجموعه");gp.setOnClickListener(v->addVaultGroupDialog());gh.addView(gp,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));groups.addView(gh);
        groups.addView(UiKit.muted(this,"مجموعه جدید فقط از این لیست ساخته می‌شود."),UiKit.matchWrap(this,6,8));groupManagerList=new LinearLayout(this);groupManagerList.setOrientation(LinearLayout.VERTICAL);groups.addView(groupManagerList);root.addView(groups,UiKit.matchWrap(this,0,12));

        Button add=UiKit.primaryButton(this,"＋ مورد محرمانه جدید");
        add.setOnClickListener(v->addDialog());
        root.addView(add,UiKit.matchWrap(this,0,10));
        EditText search=field("جستجو در عنوان، مجموعه یا شناسه");
        search.setSingleLine(true);search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence x,int a,int b,int c){}public void onTextChanged(CharSequence x,int a,int b,int c){vaultQuery=x==null?"":x.toString().trim();render();}public void afterTextChanged(Editable e){}});
        root.addView(search,UiKit.matchWrap(this,0,14));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        renderGroups();render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private java.util.List<String> vaultGroupValues(){java.util.ArrayList<String> out=new java.util.ArrayList<>();java.util.Collections.addAll(out,NexaStore.defaultVaultGroups());for(String x:NexaStore.vaultGroups(this))if(!out.contains(x))out.add(x);for(NexaStore.VaultEntry x:NexaStore.vault(this))if(!out.contains(x.type))out.add(x.type);return out;}
    private boolean isDefaultGroup(String g){for(String x:NexaStore.defaultVaultGroups())if(x.equals(g))return true;return false;}
    private void renderGroups(){if(groupManagerList==null)return;groupManagerList.removeAllViews();for(String g:vaultGroupValues()){
        LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView name=UiKit.muted(this,"• "+g);name.setTextSize(14);row.addView(name,new LinearLayout.LayoutParams(0,-2,1f));
        if(!isDefaultGroup(g)){Button rename=UiKit.secondaryButton(this,"✎");rename.setContentDescription("ویرایش نام مجموعه "+g);rename.setOnClickListener(v->renameVaultGroupDialog(g));row.addView(rename,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));Button del=UiKit.secondaryButton(this,"🗑");del.setContentDescription("حذف مجموعه "+g);del.setOnClickListener(v->deleteVaultGroupDialog(g));row.addView(del,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));}
        groupManagerList.addView(row,UiKit.matchWrap(this,0,4));}}
    private void renameVaultGroupDialog(String oldName){EditText input=field("نام جدید");input.setText(oldName);new AlertDialog.Builder(this).setTitle("تغییر نام مجموعه").setView(input).setPositiveButton("ذخیره",(d,w)->{String n=input.getText().toString().trim();if(NexaStore.renameVaultGroup(this,oldName,n)){renderGroups();render();}else Toast.makeText(this,"نام جدید معتبر نیست یا تکراری است.",Toast.LENGTH_LONG).show();}).setNegativeButton("انصراف",null).show();}
    private void deleteVaultGroupDialog(String name){new AlertDialog.Builder(this).setTitle("حذف مجموعه؟").setMessage("موارد داخل این مجموعه حذف نمی‌شوند و به «سایر» منتقل می‌شوند.").setPositiveButton("حذف",(d,w)->{if(NexaStore.removeVaultGroup(this,name,"سایر")){renderGroups();render();}}).setNegativeButton("انصراف",null).show();}
    private void addVaultGroupDialog(){EditText input=field("نام مجموعه جدید");new AlertDialog.Builder(this).setTitle("مجموعه جدید").setView(input).setPositiveButton("افزودن",(d,w)->{String value=input.getText().toString().trim();if(value.isEmpty())return;NexaStore.addVaultGroup(this,value);renderGroups();}).setNegativeButton("انصراف",null).show();}

    private void addDialog() { editDialog(null); }

    private void editDialog(NexaStore.VaultEntry existing) {
        LinearLayout box=UiKit.dialogPanel(this);

        Spinner type=UiKit.styledSpinner(this);
        java.util.List<String> types=new java.util.ArrayList<>();
        java.util.Collections.addAll(types,NexaStore.defaultVaultGroups());
        for(String x:NexaStore.vaultGroups(this))if(!types.contains(x))types.add(x);
        for(NexaStore.VaultEntry x:NexaStore.vault(this))if(!types.contains(x.type))types.add(x.type);

        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,types){
            @Override public View getView(int position,View convert,android.view.ViewGroup parent){TextView v=(TextView)super.getView(position,convert,parent);v.setTextColor(UiKit.TEXT);v.setPadding(12,16,12,16);return v;}
            @Override public View getDropDownView(int position,View convert,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(position,convert,parent);v.setTextColor(UiKit.TEXT);v.setBackgroundColor(UiKit.CARD_2);v.setPadding(18,16,18,16);return v;}
        };
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);type.setAdapter(adapter);

        EditText title=field("عنوان؛ مثلاً حساب بانکی یا سایت");
        EditText username=field("نام کاربری / شناسه");
        EditText secret=field("رمز / اطلاعات محرمانه");
        secret.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);
        final boolean[] secretVisible={false};
        Button revealSecret=UiKit.secondaryButton(this,"👁");
        revealSecret.setContentDescription("نمایش یا پنهان کردن رمز");
        revealSecret.setOnClickListener(v->{
            secretVisible[0]=!secretVisible[0];
            int pos=secret.getSelectionStart();
            secret.setInputType(InputType.TYPE_CLASS_TEXT|(secretVisible[0]?InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD:InputType.TYPE_TEXT_VARIATION_PASSWORD));
            secret.setSelection(Math.max(0,Math.min(pos,secret.length())));
            revealSecret.setText(secretVisible[0]?"🙈":"👁");
        });
        EditText note=field("یادداشت");

        secret.setTextDirection(View.TEXT_DIRECTION_LTR);secret.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        username.setTextDirection(View.TEXT_DIRECTION_LTR);
        if(existing!=null){
            type.setSelection(Math.max(0,types.indexOf(existing.type)));
            title.setText(existing.title);username.setText(VaultCrypto.decrypt(existing.usernameEncrypted));
            secret.setText(VaultCrypto.decrypt(existing.secretEncrypted));note.setText(VaultCrypto.decrypt(existing.noteEncrypted));
        }
        box.addView(type);box.addView(UiKit.muted(this,"مجموعه جدید را از لیست مجموعه‌های Vault اضافه کن."),UiKit.matchWrap(this,4,6));box.addView(title);box.addView(username);
        LinearLayout secretRow=new LinearLayout(this);secretRow.setGravity(Gravity.CENTER_VERTICAL);secretRow.addView(secret,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams eyeLp=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));eyeLp.setMargins(UiKit.dp(this,6),0,0,0);secretRow.addView(revealSecret,eyeLp);
        box.addView(secretRow);box.addView(note);

        new AlertDialog.Builder(this)
                .setTitle(existing==null?"مورد محرمانه جدید":"ویرایش مورد محرمانه")
                .setMessage("برای کارت بانکی بهتر است رمز پویا، CVV2 و اطلاعاتی که امکان سوءاستفاده مستقیم دارند ذخیره نشوند.")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())return;

                    NexaStore.VaultEntry x=existing==null?new NexaStore.VaultEntry():existing;
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.usernameEncrypted=VaultCrypto.encrypt(username.getText().toString());
                    x.secretEncrypted=VaultCrypto.encrypt(secret.getText().toString());
                    x.noteEncrypted=VaultCrypto.encrypt(note.getText().toString());
                    x.updatedAt=System.currentTimeMillis();

                    if((!username.getText().toString().isEmpty() && x.usernameEncrypted.isEmpty()) ||
                       (!secret.getText().toString().isEmpty() && x.secretEncrypted.isEmpty())) {
                        Toast.makeText(this,"رمزگذاری انجام نشد؛ مورد ذخیره نشد.",Toast.LENGTH_LONG).show();
                        return;
                    }

                    if(existing==null)NexaStore.addVault(this,x);else NexaStore.updateVault(this,x);
                    NexaStore.addHistory(this,"Vault",(existing==null?"مورد جدید: ":"ویرایش مورد: ")+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        renderGroups();
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.VaultEntry> data=new java.util.ArrayList<>(NexaStore.vault(this));
        java.util.Collections.sort(data,(a,b)->Long.compare(b.updatedAt,a.updatedAt));
        if(!vaultQuery.isEmpty()){String q=vaultQuery.toLowerCase(java.util.Locale.ROOT);data.removeIf(x->{String u=VaultCrypto.decrypt(x.usernameEncrypted);return !(x.title+" "+x.type+" "+u).toLowerCase(java.util.Locale.ROOT).contains(q);});}

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,vaultQuery.isEmpty()?"هنوز چیزی در Vault ذخیره نشده.":"موردی مطابق جستجو پیدا نشد.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        java.util.Map<String,java.util.List<NexaStore.VaultEntry>> groups=new java.util.LinkedHashMap<>();
        for(NexaStore.VaultEntry x:data){
            if(!groups.containsKey(x.type))groups.put(x.type,new java.util.ArrayList<>());
            groups.get(x.type).add(x);
        }
        for(java.util.Map.Entry<String,java.util.List<NexaStore.VaultEntry>> group:groups.entrySet()){
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
            for(NexaStore.VaultEntry x:group.getValue()){
                LinearLayout c=UiKit.cardLayout(this);
                c.addView(UiKit.sectionTitle(this,"🔐 "+x.title));
                TextView secret=UiKit.muted(this,"••••••••");secret.setTextSize(16);
                secret.setTextDirection(View.TEXT_DIRECTION_LTR);
                secret.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
                secret.setGravity(Gravity.LEFT);
                c.addView(secret,UiKit.matchWrap(this,10,8));
                LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
                Button show=UiKit.secondaryButton(this,"👁 نمایش");
                final Runnable hide=()->secret.setText("••••••••");
                show.setOnClickListener(v->{
                    if(!authenticated){android.widget.Toast.makeText(this,"صندوق قفل است.",Toast.LENGTH_SHORT).show();return;}
                    String u=VaultCrypto.decrypt(x.usernameEncrypted), password=VaultCrypto.decrypt(x.secretEncrypted),n=VaultCrypto.decrypt(x.noteEncrypted);
                    // Separate values in a LTR view to prevent Persian bidi reordering.
                    secret.setText((u.isEmpty()?"":"شناسه: "+u+"\n")+(password.isEmpty()?"":"رمز: "+password+"\n")+(n.isEmpty()?"":"یادداشت: "+n));
                    secret.removeCallbacks(hide);secret.postDelayed(hide,15000);
                });
                Button copy=UiKit.secondaryButton(this,"⧉ کپی");
                copy.setOnClickListener(v->{if(!authenticated)return;
                    ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                    final String copied=VaultCrypto.decrypt(x.secretEncrypted);cm.setPrimaryClip(ClipData.newPlainText("Nexa",copied));
                    new android.os.Handler(getMainLooper()).postDelayed(()->{try{ClipData now=cm.getPrimaryClip();if(now!=null&&now.getItemCount()>0&&copied.contentEquals(now.getItemAt(0).coerceToText(this)))cm.setPrimaryClip(ClipData.newPlainText("Nexa",""));}catch(Exception ignored){}},30000L);
                    Toast.makeText(this,"رمز کپی شد؛ اگر تغییر نکند ۳۰ ثانیه دیگر از کلیپ‌بورد پاک می‌شود.",Toast.LENGTH_LONG).show();});
                TextView updated=UiKit.muted(this,"آخرین ویرایش: "+new java.text.SimpleDateFormat("yyyy/MM/dd  HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(x.updatedAt)));updated.setTextSize(12);c.addView(updated,UiKit.matchWrap(this,0,6));
                Button edit=UiKit.secondaryButton(this,"✎");edit.setContentDescription("ویرایش "+x.title);edit.setOnClickListener(v->editDialog(x));
                Button del=UiKit.secondaryButton(this,"🗑");del.setContentDescription("حذف "+x.title);
                del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف از Vault؟").setMessage(x.title)
                    .setPositiveButton("حذف",(d,w)->{NexaStore.removeVault(this,x.id);render();})
                    .setNegativeButton("انصراف",null).show());
                for(Button button:new Button[]{show,copy,edit,del})actions.addView(button,new LinearLayout.LayoutParams(0,-2,1f));
                c.addView(actions,UiKit.matchWrap(this,6,0));body.addView(c,UiKit.matchWrap(this,8,0));
            }
            list.addView(UiKit.collapsible(this,"vault_group_"+group.getKey(),group.getKey()+"  ("+group.getValue().size()+")","",6,false,body),UiKit.matchWrap(this,0,10));
        }
    }

}
