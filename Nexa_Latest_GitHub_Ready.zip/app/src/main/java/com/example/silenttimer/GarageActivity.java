package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class GarageActivity extends Activity {
    private LinearLayout list;
    private TextView overview;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));root.addView(UiKit.title(this,"Nexa Garage"),UiKit.matchWrap(this,0,14));LinearLayout hero=UiKit.colorfulCardLayout(this,4);hero.addView(UiKit.sectionTitle(this,"🚗 دفترچه خودرو و موتور"));hero.addView(UiKit.muted(this,"کیلومتر، سرویس، تعمیر، هزینه و سوخت را برای هر وسیله جدا نگه دار."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ وسیله جدید");add.setOnClickListener(v->addVehicle());hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));
        LinearLayout stats=UiKit.colorfulCardLayout(this,7);overview=UiKit.muted(this,"");stats.addView(UiKit.sectionTitle(this,"نمای کلی گاراژ"));stats.addView(overview,UiKit.matchWrap(this,6,0));root.addView(stats,UiKit.matchWrap(this,0,14));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private void addVehicle(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(32,8,32,0);EditText name=new EditText(this);name.setHint("نام وسیله؛ مثلاً ۲۰۷ من");Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"خودرو","موتور","سایر"}));EditText km=UiKit.styleField(this,new EditText(this),"کیلومتر فعلی");km.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(km);b.addView(name);b.addView(type);b.addView(km);new AlertDialog.Builder(this).setTitle("وسیله جدید").setView(b).setPositiveButton("ذخیره",(d,w)->{NexaStore.Vehicle v=new NexaStore.Vehicle();v.name=name.getText().toString().trim();v.type=String.valueOf(type.getSelectedItem());v.currentKm=NumberFormatUtil.intValue(km.getText());if(v.name.isEmpty())v.name=v.type;NexaStore.addVehicle(this,v);NexaStore.addHistory(this,"گاراژ","وسیله اضافه شد: "+v.name);render();}).setNegativeButton("انصراف",null).show();}
    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Vehicle> vs=NexaStore.vehicles(this);updateOverview(vs);if(vs.isEmpty()){TextView e=UiKit.muted(this,"هنوز وسیله‌ای ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}for(NexaStore.Vehicle v:vs){LinearLayout c=UiKit.colorfulCardLayout(this,4);c.addView(UiKit.sectionTitle(this,(v.type.equals("موتور")?"🏍️":"🚗")+"  "+v.name));c.addView(UiKit.muted(this,String.format(java.util.Locale.US,"%,d km",v.currentKm)),UiKit.matchWrap(this,6,6));String due=dueText(v);if(!due.isEmpty())c.addView(UiKit.muted(this,due),UiKit.matchWrap(this,0,8));Button open=UiKit.primaryButton(this,"باز کردن دفترچه");open.setOnClickListener(x->{Intent i=new Intent(this,VehicleActivity.class);i.putExtra("id",v.id);startActivity(i);});c.addView(open);list.addView(c,UiKit.matchWrap(this,0,12));}}
    private void updateOverview(List<NexaStore.Vehicle> vs){
        if(overview==null)return;long service=0,fuel=0;int due=0,soon=0;
        for(NexaStore.Vehicle v:vs){for(NexaStore.ServiceRecord r:NexaStore.servicesFor(this,v.id)){service+=r.cost;if(r.nextDueKm>0){int left=r.nextDueKm-v.currentKm;if(left<=0)due++;else if(left<=500)soon++;}}for(NexaStore.FuelRecord f:NexaStore.fuelsFor(this,v.id))fuel+=f.cost;}
        overview.setText("وسیله: "+vs.size()+"  •  موعد رسیده: "+due+"  •  نزدیک موعد: "+soon+"\nهزینه سرویس: "+money(service)+"  •  سوخت: "+money(fuel)+"  •  کل: "+money(service+fuel));
    }
    private String money(long n){return String.format(java.util.Locale.US,"%,d تومان",n);}

    private String dueText(NexaStore.Vehicle v){int best=Integer.MAX_VALUE;String cat="";for(NexaStore.ServiceRecord r:NexaStore.servicesFor(this,v.id)){if(r.nextDueKm>0){int left=r.nextDueKm-v.currentKm;if(left<best){best=left;cat=r.category;}}}if(best==Integer.MAX_VALUE)return "";return best<=0?"⚠ موعد "+cat+" رسیده":"⏳ "+cat+" تا "+best+" کیلومتر دیگر";}
}
