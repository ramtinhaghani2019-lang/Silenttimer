package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class GarageActivity extends Activity {
    private LinearLayout list;
    private String pendingVoiceTitle;
    private TextView overview;
    private LinearLayout metricsHost;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        pendingVoiceTitle=getIntent().getStringExtra("voice_title");
        build();
        if(getIntent().getBooleanExtra("quick_add",false)){
            getIntent().removeExtra("quick_add");
            list.postDelayed(()->addVehicle(),250);
        }
    }
    @Override protected void onResume(){super.onResume();render();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));root.addView(UiKit.title(this,"گاراژ نِکسا"),UiKit.matchWrap(this,0,8));
        root.addView(UiKit.featureHero(this,"vehicle","گاراژ هوشمند","وضعیت سرویس‌ها، کیلومتر و هزینه‌ها"),UiKit.matchWrap(this,0,12));
        Button add=UiKit.primaryButton(this,"＋ وسیله جدید");add.setOnClickListener(v->addVehicle());root.addView(add,UiKit.matchWrap(this,0,12));
        metricsHost=new LinearLayout(this);metricsHost.setOrientation(LinearLayout.VERTICAL);root.addView(metricsHost,UiKit.matchWrap(this,0,12));
        LinearLayout stats=UiKit.colorfulCardLayout(this,7);overview=UiKit.muted(this,"");stats.addView(UiKit.sectionTitle(this,"💳 هزینه‌های ثبت‌شده"));stats.addView(overview,UiKit.matchWrap(this,6,0));root.addView(stats,UiKit.matchWrap(this,0,14));
        root.addView(NexaGarageUi.sectionLabel(this,"وسایل نقلیه"));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private void addVehicle(){LinearLayout b=UiKit.dialogPanel(this);b.addView(NexaGarageUi.sectionLabel(this,"مشخصات وسیله"),UiKit.matchWrap(this,0,6));EditText name=UiKit.styleField(this,new EditText(this),"نام وسیله؛ مثلاً ۲۰۷ من");
        if(pendingVoiceTitle!=null){name.setText(pendingVoiceTitle);pendingVoiceTitle=null;}Spinner type=UiKit.styledSpinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"خودرو","موتور","سایر"}));EditText km=UiKit.styleField(this,new EditText(this),"کیلومتر فعلی");km.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(km);b.addView(name,UiKit.matchWrap(this,0,9));b.addView(type,UiKit.matchWrap(this,0,9));b.addView(km,UiKit.matchWrap(this,0,9));new AlertDialog.Builder(this).setTitle("وسیله جدید").setView(b).setPositiveButton("ذخیره",(d,w)->{NexaStore.Vehicle v=new NexaStore.Vehicle();v.name=name.getText().toString().trim();v.type=String.valueOf(type.getSelectedItem());v.currentKm=NumberFormatUtil.intValue(km.getText());if(v.name.isEmpty())v.name=v.type;NexaStore.addVehicle(this,v);NexaStore.addHistory(this,"گاراژ","وسیله اضافه شد: "+v.name);render();}).setNegativeButton("انصراف",null).show();}
    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Vehicle> vs=NexaStore.vehicles(this);updateOverview(vs);if(vs.isEmpty()){TextView e=UiKit.muted(this,"هنوز وسیله‌ای ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}for(NexaStore.Vehicle v:vs){String due=dueText(v);boolean isOverdue=due.startsWith("⚠");boolean isSoon=false;
            if(!isOverdue)for(NexaStore.ServiceRecord service:NexaStore.servicesFor(this,v.id)){int left=service.nextDueKm-v.currentKm;if(service.nextDueKm>0&&left>0&&left<=500)isSoon=true;}
            LinearLayout c=NexaGarageUi.vehicleCard(this,isOverdue,isSoon);
            c.addView(UiKit.sectionTitle(this,(v.type.equals("موتور")?"🏍️":v.type.equals("سایر")?"🛠️":"🚗")+"  "+v.name));
            c.addView(UiKit.muted(this,String.format(java.util.Locale.US,"کیلومتر فعلی: %,d km",v.currentKm)),UiKit.matchWrap(this,6,6));
            if(!due.isEmpty())c.addView(NexaGarageUi.state(this,due,isOverdue?UiKit.RED:(isSoon?UiKit.GOLD:UiKit.TEAL)),UiKit.matchWrap(this,0,9));
            Button open=UiKit.primaryButton(this,"باز کردن دفترچه");open.setOnClickListener(x->{Intent i=new Intent(this,VehicleActivity.class);i.putExtra("id",v.id);startActivity(i);});c.addView(open);list.addView(c,UiKit.matchWrap(this,0,12));}}
    private void updateOverview(List<NexaStore.Vehicle> vs){
        if(overview==null)return;long service=0,fuel=0;int due=0,soon=0;
        for(NexaStore.Vehicle v:vs){for(NexaStore.ServiceRecord r:NexaStore.servicesFor(this,v.id)){service+=r.cost;if(r.nextDueKm>0){int left=r.nextDueKm-v.currentKm;if(left<=0)due++;else if(left<=500)soon++;}}for(NexaStore.FuelRecord f:NexaStore.fuelsFor(this,v.id))fuel+=f.cost;}
        if(metricsHost!=null){metricsHost.removeAllViews();metricsHost.addView(NexaGarageUi.metrics(this,vs.size(),due,soon));}
        overview.setText("سرویس: "+money(service)+"\nسوخت: "+money(fuel)+"\nمجموع هزینه‌ها: "+money(service+fuel));
    }
    private String money(long n){return String.format(java.util.Locale.US,"%,d تومان",n);}

    private String dueText(NexaStore.Vehicle v){int best=Integer.MAX_VALUE;String cat="";for(NexaStore.ServiceRecord r:NexaStore.servicesFor(this,v.id)){if(r.nextDueKm>0){int left=r.nextDueKm-v.currentKm;if(left<best){best=left;cat=r.category;}}}if(best==Integer.MAX_VALUE)return "";return best<=0?"⚠ موعد "+cat+" رسیده":"⏳ "+cat+" تا "+best+" کیلومتر دیگر";}
}
