package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Voice recognition is user-triggered; recognizer is provided by Android, never a background listener. */
public final class VoiceQuickAddActivity extends Activity {
    private static final int RECOGNIZE=7218;
    private EditText transcript;
    private boolean committed=false;
    @Override public void onCreate(Bundle state){
        super.onCreate(state);UiKit.applyWindow(this);
        ScrollView sc=new ScrollView(this);sc.setBackground(UiKit.screenBackground(this));
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,22),UiKit.dp(this,18),UiKit.dp(this,22));
        root.setLayoutDirection(android.view.View.LAYOUT_DIRECTION_RTL);sc.addView(root);
        root.addView(UiKit.title(this,"ثبت صوتی در Nexa"),UiKit.matchWrap(this,0,16));
        root.addView(UiKit.muted(this,"بگو: ۵۰ میلیون بدهی به احمدی ثبت کن"),UiKit.matchWrap(this,0,10));
        transcript=UiKit.styleField(this,new EditText(this),"متن فرمان را ببین یا اصلاح کن");
        transcript.setMinLines(2);transcript.setGravity(Gravity.TOP|Gravity.RIGHT);
        root.addView(transcript,UiKit.matchWrap(this,0,12));
        Button listen=UiKit.primaryButton(this,"🎙  شروع صحبت");
        listen.setOnClickListener(v->listen());root.addView(listen,UiKit.matchWrap(this,0,9));
        Button interpret=UiKit.secondaryButton(this,"بررسی و تأیید فرمان");
        interpret.setOnClickListener(v->interpret());root.addView(interpret,UiKit.matchWrap(this,0,10));
        root.addView(UiKit.muted(this,"ثبت مالی فقط پس از تأیید نهایی انجام می‌شود. در صورت ابهام، متن را اصلاح کن."));
        setContentView(sc);
        if(state!=null)transcript.setText(state.getString("transcript",""));
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("transcript",transcript==null?"":transcript.getText().toString());
        super.onSaveInstanceState(out);
    }
    private void listen(){
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR");
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"fa-IR");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"فرمان فارسی خود را بیان کنید");
        try{startActivityForResult(i,RECOGNIZE);}catch(ActivityNotFoundException e){
            Toast.makeText(this,"موتور تشخیص گفتار در گوشی فعال نیست؛ فرمان را تایپ کن",Toast.LENGTH_LONG).show();
        }
    }
    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data);
        if(req!=RECOGNIZE||result!=RESULT_OK||data==null)return;
        ArrayList<String> text=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
        if(text==null||text.isEmpty())return;
        ArrayList<String> options=new ArrayList<>();
        for(String s:text){
            if(s!=null&&!s.trim().isEmpty() && !options.contains(s.trim()))options.add(s.trim());
        }
        if(options.size()==1)transcript.setText(options.get(0));
        else if(options.size()>1){
            new AlertDialog.Builder(this).setTitle("متن درست را انتخاب کن")
                    .setItems(options.toArray(new String[0]),(dialog,which)->transcript.setText(options.get(which)))
                    .setNegativeButton("ویرایش دستی",(dialog,which)->transcript.setText(options.get(0)))
                    .show();
        }
    }
    private void interpret(){
        String s=transcript.getText().toString().trim();
        if(s.isEmpty()){Toast.makeText(this,"ابتدا صحبت کن یا متن را بنویس",Toast.LENGTH_SHORT).show();return;}
        VoiceCommandParser.Finance f=VoiceCommandParser.finance(s);
        if(f!=null){confirmFinance(f);return;}
        VoiceCommandParser.FormDraft form=VoiceCommandParser.nonFinancialForm(s);
        if(form!=null){
            Intent i=new Intent(this,NexaListActivity.class);
            i.putExtra("quick_add",form.destination);
            i.putExtra("voice_title",form.title);
            startActivity(i);
            finish();
            return;
        }
        String reminder=VoiceCommandParser.reminderTitle(s);
        if(reminder!=null && !reminder.isEmpty()){
            Intent i=new Intent(this,ReminderEditActivity.class);
            i.putExtra("voice_title",reminder);
            i.putExtra("voice_repeat",VoiceCommandParser.spokenRecurrence(s));
            startActivity(i);
            return;
        }
        new AlertDialog.Builder(this).setTitle("فرمان نیاز به بررسی دارد")
                .setMessage("نوع عملیات یا مبلغ و طرف‌حساب به‌طور قطعی شناسایی نشد. هیچ اطلاعاتی ثبت نشده است. متن را اصلاح کن یا از فرم مربوط استفاده کن.")
                .setPositiveButton("اصلاح متن",null)
                .setNeutralButton("فرم ثبت سریع",(d,w)->startActivity(new Intent(this,QuickAddActivity.class)))
                .show();
    }
    private void confirmFinance(VoiceCommandParser.Finance f){
        NexaStore.LedgerParty match=null;
        int matches=0;
        String target=VoiceCommandParser.identity(f.party);
        for(NexaStore.LedgerParty p:NexaStore.ledgerParties(this)){
            if(target.equals(VoiceCommandParser.identity(p.name))){match=p;matches++;}
            else if(VoiceCommandParser.identity(p.name).contains(target)||target.contains(VoiceCommandParser.identity(p.name))){
                // Similar names should not automatically route money to the wrong person.
                new AlertDialog.Builder(this).setTitle("نام نزدیک به حساب موجود")
                        .setMessage("طرف‌حساب مشابه «"+p.name+"» وجود دارد. لطفاً ابتدا حساب درست را از صفحه حسابداری انتخاب کن.")
                        .setPositiveButton("حسابداری",(d,w)->startActivity(new Intent(this,LedgerActivity.class)))
                        .setNegativeButton("بازگشت",null).show();return;
            }
        }
        if(matches>1){Toast.makeText(this,"چند طرف‌حساب هم‌نام وجود دارد؛ ثبت متوقف شد",Toast.LENGTH_LONG).show();return;}
        final NexaStore.LedgerParty existing=match;
        String type="DEBT".equals(f.kind)?"بدهی من":"CREDIT".equals(f.kind)?"طلب من":
                "PAYMENT".equals(f.kind)?"پرداخت من":"دریافتی من";
        String preview="نوع: "+type+"\nمبلغ: "+PersianFinancialDisplay.amount(f.amount)+" تومان\nطرف‌حساب: "+f.party
                +"\nوضعیت: "+(existing==null?"ایجاد حساب جدید":"ثبت در حساب موجود")
                +"\n\nاگر جهت بدهی یا نام درست نیست، برگرد و متن را اصلاح کن.";
        new AlertDialog.Builder(this).setTitle("تأیید ثبت مالی").setMessage(preview)
                .setNegativeButton("اصلاح",null)
                .setPositiveButton("تأیید و ثبت",(d,w)->{
                    if(committed)return;
                    committed=true;
                    NexaStore.LedgerParty party=existing;
                    if(party==null){party=new NexaStore.LedgerParty();party.name=f.party;NexaStore.upsertLedgerParty(this,party);}
                    NexaStore.LedgerEntry entry=new NexaStore.LedgerEntry();entry.partyId=party.id;
                    entry.kind=f.kind;entry.amount=f.amount;entry.note="ثبت با تأیید فرمان صوتی";
                    NexaStore.addLedgerEntry(this,entry);
                    NexaStore.addHistory(this,"حسابداری","ثبت صوتی تأییدشده برای "+party.name);
                    Toast.makeText(this,"تراکنش با موفقیت ثبت شد",Toast.LENGTH_LONG).show();finish();
                }).show();
    }
}
