package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Central file/receipt manager. OCR intentionally not included. */
public class FileCenterActivity extends Activity {
    private LinearLayout usageBox,receiptBox,summaryBox;private Spinner sellerFilter;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,16),UiKit.dp(this,18),UiKit.dp(this,28));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
        root.addView(UiKit.title(this,"فایل‌ها و فاکتورها"),UiKit.matchWrap(this,0,6));
        root.addView(UiKit.muted(this,"مدیریت پیوست‌ها و فاکتورهای ذخیره‌شده در Nexa"),UiKit.matchWrap(this,0,15));
        summaryBox=new LinearLayout(this);summaryBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(summaryBox,UiKit.matchWrap(this,0,15));
        LinearLayout u=UiKit.colorfulCardLayout(this,1);
        u.addView(UiKit.sectionTitle(this,"🗂 فایل‌ها بر اساس بخش"),UiKit.matchWrap(this,0,8));
        usageBox=new LinearLayout(this);usageBox.setOrientation(LinearLayout.VERTICAL);u.addView(usageBox);
        root.addView(u,UiKit.matchWrap(this,0,15));
        LinearLayout r=UiKit.colorfulCardLayout(this,4);
        r.addView(UiKit.sectionTitle(this,"🧾 فاکتورهای خرید"),UiKit.matchWrap(this,0,5));
        r.addView(UiKit.muted(this,"برای نمایش فاکتورها فروشنده را انتخاب کنید."),UiKit.matchWrap(this,0,12));
        List<String> names=new ArrayList<>();names.add("همه فروشندگان");
        for(NexaStore.ShoppingSeller seller:NexaStore.sellers(this))names.add(seller.name);
        sellerFilter=UiKit.styledSpinner(this);
        sellerFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));
        sellerFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){renderReceipts();}
        });
        r.addView(sellerFilter,UiKit.matchWrap(this,0,14));
        receiptBox=new LinearLayout(this);receiptBox.setOrientation(LinearLayout.VERTICAL);r.addView(receiptBox);
        root.addView(r,UiKit.matchWrap(this,0,14));
        root.addView(UiKit.muted(this,"حذف نسخه ذخیره‌شده در Nexa، اصل تصویر را از گالری گوشی پاک نمی‌کند."),UiKit.matchWrap(this,0,0));
        setContentView(sc);renderUsage();renderReceipts();
    }
    private void renderSummary(){
        if(summaryBox==null)return;
        summaryBox.removeAllViews();
        summaryBox.addView(NexaArchiveUi.metrics(this,
            new String[]{"همه فایل‌ها","حجم استفاده‌شده","فاکتورهای خرید"},
            new String[]{String.valueOf(AttachmentStore.count(this)),
                AttachmentStore.humanSize(AttachmentStore.totalBytes(this)),
                String.valueOf(NexaStore.shoppingReceipts(this).size())},
            new int[]{UiKit.PURPLE,UiKit.BLUE,UiKit.GREEN}));
    }
    private void renderUsage(){
        renderSummary();
        usageBox.removeAllViews();
        String[] mods={"shopping","docs","garage","home","case","assets","general"};
        for(String module:mods){
            int n=AttachmentStore.countExistingModule(this,module);
            long bytes=AttachmentStore.bytesExistingModule(this,module);
            LinearLayout row=new LinearLayout(this);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            row.setGravity(Gravity.CENTER_VERTICAL);row.setMinimumHeight(UiKit.dp(this,64));
            row.setPadding(UiKit.dp(this,10),UiKit.dp(this,6),UiKit.dp(this,8),UiKit.dp(this,6));
            row.setBackground(UiKit.rounded(this,0xFF24213E,14));
            LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);
            words.addView(UiKit.sectionTitle(this,label(module)));
            words.addView(UiKit.muted(this,n+" فایل  ·  "+AttachmentStore.humanSize(bytes)),UiKit.matchWrap(this,3,0));
            row.addView(words,new LinearLayout.LayoutParams(0,-2,1f));
            if(n>0){
                Button d=UiKit.deleteIconButton(this);
                d.setContentDescription("حذف فایل‌های بخش "+label(module));
                d.setOnClickListener(v->confirmDelete(module));
                row.addView(d,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            }
            usageBox.addView(row,UiKit.matchWrap(this,0,8));
        }
        Button all=UiKit.secondaryButton(this,"حذف همه فایل‌های Nexa");
        all.setOnClickListener(v->confirmDelete("all"));
        usageBox.addView(all,UiKit.matchWrap(this,8,0));
    }
    private String label(String m){if("shopping".equals(m))return "فاکتورهای خرید";if("docs".equals(m))return "مدارک";if("garage".equals(m))return "گاراژ";if("home".equals(m))return "خانه";if("case".equals(m))return "پرونده‌ها";if("assets".equals(m))return "دارایی‌ها";return "سایر";}
    private void confirmDelete(String m){boolean all="all".equals(m);int n=all?AttachmentStore.count(this):AttachmentStore.countExistingModule(this,m);new AlertDialog.Builder(this).setTitle("حذف "+(all?"همه فایل‌ها":label(m))+"؟").setMessage(n+" فایل انتخاب شده. این کار برگشت‌پذیر نیست.").setPositiveButton("ادامه",(d,w)->new AlertDialog.Builder(this).setTitle("تأیید نهایی").setMessage("فایل اصلی Gallery حذف نمی‌شود. مطمئنی؟").setPositiveButton("بله، حذف کن",(d2,w2)->{if(all){AttachmentStore.deleteAll(this);NexaStore.clearShoppingReceipts(this);}else{AttachmentStore.deleteExistingModule(this,m);if("shopping".equals(m))NexaStore.clearShoppingReceipts(this);}renderUsage();renderReceipts();}).setNegativeButton("انصراف",null).show()).setNegativeButton("انصراف",null).show();}
    private void renderReceipts(){
        if(receiptBox==null)return;
        receiptBox.removeAllViews();
        String seller=sellerFilter==null||sellerFilter.getSelectedItem()==null?
            "همه فروشندگان":String.valueOf(sellerFilter.getSelectedItem());
        List<NexaStore.ShoppingReceipt> receipts=NexaStore.shoppingReceipts(this);
        int shown=0;
        for(NexaStore.ShoppingReceipt receipt:receipts){
            if(!"همه فروشندگان".equals(seller)&&!seller.equals(receipt.sellerName))continue;
            shown++;
            String info=PersianDateUtil.pretty(receipt.createdAt)+
                (receipt.sellerName.isEmpty()?"":"  ·  "+receipt.sellerName)+
                (receipt.amount>0?"  ·  "+NumberFormatUtil.grouped(receipt.amount)+" تومان":"");
            boolean exists=new File(receipt.localPath).exists();
            LinearLayout c=NexaArchiveUi.record(this,
                receipt.title.isEmpty()?"فاکتور خرید":receipt.title,info,
                exists?"ذخیره‌شده":"فایل پیدا نشد",exists?UiKit.GREEN:UiKit.RED);
            LinearLayout actions=new LinearLayout(this);
            actions.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);
            Button open=UiKit.openIconButton(this);
            open.setContentDescription("نمایش فاکتور "+receipt.title);
            open.setOnClickListener(v->openReceipt(receipt));
            actions.addView(open,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            Button del=UiKit.deleteIconButton(this);
            del.setContentDescription("حذف فاکتور "+receipt.title);
            del.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("حذف فاکتور؟").setMessage("فقط نسخه Nexa پاک می‌شود.")
                .setPositiveButton("حذف",(d,w)->{
                    AttachmentStore.deletePath(receipt.localPath);
                    NexaStore.removeShoppingReceipt(this,receipt.id);
                    renderUsage();renderReceipts();
                }).setNegativeButton("انصراف",null).show());
            actions.addView(del,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            c.addView(actions,UiKit.matchWrap(this,8,0));
            receiptBox.addView(c,UiKit.matchWrap(this,0,9));
        }
        if(shown==0){
            receiptBox.addView(UiKit.emptyState(this,"فاکتوری پیدا نشد","فروشنده دیگری را انتخاب کنید یا بعداً دوباره بررسی کنید."),UiKit.matchWrap(this,5,0));
        }
    }
    private void openReceipt(NexaStore.ShoppingReceipt r){File f=new File(r.localPath);if(!f.exists()){new AlertDialog.Builder(this).setMessage("فایل این فاکتور پیدا نشد.").setPositiveButton("بستن",null).show();return;}ZoomImageView img=new ZoomImageView(this);img.setImageBitmap(BitmapFactory.decodeFile(r.localPath));img.setAdjustViewBounds(true);new AlertDialog.Builder(this).setTitle(r.title).setView(img).setPositiveButton("بستن",null).show();}
}
