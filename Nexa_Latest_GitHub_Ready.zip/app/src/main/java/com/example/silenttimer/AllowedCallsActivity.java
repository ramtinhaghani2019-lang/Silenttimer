package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.role.RoleManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class AllowedCallsActivity extends Activity {
    private static final int PICK_CONTACT = 5501;
    private static final int REQ_CONTACTS = 5502;
    private static final int REQ_CALL_SCREENING_ROLE = 5503;

    private LinearLayout listContainer;
    private Switch enabledSwitch;
    private TextView countText;
    private TextView roleStatus;
    private TextView fullScreenStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        UiKit.applyWindow(this);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshList();
        refreshRoleStatus();
        refreshFullScreenStatus();
    }

    private void buildUi() {
        int[] p = UiKit.palette(this);

        LinearLayout screen = new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(
                UiKit.dp(this, 20),
                UiKit.dp(this, 18),
                UiKit.dp(this, 20),
                UiKit.dp(this, 18)
        );
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(header, UiKit.matchWrap(this, 0, 18));

        Button back = UiKit.secondaryButton(this, "‹");
        back.setTextSize(25f);
        back.setOnClickListener(v -> finish());
        header.addView(back);

        TextView title = UiKit.title(this, "تماس‌های مجاز");
        LinearLayout.LayoutParams tp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tp.setMargins(UiKit.dp(this, 12), 0, 0, 0);
        header.addView(title, tp);

        LinearLayout masterCard = UiKit.cardLayout(this);
        root.addView(masterCard, UiKit.matchWrap(this, 0, 14));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        masterCard.addView(top);

        TextView masterTitle = UiKit.sectionTitle(this, "زنگ خوردن تماس‌های مجاز");
        LinearLayout.LayoutParams mt =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        top.addView(masterTitle, mt);

        enabledSwitch = UiKit.styledSwitch(this);
        enabledSwitch.setChecked(AppPrefs.isAllowedCallsEnabled(this));
        enabledSwitch.setText(enabledSwitch.isChecked() ? "روشن" : "خاموش");
        top.addView(enabledSwitch);

        masterCard.addView(
                UiKit.muted(this, "در Silent یا Vibrate فقط شماره‌های این لیست می‌توانند با صدا زنگ بخورند."),
                UiKit.matchWrap(this, 8, 0)
        );

        enabledSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            AppPrefs.setAllowedCallsEnabled(this, isChecked);
            enabledSwitch.setText(isChecked ? "روشن" : "خاموش");
        });

        LinearLayout missedCard = UiKit.cardLayout(this);
        root.addView(missedCard, UiKit.matchWrap(this, 0, 14));
        missedCard.addView(UiKit.sectionTitle(this, "اعلان تماس از دست‌رفته"));
        missedCard.addView(
                UiKit.muted(this, "Nexa تماس پاسخ‌داده‌نشده را با اعلان واضح روی صفحه قفل نشان می‌دهد."),
                UiKit.matchWrap(this, 5, 10)
        );

        Switch missedEnabled = UiKit.styledSwitch(this);
        missedEnabled.setText("Missed Call Lock Screen Guard");
        missedEnabled.setChecked(AppPrefs.isMissedCallGuardEnabled(this));
        missedEnabled.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPrefs.setMissedCallGuardEnabled(this, isChecked));
        missedCard.addView(missedEnabled, UiKit.matchWrap(this, 0, 6));

        Switch showName = UiKit.styledSwitch(this);
        showName.setText("نمایش نام مخاطب");
        showName.setChecked(AppPrefs.isMissedCallShowName(this));
        showName.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPrefs.setMissedCallShowName(this, isChecked));
        missedCard.addView(showName, UiKit.matchWrap(this, 0, 4));

        Switch showNumber = UiKit.styledSwitch(this);
        showNumber.setText("نمایش شماره تماس");
        showNumber.setChecked(AppPrefs.isMissedCallShowNumber(this));
        showNumber.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPrefs.setMissedCallShowNumber(this, isChecked));
        missedCard.addView(showNumber, UiKit.matchWrap(this, 0, 4));

        Switch showTime = UiKit.styledSwitch(this);
        showTime.setText("نمایش زمان تماس");
        showTime.setChecked(AppPrefs.isMissedCallShowTime(this));
        showTime.setOnCheckedChangeListener((buttonView, isChecked) ->
                AppPrefs.setMissedCallShowTime(this, isChecked));
        missedCard.addView(showTime);

        LinearLayout fullScreenCard = UiKit.cardLayout(this);
        root.addView(fullScreenCard, UiKit.matchWrap(this, 0, 14));
        fullScreenCard.addView(UiKit.sectionTitle(this, "نمایش روی صفحه قفل"));
        fullScreenStatus = UiKit.muted(this, "");
        fullScreenCard.addView(fullScreenStatus, UiKit.matchWrap(this, 5, 10));
        Button fullScreenButton = UiKit.primaryButton(this, "اجازه نمایش تمام‌صفحه");
        fullScreenButton.setOnClickListener(v -> openFullScreenPermission());
        fullScreenCard.addView(fullScreenButton);

        LinearLayout roleCard = UiKit.cardLayout(this);
        root.addView(roleCard, UiKit.matchWrap(this, 0, 14));
        roleCard.addView(UiKit.sectionTitle(this, "دسترسی تماس هوشمند"));

        roleStatus = UiKit.muted(this, "");
        roleCard.addView(roleStatus, UiKit.matchWrap(this, 5, 12));

        Button roleButton = UiKit.primaryButton(this, "فعال‌سازی Call Screening");
        roleButton.setOnClickListener(v -> requestCallScreeningRole());
        roleCard.addView(roleButton);

        LinearLayout addCard = UiKit.cardLayout(this);
        root.addView(addCard, UiKit.matchWrap(this, 0, 14));
        addCard.addView(UiKit.sectionTitle(this, "افزودن شماره"));
        addCard.addView(
                UiKit.muted(this, "مخاطب را مستقیم از دفتر تلفن انتخاب کن یا دستی وارد کن."),
                UiKit.matchWrap(this, 5, 12)
        );

        Button pick = UiKit.primaryButton(this, "انتخاب از دفتر تلفن");
        pick.setOnClickListener(v -> pickContact());
        addCard.addView(pick, UiKit.matchWrap(this, 0, 8));

        Button manual = UiKit.secondaryButton(this, "افزودن دستی");
        manual.setOnClickListener(v -> showManualDialog());
        addCard.addView(manual);

        LinearLayout listCard = UiKit.cardLayout(this);
        root.addView(listCard, UiKit.matchWrap(this, 0, 14));

        LinearLayout listHead = new LinearLayout(this);
        listHead.setOrientation(LinearLayout.HORIZONTAL);
        listHead.setGravity(Gravity.CENTER_VERTICAL);
        listCard.addView(listHead);

        TextView listTitle = UiKit.sectionTitle(this, "شماره‌های ذخیره‌شده");
        LinearLayout.LayoutParams ltp =
                new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        listHead.addView(listTitle, ltp);

        countText = UiKit.muted(this, "");
        listHead.addView(countText);

        listContainer = new LinearLayout(this);
        listContainer.setOrientation(LinearLayout.VERTICAL);
        listCard.addView(listContainer, UiKit.matchWrap(this, 12, 0));

        root.addView(
                UiKit.muted(this, "بعد از پایان تماس، گوشی به Silent یا Vibrate قبلی برمی‌گردد."),
                UiKit.matchWrap(this, 0, 12)
        );

        screen.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
        ));

        LinearLayout bottom = UiKit.bottomNav(
                this, -1,
                v -> { startActivity(new Intent(this, MainActivity.class)); finish(); },
                v -> startActivity(new Intent(this, TodayActivity.class)),
                v -> startActivity(new Intent(this, QuickAddActivity.class)),
                v -> startActivity(new Intent(this, HistoryActivity.class))
        );
        LinearLayout.LayoutParams bottomLp = UiKit.matchWrap(this);
        bottomLp.setMargins(
                UiKit.dp(this, 16),
                0,
                UiKit.dp(this, 16),
                UiKit.dp(this, 12)
        );
        screen.addView(bottom, bottomLp);

        setContentView(screen);
        refreshList();
        refreshRoleStatus();
        refreshFullScreenStatus();
    }

    private void openFullScreenPermission() {
        if (Build.VERSION.SDK_INT < 34) {
            Toast.makeText(this, "روی این نسخه اندروید نیاز به مجوز جداگانه نیست.", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Intent intent = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT);
            intent.setData(android.net.Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "تنظیم نمایش تمام‌صفحه در این دستگاه پیدا نشد.", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshFullScreenStatus() {
        if (fullScreenStatus == null) return;
        boolean allowed = true;
        if (Build.VERSION.SDK_INT >= 34) {
            android.app.NotificationManager nm = (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            allowed = nm != null && nm.canUseFullScreenIntent();
        }
        fullScreenStatus.setTextColor(android.graphics.Color.parseColor(allowed ? "#40E0C4" : "#FFB86C"));
        fullScreenStatus.setText(allowed
                ? "✓ نمایش تمام‌صفحه مجاز است؛ Nexa می‌تواند کارت تماس ازدست‌رفته را روی قفل باز کند."
                : "برای نمایش واضح روی Lock Screen، اجازه Full-screen notifications را برای Nexa فعال کن.");
    }

    private void requestCallScreeningRole() {
        if (Build.VERSION.SDK_INT < 29) {
            Toast.makeText(this, "این قابلیت به Android 10 یا جدیدتر نیاز دارد.", Toast.LENGTH_SHORT).show();
            return;
        }

        RoleManager rm = getSystemService(RoleManager.class);

        if (!rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
            Toast.makeText(this, "Call Screening روی این دستگاه در دسترس نیست.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
            Toast.makeText(this, "دسترسی تماس هوشمند فعال است.", Toast.LENGTH_SHORT).show();
            return;
        }

        startActivityForResult(
                rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),
                REQ_CALL_SCREENING_ROLE
        );
    }

    private void refreshRoleStatus() {
        if (roleStatus == null) return;

        if (Build.VERSION.SDK_INT >= 29) {
            RoleManager rm = getSystemService(RoleManager.class);
            boolean active = rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)
                    && rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);

            roleStatus.setTextColor(android.graphics.Color.parseColor(active?"#40E0C4":"#CAC2DD"));
            roleStatus.setText(
                    active
                            ? "✓ فعال است؛ شماره‌های مجاز قبل از شروع زنگ تشخیص داده می‌شوند."
                            : "برای عملکرد مطمئن شماره‌های مجاز، این دسترسی را یک‌بار فعال کن."
            );
        } else {
            roleStatus.setText("روی این نسخه اندروید از روش قدیمی تماس استفاده می‌شود.");
        }
    }

    private void pickContact() {
        Intent i = new Intent(
                Intent.ACTION_PICK,
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        );
        startActivityForResult(i, PICK_CONTACT);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_CONTACT &&
                resultCode == RESULT_OK &&
                data != null &&
                data.getData() != null) {

            Cursor cursor = null;

            try {
                cursor = getContentResolver().query(
                        data.getData(),
                        new String[]{
                                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                                ContactsContract.CommonDataKinds.Phone.NUMBER
                        },
                        null,
                        null,
                        null
                );

                if (cursor != null && cursor.moveToFirst()) {
                    String name = cursor.getString(0);
                    String number = cursor.getString(1);

                    AppPrefs.addAllowedContact(this, name, number);
                    refreshList();

                    Toast.makeText(this, "مخاطب اضافه شد.", Toast.LENGTH_SHORT).show();
                }
            } finally {
                if (cursor != null) cursor.close();
            }
        }

        if (requestCode == REQ_CALL_SCREENING_ROLE) {
            refreshRoleStatus();

            if (checkSelfPermission(Manifest.permission.READ_CONTACTS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.READ_CONTACTS},
                        REQ_CONTACTS
                );
            }
        }
    }

    private void showManualDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(
                UiKit.dp(this, 18),
                UiKit.dp(this, 8),
                UiKit.dp(this, 18),
                0
        );

        EditText name = new EditText(this);
        name.setHint("نام");
        name.setSingleLine(true);
        box.addView(name);

        EditText number = new EditText(this);
        number.setHint("شماره تماس");
        number.setInputType(InputType.TYPE_CLASS_PHONE);
        number.setSingleLine(true);
        box.addView(number);

        new AlertDialog.Builder(this)
                .setTitle("افزودن شماره")
                .setView(box)
                .setPositiveButton("افزودن", (dialog, which) -> {
                    String n = number.getText().toString().trim();
                    if (!n.isEmpty()) {
                        AppPrefs.addAllowedContact(this, name.getText().toString(), n);
                        refreshList();
                    }
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void refreshList() {
        if (listContainer == null) return;

        listContainer.removeAllViews();

        List<AppPrefs.ContactEntry> list = AppPrefs.getAllowedContacts(this);
        countText.setText(list.size() + " مخاطب");

        if (list.isEmpty()) {
            TextView empty = UiKit.muted(this, "هنوز مخاطبی اضافه نشده.");
            empty.setGravity(Gravity.CENTER);
            listContainer.addView(empty);
            return;
        }

        for (int i = 0; i < list.size(); i++) {
            AppPrefs.ContactEntry entry = list.get(i);

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(
                    UiKit.dp(this, 12),
                    UiKit.dp(this, 10),
                    UiKit.dp(this, 12),
                    UiKit.dp(this, 10)
            );
            row.setBackground(UiKit.field(this));

            LinearLayout textBox = new LinearLayout(this);
            textBox.setOrientation(LinearLayout.VERTICAL);

            LinearLayout.LayoutParams textParams =
                    new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
            row.addView(textBox, textParams);

            TextView name = UiKit.sectionTitle(
                    this,
                    entry.name.trim().isEmpty() ? "بدون نام" : entry.name
            );
            name.setTextSize(15f);
            textBox.addView(name);

            TextView number = UiKit.muted(this, entry.number);
            number.setTextDirection(View.TEXT_DIRECTION_LTR);
            number.setGravity(Gravity.LEFT);
            textBox.addView(number);

            final int index = i;

            Button remove = UiKit.secondaryButton(this, "حذف");
            remove.setMinWidth(UiKit.dp(this, 70));
            remove.setOnClickListener(v -> {
                AppPrefs.removeAllowedContact(this, index);
                refreshList();
            });
            row.addView(remove);

            listContainer.addView(
                    row,
                    UiKit.matchWrap(this, i == 0 ? 0 : 8, 0)
            );
        }
    }
}
