package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Four recently opened destinations; stores only class names, never user content. */
final class ModuleRecentPolicy {
    private ModuleRecentPolicy(){}
    static final int LIMIT=4;
    static List<String> read(String stored){
        ArrayList<String> values=new ArrayList<>();
        if(stored==null||stored.trim().isEmpty())return Collections.unmodifiableList(values);
        for(String part:stored.split("\\|")){
            String clean=part.trim();
            if(clean.isEmpty()||values.contains(clean))continue;
            values.add(clean);
            if(values.size()==LIMIT)break;
        }
        return Collections.unmodifiableList(values);
    }
    static String opened(String stored,String destination){
        if(destination==null||destination.trim().isEmpty())return join(read(stored));
        ArrayList<String> updated=new ArrayList<>();
        updated.add(destination.trim());
        for(String old:read(stored)){
            if(!updated.contains(old))updated.add(old);
            if(updated.size()==LIMIT)break;
        }
        return join(updated);
    }
    private static String join(List<String> items){
        StringBuilder result=new StringBuilder();
        for(String item:items){if(result.length()>0)result.append('|');result.append(item);}
        return result.toString();
    }
}
