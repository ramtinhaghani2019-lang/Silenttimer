package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Stateless native presentation helpers for Focus and Silent profiles. */
final class NexaFocusUi {
    private NexaFocusUi() { }

    static HorizontalScrollView metrics(Context c, int profiles, int activeSchedules, int allSchedules) {
        HorizontalScrollView scroll=new HorizontalScrollView(c);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(false);
        LinearLayout row=new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.addView(metric(c,"پروفایل‌ها",String.valueOf(profiles),UiKit.PURPLE));
        row.addView(metric(c,"زمان‌بندی فعال",String.valueOf(activeSchedules),UiKit.GREEN));
        row.addView(metric(c,"کل زمان‌بندی‌ها",String.valueOf(allSchedules),UiKit.BLUE));
        scroll.addView(row);
        scroll.setContentDescription("خلاصه وضعیت تمرکز و پروفایل‌های سکوت");
        return scroll;
    }

    private static View metric(Context c,String name,String value,int color) {
        LinearLayout tile=UiKit.financialMetric(c,name,value,color);
        tile.setMinimumHeight(UiKit.dp(c,85));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(UiKit.dp(c,148),-2);
        lp.setMargins(UiKit.dp(c,3),0,UiKit.dp(c,7),0);
        tile.setLayoutParams(lp);
        return tile;
    }

    static LinearLayout record(Context c,String symbol,String name,String description,int tone) {
        LinearLayout card=UiKit.cardLayout(c);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setMinimumHeight(UiKit.dp(c,116));
        card.setBackground(UiKit.colorfulCard(c,tone==UiKit.GREEN?3:tone==UiKit.BLUE?2:5));
        LinearLayout top=new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView icon=new TextView(c);icon.setText(symbol);icon.setTextSize(22f);
        icon.setGravity(Gravity.CENTER);icon.setBackground(UiKit.rounded(c,UiKit.CARD_2,14));
        top.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(c,45),UiKit.dp(c,45)));
        LinearLayout text=new LinearLayout(c);text.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams t=new LinearLayout.LayoutParams(0,-2,1f);
        t.setMargins(UiKit.dp(c,9),0,0,0);
        TextView title=UiKit.sectionTitle(c,name);title.setMaxLines(2);text.addView(title);
        TextView subtitle=UiKit.muted(c,description);subtitle.setMaxLines(3);
        text.addView(subtitle,UiKit.matchWrap(c,3,0));top.addView(text,t);
        card.addView(top);
        card.setContentDescription(name+"، "+description);
        return card;
    }

    static TextView section(Context c,String title){
        TextView t=UiKit.sectionTitle(c,title);
        t.setTextSize(17f);
        t.setPadding(0,UiKit.dp(c,5),0,UiKit.dp(c,6));
        return t;
    }

    static LinearLayout empty(Context c,String title,String subtitle) {
        LinearLayout card=UiKit.cardLayout(c);
        card.setGravity(Gravity.CENTER);
        card.setMinimumHeight(UiKit.dp(c,112));
        TextView heading=UiKit.sectionTitle(c,title);heading.setGravity(Gravity.CENTER);
        card.addView(heading);
        TextView info=UiKit.muted(c,subtitle);info.setGravity(Gravity.CENTER);
        card.addView(info,UiKit.matchWrap(c,7,0));
        return card;
    }

    static TextView status(Context c,String label,int color){
        TextView tag=UiKit.statusBadge(c,label,color);
        tag.setTextColor(color);
        tag.setTextSize(12f);
        tag.setMinHeight(UiKit.dp(c,34));
        tag.setContentDescription("وضعیت: "+label);
        return tag;
    }
}
