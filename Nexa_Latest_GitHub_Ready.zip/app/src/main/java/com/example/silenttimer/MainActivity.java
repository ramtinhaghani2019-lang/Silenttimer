package com.example.silenttimer;
import android.provider.Settings;
import android.os.PowerManager;
import android.app.NotificationManager;
import android.app.AlarmManager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.Manifest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_APP_UNLOCK=810;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean startupDone=false;
    private boolean permissionRepairShown=false;
    private boolean awaitingUnlock=false;
    private RingTimerView ring;
    private TextView heroTime,heroState,heroSub,todaySummary,attentionSummary,nextReminderSummary;
    private LinearLayout attentionCard;
    private TextView financeDebtValue,financeCreditValue;
    private long lastOverviewRefresh=0L;
    private long lastFinanceRefresh=0L;

    private final Runnable ticker=new Runnable(){
        @Override public void run(){
            refresh();
            handler.postDelayed(this,1000);
        }
    };

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        AppPrefs.applyLaunchSafetyMigration(this);
        continueStartup();
    }

    private void continueStartup(){
        if(startupDone||isFinishing())return;
        if(NexaStore.lockEnabled(this)&&!SecurityGate.isUnlocked()){
            if(!awaitingUnlock){
                awaitingUnlock=true;
                startActivityForResult(new Intent(this,UnlockActivity.class),REQ_APP_UNLOCK);
            }
            return;
        }
        startupDone=true;
        boolean first=!AppPrefs.isSetupCompleted(this);
        if(!first)ensureMonitor();
        build();
        if(!NexaStore.accountConfigured(this)){
            startActivityForResult(new Intent(this,AccountSetupActivity.class),811);
        }else if(first){
            startPermissionSetup();
        }
    }

    private void startPermissionSetup(){
        Intent i=new Intent(this,SettingsActivity.class);
        i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
        startActivity(i);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==REQ_APP_UNLOCK){
            awaitingUnlock=false;
            if(result==RESULT_OK&&SecurityGate.isUnlocked()) continueStartup();
            else finish();
            return;
        }
        if(request==811){
            if(!NexaStore.accountConfigured(this)){
                // Keep setup mandatory without saving an incomplete/invalid profile.
                finish();return;
            }
            if(!AppPrefs.isSetupCompleted(this))startPermissionSetup();
        }
    }

    @Override protected void onResume(){
        super.onResume();
        lastFinanceRefresh=0;
        lastOverviewRefresh=0;
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        TodayNotificationManager.refresh(this);
        handler.postDelayed(this::checkCriticalPermissions,450);
    }

    /**
     * Special Android permissions cannot legally be made permanent by an app.
     * Nexa therefore verifies the real OS state on every foreground entry and,
     * if Android/One UI has revoked one, opens the existing guided repair flow.
     */
    private void checkCriticalPermissions(){
        if(isFinishing()||!AppPrefs.isSetupCompleted(this)||permissionRepairShown)return;
        NotificationManager nm=(NotificationManager)getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        AlarmManager am=(AlarmManager)getSystemService(android.content.Context.ALARM_SERVICE);
        PowerManager pm=(PowerManager)getSystemService(android.content.Context.POWER_SERVICE);
        boolean notifications=Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED;
        boolean exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms();
        boolean full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent();
        boolean battery=pm.isIgnoringBatteryOptimizations(getPackageName());
        boolean dnd=nm.isNotificationPolicyAccessGranted();
        if(notifications&&exact&&full&&battery&&dnd)return;
        permissionRepairShown=true;
        new android.app.AlertDialog.Builder(this)
            .setTitle("یک دسترسی Nexa غیرفعال شده")
            .setMessage("Android یا One UI یکی از دسترسی‌های ضروری هشدارها را غیرفعال کرده است. Nexa خودش هیچ دسترسی تأییدشده‌ای را حذف نمی‌کند. برای حفظ هشدار دارو، یادآورها و Lock Screen، وضعیت واقعی سیستم را دوباره تأیید کن.")
            .setPositiveButton("بررسی و فعال‌سازی",(d,w)->{Intent i=new Intent(this,SettingsActivity.class);i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);startActivity(i);})
            .setNegativeButton("بعداً",null)
            .show();
    }

    @Override protected void onPause(){
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    private void build(){
        LinearLayout screen=new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);

        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,42));
        sc.addView(root);

        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout hb=new LinearLayout(this);
        hb.setOrientation(LinearLayout.VERTICAL);
        head.addView(hb,new LinearLayout.LayoutParams(0,-2,1f));

        TextView logo=UiKit.title(this,"Nexa");
        logo.setTextSize(29);
        hb.addView(logo);
        hb.addView(UiKit.muted(this,"دستیار هوشمند شخصی • "+VersionUtil.name(this)));

        Button mic=UiKit.iconButton(this,"🎙","ثبت با صدا",UiKit.TEAL);
        mic.setContentDescription("ثبت با صدا");
        mic.setOnClickListener(v->startActivity(new Intent(this,VoiceQuickAddActivity.class)));
        head.addView(mic,new LinearLayout.LayoutParams(UiKit.dp(this,49),UiKit.dp(this,49)));
        Button quick=UiKit.iconButton(this,"＋","ثبت سریع",UiKit.GREEN);
        quick.setTextSize(24);
        quick.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        head.addView(quick,new LinearLayout.LayoutParams(UiKit.dp(this,49),UiKit.dp(this,49)));

        Button settings=UiKit.iconButton(this,"⚙","تنظیمات",UiKit.GOLD);
        settings.setTextSize(21);
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        head.addView(settings,new LinearLayout.LayoutParams(UiKit.dp(this,49),UiKit.dp(this,49)));

        root.addView(head,UiKit.matchWrap(this,0,10));

        LinearLayout hero=UiKit.accentCardLayout(this);
        // Compact information-first homepage; the old 150dp image was decorative only.
        heroState=UiKit.muted(this,"");heroState.setGravity(Gravity.CENTER);hero.addView(heroState);
        heroTime=UiKit.title(this,"");heroTime.setTextSize(17);heroTime.setGravity(Gravity.CENTER);hero.addView(heroTime,UiKit.matchWrap(this,4,2));
        heroSub=UiKit.muted(this,"");heroSub.setGravity(Gravity.CENTER);hero.addView(heroSub);
        ring=new RingTimerView(this);ring.setVisibility(View.GONE);
        root.addView(hero,UiKit.matchWrap(this,0,12));

        LinearLayout quickTimers=new LinearLayout(this);
        quickTimers.setOrientation(LinearLayout.HORIZONTAL);
        addQuick(quickTimers,"15 دقیقه",15);
        addQuick(quickTimers,"30 دقیقه",30);
        addQuick(quickTimers,"1 ساعت",60);
        root.addView(quickTimers,UiKit.matchWrap(this,0,12));

        Button quickAdd=UiKit.primaryButton(this,"＋ ثبت سریع در Nexa");
        quickAdd.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        // New item action already exists in the top bar; avoid duplicating a full-width button.

        LinearLayout today=UiKit.colorfulCardLayout(this,1);
        today.addView(UiKit.sectionTitle(this,"✦ امروز در Nexa"));
        todaySummary=UiKit.muted(this,"");
        today.addView(todaySummary,UiKit.matchWrap(this,7,4));
        nextReminderSummary=UiKit.muted(this,"");
        nextReminderSummary.setTextSize(12.5f);
        nextReminderSummary.setMaxLines(2);
        nextReminderSummary.setVisibility(View.GONE);
        today.addView(nextReminderSummary,UiKit.matchWrap(this,4,4));
        Button openToday=UiKit.secondaryButton(this,"باز کردن Nexa Today");
        openToday.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        // The whole Today card is tappable; avoid redundant button.
        today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        root.addView(today,UiKit.matchWrap(this,0,8));

        LinearLayout attention=UiKit.colorfulCardLayout(this,3);
        attentionCard=attention;
        attention.addView(UiKit.sectionTitle(this,"⚡ نیازمند توجه"));
        attentionSummary=UiKit.muted(this,"");
        attention.addView(attentionSummary,UiKit.matchWrap(this,7,10));
        LinearLayout attentionActions=new LinearLayout(this);
        attentionActions.setOrientation(LinearLayout.HORIZONTAL);
        Button attentionToday=UiKit.secondaryButton(this,"امروز");
        attentionToday.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        Button attentionTimeline=UiKit.secondaryButton(this,"Timeline");
        attentionTimeline.setOnClickListener(v->startActivity(new Intent(this,TimelineActivity.class)));
        attentionActions.addView(attentionToday,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams atl=new LinearLayout.LayoutParams(0,-2,1f);atl.setMargins(UiKit.dp(this,8),0,0,0);
        attentionActions.addView(attentionTimeline,atl);
        // This card is informational; relevant feature shortcuts are directly below.
        root.addView(attention,UiKit.matchWrap(this,0,9));

        // Two clearly separated balances: no long bidirectional string or awkward wrapping.
        LinearLayout financeRow=new LinearLayout(this);
        financeRow.setOrientation(LinearLayout.HORIZONTAL);
        financeRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout debtCard=UiKit.colorfulCardLayout(this,4);
        debtCard.addView(UiKit.muted(this,"بدهی من"));
        financeDebtValue=UiKit.sectionTitle(this,"۰ تومان");
        financeDebtValue.setTextColor(UiKit.RED);
        financeDebtValue.setTextSize(14f);
        financeDebtValue.setMaxLines(3);
        debtCard.addView(financeDebtValue,UiKit.matchWrap(this,4,0));
        debtCard.setContentDescription("خلاصه بدهی‌ها؛ ورود به حسابداری");
        debtCard.setOnClickListener(v->startActivity(new Intent(this,LedgerActivity.class)));
        financeRow.addView(debtCard,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout creditCard=UiKit.colorfulCardLayout(this,4);
        creditCard.addView(UiKit.muted(this,"طلب من"));
        financeCreditValue=UiKit.sectionTitle(this,"۰ تومان");
        financeCreditValue.setTextColor(UiKit.GOLD);
        financeCreditValue.setTextSize(14f);
        financeCreditValue.setMaxLines(3);
        creditCard.addView(financeCreditValue,UiKit.matchWrap(this,4,0));
        creditCard.setContentDescription("خلاصه طلب‌ها؛ ورود به حسابداری");
        creditCard.setOnClickListener(v->startActivity(new Intent(this,LedgerActivity.class)));
        LinearLayout.LayoutParams creditParams=new LinearLayout.LayoutParams(0,-2,1f);
        creditParams.setMargins(UiKit.dp(this,8),0,0,0);
        financeRow.addView(creditCard,creditParams);
        root.addView(financeRow,UiKit.matchWrap(this,0,8));

        root.addView(UiKit.sectionTitle(this,"دسترسی سریع"),UiKit.matchWrap(this,2,7));
        addFeatureRow(root,
                new Feature("✦","امروز","",TodayActivity.class,1),
                new Feature("📅","یادآورها","",RemindersActivity.class,1));
        addFeatureRow(root,
                new Feature("💰","حسابداری","",LedgerActivity.class,1),
                new Feature("🛒","فهرست‌ها","",NexaListActivity.class,3));
        Button all=UiKit.secondaryButton(this,"☰  همه بخش‌ها و ابزارها");
        all.setOnClickListener(v->showAllFeatures());
        root.addView(all,UiKit.matchWrap(this,4,10));

        LinearLayout bottom=UiKit.bottomNav(
                this,0,
                v->{},
                v->startActivity(new Intent(this,TodayActivity.class)),
                v->startActivity(new Intent(this,QuickAddActivity.class)),
                v->startActivity(new Intent(this,TimelineActivity.class))
        );
        LinearLayout.LayoutParams bp=UiKit.matchWrap(this);
        bp.setMargins(UiKit.dp(this,16),0,UiKit.dp(this,16),UiKit.dp(this,12));
        // Keep the complete home dashboard in a weighted scrolling region.
        // Regression in Build 180: only the bottom navigation was attached to
        // screen, leaving the dashboard off-screen and the rest visually blank.
        attachHomeContent(screen, sc, bottom, bp);

        setContentView(screen);
        refresh();
    }

    // Package-private for an Android instrumentation regression test.  The
    // content MUST be added before navigation, otherwise the app opens empty.
    static void attachHomeContent(LinearLayout screen, ScrollView sc, View bottom,
                                  LinearLayout.LayoutParams bottomParams){
        if(screen==null || sc==null || bottom==null || bottomParams==null)
            throw new IllegalArgumentException("Home layout is incomplete");
        if(screen.getOrientation()!=LinearLayout.VERTICAL)
            throw new IllegalArgumentException("Home needs vertical layout");
        if(sc.getChildCount()==0)
            throw new IllegalArgumentException("Home dashboard has no content");
        screen.addView(sc,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,0,1f));
        screen.addView(bottom,bottomParams);
    }

    private void showAllFeatures(){
        final String[] names={"دارو و سلامت","دارایی‌ها","قبوض و اقساط","اسناد و مدارک",
                "سرویس خودرو","سرویس خانه","پرونده‌ها","هواشناسی",
                "صدا و اعلان‌ها","باتری و شارژ","امنیت و حریم خصوصی","اضطراری",
                "تنظیمات","جستجوی سراسری","خط زمانی","سوابق","فایل‌ها","دفتر مشترک"};
        final String[] icons={"♧","◇","▤","▣","⚙","⌂","▦","☁","♫","ϟ","♢","✚","⚙","⌕","◷","☷","▣","♙"};
        final Class<?>[] screens={MedicineActivity.class,AssetsActivity.class,BillsActivity.class,DocsActivity.class,
                GarageActivity.class,HomeCareActivity.class,CaseActivity.class,WeatherActivity.class,
                SilentHubActivity.class,BatteryGuardActivity.class,VaultActivity.class,EmergencyActivity.class,
                SettingsActivity.class,SearchActivity.class,TimelineActivity.class,HistoryActivity.class,FileCenterActivity.class,SharedEntitiesActivity.class};
        LinearLayout list=UiKit.dialogPanel(this);
        list.setPadding(UiKit.dp(this,10),UiKit.dp(this,8),UiKit.dp(this,10),UiKit.dp(this,8));
        ScrollView scroll=new ScrollView(this);
        scroll.setFillViewport(false);
        scroll.addView(list);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("همه بخش‌ها")
            .setView(scroll).setNegativeButton("بستن",null).create();
        for(int i=0;i<names.length;i+=2){
            LinearLayout row=new LinearLayout(this);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            for(int j=i;j<Math.min(i+2,names.length);j++){
                final int index=j;
                Button tile=UiKit.secondaryButton(this,icons[j]+"  "+names[j]);
                tile.setTextSize(13f);
                tile.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
                tile.setSingleLine(false);
                tile.setMinHeight(UiKit.dp(this,55));
                tile.setOnClickListener(v->{dialog.dismiss();startActivity(new Intent(this,screens[index]));});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
                lp.setMargins(UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3));
                row.addView(tile,lp);
            }
            list.addView(row,UiKit.matchWrap(this));
        }
        dialog.setOnShowListener(d->{
            android.view.Window w=dialog.getWindow();
            if(w!=null)w.setLayout(getResources().getDisplayMetrics().widthPixels-UiKit.dp(this,28),
                (int)(getResources().getDisplayMetrics().heightPixels*.78f));
        });
        dialog.show();
    }

    private static final class Feature{
        String icon,title,sub;
        Class<?> cls;
        int v;
        Feature(String i,String t,String s,Class<?>c,int x){
            icon=i;title=t;sub=s;cls=c;v=x;
        }
    }

    private void addFeatureRow(LinearLayout root,Feature a,Feature b){
        if(a==null && b==null)return;
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        if(a!=null) row.addView(tile(a),tileLp(true));
        if(b!=null) row.addView(tile(b),tileLp(false));
        root.addView(row,UiKit.matchWrap(this,0,10));
    }

    private LinearLayout.LayoutParams tileLp(boolean first){
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
        if(first)p.setMargins(0,0,UiKit.dp(this,5),0);
        else p.setMargins(UiKit.dp(this,5),0,0,0);
        return p;
    }

    private View tile(Feature f){
        LinearLayout c=UiKit.colorfulCardLayout(this,f.v);
        c.setGravity(Gravity.CENTER);c.setMinimumHeight(UiKit.dp(this,72));

        TextView icon=UiKit.title(this,f.icon);
        icon.setTextSize(21);
        icon.setGravity(Gravity.CENTER);
        c.addView(icon);

        TextView t=UiKit.sectionTitle(this,f.title);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(15);
        c.addView(t,UiKit.matchWrap(this,4,1));

        // Descriptions are available within each destination; tiles only show their name.

        c.setOnClickListener(v->startActivity(new Intent(this,f.cls)));
        return c;
    }

    private void addQuick(LinearLayout row,String text,int min){
        TextView chip=UiKit.chip(this,text,false);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
        p.setMargins(UiKit.dp(this,4),0,UiKit.dp(this,4),0);
        row.addView(chip,p);

        chip.setOnClickListener(v->{
            if(!AppPrefs.isSetupCompleted(this)){
                Intent i=new Intent(this,SettingsActivity.class);
                i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
                startActivity(i);
                return;
            }

            Intent i=new Intent(this,SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_START);
            i.putExtra(SilentTimerService.EXTRA_MINUTES,min);
            i.putExtra(SilentTimerService.EXTRA_TARGET_MODE,AudioManager.RINGER_MODE_SILENT);

            try{
                if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
                else startService(i);
            }catch(Exception ignored){}

            Toast.makeText(this,"تایمر شروع شد.",Toast.LENGTH_SHORT).show();
        });
    }

    private void refresh(){
        if(heroTime==null)return;

        long now=System.currentTimeMillis();
        long end=AppPrefs.getEndAt(this);
        long start=AppPrefs.getStartAt(this);

        if(end>now){
            long rem=end-now,sec=rem/1000,h=sec/3600,m=(sec%3600)/60,s=sec%60;
            heroState.setText("● تایمر فعال");
            heroTime.setText(h>0
                    ?String.format(Locale.US,"%02d:%02d:%02d",h,m,s)
                    :String.format(Locale.US,"%02d:%02d",m,s));
            heroSub.setText(
                    (AppPrefs.getTargetRingerMode(this)==AudioManager.RINGER_MODE_VIBRATE?"لرزش":"بی‌صدا")+
                            " • پایان "+
                            new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(end))
            );
            float prog=0;
            if(start>0&&end>start)prog=1f-(float)rem/(float)(end-start);
            ring.setProgress(prog);
        }else{
            if(!"◉ آماده برای تمرکز".contentEquals(heroState.getText()))
                heroState.setText("◉ آماده برای تمرکز");
            if(!"یک بازه تمرکز انتخاب کنید".contentEquals(heroTime.getText()))
                heroTime.setText("یک بازه تمرکز انتخاب کنید");
            if(!"با دکمه‌های ۱۵، ۳۰ یا ۶۰ دقیقه شروع کنید".contentEquals(heroSub.getText()))
                heroSub.setText("با دکمه‌های ۱۵، ۳۰ یا ۶۰ دقیقه شروع کنید");
            ring.setProgress(0);
        }

        // Timer changes every second, but the dashboard's stored collections do not.
        // Re-read them on foreground entry and at a modest interval to avoid jank.
        if(!HomeRefreshGate.due(now,lastOverviewRefresh,HomeRefreshGate.OVERVIEW_MS))return;
        lastOverviewRefresh=now;
        int upcoming=0;
        NexaStore.Reminder closest=null;
        long closestDue=Long.MAX_VALUE;
        List<NexaStore.Reminder> storedReminders=NexaStore.reminders(this);
        for(NexaStore.Reminder r:storedReminders){
            if(!r.active || r.done || r.whenMillis<=0)continue;
            // Recurring reminders with a historical original date can have
            // future occurrences even before their original record is advanced.
            long due=r.whenMillis;
            if(due<=now && ReminderRecurrence.isRecurring(r.recurrence))
                due=ReminderRecurrence.after(r.whenMillis,r.recurrence,now);
            if(due>now){
                if(due<=now+24L*60L*60L*1000L)upcoming++;
                if(due<closestDue){closest=r;closestDue=due;}
            }
        }
        if(nextReminderSummary!=null){
            if(closest==null){
                nextReminderSummary.setVisibility(View.GONE);
            }else{
                nextReminderSummary.setText("نوبت بعدی: "+closest.title+" • "+PersianDateUtil.pretty(closestDue));
                nextReminderSummary.setVisibility(View.VISIBLE);
            }
        }

        int meds=0;
        for(NexaStore.Medicine m:NexaStore.medicines(this))if(m.active)meds++;

        int tasks=0;
        for(NexaStore.TodoItem t:NexaStore.todos(this))if(!t.done)tasks++;

        int bills=0;
        for(NexaStore.BillItem b:NexaStore.bills(this))if(!b.paid)bills++;

        todaySummary.setText(upcoming+" یادآور • "+meds+" دارو • "+tasks+" کار • "+bills+" پرداخت");
        if(financeDebtValue!=null && financeCreditValue!=null
                && HomeRefreshGate.due(now,lastFinanceRefresh,HomeRefreshGate.FINANCE_MS)){
            lastFinanceRefresh=now;
            long owed=0,receivable=0;
            for(NexaStore.LedgerParty p:NexaStore.ledgerParties(this)){
                long balance=NexaStore.ledgerBalance(this,p.id);
                if(balance<0)owed+=balance==Long.MIN_VALUE?Long.MAX_VALUE:-balance;
                else if(balance>0)receivable+=balance;
            }
            financeDebtValue.setText(PersianFinancialDisplay.amount(owed)+" تومان");
            financeCreditValue.setText(PersianFinancialDisplay.amount(receivable)+" تومان");
        }

        if(attentionSummary!=null){
            int overdueReminders=0, overdueBills=0, expiringDocs=0, dueHome=0, dueTodos=0;
            long next30=now+30L*24L*60L*60L*1000L;
            for(NexaStore.Reminder r:storedReminders)
                if(r.active&&!r.done&&r.whenMillis>0&&r.whenMillis<now)overdueReminders++;
            for(NexaStore.BillItem b:NexaStore.bills(this))
                if(!b.paid&&b.dueDate>0&&b.dueDate<now)overdueBills++;
            for(NexaStore.DocumentItem d:NexaStore.documents(this))
                if(d.expiryDate>0&&d.expiryDate<=next30)expiringDocs++;
            for(NexaStore.HomeItem h:NexaStore.homeItems(this))
                if(h.nextDueDate>0&&h.nextDueDate<=next30)dueHome++;
            for(NexaStore.TodoItem t:NexaStore.todos(this))
                if(!t.done&&t.dueMillis>0&&t.dueMillis<now)dueTodos++;
            int total=overdueReminders+overdueBills+expiringDocs+dueHome+dueTodos;
            // No empty warning card on a healthy dashboard; save vertical space.
            if(attentionCard!=null)attentionCard.setVisibility(total==0?View.GONE:View.VISIBLE);
            if(total==0) attentionSummary.setText("✓ مورد فوری یا نزدیک به سررسید وجود ندارد.");
            else attentionSummary.setText(
                    "🔴 "+overdueReminders+" یادآور معوق  •  💳 "+overdueBills+" پرداخت معوق\n"+
                    "📄 "+expiringDocs+" مدرک منقضی/۳۰روزه  •  🏠 "+dueHome+" سرویس خانه\n"+
                    "✓ "+dueTodos+" کار عقب‌افتاده  •  مجموع: "+total
            );
        }
    }

    private void ensureMonitor(){
        if(!AppPrefs.isMonitoringEnabled(this))return;

        Intent i=new Intent(this,SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_MONITOR);

        try{
            if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
            else startService(i);
        }catch(Exception ignored){}

        ReminderScheduler.rescheduleAll(this);
        EmergencyCardManager.refresh(this);
    }
}
