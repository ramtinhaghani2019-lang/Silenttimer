package com.example.silenttimer;
import android.provider.Settings;
import android.os.PowerManager;
import android.app.NotificationManager;
import android.app.AlarmManager;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.Manifest;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.List;

public class MainActivity extends Activity {
    private static final int REQ_APP_UNLOCK=810;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean startupDone=false;
    private boolean permissionRepairShown=false;
    private boolean awaitingUnlock=false;
    private RingTimerView ring;
    private TextView heroTime,heroState,heroSub,todaySummary,attentionSummary,nextReminderSummary,nextOccasionSummary;
    private LinearLayout attentionCard;
    private android.widget.ProgressBar focusProgress;
    private TextView financeDebtValue,financeCreditValue;
    private long lastOverviewRefresh=0L;
    private long lastFinanceRefresh=0L;

    private final Runnable ticker=new Runnable(){
        @Override public void run(){
            refresh();
            handler.postDelayed(this,1000);
        }
    };

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        AppPrefs.applyLaunchSafetyMigration(this);
        continueStartup();
    }

    private void continueStartup(){
        if(startupDone||isFinishing())return;
        if(NexaStore.lockEnabled(this)&&!SecurityGate.isUnlocked()){
            if(!awaitingUnlock){
                awaitingUnlock=true;
                startActivityForResult(new Intent(this,UnlockActivity.class),REQ_APP_UNLOCK);
            }
            return;
        }
        startupDone=true;
        boolean first=!AppPrefs.isSetupCompleted(this);
        if(!first)ensureMonitor();
        build();
        if(!NexaStore.accountConfigured(this)){
            startActivityForResult(new Intent(this,AccountSetupActivity.class),811);
        }else if(first){
            startPermissionSetup();
        }
    }

    private void startPermissionSetup(){
        Intent i=new Intent(this,SettingsActivity.class);
        i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
        startActivity(i);
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==REQ_APP_UNLOCK){
            awaitingUnlock=false;
            if(result==RESULT_OK&&SecurityGate.isUnlocked()) continueStartup();
            else finish();
            return;
        }
        if(request==811){
            if(!NexaStore.accountConfigured(this)){
                // Keep setup mandatory without saving an incomplete/invalid profile.
                finish();return;
            }
            if(!AppPrefs.isSetupCompleted(this))startPermissionSetup();
        }
    }

    @Override protected void onResume(){
        super.onResume();
        lastFinanceRefresh=0;
        lastOverviewRefresh=0;
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        TodayNotificationManager.refresh(this);
        handler.postDelayed(this::checkCriticalPermissions,450);
    }

    /**
     * Special Android permissions cannot legally be made permanent by an app.
     * Nexa therefore verifies the real OS state on every foreground entry and,
     * if Android/One UI has revoked one, opens the existing guided repair flow.
     */
    private void checkCriticalPermissions(){
        if(isFinishing()||!AppPrefs.isSetupCompleted(this)||permissionRepairShown)return;
        NotificationManager nm=(NotificationManager)getSystemService(android.content.Context.NOTIFICATION_SERVICE);
        AlarmManager am=(AlarmManager)getSystemService(android.content.Context.ALARM_SERVICE);
        PowerManager pm=(PowerManager)getSystemService(android.content.Context.POWER_SERVICE);
        boolean notifications=Build.VERSION.SDK_INT<33||checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)==android.content.pm.PackageManager.PERMISSION_GRANTED;
        boolean exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms();
        boolean full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent();
        boolean battery=pm.isIgnoringBatteryOptimizations(getPackageName());
        boolean dnd=nm.isNotificationPolicyAccessGranted();
        if(notifications&&exact&&full&&battery&&dnd)return;
        permissionRepairShown=true;
        new android.app.AlertDialog.Builder(this)
            .setTitle("یک دسترسی Nexa غیرفعال شده")
            .setMessage("Android یا One UI یکی از دسترسی‌های ضروری هشدارها را غیرفعال کرده است. Nexa خودش هیچ دسترسی تأییدشده‌ای را حذف نمی‌کند. برای حفظ هشدار دارو، یادآورها و Lock Screen، وضعیت واقعی سیستم را دوباره تأیید کن.")
            .setPositiveButton("بررسی و فعال‌سازی",(d,w)->{Intent i=new Intent(this,SettingsActivity.class);i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);startActivity(i);})
            .setNegativeButton("بعداً",null)
            .show();
    }

    @Override protected void onPause(){
        handler.removeCallbacks(ticker);
        super.onPause();
    }

    /** Build 188: information-first home screen. All destinations and data sources are preserved.
     * Native layouts reflow for small screens and large Android font scales. */
    private void build(){
        LinearLayout screen=new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        screen.setBackground(UiKit.screenBackground(this));

        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);
        sc.setVerticalScrollBarEnabled(false);
        sc.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,22));
        sc.addView(root);

        // One compact header, clear branding, no duplicate quick-add action.
        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout brand=new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo=UiKit.title(this,"Nexa");
        logo.setTextSize(27);
        brand.addView(logo);
        TextView brandCaption=HomeUi.secondary(this,"دستیار هوشمند شخصی");
        brandCaption.setTextSize(12f);
        brand.addView(brandCaption);
        head.addView(brand,new LinearLayout.LayoutParams(0,-2,1f));
        Button mic=UiKit.iconButton(this,"🎙️","ثبت با صدا",UiKit.TEAL);
        mic.setOnClickListener(v->startActivity(new Intent(this,VoiceQuickAddActivity.class)));
        head.addView(mic,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        // One-tap global search. The directory and all existing modules stay available.
        Button globalSearch=UiKit.iconButton(this,"🔎","جست‌وجوی سراسری",UiKit.TEAL);
        globalSearch.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        LinearLayout.LayoutParams searchParams=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        searchParams.setMargins(UiKit.dp(this,6),0,0,0);
        head.addView(globalSearch,searchParams);
        Button settings=UiKit.iconButton(this,"⚙️","تنظیمات",UiKit.GOLD);
        settings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        LinearLayout.LayoutParams settingParams=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        settingParams.setMargins(UiKit.dp(this,8),0,0,0);
        head.addView(settings,settingParams);
        root.addView(head,UiKit.matchWrap(this,0,16));

        // Timer is a single complete interaction, not a giant empty status card.
        LinearLayout focus=HomeUi.panel(this,true);
        LinearLayout focusHeader=new LinearLayout(this);
        focusHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView focusTitle=HomeUi.heading(this,"◉  تمرکز و سکوت");
        focusHeader.addView(focusTitle,new LinearLayout.LayoutParams(0,-2,1f));
        heroState=HomeUi.badge(this,"آماده",UiKit.TEAL);
        focusHeader.addView(heroState);
        focus.addView(focusHeader,UiKit.matchWrap(this,0,5));
        heroTime=UiKit.title(this,"برای شروع یک زمان انتخاب کن");
        heroTime.setTextSize(19f);
        heroTime.setGravity(Gravity.RIGHT);
        heroTime.setMaxLines(2);
        focus.addView(heroTime,UiKit.matchWrap(this,3,4));
        heroSub=HomeUi.secondary(this,"انتخاب زمان، حالت بی‌صدا را فعال می‌کند");
        heroSub.setTextSize(12.5f);
        focus.addView(heroSub,UiKit.matchWrap(this,0,8));
        focusProgress=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        focusProgress.setMax(1000);
        focusProgress.setVisibility(View.GONE);
        focusProgress.setProgressTintList(android.content.res.ColorStateList.valueOf(UiKit.GOLD));
        focus.addView(focusProgress,new LinearLayout.LayoutParams(-1,UiKit.dp(this,3)));
        ring=new RingTimerView(this);
        ring.setVisibility(View.GONE);
        LinearLayout quickTimers=new LinearLayout(this);
        quickTimers.setGravity(Gravity.CENTER_VERTICAL);
        addQuick(quickTimers,"۱۵ دقیقه",15);
        addQuick(quickTimers,"۳۰ دقیقه",30);
        addQuick(quickTimers,"۱ ساعت",60);
        focus.addView(quickTimers,UiKit.matchWrap(this,11,0));
        root.addView(focus,UiKit.matchWrap(this,0,12));

        // Today's overview: one tap to a complete, existing timeline.
        LinearLayout today=HomeUi.panel(this,false);
        LinearLayout todayHeader=HomeUi.headerRow(this,"✨  امروز در Nexa","مشاهده  ‹");
        today.addView(todayHeader);
        todaySummary=HomeUi.secondary(this,"");
        todaySummary.setTextSize(14f);
        todaySummary.setMaxLines(3);
        today.addView(todaySummary,UiKit.matchWrap(this,8,2));
        nextReminderSummary=HomeUi.secondary(this,"");
        nextReminderSummary.setTextSize(12f);
        nextReminderSummary.setMaxLines(2);
        nextReminderSummary.setVisibility(View.GONE);
        today.addView(nextReminderSummary,UiKit.matchWrap(this,3,0));
        // A tappable, unobtrusive link only when an active occasion exists.
        nextOccasionSummary=HomeUi.secondary(this,"");
        nextOccasionSummary.setTextSize(12.5f);
        nextOccasionSummary.setTextColor(UiKit.GOLD);
        nextOccasionSummary.setMaxLines(2);
        nextOccasionSummary.setMinHeight(UiKit.dp(this,44));
        nextOccasionSummary.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        nextOccasionSummary.setVisibility(View.GONE);
        nextOccasionSummary.setContentDescription("مشاهده نزدیک‌ترین مناسبت سالانه");
        nextOccasionSummary.setOnClickListener(v->startActivity(new Intent(this,AnnualOccasionsActivity.class)));
        today.addView(nextOccasionSummary,UiKit.matchWrap(this,2,0));
        today.setContentDescription("خلاصه امروز؛ برای مشاهده جزئیات لمس کنید");
        today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        root.addView(today,UiKit.matchWrap(this,0,12));

        // Financial balances respect exact amount rendering and original debt/credit colors.
        root.addView(HomeUi.sectionLabel(this,"وضعیت مالی"),UiKit.matchWrap(this,0,7));
        LinearLayout financeRow=new LinearLayout(this);
        financeRow.setOrientation(LinearLayout.HORIZONTAL);
        financeRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout debtCard=HomeUi.balanceCard(this,"بدهی من",UiKit.RED);
        financeDebtValue=HomeUi.money(this,"۰ تومان",UiKit.RED);
        debtCard.addView(financeDebtValue,UiKit.matchWrap(this,7,0));
        debtCard.setContentDescription("خلاصه بدهی‌ها؛ ورود به حسابداری");
        debtCard.setOnClickListener(v->startActivity(new Intent(this,LedgerActivity.class)));
        LinearLayout creditCard=HomeUi.balanceCard(this,"طلب من",UiKit.GOLD);
        financeCreditValue=HomeUi.money(this,"۰ تومان",UiKit.GOLD);
        creditCard.addView(financeCreditValue,UiKit.matchWrap(this,7,0));
        creditCard.setContentDescription("خلاصه طلب‌ها؛ ورود به حسابداری");
        creditCard.setOnClickListener(v->startActivity(new Intent(this,LedgerActivity.class)));
        boolean stackCards=HomeUi.shouldStack(this);
        if(stackCards){
            financeRow.setOrientation(LinearLayout.VERTICAL);
            financeRow.addView(debtCard,UiKit.matchWrap(this,0,8));
            financeRow.addView(creditCard,UiKit.matchWrap(this));
        }else{
            LinearLayout.LayoutParams debitParams=new LinearLayout.LayoutParams(0,-2,1f);
            debitParams.setMargins(0,0,UiKit.dp(this,5),0);
            financeRow.addView(debtCard,debitParams);
            LinearLayout.LayoutParams creditParams=new LinearLayout.LayoutParams(0,-2,1f);
            creditParams.setMargins(UiKit.dp(this,5),0,0,0);
            financeRow.addView(creditCard,creditParams);
        }
        root.addView(financeRow,UiKit.matchWrap(this,0,12));

        // An empty alert block should never waste space on the main screen.
        attentionCard=HomeUi.panel(this,false);
        attentionCard.addView(HomeUi.heading(this,"⚡  نیازمند توجه"));
        attentionSummary=HomeUi.secondary(this,"");
        attentionSummary.setTextSize(13f);
        attentionCard.addView(attentionSummary,UiKit.matchWrap(this,6,0));
        attentionCard.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        root.addView(attentionCard,UiKit.matchWrap(this,0,12));

        root.addView(HomeUi.sectionLabel(this,"دسترسی سریع"),UiKit.matchWrap(this,1,7));
        addFeatureRow(root,
                new Feature("📅","یادآورها","هشدارها و برنامه‌ها",RemindersActivity.class,1),
                new Feature("🎂","مناسبت‌ها","تولد، ازدواج و سالگردها",AnnualOccasionsActivity.class,1));
        addFeatureRow(root,
                new Feature("💳","حسابداری","بدهی، طلب و پرداخت",LedgerActivity.class,1),
                new Feature("📋","فهرست‌ها","کارها و لیست‌ها",NexaListActivity.class,1));
        TextView all=HomeUi.directoryLink(this,"☷  مشاهده همه بخش‌ها و ابزارها");
        all.setOnClickListener(v->showAllFeatures());
        root.addView(all,UiKit.matchWrap(this,2,1));

        LinearLayout bottom=UiKit.bottomNav(this,0,
                v->{},
                v->startActivity(new Intent(this,TodayActivity.class)),
                v->startActivity(new Intent(this,QuickAddActivity.class)),
                v->startActivity(new Intent(this,TimelineActivity.class)));
        LinearLayout.LayoutParams bp=UiKit.matchWrap(this);
        bp.setMargins(UiKit.dp(this,16),0,UiKit.dp(this,16),UiKit.dp(this,9));
        attachHomeContent(screen,sc,bottom,bp);
        setContentView(screen);
        refresh();
    }

    // Package-private for an Android instrumentation regression test.  The
    // content MUST be added before navigation, otherwise the app opens empty.
    static void attachHomeContent(LinearLayout screen, ScrollView sc, View bottom,
                                  LinearLayout.LayoutParams bottomParams){
        if(screen==null || sc==null || bottom==null || bottomParams==null)
            throw new IllegalArgumentException("Home layout is incomplete");
        if(screen.getOrientation()!=LinearLayout.VERTICAL)
            throw new IllegalArgumentException("Home needs vertical layout");
        if(sc.getChildCount()==0)
            throw new IllegalArgumentException("Home dashboard has no content");
        screen.addView(sc,new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,0,1f));
        screen.addView(bottom,bottomParams);
    }

    private void showAllFeatures(){
        // A single searchable, scrollable directory rather than a full-screen wall of labels.
        // All destinations remain reachable; this replaces presentation only.
        final String[] names={"دارو و سلامت","دارایی‌ها","قبوض و اقساط","اسناد و مدارک",
                "سرویس خودرو","سرویس خانه","پرونده‌ها","هواشناسی",
                "صدا و اعلان‌ها","باتری و شارژ","امنیت و حریم خصوصی","اضطراری",
                "تنظیمات","جستجوی سراسری","خط زمانی","سوابق","فایل‌ها","دفتر مشترک","مناسبت‌ها"};
        // Keep the old colorful emoji identity (not monochrome symbol fonts).
        final String[] icons=FeatureEmoji.directoryIcons();
        final String[] aliases={"دارو پزشکی سلامت", "اموال سرمایه دارایی", "قسط پرداخت قبض سررسید", "مدرک سند گواهینامه", "ماشین اتومبیل", "منزل خدمات", "پرونده اطلاعات", "آب و هوا", "صدا آلارم نوتیفیکیشن", "شارژ باتری", "رمز قفل حریم خصوصی", "کمک فوری", "پیکربندی", "پیدا کردن", "تایم لاین", "تاریخچه", "پیوست فایل", "شخص مخاطب کارت فروشنده", "تولد سالگرد ازدواج فوت مراسم مناسبت"};
        final Class<?>[] screens={MedicineActivity.class,AssetsActivity.class,BillsActivity.class,DocsActivity.class,
                GarageActivity.class,HomeCareActivity.class,CaseActivity.class,WeatherActivity.class,
                SilentHubActivity.class,BatteryGuardActivity.class,VaultActivity.class,EmergencyActivity.class,
                SettingsActivity.class,SearchActivity.class,TimelineActivity.class,HistoryActivity.class,FileCenterActivity.class,SharedEntitiesActivity.class,AnnualOccasionsActivity.class};
        final String[] groups={"امور مالی و اسناد","زندگی و سلامت","هشدارها و ابزارها","تنظیمات و مدیریت"};
        final int[] groupOf={1,0,0,0,1,1,1,1,2,2,3,2,3,3,3,3,3,0,1};
        if(names.length!=screens.length||names.length!=icons.length||names.length!=aliases.length||names.length!=groupOf.length)
            throw new IllegalStateException("Feature menu items mismatch");

        final LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        panel.setPadding(UiKit.dp(this,12),UiKit.dp(this,6),UiKit.dp(this,12),0);
        panel.setFocusableInTouchMode(true);

        final android.widget.EditText search=UiKit.styleField(this,new android.widget.EditText(this),"جست‌وجوی بخش‌ها؛ مثلاً قسط، کارت یا دارو");
        search.setSingleLine(true);
        search.setInputType(android.text.InputType.TYPE_CLASS_TEXT);
        search.setContentDescription("جست‌وجو در بخش‌های Nexa");
        panel.addView(search,UiKit.matchWrap(this,0,8));

        final ScrollView scroller=new ScrollView(this);
        scroller.setFillViewport(false);
        scroller.setVerticalScrollBarEnabled(true);
        final LinearLayout results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        results.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroller.addView(results);
        int height=Math.min(UiKit.dp(this,610),(int)(getResources().getDisplayMetrics().heightPixels*.66f));
        panel.addView(scroller,new LinearLayout.LayoutParams(-1,height));
        final AlertDialog dialog=new AlertDialog.Builder(this)
                .setTitle("همه بخش‌های Nexa")
                .setView(panel).setNegativeButton("بستن",null).create();

        final Runnable redraw=()->{
            String filter=search.getText().toString();
            results.removeAllViews();
            int found=0;
            for(int g=0;g<groups.length;g++){
                java.util.ArrayList<Integer> visible=new java.util.ArrayList<>();
                for(int i=0;i<names.length;i++)
                    if(groupOf[i]==g && FeatureSearch.matches(names[i],aliases[i],groups[g],filter)) visible.add(i);
                if(visible.isEmpty())continue;
                found+=visible.size();
                TextView heading=UiKit.sectionTitle(this,groups[g]);
                heading.setTextSize(13.5f);
                heading.setContentDescription("دسته "+groups[g]);
                results.addView(heading,UiKit.matchWrap(this,10,5));
                for(int idx:visible){
                    // Build 191: single-column native rows let long Persian labels breathe.
                    // FeatureEmoji.directoryIcons() still supplies all original colorful emoji.
                    LinearLayout item=UiKit.featureDirectoryRow(this,icons[idx],names[idx],idx%8);
                    item.setOnClickListener(v->{dialog.dismiss();startActivity(new Intent(this,screens[idx]));});
                    results.addView(item,UiKit.matchWrap(this,0,7));
                }
            }
            if(found==0)results.addView(UiKit.emptyState(this,"بخشی پیدا نشد","عبارت دیگری جست‌وجو کن"),UiKit.matchWrap(this,12,8));
            scroller.scrollTo(0,0);
        };
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){redraw.run();}
            public void afterTextChanged(android.text.Editable e){}
        });
        redraw.run();
        panel.requestFocus(); // Opening the directory must not cover it with the keyboard.
        dialog.setOnShowListener(d->{
            android.view.Window window=dialog.getWindow();
            if(window!=null){
                window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
                window.setLayout(getResources().getDisplayMetrics().widthPixels-UiKit.dp(this,24),-2);
            }
        });
        dialog.show();
    }

    private static final class Feature{
        String icon,title,sub;
        Class<?> cls;
        int v;
        Feature(String i,String t,String s,Class<?>c,int x){
            icon=i;title=t;sub=s;cls=c;v=x;
        }
    }

    private void addFeatureRow(LinearLayout root,Feature a,Feature b){
        if(a==null&&b==null)return;
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(HomeUi.shouldStack(this)?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        if(HomeUi.shouldStack(this)){
            if(a!=null)row.addView(tile(a),UiKit.matchWrap(this,0,8));
            if(b!=null)row.addView(tile(b),UiKit.matchWrap(this));
        }else{
            if(a!=null){
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
                p.setMargins(0,0,UiKit.dp(this,5),0);
                row.addView(tile(a),p);
            }
            if(b!=null){
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
                p.setMargins(UiKit.dp(this,5),0,0,0);
                row.addView(tile(b),p);
            }
        }
        root.addView(row,UiKit.matchWrap(this,0,9));
    }

    private View tile(Feature f){
        LinearLayout tile=HomeUi.shortcut(this,f.icon,f.title,f.sub);
        tile.setContentDescription("باز کردن "+f.title);
        tile.setOnClickListener(v->startActivity(new Intent(this,f.cls)));
        return tile;
    }

    private void addQuick(LinearLayout row,String text,int min){
        TextView chip=UiKit.chip(this,text,false);
        chip.setMinHeight(UiKit.dp(this,46));
        chip.setTextSize(13.5f);
        chip.setContentDescription("شروع تایمر "+text);
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
        p.setMargins(UiKit.dp(this,4),0,UiKit.dp(this,4),0);
        row.addView(chip,p);

        chip.setOnClickListener(v->{
            if(!AppPrefs.isSetupCompleted(this)){
                Intent i=new Intent(this,SettingsActivity.class);
                i.putExtra(SettingsActivity.EXTRA_START_SETUP,true);
                startActivity(i);
                return;
            }

            Intent i=new Intent(this,SilentTimerService.class);
            i.setAction(SilentTimerService.ACTION_START);
            i.putExtra(SilentTimerService.EXTRA_MINUTES,min);
            i.putExtra(SilentTimerService.EXTRA_TARGET_MODE,AudioManager.RINGER_MODE_SILENT);

            try{
                if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
                else startService(i);
                // Starting a service is asynchronous: never claim it is active until refresh confirms it.
                Toast.makeText(this,"درخواست شروع تایمر ارسال شد.",Toast.LENGTH_SHORT).show();
            }catch(Exception startError){
                Toast.makeText(this,"شروع تایمر انجام نشد؛ دسترسی‌های برنامه را بررسی کن.",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void refresh(){
        if(heroTime==null)return;

        long now=System.currentTimeMillis();
        long end=AppPrefs.getEndAt(this);
        long start=AppPrefs.getStartAt(this);

        if(end>now){
            long rem=end-now,sec=rem/1000,h=sec/3600,m=(sec%3600)/60,s=sec%60;
            heroState.setText("● فعال");
            heroTime.setTextDirection(View.TEXT_DIRECTION_LTR);
            heroTime.setTypeface(android.graphics.Typeface.MONOSPACE,android.graphics.Typeface.BOLD);
            heroTime.setTextSize(27f);
            heroTime.setText(h>0
                    ?String.format(Locale.US,"%02d:%02d:%02d",h,m,s)
                    :String.format(Locale.US,"%02d:%02d",m,s));
            heroSub.setText(
                    (AppPrefs.getTargetRingerMode(this)==AudioManager.RINGER_MODE_VIBRATE?"لرزش":"بی‌صدا")+
                            " • پایان "+
                            new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(end))
            );
            float prog=0;
            if(start>0&&end>start)prog=1f-(float)rem/(float)(end-start);
            ring.setProgress(prog);
            if(focusProgress!=null){focusProgress.setVisibility(View.VISIBLE);focusProgress.setProgress(Math.round(Math.max(0,Math.min(1,prog))*1000));}
        }else{
            if(!"آماده".contentEquals(heroState.getText()))heroState.setText("آماده");
            if(!"برای شروع یک زمان انتخاب کن".contentEquals(heroTime.getText()))
                heroTime.setText("برای شروع یک زمان انتخاب کن");
            heroTime.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG_RTL);
            heroTime.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);
            heroTime.setTextSize(19f);
            if(!"انتخاب زمان، حالت بی‌صدا را فعال می‌کند".contentEquals(heroSub.getText()))
                heroSub.setText("انتخاب زمان، حالت بی‌صدا را فعال می‌کند");
            if(focusProgress!=null)focusProgress.setVisibility(View.GONE);
            ring.setProgress(0);
        }

        // Timer changes every second, but the dashboard's stored collections do not.
        // Re-read them on foreground entry and at a modest interval to avoid jank.
        if(!HomeRefreshGate.due(now,lastOverviewRefresh,HomeRefreshGate.OVERVIEW_MS))return;
        lastOverviewRefresh=now;
        int upcoming=0;
        NexaStore.Reminder closest=null;
        long closestDue=Long.MAX_VALUE;
        List<NexaStore.Reminder> storedReminders=NexaStore.reminders(this);
        for(NexaStore.Reminder r:storedReminders){
            if(!r.active || r.done || r.whenMillis<=0)continue;
            // Recurring reminders with a historical original date can have
            // future occurrences even before their original record is advanced.
            long due=r.whenMillis;
            if(due<=now && ReminderRecurrence.isRecurring(r.recurrence))
                due=ReminderRecurrence.after(r.whenMillis,r.recurrence,now);
            if(due>now){
                if(due<=now+24L*60L*60L*1000L)upcoming++;
                if(due<closestDue){closest=r;closestDue=due;}
            }
        }
        // Preview is calculated from original annual dates; the preview never
        // re-schedules alarms and never edits any stored records.
        if(nextOccasionSummary!=null){
            HomeOccasionPolicy.Match next=HomeOccasionPolicy.closest(OccasionStore.all(this),now);
            if(next==null){
                nextOccasionSummary.setVisibility(View.GONE);
            }else{
                nextOccasionSummary.setText(next.occasion.icon()+" مناسبت بعدی: "+next.occasion.title+
                        " • "+PersianDateUtil.pretty(next.due)+"   ›");
                nextOccasionSummary.setVisibility(View.VISIBLE);
            }
        }
        if(nextReminderSummary!=null){
            if(closest==null){
                nextReminderSummary.setVisibility(View.GONE);
            }else{
                nextReminderSummary.setText("نوبت بعدی: "+closest.title+" • "+PersianDateUtil.pretty(closestDue));
                nextReminderSummary.setVisibility(View.VISIBLE);
            }
        }

        int meds=0;
        for(NexaStore.Medicine m:NexaStore.medicines(this))if(m.active)meds++;

        int tasks=0;
        for(NexaStore.TodoItem t:NexaStore.todos(this))if(!t.done)tasks++;

        int bills=0;
        for(NexaStore.BillItem b:NexaStore.bills(this))if(!b.paid)bills++;

        todaySummary.setText(translateDigits(upcoming)+" یادآور   •   "+translateDigits(meds)+" دارو\n"+
                translateDigits(tasks)+" کار   •   "+translateDigits(bills)+" پرداخت");
        if(financeDebtValue!=null && financeCreditValue!=null
                && HomeRefreshGate.due(now,lastFinanceRefresh,HomeRefreshGate.FINANCE_MS)){
            lastFinanceRefresh=now;
            long owed=0,receivable=0;
            for(NexaStore.LedgerParty p:NexaStore.ledgerParties(this)){
                long balance=NexaStore.ledgerBalance(this,p.id);
                if(balance<0)owed+=balance==Long.MIN_VALUE?Long.MAX_VALUE:-balance;
                else if(balance>0)receivable+=balance;
            }
            financeDebtValue.setText(PersianFinancialDisplay.amount(owed)+" تومان");
            financeCreditValue.setText(PersianFinancialDisplay.amount(receivable)+" تومان");
        }

        if(attentionSummary!=null){
            int overdueReminders=0, overdueBills=0, expiringDocs=0, dueHome=0, dueTodos=0;
            long next30=now+30L*24L*60L*60L*1000L;
            for(NexaStore.Reminder r:storedReminders)
                if(r.active&&!r.done&&AgendaDuePolicy.overdueForAttention(
                        r.whenMillis,r.recurrence,now))overdueReminders++;
            for(NexaStore.BillItem b:NexaStore.bills(this))
                if(!b.paid&&b.dueDate>0&&b.dueDate<now)overdueBills++;
            for(NexaStore.DocumentItem d:NexaStore.documents(this))
                if(d.expiryDate>0&&d.expiryDate<=next30)expiringDocs++;
            for(NexaStore.HomeItem h:NexaStore.homeItems(this))
                if(h.nextDueDate>0&&h.nextDueDate<=next30)dueHome++;
            for(NexaStore.TodoItem t:NexaStore.todos(this))
                if(!t.done&&t.dueMillis>0&&t.dueMillis<now)dueTodos++;
            int total=overdueReminders+overdueBills+expiringDocs+dueHome+dueTodos;
            // No empty warning card on a healthy dashboard; save vertical space.
            if(attentionCard!=null)attentionCard.setVisibility(total==0?View.GONE:View.VISIBLE);
            if(total==0) attentionSummary.setText("✓ مورد فوری یا نزدیک به سررسید وجود ندارد.");
            else attentionSummary.setText(
                    "🔴 "+overdueReminders+" یادآور معوق  •  💳 "+overdueBills+" پرداخت معوق\n"+
                    "📄 "+expiringDocs+" مدرک منقضی/۳۰روزه  •  🏠 "+dueHome+" سرویس خانه\n"+
                    "✓ "+dueTodos+" کار عقب‌افتاده  •  مجموع: "+total
            );
        }
    }

    private static String translateDigits(int value){
        return String.valueOf(value).replace('0','۰').replace('1','۱').replace('2','۲')
                .replace('3','۳').replace('4','۴').replace('5','۵').replace('6','۶')
                .replace('7','۷').replace('8','۸').replace('9','۹');
    }

    private void ensureMonitor(){
        if(!AppPrefs.isMonitoringEnabled(this))return;

        Intent i=new Intent(this,SilentTimerService.class);
        i.setAction(SilentTimerService.ACTION_MONITOR);

        try{
            if(Build.VERSION.SDK_INT>=26)startForegroundService(i);
            else startService(i);
        }catch(Exception ignored){}

        ReminderScheduler.rescheduleAll(this);
        EmergencyCardManager.refresh(this);
    }
}
