package com.example.silenttimer;


/** Search-only normalization: never changes stored names or user data. */
public final class FeatureSearch {
    private FeatureSearch() {}

    public static String normalize(String text) {
        if (text == null) return "";
        StringBuilder out = new StringBuilder();
        boolean space = true;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (c == 'ي' || c == 'ى') c = 'ی';
            else if (c == 'ك') c = 'ک';
            else if (c == '\u200c' || c == '\u200f' || c == '\u200e') c = ' ';
            if (c >= '\u064b' && c <= '\u065f') continue;
            if (Character.isWhitespace(c)) {
                if (!space) { out.append(' '); space = true; }
            } else {
                out.append(Character.toLowerCase(c));
                space = false;
            }
        }
        return out.toString().trim();
    }

    public static boolean matches(String name, String alias, String category, String query) {
        String q = normalize(query);
        if (q.isEmpty()) return true;
        // All words may occur in separate searchable fields in any order.
        String haystack = normalize(name) + " " + normalize(alias) + " " + normalize(category);
        for (String word : q.split(" ")) if (!haystack.contains(word)) return false;
        return true;
    }
}
