package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Editable, grouped portfolio. No online price is represented as verified Iranian consensus. */
public class AssetsActivity extends Activity {
    private LinearLayout list;
    private String pendingVoiceTitle;
    private GridLayout typeManagerList;
    private TextView summary,marketStatus;
    private EditText usdToman;
    private final DecimalFormat df=new DecimalFormat("#,##0.###");
    private final DecimalFormat moneyFormat=new DecimalFormat("#,##0.##");
    private final List<String> standardTypes=new ArrayList<>();
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        java.util.Collections.addAll(standardTypes,"طلای ۱۸ عیار","طلای ۲۴ عیار","نقره","مس","دلار","یورو","سکه تمام بهار آزادی","نیم‌سکه بهار آزادی","ربع‌سکه بهار آزادی","سکه گرمی","سهام / بورس","سایر");
        pendingVoiceTitle=getIntent().getStringExtra("voice_title");
        build();if(getIntent().getBooleanExtra("quick_add",false)){
            getIntent().removeExtra("quick_add");
            list.postDelayed(()->editForm(null),250);
        }
    }
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));return e;}
    private Spinner picker(List<String> values){Spinner s=UiKit.styledSpinner(this);
        ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
            @Override public View getView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setPadding(12,12,12,12);return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);t.setPadding(14,14,14,14);return t;}
        };a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);return s;
    }
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,28));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.header(this,"📈 دارایی‌ها و سرمایه‌گذاری",v->finish()),UiKit.matchWrap(this,0,4));
// Keep market details in the existing collapsible section instead of a second hero.
        LinearLayout sum=UiKit.accentCardLayout(this);sum.addView(UiKit.sectionTitle(this,"💰 ارزش کل سبد"));
        summary=UiKit.muted(this,"");summary.setTextSize(16);sum.addView(summary,UiKit.matchWrap(this,8,0));root.addView(sum,UiKit.matchWrap(this,0,12));
        LinearLayout market=new LinearLayout(this);market.setOrientation(LinearLayout.VERTICAL);
        market.addView(UiKit.muted(this,"مبنای قیمت‌ها بازار آزاد ایران است: دلار، یورو، طلای ۱۸ و ۲۴ عیار، اونس جهانی و سکه‌ها. در خطا آخرین قیمت معتبر حفظ می‌شود."),UiKit.matchWrap(this,0,8));
        List<String> modes=new ArrayList<>();java.util.Collections.addAll(modes,"فقط دستی / آفلاین","به‌روزرسانی آنلاین هنگام درخواست","خودکار هنگام باز بودن (هر ۵ دقیقه)");
        Spinner mode=picker(modes);mode.setSelection(NexaStore.marketRefreshMode(this));
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long id){NexaStore.setMarketRefreshMode(AssetsActivity.this,position);}});
        market.addView(mode,UiKit.matchWrap(this,0,8));
        Button refresh=UiKit.primaryButton(this,"دریافت قیمت بازار ایران");refresh.setOnClickListener(v->refreshMarket(refresh));market.addView(refresh);
        Button history=UiKit.secondaryButton(this,"📊 تاریخچه و نمودار بازار");history.setOnClickListener(v->showMarketHistory());market.addView(history,UiKit.matchWrap(this,8,0));
        Button alerts=UiKit.secondaryButton(this,"🔔 مدیریت هشدارهای قیمت");alerts.setOnClickListener(v->showPriceAlertManager());market.addView(alerts,UiKit.matchWrap(this,8,0));
        marketStatus=UiKit.muted(this,"");market.addView(marketStatus,UiKit.matchWrap(this,10,0));
        LinearLayout marketCard=UiKit.colorfulCardLayout(this,5);marketCard.addView(UiKit.sectionTitle(this,"🇮🇷 قیمت‌های بازار"));marketCard.addView(UiKit.muted(this,"دلار • یورو • طلا • اونس • سکه | آخرین قیمت معتبر"),UiKit.matchWrap(this,4,8));marketCard.addView(market);root.addView(
                UiKit.collapsible(this,"market_controls_176","قیمت بازار و تنظیمات","",5,false,marketCard),
                UiKit.matchWrap(this,0,10));
        LinearLayout typesBody=new LinearLayout(this);typesBody.setOrientation(LinearLayout.VERTICAL);LinearLayout typeHead=new LinearLayout(this);typeHead.setGravity(Gravity.CENTER_VERTICAL);
        typeHead.addView(UiKit.sectionTitle(this,"انواع دارایی"),new LinearLayout.LayoutParams(0,-2,1f));Button typePlus=UiKit.addIconButton(this);typePlus.setOnClickListener(v->addAssetTypeDialog());typeHead.addView(typePlus,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));typesBody.addView(typeHead);
        Button typesInfo=UiKit.secondaryButton(this,"ⓘ"); typesInfo.setContentDescription("راهنمای انواع دارایی"); typesInfo.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("راهنمای انواع دارایی").setMessage("نوع دارایی برای دسته‌بندی خریدهاست. نوع جدید را فقط از همین بخش اضافه کنید تا همه خریدها و گزارش‌ها یکدست بمانند.").setPositiveButton("بستن",null).show()); typeHead.addView(typesInfo,new LinearLayout.LayoutParams(UiKit.dp(this,52),UiKit.dp(this,42)));typeManagerList=new GridLayout(this);typeManagerList.setColumnCount(getResources().getDisplayMetrics().widthPixels / getResources().getDisplayMetrics().density >= 390 ? 3 : 2);typesBody.addView(typeManagerList);Button typeManager=UiKit.secondaryButton(this,"☷  مدیریت انواع دارایی");
        typeManager.setOnClickListener(v->{
            android.view.ViewGroup parent=(android.view.ViewGroup)typesBody.getParent();
            if(parent!=null)parent.removeView(typesBody);
            ScrollView box=new ScrollView(this);box.addView(typesBody);
            new AlertDialog.Builder(this).setTitle("انواع دارایی").setView(box)
                    .setNegativeButton("بستن",null).show();
        });
        root.addView(typeManager,UiKit.matchWrap(this,0,9));
        Button add=UiKit.primaryButton(this,"＋ ثبت دارایی / خرید جدید");add.setOnClickListener(v->editForm(null));root.addView(add,UiKit.matchWrap(this,0,14));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);
        renderAssetTypes();render();updateMarketText();
    }
    @Override protected void onResume(){super.onResume();if(list!=null){
        if(NexaStore.marketRefreshMode(this)==2 && System.currentTimeMillis()-NexaStore.iranMarketUpdated(this)>300000L){
            // No background polling: only refresh on screen opening, if cache is stale.
            MarketDataHelper.refresh(this,(ok,msg)->{if(ok){updateOnlineAssets();render();}if(marketStatus!=null)marketStatus.setText(msg);});
        }
    }}
    private List<String> assetTypeValues(){List<String> out=new ArrayList<>(standardTypes);for(String x:NexaStore.assetTypes(this))if(!out.contains(x))out.add(x);for(NexaStore.AssetEntry x:NexaStore.assets(this))if(!out.contains(x.type))out.add(x.type);return out;}
    private void renderAssetTypes(){
        if(typeManagerList==null)return;
        typeManagerList.removeAllViews();
        int columns=typeManagerList.getColumnCount();
        int available=getResources().getDisplayMetrics().widthPixels-UiKit.dp(this,72);
        int cellWidth=Math.max(UiKit.dp(this,90),available/columns-UiKit.dp(this,8));
        for(String t:assetTypeValues()){
            TextView chip=UiKit.muted(this,t);
            chip.setTextSize(12);
            chip.setGravity(Gravity.CENTER);
            chip.setSingleLine(false);
            chip.setMinHeight(UiKit.dp(this,42));
            chip.setPadding(UiKit.dp(this,5),UiKit.dp(this,6),UiKit.dp(this,5),UiKit.dp(this,6));
            chip.setBackground(UiKit.field(this));
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();
            lp.width=cellWidth;lp.height=GridLayout.LayoutParams.WRAP_CONTENT;
            lp.setMargins(UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3));
            typeManagerList.addView(chip,lp);
        }
    }
    private void addAssetTypeDialog(){EditText entry=field("نام نوع دارایی جدید");new AlertDialog.Builder(this).setTitle("نوع دارایی جدید").setView(entry).setPositiveButton("افزودن",(d,w)->{String t=entry.getText().toString().trim();if(t.isEmpty())return;NexaStore.addAssetType(this,t);renderAssetTypes();}).setNegativeButton("انصراف",null).show();}

    private void refreshMarket(Button b){
        if(NexaStore.marketRefreshMode(this)==0){Toast.makeText(this,"دریافت اینترنتی خاموش است.",Toast.LENGTH_SHORT).show();return;}
        b.setEnabled(false);marketStatus.setText("در حال دریافت...");
        MarketDataHelper.refresh(this,(ok,msg)->{b.setEnabled(true);marketStatus.setText(msg);
            if(ok){updateOnlineAssets();checkPriceAlerts();render();updateMarketText();}});
    }

    private void showPriceAlertManager(){
        List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),UiKit.dp(this,8));
        int active=0;
        for(NexaStore.AssetEntry x:data){
            if(x.alertTarget<=0&&!x.alertAtBuy)continue;active++;
            double target=x.alertAtBuy?x.buyUnitPrice:x.alertTarget;
            String mode="up".equals(x.alertDirection)?"بالاتر از هدف":"down".equals(x.alertDirection)?"پایین‌تر از هدف":"exact".equals(x.alertDirection)?"دقیقاً هدف":"عبور از هدف";
            LinearLayout row=UiKit.cardLayout(this);
            row.addView(UiKit.sectionTitle(this,(x.name==null||x.name.trim().isEmpty()?x.type:x.name)));
            row.addView(UiKit.muted(this,mode+" • "+money(target)+"\nقیمت فعلی: "+money(x.currentUnitPrice)),UiKit.matchWrap(this,4,6));
            Button edit=UiKit.secondaryButton(this,"ویرایش هشدار");edit.setOnClickListener(v->{priceAlertDialog(x);});row.addView(edit);
            box.addView(row,UiKit.matchWrap(this,0,8));
        }
        if(active==0)box.addView(UiKit.muted(this,"هیچ هشدار قیمت فعالی وجود ندارد."),UiKit.matchWrap(this,8,8));
        ScrollView sc=new ScrollView(this);sc.addView(box);
        final boolean hasActiveAlerts = active > 0;
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("🔔 مدیریت هشدارهای قیمت").setView(sc).setPositiveButton("بستن",null)
            .setNeutralButton(hasActiveAlerts?"خاموش‌کردن همه":null,null).create();
        dlg.setOnShowListener(d->{if(hasActiveAlerts)dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{List<NexaStore.AssetEntry> all=NexaStore.assets(this);for(NexaStore.AssetEntry x:all){x.alertTarget=0;x.alertAtBuy=false;x.alertTriggered=false;x.lastAlertObservedPrice=0;}NexaStore.saveAssets(this,all);PriceMonitorReceiver.cancel(this);dlg.dismiss();render();Toast.makeText(this,"همه هشدارهای قیمت خاموش شدند.",Toast.LENGTH_SHORT).show();});});
        dlg.show();
    }

    private void showMarketHistory(){
        List<NexaStore.MarketHistoryPoint> all=NexaStore.marketHistory(this);
        if(all.isEmpty()){Toast.makeText(this,"هنوز تاریخچه‌ای ثبت نشده؛ با دریافت قیمت‌های جدید، تاریخچه ساخته می‌شود.",Toast.LENGTH_LONG).show();return;}
        LinearLayout box=UiKit.dialogPanel(this);List<String> names=java.util.Arrays.asList("دلار","یورو","طلای ۱۸ عیار","طلای ۲۴ عیار","اونس جهانی","سکه تمام بهار آزادی","نیم‌سکه بهار آزادی","ربع‌سکه بهار آزادی","سکه گرمی");
        Spinner asset=picker(names);Spinner range=picker(java.util.Arrays.asList("۲۴ ساعت","۷ روز","۳۰ روز","همه تاریخچه"));TextView stats=UiKit.muted(this,"");MarketHistoryView chart=new MarketHistoryView(this);
        box.addView(asset,UiKit.matchWrap(this,0,6));box.addView(range,UiKit.matchWrap(this,0,6));box.addView(stats,UiKit.matchWrap(this,6,6));box.addView(chart,new LinearLayout.LayoutParams(-1,UiKit.dp(this,240)));
        Runnable redraw=()->{long now=System.currentTimeMillis();int rp=range.getSelectedItemPosition();long since=rp==0?now-24*60*60_000L:rp==1?now-7L*24*60*60_000L:rp==2?now-30L*24*60*60_000L:0;int ap=asset.getSelectedItemPosition();List<Double> vals=new ArrayList<>();double first=0,last=0,min=Double.MAX_VALUE,max=0;int n=0;for(NexaStore.MarketHistoryPoint p:all){if(p.time<since)continue;double v=marketHistoryValue(p,ap);if(v<=0)continue;if(n++==0)first=v;last=v;min=Math.min(min,v);max=Math.max(max,v);vals.add(v);}chart.setValues(vals);if(n==0){stats.setText("برای این بازه داده‌ای ثبت نشده است.");return;}double pct=first>0?(last-first)/first*100:0;stats.setText("آخرین: "+money(last)+"\nکمترین: "+money(min)+" • بیشترین: "+money(max)+"\nتغییر بازه: "+persian(String.format(Locale.US,"%+.2f%%",pct))+" • "+n+" نقطه");};
        android.widget.AdapterView.OnItemSelectedListener listener=new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){redraw.run();}};asset.setOnItemSelectedListener(listener);range.setOnItemSelectedListener(listener);redraw.run();
        new AlertDialog.Builder(this).setTitle("تاریخچه بازار ایران").setView(box).setPositiveButton("بستن",null).show();
    }
    private double marketHistoryValue(NexaStore.MarketHistoryPoint p,int i){switch(i){case 0:return p.usd;case 1:return p.eur;case 2:return p.gold18;case 3:return p.gold24;case 4:return p.ounce;case 5:return p.bahar;case 6:return p.half;case 7:return p.quarter;default:return p.gerami;}}

    private void editForm(NexaStore.AssetEntry current){editForm(current,null,null);}
    private void editForm(NexaStore.AssetEntry current,String inheritedType,String inheritedGroup){
        LinearLayout box=UiKit.dialogPanel(this);
        List<String> types=assetTypeValues();
        Spinner type=picker(types);if(current!=null)type.setSelection(Math.max(0,types.indexOf(current.type)));
        else if(inheritedType!=null)type.setSelection(Math.max(0,types.indexOf(inheritedType)));
        EditText name=field("فروشنده / مجموعه؛ مثلاً طلای جوادی");
        if(current==null&&inheritedGroup!=null)name.setText(inheritedGroup);
        if(current==null&&pendingVoiceTitle!=null){
            name.setText(pendingVoiceTitle);
            pendingVoiceTitle=null; // A voice draft must only prefill the first new-item form.
        }
        final String[] sellerId={current==null?"":current.sellerId};
        Button sellerBtn=UiKit.secondaryButton(this,"انتخاب از دفتر مشترک فروشندگان");
        NexaStore.ShoppingSeller oldSeller=current==null?null:NexaStore.sellerById(this,current.sellerId);if(oldSeller!=null)sellerBtn.setText("فروشنده: "+oldSeller.name);
        sellerBtn.setOnClickListener(v->pickSeller(sellerId,sellerBtn,name));
        EditText amount=field("مقدار؛ مثلاً ۵٫۲۵ گرم");amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText soot=field("سوت اضافه (۰ تا ۹۹۹) برای طلا");soot.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText buy=field("قیمت خرید هر واحد");buy.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(buy);
        EditText quote=field("قیمت فعلی هر واحد");quote.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(quote);
        EditText fee=field("مجموع کارمزد و هزینه");fee.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(fee);
        Spinner currency=picker(java.util.Arrays.asList("ریال"));
        CheckBox online=new CheckBox(this);online.setText("قیمت روز از بازار ایران (برای نوع‌های پشتیبانی‌شده)");online.setTextColor(UiKit.TEXT);
        EditText alertTarget=field("هشدار قیمت هدف (تومان)؛ ۰ یعنی خاموش");alertTarget.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(alertTarget);
        CheckBox alertBuy=new CheckBox(this);alertBuy.setText("هشدار هنگام رسیدن دوباره به قیمت آخرین خرید");alertBuy.setTextColor(UiKit.TEXT);
        Spinner alertDirection=picker(java.util.Arrays.asList("هشدار در هر دو جهت","فقط عبور رو به بالا","فقط عبور رو به پایین"));
        EditText note=field("توضیحات / مشخصات");
        final long[] buyDate={current==null?System.currentTimeMillis():current.buyDate};
        Button date=UiKit.secondaryButton(this,"تاریخ و ساعت خرید: "+PersianDateUtil.pretty(buyDate[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,buyDate[0],"تاریخ و ساعت خرید",ms->{buyDate[0]=ms;date.setText("تاریخ و ساعت خرید: "+PersianDateUtil.pretty(ms));}));
        TextView total=UiKit.sectionTitle(this,"مجموع خرید: —");
        if(current!=null){name.setText(current.name);amount.setText(df.format(current.amount));
            buy.setText(df.format("ریال".equals(current.currency)?current.buyUnitPrice*10:current.buyUnitPrice));
            quote.setText(df.format("ریال".equals(current.currency)?current.currentUnitPrice*10:current.currentUnitPrice));
            fee.setText(df.format("ریال".equals(current.currency)?current.fee*10:current.fee));
            currency.setSelection(0);online.setChecked(current.autoPrice);alertTarget.setText(current.alertTarget>0?moneyFormat.format(current.alertTarget):"");alertBuy.setChecked(current.alertAtBuy);alertDirection.setSelection("up".equals(current.alertDirection)?1:("down".equals(current.alertDirection)?2:0));note.setText(current.note);}
        // An existing asset amount already includes soot; editing starts from the exact decimal amount.
        TextWatcher calculate=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){double a=num(amount.getText().toString());
                double price=num(buy.getText().toString());double fees=num(fee.getText().toString());int extra=(int)num(soot.getText().toString());
                if(extra>=0&&extra<=999)a+=extra/1000.0;
                double totalPrice=a*price+fees;total.setText("مجموع خرید: "+persian(moneyFormat.format(totalPrice))+" "+currency.getSelectedItem());}
            public void afterTextChanged(Editable e){}};
        amount.addTextChangedListener(calculate);buy.addTextChangedListener(calculate);fee.addTextChangedListener(calculate);soot.addTextChangedListener(calculate);
        currency.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}
            public void onItemSelected(android.widget.AdapterView<?> a,View v,int i,long id){total.setText("مجموع خرید: "+persian(moneyFormat.format(num(amount.getText().toString())*num(buy.getText().toString())+num(fee.getText().toString())))+" "+currency.getSelectedItem());}});
        box.addView(type,UiKit.matchWrap(this,0,8));box.addView(UiKit.muted(this,"نوع جدید را از لیست «انواع دارایی» صفحه اصلی این بخش اضافه کن."),UiKit.matchWrap(this,0,6));for(View v:new View[]{name,sellerBtn,amount,soot,buy,quote,fee,currency,online,alertTarget,alertBuy,alertDirection,date,total,note})box.addView(v,UiKit.matchWrap(this,0,8));
        ScrollView sc=new ScrollView(this);sc.addView(box);
        new AlertDialog.Builder(this).setTitle(current==null?"ثبت خرید دارایی":"ویرایش کامل خرید")
            .setView(sc).setPositiveButton("ذخیره",(d,w)->{
                double a=num(amount.getText().toString()),b=num(buy.getText().toString());int st=(int)num(soot.getText().toString());
                if(st<0||st>999){Toast.makeText(this,"سوت باید ۰ تا ۹۹۹ باشد.",Toast.LENGTH_LONG).show();return;}
                a+=st/1000.0;
                if(a<=0||b<=0){Toast.makeText(this,"مقدار و قیمت خرید باید مثبت باشند.",Toast.LENGTH_LONG).show();return;}
                NexaStore.AssetEntry x=current==null?new NexaStore.AssetEntry():current;
                x.type=String.valueOf(type.getSelectedItem());x.name=name.getText().toString().trim();
                if(x.name.isEmpty())x.name="بدون مجموعه";
                x.amount=a;double divisor=10.0;
                x.buyUnitPrice=b/divisor;x.currentUnitPrice=num(quote.getText().toString())/divisor;
                if(x.currentUnitPrice<=0)x.currentUnitPrice=x.buyUnitPrice;
                x.fee=num(fee.getText().toString())/divisor;x.currency="ریال";
                x.autoPrice=online.isChecked();x.alertTarget=num(alertTarget.getText().toString());x.alertAtBuy=alertBuy.isChecked();x.alertDirection=alertDirection.getSelectedItemPosition()==1?"up":(alertDirection.getSelectedItemPosition()==2?"down":"both");x.alertTriggered=false;x.buyDate=buyDate[0];x.note=note.getText().toString().trim();x.sellerId=sellerId[0];
                if(x.autoPrice)applyMarketToAsset(x);
                if(current==null)NexaStore.addAsset(this,x);else NexaStore.updateAsset(this,x);
                NexaStore.addHistory(this,"دارایی",(current==null?"خرید جدید: ":"ویرایش خرید: ")+x.name);PriceMonitorReceiver.schedule(this);render();
            }).setNegativeButton("انصراف",null).show();
    }
    private void pickSeller(String[] out,Button btn,EditText name){List<NexaStore.ShoppingSeller> data=NexaStore.sellers(this);LinearLayout box=UiKit.dialogPanel(this);if(data.isEmpty())box.addView(UiKit.muted(this,"فروشنده‌ای ثبت نشده؛ از Settings > دفتر مشترک اضافه کن."));for(NexaStore.ShoppingSeller s:data){Button b=UiKit.secondaryButton(this,s.name+(s.category.isEmpty()?"":" • "+s.category));b.setOnClickListener(v->{out[0]=s.id;btn.setText("فروشنده: "+s.name);name.setText(s.name);});box.addView(b,UiKit.matchWrap(this,0,5));}new AlertDialog.Builder(this).setTitle("انتخاب فروشنده").setView(box).setPositiveButton("بستن",null).show();}
    private void updateOnlineAssets(){AssetMarketEngine.updateOnlineAssets(this);}
    private void applyMarketToAsset(NexaStore.AssetEntry x){double v=AssetMarketEngine.marketPrice(this,x.type);if(v>0)x.currentUnitPrice=v;}
    private void updateMarketText(){if(marketStatus==null)return;long t=NexaStore.iranMarketUpdated(this);
        if(t<=0){marketStatus.setText("قیمت بازار ایران هنوز دریافت نشده");return;}
        long age=Math.max(0,System.currentTimeMillis()-t);String freshness=age>86400000L?" • داده قدیمی":age>1800000L?" • نیازمند تازه‌سازی":" • تازه";
        marketStatus.setText("آخرین دریافت معتبر: "+PersianDateUtil.pretty(t)+freshness+
            "\nدلار "+PersianFinancialDisplay.amount(NexaStore.iranUsd(this))+" • یورو "+PersianFinancialDisplay.amount(NexaStore.iranEur(this))+
            "\nطلای ۱۸: "+PersianFinancialDisplay.amount(NexaStore.iranGold18(this))+" • طلای ۲۴: "+PersianFinancialDisplay.amount(NexaStore.iranGold24(this))+
            "\nاونس جهانی $"+PersianFinancialDisplay.amount(NexaStore.iranOunce(this))+
            "\nتمام بهار آزادی "+PersianFinancialDisplay.amount(NexaStore.iranBahar(this))+" • نیم بهار آزادی "+PersianFinancialDisplay.amount(NexaStore.iranHalf(this))+" • ربع بهار آزادی "+PersianFinancialDisplay.amount(NexaStore.iranQuarter(this))+
            "\nمنبع: "+NexaStore.iranMarketSource(this));}
    private void checkPriceAlerts(){AssetMarketEngine.checkAlerts(this);}
    private double cost(NexaStore.AssetEntry x){return AssetFinanceEngine.openCost(x);}
    private double value(NexaStore.AssetEntry x){return AssetFinanceEngine.marketValue(x);}
    private String persian(String raw){return PersianFinancialDisplay.digits(raw);}
    private String money(double value){return PersianFinancialDisplay.amount(value)+" تومان";}
    private void render(){renderAssetTypes();if(list==null)return;list.removeAllViews();List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        double initial=AssetFinanceEngine.totalOpenCost(data),now=AssetFinanceEngine.totalMarketValue(data);
        double realized=AssetFinanceEngine.totalRealized(data),profit=now-initial+realized;
        summary.setText("تعداد خریدها: "+data.size()+" • انواع دارایی: "+new LinkedHashSet<String>(){{for(NexaStore.AssetEntry a:data)add(a.type);}}.size()+"\nبهای خرید: "+money(initial)+"\nارزش فعلی: "+money(now)+
            "\nسود/زیان باز: "+(now-initial>=0?"+":"")+money(now-initial)+"\nسود/زیان تحقق‌یافته: "+(realized>=0?"+":"")+money(realized)+"\nسود/زیان کل: "+(profit>=0?"+":"")+money(profit)+
            (initial>0?"   ("+persian(String.format(Locale.US,"%+.2f%%",profit/initial*100.0))+")":""));
        if(data.isEmpty()){TextView e=UiKit.muted(this,"هنوز خریدی ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,15,0));return;}
        Map<String,Map<String,List<NexaStore.AssetEntry>>> typeGroups=new LinkedHashMap<>();
        for(NexaStore.AssetEntry x:data){Map<String,List<NexaStore.AssetEntry>> vendors=typeGroups.get(x.type);
            if(vendors==null){vendors=new LinkedHashMap<>();typeGroups.put(x.type,vendors);}
            NexaStore.ShoppingSeller linked=NexaStore.sellerById(this,x.sellerId);String vendorName=linked!=null?linked.name:(x.name==null||x.name.trim().isEmpty()?"بدون فروشنده":x.name);
            List<NexaStore.AssetEntry> entries=vendors.get(vendorName);
            if(entries==null){entries=new ArrayList<>();vendors.put(vendorName,entries);}entries.add(x);
        }
        for(Map.Entry<String,Map<String,List<NexaStore.AssetEntry>>> type: typeGroups.entrySet()){
            LinearLayout typeCard=UiKit.colorfulCardLayout(this,4),typeBody=new LinearLayout(this);
            typeBody.setOrientation(LinearLayout.VERTICAL);typeBody.setVisibility(View.GONE);
            double tCost=0,tValue=0;int n=0;for(List<NexaStore.AssetEntry> vals:type.getValue().values())
                for(NexaStore.AssetEntry x:vals){tCost+=cost(x);tValue+=value(x);n++;}
            final double ct=tCost,vt=tValue;final int count=n;
            Button head=UiKit.secondaryButton(this,"▸ "+type.getKey()+" • "+n+" مورد • ارزش "+money(vt)+" • "+money(vt-ct));
            head.setOnClickListener(v->{boolean open=typeBody.getVisibility()!=View.VISIBLE;
                typeBody.setVisibility(open?View.VISIBLE:View.GONE);
                head.setText((open?"▾ ":"▸ ")+type.getKey()+" • "+count+" مورد • ارزش "+money(vt)+" • "+money(vt-ct));});
            typeCard.addView(head);
            for(Map.Entry<String,List<NexaStore.AssetEntry>> vendor:type.getValue().entrySet()){
                LinearLayout vendorCard=UiKit.cardLayout(this),vendorBody=new LinearLayout(this);
                vendorBody.setOrientation(LinearLayout.VERTICAL);vendorBody.setVisibility(View.GONE);
                double groupCost=0,groupValue=0,amount=0;
                for(NexaStore.AssetEntry x:vendor.getValue()){groupCost+=cost(x);groupValue+=value(x);amount+=x.amount;}
                Button vendorHead=UiKit.secondaryButton(this,"▸ "+vendor.getKey()+"  ("+vendor.getValue().size()+")");
                vendorHead.setOnClickListener(v->{boolean open=vendorBody.getVisibility()!=View.VISIBLE;
                    vendorBody.setVisibility(open?View.VISIBLE:View.GONE);
                    vendorHead.setText((open?"▾ ":"▸ ")+vendor.getKey()+"  ("+vendor.getValue().size()+")");});
                vendorCard.addView(vendorHead);
                Button addToGroup=UiKit.secondaryButton(this,"＋ خرید در همین مجموعه");
                addToGroup.setOnClickListener(v->editForm(null,type.getKey(),vendor.getKey()));
                vendorCard.addView(addToGroup,UiKit.matchWrap(this,4,6));
                TextView groupAmount=UiKit.muted(this,"مقدار: "+df.format(amount)); vendorCard.addView(groupAmount,UiKit.matchWrap(this,6,2));
                TextView groupBuy=UiKit.muted(this,"مجموع خرید: "+money(groupCost)); groupBuy.setTextColor(UiKit.GOLD); vendorCard.addView(groupBuy,UiKit.matchWrap(this,0,2));
                double groupProfit=groupValue-groupCost; TextView groupValueText=UiKit.muted(this,"ارزش فعلی: "+money(groupValue)); groupValueText.setTextColor(UiKit.TEXT); vendorCard.addView(groupValueText,UiKit.matchWrap(this,0,2));
                TextView groupProfitText=UiKit.muted(this,"سود/زیان: "+money(groupProfit)+(groupCost>0?" ("+persian(String.format(Locale.US,"%+.2f%%",groupProfit/groupCost*100.0))+")":"")); groupProfitText.setTextColor(groupProfit>=0?UiKit.GREEN:UiKit.RED); vendorCard.addView(groupProfitText,UiKit.matchWrap(this,0,6));
                Button groupPrice=UiKit.secondaryButton(this,"✎ قیمت لحظه‌ای سرگروه");
                groupPrice.setContentDescription("ثبت قیمت لحظه‌ای برای تمام خریدهای "+vendor.getKey());
                groupPrice.setOnClickListener(v->editGroupMarketPrice(vendor.getKey(),vendor.getValue()));
                vendorCard.addView(groupPrice,UiKit.matchWrap(this,4,8));
                java.util.Collections.sort(vendor.getValue(),(a,b)->Long.compare(b.buyDate,a.buyDate));
                for(NexaStore.AssetEntry x:vendor.getValue()){
                    LinearLayout row=UiKit.cardLayout(this);double p=value(x)-cost(x);
                    row.addView(UiKit.sectionTitle(this,"خرید "+PersianDateUtil.pretty(x.buyDate)));
                    TextView qtyText=UiKit.muted(this,"مقدار: "+df.format(x.amount)+(x.currency==null||x.currency.isEmpty()?"":" • ارز: "+x.currency)); row.addView(qtyText,UiKit.matchWrap(this,5,2));
                    TextView buyText=UiKit.muted(this,"قیمت خرید: "+money(x.buyUnitPrice)); buyText.setTextColor(UiKit.GOLD); row.addView(buyText,UiKit.matchWrap(this,0,2));
                    TextView currentText=UiKit.muted(this,"قیمت روز: "+money(x.currentUnitPrice)+(x.autoPrice?" 🌐":" ✎")); currentText.setTextColor(UiKit.TEXT); row.addView(currentText,UiKit.matchWrap(this,0,2));
                    TextView profitText=UiKit.muted(this,"سود/زیان: "+money(p)+(cost(x)>0?"  ("+persian(String.format(Locale.US,"%+.2f%%",p/cost(x)*100))+")":"")); profitText.setTextColor(p>=0?UiKit.GREEN:UiKit.RED); row.addView(profitText,UiKit.matchWrap(this,0,2));
                    if(x.fee>0)row.addView(UiKit.muted(this,"کارمزد: "+money(x.fee)),UiKit.matchWrap(this,0,2));
                    if(x.realizedProfit!=0){TextView rp=UiKit.muted(this,"سود/زیان فروش‌ها: "+money(x.realizedProfit));rp.setTextColor(x.realizedProfit>=0?UiKit.GREEN:UiKit.RED);row.addView(rp,UiKit.matchWrap(this,0,2));}
                    if(x.soldAmount>0)row.addView(UiKit.muted(this,"فروخته‌شده: "+df.format(x.soldAmount)),UiKit.matchWrap(this,0,2));
                    if(x.alertTarget>0||x.alertAtBuy)row.addView(UiKit.muted(this,"🔔 هشدار: "+(x.alertAtBuy?"قیمت خرید":money(x.alertTarget))+" • "+("up".equals(x.alertDirection)?"بالاتر از هدف":"down".equals(x.alertDirection)?"پایین‌تر از هدف":"exact".equals(x.alertDirection)?"دقیقاً هدف":"عبور از هدف")),UiKit.matchWrap(this,0,6));
                    if(x.note!=null&&!x.note.trim().isEmpty())row.addView(UiKit.muted(this,"📝 "+x.note),UiKit.matchWrap(this,0,6));
                    LinearLayout buttons=new LinearLayout(this);
                    Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editForm(x));
                    Button sell=UiKit.secondaryButton(this,"فروش");sell.setOnClickListener(v->sellForm(x));
                    Button bell=UiKit.secondaryButton(this,(x.alertTarget>0||x.alertAtBuy)?"🔔":"🔕");bell.setOnClickListener(v->priceAlertDialog(x));
                    Button delete=UiKit.deleteIconButton(this);delete.setOnClickListener(v->new AlertDialog.Builder(this)
                        .setTitle("حذف خرید؟").setMessage(x.name+" • "+PersianDateUtil.pretty(x.buyDate))
                        .setPositiveButton("حذف",(d,w)->{NexaStore.removeAsset(this,x.id);PriceMonitorReceiver.schedule(this);render();})
                        .setNegativeButton("انصراف",null).show());
                    buttons.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(UiKit.dp(this,72),UiKit.dp(this,44));slp.setMargins(UiKit.dp(this,5),0,0,0);buttons.addView(sell,slp);LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(UiKit.dp(this,52),UiKit.dp(this,44));blp.setMargins(UiKit.dp(this,5),0,0,0);buttons.addView(bell,blp);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dlp.setMargins(UiKit.dp(this,5),0,0,0);buttons.addView(delete,dlp);
                    row.addView(buttons,UiKit.matchWrap(this,7,0));vendorBody.addView(row,UiKit.matchWrap(this,6,0));
                }
                vendorCard.addView(vendorBody);typeBody.addView(vendorCard,UiKit.matchWrap(this,7,0));
            }
            typeCard.addView(typeBody);list.addView(typeCard,UiKit.matchWrap(this,0,10));
        }
    }
    private void priceAlertDialog(NexaStore.AssetEntry x){
        LinearLayout box=UiKit.dialogPanel(this);
        EditText target=field("قیمت هدف (تومان)");target.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(target);
        if(x.alertTarget>0)target.setText(moneyFormat.format(x.alertTarget));
        Spinner mode=picker(java.util.Arrays.asList("بالاتر از قیمت هدف","پایین‌تر از قیمت هدف","دقیقاً قیمت هدف","عبور از قیمت هدف"));
        int pos="down".equals(x.alertDirection)?1:("exact".equals(x.alertDirection)?2:("both".equals(x.alertDirection)?3:0));mode.setSelection(pos);
        CheckBox atBuy=new CheckBox(this);atBuy.setText("هدف = قیمت خرید من ("+money(x.buyUnitPrice)+")");atBuy.setTextColor(UiKit.TEXT);atBuy.setChecked(x.alertAtBuy);
        box.addView(UiKit.muted(this,"هشدار مستقیم برای همین خرید؛ بدون ورود به فرم ویرایش دارایی."),UiKit.matchWrap(this,0,8));
        box.addView(target,UiKit.matchWrap(this,0,8));box.addView(mode,UiKit.matchWrap(this,0,8));box.addView(atBuy,UiKit.matchWrap(this,0,4));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("🔔 هشدار قیمت").setView(box)
            .setPositiveButton("ذخیره",null).setNeutralButton("خاموش کردن",null).setNegativeButton("انصراف",null).create();
        dlg.setOnShowListener(v->{
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{double t=num(target.getText().toString());if(!atBuy.isChecked()&&t<=0){Toast.makeText(this,"قیمت هدف را وارد کن.",Toast.LENGTH_SHORT).show();return;}x.alertAtBuy=atBuy.isChecked();x.alertTarget=x.alertAtBuy?0:t;int m=mode.getSelectedItemPosition();x.alertDirection=m==0?"up":m==1?"down":m==2?"exact":"both";x.alertTriggered=false;x.lastAlertObservedPrice=x.currentUnitPrice;NexaStore.updateAsset(this,x);PriceMonitorReceiver.schedule(this);dlg.dismiss();render();});
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(b->{x.alertTarget=0;x.alertAtBuy=false;x.alertTriggered=false;x.lastAlertObservedPrice=0;NexaStore.updateAsset(this,x);PriceMonitorReceiver.schedule(this);dlg.dismiss();render();});
        });dlg.show();
    }

    private void editGroupMarketPrice(String groupName,List<NexaStore.AssetEntry> entries){
        if(entries==null||entries.isEmpty())return;
        LinearLayout box=UiKit.dialogPanel(this);
        box.addView(UiKit.sectionTitle(this,"قیمت لحظه‌ای • "+groupName),UiKit.matchWrap(this,0,6));
        box.addView(UiKit.muted(this,"این قیمت فقط ارزش روز را برای تمام زیرگروه‌ها/خریدهای این سرگروه به‌روزرسانی می‌کند؛ قیمت خرید تاریخی تغییر نمی‌کند."),UiKit.matchWrap(this,0,8));
        EditText price=field("قیمت لحظه‌ای هر واحد (تومان)");price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        double current=0;for(NexaStore.AssetEntry e:entries)if(e.currentUnitPrice>0){current=e.currentUnitPrice;break;}
        if(current>0)price.setText(moneyFormat.format(current));box.addView(price);
        new AlertDialog.Builder(this).setTitle("بروزرسانی سرگروه").setView(box).setPositiveButton("اعمال به همه",(d,w)->{
            double value=num(price.getText().toString());if(value<=0){Toast.makeText(this,"قیمت معتبر وارد کنید.",Toast.LENGTH_SHORT).show();return;}
            for(NexaStore.AssetEntry e:entries){e.currentUnitPrice=value;e.autoPrice=false;NexaStore.updateAsset(this,e);}
            NexaStore.addHistory(this,"دارایی","قیمت لحظه‌ای "+groupName+" • "+money(value));render();
        }).setNegativeButton("انصراف",null).show();
    }

    private void sellForm(NexaStore.AssetEntry x){
        if(x.amount<=0){Toast.makeText(this,"موجودی این خرید صفر است.",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.muted(this,"موجودی قابل فروش: "+df.format(x.amount)+" • میانگین خرید: "+money(x.buyUnitPrice)),UiKit.matchWrap(this,0,6));
        EditText qty=field("مقدار فروش"),price=field("قیمت فروش هر واحد (تومان)");qty.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);price.setText(x.currentUnitPrice>0?moneyFormat.format(x.currentUnitPrice):"");box.addView(qty,UiKit.matchWrap(this,4,4));box.addView(price,UiKit.matchWrap(this,4,4));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ثبت فروش • "+x.type).setView(box).setPositiveButton("ثبت فروش",null).setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(dd->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{double q=num(qty.getText().toString()),p=num(price.getText().toString());if(!AssetFinanceEngine.sell(x,q,p,System.currentTimeMillis())){Toast.makeText(this,"مقدار یا قیمت فروش معتبر نیست.",Toast.LENGTH_LONG).show();return;}NexaStore.updateAsset(this,x);NexaStore.addHistory(this,"دارایی","فروش "+x.type+" • "+df.format(q)+" واحد • "+money(p));render();dialog.dismiss();}));dialog.show();
    }
    private double num(String raw){try{String s=raw.trim().replace(",","").replace("٬","").replace("٫",".");
        StringBuilder result=new StringBuilder();for(int i=0;i<s.length();i++){char ch=s.charAt(i);
            if(ch>='۰'&&ch<='۹')ch=(char)('0'+ch-'۰');if(ch>='٠'&&ch<='٩')ch=(char)('0'+ch-'٠');result.append(ch);}
        return Double.parseDouble(result.toString());}catch(Exception e){return 0;}}
}
