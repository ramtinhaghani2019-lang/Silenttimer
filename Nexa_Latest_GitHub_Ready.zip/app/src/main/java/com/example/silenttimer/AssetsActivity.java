package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Editable, grouped portfolio. No online price is represented as verified Iranian consensus. */
public class AssetsActivity extends Activity {
    private LinearLayout list,typeManagerList;
    private TextView summary,marketStatus;
    private EditText usdToman;
    private final DecimalFormat df=new DecimalFormat("#,##0.###");
    private final DecimalFormat moneyFormat=new DecimalFormat("#,##0.##");
    private final List<String> standardTypes=new ArrayList<>();
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        java.util.Collections.addAll(standardTypes,"طلای ۱۸ عیار","طلای ۲۴ عیار","نقره","مس","دلار","یورو","سهام / بورس","سایر");
        build();if(getIntent().getBooleanExtra("quick_add",false))list.postDelayed(()->editForm(null),250);
    }
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));return e;}
    private Spinner picker(List<String> values){Spinner s=new Spinner(this);
        ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
            @Override public View getView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setPadding(12,12,12,12);return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);t.setPadding(14,14,14,14);return t;}
        };a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);return s;
    }
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,28));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,UiKit.matchWrap(this,0,12));
        root.addView(UiKit.title(this,"Nexa Assets"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"📈 دارایی‌ها • گروه‌بندی نوع و فروشنده • سود و زیان"),UiKit.matchWrap(this,0,14));
        LinearLayout sum=UiKit.colorfulCardLayout(this,4);sum.addView(UiKit.sectionTitle(this,"ارزش سبد"));
        summary=UiKit.muted(this,"");summary.setTextSize(16);sum.addView(summary,UiKit.matchWrap(this,8,0));root.addView(sum,UiKit.matchWrap(this,0,12));
        LinearLayout market=UiKit.colorfulCardLayout(this,7);market.addView(UiKit.sectionTitle(this,"🌐 مرجع جهانی و برآورد تومانی"));
        market.addView(UiKit.muted(this,"قیمت جهانی از سرویس مرجع خارجی دریافت می‌شود؛ نرخ ارز واردشده دستی است. این بخش هنوز نرخ تأییدشده چند منبع ایرانی نیست."),UiKit.matchWrap(this,8,8));
        usdToman=field("نرخ دلار به تومان (دستی)");usdToman.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(usdToman);
        double rate=NexaStore.usdToman(this);if(rate>0)usdToman.setText(String.format(Locale.US,"%.0f",rate));
        market.addView(usdToman,UiKit.matchWrap(this,0,9));
        Button saveRate=UiKit.secondaryButton(this,"ذخیره نرخ دلار");saveRate.setOnClickListener(v->{double r=num(usdToman.getText().toString());
            if(r<=0)return;NexaStore.setUsdToman(this,r);updateOnlineAssets();render();});market.addView(saveRate,UiKit.matchWrap(this,0,8));
        List<String> modes=new ArrayList<>();java.util.Collections.addAll(modes,"فقط دستی / آفلاین","به‌روزرسانی آنلاین هنگام درخواست","خودکار هنگام باز بودن (هر ۵ دقیقه)");
        Spinner mode=picker(modes);mode.setSelection(NexaStore.marketRefreshMode(this));
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long id){
                NexaStore.setMarketRefreshMode(AssetsActivity.this,position);
            }});
        market.addView(mode,UiKit.matchWrap(this,0,8));
        Button refresh=UiKit.primaryButton(this,"دریافت قیمت جهانی");refresh.setOnClickListener(v->refreshMarket(refresh));market.addView(refresh);
        marketStatus=UiKit.muted(this,"");market.addView(marketStatus,UiKit.matchWrap(this,10,0));
        root.addView(market,UiKit.matchWrap(this,0,12));
        LinearLayout typesCard=UiKit.colorfulCardLayout(this,1);LinearLayout typeHead=new LinearLayout(this);typeHead.setGravity(Gravity.CENTER_VERTICAL);
        typeHead.addView(UiKit.sectionTitle(this,"انواع دارایی"),new LinearLayout.LayoutParams(0,-2,1f));Button typePlus=UiKit.addIconButton(this);typePlus.setOnClickListener(v->addAssetTypeDialog());typeHead.addView(typePlus,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));typesCard.addView(typeHead);
        typesCard.addView(UiKit.muted(this,"تعریف نوع جدید فقط از این لیست انجام می‌شود."),UiKit.matchWrap(this,6,8));typeManagerList=new LinearLayout(this);typeManagerList.setOrientation(LinearLayout.VERTICAL);typesCard.addView(typeManagerList);root.addView(typesCard,UiKit.matchWrap(this,0,12));
        Button add=UiKit.primaryButton(this,"＋ ثبت دارایی / خرید جدید");add.setOnClickListener(v->editForm(null));root.addView(add,UiKit.matchWrap(this,0,14));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);
        renderAssetTypes();render();updateMarketText();
    }
    @Override protected void onResume(){super.onResume();if(list!=null){
        if(NexaStore.marketRefreshMode(this)==2 && System.currentTimeMillis()-NexaStore.marketUpdated(this)>300000L){
            // No background polling: only refresh on screen opening, if cache is stale.
            MarketDataHelper.refresh(this,(ok,msg)->{if(ok){updateOnlineAssets();render();}if(marketStatus!=null)marketStatus.setText(msg);});
        }
    }}
    private List<String> assetTypeValues(){List<String> out=new ArrayList<>(standardTypes);for(String x:NexaStore.assetTypes(this))if(!out.contains(x))out.add(x);for(NexaStore.AssetEntry x:NexaStore.assets(this))if(!out.contains(x.type))out.add(x.type);return out;}
    private void renderAssetTypes(){if(typeManagerList==null)return;typeManagerList.removeAllViews();for(String t:assetTypeValues()){TextView row=UiKit.muted(this,"• "+t);row.setTextSize(14);typeManagerList.addView(row,UiKit.matchWrap(this,0,4));}}
    private void addAssetTypeDialog(){EditText entry=field("نام نوع دارایی جدید");new AlertDialog.Builder(this).setTitle("نوع دارایی جدید").setView(entry).setPositiveButton("افزودن",(d,w)->{String t=entry.getText().toString().trim();if(t.isEmpty())return;NexaStore.addAssetType(this,t);renderAssetTypes();}).setNegativeButton("انصراف",null).show();}

    private void refreshMarket(Button b){
        if(NexaStore.marketRefreshMode(this)==0){Toast.makeText(this,"دریافت اینترنتی خاموش است.",Toast.LENGTH_SHORT).show();return;}
        b.setEnabled(false);marketStatus.setText("در حال دریافت...");
        MarketDataHelper.refresh(this,(ok,msg)->{b.setEnabled(true);marketStatus.setText(msg);
            if(ok){updateOnlineAssets();render();}});
    }
    private void editForm(NexaStore.AssetEntry current){
        LinearLayout box=UiKit.dialogPanel(this);
        List<String> types=assetTypeValues();
        Spinner type=picker(types);if(current!=null)type.setSelection(Math.max(0,types.indexOf(current.type)));
        EditText name=field("فروشنده / مجموعه؛ مثلاً طلای جوادی");
        final String[] sellerId={current==null?"":current.sellerId};
        Button sellerBtn=UiKit.secondaryButton(this,"انتخاب از دفتر مشترک فروشندگان");
        NexaStore.ShoppingSeller oldSeller=current==null?null:NexaStore.sellerById(this,current.sellerId);if(oldSeller!=null)sellerBtn.setText("فروشنده: "+oldSeller.name);
        sellerBtn.setOnClickListener(v->pickSeller(sellerId,sellerBtn,name));
        EditText amount=field("مقدار؛ مثلاً ۵٫۲۵ گرم");amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText soot=field("سوت اضافه (۰ تا ۹۹۹) برای طلا");soot.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText buy=field("قیمت خرید هر واحد");buy.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(buy);
        EditText quote=field("قیمت فعلی هر واحد");quote.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(quote);
        EditText fee=field("مجموع کارمزد و هزینه");fee.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(fee);
        Spinner currency=picker(java.util.Arrays.asList("تومان","ریال"));
        CheckBox online=new CheckBox(this);online.setText("قیمت روز از مرجع جهانی (اگر برای این نوع موجود باشد)");online.setTextColor(UiKit.TEXT);
        EditText note=field("توضیحات / مشخصات");
        final long[] buyDate={current==null?System.currentTimeMillis():current.buyDate};
        Button date=UiKit.secondaryButton(this,"تاریخ و ساعت خرید: "+PersianDateUtil.pretty(buyDate[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,buyDate[0],"تاریخ و ساعت خرید",ms->{buyDate[0]=ms;date.setText("تاریخ و ساعت خرید: "+PersianDateUtil.pretty(ms));}));
        TextView total=UiKit.sectionTitle(this,"مجموع خرید: —");
        if(current!=null){name.setText(current.name);amount.setText(df.format(current.amount));
            buy.setText(df.format("ریال".equals(current.currency)?current.buyUnitPrice*10:current.buyUnitPrice));
            quote.setText(df.format("ریال".equals(current.currency)?current.currentUnitPrice*10:current.currentUnitPrice));
            fee.setText(df.format("ریال".equals(current.currency)?current.fee*10:current.fee));
            currency.setSelection("ریال".equals(current.currency)?1:0);online.setChecked(current.autoPrice);note.setText(current.note);}
        // An existing asset amount already includes soot; editing starts from the exact decimal amount.
        TextWatcher calculate=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){double a=num(amount.getText().toString());
                double price=num(buy.getText().toString());double fees=num(fee.getText().toString());int extra=(int)num(soot.getText().toString());
                if(extra>=0&&extra<=999)a+=extra/1000.0;
                double totalPrice=a*price+fees;total.setText("مجموع خرید: "+moneyFormat.format(totalPrice)+" "+currency.getSelectedItem());}
            public void afterTextChanged(Editable e){}};
        amount.addTextChangedListener(calculate);buy.addTextChangedListener(calculate);fee.addTextChangedListener(calculate);soot.addTextChangedListener(calculate);
        currency.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}
            public void onItemSelected(android.widget.AdapterView<?> a,View v,int i,long id){total.setText("مجموع خرید: "+moneyFormat.format(num(amount.getText().toString())*num(buy.getText().toString())+num(fee.getText().toString()))+" "+currency.getSelectedItem());}});
        box.addView(type,UiKit.matchWrap(this,0,8));box.addView(UiKit.muted(this,"نوع جدید را از لیست «انواع دارایی» صفحه اصلی این بخش اضافه کن."),UiKit.matchWrap(this,0,6));for(View v:new View[]{name,sellerBtn,amount,soot,buy,quote,fee,currency,online,date,total,note})box.addView(v,UiKit.matchWrap(this,0,8));
        ScrollView sc=new ScrollView(this);sc.addView(box);
        new AlertDialog.Builder(this).setTitle(current==null?"ثبت خرید دارایی":"ویرایش کامل خرید")
            .setView(sc).setPositiveButton("ذخیره",(d,w)->{
                double a=num(amount.getText().toString()),b=num(buy.getText().toString());int st=(int)num(soot.getText().toString());
                if(st<0||st>999){Toast.makeText(this,"سوت باید ۰ تا ۹۹۹ باشد.",Toast.LENGTH_LONG).show();return;}
                a+=st/1000.0;
                if(a<=0||b<=0){Toast.makeText(this,"مقدار و قیمت خرید باید مثبت باشند.",Toast.LENGTH_LONG).show();return;}
                NexaStore.AssetEntry x=current==null?new NexaStore.AssetEntry():current;
                x.type=String.valueOf(type.getSelectedItem());x.name=name.getText().toString().trim();
                if(x.name.isEmpty())x.name="بدون مجموعه";
                x.amount=a;double divisor=currency.getSelectedItemPosition()==1?10.0:1.0;
                x.buyUnitPrice=b/divisor;x.currentUnitPrice=num(quote.getText().toString())/divisor;
                if(x.currentUnitPrice<=0)x.currentUnitPrice=x.buyUnitPrice;
                x.fee=num(fee.getText().toString())/divisor;x.currency=String.valueOf(currency.getSelectedItem());
                x.autoPrice=online.isChecked();x.buyDate=buyDate[0];x.note=note.getText().toString().trim();x.sellerId=sellerId[0];
                if(x.autoPrice)applyMarketToAsset(x);
                if(current==null)NexaStore.addAsset(this,x);else NexaStore.updateAsset(this,x);
                NexaStore.addHistory(this,"دارایی",(current==null?"خرید جدید: ":"ویرایش خرید: ")+x.name);render();
            }).setNegativeButton("انصراف",null).show();
    }
    private void pickSeller(String[] out,Button btn,EditText name){List<NexaStore.ShoppingSeller> data=NexaStore.sellers(this);LinearLayout box=UiKit.dialogPanel(this);if(data.isEmpty())box.addView(UiKit.muted(this,"فروشنده‌ای ثبت نشده؛ از Settings > دفتر مشترک اضافه کن."));for(NexaStore.ShoppingSeller s:data){Button b=UiKit.secondaryButton(this,s.name+(s.category.isEmpty()?"":" • "+s.category));b.setOnClickListener(v->{out[0]=s.id;btn.setText("فروشنده: "+s.name);name.setText(s.name);});box.addView(b,UiKit.matchWrap(this,0,5));}new AlertDialog.Builder(this).setTitle("انتخاب فروشنده").setView(box).setPositiveButton("بستن",null).show();}
    private void updateOnlineAssets(){List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        for(NexaStore.AssetEntry x:data)if(x.autoPrice)applyMarketToAsset(x);NexaStore.saveAssets(this,data);}
    private void applyMarketToAsset(NexaStore.AssetEntry x){
        double usd=NexaStore.usdToman(this);if(usd<=0)return;
        double gold=NexaStore.marketGold(this),silver=NexaStore.marketSilver(this),eur=NexaStore.marketEurPerUsd(this);
        if(x.type.contains("۱۸")&&gold>0)x.currentUnitPrice=(gold/31.1034768)*0.75*usd;
        else if(x.type.contains("۲۴")&&gold>0)x.currentUnitPrice=(gold/31.1034768)*usd;
        else if(x.type.equals("نقره")&&silver>0)x.currentUnitPrice=(silver/31.1034768)*usd;
        else if(x.type.equals("دلار"))x.currentUnitPrice=usd;
        else if(x.type.equals("یورو")&&eur>0)x.currentUnitPrice=usd/eur;
    }
    private void updateMarketText(){if(marketStatus==null)return;long t=NexaStore.marketUpdated(this);
        marketStatus.setText(t<=0?"قیمت جهانی هنوز دریافت نشده":"آخرین دریافت جهانی: "+PersianDateUtil.pretty(t)+
                "\nXAU $"+df.format(NexaStore.marketGold(this))+"    XAG $"+df.format(NexaStore.marketSilver(this)));}
    private double cost(NexaStore.AssetEntry x){return x.amount*x.buyUnitPrice+x.fee;}
    private double value(NexaStore.AssetEntry x){return x.amount*x.currentUnitPrice;}
    private String money(double value){return moneyFormat.format(value)+" تومان";}
    private void render(){renderAssetTypes();if(list==null)return;list.removeAllViews();List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        double initial=0,now=0;for(NexaStore.AssetEntry x:data){initial+=cost(x);now+=value(x);}
        double profit=now-initial;
        summary.setText("بهای خرید: "+money(initial)+"\nارزش فعلی: "+money(now)+
            "\nسود/زیان: "+(profit>=0?"+":"")+money(profit)+
            (initial>0?"   ("+String.format(Locale.US,"%+.2f%%",profit/initial*100.0)+")":""));
        if(data.isEmpty()){TextView e=UiKit.muted(this,"هنوز خریدی ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,15,0));return;}
        Map<String,Map<String,List<NexaStore.AssetEntry>>> typeGroups=new LinkedHashMap<>();
        for(NexaStore.AssetEntry x:data){Map<String,List<NexaStore.AssetEntry>> vendors=typeGroups.get(x.type);
            if(vendors==null){vendors=new LinkedHashMap<>();typeGroups.put(x.type,vendors);}
            List<NexaStore.AssetEntry> entries=vendors.get(x.name);
            if(entries==null){entries=new ArrayList<>();vendors.put(x.name,entries);}entries.add(x);
        }
        for(Map.Entry<String,Map<String,List<NexaStore.AssetEntry>>> type: typeGroups.entrySet()){
            LinearLayout typeCard=UiKit.colorfulCardLayout(this,4),typeBody=new LinearLayout(this);
            typeBody.setOrientation(LinearLayout.VERTICAL);typeBody.setVisibility(View.GONE);
            double tCost=0,tValue=0;int n=0;for(List<NexaStore.AssetEntry> vals:type.getValue().values())
                for(NexaStore.AssetEntry x:vals){tCost+=cost(x);tValue+=value(x);n++;}
            final double ct=tCost,vt=tValue;final int count=n;
            Button head=UiKit.secondaryButton(this,"▸ "+type.getKey()+" • "+n+" مورد • "+money(vt-ct));
            head.setOnClickListener(v->{boolean open=typeBody.getVisibility()!=View.VISIBLE;
                typeBody.setVisibility(open?View.VISIBLE:View.GONE);
                head.setText((open?"▾ ":"▸ ")+type.getKey()+" • "+count+" مورد • "+money(vt-ct));});
            typeCard.addView(head);
            for(Map.Entry<String,List<NexaStore.AssetEntry>> vendor:type.getValue().entrySet()){
                LinearLayout vendorCard=UiKit.cardLayout(this),vendorBody=new LinearLayout(this);
                vendorBody.setOrientation(LinearLayout.VERTICAL);vendorBody.setVisibility(View.GONE);
                double groupCost=0,groupValue=0,amount=0;
                for(NexaStore.AssetEntry x:vendor.getValue()){groupCost+=cost(x);groupValue+=value(x);amount+=x.amount;}
                Button vendorHead=UiKit.secondaryButton(this,"▸ "+vendor.getKey()+"  ("+vendor.getValue().size()+")");
                vendorHead.setOnClickListener(v->{boolean open=vendorBody.getVisibility()!=View.VISIBLE;
                    vendorBody.setVisibility(open?View.VISIBLE:View.GONE);
                    vendorHead.setText((open?"▾ ":"▸ ")+vendor.getKey()+"  ("+vendor.getValue().size()+")");});
                vendorCard.addView(vendorHead);
                vendorCard.addView(UiKit.muted(this,"مقدار: "+df.format(amount)+" • مجموع خرید: "+money(groupCost)+
                    "\nارزش: "+money(groupValue)+" • سود/زیان: "+money(groupValue-groupCost)),UiKit.matchWrap(this,6,6));
                for(NexaStore.AssetEntry x:vendor.getValue()){
                    LinearLayout row=UiKit.cardLayout(this);double p=value(x)-cost(x);
                    row.addView(UiKit.sectionTitle(this,"خرید "+PersianDateUtil.pretty(x.buyDate)));
                    row.addView(UiKit.muted(this,"مقدار: "+df.format(x.amount)+" • قیمت خرید: "+money(x.buyUnitPrice)+
                        "\nقیمت روز: "+money(x.currentUnitPrice)+(x.autoPrice?" 🌐":" ✎")+"\nسود/زیان: "+money(p)+
                        (cost(x)>0?"  ("+String.format(Locale.US,"%+.2f%%",p/cost(x)*100)+")":"")),UiKit.matchWrap(this,5,6));
                    LinearLayout buttons=new LinearLayout(this);
                    Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editForm(x));
                    Button delete=UiKit.deleteIconButton(this);delete.setOnClickListener(v->new AlertDialog.Builder(this)
                        .setTitle("حذف خرید؟").setMessage(x.name+" • "+PersianDateUtil.pretty(x.buyDate))
                        .setPositiveButton("حذف",(d,w)->{NexaStore.removeAsset(this,x.id);render();})
                        .setNegativeButton("انصراف",null).show());
                    buttons.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dlp.setMargins(UiKit.dp(this,5),0,0,0);buttons.addView(delete,dlp);
                    row.addView(buttons,UiKit.matchWrap(this,7,0));vendorBody.addView(row,UiKit.matchWrap(this,6,0));
                }
                vendorCard.addView(vendorBody);typeBody.addView(vendorCard,UiKit.matchWrap(this,7,0));
            }
            typeCard.addView(typeBody);list.addView(typeCard,UiKit.matchWrap(this,0,10));
        }
    }
    private double num(String raw){try{String s=raw.trim().replace(",","").replace("٬","").replace("٫",".");
        StringBuilder result=new StringBuilder();for(int i=0;i<s.length();i++){char ch=s.charAt(i);
            if(ch>='۰'&&ch<='۹')ch=(char)('0'+ch-'۰');if(ch>='٠'&&ch<='٩')ch=(char)('0'+ch-'٠');result.append(ch);}
        return Double.parseDouble(result.toString());}catch(Exception e){return 0;}}
}
