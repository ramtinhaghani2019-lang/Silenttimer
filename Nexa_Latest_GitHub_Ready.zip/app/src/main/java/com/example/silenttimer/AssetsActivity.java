package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Editable, grouped portfolio. No online price is represented as verified Iranian consensus. */
public class AssetsActivity extends Activity {
    private LinearLayout list;
    private String pendingVoiceTitle;
    private GridLayout typeManagerList;
    private TextView summary,marketStatus,marketSource,marketFeedback,portfolioTotal,portfolioChange,marketHeaderFreshness;
    private LinearLayout marketRateContainer;
    private LinearLayout metricContainer,filterContainer;
    private int assetFilter=0;
    // Flat positions first; legacy hierarchical operations stay available on demand.
    private boolean groupedView=true; // Show each asset type once; expand to see individual purchases.
    private EditText usdToman;
    private final DecimalFormat df=new DecimalFormat("#,##0.###");
    private final DecimalFormat moneyFormat=new DecimalFormat("#,##0.##");
    private final List<String> standardTypes=new ArrayList<>();
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        java.util.Collections.addAll(standardTypes,"طلای ۱۸ عیار","طلای ۲۴ عیار","نقره","مس","دلار","یورو","سکه تمام بهار آزادی","نیم‌سکه بهار آزادی","ربع‌سکه بهار آزادی","سکه گرمی","سهام / بورس","سایر");
        pendingVoiceTitle=getIntent().getStringExtra("voice_title");
        build();if(getIntent().getBooleanExtra("quick_add",false)){
            getIntent().removeExtra("quick_add");
            list.postDelayed(()->editForm(null),250);
        }
    }
    private EditText field(String hint){return UiKit.styleField(this,new EditText(this),hint);}
    private Spinner picker(List<String> values){Spinner s=UiKit.styledSpinner(this);
        ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
            @Override public View getView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setPadding(12,12,12,12);return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);t.setPadding(14,14,14,14);return t;}
        };a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);return s;
    }
    private void build(){
        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,16),UiKit.dp(this,14),UiKit.dp(this,16),UiKit.dp(this,28));
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);
        root.addView(UiKit.header(this,"دارایی‌ها",v->finish()),UiKit.matchWrap(this,0,14));

        // One primary number, one secondary result. No duplicate market/portfolio banners.
        LinearLayout hero=NexaAssetsUi.hero(this);
        hero.addView(UiKit.muted(this,"ارزش روز دارایی‌ها"),UiKit.matchWrap(this,0,5));
        portfolioTotal=UiKit.title(this,"—");
        portfolioTotal.setTextSize(22f);
        portfolioTotal.setMaxLines(2);
        portfolioTotal.setTextColor(UiKit.TEXT);
        hero.addView(portfolioTotal,UiKit.matchWrap(this,0,9));
        portfolioChange=UiKit.muted(this,"سود یا زیان کل");
        portfolioChange.setTextSize(13f);
        hero.addView(portfolioChange);
        root.addView(hero,UiKit.matchWrap(this,0,14));

        // One primary action. Market refresh is an icon beside its own section title.
        Button add=UiKit.primaryButton(this,"＋  ثبت خرید جدید");
        add.setContentDescription("ثبت خرید جدید دارایی");
        add.setOnClickListener(v->editForm(null));
        root.addView(add,new LinearLayout.LayoutParams(-1,UiKit.dp(this,50)));

        LinearLayout listTitle=new LinearLayout(this);
        listTitle.setGravity(Gravity.CENTER_VERTICAL);
        listTitle.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        listTitle.addView(UiKit.sectionTitle(this,"دارایی‌های من"),new LinearLayout.LayoutParams(0,-2,1f));
        Button layout=UiKit.secondaryButton(this,"فهرست ساده");
        layout.setTextSize(12f);
        layout.setContentDescription("تغییر نمایش فهرست و گروه‌بندی خریدها");
        layout.setOnClickListener(v->{groupedView=!groupedView;layout.setText(groupedView?"فهرست ساده":"گروه‌بندی");render();});
        listTitle.addView(layout,new LinearLayout.LayoutParams(UiKit.dp(this,116),UiKit.dp(this,48)));
        root.addView(listTitle,UiKit.matchWrap(this,0,8));
        filterContainer=new LinearLayout(this);
        filterContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(filterContainer,UiKit.matchWrap(this,0,10));
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list,UiKit.matchWrap(this,0,14));

        // Advanced reporting does not compete with the main task (viewing a purchase).
        LinearLayout report=new LinearLayout(this);
        report.setOrientation(LinearLayout.VERTICAL);
        metricContainer=new LinearLayout(this);
        metricContainer.setOrientation(LinearLayout.VERTICAL);
        report.addView(metricContainer,UiKit.matchWrap(this,0,8));
        summary=UiKit.muted(this,"");
        summary.setTextSize(13f);
        report.addView(summary);
        View assetReportSection=UiKit.collapsible(this,"asset_breakdown_199","گزارش مالی","بهای خرید و سود/زیان",2,false,report);
        root.addView(assetReportSection,UiKit.matchWrap(this,0,10));

        LinearLayout market=new LinearLayout(this);
        market.setOrientation(LinearLayout.VERTICAL);
        market.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        marketStatus=UiKit.muted(this,"");
        marketStatus.setTextSize(12f);
        market.addView(marketStatus,UiKit.matchWrap(this,2,8));
        marketRateContainer=new LinearLayout(this);
        marketRateContainer.setOrientation(LinearLayout.VERTICAL);
        marketRateContainer.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        market.addView(marketRateContainer,UiKit.matchWrap(this,0,8));
        marketSource=UiKit.muted(this,"");
        marketSource.setTextSize(11.5f);
        market.addView(marketSource,UiKit.matchWrap(this,0,11));
        Button history=UiKit.secondaryButton(this,"نمودار و تاریخچه نرخ‌ها");
        history.setTextSize(13f);
        history.setOnClickListener(v->showMarketHistory());
        market.addView(history,new LinearLayout.LayoutParams(-1,UiKit.dp(this,48)));
        Button alerts=UiKit.secondaryButton(this,"مدیریت هشدار قیمت");
        alerts.setTextSize(13f);
        alerts.setOnClickListener(v->showPriceAlertManager());
        market.addView(alerts,new LinearLayout.LayoutParams(-1,UiKit.dp(this,48)));
        marketFeedback=UiKit.muted(this,"");
        marketFeedback.setTextSize(12f);
        market.addView(marketFeedback,UiKit.matchWrap(this,5,0));
        LinearLayout modePanel=new LinearLayout(this);
        modePanel.setOrientation(LinearLayout.VERTICAL);
        List<String> modes=new ArrayList<>();
        java.util.Collections.addAll(modes,"فقط دستی / آفلاین","آنلاین هنگام درخواست","خودکار هنگام باز شدن صفحه (هر ۵ دقیقه)");
        Spinner mode=picker(modes);
        mode.setSelection(NexaStore.marketRefreshMode(this));
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long id){NexaStore.setMarketRefreshMode(AssetsActivity.this,position);}
        });
        modePanel.addView(UiKit.fieldLabel(this,"روش دریافت قیمت"),UiKit.matchWrap(this,0,5));
        modePanel.addView(mode,UiKit.matchWrap(this,0,5));
        modePanel.addView(UiKit.muted(this,"در حالت خودکار فقط هنگام بازکردن صفحه و در صورت قدیمی بودن اطلاعات، دریافت انجام می‌شود."),UiKit.matchWrap(this,5,0));
        market.addView(UiKit.collapsible(this,"asset_market_mode_207","تنظیمات دریافت نرخ","",3,false,modePanel),UiKit.matchWrap(this,10,0));
        LinearLayout assetMarketSection=UiKit.collapsible(this,"market_controls_176","نرخ‌های بازار","ارز، طلا و سکه • آخرین قیمت‌ها",5,false,market);
        // Header-level refresh stays visible when rates are collapsed and does not open the panel.
        LinearLayout marketHeader=(LinearLayout)assetMarketSection.getChildAt(0);
        TextView marketHeading=(TextView)marketHeader.getChildAt(0);
        marketHeader.removeViewAt(0);
        LinearLayout titleStack=new LinearLayout(this);
        titleStack.setOrientation(LinearLayout.VERTICAL);
        titleStack.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        titleStack.addView(marketHeading);
        marketHeaderFreshness=UiKit.muted(this,"هنوز دریافت نشده");
        marketHeaderFreshness.setTextSize(11f);
        marketHeaderFreshness.setMaxLines(1);
        titleStack.addView(marketHeaderFreshness,UiKit.matchWrap(this,1,0));
        marketHeader.addView(titleStack,0,new LinearLayout.LayoutParams(0,-2,1f));
        Button compactRefresh=UiKit.secondaryButton(this,"⟳");
        compactRefresh.setTextSize(22f);compactRefresh.setTextColor(UiKit.GOLD);
        compactRefresh.setContentDescription("به‌روزرسانی نرخ‌های بازار");
        compactRefresh.setOnClickListener(v->refreshMarket(compactRefresh));
        marketHeader.addView(compactRefresh,1,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        root.addView(assetMarketSection,UiKit.matchWrap(this,0,10));

        // Category management retains all legacy commands, but does not clutter the portfolio.
        LinearLayout typesBody=new LinearLayout(this);
        typesBody.setOrientation(LinearLayout.VERTICAL);
        LinearLayout typeHead=new LinearLayout(this);
        typeHead.setGravity(Gravity.CENTER_VERTICAL);
        typeHead.addView(UiKit.sectionTitle(this,"دسته‌بندی دارایی‌ها"),new LinearLayout.LayoutParams(0,-2,1f));
        Button typePlus=UiKit.addIconButton(this);
        typePlus.setOnClickListener(v->addAssetTypeDialog());
        typeHead.addView(typePlus,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        typesBody.addView(typeHead);
        typeManagerList=new GridLayout(this);
        typeManagerList.setColumnCount(getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density>=390?3:2);
        typesBody.addView(typeManagerList);
        Button typeInfo=UiKit.secondaryButton(this,"راهنمای دسته‌بندی‌ها");
        typeInfo.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("راهنمای انواع دارایی").setMessage("دسته‌بندی برای مرتب‌کردن خریدهاست. نوع جدید را اینجا اضافه کنید تا خریدها و گزارش‌ها یکدست بمانند.").setPositiveButton("بستن",null).show());
        typesBody.addView(typeInfo,UiKit.matchWrap(this,10,0));
        Button typeManager=UiKit.secondaryButton(this,"مدیریت دسته‌بندی‌ها");
        typeManager.setOnClickListener(v->{
            android.view.ViewGroup parent=(android.view.ViewGroup)typesBody.getParent();
            if(parent!=null)parent.removeView(typesBody);
            renderAssetTypes();
            ScrollView box=new ScrollView(this);
            box.addView(typesBody);
            new AlertDialog.Builder(this).setTitle("دسته‌بندی دارایی‌ها").setView(box).setNegativeButton("بستن",null).show();
        });
        root.addView(typeManager,UiKit.matchWrap(this,0,10));
        // Original Nexa reference order: overview -> financial report -> market -> holdings.
        // These panels stay collapsed by default, so they never push hundreds of purchases down.
        View reportSection=assetReportSection;
        View marketSection=assetMarketSection;
        // Resolve by known construction order rather than hard-coded pixel positions.
        root.removeView(reportSection);root.removeView(marketSection);
        int firstHolding=root.indexOfChild(listTitle);
        root.addView(reportSection,firstHolding,UiKit.matchWrap(this,0,8));
        root.addView(marketSection,firstHolding+1,UiKit.matchWrap(this,0,12));
        LinearLayout screen=new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout bottom=UiKit.referenceBottomNav(this,-1);
        LinearLayout.LayoutParams np=UiKit.matchWrap(this);
        np.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,12),UiKit.dp(this,9));
        screen.addView(bottom,np);
        setContentView(screen);
        renderAssetTypes();
        render();
        updateMarketText();
    }
    @Override protected void onResume(){super.onResume();if(list!=null){
        updateMarketText();
        if(NexaStore.marketRefreshMode(this)==2 && System.currentTimeMillis()-NexaStore.iranMarketUpdated(this)>300000L){
            // No background polling: only refresh on screen opening, if cache is stale.
            MarketDataHelper.refresh(this,(ok,msg)->{if(ok){updateOnlineAssets();render();}
                if(marketFeedback!=null)marketFeedback.setText(msg);updateMarketText();});
        }
    }}
    private List<String> assetTypeValues(){List<String> out=new ArrayList<>(standardTypes);for(String x:NexaStore.assetTypes(this))if(!out.contains(x))out.add(x);for(NexaStore.AssetEntry x:NexaStore.assets(this))if(!out.contains(x.type))out.add(x.type);return out;}
    private void renderAssetTypes(){
        if(typeManagerList==null)return;
        typeManagerList.removeAllViews();
        int columns=typeManagerList.getColumnCount();
        int available=getResources().getDisplayMetrics().widthPixels-UiKit.dp(this,72);
        int cellWidth=Math.max(UiKit.dp(this,90),available/columns-UiKit.dp(this,8));
        for(String t:assetTypeValues()){
            TextView chip=UiKit.muted(this,t);
            chip.setTextSize(12);
            chip.setGravity(Gravity.CENTER);
            chip.setSingleLine(false);
            chip.setMinHeight(UiKit.dp(this,48));chip.setMinimumHeight(UiKit.dp(this,48));
            chip.setPadding(UiKit.dp(this,5),UiKit.dp(this,6),UiKit.dp(this,5),UiKit.dp(this,6));
            chip.setBackground(UiKit.field(this));
            GridLayout.LayoutParams lp=new GridLayout.LayoutParams();
            lp.width=cellWidth;lp.height=GridLayout.LayoutParams.WRAP_CONTENT;
            lp.setMargins(UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3));
            typeManagerList.addView(chip,lp);
        }
    }
    private void addAssetTypeDialog(){EditText entry=field("نام نوع دارایی جدید");new AlertDialog.Builder(this).setTitle("نوع دارایی جدید").setView(entry).setPositiveButton("افزودن",(d,w)->{String t=entry.getText().toString().trim();if(t.isEmpty())return;NexaStore.addAssetType(this,t);renderAssetTypes();}).setNegativeButton("انصراف",null).show();}

    private void refreshMarket(Button b){
        if(NexaStore.marketRefreshMode(this)==0){Toast.makeText(this,"دریافت اینترنتی خاموش است.",Toast.LENGTH_SHORT).show();return;}
        b.setEnabled(false);
        if(marketFeedback!=null)marketFeedback.setText("در حال دریافت نرخ‌های جدید…");
        MarketDataHelper.refresh(this,(ok,msg)->{b.setEnabled(true);
            if(marketFeedback!=null)marketFeedback.setText(msg);
            if(ok){updateOnlineAssets();checkPriceAlerts();render();}
            updateMarketText();});
    }

    private void showPriceAlertManager(){
        List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),UiKit.dp(this,8));
        int active=0;
        for(NexaStore.AssetEntry x:data){
            if(x.alertTarget<=0&&!x.alertAtBuy)continue;active++;
            double target=x.alertAtBuy?x.buyUnitPrice:x.alertTarget;
            String mode="up".equals(x.alertDirection)?"بالاتر از هدف":"down".equals(x.alertDirection)?"پایین‌تر از هدف":"exact".equals(x.alertDirection)?"دقیقاً هدف":"عبور از هدف";
            LinearLayout row=UiKit.cardLayout(this);
            row.addView(UiKit.sectionTitle(this,(x.name==null||x.name.trim().isEmpty()?x.type:x.name)));
            row.addView(UiKit.muted(this,mode+" • "+money(target)+"\nقیمت فعلی: "+money(x.currentUnitPrice)),UiKit.matchWrap(this,4,6));
            Button edit=UiKit.secondaryButton(this,"ویرایش هشدار");edit.setOnClickListener(v->{priceAlertDialog(x);});row.addView(edit);
            box.addView(row,UiKit.matchWrap(this,0,8));
        }
        if(active==0)box.addView(UiKit.muted(this,"هیچ هشدار قیمت فعالی وجود ندارد."),UiKit.matchWrap(this,8,8));
        ScrollView sc=new ScrollView(this);sc.addView(box);
        final boolean hasActiveAlerts = active > 0;
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("🔔 مدیریت هشدارهای قیمت").setView(sc).setPositiveButton("بستن",null)
            .setNeutralButton(hasActiveAlerts?"خاموش‌کردن همه":null,null).create();
        dlg.setOnShowListener(d->{if(hasActiveAlerts)dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{List<NexaStore.AssetEntry> all=NexaStore.assets(this);for(NexaStore.AssetEntry x:all){x.alertTarget=0;x.alertAtBuy=false;x.alertTriggered=false;x.lastAlertObservedPrice=0;}NexaStore.saveAssets(this,all);PriceMonitorReceiver.cancel(this);dlg.dismiss();render();Toast.makeText(this,"همه هشدارهای قیمت خاموش شدند.",Toast.LENGTH_SHORT).show();});});
        dlg.show();
    }

    private void showMarketHistory(){
        List<NexaStore.MarketHistoryPoint> all=new ArrayList<>(NexaStore.marketHistory(this));
        if(all.isEmpty()){
            Toast.makeText(this,"هنوز تاریخچه‌ای ثبت نشده؛ بعد از دریافت قیمت‌های جدید تاریخچه ساخته می‌شود.",Toast.LENGTH_LONG).show();
            return;
        }
        java.util.Collections.sort(all,(a,b)->Long.compare(a.time,b.time));
        String[] names={"دلار","یورو","طلای ۱۸ عیار","طلای ۲۴ عیار","اونس جهانی",
            "سکه امامی","سکه تمام بهار آزادی","نیم‌سکه بهار آزادی","ربع‌سکه بهار آزادی","سکه گرمی"};
        final int[] selectedAsset={0};
        final android.app.Dialog dialog=new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        LinearLayout box=UiKit.cardLayout(this);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout heading=new LinearLayout(this);
        heading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView label=UiKit.sectionTitle(this,"تاریخچه نرخ‌های بازار");
        label.setTextSize(17f);
        heading.addView(label,new LinearLayout.LayoutParams(0,-2,1f));
        Button close=UiKit.secondaryButton(this,"×");
        close.setTextSize(21f);
        close.setContentDescription("بستن تاریخچه نرخ‌های بازار");
        close.setOnClickListener(v->dialog.dismiss());
        heading.addView(close,new LinearLayout.LayoutParams(UiKit.dp(this,46),UiKit.dp(this,46)));
        box.addView(heading,UiKit.matchWrap(this,0,8));
        HorizontalScrollView choices=new HorizontalScrollView(this);
        choices.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        choices.setHorizontalScrollBarEnabled(false);
        LinearLayout chips=new LinearLayout(this);
        chips.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        choices.addView(chips);
        box.addView(choices,UiKit.matchWrap(this,0,10));
        Spinner range=picker(java.util.Arrays.asList("۲۴ ساعت","۷ روز","۳۰ روز","۹۰ روز","همه"));
        range.setSelection(1);
        box.addView(UiKit.fieldLabel(this,"بازه نمایش"),UiKit.matchWrap(this,0,3));
        box.addView(range,UiKit.matchWrap(this,0,9));
        TextView stats=financialLine("");
        box.addView(stats,UiKit.matchWrap(this,0,5));
        MarketHistoryView chart=new MarketHistoryView(this);
        box.addView(chart,new LinearLayout.LayoutParams(-1,UiKit.dp(this,245)));
        TextView selected=financialLine("نقطه‌ای روی نمودار را لمس کن تا نرخ و تاریخ آن نمایش داده شود.");
        selected.setTextColor(UiKit.GOLD);
        box.addView(selected,UiKit.matchWrap(this,6,0));
        chart.setOnPointSelectedListener((time,price)->selected.setText(
            "قیمت: "+AssetRateFormatter.display(price)+" • "+PersianDateUtil.pretty(time)));
        final Runnable[] redraw=new Runnable[1];
        redraw[0]=()->{
            long now=System.currentTimeMillis();int rp=range.getSelectedItemPosition();
            long day=24L*60*60*1000;
            long since=rp==0?now-day:rp==1?now-7*day:rp==2?now-30*day:rp==3?now-90*day:0;
            List<Double> vals=new ArrayList<>();List<Long> times=new ArrayList<>();
            double first=0,last=0,min=Double.MAX_VALUE,max=Double.NEGATIVE_INFINITY;
            for(NexaStore.MarketHistoryPoint point:all){
                if(point.time<since)continue;
                double v=marketHistoryValue(point,selectedAsset[0]);
                if(!Double.isFinite(v)||v<=0)continue;
                if(vals.isEmpty())first=v;
                last=v;min=Math.min(min,v);max=Math.max(max,v);
                vals.add(v);times.add(point.time);
            }
            chart.setSeries(vals,times);
            selected.setText("نقطه‌ای روی نمودار را لمس کن تا قیمت دقیق نمایش داده شود.");
            if(vals.isEmpty()){
                stats.setText("برای این بازه داده معتبری ثبت نشده است.");return;
            }
            double change=first>0?(last-first)/first*100d:0;
            String warning=min>0&&max/min>5d?"\nتفاوت زیاد مقیاس نرخ‌ها؛ واحد منبع را بررسی کن.":"";
            stats.setText("آخرین: "+AssetRateFormatter.display(last)+
                "\nکمترین: "+AssetRateFormatter.display(min)+"  •  بیشترین: "+AssetRateFormatter.display(max)+
                "\nتغییر: "+persian(String.format(Locale.US,"%+.2f%%",change))+
                "  •  "+persian(String.valueOf(vals.size()))+" نقطه"+warning);
        };
        final Runnable[] renderChips=new Runnable[1];
        renderChips[0]=()->{
            chips.removeAllViews();
            for(int i=0;i<names.length;i++){
                final int index=i;boolean active=index==selectedAsset[0];
                LinearLayout chip=new LinearLayout(this);
                chip.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                chip.setGravity(Gravity.CENTER_VERTICAL);
                chip.setPadding(UiKit.dp(this,10),0,UiKit.dp(this,10),0);
                chip.setBackground(UiKit.rounded(this,active?UiKit.GOLD:UiKit.CARD_2,14));
                chip.setMinimumHeight(UiKit.dp(this,46));
                NexaOutlineIcon pictogram=new NexaOutlineIcon(this,AssetVisualPolicy.iconFor(names[i]),
                    active?UiKit.BG_1:UiKit.GOLD);
                chip.addView(pictogram,new LinearLayout.LayoutParams(UiKit.dp(this,22),UiKit.dp(this,22)));
                TextView name=UiKit.muted(this,names[i]);
                name.setTextColor(active?UiKit.BG_1:UiKit.TEXT);
                name.setTextSize(12f);name.setSingleLine(true);
                LinearLayout.LayoutParams textLp=new LinearLayout.LayoutParams(-2,-2);
                textLp.rightMargin=UiKit.dp(this,6);
                chip.addView(name,textLp);
                chip.setClickable(true);chip.setFocusable(true);
                chip.setContentDescription("نمایش تاریخچه "+names[i]+(active?"، انتخاب‌شده":""));
                chip.setOnClickListener(v->{selectedAsset[0]=index;renderChips[0].run();redraw[0].run();});
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,46));
                lp.leftMargin=UiKit.dp(this,6);
                chips.addView(chip,lp);
            }
        };
        range.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> parent){}
            public void onItemSelected(android.widget.AdapterView<?> parent,View view,int position,long id){redraw[0].run();}
        });
        renderChips[0].run();redraw[0].run();
        ScrollView scroll=new ScrollView(this);
        scroll.addView(box);
        dialog.setContentView(scroll);
        dialog.show();
        android.view.Window window=dialog.getWindow();
        if(window!=null){
            window.setBackgroundDrawableResource(android.R.color.transparent);
            window.setLayout((int)(getResources().getDisplayMetrics().widthPixels*0.93f),
                (int)(getResources().getDisplayMetrics().heightPixels*0.76f));
            window.setGravity(Gravity.CENTER);
        }
    }
    private double marketHistoryValue(NexaStore.MarketHistoryPoint p,int i){switch(i){case 0:return p.usd;case 1:return p.eur;case 2:return p.gold18;case 3:return p.gold24;case 4:return p.ounce;case 5:return p.emami;case 6:return p.bahar;case 7:return p.half;case 8:return p.quarter;default:return p.gerami;}}

    private void editForm(NexaStore.AssetEntry current){editForm(current,null,null);}
    private void editForm(NexaStore.AssetEntry current,String inheritedType,String inheritedGroup){
        LinearLayout box=UiKit.dialogPanel(this);
        TextView formTitle=UiKit.title(this,current==null?"ثبت خرید دارایی":"ویرایش خرید دارایی");
        formTitle.setTextSize(18f);
        formTitle.setTextColor(UiKit.GOLD);
        box.addView(formTitle,UiKit.matchWrap(this,0,8));
        List<String> types=assetTypeValues();
        Spinner type=picker(types);
        if(current!=null)type.setSelection(Math.max(0,types.indexOf(current.type)));
        else if(inheritedType!=null)type.setSelection(Math.max(0,types.indexOf(inheritedType)));
        EditText name=field("نام مجموعه یا فروشنده");
        if(current==null&&inheritedGroup!=null)name.setText(inheritedGroup);
        if(current==null&&pendingVoiceTitle!=null){name.setText(pendingVoiceTitle);pendingVoiceTitle=null;}
        final String[] sellerId={current==null?"":current.sellerId};
        Button sellerBtn=UiKit.secondaryButton(this,"انتخاب فروشنده از دفتر مشترک");
        NexaStore.ShoppingSeller oldSeller=current==null?null:NexaStore.sellerById(this,current.sellerId);
        if(oldSeller!=null)sellerBtn.setText("فروشنده: "+oldSeller.name);
        sellerBtn.setOnClickListener(v->pickSeller(sellerId,sellerBtn,name));

        Spinner entryMode=picker(java.util.Arrays.asList("ورود مقدار خالص دریافتی","محاسبه مقدار از مبلغ پرداختی"));
        EditText amount=field("مثلاً 207.21465920");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText paid=field("مبلغ پرداختی (ریال)");
        paid.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        NumberFormatUtil.attachThousandsDecimal(paid);
        EditText buy=field("قیمت خرید هر واحد (ریال)");
        buy.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        NumberFormatUtil.attachThousandsDecimal(buy);
        EditText fee=field("کارمزد پرداختی (ریال)");
        fee.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        NumberFormatUtil.attachThousandsDecimal(fee);
        EditText quote=field("قیمت فعلی هر واحد (ریال)");
        quote.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        NumberFormatUtil.attachThousandsDecimal(quote);
        CheckBox online=new CheckBox(this);
        online.setText("به‌روزرسانی خودکار فقط برای دارایی‌های دارای نرخ معتبر");
        online.setTextColor(UiKit.TEXT);
        EditText alertTarget=field("قیمت هدف هشدار (تومان)");
        alertTarget.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        NumberFormatUtil.attachThousandsDecimal(alertTarget);
        CheckBox alertBuy=new CheckBox(this);
        alertBuy.setText("هشدار رسیدن به قیمت خرید");
        alertBuy.setTextColor(UiKit.TEXT);
        Spinner alertDirection=picker(java.util.Arrays.asList("هشدار در هر دو جهت","فقط عبور رو به بالا","فقط عبور رو به پایین"));
        EditText note=field("یادداشت خرید (اختیاری)");
        final long[] buyDate={current==null?System.currentTimeMillis():current.buyDate};
        Button date=UiKit.secondaryButton(this,"تاریخ خرید: "+PersianDateUtil.pretty(buyDate[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,buyDate[0],"تاریخ و ساعت خرید",ms->{
            buyDate[0]=ms;date.setText("تاریخ خرید: "+PersianDateUtil.pretty(ms));
        }));
        TextView total=UiKit.sectionTitle(this,"بهای تمام‌شده: —");
        total.setTextColor(UiKit.GOLD);
        total.setTextSize(14f);
        TextView quantityPreview=UiKit.muted(this,"مقدار خالص محاسبه‌شده: —");
        quantityPreview.setTextColor(UiKit.TEAL);
        if(current!=null){
            name.setText(current.name);
            amount.setText(Double.isFinite(current.amount)?BigDecimal.valueOf(current.amount).stripTrailingZeros().toPlainString():"");
            buy.setText(moneyFormat.format("ریال".equals(current.currency)?current.buyUnitPrice*10:current.buyUnitPrice));
            quote.setText(current.currentUnitPrice>0?moneyFormat.format("ریال".equals(current.currency)?current.currentUnitPrice*10:current.currentUnitPrice):"");
            fee.setText(moneyFormat.format("ریال".equals(current.currency)?current.fee*10:current.fee));
            online.setChecked(current.autoPrice);
            alertTarget.setText(current.alertTarget>0?moneyFormat.format(current.alertTarget):"");
            alertBuy.setChecked(current.alertAtBuy);
            alertDirection.setSelection("up".equals(current.alertDirection)?1:("down".equals(current.alertDirection)?2:0));
            note.setText(current.note);
        }
        // Keep exact stored precision when the user only edits a note or group name.
        final String originalAmountText=amount.getText().toString();
        final String originalBuyText=buy.getText().toString();
        final String originalFeeText=fee.getText().toString();
        final String originalQuoteText=quote.getText().toString();
        // Switch modes without mutating saved lots. Existing purchases start in precise-quantity mode.
        LinearLayout manualBox=new LinearLayout(this);manualBox.setOrientation(LinearLayout.VERTICAL);
        manualBox.addView(UiKit.formField(this,"مقدار خالص دریافتی (تا ۸ رقم اعشار)",amount));
        LinearLayout autoBox=new LinearLayout(this);autoBox.setOrientation(LinearLayout.VERTICAL);
        autoBox.addView(UiKit.formField(this,"مبلغ پرداختی، شامل کارمزد (ریال)",paid));
        autoBox.addView(quantityPreview,UiKit.matchWrap(this,5,0));

        final boolean[] changing={false};
        Runnable update=()->{
            if(changing[0])return;
            changing[0]=true;
            try{
                double p=num(buy.getText().toString()),f=num(fee.getText().toString());
                boolean auto=entryMode.getSelectedItemPosition()==1;
                if(auto){
                    double paidRial=num(paid.getText().toString());
                    if(AssetPurchaseMath.valid(paidRial,p,f)){
                        double calculated=AssetPurchaseMath.netQuantity(paidRial,p,f);
                        String exact=AssetPurchaseMath.quantityText(calculated);
                        amount.setText(exact);
                        quantityPreview.setText("مقدار خالص محاسبه‌شده: "+exact+" واحد");
                        total.setText("کل پرداختی: "+persian(moneyFormat.format(paidRial))+" ریال");
                    }else{
                        amount.setText("");
                        quantityPreview.setText("مبلغ، نرخ و کارمزد معتبر وارد کن");
                        total.setText("کل پرداختی: —");
                    }
                }else{
                    double q=num(amount.getText().toString());
                    double cost=q*p+f;
                    total.setText("بهای تمام‌شده: "+(q>0&&p>0?persian(moneyFormat.format(cost)):"—")+" ریال");
                }
            }finally{changing[0]=false;}
        };
        TextWatcher calcWatcher=new TextWatcher(){
            public void beforeTextChanged(CharSequence a,int b,int c,int d){}
            public void onTextChanged(CharSequence a,int b,int c,int d){update.run();}
            public void afterTextChanged(Editable a){}
        };
        amount.addTextChangedListener(calcWatcher);
        buy.addTextChangedListener(calcWatcher);
        fee.addTextChangedListener(calcWatcher);
        paid.addTextChangedListener(calcWatcher);
        entryMode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> parent){}
            public void onItemSelected(android.widget.AdapterView<?> parent,View row,int pos,long id){
                manualBox.setVisibility(pos==0?View.VISIBLE:View.GONE);
                autoBox.setVisibility(pos==1?View.VISIBLE:View.GONE);
                update.run();
            }
        });
        autoBox.setVisibility(View.GONE);
        box.addView(NexaAssetsUi.formHeading(this,"مشخصات خرید"));
        box.addView(UiKit.formField(this,"نوع دارایی",type),UiKit.matchWrap(this,0,7));
        box.addView(UiKit.formField(this,"نام گروه / فروشنده",name),UiKit.matchWrap(this,0,6));
        box.addView(NexaAssetsUi.formHeading(this,"مقدار و قیمت"));
        box.addView(UiKit.formField(this,"روش ورود اطلاعات",entryMode),UiKit.matchWrap(this,0,6));
        box.addView(manualBox,UiKit.matchWrap(this,0,6));
        box.addView(autoBox,UiKit.matchWrap(this,0,6));
        box.addView(UiKit.formField(this,"قیمت خرید هر واحد (ریال)",buy),UiKit.matchWrap(this,0,6));
        box.addView(UiKit.formField(this,"کارمزد و هزینه پرداخت‌شده (ریال)",fee),UiKit.matchWrap(this,0,8));
        box.addView(total,UiKit.matchWrap(this,2,8));
        TextView feeHint=UiKit.muted(this,"در حالت محاسبه خودکار، کارمزد فقط یک‌بار از مبلغ پرداختی کسر می‌شود. مقدار دریافتی خالص ثبت خواهد شد.");
        feeHint.setTextSize(11.5f);
        box.addView(feeHint,UiKit.matchWrap(this,0,8));

        LinearLayout sellerFields=new LinearLayout(this);sellerFields.setOrientation(LinearLayout.VERTICAL);
        sellerFields.addView(sellerBtn,new LinearLayout.LayoutParams(-1,UiKit.dp(this,48)));
        box.addView(UiKit.formDisclosure(this,"انتخاب فروشنده از دفتر مشترک",sellerFields,
            current!=null&&current.sellerId!=null&&!current.sellerId.isEmpty()),UiKit.matchWrap(this,6,7));
        LinearLayout pricing=new LinearLayout(this);pricing.setOrientation(LinearLayout.VERTICAL);
        pricing.addView(UiKit.formField(this,"قیمت فعلی هر واحد (ریال)",quote),UiKit.matchWrap(this,0,6));
        pricing.addView(online,UiKit.matchWrap(this,0,6));
        pricing.addView(UiKit.formField(this,"قیمت هدف هشدار (تومان)",alertTarget),UiKit.matchWrap(this,0,6));
        pricing.addView(alertBuy,UiKit.matchWrap(this,0,6));
        pricing.addView(UiKit.formField(this,"جهت هشدار",alertDirection),UiKit.matchWrap(this,0,4));
        box.addView(UiKit.formDisclosure(this,"قیمت روز و هشدارها",pricing,
            current!=null&&(current.alertTarget>0||current.alertAtBuy||current.autoPrice)),UiKit.matchWrap(this,0,7));
        LinearLayout annotations=new LinearLayout(this);annotations.setOrientation(LinearLayout.VERTICAL);
        annotations.addView(date,new LinearLayout.LayoutParams(-1,UiKit.dp(this,48)));
        annotations.addView(UiKit.formField(this,"یادداشت",note),UiKit.matchWrap(this,6,0));
        box.addView(UiKit.formDisclosure(this,"تاریخ و توضیحات",annotations,
            current!=null),UiKit.matchWrap(this,0,7));
        update.run();

        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(false);
        sc.addView(box);
        AlertDialog saveDialog=new AlertDialog.Builder(this)
            .setView(sc).setPositiveButton("ذخیره",null).setNegativeButton("انصراف",null).create();
        saveDialog.setOnShowListener(dd->{
            Button positive=saveDialog.getButton(AlertDialog.BUTTON_POSITIVE);
            positive.setTextColor(UiKit.BG_1);
            positive.setAllCaps(false);
            positive.setBackground(UiKit.rounded(this,UiKit.GOLD,10));
            positive.setMinHeight(UiKit.dp(this,48));
            positive.setPadding(UiKit.dp(this,15),0,UiKit.dp(this,15),0);
            Button negative=saveDialog.getButton(AlertDialog.BUTTON_NEGATIVE);
            negative.setTextColor(UiKit.MUTED);
            negative.setAllCaps(false);
            positive.setOnClickListener(v->{
                double a=num(amount.getText().toString()),b=num(buy.getText().toString());
                double f=num(fee.getText().toString());
                if(current!=null && entryMode.getSelectedItemPosition()==0){
                    if(amount.getText().toString().equals(originalAmountText))a=current.amount;
                    if(buy.getText().toString().equals(originalBuyText))
                        b="ریال".equals(current.currency)?current.buyUnitPrice*10:current.buyUnitPrice;
                    if(fee.getText().toString().equals(originalFeeText))
                        f="ریال".equals(current.currency)?current.fee*10:current.fee;
                }
                if(entryMode.getSelectedItemPosition()==1&&!AssetPurchaseMath.valid(num(paid.getText().toString()),b,f)){
                    Toast.makeText(this,"مبلغ پرداختی باید بیشتر از کارمزد و قیمت واحد معتبر باشد.",Toast.LENGTH_LONG).show();return;
                }
                if(!Double.isFinite(a)||!Double.isFinite(b)||!Double.isFinite(f)||a<=0||b<=0||f<0){
                    Toast.makeText(this,"مقدار، قیمت خرید یا کارمزد معتبر نیست.",Toast.LENGTH_LONG).show();return;
                }
                NexaStore.AssetEntry x=current==null?new NexaStore.AssetEntry():current;
                x.type=String.valueOf(type.getSelectedItem());
                x.name=name.getText().toString().trim();
                if(x.name.isEmpty())x.name="بدون مجموعه";
                x.amount=a;
                double divisor=10.0; // Storage has historically used toman; UI labels are rial.
                x.buyUnitPrice=b/divisor;
                double explicitQuote=(current!=null && quote.getText().toString().equals(originalQuoteText))
                    ?current.currentUnitPrice:num(quote.getText().toString())/divisor;
                if(explicitQuote>0 && (current==null||Double.compare(explicitQuote,current.currentUnitPrice)!=0))
                    x.quoteUpdatedAt=System.currentTimeMillis();
                x.currentUnitPrice=explicitQuote;
                if(x.currentUnitPrice<=0){
                    x.currentUnitPrice=x.buyUnitPrice;
                    x.quoteUpdatedAt=0;
                    if(current==null){
                        List<NexaStore.AssetEntry> previous=new ArrayList<>();
                        long latestQuote=0;
                        for(NexaStore.AssetEntry old:NexaStore.assets(this)){
                            if(AssetGroupQuoteEngine.belongs(old,x.type)){
                                previous.add(old);
                                latestQuote=Math.max(latestQuote,old.quoteUpdatedAt);
                            }
                        }
                        double groupPrice=AssetGroupQuoteEngine.sharedQuote(previous);
                        if(latestQuote>0&&Double.isFinite(groupPrice)){
                            x.currentUnitPrice=groupPrice;x.quoteUpdatedAt=latestQuote;
                        }
                    }
                }
                x.fee=f/divisor;
                x.currency="ریال";
                x.autoPrice=online.isChecked();
                x.alertTarget=num(alertTarget.getText().toString());
                x.alertAtBuy=alertBuy.isChecked();
                x.alertDirection=alertDirection.getSelectedItemPosition()==1?"up":(alertDirection.getSelectedItemPosition()==2?"down":"both");
                x.alertTriggered=false;x.buyDate=buyDate[0];
                x.note=note.getText().toString().trim();x.sellerId=sellerId[0];
                if(x.autoPrice){applyMarketToAsset(x);x.quoteUpdatedAt=0;}
                if(current==null)NexaStore.addAsset(this,x);else NexaStore.updateAsset(this,x);
                NexaStore.addHistory(this,"دارایی",(current==null?"خرید جدید: ":"ویرایش خرید: ")+x.name);
                PriceMonitorReceiver.schedule(this);
                render();saveDialog.dismiss();
            });
        });
        saveDialog.show();
        android.view.Window window=saveDialog.getWindow();
        if(window!=null)window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
    }
    private void pickSeller(String[] out,Button btn,EditText name){
        DirectoryPicker.seller(this,s->{out[0]=s.id;btn.setText("فروشنده: "+s.name);name.setText(s.name);});
    }
    private void updateOnlineAssets(){AssetMarketEngine.updateOnlineAssets(this);}
    private void applyMarketToAsset(NexaStore.AssetEntry x){double v=AssetMarketEngine.marketPrice(this,x.type);if(v>0)x.currentUnitPrice=v;}
    private void updateMarketText(){
        if(marketStatus==null || marketRateContainer==null)return;
        marketRateContainer.removeAllViews();
        long last=NexaStore.iranMarketUpdated(this);
        if(last<=0){
            marketStatus.setText("هنوز نرخ معتبری ذخیره نشده است. از آیکون تازه‌سازی استفاده کن.");
            if(marketHeaderFreshness!=null)marketHeaderFreshness.setText("هنوز دریافت نشده");
            if(marketSource!=null)marketSource.setText("");
            return;
        }
        long age=Math.max(0L,System.currentTimeMillis()-last);
        String freshness=AssetRateFormatter.freshness(age);
        marketStatus.setText("آخرین دریافت: "+PersianDateUtil.pretty(last)+"  •  "+freshness);
        if(marketHeaderFreshness!=null)marketHeaderFreshness.setText("آخرین نرخ: "+PersianDateUtil.pretty(last)+" • "+freshness);
        AssetRatesPanel.addGroup(this,marketRateContainer,"ارزها",new String[]{"دلار","یورو"},
                new double[]{NexaStore.iranUsd(this),NexaStore.iranEur(this)});
        AssetRatesPanel.addGroup(this,marketRateContainer,"طلا و اونس جهانی",
                new String[]{"طلای ۱۸ عیار","طلای ۲۴ عیار","اونس جهانی (USD)"},
                new double[]{NexaStore.iranGold18(this),NexaStore.iranGold24(this),NexaStore.iranOunce(this)});
        AssetRatesPanel.addGroup(this,marketRateContainer,"سکه‌ها",
                new String[]{"امامی","بهار آزادی","نیم‌سکه","ربع‌سکه","سکه گرمی"},
                new double[]{NexaStore.iranEmami(this),NexaStore.iranBahar(this),
                        NexaStore.iranHalf(this),NexaStore.iranQuarter(this),NexaStore.iranGerami(this)});
        if(marketSource!=null){
            String provider=NexaStore.iranMarketSource(this);
            marketSource.setText("منبع: "+(provider==null||provider.trim().isEmpty()?"نامشخص":provider)
                +"  •  مقادیر بدون تبدیل مقیاس نمایش داده می‌شوند؛ واحد مبنا را در منبع بررسی کنید.");
        }
    }
    private void checkPriceAlerts(){AssetMarketEngine.checkAlerts(this);}
    private double cost(NexaStore.AssetEntry x){return AssetFinanceEngine.openCost(x);}
    private double value(NexaStore.AssetEntry x){return AssetFinanceEngine.marketValue(x);}
    private String persian(String raw){return PersianFinancialDisplay.digits(raw);}
    private String money(double value){return PersianFinancialDisplay.amount2(value)+" تومان";}
    private String percent(double gain,double basis){
        if(!Double.isFinite(gain)||!Double.isFinite(basis)||basis<=0)return "—";
        return persian(String.format(Locale.US,"%+.2f%%",gain/basis*100d));
    }
    private TextView financialLine(String content){
        TextView t=UiKit.muted(this,content);
        t.setTextSize(12.5f);t.setMaxLines(3);
        return t;
    }
    private void renderAssetFilters(){
        if(filterContainer==null)return;
        filterContainer.removeAllViews();
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);scroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout row=new LinearLayout(this);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] labels={"همه","سودده","زیان‌ده","هشدار فعال"};
        for(int i=0;i<labels.length;i++){
            final int selected=i;TextView chip=NexaAssetsUi.filter(this,labels[i],assetFilter==i);
            chip.setOnClickListener(v->{if(assetFilter!=selected){assetFilter=selected;render();}});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,44));
            if(i>0)lp.leftMargin=UiKit.dp(this,7);row.addView(chip,lp);
        }
        scroll.addView(row);filterContainer.addView(scroll);
    }
    private void render(){renderAssetTypes();if(list==null)return;list.removeAllViews();List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        double initial=AssetFinanceEngine.totalOpenCost(data),now=AssetFinanceEngine.totalMarketValue(data);
        double realized=AssetFinanceEngine.totalRealized(data),profit=now-initial+realized;
        double lifetimeReturn=AssetFinanceEngine.totalReturnPercent(data);
        if(portfolioTotal!=null)portfolioTotal.setText(money(now));
        if(portfolioChange!=null){portfolioChange.setText("سود/زیان کل: "+(profit>=0?"+":"")+money(profit)+
                (Double.isFinite(lifetimeReturn)?"  •  بازده کل: "+persian(String.format(Locale.US,"%+.2f%%",lifetimeReturn)):""));
            portfolioChange.setTextColor(profit>=0?UiKit.GREEN:UiKit.RED);}
        if(metricContainer!=null){metricContainer.removeAllViews();
            metricContainer.addView(NexaAssetsUi.metrics(this,
                new String[]{"بهای خرید","سود/زیان باز","سود فروش‌ها"},
                new String[]{money(initial),(now-initial>=0?"+":"")+money(now-initial),(realized>=0?"+":"")+money(realized)},
                new int[]{UiKit.GOLD,now-initial>=0?UiKit.GREEN:UiKit.RED,realized>=0?UiKit.GREEN:UiKit.RED}));}
        renderAssetFilters();
        summary.setText("خریدها: "+persian(String.valueOf(data.size()))+
            "  •  نوع دارایی: "+persian(String.valueOf(new LinkedHashSet<String>(){{for(NexaStore.AssetEntry a:data)add(a.type);}}.size()))+
            "  •  سود/زیان کل: "+(profit>=0?"+":"")+money(profit));
        summary.setMaxLines(3);
        if(data.isEmpty()){TextView e=UiKit.muted(this,"هنوز خریدی ثبت نشده. از دکمه ثبت دارایی شروع کن.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,15,0));return;}
        List<NexaStore.AssetEntry> visible=new ArrayList<>();
        for(NexaStore.AssetEntry x:data){
            if(AssetOverviewPolicy.matches(assetFilter,cost(x),value(x),x.alertTarget>0||x.alertAtBuy))visible.add(x);
        }
        if(visible.isEmpty()){TextView e=UiKit.muted(this,"موردی برای این فیلتر پیدا نشد؛ از فیلتر «همه» استفاده کن.");
            e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,15,0));return;}
        if(groupedView)renderPortfolioGroups(visible);
        else renderFlatAssets(visible);
    }

    // Each type is one compact overview, regardless of purchase count or seller.
    // Full purchase details are displayed only on demand and never altered/deleted.
    private void renderPortfolioGroups(List<NexaStore.AssetEntry> visible){
        java.util.Collections.sort(visible,(a,b)->Long.compare(b.buyDate,a.buyDate));
        Map<String,List<NexaStore.AssetEntry>> groups=new LinkedHashMap<>();
        for(NexaStore.AssetEntry x:visible){
            String name=x.type==null||x.type.trim().isEmpty()?"سایر دارایی‌ها":x.type.trim();
            List<NexaStore.AssetEntry> members=groups.get(name);
            if(members==null){members=new ArrayList<>();groups.put(name,members);}
            members.add(x);
        }
        for(Map.Entry<String,List<NexaStore.AssetEntry>> g:groups.entrySet()){
            List<NexaStore.AssetEntry> members=g.getValue();
            double total=0,openCost=0;
            for(NexaStore.AssetEntry x:members){total+=value(x);openCost+=cost(x);}
            final double gain=total-openCost;
            LinearLayout card=UiKit.cardLayout(this);
            card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            card.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
            LinearLayout headline=new LinearLayout(this);
            headline.setGravity(Gravity.CENTER_VERTICAL);
            headline.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            NexaOutlineIcon pictogram=new NexaOutlineIcon(this,AssetVisualPolicy.iconFor(g.getKey()),UiKit.GOLD);
            headline.addView(pictogram,new LinearLayout.LayoutParams(UiKit.dp(this,30),UiKit.dp(this,30)));
            LinearLayout headingBox=new LinearLayout(this);headingBox.setOrientation(LinearLayout.VERTICAL);
            TextView name=UiKit.sectionTitle(this,g.getKey());name.setTextSize(16f);
            name.setMaxLines(2);headingBox.addView(name);
            TextView count=UiKit.muted(this,persian(String.valueOf(members.size()))+" خرید ثبت‌شده");
            count.setTextSize(11.5f);headingBox.addView(count,UiKit.matchWrap(this,2,0));
            LinearLayout.LayoutParams hlp=new LinearLayout.LayoutParams(0,-2,1f);
            hlp.rightMargin=UiKit.dp(this,10);
            headline.addView(headingBox,hlp);card.addView(headline);
            TextView valuation=UiKit.title(this,money(total));
            valuation.setTextSize(19f);valuation.setMaxLines(3);
            valuation.setAutoSizeTextTypeUniformWithConfiguration(13,19,1,TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
            card.addView(valuation,UiKit.matchWrap(this,8,4));
            double qty=AssetGroupQuoteEngine.quantity(members);
            card.addView(financialLine("بهای خرید باقی‌مانده: "+money(openCost)),UiKit.matchWrap(this,3,2));
            if(qty>0 && openCost>0)
                card.addView(financialLine("میانگین بهای تمام‌شده هر واحد: "+money(openCost/qty)),UiKit.matchWrap(this,0,2));
            double shared=AssetGroupQuoteEngine.sharedQuote(members);
            card.addView(financialLine("قیمت روز هر واحد: "+(Double.isFinite(shared)?money(shared):"متفاوت / ثبت‌نشده")),UiKit.matchWrap(this,0,4));
            TextView result=UiKit.muted(this,"سود/زیان باز: "+(gain>=0?"+":"")+money(gain)+"  ("+percent(gain,openCost)+")");
            result.setTextSize(12.5f);result.setMaxLines(3);
            result.setTextColor(gain>=0?UiKit.GREEN:UiKit.RED);
            card.addView(result,UiKit.matchWrap(this,0,5));
            boolean hasSales=false;
            for(NexaStore.AssetEntry x:members)if(x.soldAmount>0){hasSales=true;break;}
            if(hasSales){
                double realizedGain=AssetFinanceEngine.totalRealized(members);
                double overallGain=gain+realizedGain;
                double basis=AssetFinanceEngine.totalInvestedCost(members);
                card.addView(financialLine("سود/زیان فروش‌های قبلی: "+(realizedGain>=0?"+":"")+money(realizedGain)),UiKit.matchWrap(this,0,3));
                TextView overall=financialLine("جمع سود/زیان صندوق: "+(overallGain>=0?"+":"")+money(overallGain)
                    +"  ("+percent(overallGain,basis)+")");
                overall.setTextColor(overallGain>=0?UiKit.GREEN:UiKit.RED);
                card.addView(overall,UiKit.matchWrap(this,0,5));
            }
            long groupQuoteTime=0;
            for(NexaStore.AssetEntry x:members)groupQuoteTime=Math.max(groupQuoteTime,x.quoteUpdatedAt);
            if(groupQuoteTime>0)card.addView(financialLine("آخرین ثبت دستی نرخ: "+PersianDateUtil.pretty(groupQuoteTime)),UiKit.matchWrap(this,0,7));
            Button quoteButton=UiKit.secondaryButton(this,"✎  ثبت / ویرایش قیمت روز");
            quoteButton.setTextSize(13f);quoteButton.setTextColor(UiKit.GOLD);
            quoteButton.setContentDescription("ثبت قیمت روز برای همه خریدهای "+g.getKey());
            quoteButton.setOnClickListener(v->editGroupMarketPrice(g.getKey(),members));
            card.addView(quoteButton,new LinearLayout.LayoutParams(-1,UiKit.dp(this,48)));
            LinearLayout details=new LinearLayout(this);
            details.setOrientation(LinearLayout.VERTICAL);
            details.setVisibility(View.GONE);
            for(NexaStore.AssetEntry x:members)details.addView(compactPurchaseCard(x),UiKit.matchWrap(this,7,0));
            Button expand=UiKit.secondaryButton(this,"مشاهده خریدها ("+persian(String.valueOf(members.size()))+")");
            expand.setTextSize(12.5f);
            expand.setContentDescription("باز کردن خریدهای "+g.getKey());
            expand.setOnClickListener(v->{boolean show=details.getVisibility()!=View.VISIBLE;
                details.setVisibility(show?View.VISIBLE:View.GONE);
                expand.setText(show?"بستن جزئیات":"مشاهده خریدها ("+persian(String.valueOf(members.size()))+")");});
            card.addView(expand,new LinearLayout.LayoutParams(-1,UiKit.dp(this,48)));
            card.addView(details);
            list.addView(card,UiKit.matchWrap(this,0,9));
        }
    }
    private LinearLayout compactPurchaseCard(NexaStore.AssetEntry x){
        double p=value(x)-cost(x);
        LinearLayout card=NexaAssetsUi.purchaseCard(this,p);
        NexaStore.ShoppingSeller seller=NexaStore.sellerById(this,x.sellerId);
        String owner=seller!=null?seller.name:x.name;
        TextView label=UiKit.muted(this,(owner==null||owner.trim().isEmpty()?"خرید":"خرید • "+owner)
            +"  •  "+PersianDateUtil.pretty(x.buyDate));
        label.setTextSize(12f);label.setMaxLines(2);card.addView(label);
        TextView price=UiKit.title(this,money(value(x)));
        price.setTextSize(16f);price.setMaxLines(3);
        price.setAutoSizeTextTypeUniformWithConfiguration(12,16,1,TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
        card.addView(price,UiKit.matchWrap(this,5,5));
        TextView amount=UiKit.muted(this,"مقدار باقی‌مانده: "+persian(AssetPurchaseMath.quantityText(x.amount)));
        amount.setTextSize(12f);card.addView(amount,UiKit.matchWrap(this,0,4));
        card.addView(financialLine("قیمت خرید هر واحد: "+money(x.buyUnitPrice)),UiKit.matchWrap(this,0,2));
        card.addView(financialLine("قیمت روز هر واحد: "+money(x.currentUnitPrice)),UiKit.matchWrap(this,0,2));
        card.addView(financialLine("بهای خرید باقی‌مانده: "+money(cost(x))),UiKit.matchWrap(this,0,4));
        TextView gain=financialLine("سود/زیان: "+(p>=0?"+":"")+money(p)+"  ("+percent(p,cost(x))+")");
        gain.setTextColor(p>=0?UiKit.GREEN:UiKit.RED);
        card.addView(gain,UiKit.matchWrap(this,0,5));
        LinearLayout actions=new LinearLayout(this);
        actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button details=UiKit.secondaryButton(this,"جزئیات");
        details.setTextSize(12.5f);details.setOnClickListener(v->showAssetDetails(x));
        actions.addView(details,new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f));
        if(x.amount>0){Button sell=UiKit.secondaryButton(this,"فروش");
            sell.setTextSize(12.5f);sell.setOnClickListener(v->sellForm(x));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(UiKit.dp(this,84),UiKit.dp(this,48));
            lp.rightMargin=UiKit.dp(this,7);actions.addView(sell,lp);}
        card.addView(actions,UiKit.matchWrap(this,7,0));return card;
    }
    // Default view: no nested accordions, no repeated totals or four-button toolbars.
    // Compact, scannable cards: the portfolio is a list of assets, not a stack of mini forms.
    private void renderFlatAssets(List<NexaStore.AssetEntry> visible){
        java.util.Collections.sort(visible,(a,b)->Long.compare(b.buyDate,a.buyDate));
        for(NexaStore.AssetEntry x:visible)list.addView(compactPurchaseCard(x),UiKit.matchWrap(this,0,8));
    }

    private void showAssetDetails(NexaStore.AssetEntry x){
        LinearLayout content=UiKit.dialogPanel(this);
        content.addView(UiKit.sectionTitle(this,x.type==null?"دارایی":x.type),UiKit.matchWrap(this,0,6));
        String owner=x.name==null?"":x.name;
        content.addView(UiKit.muted(this,"مجموعه: "+owner),UiKit.matchWrap(this,0,5));
        content.addView(UiKit.muted(this,"مقدار باقیمانده: "+persian(AssetPurchaseMath.quantityText(x.amount))),UiKit.matchWrap(this,0,5));
        content.addView(UiKit.muted(this,"تاریخ خرید: "+PersianDateUtil.pretty(x.buyDate)),UiKit.matchWrap(this,0,5));
        content.addView(UiKit.muted(this,"قیمت خرید هر واحد: "+money(x.buyUnitPrice)),UiKit.matchWrap(this,0,5));
        content.addView(UiKit.muted(this,"قیمت فعلی هر واحد: "+money(x.currentUnitPrice)),UiKit.matchWrap(this,0,5));
        content.addView(UiKit.muted(this,"بهای خرید باقیمانده: "+money(cost(x))),UiKit.matchWrap(this,0,5));
        content.addView(UiKit.muted(this,"ارزش فعلی: "+money(value(x))),UiKit.matchWrap(this,0,5));
        double profit=value(x)-cost(x);
        TextView gain=UiKit.muted(this,"سود/زیان باز: "+(profit>=0?"+":"")+money(profit)+" ("+percent(profit,cost(x))+")");
        gain.setTextColor(profit>=0?UiKit.GREEN:UiKit.RED);
        content.addView(gain,UiKit.matchWrap(this,0,5));
        if(x.fee>0)content.addView(UiKit.muted(this,"کارمزد: "+money(x.fee)),UiKit.matchWrap(this,0,5));
        if(x.soldAmount>0)content.addView(UiKit.muted(this,"مقدار فروخته‌شده: "+persian(AssetPurchaseMath.quantityText(x.soldAmount))),UiKit.matchWrap(this,0,5));
        if(x.realizedProfit!=0)content.addView(UiKit.muted(this,"سود/زیان تحقق‌یافته: "+money(x.realizedProfit)),UiKit.matchWrap(this,0,5));
        if(x.alertTarget>0||x.alertAtBuy)content.addView(UiKit.muted(this,"هشدار قیمت فعال"),UiKit.matchWrap(this,0,5));
        if(x.note!=null&&!x.note.trim().isEmpty())content.addView(UiKit.muted(this,"توضیحات: "+x.note),UiKit.matchWrap(this,0,8));
        Button edit=UiKit.secondaryButton(this,"ویرایش خرید");
        Button alert=UiKit.secondaryButton(this,"تنظیم هشدار قیمت");
        Button delete=UiKit.secondaryButton(this,"حذف این خرید");
        content.addView(edit,UiKit.matchWrap(this,10,0));
        content.addView(alert,UiKit.matchWrap(this,8,0));
        content.addView(delete,UiKit.matchWrap(this,8,0));
        ScrollView scroll=new ScrollView(this);
        scroll.addView(content);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("جزئیات خرید").setView(scroll).setNegativeButton("بستن",null).create();
        edit.setOnClickListener(v->{dialog.dismiss();editForm(x);});
        alert.setOnClickListener(v->{dialog.dismiss();priceAlertDialog(x);});
        delete.setOnClickListener(v->{dialog.dismiss();new AlertDialog.Builder(this).setTitle("حذف خرید؟")
            .setMessage(x.type+" • "+PersianDateUtil.pretty(x.buyDate))
            .setPositiveButton("حذف",(d,w)->{NexaStore.removeAsset(this,x.id);PriceMonitorReceiver.schedule(this);render();})
            .setNegativeButton("انصراف",null).show();});
        dialog.show();
    }

    private void priceAlertDialog(NexaStore.AssetEntry x){
        LinearLayout box=UiKit.dialogPanel(this);
        EditText target=field("قیمت هدف (تومان)");target.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(target);
        if(x.alertTarget>0)target.setText(moneyFormat.format(x.alertTarget));
        Spinner mode=picker(java.util.Arrays.asList("بالاتر از قیمت هدف","پایین‌تر از قیمت هدف","دقیقاً قیمت هدف","عبور از قیمت هدف"));
        int pos="down".equals(x.alertDirection)?1:("exact".equals(x.alertDirection)?2:("both".equals(x.alertDirection)?3:0));mode.setSelection(pos);
        CheckBox atBuy=new CheckBox(this);atBuy.setText("هدف = قیمت خرید من ("+money(x.buyUnitPrice)+")");atBuy.setTextColor(UiKit.TEXT);atBuy.setChecked(x.alertAtBuy);
        box.addView(UiKit.muted(this,"هشدار مستقیم برای همین خرید؛ بدون ورود به فرم ویرایش دارایی."),UiKit.matchWrap(this,0,8));
        box.addView(target,UiKit.matchWrap(this,0,8));box.addView(mode,UiKit.matchWrap(this,0,8));box.addView(atBuy,UiKit.matchWrap(this,0,4));
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("🔔 هشدار قیمت").setView(box)
            .setPositiveButton("ذخیره",null).setNeutralButton("خاموش کردن",null).setNegativeButton("انصراف",null).create();
        dlg.setOnShowListener(v->{
            dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(b->{double t=num(target.getText().toString());if(!atBuy.isChecked()&&t<=0){Toast.makeText(this,"قیمت هدف را وارد کن.",Toast.LENGTH_SHORT).show();return;}x.alertAtBuy=atBuy.isChecked();x.alertTarget=x.alertAtBuy?0:t;int m=mode.getSelectedItemPosition();x.alertDirection=m==0?"up":m==1?"down":m==2?"exact":"both";x.alertTriggered=false;x.lastAlertObservedPrice=x.currentUnitPrice;NexaStore.updateAsset(this,x);PriceMonitorReceiver.schedule(this);dlg.dismiss();render();});
            dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(b->{x.alertTarget=0;x.alertAtBuy=false;x.alertTriggered=false;x.lastAlertObservedPrice=0;NexaStore.updateAsset(this,x);PriceMonitorReceiver.schedule(this);dlg.dismiss();render();});
        });dlg.show();
    }

    /** Manual NAV/quote is applied atomically to ALL purchases of the type, not just visible filters. */
    private void editGroupMarketPrice(String groupName,List<NexaStore.AssetEntry> displayed){
        List<NexaStore.AssetEntry> entries=new ArrayList<>();
        for(NexaStore.AssetEntry x:NexaStore.assets(this))if(AssetGroupQuoteEngine.belongs(x,groupName))entries.add(x);
        if(entries.isEmpty()){Toast.makeText(this,"خریدی برای این گروه ثبت نشده است.",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=UiKit.dialogPanel(this);
        box.addView(UiKit.sectionTitle(this,"قیمت روز • "+groupName),UiKit.matchWrap(this,0,8));
        box.addView(financialLine("یک قیمت برای هر واحد (تومان) وارد کن. همه خریدهای این گروه، حتی خریدهای مخفی‌شده با فیلتر، با همان نرخ ارزش‌گذاری می‌شوند. قیمت خرید و تاریخچه فروش تغییر نمی‌کنند."),UiKit.matchWrap(this,0,10));
        double old=AssetGroupQuoteEngine.sharedQuote(entries);
        box.addView(financialLine("نرخ فعلی گروه: "+(Double.isFinite(old)?money(old):"نرخ یکسانی ثبت نشده")),UiKit.matchWrap(this,0,8));
        EditText price=field("قیمت روز هر واحد • تومان");
        price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        NumberFormatUtil.attachThousandsDecimal(price);
        if(Double.isFinite(old))price.setText(moneyFormat.format(old));
        box.addView(price,UiKit.matchWrap(this,0,9));
        double totalCost=AssetFinanceEngine.totalOpenCost(entries);
        double quantity=AssetGroupQuoteEngine.quantity(entries);
        TextView preview=financialLine("قیمت را وارد کن تا ارزش روز و سود/زیان پیش از ثبت نمایش داده شود.");
        box.addView(preview,UiKit.matchWrap(this,0,3));
        TextWatcher watcher=new TextWatcher(){
            public void beforeTextChanged(CharSequence text,int start,int count,int after){}
            public void onTextChanged(CharSequence text,int start,int before,int count){
                double p=num(text.toString());double market=quantity*p;
                if(!AssetGroupQuoteEngine.validQuote(p)||!Double.isFinite(market)){
                    preview.setText("قیمت روز معتبر وارد کن.");return;
                }
                double gain=market-totalCost;
                preview.setText("ارزش روز کل: "+money(market)
                    +"\nسود/زیان باز گروه: "+(gain>=0?"+":"")+money(gain)
                    +" ("+percent(gain,totalCost)+")"
                    +"\nتعداد خریدها: "+persian(String.valueOf(entries.size())));
                preview.setTextColor(gain>=0?UiKit.GREEN:UiKit.RED);
            }
            public void afterTextChanged(Editable text){}
        };
        price.addTextChangedListener(watcher);
        ScrollView scroll=new ScrollView(this);
        scroll.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ثبت قیمت روز صندوق")
            .setView(scroll).setPositiveButton("ثبت برای کل گروه",null)
            .setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            double newQuote=num(price.getText().toString());
            if(!AssetGroupQuoteEngine.validQuote(newQuote)){
                price.setError("قیمت باید مثبت و معتبر باشد.");return;
            }
            // Re-read persistent holdings; never overwrite a subset from the filtered display.
            List<NexaStore.AssetEntry> latest=NexaStore.assets(this);
            int changed=AssetGroupQuoteEngine.applyQuote(latest,groupName,newQuote,System.currentTimeMillis());
            if(changed<=0){
                Toast.makeText(this,"مقادیر خرید معتبر نیستند؛ هیچ تغییری ذخیره نشد.",Toast.LENGTH_LONG).show();return;
            }
            NexaStore.saveAssets(this,latest); // One write for all purchases.
            NexaStore.addHistory(this,"دارایی","ثبت قیمت روز "+groupName+" • "+money(newQuote)
                +" • "+persian(String.valueOf(changed))+" خرید");
            PriceMonitorReceiver.schedule(this);
            render();dialog.dismiss();
            Toast.makeText(this,"قیمت روز تمام خریدهای گروه ثبت شد.",Toast.LENGTH_SHORT).show();
        }));
        dialog.show();
    }

    private void sellForm(NexaStore.AssetEntry x){
        if(x.amount<=0){Toast.makeText(this,"موجودی این خرید صفر است.",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.muted(this,"موجودی قابل فروش: "+AssetPurchaseMath.quantityText(x.amount)+" • میانگین خرید: "+money(x.buyUnitPrice)),UiKit.matchWrap(this,0,6));
        EditText qty=field("مقدار فروش"),price=field("قیمت فروش هر واحد (تومان)");qty.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);price.setText(x.currentUnitPrice>0?moneyFormat.format(x.currentUnitPrice):"");box.addView(qty,UiKit.matchWrap(this,4,4));box.addView(price,UiKit.matchWrap(this,4,4));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ثبت فروش • "+x.type).setView(box).setPositiveButton("ثبت فروش",null).setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(dd->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{double q=num(qty.getText().toString()),p=num(price.getText().toString());if(!AssetFinanceEngine.sell(x,q,p,System.currentTimeMillis())){Toast.makeText(this,"مقدار یا قیمت فروش معتبر نیست.",Toast.LENGTH_LONG).show();return;}NexaStore.updateAsset(this,x);NexaStore.addHistory(this,"دارایی","فروش "+x.type+" • "+AssetPurchaseMath.quantityText(q)+" واحد • "+money(p));render();dialog.dismiss();}));dialog.show();
    }
    private double num(String raw){try{String s=raw.trim().replace(",","").replace("٬","").replace("٫",".");
        StringBuilder result=new StringBuilder();for(int i=0;i<s.length();i++){char ch=s.charAt(i);
            if(ch>='۰'&&ch<='۹')ch=(char)('0'+ch-'۰');if(ch>='٠'&&ch<='٩')ch=(char)('0'+ch-'٠');result.append(ch);}
        return Double.parseDouble(result.toString());}catch(Exception e){return 0;}}
}
