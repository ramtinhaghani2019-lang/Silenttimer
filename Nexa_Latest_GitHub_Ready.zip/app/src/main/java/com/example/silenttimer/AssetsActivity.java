package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Editable, grouped portfolio. No online price is represented as verified Iranian consensus. */
public class AssetsActivity extends Activity {
    private LinearLayout list,typeManagerList;
    private TextView summary,marketStatus;
    private EditText usdToman;
    private final DecimalFormat df=new DecimalFormat("#,##0.###");
    private final DecimalFormat moneyFormat=new DecimalFormat("#,##0.##");
    private final List<String> standardTypes=new ArrayList<>();
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        java.util.Collections.addAll(standardTypes,"طلای ۱۸ عیار","طلای ۲۴ عیار","نقره","مس","دلار","یورو","سکه امامی","سکه بهار آزادی","نیم سکه","ربع سکه","سکه گرمی","سهام / بورس","سایر");
        build();if(getIntent().getBooleanExtra("quick_add",false))list.postDelayed(()->editForm(null),250);
    }
    private EditText field(String hint){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));return e;}
    private Spinner picker(List<String> values){Spinner s=new Spinner(this);
        ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,values){
            @Override public View getView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setPadding(12,12,12,12);return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(p,v,parent);
                t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);t.setPadding(14,14,14,14);return t;}
        };a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);return s;
    }
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,28));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));
        root.addView(UiKit.title(this,"Nexa Assets"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"📈 دارایی‌ها • گروه‌بندی نوع و فروشنده • سود و زیان"),UiKit.matchWrap(this,0,14));
        LinearLayout sum=UiKit.colorfulCardLayout(this,4);sum.addView(UiKit.sectionTitle(this,"ارزش سبد"));
        summary=UiKit.muted(this,"");summary.setTextSize(16);sum.addView(summary,UiKit.matchWrap(this,8,0));root.addView(sum,UiKit.matchWrap(this,0,12));
        LinearLayout market=new LinearLayout(this);market.setOrientation(LinearLayout.VERTICAL);
        market.addView(UiKit.muted(this,"مبنای قیمت‌ها بازار آزاد ایران است: دلار، یورو، طلای ۱۸ و ۲۴ عیار، اونس جهانی و سکه‌ها. در خطا آخرین قیمت معتبر حفظ می‌شود."),UiKit.matchWrap(this,0,8));
        List<String> modes=new ArrayList<>();java.util.Collections.addAll(modes,"فقط دستی / آفلاین","به‌روزرسانی آنلاین هنگام درخواست","خودکار هنگام باز بودن (هر ۵ دقیقه)");
        Spinner mode=picker(modes);mode.setSelection(NexaStore.marketRefreshMode(this));
        mode.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p,View v,int position,long id){NexaStore.setMarketRefreshMode(AssetsActivity.this,position);}});
        market.addView(mode,UiKit.matchWrap(this,0,8));
        Button refresh=UiKit.primaryButton(this,"دریافت قیمت بازار ایران");refresh.setOnClickListener(v->refreshMarket(refresh));market.addView(refresh);
        marketStatus=UiKit.muted(this,"");market.addView(marketStatus,UiKit.matchWrap(this,10,0));
        root.addView(UiKit.collapsible(this,"assets_market","🇮🇷 بازار ایران","قیمت آزاد ایران • آخرین دریافت معتبر",7,false,market),UiKit.matchWrap(this,0,12));
        LinearLayout typesBody=new LinearLayout(this);typesBody.setOrientation(LinearLayout.VERTICAL);LinearLayout typeHead=new LinearLayout(this);typeHead.setGravity(Gravity.CENTER_VERTICAL);
        typeHead.addView(UiKit.sectionTitle(this,"انواع دارایی"),new LinearLayout.LayoutParams(0,-2,1f));Button typePlus=UiKit.addIconButton(this);typePlus.setOnClickListener(v->addAssetTypeDialog());typeHead.addView(typePlus,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));typesBody.addView(typeHead);
        typesBody.addView(UiKit.muted(this,"تعریف نوع جدید فقط از این لیست انجام می‌شود."),UiKit.matchWrap(this,6,8));typeManagerList=new LinearLayout(this);typeManagerList.setOrientation(LinearLayout.VERTICAL);typesBody.addView(typeManagerList);root.addView(UiKit.collapsible(this,"assets_types","انواع دارایی","مدیریت فهرست نوع‌های دارایی",1,false,typesBody),UiKit.matchWrap(this,0,12));
        Button add=UiKit.primaryButton(this,"＋ ثبت دارایی / خرید جدید");add.setOnClickListener(v->editForm(null));root.addView(add,UiKit.matchWrap(this,0,14));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);
        renderAssetTypes();render();updateMarketText();
    }
    @Override protected void onResume(){super.onResume();if(list!=null){
        if(NexaStore.marketRefreshMode(this)==2 && System.currentTimeMillis()-NexaStore.iranMarketUpdated(this)>300000L){
            // No background polling: only refresh on screen opening, if cache is stale.
            MarketDataHelper.refresh(this,(ok,msg)->{if(ok){updateOnlineAssets();render();}if(marketStatus!=null)marketStatus.setText(msg);});
        }
    }}
    private List<String> assetTypeValues(){List<String> out=new ArrayList<>(standardTypes);for(String x:NexaStore.assetTypes(this))if(!out.contains(x))out.add(x);for(NexaStore.AssetEntry x:NexaStore.assets(this))if(!out.contains(x.type))out.add(x.type);return out;}
    private void renderAssetTypes(){if(typeManagerList==null)return;typeManagerList.removeAllViews();for(String t:assetTypeValues()){TextView row=UiKit.muted(this,"• "+t);row.setTextSize(14);typeManagerList.addView(row,UiKit.matchWrap(this,0,4));}}
    private void addAssetTypeDialog(){EditText entry=field("نام نوع دارایی جدید");new AlertDialog.Builder(this).setTitle("نوع دارایی جدید").setView(entry).setPositiveButton("افزودن",(d,w)->{String t=entry.getText().toString().trim();if(t.isEmpty())return;NexaStore.addAssetType(this,t);renderAssetTypes();}).setNegativeButton("انصراف",null).show();}

    private void refreshMarket(Button b){
        if(NexaStore.marketRefreshMode(this)==0){Toast.makeText(this,"دریافت اینترنتی خاموش است.",Toast.LENGTH_SHORT).show();return;}
        b.setEnabled(false);marketStatus.setText("در حال دریافت...");
        MarketDataHelper.refresh(this,(ok,msg)->{b.setEnabled(true);marketStatus.setText(msg);
            if(ok){updateOnlineAssets();checkPriceAlerts();render();updateMarketText();}});
    }
    private void editForm(NexaStore.AssetEntry current){
        LinearLayout box=UiKit.dialogPanel(this);
        List<String> types=assetTypeValues();
        Spinner type=picker(types);if(current!=null)type.setSelection(Math.max(0,types.indexOf(current.type)));
        EditText name=field("فروشنده / مجموعه؛ مثلاً طلای جوادی");
        final String[] sellerId={current==null?"":current.sellerId};
        Button sellerBtn=UiKit.secondaryButton(this,"انتخاب از دفتر مشترک فروشندگان");
        NexaStore.ShoppingSeller oldSeller=current==null?null:NexaStore.sellerById(this,current.sellerId);if(oldSeller!=null)sellerBtn.setText("فروشنده: "+oldSeller.name);
        sellerBtn.setOnClickListener(v->pickSeller(sellerId,sellerBtn,name));
        EditText amount=field("مقدار؛ مثلاً ۵٫۲۵ گرم");amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText soot=field("سوت اضافه (۰ تا ۹۹۹) برای طلا");soot.setInputType(InputType.TYPE_CLASS_NUMBER);
        EditText buy=field("قیمت خرید هر واحد");buy.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(buy);
        EditText quote=field("قیمت فعلی هر واحد");quote.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(quote);
        EditText fee=field("مجموع کارمزد و هزینه");fee.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(fee);
        Spinner currency=picker(java.util.Arrays.asList("تومان","ریال"));
        CheckBox online=new CheckBox(this);online.setText("قیمت روز از بازار ایران (برای نوع‌های پشتیبانی‌شده)");online.setTextColor(UiKit.TEXT);
        EditText alertTarget=field("هشدار قیمت هدف (تومان)؛ ۰ یعنی خاموش");alertTarget.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);NumberFormatUtil.attachThousandsDecimal(alertTarget);
        CheckBox alertBuy=new CheckBox(this);alertBuy.setText("هشدار هنگام رسیدن دوباره به قیمت آخرین خرید");alertBuy.setTextColor(UiKit.TEXT);
        Spinner alertDirection=picker(java.util.Arrays.asList("هشدار در هر دو جهت","فقط عبور رو به بالا","فقط عبور رو به پایین"));
        EditText note=field("توضیحات / مشخصات");
        final long[] buyDate={current==null?System.currentTimeMillis():current.buyDate};
        Button date=UiKit.secondaryButton(this,"تاریخ و ساعت خرید: "+PersianDateUtil.pretty(buyDate[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,buyDate[0],"تاریخ و ساعت خرید",ms->{buyDate[0]=ms;date.setText("تاریخ و ساعت خرید: "+PersianDateUtil.pretty(ms));}));
        TextView total=UiKit.sectionTitle(this,"مجموع خرید: —");
        if(current!=null){name.setText(current.name);amount.setText(df.format(current.amount));
            buy.setText(df.format("ریال".equals(current.currency)?current.buyUnitPrice*10:current.buyUnitPrice));
            quote.setText(df.format("ریال".equals(current.currency)?current.currentUnitPrice*10:current.currentUnitPrice));
            fee.setText(df.format("ریال".equals(current.currency)?current.fee*10:current.fee));
            currency.setSelection("ریال".equals(current.currency)?1:0);online.setChecked(current.autoPrice);alertTarget.setText(current.alertTarget>0?moneyFormat.format(current.alertTarget):"");alertBuy.setChecked(current.alertAtBuy);alertDirection.setSelection("up".equals(current.alertDirection)?1:("down".equals(current.alertDirection)?2:0));note.setText(current.note);}
        // An existing asset amount already includes soot; editing starts from the exact decimal amount.
        TextWatcher calculate=new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){double a=num(amount.getText().toString());
                double price=num(buy.getText().toString());double fees=num(fee.getText().toString());int extra=(int)num(soot.getText().toString());
                if(extra>=0&&extra<=999)a+=extra/1000.0;
                double totalPrice=a*price+fees;total.setText("مجموع خرید: "+moneyFormat.format(totalPrice)+" "+currency.getSelectedItem());}
            public void afterTextChanged(Editable e){}};
        amount.addTextChangedListener(calculate);buy.addTextChangedListener(calculate);fee.addTextChangedListener(calculate);soot.addTextChangedListener(calculate);
        currency.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> a){}
            public void onItemSelected(android.widget.AdapterView<?> a,View v,int i,long id){total.setText("مجموع خرید: "+moneyFormat.format(num(amount.getText().toString())*num(buy.getText().toString())+num(fee.getText().toString()))+" "+currency.getSelectedItem());}});
        box.addView(type,UiKit.matchWrap(this,0,8));box.addView(UiKit.muted(this,"نوع جدید را از لیست «انواع دارایی» صفحه اصلی این بخش اضافه کن."),UiKit.matchWrap(this,0,6));for(View v:new View[]{name,sellerBtn,amount,soot,buy,quote,fee,currency,online,alertTarget,alertBuy,alertDirection,date,total,note})box.addView(v,UiKit.matchWrap(this,0,8));
        ScrollView sc=new ScrollView(this);sc.addView(box);
        new AlertDialog.Builder(this).setTitle(current==null?"ثبت خرید دارایی":"ویرایش کامل خرید")
            .setView(sc).setPositiveButton("ذخیره",(d,w)->{
                double a=num(amount.getText().toString()),b=num(buy.getText().toString());int st=(int)num(soot.getText().toString());
                if(st<0||st>999){Toast.makeText(this,"سوت باید ۰ تا ۹۹۹ باشد.",Toast.LENGTH_LONG).show();return;}
                a+=st/1000.0;
                if(a<=0||b<=0){Toast.makeText(this,"مقدار و قیمت خرید باید مثبت باشند.",Toast.LENGTH_LONG).show();return;}
                NexaStore.AssetEntry x=current==null?new NexaStore.AssetEntry():current;
                x.type=String.valueOf(type.getSelectedItem());x.name=name.getText().toString().trim();
                if(x.name.isEmpty())x.name="بدون مجموعه";
                x.amount=a;double divisor=currency.getSelectedItemPosition()==1?10.0:1.0;
                x.buyUnitPrice=b/divisor;x.currentUnitPrice=num(quote.getText().toString())/divisor;
                if(x.currentUnitPrice<=0)x.currentUnitPrice=x.buyUnitPrice;
                x.fee=num(fee.getText().toString())/divisor;x.currency=String.valueOf(currency.getSelectedItem());
                x.autoPrice=online.isChecked();x.alertTarget=num(alertTarget.getText().toString());x.alertAtBuy=alertBuy.isChecked();x.alertDirection=alertDirection.getSelectedItemPosition()==1?"up":(alertDirection.getSelectedItemPosition()==2?"down":"both");x.alertTriggered=false;x.buyDate=buyDate[0];x.note=note.getText().toString().trim();x.sellerId=sellerId[0];
                if(x.autoPrice)applyMarketToAsset(x);
                if(current==null)NexaStore.addAsset(this,x);else NexaStore.updateAsset(this,x);
                NexaStore.addHistory(this,"دارایی",(current==null?"خرید جدید: ":"ویرایش خرید: ")+x.name);PriceMonitorReceiver.schedule(this);render();
            }).setNegativeButton("انصراف",null).show();
    }
    private void pickSeller(String[] out,Button btn,EditText name){List<NexaStore.ShoppingSeller> data=NexaStore.sellers(this);LinearLayout box=UiKit.dialogPanel(this);if(data.isEmpty())box.addView(UiKit.muted(this,"فروشنده‌ای ثبت نشده؛ از Settings > دفتر مشترک اضافه کن."));for(NexaStore.ShoppingSeller s:data){Button b=UiKit.secondaryButton(this,s.name+(s.category.isEmpty()?"":" • "+s.category));b.setOnClickListener(v->{out[0]=s.id;btn.setText("فروشنده: "+s.name);name.setText(s.name);});box.addView(b,UiKit.matchWrap(this,0,5));}new AlertDialog.Builder(this).setTitle("انتخاب فروشنده").setView(box).setPositiveButton("بستن",null).show();}
    private void updateOnlineAssets(){AssetMarketEngine.updateOnlineAssets(this);}
    private void applyMarketToAsset(NexaStore.AssetEntry x){double v=AssetMarketEngine.marketPrice(this,x.type);if(v>0)x.currentUnitPrice=v;}
    private void updateMarketText(){if(marketStatus==null)return;long t=NexaStore.iranMarketUpdated(this);
        if(t<=0){marketStatus.setText("قیمت بازار ایران هنوز دریافت نشده");return;}
        long age=Math.max(0,System.currentTimeMillis()-t);String freshness=age>86400000L?" • داده قدیمی":age>1800000L?" • نیازمند تازه‌سازی":" • تازه";
        marketStatus.setText("آخرین دریافت معتبر: "+PersianDateUtil.pretty(t)+freshness+
            "\nدلار "+moneyFormat.format(NexaStore.iranUsd(this))+" • یورو "+moneyFormat.format(NexaStore.iranEur(this))+
            "\nطلای ۱۸: "+moneyFormat.format(NexaStore.iranGold18(this))+" • طلای ۲۴: "+moneyFormat.format(NexaStore.iranGold24(this))+
            "\nاونس جهانی $"+df.format(NexaStore.iranOunce(this))+
            "\nسکه امامی "+moneyFormat.format(NexaStore.iranEmami(this))+" • نیم "+moneyFormat.format(NexaStore.iranHalf(this))+" • ربع "+moneyFormat.format(NexaStore.iranQuarter(this))+
            "\nمنبع: "+NexaStore.iranMarketSource(this));}
    private void checkPriceAlerts(){AssetMarketEngine.checkAlerts(this);}
    private double cost(NexaStore.AssetEntry x){return AssetFinanceEngine.openCost(x);}
    private double value(NexaStore.AssetEntry x){return AssetFinanceEngine.marketValue(x);}
    private String money(double value){return moneyFormat.format(value)+" تومان";}
    private void render(){renderAssetTypes();if(list==null)return;list.removeAllViews();List<NexaStore.AssetEntry> data=NexaStore.assets(this);
        double initial=AssetFinanceEngine.totalOpenCost(data),now=AssetFinanceEngine.totalMarketValue(data);
        double realized=AssetFinanceEngine.totalRealized(data),profit=now-initial+realized;
        summary.setText("تعداد خریدها: "+data.size()+" • انواع دارایی: "+new LinkedHashSet<String>(){{for(NexaStore.AssetEntry a:data)add(a.type);}}.size()+"\nبهای خرید: "+money(initial)+"\nارزش فعلی: "+money(now)+
            "\nسود/زیان باز: "+(now-initial>=0?"+":"")+money(now-initial)+"\nسود/زیان تحقق‌یافته: "+(realized>=0?"+":"")+money(realized)+"\nسود/زیان کل: "+(profit>=0?"+":"")+money(profit)+
            (initial>0?"   ("+String.format(Locale.US,"%+.2f%%",profit/initial*100.0)+")":""));
        if(data.isEmpty()){TextView e=UiKit.muted(this,"هنوز خریدی ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,15,0));return;}
        Map<String,Map<String,List<NexaStore.AssetEntry>>> typeGroups=new LinkedHashMap<>();
        for(NexaStore.AssetEntry x:data){Map<String,List<NexaStore.AssetEntry>> vendors=typeGroups.get(x.type);
            if(vendors==null){vendors=new LinkedHashMap<>();typeGroups.put(x.type,vendors);}
            NexaStore.ShoppingSeller linked=NexaStore.sellerById(this,x.sellerId);String vendorName=linked!=null?linked.name:(x.name==null||x.name.trim().isEmpty()?"بدون فروشنده":x.name);
            List<NexaStore.AssetEntry> entries=vendors.get(vendorName);
            if(entries==null){entries=new ArrayList<>();vendors.put(vendorName,entries);}entries.add(x);
        }
        for(Map.Entry<String,Map<String,List<NexaStore.AssetEntry>>> type: typeGroups.entrySet()){
            LinearLayout typeCard=UiKit.colorfulCardLayout(this,4),typeBody=new LinearLayout(this);
            typeBody.setOrientation(LinearLayout.VERTICAL);typeBody.setVisibility(View.GONE);
            double tCost=0,tValue=0;int n=0;for(List<NexaStore.AssetEntry> vals:type.getValue().values())
                for(NexaStore.AssetEntry x:vals){tCost+=cost(x);tValue+=value(x);n++;}
            final double ct=tCost,vt=tValue;final int count=n;
            Button head=UiKit.secondaryButton(this,"▸ "+type.getKey()+" • "+n+" مورد • ارزش "+money(vt)+" • "+money(vt-ct));
            head.setOnClickListener(v->{boolean open=typeBody.getVisibility()!=View.VISIBLE;
                typeBody.setVisibility(open?View.VISIBLE:View.GONE);
                head.setText((open?"▾ ":"▸ ")+type.getKey()+" • "+count+" مورد • ارزش "+money(vt)+" • "+money(vt-ct));});
            typeCard.addView(head);
            for(Map.Entry<String,List<NexaStore.AssetEntry>> vendor:type.getValue().entrySet()){
                LinearLayout vendorCard=UiKit.cardLayout(this),vendorBody=new LinearLayout(this);
                vendorBody.setOrientation(LinearLayout.VERTICAL);vendorBody.setVisibility(View.GONE);
                double groupCost=0,groupValue=0,amount=0;
                for(NexaStore.AssetEntry x:vendor.getValue()){groupCost+=cost(x);groupValue+=value(x);amount+=x.amount;}
                Button vendorHead=UiKit.secondaryButton(this,"▸ "+vendor.getKey()+"  ("+vendor.getValue().size()+")");
                vendorHead.setOnClickListener(v->{boolean open=vendorBody.getVisibility()!=View.VISIBLE;
                    vendorBody.setVisibility(open?View.VISIBLE:View.GONE);
                    vendorHead.setText((open?"▾ ":"▸ ")+vendor.getKey()+"  ("+vendor.getValue().size()+")");});
                vendorCard.addView(vendorHead);
                vendorCard.addView(UiKit.muted(this,"مقدار: "+df.format(amount)+" • مجموع خرید: "+money(groupCost)+
                    "\nارزش: "+money(groupValue)+" • سود/زیان: "+money(groupValue-groupCost)+(groupCost>0?" ("+String.format(Locale.US,"%+.2f%%",(groupValue-groupCost)/groupCost*100.0)+")":"")),UiKit.matchWrap(this,6,6));
                java.util.Collections.sort(vendor.getValue(),(a,b)->Long.compare(b.buyDate,a.buyDate));
                for(NexaStore.AssetEntry x:vendor.getValue()){
                    LinearLayout row=UiKit.cardLayout(this);double p=value(x)-cost(x);
                    row.addView(UiKit.sectionTitle(this,"خرید "+PersianDateUtil.pretty(x.buyDate)));
                    row.addView(UiKit.muted(this,"مقدار: "+df.format(x.amount)+" • قیمت خرید: "+money(x.buyUnitPrice)+
                        "\nقیمت روز: "+money(x.currentUnitPrice)+(x.autoPrice?" 🌐":" ✎")+"\nسود/زیان: "+money(p)+
                        (cost(x)>0?"  ("+String.format(Locale.US,"%+.2f%%",p/cost(x)*100)+")":"")+(x.fee>0?"\nکارمزد: "+money(x.fee):"")+(x.realizedProfit!=0?"\nسود/زیان فروش‌ها: "+money(x.realizedProfit):"")+(x.soldAmount>0?" • فروخته‌شده: "+df.format(x.soldAmount):"")+(x.alertTarget>0||x.alertAtBuy?"\n🔔 هشدار: "+(x.alertAtBuy?"قیمت خرید":money(x.alertTarget))+" • "+("up".equals(x.alertDirection)?"رو به بالا":"down".equals(x.alertDirection)?"رو به پایین":"دوطرفه"):"")+(x.currency==null||x.currency.isEmpty()?"":" • ارز: "+x.currency)),UiKit.matchWrap(this,5,6));
                    if(x.note!=null&&!x.note.trim().isEmpty())row.addView(UiKit.muted(this,"📝 "+x.note),UiKit.matchWrap(this,0,6));
                    LinearLayout buttons=new LinearLayout(this);
                    Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editForm(x));
                    Button sell=UiKit.secondaryButton(this,"فروش");sell.setOnClickListener(v->sellForm(x));
                    Button bell=UiKit.secondaryButton(this,(x.alertTarget>0||x.alertAtBuy)?"🔔":"🔕");bell.setOnClickListener(v->{if(x.alertTarget>0||x.alertAtBuy){x.alertTarget=0;x.alertAtBuy=false;x.alertTriggered=false;NexaStore.updateAsset(this,x);PriceMonitorReceiver.schedule(this);render();}else editForm(x);});
                    Button delete=UiKit.deleteIconButton(this);delete.setOnClickListener(v->new AlertDialog.Builder(this)
                        .setTitle("حذف خرید؟").setMessage(x.name+" • "+PersianDateUtil.pretty(x.buyDate))
                        .setPositiveButton("حذف",(d,w)->{NexaStore.removeAsset(this,x.id);PriceMonitorReceiver.schedule(this);render();})
                        .setNegativeButton("انصراف",null).show());
                    buttons.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));LinearLayout.LayoutParams slp=new LinearLayout.LayoutParams(UiKit.dp(this,72),UiKit.dp(this,44));slp.setMargins(UiKit.dp(this,5),0,0,0);buttons.addView(sell,slp);LinearLayout.LayoutParams blp=new LinearLayout.LayoutParams(UiKit.dp(this,52),UiKit.dp(this,44));blp.setMargins(UiKit.dp(this,5),0,0,0);buttons.addView(bell,blp);LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dlp.setMargins(UiKit.dp(this,5),0,0,0);buttons.addView(delete,dlp);
                    row.addView(buttons,UiKit.matchWrap(this,7,0));vendorBody.addView(row,UiKit.matchWrap(this,6,0));
                }
                vendorCard.addView(vendorBody);typeBody.addView(vendorCard,UiKit.matchWrap(this,7,0));
            }
            typeCard.addView(typeBody);list.addView(typeCard,UiKit.matchWrap(this,0,10));
        }
    }
    private void sellForm(NexaStore.AssetEntry x){
        if(x.amount<=0){Toast.makeText(this,"موجودی این خرید صفر است.",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.muted(this,"موجودی قابل فروش: "+df.format(x.amount)+" • میانگین خرید: "+money(x.buyUnitPrice)),UiKit.matchWrap(this,0,6));
        EditText qty=field("مقدار فروش"),price=field("قیمت فروش هر واحد (تومان)");qty.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);price.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);price.setText(x.currentUnitPrice>0?moneyFormat.format(x.currentUnitPrice):"");box.addView(qty,UiKit.matchWrap(this,4,4));box.addView(price,UiKit.matchWrap(this,4,4));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("ثبت فروش • "+x.type).setView(box).setPositiveButton("ثبت فروش",null).setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(dd->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{double q=num(qty.getText().toString()),p=num(price.getText().toString());if(!AssetFinanceEngine.sell(x,q,p,System.currentTimeMillis())){Toast.makeText(this,"مقدار یا قیمت فروش معتبر نیست.",Toast.LENGTH_LONG).show();return;}NexaStore.updateAsset(this,x);NexaStore.addHistory(this,"دارایی","فروش "+x.type+" • "+df.format(q)+" واحد • "+money(p));render();dialog.dismiss();}));dialog.show();
    }
    private double num(String raw){try{String s=raw.trim().replace(",","").replace("٬","").replace("٫",".");
        StringBuilder result=new StringBuilder();for(int i=0;i<s.length();i++){char ch=s.charAt(i);
            if(ch>='۰'&&ch<='۹')ch=(char)('0'+ch-'۰');if(ch>='٠'&&ch<='٩')ch=(char)('0'+ch-'٠');result.append(ch);}
        return Double.parseDouble(result.toString());}catch(Exception e){return 0;}}
}
