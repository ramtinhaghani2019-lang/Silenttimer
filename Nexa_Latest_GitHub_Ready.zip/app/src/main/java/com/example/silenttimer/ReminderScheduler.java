package com.example.silenttimer;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;

import java.util.List;

public final class ReminderScheduler {
    public static final String CHANNEL = "nexa_reminders_alarm_v6";
    public static final String LOCK_CHANNEL = "nexa_lock_card";
    private ReminderScheduler() {}

    public static void rescheduleAll(Context c) {
        for (NexaStore.Reminder r : NexaStore.reminders(c)) {
            if (r.active && !r.done) scheduleReminder(c, r);
        }
        MedicineScheduler.rescheduleAll(c);
        WeeklyScheduler.rescheduleAll(c);
        updateLockCard(c);
    }

    public static void scheduleReminder(Context c, NexaStore.Reminder r) {
        scheduleTokens(c,r);
        updateLockCard(c);
    }

    /** Schedule a confirmed bulk import, refreshing the lock card only once. */
    public static void scheduleImportedBatch(Context c, List<NexaStore.Reminder> reminders) {
        if (reminders == null || reminders.isEmpty()) return;
        for (NexaStore.Reminder r : reminders) scheduleTokens(c,r);
        updateLockCard(c);
    }

    private static void scheduleTokens(Context c, NexaStore.Reminder r) {
        if (r == null || !r.active || r.done) return;
        for (String rule : AlertRules.split(r.offsetsMinutes)) {
            long trigger=AlertRules.trigger(r.whenMillis,rule);
            if (trigger > System.currentTimeMillis()) {
                String token=occurrenceToken(r.id,rule,r.whenMillis);
                scheduleToken(c,r.id,token,trigger,r.repeatMinutes);
            }
        }
    }

    public static void cancelReminder(Context c,NexaStore.Reminder r){
        if(r==null)return;
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        for(String rule:AlertRules.split(r.offsetsMinutes)){
            String token=occurrenceToken(r.id,rule,r.whenMillis);
            // Cancel both new occurrence-scoped and pre-155 legacy alarms.
            cancelToken(c, r.id+":"+rule);
            Intent i=new Intent(c,ReminderAlarmReceiver.class);
            PendingIntent pi=PendingIntent.getBroadcast(c,token.hashCode(),i,
                    PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);
            if(pi!=null && am!=null){am.cancel(pi);pi.cancel();}
            NexaAudioController.stopOwner("reminder:"+token);
            if(nm!=null)nm.cancel(token.hashCode());
        }
    }

    /** A completed occurrence must not suppress the next occurrence of a recurring reminder. */
    public static String occurrenceToken(String reminderId, String rule, long whenMillis) {
        return reminderId + ":" + rule + ":" + whenMillis;
    }

    public static void scheduleToken(Context c, String reminderId, String token, long trigger, int repeatMinutes) {
        Intent i = new Intent(c, ReminderAlarmReceiver.class);
        i.putExtra("id", reminderId);
        i.putExtra("token", token);
        i.putExtra("repeat", repeatMinutes);
        PendingIntent pi = PendingIntent.getBroadcast(c, token.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setAlarm(c, trigger, pi);
    }

    public static void cancelToken(Context c, String token) {
        if (token == null) return;
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent i = new Intent(c, ReminderAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(c, token.hashCode(), i,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
        if (pi != null) { am.cancel(pi); pi.cancel(); }
    }

    /** Reuses the reminder token PendingIntent so dismissal/cancellation can cancel retries. */
    public static void scheduleCallAudioRetry(Context c, String reminderId, String token, int attempt) {
        if (attempt < 1 || attempt > 5) return;
        Intent i = new Intent(c, ReminderAlarmReceiver.class);
        i.putExtra("id", reminderId);
        i.putExtra("token", token);
        i.putExtra("repeat", 0);
        i.putExtra("call_retry", attempt);
        PendingIntent pi = PendingIntent.getBroadcast(c, token.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        setAlarm(c, System.currentTimeMillis() + 60_000L, pi);
    }

    public static void setAlarm(Context c, long trigger, PendingIntent pi) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            else if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, trigger, pi);
        } catch (SecurityException e) {
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi); else am.set(AlarmManager.RTC_WAKEUP, trigger, pi);
        }
    }

    public static void createChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel ch=new NotificationChannel(CHANNEL,"Nexa Alarm Reminders",NotificationManager.IMPORTANCE_HIGH);
        ch.setDescription("قرارها، سررسیدها و هشدارهای زنگ‌دار Nexa");
        ch.enableVibration(true);ch.setVibrationPattern(new long[]{0,700,350,700,350,1000});
        ch.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        Uri alarmSound=RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
        AudioAttributes alarmAttrs=new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        ch.setSound(alarmSound,alarmAttrs);
        nm.createNotificationChannel(ch);
        NotificationChannel lock=new NotificationChannel(LOCK_CHANNEL,"Nexa Lock Reminder",NotificationManager.IMPORTANCE_LOW);
        lock.setDescription("نمایش نزدیک‌ترین قرار روی صفحه قفل"); lock.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC); lock.setSound(null,null); nm.createNotificationChannel(lock);
    }

    public static void updateLockCard(Context c) {
        createChannels(c);
        NexaStore.Reminder next=null; long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:NexaStore.reminders(c)) if(r.active && r.whenMillis>=now && (next==null || r.whenMillis<next.whenMillis)) next=r;
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(next==null){nm.cancel(9200);return;}
        Intent open=new Intent(c,RemindersActivity.class);
        PendingIntent pi=PendingIntent.getActivity(c,9200,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,LOCK_CHANNEL):new Notification.Builder(c);
        Notification n=b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle(next.icon+"  "+next.title).setContentText("نزدیک‌ترین یادآور • "+PersianDateUtil.pretty(next.whenMillis)).setContentIntent(pi).setOngoing(true).setVisibility(Notification.VISIBILITY_PUBLIC).setCategory(Notification.CATEGORY_REMINDER).build();
        nm.notify(9200,n);
    }
}
