package com.example.silenttimer;

import android.content.Context;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ImageView;

/** Lightweight pinch-to-zoom image view for receipt/document previews. */
public class ZoomImageView extends ImageView {
    private static final int NONE=0, DRAG=1, ZOOM=2;
    private final Matrix matrix=new Matrix();
    private final Matrix saved=new Matrix();
    private final PointF start=new PointF();
    private final PointF mid=new PointF();
    private int mode=NONE;
    private float oldDist=1f;
    private float scale=1f;

    public ZoomImageView(Context c){super(c);init();}
    public ZoomImageView(Context c, AttributeSet a){super(c,a);init();}
    public ZoomImageView(Context c, AttributeSet a,int s){super(c,a,s);init();}

    private void init(){
        setScaleType(ScaleType.MATRIX);
        setImageMatrix(matrix);
    }

    public void resetZoom(){
        matrix.reset();scale=1f;setImageMatrix(matrix);invalidate();
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        switch(e.getActionMasked()){
            case MotionEvent.ACTION_DOWN:
                saved.set(matrix);start.set(e.getX(),e.getY());mode=DRAG;break;
            case MotionEvent.ACTION_POINTER_DOWN:
                oldDist=spacing(e);if(oldDist>10f){saved.set(matrix);midPoint(mid,e);mode=ZOOM;}break;
            case MotionEvent.ACTION_MOVE:
                if(mode==DRAG){matrix.set(saved);matrix.postTranslate(e.getX()-start.x,e.getY()-start.y);}
                else if(mode==ZOOM){float nd=spacing(e);if(nd>10f){float factor=nd/oldDist;float next=scale*factor;if(next<1f)factor=1f/scale;else if(next>6f)factor=6f/scale;matrix.set(saved);matrix.postScale(factor,factor,mid.x,mid.y);}}
                setImageMatrix(matrix);break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
                if(mode==ZOOM){float[] vals=new float[9];matrix.getValues(vals);scale=Math.max(1f,Math.min(6f,vals[Matrix.MSCALE_X]));}
                mode=NONE;break;
        }
        return true;
    }
    private float spacing(MotionEvent e){if(e.getPointerCount()<2)return 0;float x=e.getX(0)-e.getX(1),y=e.getY(0)-e.getY(1);return (float)Math.sqrt(x*x+y*y);}
    private void midPoint(PointF p,MotionEvent e){p.set((e.getX(0)+e.getX(1))/2f,(e.getY(0)+e.getY(1))/2f);}
}
