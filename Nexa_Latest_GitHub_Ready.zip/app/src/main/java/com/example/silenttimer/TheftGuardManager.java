package com.example.silenttimer;

import android.app.*;
import android.content.*;
import android.os.BatteryManager;

/** Detects a real charger connected -> disconnected transition and raises Nexa's highest-priority alarm. */
public final class TheftGuardManager {
    public static final int NOTIFICATION_ID = 7430;
    public static final String OWNER = "theft_guard";
    private TheftGuardManager(){}

    public static void onBatteryChanged(Context c, Intent i){
        if(c==null||i==null)return;
        boolean plugged=i.getIntExtra(BatteryManager.EXTRA_PLUGGED,0)!=0;
        if(!AppPrefs.isTheftGuardEnabled(c)){
            AppPrefs.setTheftLastPlugged(c,plugged);
            if(AppPrefs.isTheftAlarmActive(c)) stop(c);
            return;
        }
        if(!AppPrefs.isTheftPlugStateKnown(c)){
            AppPrefs.setTheftLastPlugged(c,plugged); // baseline only: never alarm on service/app startup
            return;
        }
        boolean wasPlugged=AppPrefs.getTheftLastPlugged(c);
        AppPrefs.setTheftLastPlugged(c,plugged);
        if(wasPlugged && !plugged && !AppPrefs.isTheftAlarmActive(c)) trigger(c);
    }

    public static void trigger(Context c){
        AppPrefs.setTheftAlarmActive(c,true);
        NexaAudioController.startAlarm(c,OWNER,NexaAudioController.PRIORITY_THEFT);
        NotificationChannelHelper.ensureCoreChannels(c);
        Intent open=new Intent(c,TheftAlarmActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,NOTIFICATION_ID,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(c,NotificationChannelHelper.CHANNEL_THEFT_ALARM)
                .setSmallIcon(R.drawable.app_icon).setContentTitle("هشدار ضدسرقت Nexa")
                .setContentText("شارژر از دستگاه جدا شد • برای توقف، هویت را تأیید کنید")
                .setStyle(new Notification.BigTextStyle().bigText("شارژر از دستگاه جدا شد. هشدار فقط پس از تأیید اثر انگشت، PIN Nexa یا قفل امن گوشی متوقف می‌شود."))
                .setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true).setAutoCancel(false)
                .setCategory(Notification.CATEGORY_ALARM).setContentIntent(pi).build();
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)nm.notify(NOTIFICATION_ID,n);
    }

    public static void stop(Context c){
        NexaAudioController.stopOwner(OWNER);
        AppPrefs.setTheftAlarmActive(c,false);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)nm.cancel(NOTIFICATION_ID);
    }
}
