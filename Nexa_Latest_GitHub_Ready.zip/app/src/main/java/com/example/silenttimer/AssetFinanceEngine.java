package com.example.silenttimer;

import java.util.List;

/** Pure portfolio calculations shared by Assets UI and regression tests. */
public final class AssetFinanceEngine {
    private AssetFinanceEngine() {}
    private static double nonnegative(double v){return Double.isFinite(v)?Math.max(0,v):0;}
    public static double openCost(NexaStore.AssetEntry x){ return nonnegative(x.amount)*nonnegative(x.buyUnitPrice)+nonnegative(x.fee); }
    public static double marketValue(NexaStore.AssetEntry x){ return nonnegative(x.amount)*nonnegative(x.currentUnitPrice); }
    public static double unrealizedProfit(NexaStore.AssetEntry x){ return marketValue(x)-openCost(x); }
    public static double returnPercent(NexaStore.AssetEntry x){ double c=openCost(x); return c>0?unrealizedProfit(x)/c*100d:0; }
    public static double totalOpenCost(List<NexaStore.AssetEntry> data){double v=0;for(NexaStore.AssetEntry x:data)v+=openCost(x);return v;}
    public static double totalMarketValue(List<NexaStore.AssetEntry> data){double v=0;for(NexaStore.AssetEntry x:data)v+=marketValue(x);return v;}
    public static double totalRealized(List<NexaStore.AssetEntry> data){double v=0;for(NexaStore.AssetEntry x:data)v+=Double.isFinite(x.realizedProfit)?x.realizedProfit:0;return v;}
    public static double totalProfit(List<NexaStore.AssetEntry> data){return totalMarketValue(data)-totalOpenCost(data)+totalRealized(data);}
    public static boolean sell(NexaStore.AssetEntry x,double quantity,double unitPrice,long when){
        if(x==null||!Double.isFinite(quantity)||!Double.isFinite(unitPrice)||quantity<=0||unitPrice<=0||quantity>x.amount)return false;
        double unitCost=x.buyUnitPrice;
        double feeShare=x.amount>0?x.fee*(quantity/x.amount):0;
        x.realizedProfit += quantity*(unitPrice-unitCost)-feeShare;
        x.saleProceeds += quantity*unitPrice;
        x.soldAmount += quantity;
        x.amount -= quantity;
        x.fee=Math.max(0,x.fee-feeShare);
        x.lastSaleDate=when;
        return true;
    }
}
