package com.example.silenttimer;

import java.util.List;

/** Pure portfolio calculations shared by Assets UI and regression tests. */
public final class AssetFinanceEngine {
    private AssetFinanceEngine() {}
    private static double nonnegative(double v){return Double.isFinite(v)?Math.max(0,v):0;}
    private static double safe(double v){return Double.isFinite(v)?v:0d;}
    private static double safeAdd(double a,double b){return safe(safe(a)+safe(b));}
    private static double safeMultiply(double a,double b){return safe(nonnegative(a)*nonnegative(b));}
    public static double openCost(NexaStore.AssetEntry x){ if(x==null)return 0; return safeAdd(safeMultiply(x.amount,x.buyUnitPrice),nonnegative(x.fee)); }
    public static double marketValue(NexaStore.AssetEntry x){ if(x==null)return 0; return safeMultiply(x.amount,x.currentUnitPrice); }
    public static double unrealizedProfit(NexaStore.AssetEntry x){ return safe(marketValue(x)-openCost(x)); }
    public static double returnPercent(NexaStore.AssetEntry x){ double c=openCost(x); return c>0?safe(unrealizedProfit(x)/c*100d):0; }
    public static double totalOpenCost(List<NexaStore.AssetEntry> data){double v=0;if(data==null)return 0;for(NexaStore.AssetEntry x:data)v=safeAdd(v,openCost(x));return v;}
    public static double totalMarketValue(List<NexaStore.AssetEntry> data){double v=0;if(data==null)return 0;for(NexaStore.AssetEntry x:data)v=safeAdd(v,marketValue(x));return v;}
    public static double totalRealized(List<NexaStore.AssetEntry> data){double v=0;if(data==null)return 0;for(NexaStore.AssetEntry x:data)v=safeAdd(v,x==null?0:x.realizedProfit);return v;}
    public static double totalProfit(List<NexaStore.AssetEntry> data){return safeAdd(safe(totalMarketValue(data)-totalOpenCost(data)),totalRealized(data));}
    public static boolean sell(NexaStore.AssetEntry x,double quantity,double unitPrice,long when){
        if(x==null || !Double.isFinite(quantity) || !Double.isFinite(unitPrice)
                || quantity<=0 || unitPrice<=0 || !Double.isFinite(x.amount)
                || x.amount<=0 || quantity>x.amount || !Double.isFinite(x.buyUnitPrice)
                || x.buyUnitPrice<0 || !Double.isFinite(x.fee) || x.fee<0
                || !Double.isFinite(x.realizedProfit) || !Double.isFinite(x.saleProceeds)
                || !Double.isFinite(x.soldAmount))return false;
        double feeShare=x.fee*(quantity/x.amount);
        double profitDelta=quantity*(unitPrice-x.buyUnitPrice)-feeShare;
        double proceeds=quantity*unitPrice;
        double nextProfit=x.realizedProfit+profitDelta;
        double nextProceeds=x.saleProceeds+proceeds;
        double nextSold=x.soldAmount+quantity;
        if(!Double.isFinite(feeShare)||!Double.isFinite(profitDelta)
                || !Double.isFinite(proceeds)||!Double.isFinite(nextProfit)
                || !Double.isFinite(nextProceeds)||!Double.isFinite(nextSold))return false;
        x.realizedProfit=nextProfit;
        x.saleProceeds=nextProceeds;
        x.soldAmount=nextSold;
        x.amount-=quantity;
        x.fee=Math.max(0,x.fee-feeShare);
        x.lastSaleDate=when;
        return true;
    }
}
