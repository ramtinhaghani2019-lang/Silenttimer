package com.example.silenttimer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

/**
 * Fail-closed, per-field receipt import. Unreconciled OCR digits are never moved
 * into financial form fields. No data is saved here; the user must confirm.
 */
public final class AssetReceiptImportPlan {
    private AssetReceiptImportPlan() { }
    public static final class Decision {
        public final AssetReceiptParser.Result trusted;
        public final boolean complete;
        public final String explanation;
        public final int verifiedNumericFields;
        Decision(AssetReceiptParser.Result trusted,boolean complete,String explanation,int count){
            this.trusted=trusted;this.complete=complete;this.explanation=explanation;
            this.verifiedNumericFields=count;
        }
    }
    private static BigDecimal decimal(String s){
        if(s==null||s.trim().isEmpty())return null;
        try{
            BigDecimal n=new BigDecimal(s);
            return n.signum()>0?n:null;
        }catch(NumberFormatException ex){return null;}
    }
    private static boolean close(BigDecimal actual,BigDecimal expected,String relative){
        if(actual==null||expected==null||expected.signum()<=0)return false;
        return actual.subtract(expected).abs().divide(expected,10,RoundingMode.HALF_UP)
            .compareTo(new BigDecimal(relative))<=0;
    }
    private static AssetReceiptParser.Result metadata(AssetReceiptParser.Result src,String type){
        AssetReceiptParser.Result out=new AssetReceiptParser.Result();
        out.assetType=type;
        out.group=src.group;
        out.hasDate=src.hasDate;
        out.jalaliYear=src.jalaliYear;
        out.jalaliMonth=src.jalaliMonth;
        out.jalaliDay=src.jalaliDay;
        out.hour=src.hour;out.minute=src.minute;
        out.rawText=src.rawText;
        return out;
    }
    public static Decision evaluate(AssetReceiptParser.Result receipt,String selectedType){
        AssetReceiptParser.Result empty=new AssetReceiptParser.Result();
        if(receipt==null)return new Decision(empty,false,"تصویر خوانده نشد؛ اعداد را دستی وارد کن.",0);
        if(receipt.isSale)return new Decision(empty,false,"رسید مربوط به فروش است؛ آن را در فرم خرید ثبت نکن.",0);
        String selected=selectedType==null?"":selectedType.trim();
        String detected=receipt.assetType==null?"":receipt.assetType.trim();
        if(!selected.isEmpty()&&!detected.isEmpty()&&!selected.equals(detected))
            return new Decision(metadata(receipt,selected),false,
                "نوع دارایی تصویر با انتخاب فرم فرق دارد؛ ابتدا نوع دارایی را بررسی کن.",0);
        String type=!selected.isEmpty()?selected:detected;
        AssetReceiptParser.Result safe=metadata(receipt,type);
        if(type.isEmpty())return new Decision(safe,false,
            "نوع دارایی مشخص نیست؛ ابتدا دارایی را انتخاب و اعداد را دستی بررسی کن.",0);
        if(AssetReceiptParser.financiallyConsistent(receipt)){
            safe.amountRial=receipt.amountRial;
            safe.unitPriceRial=receipt.unitPriceRial;
            safe.cashFeeRial=receipt.cashFeeRial;
            safe.grossQuantity=receipt.grossQuantity;
            safe.gramFee=receipt.gramFee;
            safe.netQuantity=receipt.netQuantity;
            // Tracking identifiers are optional, not proof of purchase and not used
            // as a substitute for full numerical reconciliation.
            safe.tracking=receipt.tracking;
            return new Decision(safe,receipt.hasDate,
                receipt.hasDate?"مبلغ، نرخ، کارمزد و مقدار با هم سازگارند؛ پیش از ذخیره با رسید تطبیق بده.":
                "اعداد خرید با هم سازگارند؛ تاریخ رسید خوانده نشد و باید دستی انتخاب شود.",4);
        }
        // For Karizma, accept a subset only with independent mathematical proof.
        // This cannot accept an unrelated portfolio balance as purchase quantity.
        if(!"صندوق نقره کاریزما".equals(type))
            return new Decision(safe,false,"اعداد این رسید قابل تطبیق نبودند؛ هیچ مبلغی جایگذاری نشد.",0);
        BigDecimal paid=decimal(receipt.amountRial),gross=decimal(receipt.grossQuantity),
            price=decimal(receipt.unitPriceRial),cash=decimal(receipt.cashFeeRial),
            grams=decimal(receipt.gramFee);
        boolean amountPriceGross=paid!=null&&gross!=null&&price!=null&&
            close(gross.multiply(price),paid,"0.005");
        boolean weightedFee=amountPriceGross&&grams!=null&&grams.compareTo(gross)<0&&
            close(grams,gross.multiply(new BigDecimal("0.005")),"0.015");
        boolean rialFee=amountPriceGross&&cash!=null&&cash.compareTo(paid)<0&&
            close(cash,paid.multiply(new BigDecimal("0.005")),"0.015");
        int count=0;
        if(amountPriceGross){
            safe.amountRial=receipt.amountRial;safe.unitPriceRial=receipt.unitPriceRial;
            count+=2;
        }
        if(rialFee){safe.cashFeeRial=receipt.cashFeeRial;count++;}
        if(weightedFee){
            BigDecimal net=gross.subtract(grams);
            if(net.signum()>0){safe.netQuantity=net.stripTrailingZeros().toPlainString();count++;}
        }
        List<String> pending=new ArrayList<>();
        if(safe.amountRial.isEmpty())pending.add("مبلغ");
        if(safe.unitPriceRial.isEmpty())pending.add("نرخ واحد");
        if(safe.cashFeeRial.isEmpty())pending.add("کارمزد");
        if(safe.netQuantity.isEmpty())pending.add("مقدار خالص");
        if(!receipt.hasDate)pending.add("تاریخ");
        String explanation=(count==0?"اعداد تصویر هنوز با هم تطبیق ندارند؛ ":
            "فقط اعداد سازگار وارد شدند؛ ")+
            "بررسی دستی: "+String.join("، ",pending)+".";
        return new Decision(safe,false,explanation,count);
    }
}
