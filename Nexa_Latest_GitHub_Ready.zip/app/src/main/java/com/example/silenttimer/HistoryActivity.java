package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Activity history is local-only; no vault secrets are read or displayed. */
public class HistoryActivity extends Activity {
    private LinearLayout results, filters;
    private String query="", scope=HistoryScopePolicy.ALL;
    private boolean grouped=false;
    private int visibleLimit=60;
    private Button viewMode;
    private List<NexaStore.HistoryItem> all;
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        if(b!=null){
            query=b.getString("history_query","");
            scope=b.getString("history_scope",HistoryScopePolicy.ALL);
            grouped=b.getBoolean("history_grouped",false);
            visibleLimit=Math.max(60,b.getInt("history_limit",60));
        }
        build();
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("history_query",query);
        out.putString("history_scope",scope);
        out.putBoolean("history_grouped",grouped);
        out.putInt("history_limit",visibleLimit);
        super.onSaveInstanceState(out);
    }
    private void build(){
        all=NexaStore.history(this);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,16),UiKit.dp(this,18),UiKit.dp(this,32));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.header(this,"تاریخچه فعالیت‌ها",v->finish()),UiKit.matchWrap(this,0,5));
        root.addView(UiKit.muted(this,"جدیدترین فعالیت‌ها در ابتدا؛ جست‌وجو و فیلتر در همین صفحه."),UiKit.matchWrap(this,0,11));
        long now=System.currentTimeMillis();int day=0,week=0;
        for(NexaStore.HistoryItem h:all){
            if(HistoryScopePolicy.inWindow(HistoryScopePolicy.TODAY,h.time,now))day++;
            if(HistoryScopePolicy.inWindow(HistoryScopePolicy.WEEK,h.time,now))week++;
        }
        // One concise count on first view; detailed metrics are still one tap away.
        LinearLayout metrics=new LinearLayout(this);metrics.setOrientation(LinearLayout.VERTICAL);
        metrics.addView(NexaArchiveUi.metrics(this,
            new String[]{"همه فعالیت‌ها","۷ روز گذشته","۲۴ ساعت گذشته"},
            new String[]{String.valueOf(all.size()),String.valueOf(week),String.valueOf(day)},
            new int[]{UiKit.PURPLE,UiKit.BLUE,UiKit.GREEN}));
        root.addView(UiKit.collapsible(this,"history_metrics_221",
            "آمار فعالیت‌ها · "+all.size(),"",0,false,metrics),UiKit.matchWrap(this,0,12));
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(UiKit.TEXT);
        search.setHintTextColor(UiKit.MUTED);search.setHint("⌕ جستجو در تاریخچه");
        search.setBackground(UiKit.field(this));search.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,12));
        search.setText(query);
        LinearLayout searchRow=new LinearLayout(this);searchRow.setGravity(Gravity.CENTER_VERTICAL);
        searchRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        searchRow.addView(search,new LinearLayout.LayoutParams(0,-2,1f));
        Button clearQuery=UiKit.iconButton(this,"×","پاک کردن جست‌وجوی تاریخچه",UiKit.BLUE);
        clearQuery.setOnClickListener(v->search.setText(""));
        LinearLayout.LayoutParams clearParams=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        clearParams.setMargins(UiKit.dp(this,7),0,0,0);searchRow.addView(clearQuery,clearParams);
        root.addView(searchRow,UiKit.matchWrap(this,0,13));
        filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.addView(filters,UiKit.matchWrap(this,0,8));
        viewMode=UiKit.secondaryButton(this,"نمایش گروهی");
        viewMode.setTextSize(13f);
        viewMode.setContentDescription("تغییر نمایش تاریخچه به حالت گروهی");
        viewMode.setOnClickListener(v->{grouped=!grouped;refreshViewMode();render();});
        root.addView(viewMode,UiKit.matchWrap(this,0,10));
        refreshViewMode();
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();visibleLimit=60;render();}
            public void afterTextChanged(Editable e){}
        });
        Button clear=UiKit.secondaryButton(this,"پاک کردن همه سوابق");
        clear.setOnClickListener(v->new AlertDialog.Builder(this)
            .setTitle("پاک کردن همه سوابق؟")
            .setMessage("این کار برگشت‌پذیر نیست و فقط گزارش فعالیت را حذف می‌کند.")
            .setPositiveButton("پاک کردن",(d,w)->{NexaStore.clearHistory(this);query="";scope=HistoryScopePolicy.ALL;build();})
            .setNegativeButton("انصراف",null).show());
        LinearLayout advanced=new LinearLayout(this);advanced.setOrientation(LinearLayout.VERTICAL);
        advanced.addView(clear);
        root.addView(UiKit.collapsible(this,"history_manage_221","مدیریت سوابق",
            "پاک‌کردن تاریخچه فقط با تأیید خودت",0,false,advanced),UiKit.matchWrap(this,16,0));
        setContentView(sc);refreshFilters();render();
    }
    private void refreshViewMode(){
        if(viewMode==null)return;
        viewMode.setText(grouped?"نمایش فهرستی":"نمایش گروهی");
        viewMode.setContentDescription(grouped?"تغییر به فهرست مستقیم":"تغییر به دسته‌بندی سوابق");
    }
    private void refreshFilters(){
        filters.removeAllViews();
        String[] values={HistoryScopePolicy.ALL,HistoryScopePolicy.WEEK,HistoryScopePolicy.TODAY};
        String[] labels={"همه","۷ روز","۲۴ ساعت"};
        for(int i=0;i<values.length;i++){
            final String selected=values[i];
            TextView chip=NexaArchiveUi.chip(this,labels[i],scope.equals(selected));
            chip.setOnClickListener(v->{scope=selected;visibleLimit=60;refreshFilters();render();});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
            if(i>0)p.setMargins(UiKit.dp(this,5),0,0,0);
            filters.addView(chip,p);
        }
    }
    private void render(){
        if(results==null)return;
        results.removeAllViews();
        Map<String,List<NexaStore.HistoryItem>> groups=new LinkedHashMap<>();
        List<NexaStore.HistoryItem> matched=new ArrayList<>();
        long now=System.currentTimeMillis();
        for(NexaStore.HistoryItem h:all){
            if(!HistoryScopePolicy.matches(scope,h.time,now,h.type,h.text,query))continue;
            matched.add(h);
            String type=h.type==null||h.type.trim().isEmpty()?"سایر":h.type.trim();
            if(!groups.containsKey(type))groups.put(type,new ArrayList<>());
            groups.get(type).add(h);
        }
        results.addView(UiKit.muted(this,"نمایش "+matched.size()+" فعالیت"),UiKit.matchWrap(this,0,10));
        if(matched.isEmpty()){
            results.addView(UiKit.emptyState(this,"فعالیتی پیدا نشد","فیلتر زمانی یا عبارت جست‌وجو را تغییر بده."),UiKit.matchWrap(this,5,8));
            return;
        }
        if(!grouped){
            matched.sort((a,b)->Long.compare(b.time,a.time));
            int last=Math.min(visibleLimit,matched.size());
            for(int i=0;i<last;i++){
                NexaStore.HistoryItem h=matched.get(i);
                String label=h.text==null||h.text.trim().isEmpty()?"فعالیت":h.text;
                String category=h.type==null||h.type.trim().isEmpty()?"فعالیت":h.type;
                results.addView(NexaArchiveUi.record(this,label,PersianDateUtil.pretty(h.time),category,UiKit.INDIGO),
                    UiKit.matchWrap(this,0,8));
            }
            if(last<matched.size()){
                int rest=Math.min(60,matched.size()-last);
                Button more=UiKit.secondaryButton(this,"نمایش "+rest+" فعالیت قدیمی‌تر");
                more.setOnClickListener(v->{visibleLimit+=60;render();});
                results.addView(more,UiKit.matchWrap(this,3,12));
            }
            return;
        }
        boolean openInitially=!query.trim().isEmpty()||!scope.equals(HistoryScopePolicy.ALL);
        int index=0;
        for(Map.Entry<String,List<NexaStore.HistoryItem>> group:groups.entrySet()){
            LinearLayout card=UiKit.colorfulCardLayout(this,index++);
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
            boolean open=openInitially||groups.size()==1;
            body.setVisibility(open?View.VISIBLE:View.GONE);
            Button toggle=UiKit.secondaryButton(this,(open?"▾ ":"▸ ")+group.getKey()+"  ·  "+group.getValue().size());
            toggle.setContentDescription("گروه "+group.getKey()+"، "+group.getValue().size()+" فعالیت");
            toggle.setOnClickListener(v->{boolean show=body.getVisibility()!=View.VISIBLE;
                body.setVisibility(show?View.VISIBLE:View.GONE);
                toggle.setText((show?"▾ ":"▸ ")+group.getKey()+"  ·  "+group.getValue().size());});
            card.addView(toggle);
            Map<String,List<NexaStore.HistoryItem>> subjects=new LinkedHashMap<>();
            for(NexaStore.HistoryItem h:group.getValue()){
                String raw=h.text==null?"":h.text;
                String subject=raw.contains(":")?raw.substring(raw.lastIndexOf(':')+1).trim():raw.trim();
                if(subject.isEmpty())subject="سایر";
                if(!subjects.containsKey(subject))subjects.put(subject,new ArrayList<>());
                subjects.get(subject).add(h);
            }
            for(Map.Entry<String,List<NexaStore.HistoryItem>> subject:subjects.entrySet()){
                LinearLayout subjectBody=new LinearLayout(this);subjectBody.setOrientation(LinearLayout.VERTICAL);
                boolean expand=openInitially||subjects.size()==1;
                subjectBody.setVisibility(expand?View.VISIBLE:View.GONE);
                Button subjectHead=UiKit.secondaryButton(this,(expand?"▾ ":"▸ ")+subject.getKey()+" ("+subject.getValue().size()+")");
                subjectHead.setOnClickListener(v->{boolean show=subjectBody.getVisibility()!=View.VISIBLE;
                    subjectBody.setVisibility(show?View.VISIBLE:View.GONE);
                    subjectHead.setText((show?"▾ ":"▸ ")+subject.getKey()+" ("+subject.getValue().size()+")");});
                body.addView(subjectHead,UiKit.matchWrap(this,9,0));
                for(NexaStore.HistoryItem h:subject.getValue()){
                    LinearLayout row=NexaArchiveUi.record(this,h.text==null?"فعالیت":h.text,
                        PersianDateUtil.pretty(h.time),"",UiKit.INDIGO);
                    subjectBody.addView(row,UiKit.matchWrap(this,7,0));
                }
                body.addView(subjectBody);
            }
            card.addView(body);
            results.addView(card,UiKit.matchWrap(this,0,11));
        }
    }
}
