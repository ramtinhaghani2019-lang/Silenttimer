package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Activity history is local-only; no vault secrets are read or displayed. */
public class HistoryActivity extends Activity {
    private LinearLayout results, filters;
    private String query="", scope=HistoryScopePolicy.ALL;
    private List<NexaStore.HistoryItem> all;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){
        all=NexaStore.history(this);
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,16),UiKit.dp(this,18),UiKit.dp(this,32));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
        root.addView(UiKit.title(this,"تاریخچه فعالیت‌ها"),UiKit.matchWrap(this,0,6));
        root.addView(UiKit.muted(this,"مرور سوابق، جستجو و فیلتر زمان؛ اطلاعات خصوصی نمایش داده نمی‌شود."),UiKit.matchWrap(this,0,15));
        long now=System.currentTimeMillis();int day=0,week=0;
        for(NexaStore.HistoryItem h:all){
            if(HistoryScopePolicy.inWindow(HistoryScopePolicy.TODAY,h.time,now))day++;
            if(HistoryScopePolicy.inWindow(HistoryScopePolicy.WEEK,h.time,now))week++;
        }
        root.addView(NexaArchiveUi.metrics(this,
            new String[]{"همه فعالیت‌ها","۷ روز گذشته","۲۴ ساعت گذشته"},
            new String[]{String.valueOf(all.size()),String.valueOf(week),String.valueOf(day)},
            new int[]{UiKit.PURPLE,UiKit.BLUE,UiKit.GREEN}),UiKit.matchWrap(this,0,16));
        EditText search=new EditText(this);search.setSingleLine(true);search.setTextColor(UiKit.TEXT);
        search.setHintTextColor(UiKit.MUTED);search.setHint("⌕ جستجو در تاریخچه");
        search.setBackground(UiKit.field(this));search.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,12));
        search.setText(query);root.addView(search,UiKit.matchWrap(this,0,13));
        filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);
        filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.addView(filters,UiKit.matchWrap(this,0,15));
        results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);
        search.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();render();}
            public void afterTextChanged(Editable e){}
        });
        Button clear=UiKit.secondaryButton(this,"پاک کردن همه سوابق");
        clear.setOnClickListener(v->new AlertDialog.Builder(this)
            .setTitle("پاک کردن همه سوابق؟")
            .setMessage("این کار برگشت‌پذیر نیست و فقط گزارش فعالیت را حذف می‌کند.")
            .setPositiveButton("پاک کردن",(d,w)->{NexaStore.clearHistory(this);query="";scope=HistoryScopePolicy.ALL;build();})
            .setNegativeButton("انصراف",null).show());
        root.addView(clear,UiKit.matchWrap(this,20,0));
        setContentView(sc);refreshFilters();render();
    }
    private void refreshFilters(){
        filters.removeAllViews();
        String[] values={HistoryScopePolicy.ALL,HistoryScopePolicy.WEEK,HistoryScopePolicy.TODAY};
        String[] labels={"همه","۷ روز","۲۴ ساعت"};
        for(int i=0;i<values.length;i++){
            final String selected=values[i];
            TextView chip=NexaArchiveUi.chip(this,labels[i],scope.equals(selected));
            chip.setOnClickListener(v->{scope=selected;refreshFilters();render();});
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1f);
            if(i>0)p.setMargins(UiKit.dp(this,5),0,0,0);
            filters.addView(chip,p);
        }
    }
    private void render(){
        if(results==null)return;
        results.removeAllViews();
        Map<String,List<NexaStore.HistoryItem>> groups=new LinkedHashMap<>();
        long now=System.currentTimeMillis();int shown=0;
        for(NexaStore.HistoryItem h:all){
            if(!HistoryScopePolicy.matches(scope,h.time,now,h.type,h.text,query))continue;
            String type=h.type==null||h.type.trim().isEmpty()?"سایر":h.type.trim();
            if(!groups.containsKey(type))groups.put(type,new ArrayList<>());
            groups.get(type).add(h);shown++;
        }
        results.addView(UiKit.muted(this,"نمایش "+shown+" فعالیت"),UiKit.matchWrap(this,0,10));
        if(groups.isEmpty()){
            results.addView(UiKit.emptyState(this,"فعالیتی پیدا نشد","فیلتر زمانی یا عبارت جستجو را تغییر بده."),UiKit.matchWrap(this,5,8));
            return;
        }
        boolean openInitially=!query.trim().isEmpty()||!scope.equals(HistoryScopePolicy.ALL);
        int index=0;
        for(Map.Entry<String,List<NexaStore.HistoryItem>> group:groups.entrySet()){
            LinearLayout card=UiKit.colorfulCardLayout(this,index++);
            LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);
            boolean open=openInitially||groups.size()==1;
            body.setVisibility(open?View.VISIBLE:View.GONE);
            Button toggle=UiKit.secondaryButton(this,(open?"▾ ":"▸ ")+group.getKey()+"  ·  "+group.getValue().size());
            toggle.setContentDescription("گروه "+group.getKey()+"، "+group.getValue().size()+" فعالیت");
            toggle.setOnClickListener(v->{boolean show=body.getVisibility()!=View.VISIBLE;
                body.setVisibility(show?View.VISIBLE:View.GONE);
                toggle.setText((show?"▾ ":"▸ ")+group.getKey()+"  ·  "+group.getValue().size());});
            card.addView(toggle);
            Map<String,List<NexaStore.HistoryItem>> subjects=new LinkedHashMap<>();
            for(NexaStore.HistoryItem h:group.getValue()){
                String raw=h.text==null?"":h.text;
                String subject=raw.contains(":")?raw.substring(raw.lastIndexOf(':')+1).trim():raw.trim();
                if(subject.isEmpty())subject="سایر";
                if(!subjects.containsKey(subject))subjects.put(subject,new ArrayList<>());
                subjects.get(subject).add(h);
            }
            for(Map.Entry<String,List<NexaStore.HistoryItem>> subject:subjects.entrySet()){
                LinearLayout subjectBody=new LinearLayout(this);subjectBody.setOrientation(LinearLayout.VERTICAL);
                boolean expand=openInitially||subjects.size()==1;
                subjectBody.setVisibility(expand?View.VISIBLE:View.GONE);
                Button subjectHead=UiKit.secondaryButton(this,(expand?"▾ ":"▸ ")+subject.getKey()+" ("+subject.getValue().size()+")");
                subjectHead.setOnClickListener(v->{boolean show=subjectBody.getVisibility()!=View.VISIBLE;
                    subjectBody.setVisibility(show?View.VISIBLE:View.GONE);
                    subjectHead.setText((show?"▾ ":"▸ ")+subject.getKey()+" ("+subject.getValue().size()+")");});
                body.addView(subjectHead,UiKit.matchWrap(this,9,0));
                for(NexaStore.HistoryItem h:subject.getValue()){
                    LinearLayout row=NexaArchiveUi.record(this,h.text==null?"فعالیت":h.text,
                        PersianDateUtil.pretty(h.time),"",UiKit.INDIGO);
                    subjectBody.addView(row,UiKit.matchWrap(this,7,0));
                }
                body.addView(subjectBody);
            }
            card.addView(body);
            results.addView(card,UiKit.matchWrap(this,0,11));
        }
    }
}
