package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class SilentHubActivity extends Activity {
    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"سایلنت و تمرکز"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"🔕 مرکز کنترل سکوت، تماس‌های مهم و خروج اضطراری از Silent"),UiKit.matchWrap(this,0,14));

        TextView smart=UiKit.navCard(this,"◷","سایلنت هوشمند","تایمر، Silent/Vibrate و خروج در ساعت مشخص");
        smart.setOnClickListener(v->startActivity(new Intent(this,SmartSilentActivity.class)));
        root.addView(smart,UiKit.matchWrap(this,0,10));

        TextView calls=UiKit.navCard(this,"☎","تماس‌های مجاز","شماره‌های مجاز که در Silent با صدا زنگ می‌خورند");
        calls.setOnClickListener(v->startActivity(new Intent(this,AllowedCallsActivity.class)));
        root.addView(calls,UiKit.matchWrap(this,0,10));

        LinearLayout sms=UiKit.colorfulCardLayout(this,2);
        sms.addView(UiKit.sectionTitle(this,"📩 کد اضطراری پیامکی"));
        String state=NexaStore.smsEnabled(this)?"فعال":"خاموش";
        sms.addView(UiKit.muted(this,"وضعیت: "+state+" • تنظیم شماره و کد محرمانه از Settings"),UiKit.matchWrap(this,6,10));
        Button openSettings=UiKit.secondaryButton(this,"تنظیم کد اضطراری");
        openSettings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        sms.addView(openSettings);
        root.addView(sms,UiKit.matchWrap(this,0,10));

        TextView focus=UiKit.navCard(this,"🎯","تمرکز","جلسه، خواب، مطالعه، کار و برنامه هفتگی");
        focus.setOnClickListener(v->startActivity(new Intent(this,ProfilesActivity.class)));
        root.addView(focus);

        setContentView(sc);
    }
}
