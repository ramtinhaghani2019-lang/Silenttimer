package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class SilentHubActivity extends Activity {
    private LinearLayout overview;
    private android.widget.TextView smsState;
    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.header(this,"سایلنت و تمرکز",v->finish()),UiKit.matchWrap(this,0,6));
        root.addView(UiKit.muted(this,"🔕 مرکز مدیریت سکوت، تمرکز و تماس‌های ضروری"),UiKit.matchWrap(this,0,14));
        overview=new LinearLayout(this);overview.setOrientation(LinearLayout.VERTICAL);
        root.addView(overview,UiKit.matchWrap(this,0,16));
        root.addView(NexaFocusUi.section(this,"دسترسی سریع"),UiKit.matchWrap(this,0,9));
        TextView smart=UiKit.navCard(this,"◷","سایلنت هوشمند","تایمر، Silent/Vibrate و خروج در ساعت مشخص");
        smart.setOnClickListener(v->startActivity(new Intent(this,SmartSilentActivity.class)));
        root.addView(smart,UiKit.matchWrap(this,0,10));
        TextView focus=UiKit.navCard(this,"🎯","پروفایل‌های تمرکز","جلسه، خواب، مطالعه و برنامه هفتگی");
        focus.setOnClickListener(v->startActivity(new Intent(this,ProfilesActivity.class)));
        root.addView(focus,UiKit.matchWrap(this,0,10));
        TextView calls=UiKit.navCard(this,"☎","تماس‌های مجاز","تماس‌های مهم در هنگام سکوت");
        calls.setOnClickListener(v->startActivity(new Intent(this,AllowedCallsActivity.class)));
        root.addView(calls,UiKit.matchWrap(this,0,15));
        LinearLayout sms=UiKit.colorfulCardLayout(this,2);
        sms.addView(NexaFocusUi.section(this,"📩 خروج اضطراری با پیامک"));
        smsState=UiKit.muted(this,"");sms.addView(smsState,UiKit.matchWrap(this,3,10));
        Button openSettings=UiKit.secondaryButton(this,"تنظیم کد اضطراری");
        openSettings.setOnClickListener(v->startActivity(new Intent(this,SettingsActivity.class)));
        sms.addView(openSettings);root.addView(sms,UiKit.matchWrap(this,0,8));
        setContentView(sc);refreshOverview();
    }

    @Override protected void onResume(){super.onResume();refreshOverview();}
    private void refreshOverview(){
        if(overview==null)return;
        java.util.List<NexaStore.WeeklySchedule> all=NexaStore.schedules(this);
        int active=0;for(NexaStore.WeeklySchedule s:all)if(s.enabled)active++;
        overview.removeAllViews();
        overview.addView(NexaFocusUi.metrics(this,NexaStore.profiles(this).size(),active,all.size()));
        if(smsState!=null)smsState.setText("وضعیت: "+(NexaStore.smsEnabled(this)?"فعال":"خاموش")+" • شماره و کد محرمانه در تنظیمات امنیتی");
    }
}
