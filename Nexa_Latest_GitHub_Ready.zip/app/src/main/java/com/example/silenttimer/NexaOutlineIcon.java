package com.example.silenttimer;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

/** Accessible, asset-free outline pictograms with one consistent stroke.
 * Build 223: replaces arbitrary fallback glyphs in the module directory and shared nav.
 */
public final class NexaOutlineIcon extends View {
    private final String kind;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int tint;

    public NexaOutlineIcon(Context context, String kind, int tint) {
        super(context);
        this.kind = kind == null ? "" : kind;
        this.tint = tint;
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
    }
    private void line(Canvas c,float a,float b,float x,float y){c.drawLine(a,b,x,y,p);}
    private void path(Canvas c,float... xy){
        Path path=new Path();path.moveTo(xy[0],xy[1]);
        for(int i=2;i<xy.length;i+=2)path.lineTo(xy[i],xy[i+1]);
        c.drawPath(path,p);
    }
    private void rect(Canvas c,float l,float t,float r,float b,float radius){c.drawRoundRect(new RectF(l,t,r,b),radius,radius,p);}
    private void circle(Canvas c,float x,float y,float radius){c.drawCircle(x,y,radius,p);}
    @Override protected void onDraw(Canvas original){
        super.onDraw(original);
        float scale=Math.min(getWidth(),getHeight())/24f;
        if(scale<=0)return;
        original.save();original.translate((getWidth()-24*scale)/2f,(getHeight()-24*scale)/2f);original.scale(scale,scale);
        Canvas c=original;
        p.setColor(tint);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.85f);
        p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);p.setShader(null);
        switch(kind){
            case "usd":
            case "eur":
                circle(c,12,12,10);p.setStyle(Paint.Style.FILL);p.setStrokeWidth(1f);
                p.setTextSize(15);p.setTextAlign(Paint.Align.CENTER);
                c.drawText("usd".equals(kind)?"$":"€",12,17,p);
                p.setStyle(Paint.Style.STROKE);break;
            case "gold":
                path(c,4,17,7,8,17,8,20,17,4,17);
                line(c,7,8,10,4);line(c,17,8,14,4);line(c,10,4,14,4);
                line(c,10,12,14,12);break;
            case "silver":
                path(c,3,17,6,10,12,10,15,17,3,17);
                path(c,10,10,13,5,19,5,22,12,15,12);
                line(c,8,13,11,13);line(c,17,8,19,8);break;
            case "copper":
                rect(c,4,7,20,17,2);line(c,7,9,17,9);line(c,7,15,17,15);
                path(c,8,3,16,3,18,7);break;
            case "stocks":
                line(c,3,21,21,21);line(c,3,21,3,4);
                path(c,5,17,10,13,14,15,20,6);path(c,15,6,20,6,20,11);break;
            case "coin":
                circle(c,12,12,9);circle(c,12,12,6);
                path(c,10,10,12,8,14,10,14,14,12,16,10,14,10,10);break;
            case "ounce":
                circle(c,12,12,9);line(c,3,12,21,12);
                path(c,12,3,8,8,8,16,12,21,16,16,16,8,12,3);
                path(c,5,7,19,7);path(c,5,17,19,17);break;
            case "assets":
                line(c,3,19,21,19);line(c,4,19,4,5);path(c,6,15,10,11,13,13,19,6);path(c,15,6,19,6,19,10);break;
            case "ledger":
                rect(c,3,5,21,19,3);line(c,3,9,21,9);line(c,6,14,12,14);circle(c,17,14,1.5f);break;
            case "bills":
                path(c,6,3,18,3,18,21,15,19,12,21,9,19,6,21,6,3);
                line(c,9,8,15,8);line(c,9,12,15,12);line(c,9,16,13,16);break;
            case "docs":
                path(c,6,3,14,3,19,8,19,21,6,21,6,3);path(c,14,3,14,8,19,8);line(c,9,13,16,13);line(c,9,17,15,17);break;
            case "shared":
                circle(c,9,8,3);path(c,3,19,3,17,5,14,9,13,13,14,15,17,15,19);circle(c,18,9,2);path(c,16,14,19,14,21,16,21,19);break;
            case "voice":
                rect(c,9,3,15,15,3);path(c,6,11,6,14,8,17,12,18,16,17,18,14,18,11);
                line(c,12,18,12,22);line(c,8,22,16,22);break;
            case "medicine":
                rect(c,4,4,20,20,4);line(c,12,8,12,16);line(c,8,12,16,12);break;
            case "vehicle":
                path(c,3,14,5,9,7,7,17,7,19,9,21,14,21,18,3,18,3,14);
                line(c,4,14,20,14);circle(c,7,18,2);circle(c,17,18,2);break;
            case "home":
                path(c,3,11,12,4,21,11);path(c,5,10,5,21,19,21,19,10);path(c,10,21,10,15,14,15,14,21);break;
            case "case":
                line(c,12,4,12,19);line(c,6,7,18,7);path(c,5,8,2,14,8,14,5,8);path(c,19,8,16,14,22,14,19,8);line(c,7,20,17,20);break;
            case "weather":
                circle(c,7,8,3);path(c,8,18,5,18,4,15,5,12,8,11,10,12,12,9,16,9,19,12,20,15,18,18,8,18);break;
            case "reminders":
                path(c,5,17,7,15,7,10,8,7,10,5,14,5,16,7,17,10,17,15,19,17,5,17);
                path(c,10,20,12,21,14,20);break;
            case "occasions":
                rect(c,4,10,20,21,2);rect(c,3,7,21,11,1);line(c,12,7,12,21);
                path(c,12,7,9,7,6,5,8,3,12,7,16,3,18,5,15,7,12,7);break;
            case "silent":
                path(c,17,3,11,5,8,10,10,15,15,17,20,16,17,20,10,21,5,17,3,11,6,6,11,3,17,3);break;
            case "battery":
                rect(c,3,7,19,17,2);line(c,21,10,21,14);path(c,11,8,8,13,12,13,10,16,15,11,11,11,11,8);break;
            case "emergency":
                path(c,12,3,22,20,2,20,12,3);line(c,12,9,12,14);circle(c,12,17,0.7f);break;
            case "vault":
                rect(c,5,10,19,21,2);path(c,8,10,8,7,9,4,12,3,15,4,16,7,16,10);circle(c,12,15,1.5f);break;
            case "files":
                path(c,3,7,3,20,21,20,21,8,12,8,10,5,3,5,3,7);line(c,3,10,21,10);break;
            case "scan":
                path(c,4,9,4,4,9,4);path(c,15,4,20,4,20,9);
                path(c,4,15,4,20,9,20);path(c,15,20,20,20,20,15);
                line(c,6,12,18,12);break;
            case "search":
                circle(c,10,10,6);line(c,14.5f,14.5f,21,21);break;
            case "timeline":
                rect(c,3,5,21,21,2);line(c,3,10,21,10);line(c,8,3,8,7);line(c,16,3,16,7);circle(c,8,15,1);circle(c,13,15,1);break;
            case "modules":
                rect(c,3,3,10,10,1.5f);rect(c,14,3,21,10,1.5f);
                rect(c,3,14,10,21,1.5f);rect(c,14,14,21,21,1.5f);break;
            case "history":
                path(c,5,7,3,11,7,11);path(c,3,11,4,7,8,4,12,3,17,5,20,9,21,13,19,18,15,21,10,21,6,19);
                line(c,12,8,12,13);line(c,12,13,16,15);break;
            case "settings":
                circle(c,12,12,3);circle(c,12,12,8);
                for(int i=0;i<8;i++){double a=i*Math.PI/4;float x=(float)Math.cos(a),y=(float)Math.sin(a);line(c,12+8*x,12+8*y,12+10*x,12+10*y);}break;
            case "lists":
                path(c,4,7,6,9,9,5);line(c,12,7,20,7);path(c,4,15,6,17,9,13);line(c,12,15,20,15);break;
            case "today":
                circle(c,12,12,8);line(c,12,7,12,12);line(c,12,12,16,14);break;
            case "quick":
                line(c,12,4,12,20);line(c,4,12,20,12);break;
            default:
                rect(c,4,4,20,20,3);circle(c,12,12,3);break;
        }
        original.restore();
    }
}
