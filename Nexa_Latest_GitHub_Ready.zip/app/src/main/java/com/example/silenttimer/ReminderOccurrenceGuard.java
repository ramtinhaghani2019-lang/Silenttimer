package com.example.silenttimer;

/**
 * Guards reminder notifications and alarm deliveries against an earlier edit or
 * recurrence. A token identifies exactly one occurrence (id + rule + due time).
 * Pure Java so a stale-alarm regression can be tested without an emulator.
 */
public final class ReminderOccurrenceGuard {
    private ReminderOccurrenceGuard() {}

    public static boolean isCurrent(String reminderId, long dueAtMillis,
                                    String offsetRules, boolean active,
                                    boolean done, String token) {
        if (!active || done || reminderId == null || reminderId.isEmpty()
                || dueAtMillis <= 0L || token == null || token.isEmpty()) return false;
        for (String rule : AlertRules.split(offsetRules)) {
            if (token.equals(reminderId + ":" + rule + ":" + dueAtMillis)) return true;
        }
        return false;
    }
}
