package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i){
        String token=i.getStringExtra("token");
        if(token==null)return;
        NexaAudioController.stopOwner("reminder:"+token);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.cancel(token.hashCode());
        String action=i.getAction();
        String id=i.getStringExtra("id");
        if("DISMISS".equals(action)){
            NexaStore.dismissToken(c,token);
            NexaStore.addHistory(c,"یادآور","هشدار خاموش شد");
        }else if("SNOOZE".equals(action)){
            int repeat=i.getIntExtra("repeat",5);
            if(id!=null) ReminderScheduler.scheduleToken(c,id,token,System.currentTimeMillis()+repeat*60_000L,repeat);
        }else if("DONE".equals(action)){
            NexaStore.dismissToken(c,token);
            NexaStore.Reminder r=id==null?null:NexaStore.reminder(c,id);
            if(r!=null){
                ReminderScheduler.cancelReminder(c,r);
                if(ReminderRecurrence.advanceAfterDone(r,System.currentTimeMillis())){
                    NexaStore.updateReminder(c,r);
                    ReminderScheduler.scheduleReminder(c,r);
                    NexaStore.addHistory(c,"یادآور","انجام شد؛ نوبت بعد تنظیم شد: "+r.title);
                }else{
                    r.done=true;r.active=false;
                    NexaStore.updateReminder(c,r);
                    NexaStore.addHistory(c,"یادآور","انجام شد: "+r.title);
                }
                ReminderScheduler.updateLockCard(c);
                TodayNotificationManager.refresh(c);
            }
        }
    }
}
