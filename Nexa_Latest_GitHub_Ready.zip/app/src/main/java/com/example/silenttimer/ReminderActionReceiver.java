package com.example.silenttimer;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ReminderActionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i){
        if (i == null) return;
        String token=i.getStringExtra("token");
        if(token==null || token.isEmpty())return;
        String action=i.getAction();
        if (!isSupportedAction(action)) return;
        // Ignore stale notification actions; DONE must never advance twice.
        if (NexaStore.tokenDismissed(c,token)) return;
        NexaAudioController.stopOwner("reminder:"+token);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null) nm.cancel(token.hashCode());
        String id=i.getStringExtra("id");
        // A notification from before an edit/recurrence may still be visible.
        // Allow dismissing it, but forbid snooze and DONE from changing the
        // replacement occurrence of this reminder.
        if (!"DISMISS".equals(action)) {
            NexaStore.Reminder current = id == null ? null : NexaStore.reminder(c, id);
            if (!ReminderScheduler.isCurrentOccurrence(current, token)) {
                ReminderScheduler.cancelToken(c, token);
                NexaStore.dismissToken(c, token);
                return;
            }
        }
        if("DISMISS".equals(action)){
            ReminderScheduler.cancelToken(c, token);
            NexaStore.dismissToken(c,token);
            NexaStore.addHistory(c,"یادآور","هشدار خاموش شد");
        }else if("SNOOZE".equals(action)){
            int repeat=i.getIntExtra("repeat",5);
            // Snooze must never schedule an immediate loop for one-shot reminders.
            // Replace any outstanding call-audio retry before scheduling snooze.
            int snoozeMinutes = safeSnoozeMinutes(repeat);
            ReminderScheduler.cancelToken(c, token);
            if(id!=null && !NexaStore.tokenDismissed(c, token)) {
                NexaStore.Reminder r = NexaStore.reminder(c, id);
                if(r!=null && r.active && !r.done)
                    ReminderScheduler.scheduleToken(c,id,token,
                            System.currentTimeMillis()+snoozeMinutes*60_000L,repeat);
            }
        }else if("DONE".equals(action)){
            ReminderScheduler.cancelToken(c, token);
            NexaStore.dismissToken(c,token);
            NexaStore.Reminder r=id==null?null:NexaStore.reminder(c,id);
            if(r!=null){
                ReminderScheduler.cancelReminder(c,r);
                ReminderRecurrence.recordCompleted(r);
                if(ReminderRecurrence.advanceAfterDone(r,System.currentTimeMillis())){
                    NexaStore.updateReminder(c,r);
                    LinkedReminderHelper.syncNextOccurrence(c,r);
                    ReminderScheduler.scheduleReminder(c,r);
                    NexaStore.addHistory(c,"یادآور","انجام شد؛ نوبت بعد تنظیم شد: "+r.title);
                }else{
                    r.done=true;r.active=false;
                    NexaStore.updateReminder(c,r);
                    NexaStore.addHistory(c,"یادآور","انجام شد: "+r.title);
                }
                ReminderScheduler.updateLockCard(c);
                TodayNotificationManager.refresh(c);
            }
        }
    }
    public static boolean isSupportedAction(String action) {
        return "DISMISS".equals(action) || "SNOOZE".equals(action) || "DONE".equals(action);
    }
    /** One-shot reminders use a five-minute snooze; recurring reminders retain their interval. */
    public static int safeSnoozeMinutes(int repeatMinutes) {
        return repeatMinutes > 0 ? repeatMinutes : 5;
    }
}
