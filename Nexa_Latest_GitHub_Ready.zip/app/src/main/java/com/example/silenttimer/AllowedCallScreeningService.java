package com.example.silenttimer;

import android.media.AudioManager;
import android.os.Build;
import android.telecom.Call;
import android.telecom.CallScreeningService;

public class AllowedCallScreeningService extends CallScreeningService {
    @Override
    public void onScreenCall(Call.Details callDetails) {
        String number = "";

        if (callDetails.getHandle() != null) {
            number = callDetails.getHandle().getSchemeSpecificPart();
        }

        boolean incomingForGuard = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                && callDetails.getCallDirection() == Call.Details.DIRECTION_INCOMING;

        if (incomingForGuard) {
            // Record the incoming call early so PHONE_STATE can classify an
            // unanswered RINGING -> IDLE transition as a missed call.
            MissedCallGuard.noteIncoming(this, number);
        }

        // Preserve the existing pre-Android-10 allowed-call behavior. On Android 10+
        // the call direction is explicit, so outgoing calls never trigger a bypass.
        boolean eligibleAllowedCall = Build.VERSION.SDK_INT < Build.VERSION_CODES.Q || incomingForGuard;
        if (eligibleAllowedCall && AppPrefs.isAllowedNumber(this, number)) {
            int currentMode = NexaAudioController.getRingerMode(this);
            int restoreMode = AppPrefs.isTimerActive(this)
                    ? AppPrefs.getTargetRingerMode(this)
                    : currentMode;

            if (restoreMode == AudioManager.RINGER_MODE_SILENT ||
                    restoreMode == AudioManager.RINGER_MODE_VIBRATE) {
                int capturedMode = NexaAudioController.beginTemporaryOverride(
                        this, AudioManager.RINGER_MODE_NORMAL);
                if (capturedMode >= 0) {
                    // During an active timer, restore the timer target even if the
                    // platform briefly reported another mode at call-screen time.
                    int exactRestore = AppPrefs.isTimerActive(this) ? restoreMode : capturedMode;
                    AppPrefs.setBypassRestoreMode(this, exactRestore);
                    AppPrefs.setBypassActive(this, true);
                    AppPrefs.setIgnoreManualUntil(
                            this,
                            System.currentTimeMillis() + 5000L
                    );
                }
            }
        }

        respondToCall(
                callDetails,
                new CallResponse.Builder().build()
        );
    }
}
