package com.example.silenttimer;

import android.media.AudioManager;
import android.telecom.Call;
import android.telecom.CallScreeningService;

public class AllowedCallScreeningService extends CallScreeningService {
    @Override
    public void onScreenCall(Call.Details callDetails) {
        String number = "";

        if (callDetails.getHandle() != null) {
            number = callDetails.getHandle().getSchemeSpecificPart();
        }

        if (AppPrefs.isAllowedNumber(this, number)) {
            int currentMode = NexaAudioController.getRingerMode(this);
            int restoreMode = AppPrefs.isTimerActive(this)
                    ? AppPrefs.getTargetRingerMode(this)
                    : currentMode;

            if (restoreMode == AudioManager.RINGER_MODE_SILENT ||
                    restoreMode == AudioManager.RINGER_MODE_VIBRATE) {
                int capturedMode = NexaAudioController.beginTemporaryOverride(
                        this, AudioManager.RINGER_MODE_NORMAL);
                if (capturedMode >= 0) {
                    // During an active timer, restore the timer target even if the
                    // platform briefly reported another mode at call-screen time.
                    int exactRestore = AppPrefs.isTimerActive(this) ? restoreMode : capturedMode;
                    AppPrefs.setBypassRestoreMode(this, exactRestore);
                    AppPrefs.setBypassActive(this, true);
                    AppPrefs.setIgnoreManualUntil(
                            this,
                            System.currentTimeMillis() + 5000L
                    );
                }
            }
        }

        respondToCall(
                callDetails,
                new CallResponse.Builder().build()
        );
    }
}
