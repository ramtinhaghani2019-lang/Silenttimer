package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

/** Keeps charger/theft state current independently of the Silent Timer foreground monitor. */
public class PowerConnectionReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (context == null) return;
        // A disconnect broadcast is immediate. The sticky battery intent can lag behind it.
        // Never suppress the independent unplug/theft alarm.
        if(intent!=null && Intent.ACTION_POWER_DISCONNECTED.equals(intent.getAction()))
            BatteryAlertManager.onChargerDisconnected(context);
        BackgroundReliability.run(context, "power-connection", () -> {
            Intent sticky = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (sticky != null) BatteryAlertManager.onBatteryChanged(context, sticky);
        });
    }
}
