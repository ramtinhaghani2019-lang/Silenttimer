package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class NexaStore {
    private static final String PREF = "nexa_store";
    private NexaStore() {}

    private static SharedPreferences p(Context c) {
        return c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public static final class Reminder {
        public String id = UUID.randomUUID().toString();
        public String title = "";
        public String category = "قرار";
        public String icon = "📅";
        public String note = "";
        public String sourceKey = "";
        public String doctorName = "";
        public String doctorFileNumber = "";
        public String doctorCenter = "";
        public String doctorPhone = "";
        public String doctorAddress = "";
        public long whenMillis;
        public String offsetsMinutes = "0";
        public int repeatMinutes = 5;
        public boolean done = false;
        public boolean active = true;
        public String recurrence = "none"; // none,daily,weekly,biweekly,monthly

        JSONObject json() throws Exception {
            JSONObject o = new JSONObject();
            o.put("id", id); o.put("title", title); o.put("category", category); o.put("icon", icon);
            o.put("note", note); o.put("sourceKey", sourceKey);
            o.put("doctorName", doctorName); o.put("doctorFileNumber", doctorFileNumber);
            o.put("doctorCenter", doctorCenter); o.put("doctorPhone", doctorPhone); o.put("doctorAddress", doctorAddress);
            o.put("when", whenMillis); o.put("offsets", offsetsMinutes);
            o.put("repeat", repeatMinutes);o.put("done", done); o.put("active", active); o.put("recurrence", recurrence); return o;
        }
        static Reminder from(JSONObject o) {
            Reminder r = new Reminder();
            r.id=o.optString("id",r.id); r.title=o.optString("title",""); r.category=o.optString("category","قرار");
            r.icon=o.optString("icon","📅"); r.note=o.optString("note","");
            r.sourceKey=o.optString("sourceKey","");
            r.doctorName=o.optString("doctorName",""); r.doctorFileNumber=o.optString("doctorFileNumber","");
            r.doctorCenter=o.optString("doctorCenter",""); r.doctorPhone=o.optString("doctorPhone","");
            r.doctorAddress=o.optString("doctorAddress","");
            r.whenMillis=o.optLong("when",0);
            r.offsetsMinutes=o.optString("offsets","0"); r.repeatMinutes=o.optInt("repeat",5);
            r.done=o.optBoolean("done",false); r.active=o.optBoolean("active",true); r.recurrence=o.optString("recurrence","none"); return r;
        }
    }

    public static final class Medicine {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public String dose = "";
        public int intervalHours = 8;
        public long nextDoseMillis;
        public long endMillis;
        public int repeatMinutes = 5;
        public boolean active = true;
        public String doctor="";
        public long prescriptionDate=0;
        public long firstDoseMillis=0;
        public boolean intervalFromActual=true;
        JSONObject json() throws Exception {
            JSONObject o=new JSONObject();
            o.put("doctor",doctor);o.put("prescriptionDate",prescriptionDate);
            o.put("id",id);o.put("name",name);o.put("dose",dose);o.put("interval",intervalHours);
            o.put("next",nextDoseMillis);o.put("end",endMillis);o.put("repeat",repeatMinutes);o.put("active",active);
            o.put("firstDose",firstDoseMillis);o.put("intervalFromActual",intervalFromActual);
            return o;
        }
        static Medicine from(JSONObject o){
            Medicine m=new Medicine();m.id=o.optString("id",m.id);m.name=o.optString("name","");
            m.dose=o.optString("dose","");m.intervalHours=o.optInt("interval",8);m.nextDoseMillis=o.optLong("next",0);
            m.endMillis=o.optLong("end",0);m.repeatMinutes=o.optInt("repeat",5);m.active=o.optBoolean("active",true);
            m.doctor=o.optString("doctor","");m.prescriptionDate=o.optLong("prescriptionDate",0);
            m.firstDoseMillis=o.optLong("firstDose",0);m.intervalFromActual=o.optBoolean("intervalFromActual",true);
            return m;
        }
    }

    public static final class MedicineDoseLog {
        public String id=UUID.randomUUID().toString();
        public String medicineId="";
        public long scheduledAt=0;
        public long takenAt=0;
        public String status="taken"; // taken_on_time, taken_now, skipped
        JSONObject json() throws Exception {
            JSONObject o=new JSONObject();o.put("id",id);o.put("medicineId",medicineId);
            o.put("scheduledAt",scheduledAt);o.put("takenAt",takenAt);o.put("status",status);return o;
        }
        static MedicineDoseLog from(JSONObject o){
            MedicineDoseLog x=new MedicineDoseLog();x.id=o.optString("id",x.id);x.medicineId=o.optString("medicineId","");
            x.scheduledAt=o.optLong("scheduledAt",0);x.takenAt=o.optLong("takenAt",0);x.status=o.optString("status","taken");return x;
        }
    }


    public static final class Doctor {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public String specialty = "";
        public String fileNumber = "";
        public String center = "";
        public String phone = "";
        public String address = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("specialty",specialty);o.put("file",fileNumber);o.put("center",center);o.put("phone",phone);o.put("address",address);return o;}
        static Doctor from(JSONObject o){Doctor d=new Doctor();d.id=o.optString("id",d.id);d.name=o.optString("name","");d.specialty=o.optString("specialty","");d.fileNumber=o.optString("file","");d.center=o.optString("center","");d.phone=o.optString("phone","");d.address=o.optString("address","");return d;}
    }

    public static final class LedgerParty {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public String phone = "";
        public String note = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("phone",phone);o.put("note",note);return o;}
        static LedgerParty from(JSONObject o){LedgerParty x=new LedgerParty();x.id=o.optString("id",x.id);x.name=o.optString("name","");x.phone=o.optString("phone","");x.note=o.optString("note","");return x;}
    }

    public static final class LedgerEntry {
        public String id = UUID.randomUUID().toString();
        public String partyId = "";
        public long dateMillis = System.currentTimeMillis();
        public long amount = 0;
        public String kind = "DEBT"; // DEBT: I owe, CREDIT: they owe me, PAYMENT: I paid, RECEIPT: I received
        public String note = "";
        public long dueMillis = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("party",partyId);o.put("date",dateMillis);o.put("amount",amount);o.put("kind",kind);o.put("note",note);o.put("due",dueMillis);return o;}
        static LedgerEntry from(JSONObject o){LedgerEntry x=new LedgerEntry();x.id=o.optString("id",x.id);x.partyId=o.optString("party","");x.dateMillis=o.optLong("date",System.currentTimeMillis());x.amount=Math.max(0,o.optLong("amount",0));x.kind=o.optString("kind","DEBT");x.note=o.optString("note","");x.dueMillis=o.optLong("due",0);return x;}
    }

    public static final class Vehicle {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public String type = "خودرو";
        public int currentKm = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("type",type);o.put("km",currentKm);return o;}
        static Vehicle from(JSONObject o){Vehicle v=new Vehicle();v.id=o.optString("id",v.id);v.name=o.optString("name","");v.type=o.optString("type","خودرو");v.currentKm=o.optInt("km",0);return v;}
    }

    public static final class ServiceRecord {
        public String id = UUID.randomUUID().toString();
        public String vehicleId = "";
        public String category = "سرویس دوره‌ای";
        public String icon = "🔧";
        public long dateMillis = System.currentTimeMillis();
        public int km = 0;
        public String note = "";
        public String sellerId = "";
        public long cost = 0;
        public int nextDueKm = 0;
        public long nextDueDate = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("vehicle",vehicleId);o.put("category",category);o.put("icon",icon);o.put("date",dateMillis);o.put("km",km);o.put("note",note);o.put("sellerId",sellerId);o.put("cost",cost);o.put("nextKm",nextDueKm);o.put("nextDate",nextDueDate);return o;}
        static ServiceRecord from(JSONObject o){ServiceRecord r=new ServiceRecord();r.id=o.optString("id",r.id);r.vehicleId=o.optString("vehicle","");r.category=o.optString("category","سرویس دوره‌ای");r.icon=o.optString("icon","🔧");r.dateMillis=o.optLong("date",0);r.km=o.optInt("km",0);r.note=o.optString("note","");r.sellerId=o.optString("sellerId","");r.cost=o.optLong("cost",0);r.nextDueKm=o.optInt("nextKm",0);r.nextDueDate=o.optLong("nextDate",0);return r;}
    }

    public static final class FuelRecord {
        public String id = UUID.randomUUID().toString();
        public String vehicleId = "";
        public long dateMillis = System.currentTimeMillis();
        public int km = 0;
        public double liters = 0;
        public long cost = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("vehicle",vehicleId);o.put("date",dateMillis);o.put("km",km);o.put("liters",liters);o.put("cost",cost);return o;}
        static FuelRecord from(JSONObject o){FuelRecord f=new FuelRecord();f.id=o.optString("id",f.id);f.vehicleId=o.optString("vehicle","");f.dateMillis=o.optLong("date",0);f.km=o.optInt("km",0);f.liters=o.optDouble("liters",0);f.cost=o.optLong("cost",0);return f;}
    }

    public static final class Profile {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public int minutes = 60;
        public int mode = 0;
        public boolean allowedCalls = true;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("minutes",minutes);o.put("mode",mode);o.put("allowed",allowedCalls);return o;}
        static Profile from(JSONObject o){Profile x=new Profile();x.id=o.optString("id",x.id);x.name=o.optString("name","");x.minutes=o.optInt("minutes",60);x.mode=o.optInt("mode",0);x.allowedCalls=o.optBoolean("allowed",true);return x;}
    }

    public static final class WeeklySchedule {
        public String id = UUID.randomUUID().toString();
        public String name = "";
        public int daysMask = 62; // Mon-Fri Calendar bit mapping below
        public int startHour = 9, startMinute = 0;
        public int endHour = 17, endMinute = 0;
        public int mode = 0;
        public boolean enabled = true;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("days",daysMask);o.put("sh",startHour);o.put("sm",startMinute);o.put("eh",endHour);o.put("em",endMinute);o.put("mode",mode);o.put("enabled",enabled);return o;}
        static WeeklySchedule from(JSONObject o){WeeklySchedule s=new WeeklySchedule();s.id=o.optString("id",s.id);s.name=o.optString("name","");s.daysMask=o.optInt("days",62);s.startHour=o.optInt("sh",9);s.startMinute=o.optInt("sm",0);s.endHour=o.optInt("eh",17);s.endMinute=o.optInt("em",0);s.mode=o.optInt("mode",0);s.enabled=o.optBoolean("enabled",true);return s;}
    }

    public static final class HistoryItem {
        public long time = System.currentTimeMillis();
        public String type = "";
        public String text = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("time",time);o.put("type",type);o.put("text",text);return o;}
        static HistoryItem from(JSONObject o){HistoryItem h=new HistoryItem();h.time=o.optLong("time",0);h.type=o.optString("type","");h.text=o.optString("text","");return h;}
    }

    public static final class ShoppingItem {
        public String id = UUID.randomUUID().toString();
        public String listName = "خرید";
        public String name = "";
        public String quantity = "";
        public double quantityValue = 0;
        public String unit = "عدد";
        public String category = "";
        public long price = 0; // legacy / paid total
        public long unitPrice = 0;
        public long calculatedTotal = 0;
        public long sellerQuotedTotal = 0;
        public String store="";
        public String sellerId="";
        public String paymentMethod="";
        public String bankCardId="";
        public String receiptUri=""; // legacy
        public long purchasedAt=0;
        public boolean important = false;
        public boolean done = false;
        public long createdAt = System.currentTimeMillis();
        JSONObject json() throws Exception {
            JSONObject o=new JSONObject();o.put("id",id);o.put("list",listName);o.put("name",name);o.put("qty",quantity);
            o.put("qtyValue",quantityValue);o.put("unit",unit);o.put("category",category);o.put("price",price);
            o.put("unitPrice",unitPrice);o.put("calculatedTotal",calculatedTotal);o.put("sellerQuotedTotal",sellerQuotedTotal);
            o.put("store",store);o.put("sellerId",sellerId);o.put("paymentMethod",paymentMethod);o.put("bankCardId",bankCardId);
            o.put("receipt",receiptUri);o.put("purchasedAt",purchasedAt);o.put("important",important);o.put("done",done);o.put("created",createdAt);
            return o;
        }
        static ShoppingItem from(JSONObject o){
            ShoppingItem x=new ShoppingItem();x.id=o.optString("id",x.id);x.listName=o.optString("list","خرید");
            x.name=o.optString("name","");x.quantity=o.optString("qty","");x.quantityValue=o.optDouble("qtyValue",0);
            x.unit=o.optString("unit","عدد");x.category=o.optString("category","");x.price=o.optLong("price",0);
            x.unitPrice=o.optLong("unitPrice",0);x.calculatedTotal=o.optLong("calculatedTotal",0);x.sellerQuotedTotal=o.optLong("sellerQuotedTotal",0);
            x.store=o.optString("store","");x.sellerId=o.optString("sellerId","");x.paymentMethod=o.optString("paymentMethod","");
            x.bankCardId=o.optString("bankCardId","");x.receiptUri=o.optString("receipt","");x.purchasedAt=o.optLong("purchasedAt",0);
            x.important=o.optBoolean("important",false);x.done=o.optBoolean("done",false);x.createdAt=o.optLong("created",0);return x;
        }
    }

    public static final class ShoppingList {
        public String id=UUID.randomUUID().toString();
        public String name="خرید";
        public long createdAt=System.currentTimeMillis();
        public long dueMillis=0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("createdAt",createdAt);o.put("due",dueMillis);return o;}
        static ShoppingList from(JSONObject o){ShoppingList x=new ShoppingList();x.id=o.optString("id",x.id);x.name=o.optString("name","خرید");x.createdAt=o.optLong("createdAt",0);x.dueMillis=o.optLong("due",0);return x;}
    }

    public static final class ShoppingSeller {
        public String id=UUID.randomUUID().toString();
        public String name="";
        public String phone="";
        public String address="";
        public String note="";
        public String category="عمومی";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("name",name);o.put("phone",phone);o.put("address",address);o.put("note",note);o.put("category",category);return o;}
        static ShoppingSeller from(JSONObject o){ShoppingSeller x=new ShoppingSeller();x.id=o.optString("id",x.id);x.name=o.optString("name","");x.phone=o.optString("phone","");x.address=o.optString("address","");x.note=o.optString("note","");x.category=o.optString("category","عمومی");return x;}
    }

    public static final class BankCard {
        public String id=UUID.randomUUID().toString();
        public String bank="";
        public String label="";
        public String last4="";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("bank",bank);o.put("label",label);o.put("last4",last4);return o;}
        static BankCard from(JSONObject o){BankCard x=new BankCard();x.id=o.optString("id",x.id);x.bank=o.optString("bank","");x.label=o.optString("label","");x.last4=o.optString("last4","");return x;}
        public String display(){String x=bank; if(!label.isEmpty())x+=(x.isEmpty()?"":" • ")+label; if(!last4.isEmpty())x+=" • ****"+last4; return x;}
    }

    public static final class ShoppingReceipt {
        public String id=UUID.randomUUID().toString();
        public String listName="";
        public String title="";
        public String localPath="";
        public String sha256="";
        public String sellerId="";
        public String sellerName="";
        public long amount=0;
        public long createdAt=System.currentTimeMillis();
        public ArrayList<String> itemIds=new ArrayList<>();
        JSONObject json() throws Exception {
            JSONObject o=new JSONObject();o.put("id",id);o.put("listName",listName);o.put("title",title);o.put("localPath",localPath);
            o.put("sha256",sha256);o.put("sellerId",sellerId);o.put("sellerName",sellerName);o.put("amount",amount);o.put("createdAt",createdAt);
            JSONArray a=new JSONArray();for(String x:itemIds)a.put(x);o.put("itemIds",a);return o;
        }
        static ShoppingReceipt from(JSONObject o){
            ShoppingReceipt x=new ShoppingReceipt();x.id=o.optString("id",x.id);x.listName=o.optString("listName","");
            x.title=o.optString("title","");x.localPath=o.optString("localPath","");x.sha256=o.optString("sha256","");
            x.sellerId=o.optString("sellerId","");x.sellerName=o.optString("sellerName","");x.amount=o.optLong("amount",0);x.createdAt=o.optLong("createdAt",0);
            JSONArray a=o.optJSONArray("itemIds");if(a!=null)for(int i=0;i<a.length();i++)x.itemIds.add(a.optString(i));return x;
        }
    }

    public static final class TodoItem {
        public String id = UUID.randomUUID().toString();
        public String title = "";
        public String category = "عمومی";
        public String note = "";
        public long dueMillis = 0;
        public boolean done = false;
        public long createdAt = System.currentTimeMillis();
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("title",title);o.put("category",category);o.put("note",note);o.put("due",dueMillis);o.put("done",done);o.put("created",createdAt);return o;}
        static TodoItem from(JSONObject o){TodoItem x=new TodoItem();x.id=o.optString("id",x.id);x.title=o.optString("title","");x.category=o.optString("category","عمومی");x.note=o.optString("note","");x.dueMillis=o.optLong("due",0);x.done=o.optBoolean("done",false);x.createdAt=o.optLong("created",0);return x;}
    }

    public static final class CaseItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String title = "";
        public String caseNumber = "";
        public String court = "";
        public String branch = "";
        public String counterparty = "";
        public String lawyer = "";
        public String note = "";
        public long paidAmount = 0;
        public String documentNote = "";
        public long whenMillis = 0;
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("title",title);o.put("case",caseNumber);o.put("court",court);o.put("branch",branch);o.put("party",counterparty);o.put("lawyer",lawyer);o.put("note",note);o.put("paidAmount",paidAmount);o.put("documentNote",documentNote);o.put("when",whenMillis);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static CaseItem from(JSONObject o){CaseItem x=new CaseItem();x.id=o.optString("id",x.id);x.title=o.optString("title","");x.caseNumber=o.optString("case","");x.court=o.optString("court","");x.branch=o.optString("branch","");x.counterparty=o.optString("party","");x.lawyer=o.optString("lawyer","");x.note=o.optString("note","");x.paidAmount=o.optLong("paidAmount",0);x.documentNote=o.optString("documentNote","");x.whenMillis=o.optLong("when",0);x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    public static final class VaultEntry {
        public String id = UUID.randomUUID().toString();
        public String type = "اکانت";
        public String title = "";
        public String usernameEncrypted = "";
        public String secretEncrypted = "";
        public String noteEncrypted = "";
        public long updatedAt = System.currentTimeMillis();
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("title",title);o.put("user",usernameEncrypted);o.put("secret",secretEncrypted);o.put("note",noteEncrypted);o.put("updated",updatedAt);return o;}
        static VaultEntry from(JSONObject o){VaultEntry x=new VaultEntry();x.id=o.optString("id",x.id);x.type=o.optString("type","اکانت");x.title=o.optString("title","");x.usernameEncrypted=o.optString("user","");x.secretEncrypted=o.optString("secret","");x.noteEncrypted=o.optString("note","");x.updatedAt=o.optLong("updated",0);return x;}
    }

    public static final class AssetEntry {
        public String id = UUID.randomUUID().toString();
        public String type = "سایر";
        public String name = "";
        public double amount = 0;
        public double buyUnitPrice = 0;
        public double currentUnitPrice = 0;
        public double fee = 0;
        public String currency = "تومان";
        public boolean autoPrice = false;
        public long buyDate = System.currentTimeMillis();
        public String note = "";
        public String sellerId = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("name",name);o.put("amount",amount);o.put("buy",buyUnitPrice);o.put("current",currentUnitPrice);o.put("fee",fee);o.put("currency",currency);o.put("autoPrice",autoPrice);o.put("date",buyDate);o.put("note",note);o.put("sellerId",sellerId);return o;}
        static AssetEntry from(JSONObject o){AssetEntry x=new AssetEntry();x.id=o.optString("id",x.id);x.type=o.optString("type","سایر");x.name=o.optString("name","");x.amount=o.optDouble("amount",0);x.buyUnitPrice=o.optDouble("buy",0);x.currentUnitPrice=o.optDouble("current",0);x.fee=o.optDouble("fee",0);x.currency=o.optString("currency","تومان");x.autoPrice=o.optBoolean("autoPrice",false);x.buyDate=o.optLong("date",0);x.note=o.optString("note","");x.sellerId=o.optString("sellerId","");return x;}
    }

    public static final class DocumentItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String type = "مدرک";
        public String title = "";
        public String number = "";
        public long issueDate = 0;
        public long expiryDate = 0;
        public String note = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("title",title);o.put("number",number);o.put("issue",issueDate);o.put("expiry",expiryDate);o.put("note",note);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static DocumentItem from(JSONObject o){DocumentItem x=new DocumentItem();x.id=o.optString("id",x.id);x.type=o.optString("type","مدرک");x.title=o.optString("title","");x.number=o.optString("number","");x.issueDate=o.optLong("issue",0);x.expiryDate=o.optLong("expiry",0);x.note=o.optString("note","");x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    public static final class BillItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String type = "قسط";
        public String title = "";
        public long amount = 0;
        public long dueDate = 0;
        public String recurrence = "یک‌بار";
        public String note = "";
        public boolean paid = false;
        public String sellerId = "";
        public String bankCardId = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("type",type);o.put("title",title);o.put("amount",amount);o.put("due",dueDate);o.put("repeat",recurrence);o.put("note",note);o.put("paid",paid);o.put("sellerId",sellerId);o.put("bankCardId",bankCardId);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static BillItem from(JSONObject o){BillItem x=new BillItem();x.id=o.optString("id",x.id);x.type=o.optString("type","قسط");x.title=o.optString("title","");x.amount=o.optLong("amount",0);x.dueDate=o.optLong("due",0);x.recurrence=o.optString("repeat","یک‌بار");x.note=o.optString("note","");x.paid=o.optBoolean("paid",false);x.sellerId=o.optString("sellerId","");x.bankCardId=o.optString("bankCardId","");x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    public static final class HomeItem {
        public String alertRules="1440,0";
        public int alertRepeat=5;
        public String id = UUID.randomUUID().toString();
        public String category = "خانه";
        public String title = "";
        public long lastServiceDate = 0;
        public long nextDueDate = 0;
        public long cost = 0;
        public String note = "";
        public String sellerId = "";
        JSONObject json() throws Exception {JSONObject o=new JSONObject();o.put("id",id);o.put("category",category);o.put("title",title);o.put("last",lastServiceDate);o.put("next",nextDueDate);o.put("cost",cost);o.put("note",note);o.put("sellerId",sellerId);o.put("alertRules",alertRules);o.put("alertRepeat",alertRepeat);return o;}
        static HomeItem from(JSONObject o){HomeItem x=new HomeItem();x.id=o.optString("id",x.id);x.category=o.optString("category","خانه");x.title=o.optString("title","");x.lastServiceDate=o.optLong("last",0);x.nextDueDate=o.optLong("next",0);x.cost=o.optLong("cost",0);x.note=o.optString("note","");x.sellerId=o.optString("sellerId","");x.alertRules=o.optString("alertRules","1440,0");x.alertRepeat=o.optInt("alertRepeat",5);return x;}
    }

    private interface Parser<T>{T parse(JSONObject o);} private interface Writer<T>{JSONObject write(T v)throws Exception;}
    private static <T> List<T> read(Context c,String key,Parser<T> parser){List<T> out=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString(key,"[]"));for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)out.add(parser.parse(o));}}catch(Exception ignored){}return out;}
    private static <T> void save(Context c,String key,List<T> list,Writer<T> writer){JSONArray a=new JSONArray();try{for(T v:list)a.put(writer.write(v));}catch(Exception ignored){}p(c).edit().putString(key,a.toString()).commit();}

    public static List<Reminder> reminders(Context c){List<Reminder> l=read(c,"reminders",Reminder::from);Collections.sort(l, Comparator.comparingLong(a->a.whenMillis));return l;}
    public static void saveReminders(Context c,List<Reminder> l){save(c,"reminders",l,Reminder::json);} public static void addReminder(Context c,Reminder r){List<Reminder>l=reminders(c);l.add(r);saveReminders(c,l);} public static void removeReminder(Context c,String id){List<Reminder>l=reminders(c);l.removeIf(x->x.id.equals(id));saveReminders(c,l);} public static void updateReminder(Context c,Reminder x){List<Reminder>l=reminders(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveReminders(c,l);} public static Reminder reminder(Context c,String id){for(Reminder r:reminders(c))if(r.id.equals(id))return r;return null;}

    public static List<Medicine> medicines(Context c){return read(c,"medicines",Medicine::from);} public static void saveMedicines(Context c,List<Medicine> l){save(c,"medicines",l,Medicine::json);} public static void addMedicine(Context c,Medicine m){List<Medicine>l=medicines(c);l.add(m);saveMedicines(c,l);} public static void updateMedicine(Context c,Medicine m){List<Medicine>l=medicines(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(m.id))l.set(i,m);saveMedicines(c,l);} public static Medicine medicine(Context c,String id){for(Medicine m:medicines(c))if(m.id.equals(id))return m;return null;} public static void removeMedicine(Context c,String id){List<Medicine>l=medicines(c);l.removeIf(x->x.id.equals(id));saveMedicines(c,l);}

    public static List<Vehicle> vehicles(Context c){return read(c,"vehicles",Vehicle::from);} public static void saveVehicles(Context c,List<Vehicle> l){save(c,"vehicles",l,Vehicle::json);} public static void addVehicle(Context c,Vehicle v){List<Vehicle>l=vehicles(c);l.add(v);saveVehicles(c,l);} public static Vehicle vehicle(Context c,String id){for(Vehicle v:vehicles(c))if(v.id.equals(id))return v;return null;} public static void updateVehicle(Context c,Vehicle v){List<Vehicle>l=vehicles(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(v.id))l.set(i,v);saveVehicles(c,l);}
    public static List<ServiceRecord> services(Context c){return read(c,"services",ServiceRecord::from);} public static void addService(Context c,ServiceRecord r){List<ServiceRecord>l=services(c);l.add(r);save(c,"services",l,ServiceRecord::json);} public static void updateService(Context c,ServiceRecord x){List<ServiceRecord>l=services(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"services",l,ServiceRecord::json);} public static void removeService(Context c,String id){List<ServiceRecord>l=services(c);l.removeIf(x->x.id.equals(id));save(c,"services",l,ServiceRecord::json);} public static List<ServiceRecord> servicesFor(Context c,String vehicleId){List<ServiceRecord>out=new ArrayList<>();for(ServiceRecord r:services(c))if(r.vehicleId.equals(vehicleId))out.add(r);out.sort((a,b)->Long.compare(b.dateMillis,a.dateMillis));return out;}
    public static List<FuelRecord> fuels(Context c){return read(c,"fuels",FuelRecord::from);} public static void addFuel(Context c,FuelRecord r){List<FuelRecord>l=fuels(c);l.add(r);save(c,"fuels",l,FuelRecord::json);} public static void updateFuel(Context c,FuelRecord x){List<FuelRecord>l=fuels(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"fuels",l,FuelRecord::json);} public static void removeFuel(Context c,String id){List<FuelRecord>l=fuels(c);l.removeIf(x->x.id.equals(id));save(c,"fuels",l,FuelRecord::json);} public static List<FuelRecord> fuelsFor(Context c,String vehicleId){List<FuelRecord>out=new ArrayList<>();for(FuelRecord r:fuels(c))if(r.vehicleId.equals(vehicleId))out.add(r);out.sort((a,b)->Long.compare(b.dateMillis,a.dateMillis));return out;}

    public static List<Profile> profiles(Context c){List<Profile>l=read(c,"profiles",Profile::from);if(l.isEmpty()&&!p(c).getBoolean("profiles_initialized",false)){p(c).edit().putBoolean("profiles_initialized",true).apply();String[]n={"جلسه","خواب","مطالعه","کار"};int[]m={60,480,90,120};for(int i=0;i<n.length;i++){Profile x=new Profile();x.name=n[i];x.minutes=m[i];x.mode=0;x.allowedCalls=(i<2);l.add(x);}saveProfiles(c,l);}return l;} public static void saveProfiles(Context c,List<Profile>l){save(c,"profiles",l,Profile::json);} public static void addProfile(Context c,Profile x){List<Profile>l=profiles(c);l.add(x);saveProfiles(c,l);} public static void updateProfile(Context c,Profile x){List<Profile>l=profiles(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveProfiles(c,l);} public static void removeProfile(Context c,String id){List<Profile>l=profiles(c);l.removeIf(x->x.id.equals(id));saveProfiles(c,l);}
    public static List<WeeklySchedule> schedules(Context c){return read(c,"schedules",WeeklySchedule::from);} public static void saveSchedules(Context c,List<WeeklySchedule>l){save(c,"schedules",l,WeeklySchedule::json);} public static void addSchedule(Context c,WeeklySchedule s){List<WeeklySchedule>l=schedules(c);l.add(s);saveSchedules(c,l);} public static void updateSchedule(Context c,WeeklySchedule x){List<WeeklySchedule>l=schedules(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveSchedules(c,l);} public static void removeSchedule(Context c,String id){List<WeeklySchedule>l=schedules(c);l.removeIf(x->x.id.equals(id));saveSchedules(c,l);}

    public static void addHistory(Context c,String type,String text){List<HistoryItem>l=history(c);HistoryItem h=new HistoryItem();h.type=type;h.text=text;l.add(0,h);while(l.size()>300)l.remove(l.size()-1);save(c,"history",l,HistoryItem::json);} public static List<HistoryItem> history(Context c){return read(c,"history",HistoryItem::from);} public static void clearHistory(Context c){p(c).edit().remove("history").apply();}

    public static List<MedicineDoseLog> medicineDoseLogs(Context c){
        List<MedicineDoseLog> l=read(c,"medicine_dose_logs",MedicineDoseLog::from);
        l.sort((a,b)->Long.compare(b.takenAt>0?b.takenAt:b.scheduledAt,a.takenAt>0?a.takenAt:a.scheduledAt));
        return l;
    }
    public static List<MedicineDoseLog> medicineDoseLogsFor(Context c,String medicineId){
        List<MedicineDoseLog> out=new ArrayList<>();for(MedicineDoseLog x:medicineDoseLogs(c))if(x.medicineId.equals(medicineId))out.add(x);return out;
    }
    public static void saveMedicineDoseLogs(Context c,List<MedicineDoseLog> l){save(c,"medicine_dose_logs",l,MedicineDoseLog::json);}
    public static void clearMedicineDoseLogs(Context c,String medicineId){
        List<MedicineDoseLog> all=medicineDoseLogs(c);
        for(int i=all.size()-1;i>=0;i--)if(medicineId.equals(all.get(i).medicineId))all.remove(i);
        saveMedicineDoseLogs(c,all);
    }

    public static void addMedicineDoseLog(Context c,MedicineDoseLog x){
        List<MedicineDoseLog> l=medicineDoseLogs(c);l.add(0,x);while(l.size()>1000)l.remove(l.size()-1);save(c,"medicine_dose_logs",l,MedicineDoseLog::json);
    }

    public static String[] defaultReminderCategories(){return new String[]{"📅 قرار","🩺 دکتر","💳 چک و قسط","💼 کار","🎂 تولد","💊 دارو","📄 مدارک","🔔 سایر"};}
    public static String[] defaultVaultGroups(){return new String[]{"اینستاگرام / شبکه اجتماعی","بانک‌ها","سایت‌ها","Wi-Fi","یادداشت محرمانه","سایر"};}

    public static List<Doctor> doctors(Context c){
        List<Doctor> out=read(c,"doctors",Doctor::from);
        // Import doctors already used in medical reminders so old data remains useful.
        for(Reminder r:reminders(c)){
            if(r.doctorName==null||r.doctorName.trim().isEmpty())continue;
            boolean found=false;for(Doctor d:out)if(d.name.equalsIgnoreCase(r.doctorName.trim())){found=true;break;}
            if(!found){Doctor d=new Doctor();d.name=r.doctorName.trim();d.fileNumber=r.doctorFileNumber;d.center=r.doctorCenter;d.phone=r.doctorPhone;d.address=r.doctorAddress;out.add(d);}
        }
        out.sort((a,b)->a.name.compareToIgnoreCase(b.name));return out;
    }
    public static void saveDoctors(Context c,List<Doctor>l){save(c,"doctors",l,Doctor::json);}
    public static void upsertDoctor(Context c,Doctor d){if(d==null||d.name==null||d.name.trim().isEmpty())return;List<Doctor>l=read(c,"doctors",Doctor::from);int ix=-1;for(int i=0;i<l.size();i++)if(l.get(i).name.equalsIgnoreCase(d.name.trim())){ix=i;break;}if(ix>=0){Doctor old=l.get(ix);if(!d.specialty.isEmpty())old.specialty=d.specialty;if(!d.fileNumber.isEmpty())old.fileNumber=d.fileNumber;if(!d.center.isEmpty())old.center=d.center;if(!d.phone.isEmpty())old.phone=d.phone;if(!d.address.isEmpty())old.address=d.address;}else l.add(d);saveDoctors(c,l);}
    public static Doctor doctorByName(Context c,String name){if(name==null)return null;for(Doctor d:doctors(c))if(d.name.equalsIgnoreCase(name.trim()))return d;return null;}

    public static List<LedgerParty> ledgerParties(Context c){List<LedgerParty> l=read(c,"ledger_parties",LedgerParty::from);l.sort((a,b)->a.name.compareToIgnoreCase(b.name));return l;}
    public static void saveLedgerParties(Context c,List<LedgerParty> l){save(c,"ledger_parties",l,LedgerParty::json);}
    public static void upsertLedgerParty(Context c,LedgerParty x){if(x==null||x.name==null||x.name.trim().isEmpty())return;List<LedgerParty> l=ledgerParties(c);int ix=-1;for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id)){ix=i;break;}if(ix<0)for(int i=0;i<l.size();i++)if(l.get(i).name.equalsIgnoreCase(x.name.trim())){x.id=l.get(i).id;ix=i;break;}if(ix>=0)l.set(ix,x);else l.add(x);saveLedgerParties(c,l);}
    public static void removeLedgerParty(Context c,String id){List<LedgerParty> l=ledgerParties(c);l.removeIf(x->x.id.equals(id));saveLedgerParties(c,l);}
    public static List<LedgerEntry> ledgerEntries(Context c){List<LedgerEntry> l=read(c,"ledger_entries",LedgerEntry::from);l.sort((a,b)->Long.compare(b.dateMillis,a.dateMillis));return l;}
    public static void saveLedgerEntries(Context c,List<LedgerEntry> l){save(c,"ledger_entries",l,LedgerEntry::json);}
    public static void addLedgerEntry(Context c,LedgerEntry x){List<LedgerEntry> l=ledgerEntries(c);l.add(x);saveLedgerEntries(c,l);}
    public static void updateLedgerEntry(Context c,LedgerEntry x){List<LedgerEntry> l=ledgerEntries(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveLedgerEntries(c,l);}
    public static void removeLedgerEntry(Context c,String id){List<LedgerEntry> l=ledgerEntries(c);l.removeIf(x->x.id.equals(id));saveLedgerEntries(c,l);}
    public static List<LedgerEntry> ledgerEntriesFor(Context c,String partyId){List<LedgerEntry> out=new ArrayList<>();for(LedgerEntry x:ledgerEntries(c))if(x.partyId.equals(partyId))out.add(x);return out;}
    public static long ledgerDelta(LedgerEntry x){if(x==null)return 0;if("DEBT".equals(x.kind)||"RECEIPT".equals(x.kind))return -x.amount;if("CREDIT".equals(x.kind)||"PAYMENT".equals(x.kind))return x.amount;return 0;}
    public static long ledgerBalance(Context c,String partyId){long v=0;for(LedgerEntry x:ledgerEntriesFor(c,partyId))v+=ledgerDelta(x);return v;} // positive=they owe me, negative=I owe

    public static void setEmailPanel(Context c,String url,String anonKey){p(c).edit().putString("email_supabase_url",url).putString("email_supabase_anon",anonKey).apply();}
    public static String emailSupabaseUrl(Context c){return p(c).getString("email_supabase_url","");}
    public static String emailSupabaseAnon(Context c){return p(c).getString("email_supabase_anon","");}

    private static List<String> namedList(Context c,String key){List<String>out=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString(key,"[]"));for(int i=0;i<a.length();i++){String v=a.optString(i,"").trim();if(!v.isEmpty()&&!out.contains(v))out.add(v);}}catch(Exception ignored){}return out;}
    private static void addNamed(Context c,String key,String value){if(value==null)return;String v=value.trim();if(v.isEmpty())return;List<String>l=namedList(c,key);if(!l.contains(v)){l.add(v);JSONArray a=new JSONArray();for(String x:l)a.put(x);p(c).edit().putString(key,a.toString()).commit();}}
    public static List<String> assetTypes(Context c){return namedList(c,"asset_types");}
    public static void addAssetType(Context c,String value){addNamed(c,"asset_types",value);}
    public static List<String> vaultGroups(Context c){return namedList(c,"vault_groups");}
    public static void addVaultGroup(Context c,String value){addNamed(c,"vault_groups",value);}
    public static List<String> courts(Context c){List<String> l=namedList(c,"case_courts");for(CaseItem x:cases(c))if(x.court!=null&&!x.court.trim().isEmpty()&&!l.contains(x.court.trim()))l.add(x.court.trim());return l;}
    public static void addCourt(Context c,String value){addNamed(c,"case_courts",value);}
    public static List<String> lawyers(Context c){List<String> l=namedList(c,"case_lawyers");for(CaseItem x:cases(c))if(x.lawyer!=null&&!x.lawyer.trim().isEmpty()&&!l.contains(x.lawyer.trim()))l.add(x.lawyer.trim());return l;}
    public static void addLawyer(Context c,String value){addNamed(c,"case_lawyers",value);}
    public static List<String> shoppingCategories(Context c){List<String>l=new ArrayList<>();Collections.addAll(l,"خوراکی","بهداشتی","خانه","پوشاک","داروخانه","لوازم شخصی","سایر");for(String x:namedList(c,"shopping_categories"))if(!l.contains(x))l.add(x);return l;}
    public static void addShoppingCategory(Context c,String value){addNamed(c,"shopping_categories",value);}

    public static List<String> customCategories(Context c){List<String>out=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString("custom_categories","[]"));for(int i=0;i<a.length();i++)out.add(a.optString(i));}catch(Exception ignored){}return out;}
    public static void addCustomCategory(Context c,String name){List<String>l=customCategories(c);if(!l.contains(name)){l.add(name);JSONArray a=new JSONArray();for(String s:l)a.put(s);p(c).edit().putString("custom_categories",a.toString()).apply();}}
    public static List<String> garageCategories(Context c){List<String>out=new ArrayList<>();try{JSONArray a=new JSONArray(p(c).getString("garage_categories","[]"));for(int i=0;i<a.length();i++)out.add(a.optString(i));}catch(Exception ignored){}return out;}
    public static void addGarageCategory(Context c,String name){List<String>l=garageCategories(c);if(!l.contains(name)){l.add(name);JSONArray a=new JSONArray();for(String x:l)a.put(x);p(c).edit().putString("garage_categories",a.toString()).apply();}}


    public static List<ShoppingList> shoppingLists(Context c){
        List<ShoppingList> l=read(c,"shopping_lists",ShoppingList::from);
        // migrate inferred legacy lists so an empty list can exist independently from items
        for(ShoppingItem i:read(c,"shopping",ShoppingItem::from)){
            boolean found=false;for(ShoppingList x:l)if(x.name.equalsIgnoreCase(i.listName)){found=true;break;}
            if(!found){ShoppingList x=new ShoppingList();x.name=i.listName;l.add(x);}
        }
        l.sort((a,b)->Long.compare(a.createdAt,b.createdAt));return l;
    }
    public static void saveShoppingLists(Context c,List<ShoppingList>l){save(c,"shopping_lists",l,ShoppingList::json);}
    public static void addShoppingList(Context c,ShoppingList x){List<ShoppingList>l=shoppingLists(c);l.add(x);saveShoppingLists(c,l);}
    public static void updateShoppingList(Context c,ShoppingList x,String oldName){
        List<ShoppingList>l=shoppingLists(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveShoppingLists(c,l);
        if(oldName!=null&&!oldName.equals(x.name)){
            List<ShoppingItem>items=shoppingItems(c);for(ShoppingItem i:items)if(i.listName.equalsIgnoreCase(oldName))i.listName=x.name;saveShoppingItems(c,items);
            List<ShoppingReceipt>rs=shoppingReceipts(c);for(ShoppingReceipt r:rs)if(r.listName.equalsIgnoreCase(oldName))r.listName=x.name;saveShoppingReceipts(c,rs);
        }
    }
    public static void removeShoppingList(Context c,String id){
        List<ShoppingList>l=shoppingLists(c);String name="";for(ShoppingList x:l)if(x.id.equals(id))name=x.name;
        final String n=name;l.removeIf(x->x.id.equals(id));saveShoppingLists(c,l);
        if(!n.isEmpty()){List<ShoppingItem>items=shoppingItems(c);items.removeIf(x->x.listName.equalsIgnoreCase(n));saveShoppingItems(c,items);}
    }
    public static ShoppingList shoppingListByName(Context c,String name){for(ShoppingList x:shoppingLists(c))if(x.name.equalsIgnoreCase(name))return x;return null;}

    public static List<ShoppingSeller> shoppingSellers(Context c){List<ShoppingSeller>l=read(c,"shopping_sellers",ShoppingSeller::from);l.sort((a,b)->a.name.compareToIgnoreCase(b.name));return l;}
    public static void saveShoppingSellers(Context c,List<ShoppingSeller>l){save(c,"shopping_sellers",l,ShoppingSeller::json);}
    public static void upsertShoppingSeller(Context c,ShoppingSeller x){
        if(x==null||x.name.trim().isEmpty())return;List<ShoppingSeller>l=shoppingSellers(c);int ix=-1;String nn=x.name.trim();String np=x.phone==null?"":x.phone.replaceAll("\\s+","");
        for(int i=0;i<l.size();i++){ShoppingSeller e=l.get(i);String ep=e.phone==null?"":e.phone.replaceAll("\\s+","");if(e.id.equals(x.id)||e.name.equalsIgnoreCase(nn)||(!np.isEmpty()&&np.equals(ep))){ix=i;break;}}
        if(ix>=0){if(!l.get(ix).id.equals(x.id))x.id=l.get(ix).id;l.set(ix,x);}else l.add(x);saveShoppingSellers(c,l);
    }
    public static List<ShoppingSeller> sellers(Context c){return shoppingSellers(c);}
    public static ShoppingSeller sellerById(Context c,String id){return shoppingSellerById(c,id);}
    public static void upsertSeller(Context c,ShoppingSeller x){upsertShoppingSeller(c,x);}
    public static void removeSeller(Context c,String id){removeShoppingSeller(c,id);}
    public static List<ShoppingItem> purchasesForSeller(Context c,String sellerId){List<ShoppingItem>o=new ArrayList<>();for(ShoppingItem x:shoppingItems(c))if(x.done&&sellerId!=null&&sellerId.equals(x.sellerId))o.add(x);o.sort((a,b)->Long.compare(b.purchasedAt,a.purchasedAt));return o;}
    public static List<BillItem> billsForSeller(Context c,String sellerId){List<BillItem>o=new ArrayList<>();for(BillItem x:bills(c))if(sellerId!=null&&sellerId.equals(x.sellerId))o.add(x);return o;}
    public static ShoppingSeller shoppingSellerById(Context c,String id){for(ShoppingSeller x:shoppingSellers(c))if(x.id.equals(id))return x;return null;}
    public static void removeShoppingSeller(Context c,String id){List<ShoppingSeller>l=shoppingSellers(c);l.removeIf(x->x.id.equals(id));saveShoppingSellers(c,l);}

    public static List<BankCard> bankCards(Context c){List<BankCard>l=read(c,"bank_cards",BankCard::from);l.sort((a,b)->a.display().compareToIgnoreCase(b.display()));return l;}
    public static void saveBankCards(Context c,List<BankCard>l){save(c,"bank_cards",l,BankCard::json);}
    public static void upsertBankCard(Context c,BankCard x){if(x==null||x.bank.trim().isEmpty())return;List<BankCard>l=bankCards(c);int ix=-1;for(int i=0;i<l.size();i++){BankCard e=l.get(i);if(e.id.equals(x.id)||(!x.last4.trim().isEmpty()&&e.bank.equalsIgnoreCase(x.bank)&&e.last4.equals(x.last4))||(!x.label.trim().isEmpty()&&e.bank.equalsIgnoreCase(x.bank)&&e.label.equalsIgnoreCase(x.label))){ix=i;break;}}if(ix>=0){if(!l.get(ix).id.equals(x.id))x.id=l.get(ix).id;l.set(ix,x);}else l.add(x);saveBankCards(c,l);}
    public static BankCard bankCardById(Context c,String id){for(BankCard x:bankCards(c))if(x.id.equals(id))return x;return null;}
    public static void removeBankCard(Context c,String id){List<BankCard>l=bankCards(c);l.removeIf(x->x.id.equals(id));saveBankCards(c,l);}

    public static List<ShoppingReceipt> shoppingReceipts(Context c){List<ShoppingReceipt>l=read(c,"shopping_receipts",ShoppingReceipt::from);l.sort((a,b)->Long.compare(b.createdAt,a.createdAt));return l;}
    public static void saveShoppingReceipts(Context c,List<ShoppingReceipt>l){save(c,"shopping_receipts",l,ShoppingReceipt::json);}
    public static void addShoppingReceipt(Context c,ShoppingReceipt x){List<ShoppingReceipt>l=shoppingReceipts(c);l.add(x);saveShoppingReceipts(c,l);}
    public static void updateShoppingReceipt(Context c,ShoppingReceipt x){List<ShoppingReceipt>l=shoppingReceipts(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveShoppingReceipts(c,l);}
    public static void removeShoppingReceipt(Context c,String id){List<ShoppingReceipt>l=shoppingReceipts(c);l.removeIf(x->x.id.equals(id));saveShoppingReceipts(c,l);}
    public static ShoppingReceipt receiptByHash(Context c,String hash){for(ShoppingReceipt x:shoppingReceipts(c))if(!hash.isEmpty()&&hash.equals(x.sha256))return x;return null;}
    public static List<ShoppingReceipt> receiptsForList(Context c,String listName){List<ShoppingReceipt>out=new ArrayList<>();for(ShoppingReceipt x:shoppingReceipts(c))if(x.listName.equalsIgnoreCase(listName))out.add(x);return out;}
    public static List<ShoppingReceipt> receiptsForItem(Context c,String itemId){List<ShoppingReceipt>out=new ArrayList<>();for(ShoppingReceipt x:shoppingReceipts(c))if(x.itemIds.contains(itemId))out.add(x);return out;}
    public static void clearShoppingReceipts(Context c){p(c).edit().remove("shopping_receipts").apply();}

    public static List<String> shoppingItemNames(Context c){
        java.util.LinkedHashSet<String> names=new java.util.LinkedHashSet<>();
        Collections.addAll(names,"موز","شیر","نان","قهوه","برنج","مرغ","گوشت","سیب","تخم مرغ","ماست","پنیر","شکر","چای");
        for(ShoppingItem x:shoppingItems(c))if(!x.name.trim().isEmpty())names.add(x.name.trim());
        return new ArrayList<>(names);
    }
    public static String suggestedShoppingCategory(String name){
        String n=name==null?"":name.trim();
        if(n.contains("موز")||n.contains("سیب")||n.contains("میوه")||n.contains("شیر")||n.contains("نان")||n.contains("برنج")||n.contains("مرغ")||n.contains("گوشت")||n.contains("ماست")||n.contains("پنیر")||n.contains("قهوه")||n.contains("چای")||n.contains("شکر")||n.contains("تخم"))return "خوراکی";
        if(n.contains("شامپو")||n.contains("صابون")||n.contains("خمیر دندان")||n.contains("دستمال"))return "بهداشتی";
        if(n.contains("لامپ")||n.contains("باتری")||n.contains("شوینده"))return "خانه";
        return "";
    }
    public static ShoppingItem lastPurchasedItem(Context c,String name){
        ShoppingItem best=null;for(ShoppingItem x:shoppingItems(c))if(x.done&&x.name.equalsIgnoreCase(name)&&x.purchasedAt>0&&(best==null||x.purchasedAt>best.purchasedAt))best=x;return best;
    }

    public static List<ShoppingItem> shoppingItems(Context c){List<ShoppingItem>l=read(c,"shopping",ShoppingItem::from);l.sort((a,b)->{int g=a.listName.compareToIgnoreCase(b.listName);if(g!=0)return g;if(a.done!=b.done)return a.done?1:-1;return Long.compare(a.createdAt,b.createdAt);});return l;}
    public static void saveShoppingItems(Context c,List<ShoppingItem>l){save(c,"shopping",l,ShoppingItem::json);} public static void addShoppingItem(Context c,ShoppingItem x){List<ShoppingItem>l=shoppingItems(c);l.add(x);saveShoppingItems(c,l);} public static void updateShoppingItem(Context c,ShoppingItem x){List<ShoppingItem>l=shoppingItems(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveShoppingItems(c,l);} public static void removeShoppingItem(Context c,String id){List<ShoppingItem>l=shoppingItems(c);l.removeIf(x->x.id.equals(id));saveShoppingItems(c,l);}

    public static List<TodoItem> todos(Context c){List<TodoItem>l=read(c,"todos",TodoItem::from);l.sort((a,b)->{if(a.done!=b.done)return a.done?1:-1;long ad=a.dueMillis==0?Long.MAX_VALUE:a.dueMillis,bd=b.dueMillis==0?Long.MAX_VALUE:b.dueMillis;return Long.compare(ad,bd);});return l;}
    public static void saveTodos(Context c,List<TodoItem>l){save(c,"todos",l,TodoItem::json);} public static void addTodo(Context c,TodoItem x){List<TodoItem>l=todos(c);l.add(x);saveTodos(c,l);} public static void updateTodo(Context c,TodoItem x){List<TodoItem>l=todos(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveTodos(c,l);} public static void removeTodo(Context c,String id){List<TodoItem>l=todos(c);l.removeIf(x->x.id.equals(id));saveTodos(c,l);}

    public static List<CaseItem> cases(Context c){List<CaseItem>l=read(c,"cases",CaseItem::from);l.sort(Comparator.comparingLong(a->a.whenMillis));return l;} public static void addCase(Context c,CaseItem x){List<CaseItem>l=cases(c);l.add(x);save(c,"cases",l,CaseItem::json);} public static void updateCase(Context c,CaseItem x){List<CaseItem>l=cases(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"cases",l,CaseItem::json);} public static void removeCase(Context c,String id){List<CaseItem>l=cases(c);l.removeIf(x->x.id.equals(id));save(c,"cases",l,CaseItem::json);}

    public static List<VaultEntry> vault(Context c){return read(c,"vault",VaultEntry::from);} public static void addVault(Context c,VaultEntry x){List<VaultEntry>l=vault(c);l.add(x);save(c,"vault",l,VaultEntry::json);} public static void updateVault(Context c,VaultEntry x){List<VaultEntry>l=vault(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"vault",l,VaultEntry::json);} public static void removeVault(Context c,String id){List<VaultEntry>l=vault(c);l.removeIf(x->x.id.equals(id));save(c,"vault",l,VaultEntry::json);}

    public static List<AssetEntry> assets(Context c){return read(c,"assets",AssetEntry::from);} public static void saveAssets(Context c,List<AssetEntry>l){save(c,"assets",l,AssetEntry::json);} public static void addAsset(Context c,AssetEntry x){List<AssetEntry>l=assets(c);l.add(x);saveAssets(c,l);} public static void updateAsset(Context c,AssetEntry x){List<AssetEntry>l=assets(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveAssets(c,l);} public static void removeAsset(Context c,String id){List<AssetEntry>l=assets(c);l.removeIf(x->x.id.equals(id));saveAssets(c,l);}

    public static List<DocumentItem> documents(Context c){List<DocumentItem>l=read(c,"documents",DocumentItem::from);l.sort(Comparator.comparingLong(a->a.expiryDate));return l;} public static void addDocument(Context c,DocumentItem x){List<DocumentItem>l=documents(c);l.add(x);save(c,"documents",l,DocumentItem::json);} public static void updateDocument(Context c,DocumentItem x){List<DocumentItem>l=documents(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"documents",l,DocumentItem::json);} public static void removeDocument(Context c,String id){List<DocumentItem>l=documents(c);l.removeIf(x->x.id.equals(id));save(c,"documents",l,DocumentItem::json);}

    public static List<BillItem> bills(Context c){List<BillItem>l=read(c,"bills",BillItem::from);l.sort((a,b)->{if(a.paid!=b.paid)return a.paid?1:-1;return Long.compare(a.dueDate,b.dueDate);});return l;} public static void saveBills(Context c,List<BillItem>l){save(c,"bills",l,BillItem::json);} public static void addBill(Context c,BillItem x){List<BillItem>l=bills(c);l.add(x);saveBills(c,l);} public static void updateBill(Context c,BillItem x){List<BillItem>l=bills(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);saveBills(c,l);} public static void removeBill(Context c,String id){List<BillItem>l=bills(c);l.removeIf(x->x.id.equals(id));saveBills(c,l);}

    public static List<HomeItem> homeItems(Context c){List<HomeItem>l=read(c,"home_items",HomeItem::from);l.sort(Comparator.comparingLong(a->a.nextDueDate));return l;} public static void addHomeItem(Context c,HomeItem x){List<HomeItem>l=homeItems(c);l.add(x);save(c,"home_items",l,HomeItem::json);} public static void updateHomeItem(Context c,HomeItem x){List<HomeItem>l=homeItems(c);for(int i=0;i<l.size();i++)if(l.get(i).id.equals(x.id))l.set(i,x);save(c,"home_items",l,HomeItem::json);} public static void removeHomeItem(Context c,String id){List<HomeItem>l=homeItems(c);l.removeIf(x->x.id.equals(id));save(c,"home_items",l,HomeItem::json);}

    public static void removeReminderBySource(Context c,String sourceKey){if(sourceKey==null||sourceKey.isEmpty())return;List<Reminder>l=reminders(c);l.removeIf(x->sourceKey.equals(x.sourceKey));saveReminders(c,l);}
    public static int marketRefreshMode(Context c){return p(c).getInt("market_refresh_mode",1);}
    public static void setMarketRefreshMode(Context c,int mode){p(c).edit().putInt("market_refresh_mode",Math.max(0,Math.min(2,mode))).apply();}
    public static void setUsdToman(Context c,double v){p(c).edit().putString("usd_toman",String.valueOf(v)).apply();} public static double usdToman(Context c){try{return Double.parseDouble(p(c).getString("usd_toman","0"));}catch(Exception e){return 0;}}
    public static void setMarketSnapshot(Context c,double gold,double silver,double copper,double eurPerUsd,long updated){p(c).edit().putString("market_gold",String.valueOf(gold)).putString("market_silver",String.valueOf(silver)).putString("market_copper",String.valueOf(copper)).putString("market_eur",String.valueOf(eurPerUsd)).putLong("market_updated",updated).apply();}
    private static double prefDouble(Context c,String key){try{return Double.parseDouble(p(c).getString(key,"0"));}catch(Exception e){return 0;}} public static double marketGold(Context c){return prefDouble(c,"market_gold");} public static double marketSilver(Context c){return prefDouble(c,"market_silver");} public static double marketCopper(Context c){return prefDouble(c,"market_copper");} public static double marketEurPerUsd(Context c){return prefDouble(c,"market_eur");} public static long marketUpdated(Context c){return p(c).getLong("market_updated",0);}

    public static void setEmergencyEnabled(Context c,boolean v){p(c).edit().putBoolean("emergency_card_enabled",v).apply();} public static boolean emergencyEnabled(Context c){return p(c).getBoolean("emergency_card_enabled",false);}
    public static void setEmergencyName(Context c,String v){p(c).edit().putString("emergency_name",v).apply();} public static String emergencyName(Context c){return p(c).getString("emergency_name","");}
    public static void setEmergencyPhone1(Context c,String v){p(c).edit().putString("emergency_phone1",v).apply();} public static String emergencyPhone1(Context c){return p(c).getString("emergency_phone1","");}
    public static void setEmergencyPhone2(Context c,String v){p(c).edit().putString("emergency_phone2",v).apply();} public static String emergencyPhone2(Context c){return p(c).getString("emergency_phone2","");}
    public static void setEmergencyNote(Context c,String v){p(c).edit().putString("emergency_note",v).apply();} public static String emergencyNote(Context c){return p(c).getString("emergency_note","");}
    public static void setEmergencyLabel1(Context c,String v){p(c).edit().putString("emergency_label1",v).apply();} public static String emergencyLabel1(Context c){String v=p(c).getString("emergency_label1","مادر");return v==null||v.trim().isEmpty()?"مادر":v.trim();}
    public static void setEmergencyLabel2(Context c,String v){p(c).edit().putString("emergency_label2",v).apply();} public static String emergencyLabel2(Context c){String v=p(c).getString("emergency_label2","پدر");return v==null||v.trim().isEmpty()?"پدر":v.trim();}

    public static void setSmsEnabled(Context c,boolean v){p(c).edit().putBoolean("sms_enabled",v).apply();} public static boolean smsEnabled(Context c){return p(c).getBoolean("sms_enabled",false);} public static void setSmsNumber(Context c,String v){p(c).edit().putString("sms_number",v).apply();} public static String smsNumber(Context c){return p(c).getString("sms_number","");} public static void setSmsCode(Context c,String v){
        String encrypted=VaultCrypto.encrypt(v);
        if(!v.isEmpty()&&encrypted.isEmpty())return;
        p(c).edit().putString("sms_code",v.isEmpty()?"":"enc:"+encrypted).apply();
    }
    public static String smsCode(Context c){
        String raw=p(c).getString("sms_code","");
        if(raw.startsWith("enc:"))return VaultCrypto.decrypt(raw.substring(4));
        if(!raw.isEmpty()){String encoded=VaultCrypto.encrypt(raw);
            if(!encoded.isEmpty())p(c).edit().putString("sms_code","enc:"+encoded).apply();}
        return raw;
    }
    public static void setSmsFromAnyone(Context c,boolean v){p(c).edit().putBoolean("sms_any_sender",v).apply();}
    public static boolean smsFromAnyone(Context c){return p(c).getBoolean("sms_any_sender",false);}
    public static boolean smsRateLimited(Context c){long now=System.currentTimeMillis();
        long then=p(c).getLong("last_sms_activation",0L);
        if(now-then<60000L)return true;
        p(c).edit().putLong("last_sms_activation",now).apply();return false;
    }
    public static void setUnlockNote(Context c,String v){p(c).edit().putString("unlock_note",v).apply();} public static String unlockNote(Context c){return p(c).getString("unlock_note","");}
    public static void setPin(Context c,String v){String hashed=SecurityUtil.hashPin(v);if(!hashed.isEmpty())p(c).edit().putString("pin_secure",hashed).remove("pin").apply();} public static String pin(Context c){return "";} public static boolean verifyPin(Context c,String value){String secure=p(c).getString("pin_secure","");if(!secure.isEmpty())return SecurityUtil.verifyPin(value,secure);String legacy=p(c).getString("pin","");if(!legacy.isEmpty()&&legacy.equals(value)){setPin(c,value);return true;}return false;} public static void setLockEnabled(Context c,boolean v){p(c).edit().putBoolean("lock_enabled",v).apply();} public static boolean lockEnabled(Context c){return p(c).getBoolean("lock_enabled",false);} public static void setBiometricEnabled(Context c,boolean v){p(c).edit().putBoolean("bio_enabled",v).apply();} public static boolean biometricEnabled(Context c){return p(c).getBoolean("bio_enabled",false);}

    public static boolean accountConfigured(Context c){return p(c).getBoolean("account_configured",false);}
    public static String accountName(Context c){return p(c).getString("account_name","");}
    public static String accountEmail(Context c){return p(c).getString("account_email","");}
    public static String accountPhone(Context c){return p(c).getString("account_phone","");}
    public static void saveAccount(Context c,String name,String email,String phone){p(c).edit()
            .putString("account_name",name).putString("account_email",email)
            .putString("account_phone",phone).putBoolean("account_configured",true).apply();}
    public static boolean pinConfigured(Context c){return p(c).contains("pin_secure")||p(c).contains("pin");}

    public static void setRecoveryCode(Context c,String code){String h=SecurityUtil.hashPin(code);if(!h.isEmpty())p(c).edit().putString("recovery_code_secure",h).apply();}
    public static boolean recoveryCodeConfigured(Context c){return p(c).contains("recovery_code_secure");}
    public static boolean verifyRecoveryCode(Context c,String code){return SecurityUtil.verifyPin(code,p(c).getString("recovery_code_secure",""));}
    public static void clearRecoveryCode(Context c){p(c).edit().remove("recovery_code_secure").apply();}
    public static void setSecurityAutoLockMinutes(Context c,int v){p(c).edit().putInt("security_auto_lock_minutes",Math.max(1,v)).apply();}
    public static int securityAutoLockMinutes(Context c){return p(c).getInt("security_auto_lock_minutes",5);}
    public static void setVaultLockOnBackground(Context c,boolean v){p(c).edit().putBoolean("vault_lock_on_background",v).apply();}
    public static boolean vaultLockOnBackground(Context c){return p(c).getBoolean("vault_lock_on_background",true);}
    public static void markEmailOtpSent(Context c){p(c).edit().putLong("email_otp_last_sent",System.currentTimeMillis()).apply();}
    public static long emailOtpLastSent(Context c){return p(c).getLong("email_otp_last_sent",0L);}
    public static void markEmailVerified(Context c,String email){p(c).edit().putString("email_verified",email==null?"":email.trim().toLowerCase()).apply();}
    public static boolean emailVerified(Context c){String e=accountEmail(c);return !e.isEmpty()&&e.trim().toLowerCase().equals(p(c).getString("email_verified",""));}
    public static void replaceVault(Context c,List<VaultEntry> l){save(c,"vault",l,VaultEntry::json);}

    public static boolean tokenDismissed(Context c,String token){return p(c).getStringSet("dismissed_tokens",new HashSet<>()).contains(token);} public static void dismissToken(Context c,String token){Set<String>s=new HashSet<>(p(c).getStringSet("dismissed_tokens",new HashSet<>()));s.add(token);p(c).edit().putStringSet("dismissed_tokens",s).apply();}

    public static String exportJson(Context c){
        JSONObject root=new JSONObject();
        try{
            java.util.Map<String,?> all=p(c).getAll();
            java.util.Map<String,Object> safe=new java.util.HashMap<>();
            for(java.util.Map.Entry<String,?>e:all.entrySet()){
                if(!"vault".equals(e.getKey()))safe.put(e.getKey(),e.getValue());
            }
            root.put("schema",2);
            root.put("nexa",mapToJson(safe));
            root.put("silent",mapToJson(c.getSharedPreferences("silent_timer_prefs",Context.MODE_PRIVATE).getAll()));
            root.put("vault_note","Vault is intentionally excluded from portable backup because its encryption key stays in Android Keystore.");
        }catch(Exception ignored){}
        return root.toString();
    }
    private static JSONObject mapToJson(java.util.Map<String,?> map)throws Exception{JSONObject o=new JSONObject();for(java.util.Map.Entry<String,?>e:map.entrySet()){Object v=e.getValue();if(v instanceof Set){JSONArray a=new JSONArray();for(Object x:(Set<?>)v)a.put(String.valueOf(x));JSONObject wrap=new JSONObject();wrap.put("__set",a);o.put(e.getKey(),wrap);}else o.put(e.getKey(),v);}return o;}
    public static boolean importJson(Context c,String raw){
        try{
            String vaultLocal=p(c).getString("vault","[]");
            JSONObject root=new JSONObject(raw);
            restorePrefs(p(c),root.getJSONObject("nexa"));
            p(c).edit().putString("vault",vaultLocal).apply();
            restorePrefs(c.getSharedPreferences("silent_timer_prefs",Context.MODE_PRIVATE),root.getJSONObject("silent"));
            return true;
        }catch(Exception e){
            return false;
        }
    }
    private static void restorePrefs(SharedPreferences sp,JSONObject o)throws Exception{SharedPreferences.Editor ed=sp.edit().clear();java.util.Iterator<String>it=o.keys();while(it.hasNext()){String k=it.next();Object v=o.get(k);if(v instanceof Boolean)ed.putBoolean(k,(Boolean)v);else if(v instanceof Integer)ed.putInt(k,(Integer)v);else if(v instanceof Long)ed.putLong(k,(Long)v);else if(v instanceof Double)ed.putFloat(k,((Double)v).floatValue());else if(v instanceof JSONObject && ((JSONObject)v).has("__set")){Set<String>s=new HashSet<>();JSONArray a=((JSONObject)v).getJSONArray("__set");for(int i=0;i<a.length();i++)s.add(a.getString(i));ed.putStringSet(k,s);}else ed.putString(k,String.valueOf(v));}ed.apply();}
}
