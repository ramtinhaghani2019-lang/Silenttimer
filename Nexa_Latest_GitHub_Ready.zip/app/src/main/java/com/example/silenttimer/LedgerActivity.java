package com.example.silenttimer;

import android.app.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.text.method.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class LedgerActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private EditText search;
    private boolean formattingAmount;

    @Override public void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private EditText field(String h){return UiKit.styleField(this,new EditText(this),h);}

    private void build(){
        ScrollView sc=new ScrollView(this); LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,30));
        root.setBackground(UiKit.screenBackground(this)); sc.addView(root);
        root.addView(UiKit.header(this,"⚖ بدهی‌ها و طلب‌ها",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"طرف‌حساب‌ها • تراکنش‌ها • مانده لحظه‌ای"),UiKit.matchWrap(this,0,8));root.addView(UiKit.featureHero(this,"ledger","حساب‌های من","بدهی، طلب، پرداخت و دریافت در یک نگاه"),UiKit.matchWrap(this,0,12));
        LinearLayout balanceCard=UiKit.accentCardLayout(this);balanceCard.addView(UiKit.sectionTitle(this,"💳 جمع‌بندی حساب‌ها"));summary=UiKit.sectionTitle(this,"");balanceCard.addView(summary,UiKit.matchWrap(this,6,0));root.addView(balanceCard,UiKit.matchWrap(this,0,12));
        Button add=UiKit.primaryButton(this,"＋ طرف‌حساب جدید"); add.setOnClickListener(v->editParty(null)); root.addView(add,UiKit.matchWrap(this,0,8));
        search=field("جستجوی طرف‌حساب"); search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){render();} public void afterTextChanged(Editable e){}}); root.addView(search,UiKit.matchWrap(this,0,12));
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list); setContentView(sc); render();
    }

    private String money(long x){return groupedMoney(Math.abs(x))+" تومان";}
    private String groupedMoney(long x){return NumberFormatUtil.grouped(x).replace(',','٬');}
    private String rawAmount(String s){return s==null?"":s.replace(",","").replace("٬","").trim();}
    private String state(long b){return b>0?"بستانکار • "+money(b):b<0?"بدهکار • "+money(b):"تسویه";}

    private void render(){
        list.removeAllViews(); List<NexaStore.LedgerParty> ps=NexaStore.ledgerParties(this); long receivable=0,debt=0;
        for(NexaStore.LedgerParty p:ps){long b=NexaStore.ledgerBalance(this,p.id);if(b>0)receivable+=b;else debt+=-b;}
        summary.setText("طلب من: "+money(receivable)+"\nبدهی من: "+money(debt)+"\nخالص: "+(receivable-debt>=0?"بستانکار ":"بدهکار ")+money(receivable-debt));
        if(ps.isEmpty()){list.addView(UiKit.muted(this,"هنوز طرف‌حسابی ثبت نشده."));return;}
        String q=search==null?"":search.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
        for(NexaStore.LedgerParty p:ps){
            if(!q.isEmpty() && !(p.name+" "+p.phone+" "+p.note).toLowerCase(java.util.Locale.ROOT).contains(q))continue;
            long bal=NexaStore.ledgerBalance(this,p.id); LinearLayout c=UiKit.cardLayout(this); c.addView(UiKit.sectionTitle(this,p.name));
            c.addView(UiKit.muted(this,state(bal)+" • "+NexaStore.ledgerEntriesFor(this,p.id).size()+" تراکنش"),UiKit.matchWrap(this,4,5));
            LinearLayout row=new LinearLayout(this); Button open=UiKit.primaryButton(this,"گردش حساب"); open.setOnClickListener(v->showParty(p)); row.addView(open,new LinearLayout.LayoutParams(0,-2,1f));
            Button edit=UiKit.editIconButton(this); edit.setOnClickListener(v->editParty(p)); row.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44))); Button del=UiKit.deleteIconButton(this); del.setOnClickListener(v->deleteParty(p)); row.addView(del,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44))); c.addView(row); list.addView(c,UiKit.matchWrap(this,0,7));
        }
    }

    private void editParty(NexaStore.LedgerParty old){
        LinearLayout box=UiKit.dialogPanel(this); EditText name=field("نام طرف‌حساب؛ مثلاً احمدی"); EditText phone=field("تلفن (اختیاری)"); EditText note=field("توضیحات");
        if(old!=null){name.setText(old.name);phone.setText(old.phone);note.setText(old.note);} box.addView(name);box.addView(phone);box.addView(note);
        new AlertDialog.Builder(this).setTitle(old==null?"طرف‌حساب جدید":"ویرایش طرف‌حساب").setView(box).setPositiveButton("ذخیره",(d,w)->{
            String n=name.getText().toString().trim(); if(n.isEmpty())return; NexaStore.LedgerParty p=old==null?new NexaStore.LedgerParty():old;
            p.name=n;p.phone=phone.getText().toString().trim();p.note=note.getText().toString().trim();NexaStore.upsertLedgerParty(this,p);render();
        }).setNegativeButton("انصراف",null).show();
    }

    private void deleteParty(NexaStore.LedgerParty p){
        int count=NexaStore.ledgerEntriesFor(this,p.id).size();
        new AlertDialog.Builder(this).setTitle("حذف طرف‌حساب؟").setMessage(p.name+(count>0?"\n"+count+" تراکنش این حساب نیز حذف می‌شود.":""))
                .setPositiveButton("حذف",(d,w)->{for(NexaStore.LedgerEntry x:NexaStore.ledgerEntriesFor(this,p.id))LinkedReminderHelper.remove(this,"ledger:"+x.id);NexaStore.removeLedgerParty(this,p.id);render();})
                .setNegativeButton("انصراف",null).show();
    }

    private String date(long ms){return PersianDateUtil.pretty(ms);}
    private int kindColor(String kind){
        if("DEBT".equals(kind)) return Color.rgb(239,83,80);       // red
        if("CREDIT".equals(kind)) return Color.rgb(38,198,218);   // cyan
        if("PAYMENT".equals(kind)) return Color.rgb(53,201,120);    // payment green
        return Color.rgb(102,187,106);                            // receipt green
    }

    private String kindLabel(String kind){return "DEBT".equals(kind)?"بدهی جدید":"CREDIT".equals(kind)?"طلب جدید":"PAYMENT".equals(kind)?"پرداخت کردم":"دریافت کردم";}

    private LinearLayout entryCard(NexaStore.LedgerParty p,NexaStore.LedgerEntry x,long running,Runnable refresh){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(UiKit.dp(this,12),UiKit.dp(this,10),UiKit.dp(this,12),UiKit.dp(this,10));
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.TRANSPARENT); bg.setCornerRadius(UiKit.dp(this,14)); bg.setStroke(UiKit.dp(this,2),kindColor(x.kind)); card.setBackground(bg);
        String due=x.dueMillis>0?"\nموعد: "+date(x.dueMillis)+(x.dueMillis<System.currentTimeMillis()?" • سررسید گذشته":""):""; TextView t=UiKit.muted(this,kindLabel(x.kind)+" • "+money(x.amount)+"\nثبت: "+date(x.dateMillis)+(x.note.isEmpty()?"":"\n"+x.note)+due+"\nمانده: "+state(running)); card.addView(t);
        LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.END);
        Button edit=UiKit.editIconButton(this); edit.setOnClickListener(v->editEntry(p,x,refresh)); actions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
        Button del=UiKit.deleteIconButton(this); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف تراکنش؟").setMessage(kindLabel(x.kind)+" • "+money(x.amount)).setPositiveButton("حذف",(d,w)->{LinkedReminderHelper.remove(this,"ledger:"+x.id);NexaStore.removeLedgerEntry(this,x.id);refresh.run();render();}).setNegativeButton("انصراف",null).show()); LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)); dl.setMargins(UiKit.dp(this,6),0,0,0); actions.addView(del,dl);
        card.addView(actions); return card;
    }

    private void showParty(NexaStore.LedgerParty p){
        LinearLayout box=UiKit.dialogPanel(this); TextView bal=UiKit.sectionTitle(this,state(NexaStore.ledgerBalance(this,p.id))); box.addView(bal);
        Button add=UiKit.primaryButton(this,"＋ ثبت بدهی / طلب / پرداخت / دریافت"); box.addView(add,UiKit.matchWrap(this,0,8)); LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); ScrollView txScroll=new ScrollView(this); txScroll.addView(rows); box.addView(txScroll,new LinearLayout.LayoutParams(-1,UiKit.dp(this,430)));
        final Runnable[] rr=new Runnable[1]; rr[0]=()->{
            rows.removeAllViews(); long running=0; List<NexaStore.LedgerEntry> all=NexaStore.ledgerEntriesFor(this,p.id); Collections.reverse(all);
            for(NexaStore.LedgerEntry x:all){running+=NexaStore.ledgerDelta(x); rows.addView(entryCard(p,x,running,rr[0]),UiKit.matchWrap(this,5,7));}
            if(all.isEmpty())rows.addView(UiKit.muted(this,"هنوز تراکنشی ثبت نشده.")); bal.setText(state(NexaStore.ledgerBalance(this,p.id)));
        };
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(p.name).setView(box).setPositiveButton("بستن",null).create(); add.setOnClickListener(v->editEntry(p,null,rr[0])); rr[0].run(); dialog.setOnDismissListener(x->render()); dialog.show();
    }

    private void attachGrouping(EditText amount){
        amount.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){}
            public void afterTextChanged(Editable e){
                if(formattingAmount)return; String raw=rawAmount(e.toString()); if(raw.isEmpty())return;
                try{long v=Long.parseLong(raw); String grouped=groupedMoney(v); if(!grouped.equals(e.toString())){formattingAmount=true; amount.setText(grouped); amount.setSelection(grouped.length()); formattingAmount=false;}}catch(Exception ignored){}
            }
        });
    }

    private void editEntry(NexaStore.LedgerParty p,NexaStore.LedgerEntry old,Runnable done){
        LinearLayout box=UiKit.dialogPanel(this); Spinner kind=UiKit.styledSpinner(this); String[] labels={"بدهی جدید (من بدهکارم)","طلب جدید (او به من بدهکار است)","پرداخت کردم","دریافت کردم"}; String[] kinds={"DEBT","CREDIT","PAYMENT","RECEIPT"};
        kind.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels)); EditText amount=field("مبلغ به تومان"); amount.setInputType(InputType.TYPE_CLASS_NUMBER); attachGrouping(amount); EditText note=field("شرح تراکنش"); final long[] dueMillis={old==null?0:old.dueMillis}; Button due=UiKit.secondaryButton(this,dueMillis[0]>0?"🕒 موعد: "+date(dueMillis[0]):"🕒 موعد / یادآور (اختیاری)"); due.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,dueMillis[0]>0?dueMillis[0]:System.currentTimeMillis()+3600000L,"موعد حساب",ms->{dueMillis[0]=ms;due.setText("🕒 موعد: "+date(ms));}));
        if(old!=null){for(int i=0;i<kinds.length;i++)if(kinds[i].equals(old.kind))kind.setSelection(i); amount.setText(groupedMoney(old.amount)); amount.setSelection(amount.length()); note.setText(old.note);}
        box.addView(kind);box.addView(amount);box.addView(note);box.addView(due);
        new AlertDialog.Builder(this).setTitle((old==null?"تراکنش جدید":"ویرایش تراکنش")+" • "+p.name).setView(box).setPositiveButton(old==null?"ثبت":"ذخیره",(d,w)->{
            long a=0;try{a=Long.parseLong(rawAmount(amount.getText().toString()));}catch(Exception ignored){} if(a<=0)return;
            NexaStore.LedgerEntry x=old==null?new NexaStore.LedgerEntry():old; x.partyId=p.id;x.amount=a;x.kind=kinds[kind.getSelectedItemPosition()];x.note=note.getText().toString().trim();x.dueMillis=dueMillis[0];
            if(old==null)NexaStore.addLedgerEntry(this,x);else NexaStore.updateLedgerEntry(this,x);
            if(x.dueMillis>System.currentTimeMillis())LinkedReminderHelper.upsert(this,"ledger:"+x.id,"موعد حساب • "+p.name,"حساب","💰",kindLabel(x.kind)+" • "+money(x.amount)+(x.note.isEmpty()?"":" • "+x.note),x.dueMillis,"60,0",5);else LinkedReminderHelper.remove(this,"ledger:"+x.id);
            NexaStore.addHistory(this,"حساب",p.name+" • "+labels[kind.getSelectedItemPosition()]+" • "+money(a)); done.run(); render();
        }).setNegativeButton("انصراف",null).show();
    }
}
