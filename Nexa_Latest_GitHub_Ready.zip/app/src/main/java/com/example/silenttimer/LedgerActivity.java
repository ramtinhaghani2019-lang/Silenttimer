package com.example.silenttimer;

import android.app.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.text.method.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class LedgerActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private EditText search;
    private boolean formattingAmount;
    private int reportDays=0; // 0 = all, 30 or 90 = recent rolling days
    private TextView reportSummary;
    private static final int REQUEST_LEDGER_CSV=7532;
    private String pendingReportPartyId=null;
    private int pendingReportDays=0;


    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(b!=null){
            reportDays=b.getInt("ledger.reportDays",0);
            pendingReportDays=b.getInt("ledger.pendingDays",0);
            pendingReportPartyId=b.getString("ledger.pendingParty");
        }
        UiKit.applyWindow(this);build();
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putInt("ledger.reportDays",reportDays);
        state.putInt("ledger.pendingDays",pendingReportDays);
        state.putString("ledger.pendingParty",pendingReportPartyId);
        super.onSaveInstanceState(state);
    }
    private EditText field(String h){return UiKit.styleField(this,new EditText(this),h);}

    private void build(){
        ScrollView sc=new ScrollView(this); LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,30));
        root.setBackground(UiKit.screenBackground(this)); sc.addView(root);
        root.addView(UiKit.header(this,"⚖ بدهی‌ها و طلب‌ها",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"طرف‌حساب‌ها • تراکنش‌ها • مانده لحظه‌ای"),UiKit.matchWrap(this,0,8));root.addView(UiKit.featureHero(this,"ledger","حساب‌های من","بدهی، طلب، پرداخت و دریافت در یک نگاه"),UiKit.matchWrap(this,0,12));
        LinearLayout balanceCard=UiKit.accentCardLayout(this);balanceCard.addView(UiKit.sectionTitle(this,"💳 جمع‌بندی حساب‌ها"));summary=UiKit.sectionTitle(this,"");balanceCard.addView(summary,UiKit.matchWrap(this,6,0));root.addView(balanceCard,UiKit.matchWrap(this,0,12));
        LinearLayout reportCard=UiKit.colorfulCardLayout(this,2);
        reportCard.addView(UiKit.sectionTitle(this,"📊 گزارش حساب‌ها و خروجی CSV"));
        reportCard.addView(UiKit.muted(this,"دوره گزارش، فقط آمار و فایل خروجی را تغییر می‌دهد؛ مانده اصلی حساب‌ها دست‌نخورده می‌ماند."),UiKit.matchWrap(this,2,7));
        LinearLayout periods=new LinearLayout(this);periods.setGravity(Gravity.CENTER_VERTICAL);
        int[] choices={0,30,90};String[] labels={"همه","۳۰ روز","۹۰ روز"};
        for(int i=0;i<choices.length;i++){
            final int days=choices[i];Button button=UiKit.secondaryButton(this,labels[i]);
            button.setOnClickListener(v->{reportDays=days;render();});
            periods.addView(button,new LinearLayout.LayoutParams(0,-2,1f));
        }
        reportCard.addView(periods,UiKit.matchWrap(this,0,8));
        reportSummary=UiKit.muted(this,"");reportCard.addView(reportSummary,UiKit.matchWrap(this,2,8));
        Button export=UiKit.primaryButton(this,"⇩ ذخیره گردش تمام حساب‌ها (CSV)");
        export.setOnClickListener(v->exportLedger(null));
        reportCard.addView(export,UiKit.matchWrap(this,0,5));
        reportCard.addView(UiKit.muted(this,"⚠ فایل CSV رمزگذاری نشده است؛ فقط در محل امن ذخیره کن."),UiKit.matchWrap(this,6,0));
        root.addView(reportCard,UiKit.matchWrap(this,0,12));
        Button add=UiKit.primaryButton(this,"＋ طرف‌حساب جدید"); add.setOnClickListener(v->editParty(null)); root.addView(add,UiKit.matchWrap(this,0,8));
        search=field("جستجوی طرف‌حساب"); search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){render();} public void afterTextChanged(Editable e){}}); root.addView(search,UiKit.matchWrap(this,0,12));
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list); setContentView(sc); render();
    }

    private String money(long x){return groupedMoney(Math.abs(x))+" تومان";}
    private String groupedMoney(long x){return NumberFormatUtil.grouped(x).replace(',','٬');}
    private String rawAmount(String s){return s==null?"":s.replace(",","").replace("٬","").trim();}
    private String state(long b){return b>0?"بستانکار • "+money(b):b<0?"بدهکار • "+money(b):"تسویه";}

    private void render(){
        list.removeAllViews(); List<NexaStore.LedgerParty> ps=NexaStore.ledgerParties(this); long receivable=0,debt=0;
        for(NexaStore.LedgerParty p:ps){long b=NexaStore.ledgerBalance(this,p.id);if(b>0)receivable+=b;else debt+=-b;}
        summary.setText("طلب من: "+money(receivable)+"\nبدهی من: "+money(debt)+"\nخالص: "+(receivable-debt>=0?"بستانکار ":"بدهکار ")+money(receivable-debt));
        long now=System.currentTimeMillis();
        LedgerReport.Result report=LedgerReport.generate(ps,NexaStore.ledgerEntries(this),null,LedgerReport.startMillis(reportDays,now),reportDays==0?Long.MAX_VALUE:now);
        String period=reportDays==0?"همه تراکنش‌ها":reportDays+" روز گذشته";
        reportSummary.setText("بازه: "+period+" • "+report.rows.size()+" تراکنش"
                +"\nبدهی جدید: "+money(report.debtAdded)+" • طلب جدید: "+money(report.creditAdded)
                +"\nپرداخت‌ها: "+money(report.paid)+" • دریافتی‌ها: "+money(report.received)
                +"\nتغییر خالص بازه: "+(report.periodChange>=0?"+":"")+NumberFormatUtil.grouped(report.periodChange)+" تومان"
                +"\nخالص حساب‌ها تا پایان بازه: "+NumberFormatUtil.grouped(report.closingNet)+" تومان");
        if(ps.isEmpty()){list.addView(UiKit.muted(this,"هنوز طرف‌حسابی ثبت نشده."));return;}
        String q=search==null?"":search.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
        for(NexaStore.LedgerParty p:ps){
            if(!q.isEmpty() && !(p.name+" "+p.phone+" "+p.note).toLowerCase(java.util.Locale.ROOT).contains(q))continue;
            long bal=NexaStore.ledgerBalance(this,p.id); LinearLayout c=UiKit.cardLayout(this); c.addView(UiKit.sectionTitle(this,p.name));
            c.addView(UiKit.muted(this,state(bal)+" • "+NexaStore.ledgerEntriesFor(this,p.id).size()+" تراکنش"),UiKit.matchWrap(this,4,5));
            LinearLayout row=new LinearLayout(this); Button open=UiKit.primaryButton(this,"گردش حساب"); open.setOnClickListener(v->showParty(p)); row.addView(open,new LinearLayout.LayoutParams(0,-2,1f));
            Button edit=UiKit.editIconButton(this); edit.setOnClickListener(v->editParty(p)); row.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44))); Button del=UiKit.deleteIconButton(this); del.setOnClickListener(v->deleteParty(p)); row.addView(del,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44))); c.addView(row); list.addView(c,UiKit.matchWrap(this,0,7));
        }
    }

    private void exportLedger(String partyId){
        long now=System.currentTimeMillis();
        LedgerReport.Result report=LedgerReport.generate(NexaStore.ledgerParties(this),NexaStore.ledgerEntries(this),
                partyId,LedgerReport.startMillis(reportDays,now),reportDays==0?Long.MAX_VALUE:now);
        if(report.rows.isEmpty()){
            Toast.makeText(this,"در بازه انتخابی تراکنشی برای خروجی وجود ندارد",Toast.LENGTH_LONG).show();
            return;
        }
        pendingReportPartyId=partyId;
        pendingReportDays=reportDays;
        Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType("text/csv");
        String suffix=reportDays==0?"all":String.valueOf(reportDays)+"days";
        String timestamp=new java.text.SimpleDateFormat("yyyyMMdd_HHmm",java.util.Locale.US).format(new java.util.Date(now));
        save.putExtra(Intent.EXTRA_TITLE,"Nexa_Ledger_"+(partyId==null?"All":"Party")+"_"+suffix+"_"+timestamp+".csv");
        try{startActivityForResult(save,REQUEST_LEDGER_CSV);}
        catch(Exception e){pendingReportPartyId=null;Toast.makeText(this,"برنامه‌ای برای ذخیره فایل پیدا نشد",Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_LEDGER_CSV)return;
        String partyId=pendingReportPartyId;
        int days=pendingReportDays;
        pendingReportPartyId=null;
        pendingReportDays=0;
        if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        Uri target=data.getData();
        long now=System.currentTimeMillis();
        LedgerReport.Result report=LedgerReport.generate(NexaStore.ledgerParties(this),NexaStore.ledgerEntries(this),
                partyId,LedgerReport.startMillis(days,now),days==0?Long.MAX_VALUE:now);
        try(OutputStream stream=getContentResolver().openOutputStream(target,"w")){
            if(stream==null)throw new java.io.IOException("No output stream");
            stream.write(LedgerReport.toCsv(report).getBytes(StandardCharsets.UTF_8));
            stream.flush();
            Toast.makeText(this,"گزارش ذخیره شد • "+report.rows.size()+" تراکنش",Toast.LENGTH_LONG).show();
        }catch(Exception e){
            Toast.makeText(this,"ذخیره گزارش ناموفق بود؛ فضای مقصد را بررسی کنید",Toast.LENGTH_LONG).show();
        }
    }

    private void editParty(NexaStore.LedgerParty old){
        LinearLayout box=UiKit.dialogPanel(this); EditText name=field("نام طرف‌حساب؛ مثلاً احمدی"); EditText phone=field("تلفن (اختیاری)"); EditText note=field("توضیحات");
        if(old!=null){name.setText(old.name);phone.setText(old.phone);note.setText(old.note);} box.addView(name);box.addView(phone);box.addView(note);
        new AlertDialog.Builder(this).setTitle(old==null?"طرف‌حساب جدید":"ویرایش طرف‌حساب").setView(box).setPositiveButton("ذخیره",(d,w)->{
            String n=name.getText().toString().trim(); if(n.isEmpty())return; NexaStore.LedgerParty p=old==null?new NexaStore.LedgerParty():old;
            p.name=n;p.phone=phone.getText().toString().trim();p.note=note.getText().toString().trim();NexaStore.upsertLedgerParty(this,p);render();
        }).setNegativeButton("انصراف",null).show();
    }

    private void deleteParty(NexaStore.LedgerParty p){
        int count=NexaStore.ledgerEntriesFor(this,p.id).size();
        new AlertDialog.Builder(this).setTitle("حذف طرف‌حساب؟").setMessage(p.name+(count>0?"\n"+count+" تراکنش این حساب نیز حذف می‌شود.":""))
                .setPositiveButton("حذف",(d,w)->{for(NexaStore.LedgerEntry x:NexaStore.ledgerEntriesFor(this,p.id))LinkedReminderHelper.remove(this,"ledger:"+x.id);NexaStore.removeLedgerParty(this,p.id);render();})
                .setNegativeButton("انصراف",null).show();
    }

    private String date(long ms){return PersianDateUtil.pretty(ms);}
    private int kindColor(String kind){
        if("DEBT".equals(kind)) return Color.rgb(239,83,80);       // red
        if("CREDIT".equals(kind)) return Color.rgb(38,198,218);   // cyan
        if("PAYMENT".equals(kind)) return Color.rgb(53,201,120);    // payment green
        return Color.rgb(102,187,106);                            // receipt green
    }

    private String kindLabel(String kind){return "DEBT".equals(kind)?"بدهی جدید":"CREDIT".equals(kind)?"طلب جدید":"PAYMENT".equals(kind)?"پرداخت کردم":"دریافت کردم";}

    private LinearLayout entryCard(NexaStore.LedgerParty p,NexaStore.LedgerEntry x,long running,Runnable refresh){
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(UiKit.dp(this,12),UiKit.dp(this,10),UiKit.dp(this,12),UiKit.dp(this,10));
        GradientDrawable bg=new GradientDrawable(); bg.setColor(Color.TRANSPARENT); bg.setCornerRadius(UiKit.dp(this,14)); bg.setStroke(UiKit.dp(this,2),kindColor(x.kind)); card.setBackground(bg);
        String due=x.dueMillis>0?"\nموعد: "+date(x.dueMillis)+(x.dueMillis<System.currentTimeMillis()?" • سررسید گذشته":""):""; TextView t=UiKit.muted(this,kindLabel(x.kind)+" • "+money(x.amount)+"\nثبت: "+date(x.dateMillis)+(x.note.isEmpty()?"":"\n"+x.note)+due+"\nمانده: "+state(running)); card.addView(t);
        LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.END);
        Button edit=UiKit.editIconButton(this); edit.setOnClickListener(v->editEntry(p,x,refresh)); actions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
        Button del=UiKit.deleteIconButton(this); del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف تراکنش؟").setMessage(kindLabel(x.kind)+" • "+money(x.amount)).setPositiveButton("حذف",(d,w)->{LinkedReminderHelper.remove(this,"ledger:"+x.id);NexaStore.removeLedgerEntry(this,x.id);refresh.run();render();}).setNegativeButton("انصراف",null).show()); LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)); dl.setMargins(UiKit.dp(this,6),0,0,0); actions.addView(del,dl);
        card.addView(actions); return card;
    }

    private void showParty(NexaStore.LedgerParty p){
        LinearLayout box=UiKit.dialogPanel(this); TextView bal=UiKit.sectionTitle(this,state(NexaStore.ledgerBalance(this,p.id))); box.addView(bal);
        Button export=UiKit.secondaryButton(this,"⇩ ذخیره گردش همین طرف‌حساب (CSV / بازه انتخابی)");
        export.setOnClickListener(v->exportLedger(p.id));box.addView(export,UiKit.matchWrap(this,0,8));
        Button add=UiKit.primaryButton(this,"＋ ثبت بدهی / طلب / پرداخت / دریافت"); box.addView(add,UiKit.matchWrap(this,0,8)); LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL); ScrollView txScroll=new ScrollView(this); txScroll.addView(rows); box.addView(txScroll,new LinearLayout.LayoutParams(-1,UiKit.dp(this,430)));
        final Runnable[] rr=new Runnable[1]; rr[0]=()->{
            rows.removeAllViews(); long running=0; List<NexaStore.LedgerEntry> all=NexaStore.ledgerEntriesFor(this,p.id); Collections.reverse(all);
            for(NexaStore.LedgerEntry x:all){running+=NexaStore.ledgerDelta(x); rows.addView(entryCard(p,x,running,rr[0]),UiKit.matchWrap(this,5,7));}
            if(all.isEmpty())rows.addView(UiKit.muted(this,"هنوز تراکنشی ثبت نشده.")); bal.setText(state(NexaStore.ledgerBalance(this,p.id)));
        };
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(p.name).setView(box).setPositiveButton("بستن",null).create(); add.setOnClickListener(v->editEntry(p,null,rr[0])); rr[0].run(); dialog.setOnDismissListener(x->render()); dialog.show();
    }

    private void attachGrouping(EditText amount){
        amount.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){}
            public void afterTextChanged(Editable e){
                if(formattingAmount)return; String raw=rawAmount(e.toString()); if(raw.isEmpty())return;
                try{long v=Long.parseLong(raw); String grouped=groupedMoney(v); if(!grouped.equals(e.toString())){formattingAmount=true; amount.setText(grouped); amount.setSelection(grouped.length()); formattingAmount=false;}}catch(Exception ignored){}
            }
        });
    }

    private void editEntry(NexaStore.LedgerParty p,NexaStore.LedgerEntry old,Runnable done){
        LinearLayout box=UiKit.dialogPanel(this); Spinner kind=UiKit.styledSpinner(this); String[] labels={"بدهی جدید (من بدهکارم)","طلب جدید (او به من بدهکار است)","پرداخت کردم","دریافت کردم"}; String[] kinds={"DEBT","CREDIT","PAYMENT","RECEIPT"};
        kind.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,labels)); EditText amount=field("مبلغ به تومان"); amount.setInputType(InputType.TYPE_CLASS_NUMBER); attachGrouping(amount); EditText note=field("شرح تراکنش"); final long[] dueMillis={old==null?0:old.dueMillis}; Button due=UiKit.secondaryButton(this,dueMillis[0]>0?"🕒 موعد: "+date(dueMillis[0]):"🕒 موعد / یادآور (اختیاری)"); due.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,dueMillis[0]>0?dueMillis[0]:System.currentTimeMillis()+3600000L,"موعد حساب",ms->{dueMillis[0]=ms;due.setText("🕒 موعد: "+date(ms));}));
        if(old!=null){for(int i=0;i<kinds.length;i++)if(kinds[i].equals(old.kind))kind.setSelection(i); amount.setText(groupedMoney(old.amount)); amount.setSelection(amount.length()); note.setText(old.note);}
        box.addView(kind);box.addView(amount);box.addView(note);box.addView(due);
        new AlertDialog.Builder(this).setTitle((old==null?"تراکنش جدید":"ویرایش تراکنش")+" • "+p.name).setView(box).setPositiveButton(old==null?"ثبت":"ذخیره",(d,w)->{
            long a=0;try{a=Long.parseLong(rawAmount(amount.getText().toString()));}catch(Exception ignored){} if(a<=0)return;
            NexaStore.LedgerEntry x=old==null?new NexaStore.LedgerEntry():old; x.partyId=p.id;x.amount=a;x.kind=kinds[kind.getSelectedItemPosition()];x.note=note.getText().toString().trim();x.dueMillis=dueMillis[0];
            if(old==null)NexaStore.addLedgerEntry(this,x);else NexaStore.updateLedgerEntry(this,x);
            if(x.dueMillis>System.currentTimeMillis())LinkedReminderHelper.upsert(this,"ledger:"+x.id,"موعد حساب • "+p.name,"حساب","💰",kindLabel(x.kind)+" • "+money(x.amount)+(x.note.isEmpty()?"":" • "+x.note),x.dueMillis,"60,0",5);else LinkedReminderHelper.remove(this,"ledger:"+x.id);
            NexaStore.addHistory(this,"حساب",p.name+" • "+labels[kind.getSelectedItemPosition()]+" • "+money(a)); done.run(); render();
        }).setNegativeButton("انصراف",null).show();
    }
}
