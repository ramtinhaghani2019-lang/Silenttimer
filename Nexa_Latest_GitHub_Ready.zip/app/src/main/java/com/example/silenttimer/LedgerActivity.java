package com.example.silenttimer;

import android.app.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.text.method.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class LedgerActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private EditText search;
    private boolean formattingAmount;
    private boolean newestFirst=true;
    private int historyDays=0; // Calendar days in each party's transaction list only.
    private int reportDays=0; // 0 = all, 30 or 90 = recent rolling days
    private TextView reportSummary;
    private static final int REQUEST_LEDGER_CSV=7532;
    private String pendingReportPartyId=null;
    private int pendingReportDays=0;


    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(b!=null){
            reportDays=b.getInt("ledger.reportDays",0);
            pendingReportDays=b.getInt("ledger.pendingDays",0);
            pendingReportPartyId=b.getString("ledger.pendingParty");
            newestFirst=b.getBoolean("ledger.newestFirst",true);
            historyDays=b.getInt("ledger.historyDays",0);
            if(historyDays!=0&&historyDays!=7&&historyDays!=30&&historyDays!=90)historyDays=0;
        }
        UiKit.applyWindow(this);build();
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putInt("ledger.reportDays",reportDays);
        state.putInt("ledger.pendingDays",pendingReportDays);
        state.putString("ledger.pendingParty",pendingReportPartyId);
        state.putBoolean("ledger.newestFirst",newestFirst);
        state.putInt("ledger.historyDays",historyDays);
        super.onSaveInstanceState(state);
    }
    private EditText field(String h){return UiKit.styleField(this,new EditText(this),h);}

    private void build(){
        ScrollView sc=new ScrollView(this); LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,30));
        root.setBackground(UiKit.screenBackground(this)); sc.addView(root);
        root.addView(UiKit.header(this,"⚖ بدهی‌ها و طلب‌ها",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"طرف‌حساب‌ها • تراکنش‌ها • مانده لحظه‌ای"),UiKit.matchWrap(this,0,8));root.addView(UiKit.featureHero(this,"ledger","حساب‌های من","بدهی، طلب، پرداخت و دریافت در یک نگاه"),UiKit.matchWrap(this,0,12));
        LinearLayout balanceCard=UiKit.accentCardLayout(this);balanceCard.addView(UiKit.sectionTitle(this,"💳 جمع‌بندی حساب‌ها"));summary=UiKit.sectionTitle(this,"");balanceCard.addView(summary,UiKit.matchWrap(this,6,0));root.addView(balanceCard,UiKit.matchWrap(this,0,12));
        LinearLayout reportCard=UiKit.colorfulCardLayout(this,2);
        reportCard.addView(UiKit.sectionTitle(this,"📊 گزارش حساب‌ها و خروجی CSV"));
        reportCard.addView(UiKit.muted(this,"دوره گزارش، فقط آمار و فایل خروجی را تغییر می‌دهد؛ مانده اصلی حساب‌ها دست‌نخورده می‌ماند."),UiKit.matchWrap(this,2,7));
        LinearLayout periods=new LinearLayout(this);periods.setGravity(Gravity.CENTER_VERTICAL);
        int[] choices={0,30,90};String[] labels={"همه","۳۰ روز","۹۰ روز"};
        for(int i=0;i<choices.length;i++){
            final int days=choices[i];Button button=UiKit.secondaryButton(this,labels[i]);
            button.setOnClickListener(v->{reportDays=days;render();});
            periods.addView(button,new LinearLayout.LayoutParams(0,-2,1f));
        }
        reportCard.addView(periods,UiKit.matchWrap(this,0,8));
        reportSummary=UiKit.muted(this,"");reportCard.addView(reportSummary,UiKit.matchWrap(this,2,8));
        Button export=UiKit.primaryButton(this,"⇩ ذخیره گردش تمام حساب‌ها (CSV)");
        export.setOnClickListener(v->exportLedger(null));
        reportCard.addView(export,UiKit.matchWrap(this,0,5));
        reportCard.addView(UiKit.muted(this,"⚠ فایل CSV رمزگذاری نشده است؛ فقط در محل امن ذخیره کن."),UiKit.matchWrap(this,6,0));
        root.addView(reportCard,UiKit.matchWrap(this,0,12));
        Button add=UiKit.primaryButton(this,"＋ طرف‌حساب جدید"); add.setOnClickListener(v->editParty(null)); root.addView(add,UiKit.matchWrap(this,0,8));
        search=field("جستجوی طرف‌حساب"); search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){render();} public void afterTextChanged(Editable e){}}); root.addView(search,UiKit.matchWrap(this,0,12));
        list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); root.addView(list); setContentView(sc); render();
    }

    private String money(long x){return groupedMoney(x==Long.MIN_VALUE?Long.MAX_VALUE:Math.abs(x))+" تومان";}
    private String groupedMoney(long x){return LedgerPresentation.persian(NumberFormatUtil.grouped(x));}
    private String formatUi(String text){return LedgerPresentation.persian(text);}
    private String state(long b){return b>0?"بستانکار • "+money(b):b<0?"بدهکار • "+money(b):"تسویه";}

    private void render(){
        list.removeAllViews(); List<NexaStore.LedgerParty> ps=NexaStore.ledgerParties(this); long receivable=0,debt=0;
        for(NexaStore.LedgerParty p:ps){long b=NexaStore.ledgerBalance(this,p.id);if(b>0)receivable+=b;else debt+=-b;}
        summary.setText("طلب من: "+money(receivable)+"\nبدهی من: "+money(debt)+"\nخالص: "+(receivable-debt>=0?"بستانکار ":"بدهکار ")+money(receivable-debt));
        long now=System.currentTimeMillis();
        LedgerReport.Result report=LedgerReport.generate(ps,NexaStore.ledgerEntries(this),null,LedgerReport.startMillis(reportDays,now),reportDays==0?Long.MAX_VALUE:now);
        String period=reportDays==0?"همه تراکنش‌ها":reportDays+" روز گذشته";
        reportSummary.setText(formatUi("گزارش همه طرف‌حساب‌ها • بازه: "+period+" • "+report.rows.size()+" تراکنش"
                +"\nبدهی جدید: "+money(report.debtAdded)+" • طلب جدید: "+money(report.creditAdded)
                +"\nپرداخت‌ها: "+money(report.paid)+" • دریافتی‌ها: "+money(report.received)
                +"\nتغییر خالص بازه: "+(report.periodChange>=0?"+":"")+NumberFormatUtil.grouped(report.periodChange)+" تومان"
                +"\nخالص حساب‌ها تا پایان بازه: "+NumberFormatUtil.grouped(report.closingNet)+" تومان"));
        reportSummary.setTextSize(15.5f);
        reportSummary.setTextColor(UiKit.TEXT);
        if(ps.isEmpty()){list.addView(UiKit.muted(this,"هنوز طرف‌حسابی ثبت نشده."));return;}
        String q=search==null?"":search.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
        int matchedParties=0;
        for(NexaStore.LedgerParty p:ps){
            if(!q.isEmpty() && !(p.name+" "+p.phone+" "+p.note).toLowerCase(java.util.Locale.ROOT).contains(q))continue;
            matchedParties++;
            long bal=NexaStore.ledgerBalance(this,p.id); LinearLayout c=UiKit.cardLayout(this); c.addView(UiKit.sectionTitle(this,p.name));
            TextView partyInfo=UiKit.muted(this,formatUi(state(bal)+" • "+NexaStore.ledgerEntriesFor(this,p.id).size()+" تراکنش"));
            partyInfo.setTextColor(UiKit.TEXT);partyInfo.setTextSize(15.5f);
            c.addView(partyInfo,UiKit.matchWrap(this,4,7));
            LinearLayout row=new LinearLayout(this); Button open=UiKit.primaryButton(this,"گردش حساب"); open.setOnClickListener(v->showParty(p)); row.addView(open,new LinearLayout.LayoutParams(0,-2,1f));
            Button edit=UiKit.editIconButton(this); edit.setOnClickListener(v->editParty(p)); row.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44))); Button del=UiKit.deleteIconButton(this); del.setOnClickListener(v->deleteParty(p)); row.addView(del,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44))); c.addView(row); list.addView(c,UiKit.matchWrap(this,0,7));
        }
        if(matchedParties==0)list.addView(UiKit.muted(this,"طرف‌حسابی با این عبارت پیدا نشد."));
    }

    private void exportLedger(String partyId){exportLedger(partyId,reportDays);}

    private void exportLedger(String partyId,int days){
        long now=System.currentTimeMillis();
        long start=partyId!=null&&days>0
            ?LedgerHistoryFilter.recentStart(days,now,TimeZone.getDefault())
            :LedgerReport.startMillis(days,now);
        LedgerReport.Result report=LedgerReport.generate(NexaStore.ledgerParties(this),NexaStore.ledgerEntries(this),
                partyId,start,days==0?Long.MAX_VALUE:now);
        if(report.rows.isEmpty()){
            Toast.makeText(this,"در بازه انتخابی تراکنشی برای خروجی وجود ندارد",Toast.LENGTH_LONG).show();
            return;
        }
        pendingReportPartyId=partyId;
        pendingReportDays=days;
        Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType("text/csv");
        String suffix=days==0?"all":String.valueOf(days)+"days";
        String timestamp=new java.text.SimpleDateFormat("yyyyMMdd_HHmm",java.util.Locale.US).format(new java.util.Date(now));
        save.putExtra(Intent.EXTRA_TITLE,"Nexa_Ledger_"+(partyId==null?"All":"Party")+"_"+suffix+"_"+timestamp+".csv");
        try{startActivityForResult(save,REQUEST_LEDGER_CSV);}
        catch(Exception e){pendingReportPartyId=null;Toast.makeText(this,"برنامه‌ای برای ذخیره فایل پیدا نشد",Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_LEDGER_CSV)return;
        String partyId=pendingReportPartyId;
        int days=pendingReportDays;
        pendingReportPartyId=null;
        pendingReportDays=0;
        if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        Uri target=data.getData();
        long now=System.currentTimeMillis();
        long start=partyId!=null&&days>0
            ?LedgerHistoryFilter.recentStart(days,now,TimeZone.getDefault())
            :LedgerReport.startMillis(days,now);
        LedgerReport.Result report=LedgerReport.generate(NexaStore.ledgerParties(this),NexaStore.ledgerEntries(this),
                partyId,start,days==0?Long.MAX_VALUE:now);
        try(OutputStream stream=getContentResolver().openOutputStream(target,"w")){
            if(stream==null)throw new java.io.IOException("No output stream");
            stream.write(LedgerReport.toCsv(report).getBytes(StandardCharsets.UTF_8));
            stream.flush();
            Toast.makeText(this,"گزارش ذخیره شد • "+report.rows.size()+" تراکنش",Toast.LENGTH_LONG).show();
        }catch(Exception e){
            Toast.makeText(this,"ذخیره گزارش ناموفق بود؛ فضای مقصد را بررسی کنید",Toast.LENGTH_LONG).show();
        }
    }

    private void editParty(NexaStore.LedgerParty old){
        LinearLayout box=UiKit.dialogPanel(this); EditText name=field("نام طرف‌حساب؛ مثلاً احمدی"); EditText phone=field("تلفن (اختیاری)"); EditText note=field("توضیحات");
        if(old!=null){name.setText(old.name);phone.setText(old.phone);note.setText(old.note);} box.addView(name);box.addView(phone);box.addView(note);
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle(old==null?"طرف‌حساب جدید":"ویرایش طرف‌حساب")
            .setView(box).setPositiveButton("ذخیره",null)
            .setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim();
            if(n.isEmpty()){name.setError("نام طرف‌حساب الزامی است");name.requestFocus();return;}
            NexaStore.LedgerParty person=old==null?new NexaStore.LedgerParty():old;
            person.name=n;person.phone=phone.getText().toString().trim();
            person.note=note.getText().toString().trim();
            NexaStore.upsertLedgerParty(this,person);render();dialog.dismiss();
        }));
        dialog.show();
    }

    private void deleteParty(NexaStore.LedgerParty p){
        int count=NexaStore.ledgerEntriesFor(this,p.id).size();
        new AlertDialog.Builder(this).setTitle("حذف طرف‌حساب؟").setMessage(p.name+(count>0?"\n"+count+" تراکنش این حساب نیز حذف می‌شود.":""))
                .setPositiveButton("حذف",(d,w)->{for(NexaStore.LedgerEntry x:NexaStore.ledgerEntriesFor(this,p.id))LinkedReminderHelper.remove(this,"ledger:"+x.id);NexaStore.removeLedgerParty(this,p.id);render();})
                .setNegativeButton("انصراف",null).show();
    }

    private String date(long ms){return PersianDateUtil.pretty(ms);}
    private String kindLabel(String kind){return LedgerPresentation.label(kind);}

    private void updateKindChoices(TextView[] views,int selected,TextView explanation){
        for(int i=0;i<views.length;i++){
            boolean active=i==selected;
            String code=LedgerPresentation.KINDS[i];int color=LedgerPresentation.color(code);
            TextView cell=views[i];
            cell.setText((active?"✓  ":"")+LedgerPresentation.shortLabel(code));
            cell.setTextColor(active?color:UiKit.TEXT);
            cell.setContentDescription(LedgerPresentation.label(code)+(active?"، انتخاب شده":""));
            GradientDrawable surface=new GradientDrawable();
            surface.setColor(active?0xFF183026:0xFF0D1E19);
            surface.setCornerRadius(UiKit.dp(this,14));
            surface.setStroke(UiKit.dp(this,active?2:1),color);
            cell.setBackground(surface);
        }
        explanation.setText(LedgerPresentation.help(LedgerPresentation.KINDS[selected]));
        explanation.setTextColor(LedgerPresentation.color(LedgerPresentation.KINDS[selected]));
    }

    /** Small transaction card: amount, time and running balance remain visible; tools stay accessible. */
    private LinearLayout entryCard(NexaStore.LedgerParty p,NexaStore.LedgerEntry x,long running,Runnable refresh){
        int accent=LedgerPresentation.color(x.kind);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(UiKit.dp(this,10),UiKit.dp(this,7),UiKit.dp(this,8),UiKit.dp(this,7));
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF10211C);
        bg.setCornerRadius(UiKit.dp(this,13));bg.setStroke(UiKit.dp(this,1),accent);card.setBackground(bg);

        LinearLayout content=new LinearLayout(this);
        content.setGravity(Gravity.CENTER_VERTICAL);content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView kind=UiKit.sectionTitle(this,LedgerPresentation.shortLabel(x.kind));
        kind.setTextColor(accent);kind.setTextSize(15f);
        top.addView(kind,new LinearLayout.LayoutParams(0,-2,1f));
        TextView amount=UiKit.sectionTitle(this,formatUi(money(x.amount)));
        amount.setTextColor(accent);amount.setTextSize(15f);
        amount.setGravity(Gravity.LEFT);top.addView(amount);
        info.addView(top);

        // The calendar day is shown once as a group heading; only the transaction time repeats.
        String details="ساعت "+LedgerCompactUi.timeOnly(x.dateMillis)+" • مانده: "+state(running);
        TextView meta=UiKit.muted(this,formatUi(details));meta.setTextColor(UiKit.TEXT);
        meta.setTextSize(12.5f);meta.setMaxLines(2);
        info.addView(meta,UiKit.matchWrap(this,3,0));
        if(x.note!=null && !x.note.isEmpty()){
            TextView note=UiKit.muted(this,"شرح: "+x.note);
            note.setTextSize(12.5f);note.setMaxLines(2);
            note.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(note,UiKit.matchWrap(this,2,0));
        }
        if(x.dueMillis>0){
            TextView due=UiKit.muted(this,formatUi("موعد: "+date(x.dueMillis)
                    +(x.dueMillis<System.currentTimeMillis()?" • گذشته":"")
                    +ReminderRecurrence.labelSuffix(x.dueRecurrence)));
            due.setTextSize(12f);due.setMaxLines(2);
            info.addView(due,UiKit.matchWrap(this,2,0));
        }
        content.addView(info,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.VERTICAL);
        Button edit=UiKit.editIconButton(this);edit.setContentDescription("ویرایش "+kindLabel(x.kind));
        edit.setOnClickListener(v->editEntry(p,x,refresh));
        actions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        Button del=UiKit.deleteIconButton(this);del.setContentDescription("حذف "+kindLabel(x.kind));
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف تراکنش؟")
            .setMessage(kindLabel(x.kind)+" • "+money(x.amount))
            .setPositiveButton("حذف",(d,w)->{LinkedReminderHelper.remove(this,"ledger:"+x.id);
                NexaStore.removeLedgerEntry(this,x.id);refresh.run();render();})
            .setNegativeButton("انصراف",null).show());
        LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        dl.topMargin=UiKit.dp(this,1);actions.addView(del,dl);
        LinearLayout.LayoutParams actionParams=new LinearLayout.LayoutParams(-2,-2);
        actionParams.setMargins(UiKit.dp(this,5),0,0,0);
        content.addView(actions,actionParams);
        card.addView(content);
        return card;
    }

    private void showParty(NexaStore.LedgerParty p){
        LinearLayout box=UiKit.dialogPanel(this);
        box.setPadding(UiKit.dp(this,11),UiKit.dp(this,9),UiKit.dp(this,11),UiKit.dp(this,8));
        TextView bal=UiKit.sectionTitle(this,formatUi(state(NexaStore.ledgerBalance(this,p.id))));
        bal.setTextSize(16f);box.addView(bal,UiKit.matchWrap(this,0,4));

        final String[] selectedKind={LedgerHistoryFilter.ALL};
        final int[] displayLimit={40};
        TextView[] filterChoices=new TextView[LedgerHistoryFilter.KINDS.length];
        final int[] dateChoices={0,7,30,90};
        final String[] dateLabels={"همه تاریخ‌ها","۷ روز","۳۰ روز","۹۰ روز"};
        TextView[] dateChips=new TextView[dateChoices.length];

        // Primary actions occupy a single compact row. Advanced controls are hidden by default.
        LinearLayout toolbar=new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button add=UiKit.primaryButton(this,"＋ ثبت");
        add.setTextSize(13f);add.setContentDescription("ثبت بدهی، طلب، پرداخت یا دریافت جدید");
        toolbar.addView(add,new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f));
        Button filterToggle=UiKit.secondaryButton(this,"☷ فیلتر");
        filterToggle.setTextSize(12.5f);filterToggle.setContentDescription("بازکردن تنظیمات جستجو، فیلتر و خروجی CSV");
        LinearLayout.LayoutParams fl=new LinearLayout.LayoutParams(UiKit.dp(this,86),UiKit.dp(this,48));
        fl.setMargins(UiKit.dp(this,4),0,0,0);toolbar.addView(filterToggle,fl);
        Button order=UiKit.secondaryButton(this,"");order.setTextSize(12f);
        LinearLayout.LayoutParams ol=new LinearLayout.LayoutParams(UiKit.dp(this,94),UiKit.dp(this,48));
        ol.setMargins(UiKit.dp(this,4),0,0,0);toolbar.addView(order,ol);
        box.addView(toolbar,UiKit.matchWrap(this,0,3));

        TextView activeFilters=UiKit.muted(this,"");
        activeFilters.setTextSize(12f);activeFilters.setTextColor(UiKit.GOLD);
        activeFilters.setMaxLines(1);activeFilters.setEllipsize(android.text.TextUtils.TruncateAt.END);
        activeFilters.setClickable(true);box.addView(activeFilters,UiKit.matchWrap(this,0,3));

        LinearLayout advancedFilters=new LinearLayout(this);
        advancedFilters.setOrientation(LinearLayout.VERTICAL);
        advancedFilters.setPadding(UiKit.dp(this,12),UiKit.dp(this,6),UiKit.dp(this,12),UiKit.dp(this,12));
        advancedFilters.setTag("nexa_ledger_advanced_filters");
        TextView filterTitle=UiKit.fieldLabel(this,"نوع تراکنش");
        advancedFilters.addView(filterTitle,UiKit.matchWrap(this,4,2));
        LinearLayout filterBar=new LinearLayout(this);
        filterBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<filterChoices.length;i++){
            TextView chip=new TextView(this);chip.setGravity(Gravity.CENTER);
            chip.setTextSize(13f);chip.setMinHeight(UiKit.dp(this,40));
            chip.setPadding(UiKit.dp(this,11),UiKit.dp(this,6),UiKit.dp(this,11),UiKit.dp(this,6));
            chip.setClickable(true);chip.setFocusable(true);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);
            cp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
            filterBar.addView(chip,cp);filterChoices[i]=chip;
        }
        HorizontalScrollView filterScroll=new HorizontalScrollView(this);
        filterScroll.setHorizontalScrollBarEnabled(false);filterScroll.addView(filterBar);
        advancedFilters.addView(filterScroll,UiKit.matchWrap(this,1,3));
        TextView dateLabel=UiKit.fieldLabel(this,"بازه تاریخ");
        advancedFilters.addView(dateLabel,UiKit.matchWrap(this,4,2));
        LinearLayout dateFilters=new LinearLayout(this);
        dateFilters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<dateChoices.length;i++){
            TextView chip=new TextView(this);chip.setGravity(Gravity.CENTER);
            chip.setTextSize(13f);chip.setMinHeight(UiKit.dp(this,40));
            chip.setPadding(UiKit.dp(this,11),UiKit.dp(this,6),UiKit.dp(this,11),UiKit.dp(this,6));
            chip.setClickable(true);chip.setFocusable(true);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);
            cp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
            dateFilters.addView(chip,cp);dateChips[i]=chip;
        }
        HorizontalScrollView dateScroll=new HorizontalScrollView(this);
        dateScroll.setHorizontalScrollBarEnabled(false);dateScroll.addView(dateFilters);
        advancedFilters.addView(dateScroll,UiKit.matchWrap(this,1,5));
        EditText transactionSearch=field("جستجوی شرح، مبلغ یا نوع تراکنش");
        transactionSearch.setSingleLine(true);
        advancedFilters.addView(transactionSearch,UiKit.matchWrap(this,0,5));
        LinearLayout extras=new LinearLayout(this);extras.setGravity(Gravity.CENTER_VERTICAL);
        Button clear=UiKit.secondaryButton(this,"پاک‌کردن فیلترها");clear.setTextSize(12.5f);
        Button export=UiKit.secondaryButton(this,"⇩ خروجی CSV");export.setTextSize(12.5f);
        export.setOnClickListener(v->exportLedger(p.id,historyDays));
        extras.addView(clear,new LinearLayout.LayoutParams(0,UiKit.dp(this,43),1f));
        LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(0,UiKit.dp(this,43),1f);
        xp.setMargins(UiKit.dp(this,5),0,0,0);extras.addView(export,xp);
        advancedFilters.addView(extras,UiKit.matchWrap(this,2,4));
        // Filter controls live in a separate scrollable panel, never above the transaction list.
        ScrollView optionsScroll=new ScrollView(this);
        optionsScroll.setFillViewport(false);
        optionsScroll.addView(advancedFilters);
        AlertDialog optionsDialog=new AlertDialog.Builder(this)
            .setTitle("فیلترها و خروجی حساب")
            .setView(optionsScroll)
            .setPositiveButton("بازگشت به گردش",null).create();

        TextView visibleCount=UiKit.muted(this,"");visibleCount.setTextSize(12.5f);
        box.addView(visibleCount,UiKit.matchWrap(this,1,3));
        LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView txScroll=new ScrollView(this);txScroll.setFillViewport(false);
        txScroll.setTag("nexa_ledger_transaction_list");
        txScroll.addView(rows);
        int safeHeight=Math.max(UiKit.dp(this,200),Math.min(UiKit.dp(this,540),
            (int)(getResources().getDisplayMetrics().heightPixels*0.58f)));
        box.addView(txScroll,new LinearLayout.LayoutParams(-1,safeHeight));

        final Runnable[] refresh=new Runnable[1];
        refresh[0]=()->{
            rows.removeAllViews();
            LedgerReport.Result report=LedgerReport.generate(Collections.singletonList(p),
                NexaStore.ledgerEntriesFor(this,p.id),p.id,Long.MIN_VALUE,Long.MAX_VALUE);
            // Chronology is always based on dateMillis, not entry insertion time.
            // Running balances are calculated from the unfiltered account history.
            long now=System.currentTimeMillis();
            long from=LedgerHistoryFilter.recentStart(historyDays,now,TimeZone.getDefault());
            List<LedgerReport.Row> ordered=LedgerReport.orderedRows(
                LedgerHistoryFilter.selectBetween(report.rows,selectedKind[0],
                    transactionSearch.getText().toString(),from,historyDays==0?Long.MAX_VALUE:now),
                newestFirst);
            order.setText(LedgerCompactUi.sortLabel(newestFirst));
            order.setContentDescription(newestFirst?"مرتب‌سازی جدیدترین اول؛ تغییر به قدیمی‌ترین":"مرتب‌سازی قدیمی‌ترین اول؛ تغییر به جدیدترین");
            boolean filtered=LedgerCompactUi.hasActiveFilters(selectedKind[0],historyDays,
                    transactionSearch.getText().toString());
            String currentFilter=LedgerCompactUi.activeSummary(selectedKind[0],historyDays,
                    transactionSearch.getText().toString());
            activeFilters.setText(formatUi(currentFilter));
            activeFilters.setVisibility(filtered?View.VISIBLE:View.GONE);
            filterToggle.setText(filtered?"☷ فعال":"☷ فیلتر");
            filterToggle.setTextColor(filtered?UiKit.GOLD:UiKit.TEXT);
            int shown=Math.min(ordered.size(),displayLimit[0]);
            visibleCount.setText(formatUi(shown+" از "+ordered.size()+" تراکنش"
                    +(filtered?" • کل حساب: "+report.rows.size():"")));
            int previousDay=Integer.MIN_VALUE;
            TimeZone timezone=TimeZone.getDefault();
            for(int i=0;i<shown;i++){
                LedgerReport.Row row=ordered.get(i);
                int thisDay=LedgerHistoryFilter.dayKey(row.entry.dateMillis,timezone);
                if(thisDay!=previousDay){
                    TextView dateDivider=UiKit.muted(this,formatUi(LedgerCompactUi.dayHeading(row.entry.dateMillis)));
                    dateDivider.setTextSize(12.5f);dateDivider.setTextColor(UiKit.GOLD);
                    rows.addView(dateDivider,UiKit.matchWrap(this,5,2));
                    previousDay=thisDay;
                }
                rows.addView(entryCard(p,row.entry,row.runningBalance,refresh[0]),UiKit.matchWrap(this,1,4));
            }
            if(shown<ordered.size()){
                Button more=UiKit.secondaryButton(this,formatUi("نمایش بیشتر ("+(ordered.size()-shown)+" مورد)"));
                more.setOnClickListener(v->{displayLimit[0]=Math.min(ordered.size(),shown+40);refresh[0].run();});
                rows.addView(more,UiKit.matchWrap(this,5,3));
            }
            if(ordered.isEmpty())rows.addView(UiKit.muted(this,report.rows.isEmpty()
                ?"هنوز تراکنشی ثبت نشده.":"تراکنشی با این جستجو یا فیلتر پیدا نشد."));
            bal.setText(formatUi(state(NexaStore.ledgerBalance(this,p.id))));
        };
        for(int i=0;i<filterChoices.length;i++){
            final int index=i;
            filterChoices[i].setOnClickListener(v->{
                selectedKind[0]=LedgerHistoryFilter.KINDS[index];displayLimit[0]=40;
                updateHistoryFilterChoices(filterChoices,selectedKind[0]);refresh[0].run();
            });
        }
        updateHistoryFilterChoices(filterChoices,selectedKind[0]);
        final Runnable[] updateDateChoices={null};
        updateDateChoices[0]=()->{
            for(int i=0;i<dateChips.length;i++){
                boolean active=historyDays==dateChoices[i];
                TextView chip=dateChips[i];
                chip.setText((active?"✓  ":"")+dateLabels[i]);
                chip.setTextColor(active?UiKit.GOLD:UiKit.TEXT);
                chip.setContentDescription(dateLabels[i]+(active?"، انتخاب شده":""));
                GradientDrawable bg=new GradientDrawable();
                bg.setColor(active?0xFF193029:0xFF0D1E19);
                bg.setCornerRadius(UiKit.dp(this,14));
                bg.setStroke(UiKit.dp(this,active?2:1),UiKit.GOLD);
                chip.setBackground(bg);
                final int choice=dateChoices[i];
                chip.setOnClickListener(v->{
                    historyDays=choice;displayLimit[0]=40;
                    updateDateChoices[0].run();refresh[0].run();
                });
            }
        };
        updateDateChoices[0].run();
        transactionSearch.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){
                displayLimit[0]=40;refresh[0].run();}
            public void afterTextChanged(Editable e){}
        });
        filterToggle.setOnClickListener(v->optionsDialog.show());
        activeFilters.setOnClickListener(v->optionsDialog.show());
        clear.setOnClickListener(v->{
            selectedKind[0]=LedgerHistoryFilter.ALL;historyDays=0;displayLimit[0]=40;
            transactionSearch.setText("");updateHistoryFilterChoices(filterChoices,selectedKind[0]);
            updateDateChoices[0].run();refresh[0].run();
        });
        order.setOnClickListener(v->{newestFirst=!newestFirst;displayLimit[0]=40;refresh[0].run();});
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(p.name).setView(box)
            .setPositiveButton("بستن",null).create();
        add.setOnClickListener(v->editEntry(p,null,refresh[0]));
        refresh[0].run();dialog.setOnDismissListener(x->render());dialog.show();
    }

    private void updateHistoryFilterChoices(TextView[] views,String selected) {
        for(int i=0;i<views.length;i++){
            String kind=LedgerHistoryFilter.KINDS[i];
            boolean active=kind.equals(selected);
            int accent=LedgerHistoryFilter.ALL.equals(kind)?0xFFE1C16E:LedgerPresentation.color(kind);
            TextView chip=views[i];
            chip.setText((active?"✓  ":"")+(LedgerHistoryFilter.ALL.equals(kind)?"همه":LedgerPresentation.shortLabel(kind)));
            chip.setTextColor(active?accent:UiKit.TEXT);
            chip.setContentDescription(chip.getText()+(active?"، انتخاب شده":""));
            GradientDrawable bg=new GradientDrawable();
            bg.setColor(active?0xFF193029:0xFF0D1E19);
            bg.setCornerRadius(UiKit.dp(this,14));
            bg.setStroke(UiKit.dp(this,active?2:1),accent);
            chip.setBackground(bg);
        }
    }

    private void attachGrouping(EditText amount){
        amount.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){}
            public void afterTextChanged(Editable e){
                if(formattingAmount)return; String raw=NumberFormatUtil.toLatin(e.toString()).replace(",","").replace("٬","").trim(); if(raw.isEmpty())return;
                try{long v=Long.parseLong(raw); String grouped=groupedMoney(v);
                    if(!grouped.equals(e.toString())){formattingAmount=true;
                        try{amount.setText(grouped);amount.setSelection(grouped.length());}
                        finally{formattingAmount=false;}}}catch(NumberFormatException ignored){}
            }
        });
    }

    private void editEntry(NexaStore.LedgerParty p,NexaStore.LedgerEntry old,Runnable done){
        LinearLayout box=UiKit.dialogPanel(this);
        TextView typeTitle=UiKit.fieldLabel(this,"نوع تراکنش");typeTitle.setTextSize(15f);box.addView(typeTitle);
        final int[] selected={0};
        if(old!=null)for(int i=0;i<LedgerPresentation.KINDS.length;i++)
            if(LedgerPresentation.KINDS[i].equals(old.kind))selected[0]=i;
        TextView[] choices=new TextView[4];
        for(int row=0;row<2;row++){
            LinearLayout choiceRow=new LinearLayout(this);choiceRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            for(int col=0;col<2;col++){
                int index=row*2+col;TextView choice=new TextView(this);
                choice.setTextSize(16.5f);choice.setGravity(Gravity.CENTER);choice.setMinHeight(UiKit.dp(this,53));
                choice.setPadding(UiKit.dp(this,4),UiKit.dp(this,10),UiKit.dp(this,4),UiKit.dp(this,10));
                choice.setClickable(true);choice.setFocusable(true);choices[index]=choice;
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1f);
                cp.setMargins(UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3));
                choiceRow.addView(choice,cp);
            }
            box.addView(choiceRow,UiKit.matchWrap(this,2,0));
        }
        TextView explanation=UiKit.muted(this,"");explanation.setTextSize(15f);
        box.addView(explanation,UiKit.matchWrap(this,5,9));
        for(int i=0;i<choices.length;i++){
            final int index=i;choices[i].setOnClickListener(v->{selected[0]=index;
                updateKindChoices(choices,index,explanation);});
        }
        updateKindChoices(choices,selected[0],explanation);
        EditText amount=field("مبلغ به تومان");amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setTextSize(17f);attachGrouping(amount);
        EditText note=field("شرح تراکنش (اختیاری)");note.setTextSize(16f);
        // Recorded date determines chronological order and historical running balances.
        final long[] entryDateMillis={old==null?System.currentTimeMillis():old.dateMillis};
        Button entryDate=UiKit.secondaryButton(this,"📅 تاریخ تراکنش: "+date(entryDateMillis[0]));
        entryDate.setContentDescription("انتخاب تاریخ و ساعت تراکنش برای مرتب‌سازی گردش حساب");
        entryDate.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,entryDateMillis[0],
            "تاریخ و ساعت تراکنش",ms->{entryDateMillis[0]=ms;
                entryDate.setText("📅 تاریخ تراکنش: "+date(ms));}));
        final long[] dueMillis={old==null?0:old.dueMillis};
        Button due=UiKit.secondaryButton(this,dueMillis[0]>0?"🕒 موعد: "+date(dueMillis[0]):"🕒 موعد / یادآور (اختیاری)");
        Button clearDue=UiKit.secondaryButton(this,"✕ حذف موعد ثبت‌شده");
        clearDue.setVisibility(dueMillis[0]>0?View.VISIBLE:View.GONE);
        clearDue.setOnClickListener(v->{
            dueMillis[0]=0;due.setText("🕒 موعد / یادآور (اختیاری)");
            clearDue.setVisibility(View.GONE);
        });
        due.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,
            dueMillis[0]>0?dueMillis[0]:System.currentTimeMillis()+3600000L,
            "موعد حساب",ms->{dueMillis[0]=ms;due.setText("🕒 موعد: "+date(ms));
                clearDue.setVisibility(View.VISIBLE);}));
        if(old!=null){amount.setText(groupedMoney(old.amount));amount.setSelection(amount.length());
            note.setText(old.note);}
        box.addView(amount,UiKit.matchWrap(this,0,7));
        box.addView(note,UiKit.matchWrap(this,0,7));
        box.addView(entryDate,UiKit.matchWrap(this,0,7));
        box.addView(due,UiKit.matchWrap(this,0,0));
        box.addView(clearDue,UiKit.matchWrap(this,4,0));
        // Repeat the repayment/collection reminder, never duplicate the financial transaction.
        RepeatIntervalPicker ledgerRepeat=new RepeatIntervalPicker(this,box,old==null?"none":old.dueRecurrence);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle((old==null?"تراکنش جدید":"ویرایش تراکنش")+" • "+p.name)
            .setView(scroll).setPositiveButton(old==null?"ثبت":"ذخیره",null)
            .setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            long value=LedgerPresentation.positiveAmount(amount.getText().toString());
            if(value<=0){amount.setError("مبلغ معتبر و بزرگ‌تر از صفر وارد کنید");
                amount.requestFocus();return;}
            String kind=LedgerPresentation.KINDS[selected[0]];
            NexaStore.LedgerEntry x=old==null?new NexaStore.LedgerEntry():old;
            x.partyId=p.id;x.amount=value;x.kind=kind;
            x.dateMillis=entryDateMillis[0];
            x.note=note.getText().toString().trim();x.dueMillis=dueMillis[0];x.dueRecurrence=ledgerRepeat.rule();
            if(old==null)NexaStore.addLedgerEntry(this,x);else NexaStore.updateLedgerEntry(this,x);
            if(x.dueMillis>System.currentTimeMillis()){
                LinkedReminderHelper.upsert(this,"ledger:"+x.id,"موعد حساب • "+p.name,
                    "حساب","💰",kindLabel(x.kind)+" • "+money(x.amount)
                    +(x.note.isEmpty()?"":" • "+x.note),x.dueMillis,"60,0",5,x.dueRecurrence);
            }else LinkedReminderHelper.remove(this,"ledger:"+x.id);
            NexaStore.addHistory(this,"حساب",p.name+" • "+kindLabel(kind)+" • "+money(value));
            done.run();render();dialog.dismiss();
        }));
        dialog.show();
    }
}
