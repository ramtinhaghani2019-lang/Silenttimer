package com.example.silenttimer;

import android.app.*;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.text.*;
import android.text.method.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class LedgerActivity extends Activity {
    public static final String EXTRA_OPEN_PARTY_ID="nexa.open_ledger_party_id";
    private LinearLayout list;
    private TextView summary;
    private TextView receivableMetric;
    private TextView debtMetric;
    private EditText search;
    private String savedSearch="";
    private boolean reportExpanded=false;
    private LinearLayout reportPanel;
    private boolean formattingAmount;
    private boolean newestFirst=true;
    // Only affects the party list, never the financial totals or stored entries.
    private String balanceFilter="all";
    private LinearLayout balanceFilterRow;
    private TextView partyCounter;
    private int historyDays=0; // Calendar days in each party's transaction list only.
    private int reportDays=0; // 0 = all, 30 or 90 = recent rolling days
    private TextView reportSummary;
    private static final int REQUEST_LEDGER_CSV=7532;
    private String pendingReportPartyId=null;
    private int pendingReportDays=0;


    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        if(b!=null){
            reportDays=b.getInt("ledger.reportDays",0);
            pendingReportDays=b.getInt("ledger.pendingDays",0);
            pendingReportPartyId=b.getString("ledger.pendingParty");
            newestFirst=b.getBoolean("ledger.newestFirst",true);
            historyDays=b.getInt("ledger.historyDays",0);
            savedSearch=b.getString("ledger.search","");
            reportExpanded=b.getBoolean("ledger.reportExpanded",false);
            balanceFilter=b.getString("ledger.balanceFilter","all");
            if(!LedgerPartyFilters.valid(balanceFilter))balanceFilter="all";
            if(historyDays!=0&&historyDays!=7&&historyDays!=30&&historyDays!=90)historyDays=0;
        }
        UiKit.applyWindow(this);build();
        if(b==null && getIntent()!=null){
            String directId=getIntent().getStringExtra(EXTRA_OPEN_PARTY_ID);
            if(directId!=null && !directId.isEmpty()){
                for(NexaStore.LedgerParty p:NexaStore.ledgerParties(this)){
                    if(directId.equals(p.id)){
                        showParty(p); // Navigational read only; opening search does not create a transaction.
                        break;
                    }
                }
            }
        }
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putString("ledger.search",search==null?savedSearch:search.getText().toString());
        state.putBoolean("ledger.reportExpanded",reportExpanded);
        state.putString("ledger.balanceFilter",balanceFilter);
        state.putInt("ledger.reportDays",reportDays);
        state.putInt("ledger.pendingDays",pendingReportDays);
        state.putString("ledger.pendingParty",pendingReportPartyId);
        state.putBoolean("ledger.newestFirst",newestFirst);
        state.putInt("ledger.historyDays",historyDays);
        super.onSaveInstanceState(state);
    }
    private EditText field(String h){return UiKit.styleField(this,new EditText(this),h);}

    private void build(){
        ScrollView sc=new ScrollView(this); LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(UiKit.dp(this,16),UiKit.dp(this,16),UiKit.dp(this,16),UiKit.dp(this,32));
        root.setBackground(UiKit.screenBackground(this));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sc.addView(root);
        root.addView(UiKit.header(this,"⚖ بدهی‌ها و طلب‌ها",v->finish()),UiKit.matchWrap(this,0,4));

        TextView intro=UiKit.muted(this,"مانده‌های واقعی طرف‌حساب‌ها، ثبت و گردش تراکنش‌ها");
        intro.setTextSize(12f);
        root.addView(intro,UiKit.matchWrap(this,0,10));
        LinearLayout metrics=new LinearLayout(this);
        metrics.setOrientation(HomeUi.compactGridNeedsStack(this)?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        metrics.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout credit=UiKit.financialMetric(this,"🟡 طلب‌های من","۰ تومان",UiKit.GOLD);
        LinearLayout debt=UiKit.financialMetric(this,"🔴 بدهی‌های من","۰ تومان",UiKit.RED);
        receivableMetric=(TextView)credit.getChildAt(1);
        debtMetric=(TextView)debt.getChildAt(1);
        if(metrics.getOrientation()==LinearLayout.VERTICAL){
            metrics.addView(credit,UiKit.matchWrap(this,0,8));
            metrics.addView(debt,UiKit.matchWrap(this,0,0));
        }else{
            LinearLayout.LayoutParams first=new LinearLayout.LayoutParams(0,-2,1f);
            first.setMargins(0,0,UiKit.dp(this,6),0);
            metrics.addView(credit,first);
            metrics.addView(debt,new LinearLayout.LayoutParams(0,-2,1f));
        }
        root.addView(metrics,UiKit.matchWrap(this,0,9));
        LinearLayout balanceCard=HomeUi.panel(this,false);
        TextView netLabel=HomeUi.secondary(this,"خالص حساب‌ها");
        netLabel.setTextColor(UiKit.GOLD);
        balanceCard.addView(netLabel,UiKit.matchWrap(this,0,2));
        summary=HomeUi.heading(this,"");
        summary.setTextSize(16f);
        summary.setMaxLines(2);
        summary.setAutoSizeTextTypeUniformWithConfiguration(12,16,1,
                TextView.AUTO_SIZE_TEXT_TYPE_UNIFORM);
        balanceCard.addView(summary);
        root.addView(balanceCard,UiKit.matchWrap(this,0,10));
        LinearLayout reportCard=UiKit.colorfulCardLayout(this,2);
        reportCard.addView(UiKit.sectionTitle(this,"📊 گزارش حساب‌ها و خروجی CSV"));

        LinearLayout periods=new LinearLayout(this);periods.setGravity(Gravity.CENTER_VERTICAL);
        int[] choices={0,30,90};String[] labels={"همه","۳۰ روز","۹۰ روز"};
        for(int i=0;i<choices.length;i++){
            final int days=choices[i];Button button=UiKit.secondaryButton(this,labels[i]);
            button.setOnClickListener(v->{reportDays=days;render();});
            periods.addView(button,new LinearLayout.LayoutParams(0,-2,1f));
        }
        reportCard.addView(periods,UiKit.matchWrap(this,0,8));
        reportSummary=UiKit.muted(this,"");reportCard.addView(reportSummary,UiKit.matchWrap(this,2,8));
        Button export=UiKit.primaryButton(this,"⇩ ذخیره گردش تمام حساب‌ها (CSV)");
        export.setOnClickListener(v->exportLedger(null));
        reportCard.addView(export,UiKit.matchWrap(this,0,5));
        // Advanced reporting is available on demand, never above the account list by default.
        Button showReport=UiKit.secondaryButton(this,"گزارش و خروجی  ▾");
        reportPanel=reportCard;
        reportCard.setVisibility(reportExpanded?View.VISIBLE:View.GONE);
        showReport.setText(reportExpanded?"بستن گزارش  ▴":"گزارش و خروجی  ▾");
        showReport.setOnClickListener(v->{boolean expand=reportCard.getVisibility()!=View.VISIBLE;
            reportExpanded=expand;
            reportCard.setVisibility(expand?View.VISIBLE:View.GONE);
            showReport.setText(expand?"بستن گزارش  ▴":"گزارش و خروجی  ▾");});
        LinearLayout listHeading=new LinearLayout(this);
        listHeading.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        listHeading.setGravity(Gravity.CENTER_VERTICAL);
        TextView heading=HomeUi.sectionLabel(this,"طرف‌حساب‌ها");
        listHeading.addView(heading,new LinearLayout.LayoutParams(0,-2,1f));
        partyCounter=HomeUi.secondary(this,"");
        listHeading.addView(partyCounter);
        root.addView(listHeading,UiKit.matchWrap(this,5,7));
        LinearLayout tools=new LinearLayout(this);tools.setGravity(Gravity.CENTER_VERTICAL);
        tools.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        search=field("🔎 جست‌وجوی نام یا شماره تماس");
        search.setSingleLine(true);
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.setText(savedSearch);
        search.setOnEditorActionListener((v,action,event)->{
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){
                ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(search.getWindowToken(),0);
                search.clearFocus();return true;
            }return false;
        });
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){} public void onTextChanged(CharSequence s,int a,int b,int c){render();} public void afterTextChanged(Editable e){}});
        tools.addView(search,new LinearLayout.LayoutParams(0,-2,1f));
        Button add=UiKit.primaryButton(this,"＋ افزودن");add.setContentDescription("افزودن طرف‌حساب جدید");add.setOnClickListener(v->editParty(null));
        LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(-2,UiKit.dp(this,48));ap.setMargins(UiKit.dp(this,8),0,0,0);tools.addView(add,ap);
        root.addView(tools,UiKit.matchWrap(this,0,8));
        balanceFilterRow=new LinearLayout(this);
        balanceFilterRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        balanceFilterRow.setGravity(Gravity.CENTER_VERTICAL);
        HorizontalScrollView filterScroll=new HorizontalScrollView(this);
        filterScroll.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        filterScroll.setHorizontalScrollBarEnabled(false);
        filterScroll.addView(balanceFilterRow);
        root.addView(filterScroll,UiKit.matchWrap(this,0,8));
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list,UiKit.matchWrap(this,0,9));
        // Detailed CSV tools are still present, but do not push accounts below the fold.
        root.addView(showReport,UiKit.matchWrap(this,2,5));
        root.addView(reportCard,UiKit.matchWrap(this,0,6));
        LinearLayout screen=new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout bottom=UiKit.referenceBottomNav(this,2);
        LinearLayout.LayoutParams np=UiKit.matchWrap(this);
        np.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,12),UiKit.dp(this,9));
        screen.addView(bottom,np);
        setContentView(screen);
        render();
    }

    private String money(long x){return groupedMoney(x==Long.MIN_VALUE?Long.MAX_VALUE:Math.abs(x))+" تومان";}
    private String groupedMoney(long x){return LedgerPresentation.persian(NumberFormatUtil.grouped(x));}
    private String formatUi(String text){return LedgerPresentation.persian(text);}
    private String state(long b){return b>0?"بستانکار • "+money(b):b<0?"بدهکار • "+money(b):"تسویه";}

    /** Highlights the amount and label together, without changing ledger arithmetic. */
    private void colorBalanceSegment(android.text.SpannableString result,String text,String start,String end,int color){
        int at=text.indexOf(start);if(at<0)return;
        int last=end==null?text.length():text.indexOf(end,at+start.length());
        if(last<0)last=text.length();
        result.setSpan(new android.text.style.ForegroundColorSpan(color),at,last,
            android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
    }

    private void render(){
        list.removeAllViews(); List<NexaStore.LedgerParty> ps=NexaStore.ledgerParties(this); long receivable=0,debt=0;
        for(NexaStore.LedgerParty p:ps){long b=NexaStore.ledgerBalance(this,p.id);if(b>0)receivable+=b;else debt+=-b;}
        String netStatus=receivable==debt?"تسویه":receivable>debt?"بستانکار":"بدهکار";
        String balanceText=formatUi(netStatus+"  •  "+money(receivable-debt));
        // Keep the existing balance math intact; show amounts in dedicated colored tiles.
        receivableMetric.setText(formatUi(money(receivable)));
        debtMetric.setText(formatUi(money(debt)));
        summary.setText(balanceText);
        summary.setTextColor(receivable>debt?UiKit.GOLD:receivable<debt?UiKit.RED:UiKit.GREEN);
        summary.setContentDescription("مانده خالص حساب‌ها، "+balanceText);
        long now=System.currentTimeMillis();
        LedgerReport.Result report=LedgerReport.generate(ps,NexaStore.ledgerEntries(this),null,LedgerReport.startMillis(reportDays,now),reportDays==0?Long.MAX_VALUE:now);
        String period=reportDays==0?"همه تراکنش‌ها":reportDays+" روز گذشته";
        reportSummary.setText(formatUi("گزارش همه طرف‌حساب‌ها • بازه: "+period+" • "+report.rows.size()+" تراکنش"
                +"\nبدهی جدید: "+money(report.debtAdded)+" • طلب جدید: "+money(report.creditAdded)
                +"\nپرداخت‌ها: "+money(report.paid)+" • دریافتی‌ها: "+money(report.received)
                +"\nتغییر خالص بازه: "+(report.periodChange>=0?"+":"")+NumberFormatUtil.grouped(report.periodChange)+" تومان"
                +"\nخالص حساب‌ها تا پایان بازه: "+NumberFormatUtil.grouped(report.closingNet)+" تومان"));
        reportSummary.setTextSize(15.5f);
        reportSummary.setTextColor(UiKit.TEXT);
        renderBalanceFilters();
        if(ps.isEmpty()){
            partyCounter.setText("۰ مورد");
            list.addView(UiKit.emptyState(this,"هنوز طرف‌حسابی ثبت نشده",
                "با دکمه افزودن، اولین طرف‌حساب را ثبت کنید."));
            return;
        }
        String q=search==null?"":search.getText().toString().trim().toLowerCase(java.util.Locale.ROOT);
        int matchedParties=0;
        for(NexaStore.LedgerParty p:ps){
            if(!q.isEmpty() && !(p.name+" "+p.phone+" "+p.note).toLowerCase(java.util.Locale.ROOT).contains(q))continue;
            long bal=NexaStore.ledgerBalance(this,p.id);
            if(!LedgerPartyFilters.matches(balanceFilter,bal))continue;
            matchedParties++;
            LinearLayout c=HomeUi.panel(this,false);
            c.setPadding(UiKit.dp(this,12),UiKit.dp(this,9),UiKit.dp(this,12),UiKit.dp(this,9));
            LinearLayout row=new LinearLayout(this);
            row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            NexaOutlineIcon symbol=new NexaOutlineIcon(this,"ledger",bal>0?UiKit.GOLD:bal<0?UiKit.RED:UiKit.GREEN);
            symbol.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            LinearLayout.LayoutParams symbolParams=new LinearLayout.LayoutParams(UiKit.dp(this,30),UiKit.dp(this,30));
            symbolParams.setMargins(0,0,UiKit.dp(this,9),0);
            row.addView(symbol,symbolParams);
            LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);
            TextView partyName=UiKit.sectionTitle(this,p.name);
            partyName.setTextColor(UiKit.TEXT);
            partyName.setTextSize(15f);
            partyName.setMaxLines(1);
            partyName.setEllipsize(android.text.TextUtils.TruncateAt.END);
            details.addView(partyName);
            TextView partyInfo=UiKit.muted(this,formatUi(state(bal)+" • "+NexaStore.ledgerEntriesFor(this,p.id).size()+" تراکنش"));
            partyInfo.setTextColor(bal>0?UiKit.GOLD:bal<0?UiKit.RED:UiKit.GREEN);
            partyInfo.setTextSize(12.5f);
            partyInfo.setMaxLines(2);
            details.addView(partyInfo,UiKit.matchWrap(this,3,0));
            row.addView(details,new LinearLayout.LayoutParams(0,-2,1f));
            Button more=UiKit.iconButton(this,"⋮","عملیات طرف‌حساب",UiKit.GOLD);
            more.setOnClickListener(v->new AlertDialog.Builder(this).setTitle(p.name)
                .setItems(new String[]{"گردش حساب","ویرایش","حذف"},(dialog,which)->{
                    if(which==0)showParty(p);else if(which==1)editParty(p);else deleteParty(p);
                }).show());
            row.addView(more,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            c.addView(row);
            c.setContentDescription("طرف‌حساب "+p.name+"؛ "+state(bal)+"؛ باز کردن گردش حساب");
            c.setClickable(true);
            c.setFocusable(true);
            UiKit.touchFeedback(this,c,UiKit.GOLD,17);
            c.setOnClickListener(v->showParty(p));
            list.addView(c,UiKit.matchWrap(this,0,6));
        }
        partyCounter.setText(formatUi(matchedParties+" از "+ps.size()+" مورد"));
        if(matchedParties==0){
            list.addView(UiKit.emptyState(this,"حسابی پیدا نشد",
                "عبارت جست‌وجو یا فیلتر مانده را تغییر دهید."));
            Button reset=UiKit.secondaryButton(this,"نمایش همه حساب‌ها");
            reset.setOnClickListener(v->{balanceFilter="all";search.setText("");render();});
            list.addView(reset,UiKit.matchWrap(this,7,0));
        }
    }

    /** Filter only the visible party list; balances and CSV remain comprehensive. */
    private void renderBalanceFilters(){
        balanceFilterRow.removeAllViews();
        String[] values={"all","receivable","debt","settled"};
        String[] titles={"همه","طلبکار","بدهکار","تسویه"};
        for(int i=0;i<values.length;i++){
            final String value=values[i];
            TextView chip=UiKit.chip(this,titles[i],value.equals(balanceFilter));
            chip.setMinHeight(UiKit.dp(this,44));
            chip.setMinWidth(UiKit.dp(this,76));
            chip.setGravity(Gravity.CENTER);
            chip.setFocusable(true);
            chip.setContentDescription("فیلتر "+titles[i]+(value.equals(balanceFilter)?"، انتخاب‌شده":""));
            chip.setOnClickListener(v->{balanceFilter=value;render();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,44));
            lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
            balanceFilterRow.addView(chip,lp);
        }
    }

    private void exportLedger(String partyId){exportLedger(partyId,reportDays);}

    private void exportLedger(String partyId,int days){
        long now=System.currentTimeMillis();
        long start=partyId!=null&&days>0
            ?LedgerHistoryFilter.recentStart(days,now,TimeZone.getDefault())
            :LedgerReport.startMillis(days,now);
        LedgerReport.Result report=LedgerReport.generate(NexaStore.ledgerParties(this),NexaStore.ledgerEntries(this),
                partyId,start,days==0?Long.MAX_VALUE:now);
        if(report.rows.isEmpty()){
            Toast.makeText(this,"در بازه انتخابی تراکنشی برای خروجی وجود ندارد",Toast.LENGTH_LONG).show();
            return;
        }
        pendingReportPartyId=partyId;
        pendingReportDays=days;
        Intent save=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        save.addCategory(Intent.CATEGORY_OPENABLE);
        save.setType("text/csv");
        String suffix=days==0?"all":String.valueOf(days)+"days";
        String timestamp=new java.text.SimpleDateFormat("yyyyMMdd_HHmm",java.util.Locale.US).format(new java.util.Date(now));
        save.putExtra(Intent.EXTRA_TITLE,"Nexa_Ledger_"+(partyId==null?"All":"Party")+"_"+suffix+"_"+timestamp+".csv");
        try{startActivityForResult(save,REQUEST_LEDGER_CSV);}
        catch(Exception e){pendingReportPartyId=null;Toast.makeText(this,"برنامه‌ای برای ذخیره فایل پیدا نشد",Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQUEST_LEDGER_CSV)return;
        String partyId=pendingReportPartyId;
        int days=pendingReportDays;
        pendingReportPartyId=null;
        pendingReportDays=0;
        if(resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        Uri target=data.getData();
        long now=System.currentTimeMillis();
        long start=partyId!=null&&days>0
            ?LedgerHistoryFilter.recentStart(days,now,TimeZone.getDefault())
            :LedgerReport.startMillis(days,now);
        LedgerReport.Result report=LedgerReport.generate(NexaStore.ledgerParties(this),NexaStore.ledgerEntries(this),
                partyId,start,days==0?Long.MAX_VALUE:now);
        try(OutputStream stream=getContentResolver().openOutputStream(target,"w")){
            if(stream==null)throw new java.io.IOException("No output stream");
            stream.write(LedgerReport.toCsv(report).getBytes(StandardCharsets.UTF_8));
            stream.flush();
            Toast.makeText(this,"گزارش ذخیره شد • "+report.rows.size()+" تراکنش",Toast.LENGTH_LONG).show();
        }catch(Exception e){
            Toast.makeText(this,"ذخیره گزارش ناموفق بود؛ فضای مقصد را بررسی کنید",Toast.LENGTH_LONG).show();
        }
    }

    private void editParty(NexaStore.LedgerParty old){
        LinearLayout box=UiKit.dialogPanel(this); EditText name=field("نام طرف‌حساب؛ مثلاً احمدی"); EditText phone=field("تلفن (اختیاری)"); EditText note=field("توضیحات");
        phone.setInputType(InputType.TYPE_CLASS_PHONE);
        if(old!=null){name.setText(old.name);phone.setText(old.phone);note.setText(old.note);}
        box.addView(UiKit.formField(this,"نام طرف‌حساب",name));
        LinearLayout optionalParty=new LinearLayout(this);optionalParty.setOrientation(LinearLayout.VERTICAL);
        optionalParty.addView(UiKit.formField(this,"تلفن",phone));
        optionalParty.addView(UiKit.formField(this,"یادداشت",note),UiKit.matchWrap(this,0,5));
        boolean showDetails=old!=null &&
            ((old.phone!=null&&!old.phone.trim().isEmpty())||(old.note!=null&&!old.note.trim().isEmpty()));
        box.addView(UiKit.optionalFormFields(this,"تلفن و توضیحات (اختیاری)",optionalParty,showDetails),
            UiKit.matchWrap(this,5,0));
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle(old==null?"طرف‌حساب جدید":"ویرایش طرف‌حساب")
            .setView(box).setPositiveButton("ذخیره",null)
            .setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim();
            if(n.isEmpty()){name.setError("نام طرف‌حساب الزامی است");name.requestFocus();return;}
            NexaStore.LedgerParty person=old==null?new NexaStore.LedgerParty():old;
            person.name=n;person.phone=phone.getText().toString().trim();
            person.note=note.getText().toString().trim();
            NexaStore.upsertLedgerParty(this,person);render();dialog.dismiss();
        }));
        dialog.show();
    }

    private void deleteParty(NexaStore.LedgerParty p){
        int count=NexaStore.ledgerEntriesFor(this,p.id).size();
        new AlertDialog.Builder(this).setTitle("حذف طرف‌حساب؟").setMessage(p.name+(count>0?"\n"+count+" تراکنش این حساب نیز حذف می‌شود.":""))
                .setPositiveButton("حذف",(d,w)->{for(NexaStore.LedgerEntry x:NexaStore.ledgerEntriesFor(this,p.id))LinkedReminderHelper.remove(this,"ledger:"+x.id);NexaStore.removeLedgerParty(this,p.id);render();})
                .setNegativeButton("انصراف",null).show();
    }

    private String date(long ms){return PersianDateUtil.pretty(ms);}
    private String kindLabel(String kind){return LedgerPresentation.label(kind);}

    private void updateKindChoices(TextView[] views,int selected,TextView explanation){
        for(int i=0;i<views.length;i++){
            boolean active=i==selected;
            String code=LedgerPresentation.KINDS[i];int color=LedgerPresentation.color(code);
            TextView cell=views[i];
            cell.setText((active?"✓  ":"")+LedgerPresentation.shortLabel(code));
            cell.setTextColor(active?color:UiKit.TEXT);
            cell.setContentDescription(LedgerPresentation.label(code)+(active?"، انتخاب شده":""));
            GradientDrawable surface=new GradientDrawable();
            surface.setColor(active?0xFF183026:0xFF0D1E19);
            surface.setCornerRadius(UiKit.dp(this,14));
            surface.setStroke(UiKit.dp(this,active?2:1),color);
            cell.setBackground(surface);
        }
        explanation.setText(LedgerPresentation.help(LedgerPresentation.KINDS[selected]));
        explanation.setTextColor(LedgerPresentation.color(LedgerPresentation.KINDS[selected]));
    }

    /** Small transaction card: amount, time and running balance remain visible; tools stay accessible. */
    private LinearLayout entryCard(NexaStore.LedgerParty p,NexaStore.LedgerEntry x,long running,Runnable refresh){
        int accent=LedgerPresentation.color(x.kind);
        LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(UiKit.dp(this,10),UiKit.dp(this,7),UiKit.dp(this,8),UiKit.dp(this,7));
        GradientDrawable bg=new GradientDrawable();bg.setColor(0xFF10211C);
        bg.setCornerRadius(UiKit.dp(this,13));bg.setStroke(UiKit.dp(this,1),accent);card.setBackground(bg);

        LinearLayout content=new LinearLayout(this);
        content.setGravity(Gravity.CENTER_VERTICAL);content.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout info=new LinearLayout(this);info.setOrientation(LinearLayout.VERTICAL);
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        top.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView kind=UiKit.sectionTitle(this,LedgerPresentation.shortLabel(x.kind));
        kind.setTextColor(accent);kind.setTextSize(15f);
        top.addView(kind,new LinearLayout.LayoutParams(0,-2,1f));
        TextView amount=UiKit.sectionTitle(this,formatUi(money(x.amount)));
        amount.setTextColor(accent);amount.setTextSize(15f);
        amount.setGravity(Gravity.LEFT);top.addView(amount);
        info.addView(top);

        // The calendar day is shown once as a group heading; only the transaction time repeats.
        String details="ساعت "+LedgerCompactUi.timeOnly(x.dateMillis)+" • مانده: "+state(running);
        TextView meta=UiKit.muted(this,formatUi(details));meta.setTextColor(UiKit.TEXT);
        meta.setTextSize(12.5f);meta.setMaxLines(2);
        info.addView(meta,UiKit.matchWrap(this,3,0));
        if(x.note!=null && !x.note.isEmpty()){
            TextView note=UiKit.muted(this,"شرح: "+x.note);
            note.setTextSize(12.5f);note.setMaxLines(2);
            note.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(note,UiKit.matchWrap(this,2,0));
        }
        if(x.dueMillis>0){
            TextView due=UiKit.muted(this,formatUi("موعد: "+date(x.dueMillis)
                    +(x.dueMillis<System.currentTimeMillis()?" • گذشته":"")
                    +ReminderRecurrence.labelSuffix(x.dueRecurrence)));
            due.setTextSize(12f);due.setMaxLines(2);
            info.addView(due,UiKit.matchWrap(this,2,0));
        }
        content.addView(info,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.VERTICAL);
        Button edit=UiKit.editIconButton(this);edit.setContentDescription("ویرایش "+kindLabel(x.kind));
        edit.setOnClickListener(v->editEntry(p,x,refresh));
        actions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        Button del=UiKit.deleteIconButton(this);del.setContentDescription("حذف "+kindLabel(x.kind));
        del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف تراکنش؟")
            .setMessage(kindLabel(x.kind)+" • "+money(x.amount))
            .setPositiveButton("حذف",(d,w)->{LinkedReminderHelper.remove(this,"ledger:"+x.id);
                NexaStore.removeLedgerEntry(this,x.id);refresh.run();render();})
            .setNegativeButton("انصراف",null).show());
        LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        dl.topMargin=UiKit.dp(this,1);actions.addView(del,dl);
        LinearLayout.LayoutParams actionParams=new LinearLayout.LayoutParams(-2,-2);
        actionParams.setMargins(UiKit.dp(this,5),0,0,0);
        content.addView(actions,actionParams);
        card.addView(content);
        return card;
    }

    private void showParty(NexaStore.LedgerParty p){
        LinearLayout box=UiKit.dialogPanel(this);
        box.setPadding(UiKit.dp(this,11),UiKit.dp(this,9),UiKit.dp(this,11),UiKit.dp(this,8));
        TextView bal=UiKit.sectionTitle(this,formatUi(state(NexaStore.ledgerBalance(this,p.id))));
        bal.setTextSize(16f);box.addView(bal,UiKit.matchWrap(this,0,4));

        final String[] selectedKind={LedgerHistoryFilter.ALL};
        final int[] displayLimit={40};
        TextView[] filterChoices=new TextView[LedgerHistoryFilter.KINDS.length];
        final int[] dateChoices={0,7,30,90};
        final String[] dateLabels={"همه تاریخ‌ها","۷ روز","۳۰ روز","۹۰ روز"};
        TextView[] dateChips=new TextView[dateChoices.length];

        // Primary actions occupy a single compact row. Advanced controls are hidden by default.
        LinearLayout toolbar=new LinearLayout(this);
        toolbar.setGravity(Gravity.CENTER_VERTICAL);
        toolbar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button add=UiKit.primaryButton(this,"＋ ثبت");
        add.setTextSize(13f);add.setContentDescription("ثبت بدهی، طلب، پرداخت یا دریافت جدید");
        toolbar.addView(add,new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f));
        Button filterToggle=UiKit.secondaryButton(this,"☷ فیلتر");
        filterToggle.setTextSize(12.5f);filterToggle.setContentDescription("بازکردن تنظیمات جستجو، فیلتر و خروجی CSV");
        LinearLayout.LayoutParams fl=new LinearLayout.LayoutParams(UiKit.dp(this,86),UiKit.dp(this,48));
        fl.setMargins(UiKit.dp(this,4),0,0,0);toolbar.addView(filterToggle,fl);
        Button order=UiKit.secondaryButton(this,"");order.setTextSize(12f);
        LinearLayout.LayoutParams ol=new LinearLayout.LayoutParams(UiKit.dp(this,94),UiKit.dp(this,48));
        ol.setMargins(UiKit.dp(this,4),0,0,0);toolbar.addView(order,ol);
        box.addView(toolbar,UiKit.matchWrap(this,0,3));

        TextView activeFilters=UiKit.muted(this,"");
        activeFilters.setTextSize(12f);activeFilters.setTextColor(UiKit.GOLD);
        activeFilters.setMaxLines(1);activeFilters.setEllipsize(android.text.TextUtils.TruncateAt.END);
        activeFilters.setClickable(true);box.addView(activeFilters,UiKit.matchWrap(this,0,3));

        LinearLayout advancedFilters=new LinearLayout(this);
        advancedFilters.setOrientation(LinearLayout.VERTICAL);
        advancedFilters.setPadding(UiKit.dp(this,12),UiKit.dp(this,6),UiKit.dp(this,12),UiKit.dp(this,12));
        advancedFilters.setTag("nexa_ledger_advanced_filters");
        TextView filterTitle=UiKit.fieldLabel(this,"نوع تراکنش");
        advancedFilters.addView(filterTitle,UiKit.matchWrap(this,4,2));
        LinearLayout filterBar=new LinearLayout(this);
        filterBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<filterChoices.length;i++){
            TextView chip=new TextView(this);chip.setGravity(Gravity.CENTER);
            chip.setTextSize(13f);chip.setMinHeight(UiKit.dp(this,40));
            chip.setPadding(UiKit.dp(this,11),UiKit.dp(this,6),UiKit.dp(this,11),UiKit.dp(this,6));
            chip.setClickable(true);chip.setFocusable(true);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);
            cp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
            filterBar.addView(chip,cp);filterChoices[i]=chip;
        }
        HorizontalScrollView filterScroll=new HorizontalScrollView(this);
        filterScroll.setHorizontalScrollBarEnabled(false);filterScroll.addView(filterBar);
        advancedFilters.addView(filterScroll,UiKit.matchWrap(this,1,3));
        TextView dateLabel=UiKit.fieldLabel(this,"بازه تاریخ");
        advancedFilters.addView(dateLabel,UiKit.matchWrap(this,4,2));
        LinearLayout dateFilters=new LinearLayout(this);
        dateFilters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(int i=0;i<dateChoices.length;i++){
            TextView chip=new TextView(this);chip.setGravity(Gravity.CENTER);
            chip.setTextSize(13f);chip.setMinHeight(UiKit.dp(this,40));
            chip.setPadding(UiKit.dp(this,11),UiKit.dp(this,6),UiKit.dp(this,11),UiKit.dp(this,6));
            chip.setClickable(true);chip.setFocusable(true);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);
            cp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
            dateFilters.addView(chip,cp);dateChips[i]=chip;
        }
        HorizontalScrollView dateScroll=new HorizontalScrollView(this);
        dateScroll.setHorizontalScrollBarEnabled(false);dateScroll.addView(dateFilters);
        advancedFilters.addView(dateScroll,UiKit.matchWrap(this,1,5));
        EditText transactionSearch=field("جستجوی شرح، مبلغ یا نوع تراکنش");
        transactionSearch.setSingleLine(true);
        advancedFilters.addView(transactionSearch,UiKit.matchWrap(this,0,5));
        LinearLayout extras=new LinearLayout(this);extras.setGravity(Gravity.CENTER_VERTICAL);
        Button clear=UiKit.secondaryButton(this,"پاک‌کردن فیلترها");clear.setTextSize(12.5f);
        Button export=UiKit.secondaryButton(this,"⇩ خروجی CSV");export.setTextSize(12.5f);
        export.setOnClickListener(v->exportLedger(p.id,historyDays));
        extras.addView(clear,new LinearLayout.LayoutParams(0,UiKit.dp(this,43),1f));
        LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(0,UiKit.dp(this,43),1f);
        xp.setMargins(UiKit.dp(this,5),0,0,0);extras.addView(export,xp);
        advancedFilters.addView(extras,UiKit.matchWrap(this,2,4));
        // Filter controls live in a separate scrollable panel, never above the transaction list.
        ScrollView optionsScroll=new ScrollView(this);
        optionsScroll.setFillViewport(false);
        optionsScroll.addView(advancedFilters);
        AlertDialog optionsDialog=new AlertDialog.Builder(this)
            .setTitle("فیلترها و خروجی حساب")
            .setView(optionsScroll)
            .setPositiveButton("بازگشت به گردش",null).create();

        TextView visibleCount=UiKit.muted(this,"");visibleCount.setTextSize(12.5f);
        box.addView(visibleCount,UiKit.matchWrap(this,1,3));
        LinearLayout rows=new LinearLayout(this);rows.setOrientation(LinearLayout.VERTICAL);
        ScrollView txScroll=new ScrollView(this);txScroll.setFillViewport(false);
        txScroll.setTag("nexa_ledger_transaction_list");
        txScroll.addView(rows);
        int safeHeight=Math.max(UiKit.dp(this,200),Math.min(UiKit.dp(this,540),
            (int)(getResources().getDisplayMetrics().heightPixels*0.58f)));
        box.addView(txScroll,new LinearLayout.LayoutParams(-1,safeHeight));

        final Runnable[] refresh=new Runnable[1];
        refresh[0]=()->{
            rows.removeAllViews();
            LedgerReport.Result report=LedgerReport.generate(Collections.singletonList(p),
                NexaStore.ledgerEntriesFor(this,p.id),p.id,Long.MIN_VALUE,Long.MAX_VALUE);
            // Chronology is always based on dateMillis, not entry insertion time.
            // Running balances are calculated from the unfiltered account history.
            long now=System.currentTimeMillis();
            long from=LedgerHistoryFilter.recentStart(historyDays,now,TimeZone.getDefault());
            List<LedgerReport.Row> ordered=LedgerReport.orderedRows(
                LedgerHistoryFilter.selectBetween(report.rows,selectedKind[0],
                    transactionSearch.getText().toString(),from,historyDays==0?Long.MAX_VALUE:now),
                newestFirst);
            order.setText(LedgerCompactUi.sortLabel(newestFirst));
            order.setContentDescription(newestFirst?"مرتب‌سازی جدیدترین اول؛ تغییر به قدیمی‌ترین":"مرتب‌سازی قدیمی‌ترین اول؛ تغییر به جدیدترین");
            boolean filtered=LedgerCompactUi.hasActiveFilters(selectedKind[0],historyDays,
                    transactionSearch.getText().toString());
            String currentFilter=LedgerCompactUi.activeSummary(selectedKind[0],historyDays,
                    transactionSearch.getText().toString());
            activeFilters.setText(formatUi(currentFilter));
            activeFilters.setVisibility(filtered?View.VISIBLE:View.GONE);
            filterToggle.setText(filtered?"☷ فعال":"☷ فیلتر");
            filterToggle.setTextColor(filtered?UiKit.GOLD:UiKit.TEXT);
            int shown=Math.min(ordered.size(),displayLimit[0]);
            visibleCount.setText(formatUi(shown+" از "+ordered.size()+" تراکنش"
                    +(filtered?" • کل حساب: "+report.rows.size():"")));
            int previousDay=Integer.MIN_VALUE;
            TimeZone timezone=TimeZone.getDefault();
            for(int i=0;i<shown;i++){
                LedgerReport.Row row=ordered.get(i);
                int thisDay=LedgerHistoryFilter.dayKey(row.entry.dateMillis,timezone);
                if(thisDay!=previousDay){
                    TextView dateDivider=UiKit.muted(this,formatUi(LedgerCompactUi.dayHeading(row.entry.dateMillis)));
                    dateDivider.setTextSize(12.5f);dateDivider.setTextColor(UiKit.GOLD);
                    rows.addView(dateDivider,UiKit.matchWrap(this,5,2));
                    previousDay=thisDay;
                }
                rows.addView(entryCard(p,row.entry,row.runningBalance,refresh[0]),UiKit.matchWrap(this,1,4));
            }
            if(shown<ordered.size()){
                Button more=UiKit.secondaryButton(this,formatUi("نمایش بیشتر ("+(ordered.size()-shown)+" مورد)"));
                more.setOnClickListener(v->{displayLimit[0]=Math.min(ordered.size(),shown+40);refresh[0].run();});
                rows.addView(more,UiKit.matchWrap(this,5,3));
            }
            if(ordered.isEmpty())rows.addView(UiKit.muted(this,report.rows.isEmpty()
                ?"هنوز تراکنشی ثبت نشده.":"تراکنشی با این جستجو یا فیلتر پیدا نشد."));
            bal.setText(formatUi(state(NexaStore.ledgerBalance(this,p.id))));
        };
        for(int i=0;i<filterChoices.length;i++){
            final int index=i;
            filterChoices[i].setOnClickListener(v->{
                selectedKind[0]=LedgerHistoryFilter.KINDS[index];displayLimit[0]=40;
                updateHistoryFilterChoices(filterChoices,selectedKind[0]);refresh[0].run();
            });
        }
        updateHistoryFilterChoices(filterChoices,selectedKind[0]);
        final Runnable[] updateDateChoices={null};
        updateDateChoices[0]=()->{
            for(int i=0;i<dateChips.length;i++){
                boolean active=historyDays==dateChoices[i];
                TextView chip=dateChips[i];
                chip.setText((active?"✓  ":"")+dateLabels[i]);
                chip.setTextColor(active?UiKit.GOLD:UiKit.TEXT);
                chip.setContentDescription(dateLabels[i]+(active?"، انتخاب شده":""));
                GradientDrawable bg=new GradientDrawable();
                bg.setColor(active?0xFF193029:0xFF0D1E19);
                bg.setCornerRadius(UiKit.dp(this,14));
                bg.setStroke(UiKit.dp(this,active?2:1),UiKit.GOLD);
                chip.setBackground(bg);
                final int choice=dateChoices[i];
                chip.setOnClickListener(v->{
                    historyDays=choice;displayLimit[0]=40;
                    updateDateChoices[0].run();refresh[0].run();
                });
            }
        };
        updateDateChoices[0].run();
        transactionSearch.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){
                displayLimit[0]=40;refresh[0].run();}
            public void afterTextChanged(Editable e){}
        });
        filterToggle.setOnClickListener(v->optionsDialog.show());
        activeFilters.setOnClickListener(v->optionsDialog.show());
        clear.setOnClickListener(v->{
            selectedKind[0]=LedgerHistoryFilter.ALL;historyDays=0;displayLimit[0]=40;
            transactionSearch.setText("");updateHistoryFilterChoices(filterChoices,selectedKind[0]);
            updateDateChoices[0].run();refresh[0].run();
        });
        order.setOnClickListener(v->{newestFirst=!newestFirst;displayLimit[0]=40;refresh[0].run();});
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(p.name).setView(box)
            .setPositiveButton("بستن",null).create();
        add.setOnClickListener(v->editEntry(p,null,refresh[0]));
        refresh[0].run();dialog.setOnDismissListener(x->render());dialog.show();
    }

    private void updateHistoryFilterChoices(TextView[] views,String selected) {
        for(int i=0;i<views.length;i++){
            String kind=LedgerHistoryFilter.KINDS[i];
            boolean active=kind.equals(selected);
            int accent=LedgerHistoryFilter.ALL.equals(kind)?0xFFE1C16E:LedgerPresentation.color(kind);
            TextView chip=views[i];
            chip.setText((active?"✓  ":"")+(LedgerHistoryFilter.ALL.equals(kind)?"همه":LedgerPresentation.shortLabel(kind)));
            chip.setTextColor(active?accent:UiKit.TEXT);
            chip.setContentDescription(chip.getText()+(active?"، انتخاب شده":""));
            GradientDrawable bg=new GradientDrawable();
            bg.setColor(active?0xFF193029:0xFF0D1E19);
            bg.setCornerRadius(UiKit.dp(this,14));
            bg.setStroke(UiKit.dp(this,active?2:1),accent);
            chip.setBackground(bg);
        }
    }

    private void attachGrouping(EditText amount){
        amount.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){}
            public void afterTextChanged(Editable e){
                if(formattingAmount)return; String raw=NumberFormatUtil.toLatin(e.toString()).replace(",","").replace("٬","").trim(); if(raw.isEmpty())return;
                try{long v=Long.parseLong(raw); String grouped=groupedMoney(v);
                    if(!grouped.equals(e.toString())){formattingAmount=true;
                        try{amount.setText(grouped);amount.setSelection(grouped.length());}
                        finally{formattingAmount=false;}}}catch(NumberFormatException ignored){}
            }
        });
    }

    private void editEntry(NexaStore.LedgerParty p,NexaStore.LedgerEntry old,Runnable done){
        LinearLayout box=UiKit.dialogPanel(this);
        TextView typeTitle=UiKit.fieldLabel(this,"نوع تراکنش");typeTitle.setTextSize(15f);box.addView(typeTitle);
        final int[] selected={0};
        if(old!=null)for(int i=0;i<LedgerPresentation.KINDS.length;i++)
            if(LedgerPresentation.KINDS[i].equals(old.kind))selected[0]=i;
        TextView[] choices=new TextView[4];
        for(int row=0;row<2;row++){
            LinearLayout choiceRow=new LinearLayout(this);choiceRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            for(int col=0;col<2;col++){
                int index=row*2+col;TextView choice=new TextView(this);
                choice.setTextSize(16.5f);choice.setGravity(Gravity.CENTER);choice.setMinHeight(UiKit.dp(this,53));
                choice.setPadding(UiKit.dp(this,4),UiKit.dp(this,10),UiKit.dp(this,4),UiKit.dp(this,10));
                choice.setClickable(true);choice.setFocusable(true);choices[index]=choice;
                LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,-2,1f);
                cp.setMargins(UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3),UiKit.dp(this,3));
                choiceRow.addView(choice,cp);
            }
            box.addView(choiceRow,UiKit.matchWrap(this,2,0));
        }
        TextView explanation=UiKit.muted(this,"");explanation.setTextSize(15f);
        box.addView(explanation,UiKit.matchWrap(this,5,9));
        for(int i=0;i<choices.length;i++){
            final int index=i;choices[i].setOnClickListener(v->{selected[0]=index;
                updateKindChoices(choices,index,explanation);});
        }
        updateKindChoices(choices,selected[0],explanation);
        EditText amount=field("مبلغ به تومان");amount.setInputType(InputType.TYPE_CLASS_NUMBER);
        amount.setTextSize(17f);attachGrouping(amount);
        EditText note=field("شرح تراکنش (اختیاری)");note.setTextSize(16f);
        // Recorded date determines chronological order and historical running balances.
        final long[] entryDateMillis={old==null?System.currentTimeMillis():old.dateMillis};
        Button entryDate=UiKit.secondaryButton(this,"📅 تاریخ تراکنش: "+date(entryDateMillis[0]));
        entryDate.setContentDescription("انتخاب تاریخ و ساعت تراکنش برای مرتب‌سازی گردش حساب");
        entryDate.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,entryDateMillis[0],
            "تاریخ و ساعت تراکنش",ms->{entryDateMillis[0]=ms;
                entryDate.setText("📅 تاریخ تراکنش: "+date(ms));}));
        final long[] dueMillis={old==null?0:old.dueMillis};
        Button due=UiKit.secondaryButton(this,dueMillis[0]>0?"🕒 موعد: "+date(dueMillis[0]):"🕒 موعد / یادآور (اختیاری)");
        Button clearDue=UiKit.secondaryButton(this,"✕ حذف موعد ثبت‌شده");
        clearDue.setVisibility(dueMillis[0]>0?View.VISIBLE:View.GONE);
        clearDue.setOnClickListener(v->{
            dueMillis[0]=0;due.setText("🕒 موعد / یادآور (اختیاری)");
            clearDue.setVisibility(View.GONE);
        });
        due.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,
            dueMillis[0]>0?dueMillis[0]:System.currentTimeMillis()+3600000L,
            "موعد حساب",ms->{dueMillis[0]=ms;due.setText("🕒 موعد: "+date(ms));
                clearDue.setVisibility(View.VISIBLE);}));
        if(old!=null){amount.setText(groupedMoney(old.amount));amount.setSelection(amount.length());
            note.setText(old.note);}
        box.addView(UiKit.formField(this,"مبلغ (تومان)",amount),UiKit.matchWrap(this,0,5));
        box.addView(UiKit.formField(this,"تاریخ تراکنش",entryDate),UiKit.matchWrap(this,0,7));
        LinearLayout optionalEntry=new LinearLayout(this);optionalEntry.setOrientation(LinearLayout.VERTICAL);
        optionalEntry.addView(UiKit.formField(this,"شرح تراکنش",note));
        optionalEntry.addView(UiKit.formField(this,"موعد تسویه / یادآوری",due),UiKit.matchWrap(this,0,5));
        optionalEntry.addView(clearDue,UiKit.matchWrap(this,0,0));
        // Repeat only the reminder, never multiply a financial transaction.
        RepeatIntervalPicker ledgerRepeat=new RepeatIntervalPicker(this,optionalEntry,old==null?"none":old.dueRecurrence);
        boolean showOptional=old!=null && (old.dueMillis>0 ||
                (old.note!=null&&!old.note.isEmpty()) ||
                (old.dueRecurrence!=null&&!"none".equals(old.dueRecurrence)));
        box.addView(UiKit.optionalFormFields(this,"شرح، موعد و تکرار یادآور (اختیاری)",optionalEntry,
                showOptional),UiKit.matchWrap(this,0,0));
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(false);scroll.addView(box);
        AlertDialog dialog=new AlertDialog.Builder(this)
            .setTitle((old==null?"تراکنش جدید":"ویرایش تراکنش")+" • "+p.name)
            .setView(scroll).setPositiveButton(old==null?"ثبت":"ذخیره",null)
            .setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(ignored->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            long value=LedgerPresentation.positiveAmount(amount.getText().toString());
            if(value<=0){amount.setError("مبلغ معتبر و بزرگ‌تر از صفر وارد کنید");
                amount.requestFocus();return;}
            String kind=LedgerPresentation.KINDS[selected[0]];
            NexaStore.LedgerEntry x=old==null?new NexaStore.LedgerEntry():old;
            x.partyId=p.id;x.amount=value;x.kind=kind;
            x.dateMillis=entryDateMillis[0];
            x.note=note.getText().toString().trim();x.dueMillis=dueMillis[0];x.dueRecurrence=ledgerRepeat.rule();
            if(old==null)NexaStore.addLedgerEntry(this,x);else NexaStore.updateLedgerEntry(this,x);
            if(x.dueMillis>System.currentTimeMillis()){
                LinkedReminderHelper.upsert(this,"ledger:"+x.id,"موعد حساب • "+p.name,
                    "حساب","💰",kindLabel(x.kind)+" • "+money(x.amount)
                    +(x.note.isEmpty()?"":" • "+x.note),x.dueMillis,"60,0",5,x.dueRecurrence);
            }else LinkedReminderHelper.remove(this,"ledger:"+x.id);
            NexaStore.addHistory(this,"حساب",p.name+" • "+kindLabel(kind)+" • "+money(value));
            done.run();render();dialog.dismiss();
        }));
        dialog.show();
    }
}
