package com.example.silenttimer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;

/** Synchronous fail-safe: timer must restore the phone even if FGS startup is denied. */
public final class TimerExpiryRecovery {
    private TimerExpiryRecovery() {}

    static boolean isDue(long endAt, long now) {
        return TimerExpiryPolicy.isDue(endAt,now);
    }

    public static boolean restoreIfDue(Context context) {
        long endAt = AppPrefs.getEndAt(context);
        if (!isDue(endAt, System.currentTimeMillis())) return false;
        int previous = AppPrefs.hasTimerPreviousRingerMode(context)
                ? AppPrefs.getTimerPreviousRingerMode(context)
                : AudioManager.RINGER_MODE_NORMAL;
        if (!NexaAudioController.restoreRingerMode(context, previous)) {
            BackgroundReliability.record(context, "timer.receiver.restore",
                    new IllegalStateException("Ringer restoration denied"));
            scheduleRetry(context);
            return false;
        }
        // Never erase the session if the OS still reports Silent/Vibrate.
        if (NexaAudioController.getRingerMode(context) != previous) {
            scheduleRetry(context);
            return false;
        }
        AppPrefs.clearTimer(context);
        NexaStore.addHistory(context, "سایلنت", "تایمر پایان یافت");
        return true;
    }

    /** Recreate a lost alarm after reboot/update or a system clock change. */
    public static void reschedulePending(Context context) {
        long endAt = AppPrefs.getEndAt(context);
        if (endAt <= 0L) return;
        if (isDue(endAt, System.currentTimeMillis())) {
            restoreIfDue(context);
            return;
        }
        AlarmManager am = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = PendingIntent.getBroadcast(context, 9001,
                new Intent(context, TimerEndReceiver.class),
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (android.os.Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pi);
            else
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, endAt, pi);
        } catch (RuntimeException error) {
            BackgroundReliability.record(context, "timer.rearm", error);
            scheduleRetry(context);
        }
    }

    public static void scheduleRetry(Context context) {
        AlarmManager am = (AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        Intent action = new Intent(context, TimerEndReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, 9001, action,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                    System.currentTimeMillis() + 60_000L, pi);
        } catch (RuntimeException error) {
            BackgroundReliability.record(context, "timer.receiver.retry", error);
        }
    }
}
