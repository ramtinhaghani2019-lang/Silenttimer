package com.example.silenttimer;

/** UI-only filtering of parties; ledger amounts and storage remain unchanged. */
final class LedgerPartyFilterPolicy {
    static final String[] FILTERS={"همه","طلبکار","بدهکار","تسویه"};
    private LedgerPartyFilterPolicy(){}
    static boolean matches(String filter,long balance){
        if("طلبکار".equals(filter))return balance>0;
        if("بدهکار".equals(filter))return balance<0;
        if("تسویه".equals(filter))return balance==0;
        return true;
    }
    static boolean matchesQuery(String name,String phone,String note,String query){
        if(query==null||query.trim().isEmpty())return true;
        return SearchQueryPolicy.matches((name==null?"":name)+" "+
                (phone==null?"":phone)+" "+(note==null?"":note),query);
    }
}
