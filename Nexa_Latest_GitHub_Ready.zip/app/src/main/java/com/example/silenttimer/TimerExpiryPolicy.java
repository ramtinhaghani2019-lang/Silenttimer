package com.example.silenttimer;
/** Critical safety policy for expired sessions; no Android dependencies. */
public final class TimerExpiryPolicy {
    private TimerExpiryPolicy() {}
    public static boolean isDue(long endAt, long now) {
        return endAt > 0L && now >= endAt - 1500L;
    }
    public static boolean mayClearSession(boolean restoreRequested, boolean restored) {
        return !restoreRequested || restored;
    }
}
