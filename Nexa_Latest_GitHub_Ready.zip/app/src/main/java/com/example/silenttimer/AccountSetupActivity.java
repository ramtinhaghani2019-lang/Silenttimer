package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/** First launch local profile; email recovery is disabled until a verified provider is configured. */
public class AccountSetupActivity extends Activity {
    private EditText name,email,phone,pin;
    private EditText input(String hint,int type){EditText e=new EditText(this);e.setHint(hint);e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);e.setInputType(type);e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,16),UiKit.dp(this,14),UiKit.dp(this,16),UiKit.dp(this,14));return e;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,22),UiKit.dp(this,36),UiKit.dp(this,22),UiKit.dp(this,36));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.title(this,"✦ به Nexa خوش آمدی"),UiKit.matchWrap(this,0,10));
        root.addView(UiKit.muted(this,"اطلاعات اولیه فقط در گوشی ذخیره می‌شوند. بدون اتصال به سرویس ایمیل، تأیید و بازیابی ایمیلی فعال نیست."),UiKit.matchWrap(this,0,20));
        LinearLayout card=UiKit.colorfulCardLayout(this,1);
        card.addView(UiKit.sectionTitle(this,"👤 حساب کاربری"),UiKit.matchWrap(this,0,12));
        name=input("نام و نام خانوادگی",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        email=input("ایمیل بازیابی",InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);
        phone=input("شماره موبایل (اختیاری)",InputType.TYPE_CLASS_PHONE);
        pin=input("PIN امن ۴ تا ۶ رقمی",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        name.setText(NexaStore.accountName(this));email.setText(NexaStore.accountEmail(this));phone.setText(NexaStore.accountPhone(this));
        card.addView(name,UiKit.matchWrap(this,0,10));card.addView(email,UiKit.matchWrap(this,0,10));
        card.addView(phone,UiKit.matchWrap(this,0,10));
        if(!NexaStore.pinConfigured(this))card.addView(pin,UiKit.matchWrap(this,0,10));
        card.addView(UiKit.muted(this,"توجه: ایمیل در این نسخه ذخیره می‌شود ولی هنوز تأییدشده نیست و به‌تنهایی نمی‌تواند رمز Vault را بازیابی کند."),UiKit.matchWrap(this,8,12));
        Button save=UiKit.primaryButton(this,"ذخیره و ادامه");
        save.setOnClickListener(v->{String n=name.getText().toString().trim(),e=email.getText().toString().trim();
            if(n.isEmpty()||e.isEmpty()||!Patterns.EMAIL_ADDRESS.matcher(e).matches()){
                Toast.makeText(this,"نام و ایمیل معتبر را وارد کن.",Toast.LENGTH_LONG).show();return;}
            if(!NexaStore.pinConfigured(this)){
                String p=pin.getText().toString();if(!p.matches("[0-9]{4,6}")){
                    Toast.makeText(this,"PIN باید ۴ تا ۶ رقم باشد.",Toast.LENGTH_LONG).show();return;}
                NexaStore.setPin(this,p);NexaStore.setLockEnabled(this,true);
            }
            NexaStore.saveAccount(this,n,e,phone.getText().toString().trim());
            Toast.makeText(this,"مشخصات روی گوشی ذخیره شد.",Toast.LENGTH_SHORT).show();
            finish();
        });card.addView(save);root.addView(card);setContentView(sc);
    }
}
