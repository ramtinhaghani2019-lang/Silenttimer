package com.example.silenttimer;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import java.text.DecimalFormat;

public final class NumberFormatUtil {
    private NumberFormatUtil() {}

    /** Group a signed integer string without converting through floating point or long. */
    public static String groupIntegerText(String input) {
        if (input == null) return "";
        String raw = toLatin(input).replace(",", "").replace("٬", "").trim();
        if (!raw.matches("[+-]?\\d+")) return input;
        boolean negative = raw.startsWith("-");
        boolean positive = raw.startsWith("+");
        String digits = (negative || positive) ? raw.substring(1) : raw;
        int firstNonZero = 0;
        while (firstNonZero < digits.length() - 1 && digits.charAt(firstNonZero) == '0') firstNonZero++;
        digits = digits.substring(firstNonZero);
        StringBuilder out = new StringBuilder(digits);
        for (int i = out.length() - 3; i > 0; i -= 3) out.insert(i, ',');
        return (negative && !digits.equals("0") ? "-" : positive && !digits.equals("0") ? "+" : "") + out;
    }

    /** Map a caret offset across inserted/removed grouping separators. */
    static int mappedCaret(String before, String after, int caret) {
        int bounded = Math.max(0, Math.min(caret, before.length()));
        int meaningful = 0;
        for (int i = 0; i < bounded; i++) {
            char ch = before.charAt(i);
            if (ch != ',' && ch != '٬') meaningful++;
        }
        if (meaningful == 0) return 0;
        int seen = 0;
        for (int i = 0; i < after.length(); i++) {
            char ch = after.charAt(i);
            if (ch != ',' && ch != '٬') seen++;
            if (seen == meaningful) return i + 1;
        }
        return after.length();
    }

    public static void attachThousands(EditText e) {
        e.addTextChangedListener(new TextWatcher() {
            boolean busy=false;
            @Override public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            @Override public void onTextChanged(CharSequence s,int st,int b,int c){}
            @Override public void afterTextChanged(Editable ed){
                if(busy)return;
                String raw=toLatin(ed.toString()).replace(",","").replace("٬","").trim();
                if(raw.isEmpty()||"-".equals(raw)||"+".equals(raw))return;
                if(!raw.matches("[+-]?\\d+"))return;
                String formatted = groupIntegerText(raw);
                if (!formatted.equals(ed.toString())) {
                    busy=true;
                    try { int start = mappedCaret(ed.toString(), formatted, e.getSelectionStart()); int end = mappedCaret(ed.toString(), formatted, e.getSelectionEnd()); e.setText(formatted); e.setSelection(Math.min(start, end), Math.max(start, end)); }
                    finally { busy=false; }
                }
            }
        });
    }


    /** Format a decimal input exactly, preserving fractional digits and unfinished typing. */
    public static String groupDecimalText(String input) {
        if (input == null) return "";
        String raw = toLatin(input).replace(",", "").replace("٬", "")
                .replace("٫", ".").trim();
        if (raw.isEmpty() || raw.equals("-") || raw.equals("+") || raw.equals(".") || raw.equals("-.") || raw.equals("+.")) return raw;
        if (!raw.matches("[+-]?\\d*(\\.\\d*)?")) return input;
        String[] parts = raw.split("\\.", -1);
        String whole = parts[0];
        boolean negative = whole.startsWith("-");
        boolean positive = whole.startsWith("+");
        String digits = (negative || positive) ? whole.substring(1) : whole;
        if (digits.isEmpty()) return raw;
        String grouped = groupIntegerText(digits);
        boolean isZero = grouped.equals("0") && (parts.length == 1 || !parts[1].matches(".*[1-9].*"));
        String prefix = negative && !isZero ? "-" : positive && !isZero ? "+" : "";
        return prefix + grouped + (parts.length > 1 ? "." + parts[1] : "");
    }

    public static void attachThousandsDecimal(EditText e) {
        e.addTextChangedListener(new TextWatcher() {
            boolean busy = false;
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable ed) {
                if (busy) return;
                String formatted = groupDecimalText(ed.toString());
                if (!formatted.equals(ed.toString())) {
                    busy = true;
                    try { int start = mappedCaret(ed.toString(), formatted, e.getSelectionStart()); int end = mappedCaret(ed.toString(), formatted, e.getSelectionEnd()); e.setText(formatted); e.setSelection(Math.min(start, end), Math.max(start, end)); }
                    finally { busy = false; }
                }
            }
        });
    }

    public static double doubleValue(CharSequence s){try{return Double.parseDouble(toLatin(String.valueOf(s)).replace(",","").replace("٬","").replace("٫",".").trim());}catch(Exception e){return 0d;}}

    public static long longValue(CharSequence s) {
        try{return Long.parseLong(toLatin(String.valueOf(s)).replace(",","").replace("٬","").trim());}
        catch(Exception e){return 0L;}
    }

    public static int intValue(CharSequence s) {
        long v=longValue(s);return v>Integer.MAX_VALUE?Integer.MAX_VALUE:(int)Math.max(Integer.MIN_VALUE,v);
    }

    public static String grouped(long v){return new DecimalFormat("#,###").format(v);}

    public static String format(long v){return grouped(v);}

    public static String toLatin(String s){
        if(s==null)return "";
        String fa="۰۱۲۳۴۵۶۷۸۹", ar="٠١٢٣٤٥٦٧٨٩";
        StringBuilder out=new StringBuilder();
        for(char ch:s.toCharArray()){
            int i=fa.indexOf(ch); if(i>=0){out.append((char)('0'+i));continue;}
            i=ar.indexOf(ch); if(i>=0){out.append((char)('0'+i));continue;}
            out.append(ch);
        }
        return out.toString().replace('−', '-');
    }
}
