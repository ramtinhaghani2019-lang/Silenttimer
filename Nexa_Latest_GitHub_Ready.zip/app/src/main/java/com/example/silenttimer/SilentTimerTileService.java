package com.example.silenttimer;

import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class SilentTimerTileService extends TileService {
    @Override
    public void onStartListening() {
        super.onStartListening();
        refreshTile();
    }

    @Override
    public void onClick() {
        super.onClick();

        Intent i = new Intent(this, SilentTimerService.class);

        if (AppPrefs.isTimerActive(this)) {
            i.setAction(SilentTimerService.ACTION_STOP);
        } else {
            i.setAction(SilentTimerService.ACTION_START);
            i.putExtra(SilentTimerService.EXTRA_MINUTES, 30);
            i.putExtra(
                    SilentTimerService.EXTRA_TARGET_MODE,
                    AudioManager.RINGER_MODE_SILENT
            );
        }

        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(i);
        } else {
            startService(i);
        }

        refreshTile();
    }

    private void refreshTile() {
        Tile tile = getQsTile();
        if (tile == null) return;

        boolean active = AppPrefs.isTimerActive(this);

        tile.setState(
                active ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE
        );

        tile.setLabel("Nexa Silent");

        if (Build.VERSION.SDK_INT >= 29) {
            tile.setSubtitle(active ? "فعال" : "30 دقیقه");
        }

        tile.updateTile();
    }
}
