package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class SearchActivity extends Activity {
    private EditText q;
    private LinearLayout results;

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"Universal Search"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"جستجو بین یادآورها، دارو، خودرو، خرید، پرونده، مدارک، پرداخت‌ها و دارایی‌ها"),UiKit.matchWrap(this,0,14));

        q=new EditText(this);
        q.setHint("مثلاً دکتر احمدی، روغن، چک، پاسپورت...");
        q.setTextColor(UiKit.TEXT);
        q.setHintTextColor(UiKit.MUTED);
        q.setBackground(UiKit.field(this));
        q.setPadding(UiKit.dp(this,16),UiKit.dp(this,14),UiKit.dp(this,16),UiKit.dp(this,14));
        root.addView(q,UiKit.matchWrap(this,0,8));

        Button go=UiKit.primaryButton(this,"جستجو");
        go.setOnClickListener(v->search());
        root.addView(go,UiKit.matchWrap(this,0,14));

        results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);

        setContentView(sc);
    }

    private boolean has(String hay,String x){
        return hay!=null && hay.toLowerCase().contains(x);
    }

    private void search(){
        results.removeAllViews();
        String x=q.getText().toString().trim().toLowerCase();
        if(x.isEmpty())return;

        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            String hay=r.title+" "+r.category+" "+r.note+" "+r.doctorName+" "+r.doctorFileNumber+" "+r.doctorCenter+" "+r.doctorPhone+" "+r.doctorAddress;
            if(has(hay,x))add("📅 "+r.title,r.category+" • "+PersianDateUtil.pretty(r.whenMillis));
        }

        for(NexaStore.Medicine m:NexaStore.medicines(this))
            if(has(m.name+" "+m.dose,x))add("💊 "+m.name,m.dose);

        for(NexaStore.ServiceRecord s:NexaStore.services(this))
            if(has(s.category+" "+s.note,x))add("🔧 "+s.category,s.km+" km • "+s.note);

        for(NexaStore.Vehicle v:NexaStore.vehicles(this))
            if(has(v.name+" "+v.type,x))add("🚗 "+v.name,v.currentKm+" km");

        for(NexaStore.ShoppingItem i:NexaStore.shoppingItems(this))
            if(has(i.listName+" "+i.name+" "+i.quantity+" "+i.category,x))add("🛒 "+i.name,i.listName+(i.done?" • خریده شده":""));

        for(NexaStore.TodoItem t:NexaStore.todos(this))
            if(has(t.title+" "+t.category+" "+t.note,x))add("✓ "+t.title,t.category+(t.done?" • انجام شده":""));

        for(NexaStore.CaseItem c:NexaStore.cases(this))
            if(has(c.title+" "+c.caseNumber+" "+c.court+" "+c.branch+" "+c.counterparty+" "+c.lawyer+" "+c.note,x))
                add("⚖️ "+c.title,"پرونده "+c.caseNumber+" • "+c.court);

        for(NexaStore.VaultEntry v:NexaStore.vault(this))
            if(has(v.title+" "+v.type,x))add("🔐 "+v.title,v.type+" • جزئیات محرمانه در جستجو نمایش داده نمی‌شود");

        for(NexaStore.AssetEntry a:NexaStore.assets(this))
            if(has(a.name+" "+a.type+" "+a.note,x))add("📈 "+a.name,a.type+" • مقدار "+a.amount);

        for(NexaStore.DocumentItem d:NexaStore.documents(this))
            if(has(d.title+" "+d.type+" "+d.number+" "+d.note,x))add("📄 "+d.title,d.type+" • انقضا "+PersianDateUtil.format(d.expiryDate));

        for(NexaStore.BillItem b:NexaStore.bills(this))
            if(has(b.title+" "+b.type+" "+b.note,x))add("💳 "+b.title,b.type+" • "+PersianDateUtil.pretty(b.dueDate));

        for(NexaStore.HomeItem h:NexaStore.homeItems(this))
            if(has(h.title+" "+h.category+" "+h.note,x))add("🏠 "+h.title,h.category+" • "+PersianDateUtil.format(h.nextDueDate));

        if(results.getChildCount()==0){
            android.widget.TextView e=UiKit.muted(this,"چیزی پیدا نشد.");
            e.setGravity(Gravity.CENTER);
            results.addView(e,UiKit.matchWrap(this,20,0));
        }
    }

    private void add(String t,String s){
        LinearLayout c=UiKit.cardLayout(this);
        c.addView(UiKit.sectionTitle(this,t));
        c.addView(UiKit.muted(this,s),UiKit.matchWrap(this,5,0));
        results.addView(c,UiKit.matchWrap(this,0,8));
    }
}
