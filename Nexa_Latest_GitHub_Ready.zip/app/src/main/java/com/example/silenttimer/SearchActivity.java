package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.Locale;

public class SearchActivity extends Activity {
    private EditText q;
    private LinearLayout results;
    private TextView summary;
    private String lastQuery = "";

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"Universal Search"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"جستجو بین یادآورها، دارو، خودرو، خرید، پرونده، مدارک، پرداخت‌ها و دارایی‌ها"),UiKit.matchWrap(this,0,14));

        q=new EditText(this);
        q.setHint("مثلاً دکتر احمدی، روغن، چک، پاسپورت...");
        q.setTextColor(UiKit.TEXT);
        q.setHintTextColor(UiKit.MUTED);
        q.setBackground(UiKit.field(this));
        q.setPadding(UiKit.dp(this,16),UiKit.dp(this,14),UiKit.dp(this,16),UiKit.dp(this,14));
        root.addView(q,UiKit.matchWrap(this,0,8));
        q.setSingleLine(true);
        q.setOnEditorActionListener((v,action,event)->{search();return true;});
        q.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){if(s.length()==0){results.removeAllViews();summary.setText("برای شروع، عبارت جستجو را بنویس.");}}
            public void afterTextChanged(Editable e){}
        });

        Button go=UiKit.primaryButton(this,"جستجو");
        go.setOnClickListener(v->search());
        root.addView(go,UiKit.matchWrap(this,0,14));

        summary=UiKit.muted(this,"برای شروع، عبارت جستجو را بنویس.");
        summary.setGravity(Gravity.CENTER);
        root.addView(summary,UiKit.matchWrap(this,0,10));

        LinearLayout shortcuts=new LinearLayout(this);shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        Button today=UiKit.secondaryButton(this,"امروز");today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        Button timeline=UiKit.secondaryButton(this,"تایم‌لاین");timeline.setOnClickListener(v->startActivity(new Intent(this,TimelineActivity.class)));
        shortcuts.addView(today,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,-2,1f);tlp.setMargins(UiKit.dp(this,6),0,0,0);shortcuts.addView(timeline,tlp);
        root.addView(shortcuts,UiKit.matchWrap(this,0,12));

        results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);

        setContentView(sc);
    }

    private String norm(String s){
        if(s==null)return "";
        return s.toLowerCase(Locale.ROOT).replace('ي','ی').replace('ى','ی').replace('ك','ک').replace("‌","").trim();
    }
    private boolean has(String hay,String x){return norm(hay).contains(norm(x));}

    private int score(String hay,String x){
        String h=norm(hay),n=norm(x);if(h.equals(n))return 4;if(h.startsWith(n))return 3;if(h.contains(" "+n))return 2;return h.contains(n)?1:0;
    }

    private void search(){
        results.removeAllViews();
        String x=norm(q.getText().toString());
        lastQuery=x;
        if(x.isEmpty()){summary.setText("برای شروع، عبارت جستجو را بنویس.");return;}
        int[] count={0};

        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            String hay=r.title+" "+r.category+" "+r.note+" "+r.doctorName+" "+r.doctorFileNumber+" "+r.doctorCenter+" "+r.doctorPhone+" "+r.doctorAddress;
            if(has(hay,x)){Intent i=new Intent(this,ReminderEditActivity.class);i.putExtra("edit_id",r.id);add("📅 "+r.title,r.category+" • "+PersianDateUtil.pretty(r.whenMillis),i,score(r.title,x));count[0]++;}
        }

        for(NexaStore.Medicine m:NexaStore.medicines(this))
            if(has(m.name+" "+m.dose,x)){add("💊 "+m.name,m.dose,new Intent(this,MedicineActivity.class),score(m.name,x));count[0]++;}

        for(NexaStore.ServiceRecord s:NexaStore.services(this))
            if(has(s.category+" "+s.note,x)){add("🔧 "+s.category,s.km+" km • "+s.note,new Intent(this,GarageActivity.class),score(s.category,x));count[0]++;}

        for(NexaStore.Vehicle v:NexaStore.vehicles(this))
            if(has(v.name+" "+v.type,x)){Intent i=new Intent(this,VehicleActivity.class);i.putExtra("id",v.id);add("🚗 "+v.name,v.currentKm+" km",i,score(v.name,x));count[0]++;}

        for(NexaStore.ShoppingItem i:NexaStore.shoppingItems(this))
            if(has(i.listName+" "+i.name+" "+i.quantity+" "+i.category,x)){add("🛒 "+i.name,i.listName+(i.done?" • خریده شده":""),new Intent(this,NexaListActivity.class),score(i.name,x));count[0]++;}

        for(NexaStore.TodoItem t:NexaStore.todos(this))
            if(has(t.title+" "+t.category+" "+t.note,x)){add("✓ "+t.title,t.category+(t.done?" • انجام شده":""),new Intent(this,NexaListActivity.class),score(t.title,x));count[0]++;}

        for(NexaStore.CaseItem c:NexaStore.cases(this))
            if(has(c.title+" "+c.caseNumber+" "+c.court+" "+c.branch+" "+c.counterparty+" "+c.lawyer+" "+c.note,x)){
                add("⚖️ "+c.title,"پرونده "+c.caseNumber+" • "+c.court,new Intent(this,CaseActivity.class),score(c.title,x));count[0]++;
            }

        for(NexaStore.VaultEntry v:NexaStore.vault(this))
            if(has(v.title+" "+v.type,x)){add("🔐 "+v.title,v.type+" • جزئیات محرمانه در جستجو نمایش داده نمی‌شود",new Intent(this,VaultActivity.class),score(v.title,x));count[0]++;}

        for(NexaStore.AssetEntry a:NexaStore.assets(this))
            if(has(a.name+" "+a.type+" "+a.note,x)){add("📈 "+a.name,a.type+" • مقدار "+a.amount,new Intent(this,AssetsActivity.class),score(a.name,x));count[0]++;}

        for(NexaStore.DocumentItem d:NexaStore.documents(this))
            if(has(d.title+" "+d.type+" "+d.number+" "+d.note,x)){add("📄 "+d.title,d.type+" • انقضا "+PersianDateUtil.format(d.expiryDate),new Intent(this,DocsActivity.class),score(d.title,x));count[0]++;}

        for(NexaStore.BillItem b:NexaStore.bills(this))
            if(has(b.title+" "+b.type+" "+b.note,x)){add("💳 "+b.title,b.type+" • "+PersianDateUtil.pretty(b.dueDate),new Intent(this,BillsActivity.class),score(b.title,x));count[0]++;}

        for(NexaStore.HomeItem h:NexaStore.homeItems(this))
            if(has(h.title+" "+h.category+" "+h.note,x)){add("🏠 "+h.title,h.category+" • "+PersianDateUtil.format(h.nextDueDate),new Intent(this,HomeCareActivity.class),score(h.title,x));count[0]++;}

        summary.setText("🔎 "+count[0]+" نتیجه برای «"+q.getText().toString().trim()+"»");
        if(results.getChildCount()==0){
            android.widget.TextView e=UiKit.muted(this,"چیزی پیدا نشد.");
            e.setGravity(Gravity.CENTER);
            results.addView(e,UiKit.matchWrap(this,20,0));
        }
    }

    private void add(String t,String s,Intent target,int relevance){
        LinearLayout c=UiKit.cardLayout(this);
        c.addView(UiKit.sectionTitle(this,t));
        c.addView(UiKit.muted(this,s),UiKit.matchWrap(this,5,0));
        if(relevance>=3)c.addView(UiKit.muted(this,"★ تطابق قوی"),UiKit.matchWrap(this,4,0));
        if(target!=null)c.setOnClickListener(v->startActivity(target));
        results.addView(c,UiKit.matchWrap(this,0,8));
    }
}
