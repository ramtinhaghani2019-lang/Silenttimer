package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.HorizontalScrollView;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import java.util.HashMap;
import java.util.Map;

public class SearchActivity extends Activity {
    private EditText q;
    private LinearLayout results;
    private TextView summary;
    private String lastQuery = "";
    private final List<SearchHit> hits=new ArrayList<>();
    private LinearLayout filterBar;
    private HorizontalScrollView filters;
    private int selectedFilter=SearchDisplayPolicy.ALL;
    private static final class SearchHit{
        final String title,detail;final Intent target;final int score,group,order;
        SearchHit(String t,String d,Intent i,int s,int g,int o){title=t;detail=d;target=i;score=s;group=g;order=o;}
    }

    @Override
    protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if(b!=null){
            String restored=b.getString("nexa.search.query","");
            if(!restored.trim().isEmpty()){
                q.setText(restored);
                search();
                int previous=b.getInt("nexa.search.filter",SearchDisplayPolicy.ALL);
                if(previous>=SearchDisplayPolicy.ALL && previous<SearchDisplayPolicy.FILTERS.length){
                    selectedFilter=previous;
                    showResults();
                }
            }
        }
    }

    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        root.addView(UiKit.header(this,"جستجوی نِکسا",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"یادآوری‌ها، طرف‌حساب‌ها، اقساط، پرونده‌ها و سایر بخش‌ها را یکجا پیدا کن."),UiKit.matchWrap(this,0,12));

        q=UiKit.styleField(this,new EditText(this),"نام طرف‌حساب، شماره پرونده، قبض، دارو...");
        root.addView(q,UiKit.matchWrap(this,0,8));
        q.setSingleLine(true);
        q.setOnEditorActionListener((v,action,event)->{search();return true;});
        q.addTextChangedListener(new TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){
                if(summary==null||results==null)return;
                if(!norm(s.toString()).equals(lastQuery)){
                    hits.clear();results.removeAllViews();selectedFilter=SearchDisplayPolicy.ALL;
                    if(filters!=null)filters.setVisibility(View.GONE);
                    summary.setText(s.length()==0?"برای شروع، عبارت جستجو را بنویس.":"برای مشاهده نتیجه‌ها، جستجو را بزن.");
                }
            }
            public void afterTextChanged(Editable e){}
        });

        LinearLayout searchActions=new LinearLayout(this);
        searchActions.setOrientation(LinearLayout.HORIZONTAL);
        searchActions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button go=UiKit.primaryButton(this,"🔎 جستجو");
        go.setOnClickListener(v->search());
        searchActions.addView(go,new LinearLayout.LayoutParams(0,-2,1f));
        Button clear=UiKit.secondaryButton(this,"پاک‌کردن");
        clear.setOnClickListener(v->{q.setText("");q.requestFocus();});
        LinearLayout.LayoutParams clearParams=new LinearLayout.LayoutParams(0,-2,1f);
        clearParams.setMargins(UiKit.dp(this,8),0,0,0);
        searchActions.addView(clear,clearParams);
        root.addView(searchActions,UiKit.matchWrap(this,0,12));

        summary=UiKit.muted(this,"برای شروع، عبارت جستجو را بنویس.");
        summary.setGravity(Gravity.CENTER);
        root.addView(summary,UiKit.matchWrap(this,0,10));

        LinearLayout shortcuts=new LinearLayout(this);shortcuts.setOrientation(LinearLayout.HORIZONTAL);
        Button today=UiKit.secondaryButton(this,"امروز");today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        Button timeline=UiKit.secondaryButton(this,"تایم‌لاین");timeline.setOnClickListener(v->startActivity(new Intent(this,TimelineActivity.class)));
        shortcuts.addView(today,new LinearLayout.LayoutParams(0,-2,1f));
        LinearLayout.LayoutParams tlp=new LinearLayout.LayoutParams(0,-2,1f);tlp.setMargins(UiKit.dp(this,6),0,0,0);shortcuts.addView(timeline,tlp);
        root.addView(shortcuts,UiKit.matchWrap(this,0,12));

        HorizontalScrollView filters=new HorizontalScrollView(this);
        filters.setHorizontalScrollBarEnabled(false);
        filterBar=new LinearLayout(this);
        filterBar.setOrientation(LinearLayout.HORIZONTAL);
        filterBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        filters.addView(filterBar);
        filters.setVisibility(View.GONE);
        root.addView(filters,UiKit.matchWrap(this,0,12));
        this.filters=filters;

        results=new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);

        setContentView(sc);
    }

    private String norm(String s){return SearchQueryPolicy.normalize(s);}
    private boolean has(String hay,String x){return SearchQueryPolicy.matches(hay,x);}
    private int score(String hay,String x){return SearchQueryPolicy.score(hay,x);}

    @Override protected void onSaveInstanceState(Bundle state){
        state.putString("nexa.search.query",q==null?"":q.getText().toString());
        state.putInt("nexa.search.filter",selectedFilter);
        super.onSaveInstanceState(state);
    }

    private void search(){
        hits.clear();results.removeAllViews();
        String x=norm(q.getText().toString());
        lastQuery=x;
        selectedFilter=SearchDisplayPolicy.ALL;
        if(x.isEmpty()){filters.setVisibility(View.GONE);summary.setText("برای شروع، عبارت جستجو را بنویس.");return;}

        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            String hay=r.title+" "+r.category+" "+r.note+" "+r.doctorName+" "+r.doctorFileNumber+" "+r.doctorCenter+" "+r.doctorPhone+" "+r.doctorAddress;
            if(has(hay,x)){Intent i=new Intent(this,ReminderEditActivity.class);i.putExtra("edit_id",r.id);add("📅 "+r.title,r.category+" • "+PersianDateUtil.pretty(r.whenMillis),i,score(r.title,x),SearchDisplayPolicy.TASKS);}
        }

        // Search by account name, phone, private notes or transaction descriptions;
        // previews intentionally reveal neither phone numbers nor transaction notes.
        Map<String,StringBuilder> partyNotes=new HashMap<>();
        for(NexaStore.LedgerEntry entry:NexaStore.ledgerEntries(this)){
            if(entry==null || entry.partyId==null || entry.note==null || entry.note.isEmpty())continue;
            StringBuilder notes=partyNotes.get(entry.partyId);
            if(notes==null){notes=new StringBuilder();partyNotes.put(entry.partyId,notes);}
            notes.append(' ').append(entry.note);
        }
        for(NexaStore.LedgerParty p:NexaStore.ledgerParties(this)){
            if(p==null || p.id==null || p.id.isEmpty())continue;
            String label=p.name==null?"":p.name;
            String content=label+" "+p.phone+" "+p.note+" "+
                    (partyNotes.containsKey(p.id)?partyNotes.get(p.id).toString():"");
            if(!has(content,x))continue;
            Intent target=new Intent(this,LedgerActivity.class);
            target.putExtra(LedgerActivity.EXTRA_OPEN_PARTY_ID,p.id);
            long balance=NexaStore.ledgerBalance(this,p.id);
            String status=balance>0?"طلب من":balance<0?"بدهی من":"تسویه‌شده";
            // Avoid Math.abs(Long.MIN_VALUE) overflow in the read-only preview.
            long absolute=balance==Long.MIN_VALUE?Long.MAX_VALUE:Math.abs(balance);
            String info=balance==0?"طرف‌حساب • تسویه‌شده":
                    "طرف‌حساب • "+status+": "+PersianFinancialDisplay.amount(absolute)+" تومان";
            add("👤 "+label,info,target,score(label,x)>0?score(label,x):score(content,x),SearchDisplayPolicy.FINANCE);
        }

        for(NexaStore.Medicine m:NexaStore.medicines(this))
            if(has(m.name+" "+m.dose,x)){add("💊 "+m.name,m.dose,new Intent(this,MedicineActivity.class),score(m.name,x),SearchDisplayPolicy.HEALTH);}

        for(NexaStore.ServiceRecord s:NexaStore.services(this))
            if(has(s.category+" "+s.note,x)){add("🔧 "+s.category,s.km+" km • "+s.note,new Intent(this,GarageActivity.class),score(s.category,x),SearchDisplayPolicy.CARE);}

        for(NexaStore.Vehicle v:NexaStore.vehicles(this))
            if(has(v.name+" "+v.type,x)){Intent i=new Intent(this,VehicleActivity.class);i.putExtra("id",v.id);add("🚗 "+v.name,v.currentKm+" km",i,score(v.name,x),SearchDisplayPolicy.CARE);}

        for(NexaStore.ShoppingItem i:NexaStore.shoppingItems(this))
            if(has(i.listName+" "+i.name+" "+i.quantity+" "+i.category,x)){add("🛒 "+i.name,i.listName+(i.done?" • خریده شده":""),new Intent(this,NexaListActivity.class),score(i.name,x),SearchDisplayPolicy.TASKS);}

        for(NexaStore.TodoItem t:NexaStore.todos(this))
            if(has(t.title+" "+t.category+" "+t.note,x)){add("✓ "+t.title,t.category+(t.done?" • انجام شده":""),new Intent(this,NexaListActivity.class),score(t.title,x),SearchDisplayPolicy.TASKS);}

        for(NexaStore.CaseItem c:NexaStore.cases(this))
            if(has(c.title+" "+c.caseNumber+" "+c.court+" "+c.branch+" "+c.counterparty+" "+c.lawyer+" "+c.note,x)){
                add("⚖️ "+c.title,"پرونده "+c.caseNumber+" • "+c.court,new Intent(this,CaseActivity.class),score(c.title,x),SearchDisplayPolicy.OTHER);
            }

        for(NexaStore.VaultEntry v:NexaStore.vault(this))
            if(has(v.title+" "+v.type,x)){add("🔐 "+v.title,v.type+" • جزئیات محرمانه در جستجو نمایش داده نمی‌شود",new Intent(this,VaultActivity.class),score(v.title,x),SearchDisplayPolicy.OTHER);}

        for(NexaStore.AssetEntry a:NexaStore.assets(this))
            if(has(a.name+" "+a.type+" "+a.note,x)){add("📈 "+a.name,a.type+" • مقدار "+a.amount,new Intent(this,AssetsActivity.class),score(a.name,x),SearchDisplayPolicy.FINANCE);}

        for(NexaStore.DocumentItem d:NexaStore.documents(this))
            if(has(d.title+" "+d.type+" "+d.number+" "+d.note,x)){add("📄 "+d.title,d.type+" • انقضا "+PersianDateUtil.format(d.expiryDate),new Intent(this,DocsActivity.class),score(d.title,x),SearchDisplayPolicy.OTHER);}

        for(NexaStore.BillItem b:NexaStore.bills(this))
            if(has(b.title+" "+b.type+" "+b.note,x)){add("💳 "+b.title,b.type+" • "+PersianDateUtil.pretty(b.dueDate),new Intent(this,BillsActivity.class),score(b.title,x),SearchDisplayPolicy.FINANCE);}

        for(NexaStore.HomeItem h:NexaStore.homeItems(this))
            if(has(h.title+" "+h.category+" "+h.note,x)){add("🏠 "+h.title,h.category+" • "+PersianDateUtil.format(h.nextDueDate),new Intent(this,HomeCareActivity.class),score(h.title,x),SearchDisplayPolicy.CARE);}

        Collections.sort(hits,(a,b)->SearchDisplayPolicy.compare(a.score,a.order,b.score,b.order));
        filters.setVisibility(View.VISIBLE);
        showResults();
    }

    private void showResults(){
        results.removeAllViews();filterBar.removeAllViews();
        for(int i=0;i<SearchDisplayPolicy.FILTERS.length;i++){
            final int which=i;
            TextView chip=NexaActionUi.categoryChip(this,SearchDisplayPolicy.FILTERS[i],selectedFilter==i);
            chip.setOnClickListener(v->{selectedFilter=which;showResults();});
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);
            if(i>0)cp.setMargins(UiKit.dp(this,7),0,0,0);
            filterBar.addView(chip,cp);
        }
        int shown=0;
        for(SearchHit h:hits){
            if(!SearchDisplayPolicy.matches(selectedFilter,h.group))continue;
            shown++;
            LinearLayout card=NexaActionUi.result(this,h.title,h.detail,
                    SearchDisplayPolicy.FILTERS[h.group],h.score>=3);
            if(h.target!=null)card.setOnClickListener(v->startActivity(h.target));
            results.addView(card,UiKit.matchWrap(this,0,8));
        }
        summary.setText("🔎 "+SearchDisplayPolicy.countLabel(shown,hits.size(),selectedFilter));
        if(shown==0)results.addView(UiKit.emptyState(this,"نتیجه‌ای در این دسته پیدا نشد", 
                 "فیلتر «همه» یا عبارت دیگری را امتحان کن."),UiKit.matchWrap(this,8,4));
    }

    private void add(String title,String detail,Intent target,int relevance,int group){
        hits.add(new SearchHit(title,detail,target,relevance,group,hits.size()));
    }
}
