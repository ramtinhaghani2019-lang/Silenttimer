package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Visual-only reminder components. No access to persistence, alarms or scheduling. */
final class NexaReminderUi {
    private NexaReminderUi() {}

    static LinearLayout metrics(Context c,int pending,int overdue,int completed) {
        LinearLayout strip=new LinearLayout(c);
        boolean stacked=HomeUi.shouldStack(c);
        strip.setOrientation(stacked?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        strip.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] labels={"در انتظار","معوق","انجام‌شده"};
        int[] values={pending,overdue,completed};
        int[] colors={UiKit.PURPLE,UiKit.RED,UiKit.GREEN};
        int[] variants={5,4,3};
        for(int i=0;i<labels.length;i++) {
            LinearLayout tile=UiKit.cardLayout(c);
            tile.setPadding(UiKit.dp(c,11),UiKit.dp(c,11),UiKit.dp(c,11),UiKit.dp(c,10));
            tile.setBackground(UiKit.card(c));
            tile.setMinimumHeight(UiKit.dp(c,79));
            TextView count=UiKit.sectionTitle(c,String.valueOf(values[i]));
            count.setTextColor(colors[i]);count.setTextSize(23f);count.setGravity(Gravity.RIGHT);
            tile.addView(count);
            TextView label=UiKit.muted(c,labels[i]);label.setTextSize(11.5f);
            tile.addView(label,UiKit.matchWrap(c,2,0));
            tile.setContentDescription(labels[i]+"، "+values[i]+" مورد");
            LinearLayout.LayoutParams lp=stacked?new LinearLayout.LayoutParams(-1,-2):
                new LinearLayout.LayoutParams(0,-2,1f);
            if(i>0){if(stacked)lp.topMargin=UiKit.dp(c,7);else lp.leftMargin=UiKit.dp(c,7);}
            strip.addView(tile,lp);
        }
        return strip;
    }

    static TextView filterChip(Context c,String title,boolean active) {
        TextView chip=UiKit.chip(c,title,active);
        chip.setTextSize(12.5f);
        chip.setMinimumHeight(UiKit.dp(c,44));
        chip.setGravity(Gravity.CENTER);
        chip.setContentDescription("نمایش "+title+(active?"، انتخاب‌شده":""));
        UiKit.touchFeedback(c,chip,UiKit.PURPLE,18);
        return chip;
    }

    static LinearLayout reminderCard(Context c,boolean overdue,boolean completed) {
        LinearLayout card=UiKit.cardLayout(c);
        card.setPadding(UiKit.dp(c,12),UiKit.dp(c,11),UiKit.dp(c,12),UiKit.dp(c,11));
        card.setBackground(overdue?UiKit.subtlePastCard(c):
                UiKit.colorfulCard(c,completed?3:5));
        card.setMinimumHeight(UiKit.dp(c,82));
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return card;
    }

    static TextView state(Context c,String text,int color) {
        TextView badge=UiKit.statusBadge(c,text,color);
        badge.setTextSize(11.5f);
        badge.setMinHeight(UiKit.dp(c,32));
        badge.setTextColor(color);
        return badge;
    }

    static LinearLayout formSection(Context c,String title,String subtitle) {
        LinearLayout card=UiKit.cardLayout(c);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.addView(UiKit.sectionTitle(c,title));
        if(subtitle!=null&&!subtitle.isEmpty())
            card.addView(UiKit.muted(c,subtitle),UiKit.matchWrap(c,5,10));
        return card;
    }
}
