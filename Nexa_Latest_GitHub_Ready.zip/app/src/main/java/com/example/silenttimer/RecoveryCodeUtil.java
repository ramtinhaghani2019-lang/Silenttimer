package com.example.silenttimer;
import java.security.SecureRandom;
public final class RecoveryCodeUtil {
    private static final char[] CHARS="ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray();
    private RecoveryCodeUtil(){}
    public static String generate(){SecureRandom r=new SecureRandom();StringBuilder s=new StringBuilder();for(int g=0;g<4;g++){if(g>0)s.append('-');for(int i=0;i<4;i++)s.append(CHARS[r.nextInt(CHARS.length)]);}return s.toString();}
}
