package com.example.silenttimer;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Presentation-only surfaces for the case directory; no persistence or scheduling. */
final class NexaCaseUi {
    private NexaCaseUi() { }

    static HorizontalScrollView metrics(Context c, int total, int future, int past) {
        HorizontalScrollView sc = new HorizontalScrollView(c);
        sc.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(c);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setOrientation(LinearLayout.HORIZONTAL);
        addMetric(c, row, "کل پرونده‌ها", total, UiKit.PURPLE);
        addMetric(c, row, "جلسات آینده", future, UiKit.BLUE);
        addMetric(c, row, "جلسات گذشته", past, UiKit.RED);
        sc.addView(row);
        sc.setContentDescription("خلاصه امور حقوقی: " + total + " پرونده، " + future
                + " جلسه آینده و " + past + " جلسه گذشته");
        return sc;
    }

    private static void addMetric(Context c, LinearLayout row, String name, int count, int color) {
        LinearLayout tile = UiKit.financialMetric(c, name, String.valueOf(count), color);
        tile.setMinimumHeight(UiKit.dp(c, 84));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UiKit.dp(c, 139), -2);
        lp.setMargins(UiKit.dp(c, 2), 0, UiKit.dp(c, 7), 0);
        row.addView(tile, lp);
    }

    static Button chip(Context c, String label, boolean selected) {
        Button b = UiKit.secondaryButton(c, (selected ? "✓  " : "") + label);
        b.setMinHeight(UiKit.dp(c, 48));
        b.setTextSize(13f);
        b.setTextColor(selected ? android.graphics.Color.WHITE : UiKit.TEXT);
        b.setBackground(UiKit.rounded(c, selected ? 0xFF7441D7 : UiKit.FIELD, 15));
        UiKit.touchFeedback(c, b, UiKit.GOLD, 15);
        b.setContentDescription("نمایش " + label + (selected ? "، انتخاب‌شده" : ""));
        return b;
    }

    static TextView status(Context c, boolean past) {
        TextView t = UiKit.statusBadge(c, past ? "● جلسه گذشته" : "◷ جلسه پیش‌رو",
                past ? UiKit.RED : UiKit.BLUE);
        t.setContentDescription(past ? "جلسه گذشته" : "جلسه آینده");
        return t;
    }

    static LinearLayout empty(Context c, boolean filtered) {
        LinearLayout card = UiKit.cardLayout(c);
        card.setMinimumHeight(UiKit.dp(c, 104));
        card.setGravity(Gravity.CENTER);
        TextView title = UiKit.sectionTitle(c, filtered ? "در این بخش موردی نیست" : "هنوز پرونده‌ای ثبت نشده");
        title.setGravity(Gravity.CENTER);
        card.addView(title);
        TextView subtitle = UiKit.muted(c, filtered ? "فیلتر «همه» را انتخاب کنید." : "با دکمه ثبت، اولین پرونده یا جلسه را اضافه کنید.");
        subtitle.setGravity(Gravity.CENTER);
        card.addView(subtitle, UiKit.matchWrap(c, 7, 0));
        return card;
    }
}
