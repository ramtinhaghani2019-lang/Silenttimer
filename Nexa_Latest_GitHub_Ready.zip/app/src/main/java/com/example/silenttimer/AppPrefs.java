package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public final class AppPrefs {
    private static final String NAME = "silent_timer_prefs";
    private static final String KEY_CONTACTS = "allowed_contacts_json";

    private AppPrefs() {}

    public static final class ContactEntry {
        public final String name;
        public final String number;

        public ContactEntry(String name, String number) {
            this.name = name == null ? "" : name;
            this.number = number == null ? "" : number;
        }
    }

    private static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    public static void setMinutes(Context c, int value) {
        int v = Math.max(5, Math.min(720, value));
        v = ((v + 4) / 5) * 5;
        prefs(c).edit().putInt("minutes", v).apply();
    }

    public static int getMinutes(Context c) {
        int v = prefs(c).getInt("minutes", 30);
        v = Math.max(5, Math.min(720, v));
        return ((v + 4) / 5) * 5;
    }


    public static void setEndAt(Context c, long value) {
        prefs(c).edit().putLong("end_at", value).apply();
    }

    public static long getEndAt(Context c) {
        return prefs(c).getLong("end_at", 0L);
    }

    public static void setStartAt(Context c, long value) {
        prefs(c).edit().putLong("start_at", value).apply();
    }

    public static long getStartAt(Context c) {
        return prefs(c).getLong("start_at", 0L);
    }

    public static boolean isTimerActive(Context c) {
        return getEndAt(c) > System.currentTimeMillis();
    }

    public static void setTargetRingerMode(Context c, int value) {
        prefs(c).edit().putInt("target_ringer_mode", value).apply();
    }

    public static int getTargetRingerMode(Context c) {
        return prefs(c).getInt("target_ringer_mode", AudioManager.RINGER_MODE_SILENT);
    }

    /** Persist the exact ringer mode that existed before a Nexa Silent Timer starts. */
    public static void setTimerPreviousRingerMode(Context c, int mode) {
        int safe = mode;
        if (safe != AudioManager.RINGER_MODE_NORMAL
                && safe != AudioManager.RINGER_MODE_SILENT
                && safe != AudioManager.RINGER_MODE_VIBRATE) {
            safe = AudioManager.RINGER_MODE_NORMAL;
        }
        prefs(c).edit()
                .putInt("timer_previous_ringer_mode", safe)
                .putBoolean("timer_previous_ringer_mode_valid", true)
                .apply();
    }

    public static boolean hasTimerPreviousRingerMode(Context c) {
        return prefs(c).getBoolean("timer_previous_ringer_mode_valid", false);
    }

    public static int getTimerPreviousRingerMode(Context c) {
        int mode = prefs(c).getInt("timer_previous_ringer_mode", AudioManager.RINGER_MODE_NORMAL);
        if (mode != AudioManager.RINGER_MODE_NORMAL
                && mode != AudioManager.RINGER_MODE_SILENT
                && mode != AudioManager.RINGER_MODE_VIBRATE) {
            return AudioManager.RINGER_MODE_NORMAL;
        }
        return mode;
    }

    public static void clearTimer(Context c) {
        prefs(c).edit()
                .remove("end_at")
                .remove("start_at")
                .remove("target_ringer_mode")
                .remove("timer_previous_ringer_mode")
                .remove("timer_previous_ringer_mode_valid")
                .apply();
    }

    public static void setMissedCallGuardEnabled(Context c, boolean value) {
        prefs(c).edit().putBoolean("missed_call_guard_enabled", value).apply();
    }

    public static boolean isMissedCallGuardEnabled(Context c) {
        return prefs(c).getBoolean("missed_call_guard_enabled", true);
    }

    public static void setMissedCallShowName(Context c, boolean value) {
        prefs(c).edit().putBoolean("missed_call_show_name", value).apply();
    }

    public static boolean isMissedCallShowName(Context c) {
        return prefs(c).getBoolean("missed_call_show_name", true);
    }

    public static void setMissedCallShowNumber(Context c, boolean value) {
        prefs(c).edit().putBoolean("missed_call_show_number", value).apply();
    }

    public static boolean isMissedCallShowNumber(Context c) {
        return prefs(c).getBoolean("missed_call_show_number", true);
    }

    public static void setMissedCallShowTime(Context c, boolean value) {
        prefs(c).edit().putBoolean("missed_call_show_time", value).apply();
    }

    public static boolean isMissedCallShowTime(Context c) {
        return prefs(c).getBoolean("missed_call_show_time", true);
    }

    public static void setAllowedCallsEnabled(Context c, boolean value) {
        prefs(c).edit().putBoolean("allowed_calls_enabled", value).apply();
    }

    public static boolean isAllowedCallsEnabled(Context c) {
        return prefs(c).getBoolean("allowed_calls_enabled", true);
    }

    public static void setMonitoringEnabled(Context c, boolean value) {
        prefs(c).edit().putBoolean("monitoring_enabled", value).apply();
    }

    public static boolean isMonitoringEnabled(Context c) {
        return prefs(c).getBoolean("monitoring_enabled", true);
    }

    /** One-time safety migration for 5.4.2 hotfix.
     * Old builds defaulted background ringer monitoring to ON. That could show
     * a Silent/Vibrate overlay immediately when Nexa started. Monitoring is now
     * opt-in and an existing intentional timer is never interrupted.
     */
    public static void applyLaunchSafetyMigration(Context c) {
        SharedPreferences sp=prefs(c);
        if(sp.getBoolean("launch_safety_migration_5423", false)) return;
        SharedPreferences.Editor e=sp.edit().putBoolean("launch_safety_migration_5423", true);
        // Keep the user choice. New installs default monitoring to ON; launch must not rewrite it.
        e.putLong("ignore_manual_until", System.currentTimeMillis()+4000L).apply();
    }

    public static void setBypassActive(Context c, boolean value) {
        prefs(c).edit().putBoolean("bypass_active", value).apply();
    }

    public static boolean isBypassActive(Context c) {
        return prefs(c).getBoolean("bypass_active", false);
    }

    public static void setBypassRestoreMode(Context c, int mode) {
        prefs(c).edit().putInt("bypass_restore_mode", mode).apply();
    }

    public static int getBypassRestoreMode(Context c) {
        return prefs(c).getInt("bypass_restore_mode", AudioManager.RINGER_MODE_SILENT);
    }

    public static void setIgnoreManualUntil(Context c, long value) {
        prefs(c).edit().putLong("ignore_manual_until", value).apply();
    }

    public static long getIgnoreManualUntil(Context c) {
        return prefs(c).getLong("ignore_manual_until", 0L);
    }

    public static void setSetupCompleted(Context c, boolean value) {
        prefs(c).edit().putBoolean("setup_completed", value).apply();
    }

    public static boolean isSetupCompleted(Context c) {
        return prefs(c).getBoolean("setup_completed", false);
    }

    public static List<ContactEntry> getAllowedContacts(Context c) {
        List<ContactEntry> result = new ArrayList<>();
        String raw = prefs(c).getString(KEY_CONTACTS, "[]");

        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.optJSONObject(i);
                if (obj == null) continue;

                String name = obj.optString("name", "");
                String number = obj.optString("number", "");

                if (!number.trim().isEmpty()) {
                    result.add(new ContactEntry(name, number));
                }
            }
        } catch (Exception ignored) {}

        return result;
    }

    public static void addAllowedContact(Context c, String name, String number) {
        String cleanNumber = number == null ? "" : number.trim();
        if (cleanNumber.isEmpty()) return;

        List<ContactEntry> list = getAllowedContacts(c);

        for (ContactEntry entry : list) {
            if (numbersMatch(entry.number, cleanNumber)) return;
        }

        list.add(new ContactEntry(name == null ? "" : name.trim(), cleanNumber));
        saveContacts(c, list);
    }

    public static void removeAllowedContact(Context c, int index) {
        List<ContactEntry> list = getAllowedContacts(c);
        if (index < 0 || index >= list.size()) return;
        list.remove(index);
        saveContacts(c, list);
    }

    public static boolean isAllowedNumber(Context c, String incoming) {
        if (!isAllowedCallsEnabled(c)) return false;
        if (incoming == null || incoming.trim().isEmpty()) return false;

        for (ContactEntry entry : getAllowedContacts(c)) {
            if (numbersMatch(entry.number, incoming)) return true;
        }
        return false;
    }

    private static void saveContacts(Context c, List<ContactEntry> list) {
        JSONArray array = new JSONArray();

        try {
            for (ContactEntry entry : list) {
                JSONObject obj = new JSONObject();
                obj.put("name", entry.name);
                obj.put("number", entry.number);
                array.put(obj);
            }
        } catch (Exception ignored) {}

        prefs(c).edit().putString(KEY_CONTACTS, array.toString()).apply();
    }

    public static boolean numbersMatch(String a, String b) {
        String x = normalizeNumber(a);
        String y = normalizeNumber(b);

        if (x.length() < 7 || y.length() < 7) return false;

        int compare = Math.min(10, Math.min(x.length(), y.length()));

        return x.substring(x.length() - compare)
                .equals(y.substring(y.length() - compare));
    }

    public static String normalizeNumber(String value) {
        if (value == null) return "";
        return value.replaceAll("[^0-9]", "");
    }
    /** Alarm ring duration in milliseconds. 0 means keep ringing until the user acknowledges it. */
    public static void setAlarmRingDurationMs(Context c, long value) {
        long v = value;
        if (v != 0L && v != 30_000L && v != 60_000L && v != 120_000L && v != 300_000L) v = 0L;
        prefs(c).edit().putLong("alarm_ring_duration_ms", v).apply();
    }

    public static long getAlarmRingDurationMs(Context c) {
        final String key = "alarm_ring_duration_ms";
        SharedPreferences sp = prefs(c);
        Object raw = sp.getAll().get(key);
        long v = 0L;

        // Older Nexa builds/backups could store this preference as Integer.
        // Read any numeric representation safely, then migrate it to Long.
        if (raw instanceof Number) {
            v = ((Number) raw).longValue();
        } else if (raw instanceof String) {
            try { v = Long.parseLong((String) raw); } catch (NumberFormatException ignored) { v = 0L; }
        }

        if (v != 0L && v != 30_000L && v != 60_000L && v != 120_000L && v != 300_000L) v = 0L;

        if (!(raw instanceof Long) || ((Long) raw).longValue() != v) {
            sp.edit().putLong(key, v).apply();
        }
        return v;
    }


}
