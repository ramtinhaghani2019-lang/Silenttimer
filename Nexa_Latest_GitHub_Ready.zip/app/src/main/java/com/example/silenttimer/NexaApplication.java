package com.example.silenttimer;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

/** Application-wide five-minute active polling, independent of current Nexa screen. */
public final class NexaApplication extends Application implements Application.ActivityLifecycleCallbacks {
    private final Handler main=new Handler(Looper.getMainLooper());
    private int visibleActivities;
    private final Runnable foregroundTick=new Runnable(){
        @Override public void run(){
            if(visibleActivities<=0)return;
            MarketRefreshScheduler.sync(NexaApplication.this);
            MarketRefreshScheduler.refreshIfDue(NexaApplication.this);
            main.postDelayed(this,MarketRefreshScheduler.FOREGROUND_PERIOD_MS);
        }
    };
    @Override public void onCreate(){super.onCreate();registerActivityLifecycleCallbacks(this);NexaStore.migrateAutoMarketRefresh237(this);MarketRefreshScheduler.sync(this);}
    @Override public void onActivityStarted(Activity a){
        if(++visibleActivities==1){main.removeCallbacks(foregroundTick);main.post(foregroundTick);}
    }
    @Override public void onActivityStopped(Activity a){
        visibleActivities=Math.max(0,visibleActivities-1);
        if(visibleActivities==0)main.removeCallbacks(foregroundTick);
    }
    @Override public void onActivityCreated(Activity a,Bundle b){}
    @Override public void onActivityResumed(Activity a){}
    @Override public void onActivityPaused(Activity a){}
    @Override public void onActivitySaveInstanceState(Activity a,Bundle out){}
    @Override public void onActivityDestroyed(Activity a){}
}
