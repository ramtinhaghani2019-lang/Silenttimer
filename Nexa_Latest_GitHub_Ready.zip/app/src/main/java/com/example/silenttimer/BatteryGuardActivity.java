package com.example.silenttimer;

import android.app.Activity;
import android.content.*;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

/** Read-only battery health dashboard. Does not hold wake locks or keep the screen on. */
public class BatteryGuardActivity extends Activity {
    private TextView status;
    private final BroadcastReceiver batteryReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){render(i);}};
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();IntentFilter f=new IntentFilter(Intent.ACTION_BATTERY_CHANGED);Intent sticky=registerReceiver(batteryReceiver,f);if(sticky!=null)render(sticky);}
    @Override protected void onPause(){super.onPause();try{unregisterReceiver(batteryReceiver);}catch(Exception ignored){}}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));
        root.addView(UiKit.title(this,"Nexa Battery"),UiKit.matchWrap(this,0,4));root.addView(UiKit.muted(this,"🔋 وضعیت زنده باتری • بدون WakeLock و بدون روشن نگه‌داشتن صفحه"),UiKit.matchWrap(this,0,14));
        LinearLayout card=UiKit.colorfulCardLayout(this,4);status=UiKit.muted(this,"در حال خواندن باتری...");status.setTextSize(16);card.addView(status,UiKit.matchWrap(this,8,8));root.addView(card,UiKit.matchWrap(this,0,12));
        LinearLayout alarms=UiKit.colorfulCardLayout(this,2);
        Switch charge=new Switch(this);charge.setText("هشدار رسیدن شارژ به حد");charge.setChecked(AppPrefs.isChargeAlarmEnabled(this));alarms.addView(charge,UiKit.matchWrap(this,4,6));
        Spinner high=new Spinner(this);String[] highs={"80٪","85٪","90٪","95٪","100٪"};high.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,highs));int hv=AppPrefs.getChargeAlarmThreshold(this);int hi=hv>=100?4:Math.max(0,Math.min(3,(hv-80)/5));high.setSelection(hi);alarms.addView(high,UiKit.matchWrap(this,4,6));
        Switch low=new Switch(this);low.setText("هشدار باتری کم");low.setChecked(AppPrefs.isLowBatteryAlarmEnabled(this));alarms.addView(low,UiKit.matchWrap(this,4,6));
        Spinner lowSp=new Spinner(this);String[] lows={"20٪","15٪","10٪","5٪"};lowSp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,lows));int lv=AppPrefs.getLowBatteryThreshold(this);int li=lv==20?0:lv==15?1:lv==10?2:3;lowSp.setSelection(li);alarms.addView(lowSp,UiKit.matchWrap(this,4,6));
        charge.setOnCheckedChangeListener((b,v)->AppPrefs.setChargeAlarmEnabled(this,v));low.setOnCheckedChangeListener((b,v)->AppPrefs.setLowBatteryAlarmEnabled(this,v));
        high.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){AppPrefs.setChargeAlarmThreshold(BatteryGuardActivity.this,new int[]{80,85,90,95,100}[pos]);AppPrefs.setChargeAlarmLatched(BatteryGuardActivity.this,false);}public void onNothingSelected(AdapterView<?> p){}});
        lowSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){AppPrefs.setLowBatteryThreshold(BatteryGuardActivity.this,new int[]{20,15,10,5}[pos]);AppPrefs.setLowBatteryAlarmLatched(BatteryGuardActivity.this,false);}public void onNothingSelected(AdapterView<?> p){}});
        TextView theftTitle=UiKit.muted(this,"🛡️ محافظ ضدسرقت شارژر");theftTitle.setTextSize(16);alarms.addView(theftTitle,UiKit.matchWrap(this,10,4));
        Switch theft=new Switch(this);theft.setText("هشدار هنگام جدا شدن شارژر");theft.setChecked(AppPrefs.isTheftGuardEnabled(this));alarms.addView(theft,UiKit.matchWrap(this,4,6));
        TextView theftHint=UiKit.muted(this,"پس از اتصال شارژر مسلح می‌شود؛ با جدا شدن واقعی کابل، آژیر و لرزش با بالاترین اولویت Nexa فعال می‌شود. توقف فقط با اثر انگشت، PIN Nexa یا قفل امن گوشی است.");alarms.addView(theftHint,UiKit.matchWrap(this,4,8));
        theft.setOnCheckedChangeListener((b,v)->{if(v){android.app.KeyguardManager km=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);boolean secure=NexaStore.pinConfigured(this)||(km!=null&&km.isDeviceSecure());if(!secure){b.setChecked(false);Toast.makeText(this,"برای فعال‌سازی ضدسرقت، ابتدا PIN Nexa یا قفل امن گوشی را فعال کنید.",Toast.LENGTH_LONG).show();return;}AppPrefs.clearTheftPlugState(this);}else{TheftGuardManager.stop(this);AppPrefs.clearTheftPlugState(this);}AppPrefs.setTheftGuardEnabled(this,v);});
        root.addView(alarms,UiKit.matchWrap(this,0,12));
        root.addView(UiKit.muted(this,"هشدارها فقط یک‌بار در هر عبور از حد فعال می‌شوند و پس از فاصله گرفتن ۳٪ از حد، خودکار آماده هشدار بعدی می‌شوند. اطلاعات از BatteryManager اندروید است و Nexa مقدار ساختگی نمایش نمی‌دهد."),UiKit.matchWrap(this,0,10));setContentView(sc);}
    private void render(Intent i){if(status==null||i==null)return;int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);int pct=level<0?-1:Math.round(level*100f/Math.max(1,scale));int temp=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0);int volt=i.getIntExtra(BatteryManager.EXTRA_VOLTAGE,0);int health=i.getIntExtra(BatteryManager.EXTRA_HEALTH,BatteryManager.BATTERY_HEALTH_UNKNOWN);int plugged=i.getIntExtra(BatteryManager.EXTRA_PLUGGED,0);int st=i.getIntExtra(BatteryManager.EXTRA_STATUS,BatteryManager.BATTERY_STATUS_UNKNOWN);String tech=i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
        BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);long current=0,capacity=-1;try{current=bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);}catch(Exception ignored){}try{capacity=bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);}catch(Exception ignored){}
        StringBuilder s=new StringBuilder();s.append("شارژ: ").append(pct<0?"نامشخص":pct+"٪");s.append("\nوضعیت: ").append(statusName(st));s.append("\nاتصال: ").append(plugName(plugged));s.append("\nسلامت: ").append(healthName(health));s.append("\nدما: ").append(temp==0?"نامشخص":String.format(java.util.Locale.US,"%.1f°C",temp/10f));s.append("\nولتاژ: ").append(volt<=0?"نامشخص":volt+" mV");s.append("\nجریان لحظه‌ای: ").append(current==0?"نامشخص":current+" µA");s.append("\nشارژ باقی‌مانده: ").append(capacity<=0?"نامشخص":capacity+" µAh");s.append("\nفناوری: ").append(tech==null||tech.trim().isEmpty()?"نامشخص":tech);s.append("\nمنبع داده: Android BatteryManager");status.setText(s.toString());}
    private String plugName(int p){if(p==BatteryManager.BATTERY_PLUGGED_AC)return"برق شهری";if(p==BatteryManager.BATTERY_PLUGGED_USB)return"USB";if(p==BatteryManager.BATTERY_PLUGGED_WIRELESS)return"بی‌سیم";return"روی باتری";}
    private String statusName(int s){if(s==BatteryManager.BATTERY_STATUS_CHARGING)return"در حال شارژ";if(s==BatteryManager.BATTERY_STATUS_FULL)return"کامل";if(s==BatteryManager.BATTERY_STATUS_DISCHARGING)return"در حال مصرف";if(s==BatteryManager.BATTERY_STATUS_NOT_CHARGING)return"متصل، بدون شارژ";return"نامشخص";}
    private String healthName(int h){if(h==BatteryManager.BATTERY_HEALTH_GOOD)return"خوب";if(h==BatteryManager.BATTERY_HEALTH_OVERHEAT)return"دمای بالا";if(h==BatteryManager.BATTERY_HEALTH_DEAD)return"معیوب";if(h==BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE)return"ولتاژ بالا";if(h==BatteryManager.BATTERY_HEALTH_COLD)return"دمای پایین";return"نامشخص";}
}
