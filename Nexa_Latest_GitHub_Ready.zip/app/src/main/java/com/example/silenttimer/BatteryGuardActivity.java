package com.example.silenttimer;

import android.app.Activity;
import android.content.*;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

/** Read-only battery health dashboard. Does not hold wake locks or keep the screen on. */
public class BatteryGuardActivity extends Activity {
    private TextView status;
    private final BroadcastReceiver batteryReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){render(i);}};
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();IntentFilter f=new IntentFilter(Intent.ACTION_BATTERY_CHANGED);Intent sticky=registerReceiver(batteryReceiver,f);if(sticky!=null)render(sticky);}
    @Override protected void onPause(){super.onPause();try{unregisterReceiver(batteryReceiver);}catch(Exception ignored){}}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,18),UiKit.dp(this,28));root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));
        root.addView(UiKit.title(this,"Nexa Battery"),UiKit.matchWrap(this,0,4));root.addView(UiKit.muted(this,"🔋 وضعیت زنده باتری • بدون WakeLock و بدون روشن نگه‌داشتن صفحه"),UiKit.matchWrap(this,0,14));
        LinearLayout card=UiKit.colorfulCardLayout(this,4);status=UiKit.muted(this,"در حال خواندن باتری...");status.setTextSize(16);card.addView(status,UiKit.matchWrap(this,8,8));root.addView(card,UiKit.matchWrap(this,0,12));
        root.addView(UiKit.muted(this,"اطلاعات از BatteryManager خود اندروید خوانده می‌شود. مقدار جریان/ولتاژ/سلامت در بعضی مدل‌ها توسط سازنده گزارش نمی‌شود؛ Nexa در این حالت مقدار ساختگی نمایش نمی‌دهد."),UiKit.matchWrap(this,0,10));setContentView(sc);}
    private void render(Intent i){if(status==null||i==null)return;int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);int pct=level<0?-1:Math.round(level*100f/Math.max(1,scale));int temp=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0);int volt=i.getIntExtra(BatteryManager.EXTRA_VOLTAGE,0);int health=i.getIntExtra(BatteryManager.EXTRA_HEALTH,BatteryManager.BATTERY_HEALTH_UNKNOWN);int plugged=i.getIntExtra(BatteryManager.EXTRA_PLUGGED,0);int st=i.getIntExtra(BatteryManager.EXTRA_STATUS,BatteryManager.BATTERY_STATUS_UNKNOWN);String tech=i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);
        BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);long current=0,capacity=-1;try{current=bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);}catch(Exception ignored){}try{capacity=bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);}catch(Exception ignored){}
        StringBuilder s=new StringBuilder();s.append("شارژ: ").append(pct<0?"نامشخص":pct+"٪");s.append("\nوضعیت: ").append(statusName(st));s.append("\nاتصال: ").append(plugName(plugged));s.append("\nسلامت: ").append(healthName(health));s.append("\nدما: ").append(temp==0?"نامشخص":String.format(java.util.Locale.US,"%.1f°C",temp/10f));s.append("\nولتاژ: ").append(volt<=0?"نامشخص":volt+" mV");s.append("\nجریان لحظه‌ای: ").append(current==0?"نامشخص":current+" µA");s.append("\nشارژ باقی‌مانده: ").append(capacity<=0?"نامشخص":capacity+" µAh");s.append("\nفناوری: ").append(tech==null||tech.trim().isEmpty()?"نامشخص":tech);s.append("\nمنبع داده: Android BatteryManager");status.setText(s.toString());}
    private String plugName(int p){if(p==BatteryManager.BATTERY_PLUGGED_AC)return"برق شهری";if(p==BatteryManager.BATTERY_PLUGGED_USB)return"USB";if(p==BatteryManager.BATTERY_PLUGGED_WIRELESS)return"بی‌سیم";return"روی باتری";}
    private String statusName(int s){if(s==BatteryManager.BATTERY_STATUS_CHARGING)return"در حال شارژ";if(s==BatteryManager.BATTERY_STATUS_FULL)return"کامل";if(s==BatteryManager.BATTERY_STATUS_DISCHARGING)return"در حال مصرف";if(s==BatteryManager.BATTERY_STATUS_NOT_CHARGING)return"متصل، بدون شارژ";return"نامشخص";}
    private String healthName(int h){if(h==BatteryManager.BATTERY_HEALTH_GOOD)return"خوب";if(h==BatteryManager.BATTERY_HEALTH_OVERHEAT)return"دمای بالا";if(h==BatteryManager.BATTERY_HEALTH_DEAD)return"معیوب";if(h==BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE)return"ولتاژ بالا";if(h==BatteryManager.BATTERY_HEALTH_COLD)return"دمای پایین";return"نامشخص";}
}
