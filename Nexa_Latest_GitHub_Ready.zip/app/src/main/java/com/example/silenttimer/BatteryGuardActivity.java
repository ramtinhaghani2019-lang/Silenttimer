package com.example.silenttimer;

import android.app.Activity;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

/** Nexa Master UI battery dashboard. Read-only battery telemetry + charge/theft alarms. */
public class BatteryGuardActivity extends Activity {
    private LinearLayout metrics; private TextView percentHero,connectionState;
    private int currentPct=-1; private boolean detailsExpanded=false;
    private final BroadcastReceiver batteryReceiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
        if(i!=null&&Intent.ACTION_POWER_DISCONNECTED.equals(i.getAction()))BatteryAlertManager.onChargerDisconnected(c);
        else if(i!=null&&Intent.ACTION_BATTERY_CHANGED.equals(i.getAction()))render(i);
    }};
    @Override protected void onCreate(Bundle b){
        super.onCreate(b);UiKit.applyWindow(this);
        if(b!=null)detailsExpanded=b.getBoolean("battery_details_expanded",false);
        build();
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putBoolean("battery_details_expanded",detailsExpanded);
        super.onSaveInstanceState(state);
    }
    @Override protected void onResume(){super.onResume();IntentFilter filter=new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        Intent sticky=android.os.Build.VERSION.SDK_INT>=33
                ?registerReceiver(batteryReceiver,filter,Context.RECEIVER_NOT_EXPORTED)
                :registerReceiver(batteryReceiver,filter);if(sticky!=null)render(sticky);}
    @Override protected void onPause(){super.onPause();try{unregisterReceiver(batteryReceiver);}catch(Exception ignored){}}
    private void build(){
        LinearLayout screen=new LinearLayout(this);screen.setOrientation(LinearLayout.VERTICAL);screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);screen.setBackground(UiKit.screenBackground(this));
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setPadding(UiKit.dp(this,14),UiKit.dp(this,10),UiKit.dp(this,14),UiKit.dp(this,18));sc.addView(root);
        LinearLayout head=UiKit.header(this,"🔋 باتری و شارژ",v->finish());root.addView(head,UiKit.matchWrap(this,0,0));

        LinearLayout live=UiKit.accentCardLayout(this);live.addView(UiKit.sectionTitle(this,"● وضعیت فعلی"),UiKit.matchWrap(this,0,8));
        LinearLayout liveBody=new LinearLayout(this);liveBody.setOrientation(LinearLayout.HORIZONTAL);liveBody.setGravity(Gravity.CENTER_VERTICAL);liveBody.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        TextView batteryVisual=new TextView(this);batteryVisual.setText("▣\n⚡");batteryVisual.setGravity(Gravity.CENTER);batteryVisual.setTextColor(UiKit.GREEN);batteryVisual.setTextSize(38);batteryVisual.setTypeface(Typeface.DEFAULT_BOLD);batteryVisual.setBackground(UiKit.heroSurface(this));LinearLayout.LayoutParams bvp=new LinearLayout.LayoutParams(-1,UiKit.dp(this,150));/* Visual decoration intentionally suppressed in compact dashboard. */
        LinearLayout right=new LinearLayout(this);right.setOrientation(LinearLayout.VERTICAL);right.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);percentHero=new TextView(this);percentHero.setText("--٪");percentHero.setGravity(Gravity.CENTER);percentHero.setTextColor(UiKit.GOLD);percentHero.setTextSize(26);percentHero.setTypeface(Typeface.DEFAULT_BOLD);right.addView(percentHero,UiKit.matchWrap(this,0,6));metrics=new LinearLayout(this);metrics.setOrientation(LinearLayout.VERTICAL);right.addView(metrics);
        connectionState=UiKit.muted(this,"در حال دریافت وضعیت باتری…");
        connectionState.setGravity(Gravity.CENTER);
        right.addView(connectionState,UiKit.matchWrap(this,0,5));
        metrics.setVisibility(detailsExpanded?View.VISIBLE:View.GONE);
        Button expandMetrics=UiKit.secondaryButton(this,detailsExpanded?"بستن جزئیات  ▴":"جزئیات فنی باتری  ▾");
        expandMetrics.setOnClickListener(v->{detailsExpanded=!detailsExpanded;
            metrics.setVisibility(detailsExpanded?View.VISIBLE:View.GONE);
            expandMetrics.setText(detailsExpanded?"بستن جزئیات  ▴":"جزئیات فنی باتری  ▾");});
        right.addView(expandMetrics,UiKit.matchWrap(this,5,0));
        LinearLayout.LayoutParams rlp=new LinearLayout.LayoutParams(0,-2,1f);rlp.setMargins(UiKit.dp(this,8),0,0,0);liveBody.addView(right,rlp);live.addView(liveBody);root.addView(live,UiKit.matchWrap(this,0,12));

        LinearLayout chargeCard=UiKit.colorfulCardLayout(this,4);LinearLayout chargeHead=new LinearLayout(this);chargeHead.setGravity(Gravity.CENTER_VERTICAL);chargeHead.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);TextView ct=UiKit.sectionTitle(this,"🔔 هشدار رسیدن شارژ به حد");chargeHead.addView(ct,new LinearLayout.LayoutParams(0,-2,1));Switch charge=UiKit.styledSwitch(this);charge.setChecked(AppPrefs.isChargeAlarmEnabled(this));chargeHead.addView(charge,new LinearLayout.LayoutParams(-2,-2));chargeCard.addView(chargeHead);
        LinearLayout choices=new LinearLayout(this);choices.setOrientation(LinearLayout.HORIZONTAL);choices.setGravity(Gravity.CENTER);choices.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);int selected=AppPrefs.getChargeAlarmThreshold(this);int[] vals={80,85,90,95,100};for(int value:vals){TextView chip=thresholdChip(value,value==selected);LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1);cp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);choices.addView(chip,cp);chip.setOnClickListener(v->{
            AppPrefs.setChargeAlarmThreshold(this,value);
            AppPrefs.setChargeAlarmLatched(this,false);
            for(int j=0;j<choices.getChildCount();j++){
                TextView item=(TextView)choices.getChildAt(j);
                TextView template=thresholdChip(vals[j],vals[j]==value);
                item.setText(template.getText());
                item.setTextColor(template.getCurrentTextColor());
                item.setBackground(template.getBackground());
                item.setContentDescription("هشدار شارژ در "+vals[j]+" درصد"+
                        (vals[j]==value?"، انتخاب‌شده":""));
            }
        });}chargeCard.addView(choices);
        // Sound preview / sound selection lives only in Settings, never on the charge dashboard.
        Button stop=UiKit.secondaryButton(this,"قطع هشدار فعال");
        stop.setOnClickListener(v->{BatteryAlertManager.onChargerDisconnected(this);Toast.makeText(this,"هشدار قطع شد",Toast.LENGTH_SHORT).show();});
        chargeCard.addView(stop,UiKit.matchWrap(this,6,0));
        charge.setOnCheckedChangeListener((b,v)->{AppPrefs.setChargeAlarmEnabled(this,v);AppPrefs.setChargeAlarmLatched(this,false);if(v)ensureBatteryMonitor();else NexaAudioController.stopOwner(BatteryAlarmActionReceiver.OWNER_CHARGE);});root.addView(chargeCard,UiKit.matchWrap(this,0,12));

        LinearLayout theftCard=UiKit.colorfulCardLayout(this,1);LinearLayout theftHead=new LinearLayout(this);theftHead.setGravity(Gravity.CENTER_VERTICAL);TextView tt=UiKit.sectionTitle(this,"🛡 هشدار هنگام جدا شدن شارژر");theftHead.addView(tt,new LinearLayout.LayoutParams(0,-2,1));Switch theft=UiKit.styledSwitch(this);theft.setChecked(AppPrefs.isTheftGuardEnabled(this));theftHead.addView(theft);theftCard.addView(theftHead);theft.setOnCheckedChangeListener((b,v)->{if(v){android.app.KeyguardManager km=(android.app.KeyguardManager)getSystemService(KEYGUARD_SERVICE);boolean secure=NexaStore.pinConfigured(this)||(km!=null&&km.isDeviceSecure());if(!secure){b.setChecked(false);Toast.makeText(this,"ابتدا PIN Nexa یا قفل امن گوشی را فعال کنید.",Toast.LENGTH_LONG).show();return;}AppPrefs.clearTheftPlugState(this);}else{TheftGuardManager.stop(this);AppPrefs.clearTheftPlugState(this);}AppPrefs.setTheftGuardEnabled(this,v);if(v)ensureBatteryMonitor();});root.addView(theftCard,UiKit.matchWrap(this,0,12));

        LinearLayout lowCard=UiKit.colorfulCardLayout(this,3);LinearLayout lowHead=new LinearLayout(this);lowHead.setGravity(Gravity.CENTER_VERTICAL);TextView lt=UiKit.sectionTitle(this,"🔋 هشدار باتری کم");lowHead.addView(lt,new LinearLayout.LayoutParams(0,-2,1));Switch low=UiKit.styledSwitch(this);low.setChecked(AppPrefs.isLowBatteryAlarmEnabled(this));lowHead.addView(low);lowCard.addView(lowHead);Spinner lowSp=UiKit.styledSpinner(this);String[] lows={"20٪","15٪","10٪","5٪"};lowSp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,lows));int lv=AppPrefs.getLowBatteryThreshold(this);lowSp.setSelection(lv==20?0:lv==15?1:lv==10?2:3);lowCard.addView(lowSp,UiKit.matchWrap(this,8,0));low.setOnCheckedChangeListener((b,v)->{AppPrefs.setLowBatteryAlarmEnabled(this,v);AppPrefs.setLowBatteryAlarmLatched(this,false);if(v)ensureBatteryMonitor();});lowSp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){AppPrefs.setLowBatteryThreshold(BatteryGuardActivity.this,new int[]{20,15,10,5}[pos]);AppPrefs.setLowBatteryAlarmLatched(BatteryGuardActivity.this,false);}public void onNothingSelected(AdapterView<?> p){}});root.addView(lowCard,UiKit.matchWrap(this,0,12));

        screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));LinearLayout nav=UiKit.referenceBottomNav(this,-1);LinearLayout.LayoutParams np=UiKit.matchWrap(this);np.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,12),UiKit.dp(this,10));screen.addView(nav,np);setContentView(screen);
    }
    private TextView thresholdChip(int value,boolean active){TextView t=UiKit.chip(this,value+"٪",active);t.setTextSize(15);t.setSingleLine(true);if(active)t.setText(value+"٪ ✓");return t;}
    private void ensureBatteryMonitor(){Intent mon=new Intent(this,SilentTimerService.class);mon.setAction(SilentTimerService.ACTION_MONITOR);try{if(android.os.Build.VERSION.SDK_INT>=26)startForegroundService(mon);else startService(mon);}catch(Exception ignored){}Intent sticky=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(sticky!=null)BatteryAlertManager.onBatteryChanged(this,sticky);}
    private void metric(String label,String value){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(UiKit.dp(this,9),UiKit.dp(this,4),UiKit.dp(this,9),UiKit.dp(this,4));row.setBackground(UiKit.field(this));TextView l=UiKit.muted(this,label);TextView val=UiKit.muted(this,value);val.setTextColor(Color.WHITE);val.setTextSize(15);row.addView(l,new LinearLayout.LayoutParams(0,-2,1));row.addView(val);LinearLayout.LayoutParams rp=UiKit.matchWrap(this,0,3);metrics.addView(row,rp);}
    private void render(Intent i){if(metrics==null||i==null)return;int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);currentPct=level<0?-1:Math.round(level*100f/Math.max(1,scale));int temp=i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,0),volt=i.getIntExtra(BatteryManager.EXTRA_VOLTAGE,0),health=i.getIntExtra(BatteryManager.EXTRA_HEALTH,BatteryManager.BATTERY_HEALTH_UNKNOWN),plugged=i.getIntExtra(BatteryManager.EXTRA_PLUGGED,0),st=i.getIntExtra(BatteryManager.EXTRA_STATUS,BatteryManager.BATTERY_STATUS_UNKNOWN);String tech=i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY);BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);long current=0,capacity=-1;try{current=bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);}catch(Exception ignored){}try{capacity=bm.getLongProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);}catch(Exception ignored){}percentHero.setText((currentPct<0?"--":currentPct)+"٪");
        connectionState.setText(plugged==0?"روی باتری • "+statusName(st):
                plugName(plugged)+" • "+statusName(st));
        metrics.removeAllViews();metric("دما",temp==0?"نامشخص":String.format(java.util.Locale.US,"%.1f °C",temp/10f));metric("ولتاژ",volt<=0?"نامشخص":volt+" mV");metric("جریان لحظه‌ای",current==0?"نامشخص":current+" µA");metric("شارژ باقی‌مانده",capacity<=0?"نامشخص":capacity+" µAh");metric("وضعیت",statusName(st));metric("اتصال",plugName(plugged));metric("سلامت",healthName(health));metric("فناوری",tech==null||tech.trim().isEmpty()?"نامشخص":tech);}
    private String plugName(int p){if(p==BatteryManager.BATTERY_PLUGGED_AC)return"برق شهری";if(p==BatteryManager.BATTERY_PLUGGED_USB)return"USB";if(p==BatteryManager.BATTERY_PLUGGED_WIRELESS)return"بی‌سیم";return"روی باتری";}
    private String statusName(int s){if(s==BatteryManager.BATTERY_STATUS_CHARGING)return"در حال شارژ";if(s==BatteryManager.BATTERY_STATUS_FULL)return"کامل";if(s==BatteryManager.BATTERY_STATUS_DISCHARGING)return"در حال مصرف";if(s==BatteryManager.BATTERY_STATUS_NOT_CHARGING)return"متصل، بدون شارژ";return"نامشخص";}
    private String healthName(int h){if(h==BatteryManager.BATTERY_HEALTH_GOOD)return"سلامت خوب";if(h==BatteryManager.BATTERY_HEALTH_OVERHEAT)return"دمای بالا";if(h==BatteryManager.BATTERY_HEALTH_DEAD)return"معیوب";if(h==BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE)return"ولتاژ بالا";if(h==BatteryManager.BATTERY_HEALTH_COLD)return"دمای پایین";return"سلامت نامشخص";}
}
