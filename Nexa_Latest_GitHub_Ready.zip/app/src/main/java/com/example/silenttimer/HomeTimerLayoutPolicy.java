package com.example.silenttimer;

/** Small-screen layout decision. Pure JVM logic, no timer or audio side effects. */
public final class HomeTimerLayoutPolicy {
    private HomeTimerLayoutPolicy() {}

    /** Vertical presets avoid clipping Persian text and keep 48dp touch targets. */
    public static boolean stackPresets(float availableWidthDp, float fontScale) {
        return availableWidthDp < 305f || fontScale > 1.16f;
    }
}
