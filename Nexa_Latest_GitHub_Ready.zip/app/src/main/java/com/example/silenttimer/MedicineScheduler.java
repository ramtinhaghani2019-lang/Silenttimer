package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class MedicineScheduler {
    private MedicineScheduler(){}
    public static void rescheduleAll(Context c){
        for(NexaStore.Medicine m:NexaStore.medicines(c)){
            if(m==null || m.id==null || m.id.trim().isEmpty())continue;
            if(canSchedule(m,m.nextDoseMillis))schedule(c,m);
            else cancel(c,m.id);
        }
    }
    public static void cancel(Context c,String id){if(id==null || id.trim().isEmpty())return;Intent i=new Intent(c,MedicineAlarmReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,("med"+id).hashCode(),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null){android.app.AlarmManager am=(android.app.AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pi);pi.cancel();}}
    public static void schedule(Context c,NexaStore.Medicine m){
        if(m==null || m.id==null || m.id.trim().isEmpty())return;
        if(!canSchedule(m,m.nextDoseMillis)){cancel(c,m.id);return;}
        scheduleAt(c,m.id,m.nextDoseMillis);
    }
    /** End dates are inclusive; an expired or disabled course must never ring. */
    public static boolean canSchedule(NexaStore.Medicine m,long at){
        return m!=null && m.id!=null && !m.id.trim().isEmpty() && m.active && at>0 && (m.endMillis<=0 || at<=m.endMillis);
    }
    /** Safely compute the next repeat without integer multiplication overflow. */
    public static long nextRepeatAt(long now,int repeatMinutes){
        long minutes=repeatMinutes>0?repeatMinutes:5L;
        if(minutes>Long.MAX_VALUE/60000L)return -1L;
        long delay=minutes*60000L;
        return now<=0 || now>Long.MAX_VALUE-delay?-1L:now+delay;
    }
    public static long nextDoseAt(long anchor,int intervalHours){
        if(anchor<=0 || intervalHours<=0)return -1L;
        long hours=intervalHours;
        if(hours>(Long.MAX_VALUE-anchor)/3600000L)return -1L;
        return anchor+hours*3600000L;
    }
    public static boolean canAct(NexaStore.Medicine m,long now){
        return m!=null && m.active && (m.endMillis<=0 || now<=m.endMillis);
    }
    public static void scheduleAt(Context c,String id,long at){
        if(id==null || id.trim().isEmpty())return;
        NexaStore.Medicine medicine=NexaStore.medicine(c,id);
        long now=System.currentTimeMillis();
        long when=now>Long.MAX_VALUE-1000L?-1L:Math.max(now+1000L,at);
        if(!canSchedule(medicine,when)){cancel(c,id);return;}
        Intent i=new Intent(c,MedicineAlarmReceiver.class);i.putExtra("id",id);PendingIntent pi=PendingIntent.getBroadcast(c,("med"+id).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);ReminderScheduler.setAlarm(c,when,pi);}
}
