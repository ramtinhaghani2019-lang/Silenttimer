package com.example.silenttimer;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class MedicineScheduler {
    private MedicineScheduler(){}
    public static void rescheduleAll(Context c){for(NexaStore.Medicine m:NexaStore.medicines(c))if(m.active)schedule(c,m);else cancel(c,m.id);}
    public static void cancel(Context c,String id){Intent i=new Intent(c,MedicineAlarmReceiver.class);PendingIntent pi=PendingIntent.getBroadcast(c,("med"+id).hashCode(),i,PendingIntent.FLAG_NO_CREATE|PendingIntent.FLAG_IMMUTABLE);if(pi!=null){android.app.AlarmManager am=(android.app.AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pi);pi.cancel();}}
    public static void schedule(Context c,NexaStore.Medicine m){if(!canSchedule(m,m.nextDoseMillis)){cancel(c,m.id);return;}scheduleAt(c,m.id,m.nextDoseMillis);}
    /** End dates are inclusive; an expired or disabled course must never ring. */
    public static boolean canSchedule(NexaStore.Medicine m,long at){
        return m!=null && m.active && at>0 && (m.endMillis<=0 || at<=m.endMillis);
    }
    /** Safely compute the next repeat without integer multiplication overflow. */
    public static long nextRepeatAt(long now,int repeatMinutes){
        long minutes=repeatMinutes>0?repeatMinutes:5L;
        long delay=minutes*60000L;
        return now>Long.MAX_VALUE-delay?Long.MAX_VALUE:now+delay;
    }
    public static void scheduleAt(Context c,String id,long at){Intent i=new Intent(c,MedicineAlarmReceiver.class);i.putExtra("id",id);PendingIntent pi=PendingIntent.getBroadcast(c,("med"+id).hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);ReminderScheduler.setAlarm(c,Math.max(System.currentTimeMillis()+1000,at),pi);}
}
