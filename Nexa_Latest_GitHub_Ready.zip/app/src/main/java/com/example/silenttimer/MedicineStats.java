package com.example.silenttimer;

import java.util.List;

/** Pure medicine adherence calculations shared by UI and regression tests. */
public final class MedicineStats {
    private MedicineStats(){}
    public static final class Summary {
        public int scheduled, taken, onTime, late, skipped, missed;
        public int adherencePercent(){ return scheduled<=0?0:(int)Math.round((taken*100.0)/scheduled); }
    }
    public static Summary summarize(NexaStore.Medicine m, List<NexaStore.MedicineDoseLog> logs, long now, int days){
        Summary out=new Summary();
        if(m==null||m.firstDoseMillis<=0||m.intervalHours<=0||days<=0)return out;
        long step=m.intervalHours*60L*60L*1000L, from=Math.max(m.firstDoseMillis,now-days*24L*60L*60L*1000L);
        long until=m.endMillis>0?Math.min(now,m.endMillis):now;
        if(until<from)return out;
        long slot=m.firstDoseMillis; if(slot<from)slot+=((from-slot+step-1)/step)*step;
        int guard=0;
        for(long scheduled=slot;scheduled<=until&&guard<5000;scheduled+=step,guard++){
            out.scheduled++; NexaStore.MedicineDoseLog found=null;
            for(NexaStore.MedicineDoseLog x:logs) if(Math.abs(x.scheduledAt-scheduled)<60_000L){found=x;break;}
            if(found==null){out.missed++;continue;}
            if("skipped".equals(found.status)){out.skipped++;out.missed++;continue;}
            if(found.takenAt>0){out.taken++; if(Math.abs(found.takenAt-scheduled)<=60_000L||"taken_on_time".equals(found.status))out.onTime++; else out.late++;}
            else out.missed++;
        }
        return out;
    }
}
