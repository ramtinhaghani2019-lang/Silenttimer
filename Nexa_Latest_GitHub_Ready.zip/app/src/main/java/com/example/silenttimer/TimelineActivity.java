package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TimelineActivity extends Activity {
    private static final long DAY=24L*60L*60L*1000L;
    private static final class Event {
        long time; String icon,title,sub,kind; Intent target;
        Event(long t,String i,String ti,String s,String k){this(t,i,ti,s,k,null);}
        Event(long t,String i,String ti,String s,String k,Intent target){time=t;icon=i;title=ti;sub=s;kind=k;this.target=target;}
    }
    private final List<Event> future=new ArrayList<>();
    private final List<Event> past=new ArrayList<>();
    private LinearLayout content,filters;
    private String filter="all";
    private String window="all";

    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}

    private void build(){
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this)); sc.addView(root);
        root.addView(UiKit.header(this,"خط زمانی",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"همه موعدها، رویدادها و فعالیت‌ها در یک مسیر"),UiKit.matchWrap(this,0,14));

        collect();
        long now=System.currentTimeMillis(); int overdue=0,next7=0;
        for(Event e:past) if(isActionable(e) && e.time>0 && e.time<now) overdue++;
        for(Event e:future) if(e.time<=now+7*DAY) next7++;
        root.addView(NexaAgendaUi.stats(this,
                new String[]{"پیش رو","معوق","ثبت‌شده در گذشته"},
                new String[]{String.valueOf(future.size()),String.valueOf(overdue),String.valueOf(past.size())},
                new int[]{UiKit.PURPLE,UiKit.RED,UiKit.BLUE}),UiKit.matchWrap(this,0,10));
        LinearLayout summary=UiKit.accentCardLayout(this);
        summary.addView(UiKit.muted(this,"📆 در ۷ روز آینده: "+next7+" رویداد    •    برای دیدن جزئیات، روی هر رویداد بزنید."));
        root.addView(summary,UiKit.matchWrap(this,0,12));

        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        filters=new LinearLayout(this); filters.setOrientation(LinearLayout.HORIZONTAL); filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); hs.addView(filters);
        root.addView(hs,UiKit.matchWrap(this,0,8));
        LinearLayout windows=new LinearLayout(this); windows.setOrientation(LinearLayout.HORIZONTAL); windows.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addWindow(windows,"همه زمان‌ها","all"); addWindow(windows,"امروز","today"); addWindow(windows,"۷ روز","7d"); addWindow(windows,"معوق","overdue");
        root.addView(windows,UiKit.matchWrap(this,0,12));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content);
        renderFilters(); render(); setContentView(sc);
    }

    private boolean isActionable(Event e){return !"history".equals(e.kind)&&!"service".equals(e.kind);}

    private void collect(){
        future.clear(); past.clear(); long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:NexaStore.reminders(this)) if(r.active&&r.whenMillis>0){ Intent i=new Intent(this,ReminderEditActivity.class); i.putExtra("edit_id",r.id); put(new Event(r.whenMillis,r.icon,r.title,r.category,"reminder",i),now); }
        for(NexaStore.Medicine m:NexaStore.medicines(this)) if(m.active&&m.nextDoseMillis>0) put(new Event(m.nextDoseMillis,"💊",m.name,m.dose,"medicine",new Intent(this,MedicineActivity.class)),now);
        for(NexaStore.CaseItem x:NexaStore.cases(this)) if(x.whenMillis>0) put(new Event(x.whenMillis,"⚖️",x.title,"دادگاه • "+x.caseNumber,"case",new Intent(this,CaseActivity.class)),now);
        for(NexaStore.BillItem x:NexaStore.bills(this)) if(!x.paid&&x.dueDate>0) put(new Event(x.dueDate,"💳",x.title,x.type,"bill",new Intent(this,BillsActivity.class)),now);
        for(NexaStore.DocumentItem x:NexaStore.documents(this)) if(x.expiryDate>0) put(new Event(x.expiryDate,"📄","انقضای "+x.title,x.type,"doc",new Intent(this,DocsActivity.class)),now);
        for(NexaStore.HomeItem x:NexaStore.homeItems(this)) if(x.nextDueDate>0) put(new Event(x.nextDueDate,"🏠",x.title,x.category,"home",new Intent(this,HomeCareActivity.class)),now);
        for(NexaStore.TodoItem x:NexaStore.todos(this)) if(!x.done&&x.dueMillis>0) put(new Event(x.dueMillis,"✅",x.title,x.category,"todo",new Intent(this,NexaListActivity.class)),now);
        for(NexaStore.ServiceRecord x:NexaStore.services(this)) if(x.nextDueDate>0) put(new Event(x.nextDueDate,"🚗",x.category,x.km+" km • سرویس خودرو","vehicle",new Intent(this,GarageActivity.class)),now);
        for(NexaStore.ServiceRecord x:NexaStore.services(this)) if(x.dateMillis>0) past.add(new Event(x.dateMillis,"🔧",x.category,x.km+" km • "+x.note,"service"));
        for(NexaStore.HistoryItem x:NexaStore.history(this)) if(x.time>0) past.add(new Event(x.time,"◷",x.type,x.text,"history"));
        future.sort(Comparator.comparingLong(a->a.time)); past.sort((a,b)->Long.compare(b.time,a.time));
    }
    private void put(Event e,long now){(e.time>now?future:past).add(e);}

    private void renderFilters(){
        filters.removeAllViews();
        addFilter("همه","all"); addFilter("یادآور","reminder"); addFilter("دارو","medicine"); addFilter("مالی","bill"); addFilter("دادگاه","case"); addFilter("کارها","todo"); addFilter("مدارک","doc"); addFilter("خانه","home"); addFilter("خودرو","vehicle"); addFilter("سابقه","history");
    }
    private void addFilter(String label,String key){
        TextView c=NexaAgendaUi.chip(this,label,key.equals(filter)); c.setOnClickListener(v->{filter=key;renderFilters();render();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT); lp.setMargins(UiKit.dp(this,4),0,UiKit.dp(this,4),0); filters.addView(c,lp);
    }
    private void addWindow(LinearLayout row,String label,String key){
        TextView c=NexaAgendaUi.chip(this,label,key.equals(window)); c.setOnClickListener(v->{window=key;build();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f); lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0); row.addView(c,lp);
    }
    private boolean matchesWindow(Event e,long now){
        if("all".equals(window))return true;
        if("overdue".equals(window))return isActionable(e)&&e.time>0&&e.time<now;
        long start=now-(now%DAY), end="today".equals(window)?start+DAY:now+7*DAY;
        return e.time>=start&&e.time<=end;
    }
    private boolean matches(Event e){
        if("all".equals(filter))return true;
        if("due".equals(filter))return !"history".equals(e.kind)&&!"service".equals(e.kind)&&!"medicine".equals(e.kind);
        if("history".equals(filter))return "history".equals(e.kind)||"service".equals(e.kind);
        return filter.equals(e.kind);
    }

    private void render(){
        content.removeAllViews(); long now=System.currentTimeMillis(); int shown=0;
        LinearLayout f=UiKit.colorfulCardLayout(this,1); f.addView(UiKit.sectionTitle(this,"پیش رو")); int fc=0;
        for(Event e:future){if(!matches(e)||!matchesWindow(e,now))continue; addEvent(f,e,now); if(++fc>=40)break;} if(fc==0)f.addView(UiKit.muted(this,"در این فیلتر مورد آینده‌ای وجود ندارد."),UiKit.matchWrap(this,8,0));
        content.addView(f,UiKit.matchWrap(this,0,14)); shown+=fc;
        LinearLayout p=UiKit.cardLayout(this); p.addView(UiKit.sectionTitle(this,"اخیر و معوق")); int pc=0;
        for(Event e:past){if(!matches(e)||!matchesWindow(e,now))continue; addEvent(p,e,now); if(++pc>=60)break;} if(pc==0)p.addView(UiKit.muted(this,"در این فیلتر سابقه یا مورد معوقی وجود ندارد."),UiKit.matchWrap(this,8,0));
        content.addView(p); shown+=pc;
        if(shown==0){TextView empty=UiKit.muted(this,"چیزی برای نمایش در این فیلتر نیست."); content.addView(empty,UiKit.matchWrap(this,16,0));}
    }

    private void addEvent(LinearLayout parent,Event e,long now){
        boolean isPast=e.time<=now;
        int tone=isPast?(isActionable(e)?UiKit.RED:UiKit.BLUE):UiKit.PURPLE;
        String status=isPast?(isActionable(e)?"معوق":"سابقه"):
                (e.time<=now+DAY?"۲۴ ساعت آینده":e.time<=now+7*DAY?"این هفته":"پیش رو");
        LinearLayout row=NexaAgendaUi.event(this,e.icon,e.title,
                PersianDateUtil.pretty(e.time)+(e.sub==null||e.sub.isEmpty()?"":" • "+e.sub),
                status,tone,e.target!=null);
        if(e.target!=null){ row.setOnClickListener(v->startActivity(e.target)); row.setContentDescription("باز کردن "+e.title); }
        parent.addView(row,UiKit.matchWrap(this,8,2));
    }

    @Override protected void onResume(){super.onResume(); if(content!=null){collect();render();}}
}
