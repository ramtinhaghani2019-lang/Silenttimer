package com.example.silenttimer;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.content.Intent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TimelineActivity extends Activity {
    private static final long DAY=24L*60L*60L*1000L;
    private static final class Event {
        long time; String icon,title,sub,kind; Intent target;
        Event(long t,String i,String ti,String s,String k){this(t,i,ti,s,k,null);}
        Event(long t,String i,String ti,String s,String k,Intent target){time=t;icon=i;title=ti;sub=s;kind=k;this.target=target;}
    }
    private final List<Event> future=new ArrayList<>();
    private final List<Event> past=new ArrayList<>();
    private LinearLayout content,filters,windows;
    private TextView visibleCount,clearFilters;
    private int futureLimit=40,pastLimit=60;
    private String filter="all";
    private String window="all";
    private void resetLimits(){futureLimit=40;pastLimit=60;}
    private void navigate(Class<?> target){startActivity(new Intent(this,target));finish();}

    private static final String STATE_FILTER="timeline_filter";
    private static final String STATE_WINDOW="timeline_window";
    private static final String STATE_FUTURE_LIMIT="timeline_future_limit";
    private static final String STATE_PAST_LIMIT="timeline_past_limit";

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        UiKit.applyWindow(this);
        if(b!=null){
            filter=b.getString(STATE_FILTER,"all");
            window=b.getString(STATE_WINDOW,"all");
            futureLimit=Math.max(40,b.getInt(STATE_FUTURE_LIMIT,40));
            pastLimit=Math.max(60,b.getInt(STATE_PAST_LIMIT,60));
        }
        build();
    }

    @Override protected void onSaveInstanceState(Bundle out){
        out.putString(STATE_FILTER,filter);
        out.putString(STATE_WINDOW,window);
        out.putInt(STATE_FUTURE_LIMIT,futureLimit);
        out.putInt(STATE_PAST_LIMIT,pastLimit);
        super.onSaveInstanceState(out);
    }

    private void build(){
        LinearLayout frame=new LinearLayout(this);
        frame.setOrientation(LinearLayout.VERTICAL);
        frame.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        frame.setBackground(UiKit.screenBackground(this));
        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,12),UiKit.dp(this,10),UiKit.dp(this,12),UiKit.dp(this,16));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this)); sc.addView(root);
        frame.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));
        root.addView(UiKit.header(this,"خط زمانی",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"موعدها، سررسیدها و سابقه فعالیت‌ها"),UiKit.matchWrap(this,0,9));

        collect();
        long now=System.currentTimeMillis(); int overdue=0,next7=0;
        long sevenDayEnd=AgendaDuePolicy.afterCalendarDays(AgendaDuePolicy.startOfDay(now),7);
        for(Event e:past) if(isActionable(e) && e.time>0 && e.time<now) overdue++;
        for(Event e:future) if(e.time<sevenDayEnd) next7++;
        root.addView(NexaAgendaUi.stats(this,
                new String[]{"پیش رو","معوق","ثبت‌شده در گذشته"},
                new String[]{String.valueOf(future.size()),String.valueOf(overdue),String.valueOf(past.size())},
                new int[]{UiKit.PURPLE,UiKit.RED,UiKit.BLUE}),UiKit.matchWrap(this,0,10));
        TextView nextSeven=UiKit.muted(this,"۷ روز آینده: "+next7+" رویداد");
        nextSeven.setTextColor(UiKit.GOLD);
        root.addView(nextSeven,UiKit.matchWrap(this,0,10));
        LinearLayout filterHeader=new LinearLayout(this);
        filterHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
        filterHeader.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView filterLabel=UiKit.sectionTitle(this,"فیلتر رویدادها");
        filterLabel.setTextSize(13.5f);
        filterHeader.addView(filterLabel,new LinearLayout.LayoutParams(0,-2,1f));
        clearFilters=UiKit.chip(this,"نمایش همه",false);
        clearFilters.setContentDescription("پاک کردن همه فیلترهای خط زمانی");
        clearFilters.setOnClickListener(v->{
            filter="all";window="all";resetLimits();
            renderFilters();renderWindows();render();
        });
        filterHeader.addView(clearFilters);
        root.addView(filterHeader,UiKit.matchWrap(this,0,6));

        HorizontalScrollView hs=new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false);
        filters=new LinearLayout(this); filters.setOrientation(LinearLayout.HORIZONTAL); filters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); hs.addView(filters);
        root.addView(hs,UiKit.matchWrap(this,0,8));
        windows=new LinearLayout(this); windows.setOrientation(LinearLayout.HORIZONTAL);
        windows.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        renderWindows();
        root.addView(windows,UiKit.matchWrap(this,0,7));
        visibleCount=UiKit.muted(this,"");
        visibleCount.setTextSize(11.5f);
        root.addView(visibleCount,UiKit.matchWrap(this,0,7));
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); root.addView(content);
        renderFilters(); render();
        LinearLayout nav=UiKit.referenceBottomNav(this,-1);
        LinearLayout.LayoutParams navLp=new LinearLayout.LayoutParams(-1,-2);
        navLp.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,12),UiKit.dp(this,9));
        frame.addView(nav,navLp);
        setContentView(frame);
    }

    private boolean isActionable(Event e){return !"history".equals(e.kind)&&!"service".equals(e.kind);}

    private void collect(){
        future.clear(); past.clear(); long now=System.currentTimeMillis();
        long todayStart=AgendaDuePolicy.startOfDay(now);
        for(NexaStore.Reminder r:NexaStore.reminders(this)) if(r.active&&r.whenMillis>0){
            long shown=r.done?r.whenMillis:AgendaDuePolicy.shownDue(r.whenMillis,r.recurrence,todayStart);
            Intent i=new Intent(this,ReminderEditActivity.class);
            i.putExtra("edit_id",r.id);
            put(new Event(shown,r.icon,r.title,r.category,"reminder",i),now);
        }
        for(NexaStore.Medicine m:NexaStore.medicines(this)) if(m.active&&m.nextDoseMillis>0) put(new Event(m.nextDoseMillis,"💊",m.name,m.dose,"medicine",new Intent(this,MedicineActivity.class)),now);
        for(NexaStore.CaseItem x:NexaStore.cases(this)) if(x.whenMillis>0) put(new Event(x.whenMillis,"⚖️",x.title,"دادگاه • "+x.caseNumber,"case",new Intent(this,CaseActivity.class)),now);
        for(NexaStore.BillItem x:NexaStore.bills(this)) if(!x.paid&&x.dueDate>0) put(new Event(x.dueDate,"💳",x.title,x.type,"bill",new Intent(this,BillsActivity.class)),now);
        for(NexaStore.DocumentItem x:NexaStore.documents(this)) if(x.expiryDate>0) put(new Event(x.expiryDate,"📄","انقضای "+x.title,x.type,"doc",new Intent(this,DocsActivity.class)),now);
        for(NexaStore.HomeItem x:NexaStore.homeItems(this)) if(x.nextDueDate>0) put(new Event(x.nextDueDate,"🏠",x.title,x.category,"home",new Intent(this,HomeCareActivity.class)),now);
        for(NexaStore.TodoItem x:NexaStore.todos(this)) if(!x.done&&x.dueMillis>0) put(new Event(x.dueMillis,"✅",x.title,x.category,"todo",new Intent(this,NexaListActivity.class)),now);
        for(NexaStore.ServiceRecord x:NexaStore.services(this)) if(x.nextDueDate>0) put(new Event(x.nextDueDate,"🚗",x.category,x.km+" km • سرویس خودرو","vehicle",new Intent(this,GarageActivity.class)),now);
        for(NexaStore.ServiceRecord x:NexaStore.services(this)) if(x.dateMillis>0) past.add(new Event(x.dateMillis,"🔧",x.category,x.km+" km • "+x.note,"service"));
        for(NexaStore.HistoryItem x:NexaStore.history(this)) if(x.time>0) past.add(new Event(x.time,"◷",x.type,x.text,"history"));
        future.sort(Comparator.comparingLong(a->a.time)); past.sort((a,b)->Long.compare(b.time,a.time));
    }
    private void put(Event e,long now){(e.time>now?future:past).add(e);}

    private void renderFilters(){
        filters.removeAllViews();
        addFilter("همه","all"); addFilter("یادآور","reminder"); addFilter("دارو","medicine"); addFilter("مالی","bill"); addFilter("دادگاه","case"); addFilter("کارها","todo"); addFilter("مدارک","doc"); addFilter("خانه","home"); addFilter("خودرو","vehicle"); addFilter("سابقه","history");
    }
    private void addFilter(String label,String key){
        TextView c=NexaAgendaUi.chip(this,label,key.equals(filter));
        c.setOnClickListener(v->{filter=key;resetLimits();renderFilters();render();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT); lp.setMargins(UiKit.dp(this,4),0,UiKit.dp(this,4),0); filters.addView(c,lp);
    }
    private void renderWindows(){
        windows.removeAllViews();
        addWindow(windows,"همه زمان‌ها","all");
        addWindow(windows,"امروز","today");
        addWindow(windows,"۷ روز","7d");
        addWindow(windows,"معوق","overdue");
    }
    private void addWindow(LinearLayout row,String label,String key){
        TextView c=NexaAgendaUi.chip(this,label,key.equals(window));
        c.setOnClickListener(v->{window=key;resetLimits();renderWindows();render();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f); lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0); row.addView(c,lp);
    }
    private boolean matchesWindow(Event e,long now){
        if("all".equals(window))return true;
        if("overdue".equals(window))return isActionable(e)&&e.time>0&&e.time<now;
        long start=AgendaDuePolicy.startOfDay(now);
        long end=AgendaDuePolicy.afterCalendarDays(start,"today".equals(window)?1:7);
        return e.time>=start&&e.time<end;
    }
    private boolean matches(Event e){
        if("all".equals(filter))return true;
        if("due".equals(filter))return !"history".equals(e.kind)&&!"service".equals(e.kind)&&!"medicine".equals(e.kind);
        if("history".equals(filter))return "history".equals(e.kind)||"service".equals(e.kind);
        return filter.equals(e.kind);
    }

    private void render(){
        content.removeAllViews();long now=System.currentTimeMillis();
        List<Event> visibleFuture=new ArrayList<>(),visiblePast=new ArrayList<>();
        for(Event e:future)if(matches(e)&&matchesWindow(e,now))visibleFuture.add(e);
        for(Event e:past)if(matches(e)&&matchesWindow(e,now))visiblePast.add(e);
        int visible=visibleFuture.size()+visiblePast.size();
        if(visibleCount!=null)visibleCount.setText(visible+" رویداد در این نمایش");
        if(clearFilters!=null)clearFilters.setVisibility(
                "all".equals(filter)&&"all".equals(window)?View.GONE:View.VISIBLE);
        if(visibleFuture.isEmpty()&&visiblePast.isEmpty()){
            content.addView(UiKit.emptyState(this,"موردی پیدا نشد","فیلتر یا بازه زمانی را تغییر بده."));
            return;
        }
        if(!visibleFuture.isEmpty())renderSection("پیش رو",visibleFuture,now,true);
        if(!visiblePast.isEmpty())renderSection("اخیر و معوق",visiblePast,now,false);
    }
    private void renderSection(String title,List<Event> events,long now,boolean upcoming){
        LinearLayout card=new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        TextView heading=UiKit.sectionTitle(this,title+" ("+events.size()+")");
        heading.setTextSize(14.5f);
        card.addView(heading,UiKit.matchWrap(this,3,5));
        int limit=upcoming?futureLimit:pastLimit;
        int count=Math.min(limit,events.size());
        for(int k=0;k<count;k++)addEvent(card,events.get(k),now);
        if(count<events.size()){
            Button more=UiKit.secondaryButton(this,"نمایش "+Math.min(40,events.size()-count)+" مورد دیگر");
            more.setContentDescription("نمایش رویدادهای بیشتر؛ "+(events.size()-count)+" مورد باقی‌مانده");
            more.setOnClickListener(v->{
                if(upcoming)futureLimit+=40;else pastLimit+=40;
                render();
            });
            card.addView(more,UiKit.matchWrap(this,12,0));
        }
        content.addView(card,UiKit.matchWrap(this,0,12));
    }

    private void addEvent(LinearLayout parent,Event e,long now){
        boolean isPast=e.time<=now;
        int tone=isPast?(isActionable(e)?UiKit.RED:UiKit.BLUE):UiKit.PURPLE;
        long start=AgendaDuePolicy.startOfDay(now);
        long tomorrow=AgendaDuePolicy.afterCalendarDays(start,1);
        long week=AgendaDuePolicy.afterCalendarDays(start,7);
        String status=isPast?(isActionable(e)?"معوق":"سابقه"):
                (e.time<tomorrow?"امروز":e.time<week?"این هفته":"پیش رو");
        LinearLayout row=NexaAgendaUi.event(this,e.icon,e.title,
                PersianDateUtil.pretty(e.time)+(e.sub==null||e.sub.isEmpty()?"":" • "+e.sub),
                status,tone,e.target!=null);
        if(e.target!=null){ row.setOnClickListener(v->startActivity(e.target)); row.setContentDescription("باز کردن "+e.title); }
        parent.addView(row,UiKit.matchWrap(this,8,2));
    }

    @Override protected void onResume(){super.onResume(); if(content!=null){collect();render();}}
}
