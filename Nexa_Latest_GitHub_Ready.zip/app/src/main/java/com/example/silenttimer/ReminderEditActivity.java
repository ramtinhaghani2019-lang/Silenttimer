package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class ReminderEditActivity extends Activity {
    private EditText title,note,doctorFile,doctorCenter,doctorPhone,doctorAddress;
    private AutoCompleteTextView doctorName;
    private Spinner category;
    private Button dateTime;
    private LinearLayout doctorBox;
    private NexaStore.Reminder editing;
    private final List<String> categories=new ArrayList<>();
    private long whenMillis;
    private AlertEditor alerts;

    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);String id=getIntent().getStringExtra("edit_id");if(id!=null)editing=NexaStore.reminder(this,id);whenMillis=editing!=null?editing.whenMillis:System.currentTimeMillis()+60L*60L*1000L;build();}
    private EditText field(String hint){return UiKit.styleField(this,new EditText(this),hint);}

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setBackground(UiKit.screenBackground(this));LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());head.addView(back);TextView h=UiKit.title(this,editing==null?"یادآور جدید":"ویرایش یادآور");LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(0,-2,1f);hp.setMargins(UiKit.dp(this,12),0,0,0);head.addView(h,hp);root.addView(head,UiKit.matchWrap(this,0,14));
        LinearLayout card=UiKit.colorfulCardLayout(this,6);root.addView(card);
        title=field("عنوان یادآور");card.addView(title,UiKit.matchWrap(this,0,8));
        for(String c : NexaStore.defaultReminderCategories()) categories.add(c); categories.addAll(NexaStore.customCategories(this));
        category=new Spinner(this);refreshCategory();card.addView(category,UiKit.matchWrap(this,0,5));Button categoriesBtn=UiKit.secondaryButton(this,"مدیریت دسته‌ها");categoriesBtn.setOnClickListener(v->showCategoryDirectory());card.addView(categoriesBtn,UiKit.matchWrap(this,0,8));

        doctorBox=new LinearLayout(this);doctorBox.setOrientation(LinearLayout.VERTICAL);doctorBox.setPadding(0,UiKit.dp(this,4),0,UiKit.dp(this,8));doctorBox.addView(UiKit.sectionTitle(this,"🩺 پزشک"));
        List<NexaStore.Doctor> docs=NexaStore.doctors(this);ArrayList<String> names=new ArrayList<>();for(NexaStore.Doctor d:docs)names.add(d.name);
        doctorName=new AutoCompleteTextView(this);UiKit.styleField(this,doctorName,"نام پزشک؛ انتخاب یا تایپ دستی");doctorName.setThreshold(1);doctorName.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_dropdown_item_1line,names));
        doctorBox.addView(doctorName,UiKit.matchWrap(this,8,5));Button doctorsBtn=UiKit.secondaryButton(this,"پزشکان ذخیره‌شده");doctorBox.addView(doctorsBtn,UiKit.matchWrap(this,0,5));
        doctorFile=field("شماره پرونده");doctorCenter=field("نام مطب / مرکز درمانی");doctorPhone=field("شماره تماس مطب");doctorAddress=field("آدرس");doctorBox.addView(doctorFile,UiKit.matchWrap(this,0,5));doctorBox.addView(doctorCenter,UiKit.matchWrap(this,0,5));doctorBox.addView(doctorPhone,UiKit.matchWrap(this,0,5));doctorBox.addView(doctorAddress);
        doctorName.setOnItemClickListener((p,v,pos,id)->fillDoctor(doctorName.getText().toString()));doctorsBtn.setOnClickListener(v->showDoctorDirectory());doctorBox.setVisibility(View.GONE);card.addView(doctorBox);
        category.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){@Override public void onItemSelected(AdapterView<?>p,View v,int pos,long id){updateSpecialFields();}@Override public void onNothingSelected(AdapterView<?>p){}});

        note=field("توضیحات / یادداشت");card.addView(note,UiKit.matchWrap(this,0,10));
        dateTime=UiKit.secondaryButton(this,"📅 "+PersianDateUtil.pretty(whenMillis));dateTime.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,whenMillis,"تاریخ و ساعت",ms->{whenMillis=ms;dateTime.setText("📅 "+PersianDateUtil.pretty(ms));}));card.addView(dateTime,UiKit.matchWrap(this,0,8));
        alerts=new AlertEditor(this,card,editing==null?"0":editing.offsetsMinutes,editing==null?5:editing.repeatMinutes);
        Button save=UiKit.primaryButton(this,"ذخیره یادآور");save.setOnClickListener(v->save());root.addView(save,UiKit.matchWrap(this,14,0));

        if(editing!=null){title.setText(editing.title);note.setText(editing.note);int ix=categories.indexOf(editing.category);if(ix>=0)category.setSelection(ix);doctorName.setText(editing.doctorName);doctorFile.setText(editing.doctorFileNumber);doctorCenter.setText(editing.doctorCenter);doctorPhone.setText(editing.doctorPhone);doctorAddress.setText(editing.doctorAddress);}
        setContentView(sc);updateSpecialFields();
    }

    private void refreshCategory(){ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,categories){@Override public View getView(int p,View v,android.view.ViewGroup g){TextView x=(TextView)super.getView(p,v,g);x.setTextColor(UiKit.TEXT);return x;}@Override public View getDropDownView(int p,View v,android.view.ViewGroup g){TextView x=(TextView)super.getDropDownView(p,v,g);x.setTextColor(UiKit.TEXT);x.setBackgroundColor(UiKit.CARD_2);return x;}};category.setAdapter(a);}
    private void updateSpecialFields(){Object selected=category.getSelectedItem();String cat=selected==null?"":String.valueOf(selected);doctorBox.setVisibility(cat.contains("دکتر")||cat.contains("پزشک")||cat.contains("دندان")?View.VISIBLE:View.GONE);}
    private void showCategoryDirectory(){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"دسته‌های یادآور"),UiKit.matchWrap(this,0,8));final AlertDialog[] holder=new AlertDialog[1];for(String cat:categories){Button b=UiKit.secondaryButton(this,cat);b.setOnClickListener(v->{int ix=categories.indexOf(cat);if(ix>=0){category.setSelection(ix);updateSpecialFields();}if(holder[0]!=null)holder[0].dismiss();});box.addView(b,UiKit.matchWrap(this,0,5));}Button add=UiKit.addIconButton(this);add.setOnClickListener(v->{if(holder[0]!=null)holder[0].dismiss();newCategory();});box.addView(add,UiKit.matchWrap(this,8,0));holder[0]=new AlertDialog.Builder(this).setView(box).setNegativeButton("بستن",null).create();holder[0].show();}
    private void showDoctorDirectory(){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"پزشکان ذخیره‌شده"),UiKit.matchWrap(this,0,8));List<NexaStore.Doctor> docs=NexaStore.doctors(this);if(docs.isEmpty())box.addView(UiKit.muted(this,"هنوز پزشکی ذخیره نشده."),UiKit.matchWrap(this,0,8));for(NexaStore.Doctor d:docs){Button b=UiKit.secondaryButton(this,d.name+(d.specialty.isEmpty()?"":" • "+d.specialty));b.setOnClickListener(v->{doctorName.setText(d.name);fillDoctor(d.name);});box.addView(b,UiKit.matchWrap(this,0,5));}Button add=UiKit.addIconButton(this);add.setOnClickListener(v->doctorDialog());box.addView(add,UiKit.matchWrap(this,8,0));new AlertDialog.Builder(this).setTitle("انتخاب پزشک").setView(box).setNegativeButton("بستن",null).show();}
    private void newCategory(){EditText e=field("نام دسته جدید");new AlertDialog.Builder(this).setTitle("دسته جدید").setView(e).setPositiveButton("افزودن",(d,w)->{String x=e.getText().toString().trim();if(!x.isEmpty()){String val="🔖 "+x;NexaStore.addCustomCategory(this,val);categories.add(val);refreshCategory();category.setSelection(categories.size()-1);}}).setNegativeButton("انصراف",null).show();}
    private void fillDoctor(String name){NexaStore.Doctor d=NexaStore.doctorByName(this,name);if(d==null)return;doctorFile.setText(d.fileNumber);doctorCenter.setText(d.center);doctorPhone.setText(d.phone);doctorAddress.setText(d.address);}
    private void doctorDialog(){LinearLayout box=UiKit.dialogPanel(this);EditText n=field("نام پزشک"),sp=field("تخصص"),file=field("شماره پرونده"),center=field("مطب / مرکز"),phone=field("شماره تماس"),address=field("آدرس");for(View v:new View[]{n,sp,file,center,phone,address})box.addView(v,UiKit.matchWrap(this,0,6));new AlertDialog.Builder(this).setTitle("افزودن پزشک").setView(box).setPositiveButton("ذخیره",(d,w)->{String name=n.getText().toString().trim();if(name.isEmpty())return;NexaStore.Doctor doc=new NexaStore.Doctor();doc.name=name;doc.specialty=sp.getText().toString().trim();doc.fileNumber=file.getText().toString().trim();doc.center=center.getText().toString().trim();doc.phone=phone.getText().toString().trim();doc.address=address.getText().toString().trim();NexaStore.upsertDoctor(this,doc);doctorName.setText(doc.name);fillDoctor(doc.name);}).setNegativeButton("انصراف",null).show();}

    private void save(){String t=title.getText().toString().trim();if(t.isEmpty()){Toast.makeText(this,"عنوان را وارد کن.",Toast.LENGTH_SHORT).show();return;}if(whenMillis<=System.currentTimeMillis()){Toast.makeText(this,"زمان باید در آینده باشد.",Toast.LENGTH_SHORT).show();return;}NexaStore.Reminder original=editing==null?null:NexaStore.reminder(this,editing.id);NexaStore.Reminder r=editing==null?new NexaStore.Reminder():editing;r.title=t;String cat=String.valueOf(category.getSelectedItem());r.category=cat;r.icon=cat.contains(" ")?cat.substring(0,cat.indexOf(' ')):"📅";r.note=note.getText().toString().trim();if(doctorBox.getVisibility()==View.VISIBLE){r.doctorName=doctorName.getText().toString().trim();r.doctorFileNumber=doctorFile.getText().toString().trim();r.doctorCenter=doctorCenter.getText().toString().trim();r.doctorPhone=doctorPhone.getText().toString().trim();r.doctorAddress=doctorAddress.getText().toString().trim();if(!r.doctorName.isEmpty()){NexaStore.Doctor d=new NexaStore.Doctor();d.name=r.doctorName;d.fileNumber=r.doctorFileNumber;d.center=r.doctorCenter;d.phone=r.doctorPhone;d.address=r.doctorAddress;NexaStore.upsertDoctor(this,d);}}r.whenMillis=whenMillis;r.offsetsMinutes=alerts.rules();r.repeatMinutes=alerts.repeatMinutes();r.done=false;r.active=true;if(editing==null)NexaStore.addReminder(this,r);else{List<NexaStore.Reminder>current=NexaStore.reminders(this);for(int i=0;i<current.size();i++)if(current.get(i).id.equals(r.id))current.set(i,r);NexaStore.saveReminders(this,current);}if(original!=null)ReminderScheduler.cancelReminder(this,original);ReminderScheduler.scheduleReminder(this,r);NexaStore.addHistory(this,"یادآور",(editing==null?"ثبت شد: ":"ویرایش شد: ")+r.title);TodayNotificationManager.refresh(this);finish();}
}
