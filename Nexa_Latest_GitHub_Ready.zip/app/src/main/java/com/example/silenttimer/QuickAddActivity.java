package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.HorizontalScrollView;
import android.widget.TextView;
import java.util.List;

/** High-frequency entry points kept shallow, with all legacy intent extras intact. */
public class QuickAddActivity extends Activity {
    private static final String RECENT_PREFS = "nexa_quick_routes";
    private static final String RECENT_KEY = "recent_v1";

    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.header(this,"ثبت سریع",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"مسیرهای پرکاربرد، بدون عبور از منوهای اضافه"),UiKit.matchWrap(this,0,12));
        boolean stacked=QuickAddLayoutPolicy.stack(this);
        LinearLayout actions=new LinearLayout(this);
        actions.setOrientation(stacked?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button search=UiKit.primaryButton(this,"⌕  جستجوی سراسری");
        search.setOnClickListener(v->open(SearchActivity.class,null));
        actions.addView(search,stacked?new LinearLayout.LayoutParams(-1,-2)
                :new LinearLayout.LayoutParams(0,-2,1f));
        Button timeline=UiKit.secondaryButton(this,"◷  خط زمانی");
        timeline.setOnClickListener(v->open(TimelineActivity.class,null));
        LinearLayout.LayoutParams lp=stacked?new LinearLayout.LayoutParams(-1,-2)
                :new LinearLayout.LayoutParams(0,-2,1f);
        if(stacked)lp.setMargins(0,UiKit.dp(this,8),0,0);
        else lp.setMargins(UiKit.dp(this,7),0,0,0);
        actions.addView(timeline,lp);
        root.addView(actions,UiKit.matchWrap(this,0,12));
        android.widget.TextView allSections=HomeUi.directoryLink(this,"☷  همه بخش‌های نکسا");
        allSections.setOnClickListener(v->open(ModulesActivity.class,null));
        root.addView(allSections,UiKit.matchWrap(this,0,12));
        Item[] entries = routes();
        recentSection(root,entries);
        section(root,"ثبت‌های روزمره");
        pair(root,entries[0],entries[1]);
        pair(root,entries[2],entries[3]);
        pair(root,entries[4],entries[5]);
        section(root,"مالی و دارایی");
        pair(root,entries[6],entries[7]);
        section(root,"مدیریت شخصی");
        pair(root,entries[8],entries[9]);
        pair(root,entries[10],entries[11]);
        // Keep the primary destinations visible without forcing a long scroll.
        LinearLayout screen=new LinearLayout(this);
        screen.setOrientation(LinearLayout.VERTICAL);
        screen.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        screen.setBackground(UiKit.screenBackground(this));
        screen.addView(sc,new LinearLayout.LayoutParams(-1,0,1f));
        LinearLayout nav=UiKit.referenceBottomNav(this,-1);
        LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,-2);
        np.setMargins(UiKit.dp(this,12),0,UiKit.dp(this,12),UiKit.dp(this,9));
        screen.addView(nav,np);
        setContentView(screen);
    }
    private void section(LinearLayout root,String title){
        root.addView(UiKit.sectionTitle(this,title),UiKit.matchWrap(this,8,8));
    }
    private void pair(LinearLayout root,Item first,Item second){
        boolean stacked=QuickAddLayoutPolicy.stack(this);
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(stacked?LinearLayout.VERTICAL:LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addTile(row,first,false,stacked);addTile(row,second,true,stacked);
        root.addView(row,UiKit.matchWrap(this,0,9));
    }
    private void addTile(LinearLayout row,Item item,boolean margin,boolean stacked){
        LinearLayout tile=NexaActionUi.quickActionTile(this,item.icon,item.label,
                item.detail,item.color,stacked);
        tile.setOnClickListener(v->open(item));
        tile.setFocusable(true);
        tile.setClickable(true);
        tile.setContentDescription(item.label+"؛ "+item.detail+"؛ برای باز کردن دوبار ضربه بزنید");
        LinearLayout.LayoutParams lp=stacked?new LinearLayout.LayoutParams(-1,-2)
                :new LinearLayout.LayoutParams(0,-2,1f);
        if(margin){
            if(stacked)lp.setMargins(0,UiKit.dp(this,8),0,0);
            else lp.setMargins(UiKit.dp(this,8),0,0,0);
        }
        row.addView(tile,lp);
    }
    private Item[] routes(){
        return new Item[]{
                new Item("voice","voice","ثبت صوتی","ثبت فرمان با گفتار",VoiceQuickAddActivity.class,null,7),
                new Item("occasion","occasions","مناسبت سالانه","تولد و سالگرد",OccasionEditActivity.class,null,5),
                new Item("reminder","reminders","یادآور","تاریخ و تکرار",ReminderEditActivity.class,null,5),
                new Item("medicine","medicine","دارو","مصرف و هشدار",MedicineActivity.class,null,4),
                new Item("shopping","lists","قلم خرید","فهرست خرید",NexaListActivity.class,"shopping",2),
                new Item("todo","lists","کارهای من","انجام‌دادنی‌ها",NexaListActivity.class,"todo",3),
                new Item("bills","bills","قسط و قبض","موعد پرداخت",BillsActivity.class,"bool",0),
                new Item("assets","assets","دارایی","سرمایه‌گذاری",AssetsActivity.class,"bool",1),
                new Item("case","case","پرونده","امور حقوقی",CaseActivity.class,"bool",6),
                new Item("docs","docs","مدرک","اسناد و انقضا",DocsActivity.class,"bool",5),
                new Item("homecare","home","سرویس خانه","نگهداری دوره‌ای",HomeCareActivity.class,"bool",3),
                new Item("vehicle","vehicle","خودرو","سرویس و سوخت",GarageActivity.class,null,7)
        };
    }
    private void recentSection(LinearLayout root,Item[] routes){
        String saved=getSharedPreferences(RECENT_PREFS,MODE_PRIVATE).getString(RECENT_KEY,"");
        List<String> recent=QuickAccessRecentPolicy.recent(saved);
        if(recent.isEmpty())return; // First launch stays uncluttered.
        LinearLayout recentHeader=new LinearLayout(this);
        recentHeader.setOrientation(LinearLayout.HORIZONTAL);
        recentHeader.setGravity(android.view.Gravity.CENTER_VERTICAL);
        recentHeader.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        recentHeader.addView(UiKit.sectionTitle(this,"دسترسی‌های اخیر"),
                new LinearLayout.LayoutParams(0,-2,1f));
        TextView clear=UiKit.muted(this,"پاک‌کردن");
        clear.setTextSize(12f);
        clear.setMinimumHeight(UiKit.dp(this,48));
        clear.setGravity(android.view.Gravity.CENTER);
        clear.setPadding(UiKit.dp(this,9),0,UiKit.dp(this,9),0);
        clear.setClickable(true);clear.setFocusable(true);
        clear.setContentDescription("پاک کردن فقط فهرست مسیرهای اخیر");
        UiKit.touchFeedback(this,clear,UiKit.GOLD,12);
        clear.setOnClickListener(v->{
            getSharedPreferences(RECENT_PREFS,MODE_PRIVATE).edit().remove(RECENT_KEY).apply();
            build();
        });
        recentHeader.addView(clear);
        root.addView(recentHeader,UiKit.matchWrap(this,4,4));
        HorizontalScrollView scroll=new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        scroll.setFillViewport(false);
        LinearLayout bar=new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        for(String key:recent){
            Item target=null;
            for(Item option:routes){if(option.id.equals(key)){target=option;break;}}
            if(target==null)continue;
            final Item item=target;
            TextView chip=UiKit.chip(this,item.label,false);
            chip.setMinimumHeight(UiKit.dp(this,48));
            chip.setMinHeight(UiKit.dp(this,48));
            chip.setClickable(true);chip.setFocusable(true);
            chip.setContentDescription("باز کردن مسیر اخیر "+item.label);
            UiKit.touchFeedback(this,chip,UiKit.GOLD,14);
            chip.setOnClickListener(v->open(item));
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-2,-2);
            cp.setMargins(0,0,UiKit.dp(this,8),0);
            bar.addView(chip,cp);
        }
        scroll.addView(bar);
        root.addView(scroll,UiKit.matchWrap(this,0,12));
    }
    private void navigate(Class<?> cls){
        startActivity(new Intent(this,cls));
        finish();
    }
    private void open(Item item){
        String saved=getSharedPreferences(RECENT_PREFS,MODE_PRIVATE).getString(RECENT_KEY,"");
        String updated=QuickAccessRecentPolicy.remember(saved,item.id);
        getSharedPreferences(RECENT_PREFS,MODE_PRIVATE).edit().putString(RECENT_KEY,updated).apply();
        open(item.target,item.quick);
    }
    private void open(Class<?> cls,String quick){
        Intent intent=new Intent(this,cls);
        if("shopping".equals(quick)||"todo".equals(quick))intent.putExtra("quick_add",quick);
        else if("bool".equals(quick))intent.putExtra("quick_add",true);
        startActivity(intent);finish();
    }
    private static final class Item{
        final String id,icon,label,detail,quick;final Class<?> target;final int color;
        Item(String id,String icon,String label,String detail,Class<?> target,String quick,int color){
            this.id=id;this.icon=icon;this.label=label;this.detail=detail;
            this.target=target;this.quick=quick;this.color=color;
        }
    }
}
