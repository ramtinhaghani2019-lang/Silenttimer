package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class QuickAddActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"Quick Add"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"سریع انتخاب کن چه چیزی می‌خواهی ثبت کنی."),UiKit.matchWrap(this,0,14));

        add(root,"⌕  جستجوی سراسری",SearchActivity.class,null);
        add(root,"◷  Timeline / پیگیری",TimelineActivity.class,null);

        add(root,"📅  یادآور",ReminderEditActivity.class,null);
        add(root,"💊  دارو",MedicineActivity.class,null);
        add(root,"🛒  قلم خرید",NexaListActivity.class,"shopping");
        add(root,"✓  کار / To‑Do",NexaListActivity.class,"todo");
        add(root,"⚖️  پرونده / دادگاه",CaseActivity.class,"bool");
        add(root,"📈  دارایی",AssetsActivity.class,"bool");
        add(root,"📄  مدرک",DocsActivity.class,"bool");
        add(root,"💳  قسط / قبض",BillsActivity.class,"bool");
        add(root,"🏠  سرویس خانه",HomeCareActivity.class,"bool");
        add(root,"🚗  وسیله / سرویس خودرو",GarageActivity.class,null);

        setContentView(sc);
    }

    private void add(LinearLayout root,String text,Class<?> cls,String quick) {
        Button b=UiKit.secondaryButton(this,text);
        b.setTextSize(16);
        b.setOnClickListener(v->{
            Intent i=new Intent(this,cls);
            if("shopping".equals(quick)||"todo".equals(quick))i.putExtra("quick_add",quick);
            else if("bool".equals(quick))i.putExtra("quick_add",true);
            startActivity(i);
            finish();
        });
        root.addView(b,UiKit.matchWrap(this,0,8));
    }
}
