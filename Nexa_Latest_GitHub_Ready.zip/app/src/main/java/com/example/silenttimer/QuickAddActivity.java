package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/** High-frequency entry points kept shallow, with all legacy intent extras intact. */
public class QuickAddActivity extends Activity {
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);sc.setClipToPadding(false);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        root.addView(UiKit.header(this,"ثبت سریع",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"مسیرهای پرکاربرد، بدون عبور از منوهای اضافه"),UiKit.matchWrap(this,0,12));
        LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        Button search=UiKit.primaryButton(this,"⌕  جستجوی سراسری");
        search.setOnClickListener(v->open(SearchActivity.class,null));
        actions.addView(search,new LinearLayout.LayoutParams(0,-2,1f));
        Button timeline=UiKit.secondaryButton(this,"◷  خط زمانی");
        timeline.setOnClickListener(v->open(TimelineActivity.class,null));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        lp.setMargins(UiKit.dp(this,7),0,0,0);actions.addView(timeline,lp);
        root.addView(actions,UiKit.matchWrap(this,0,12));
        section(root,"ثبت‌های روزمره");
        pair(root,new Item("📅","یادآور","تاریخ و تکرار",ReminderEditActivity.class,null,5),
                  new Item("💊","دارو","مصرف و هشدار",MedicineActivity.class,null,4));
        pair(root,new Item("🛒","قلم خرید","فهرست خرید",NexaListActivity.class,"shopping",2),
                  new Item("✓","کارهای من","انجام‌دادنی‌ها",NexaListActivity.class,"todo",3));
        section(root,"مالی و دارایی");
        pair(root,new Item("💳","قسط و قبض","موعد پرداخت",BillsActivity.class,"bool",0),
                  new Item("📈","دارایی","سرمایه‌گذاری",AssetsActivity.class,"bool",1));
        section(root,"مدیریت شخصی");
        pair(root,new Item("⚖️","پرونده","امور حقوقی",CaseActivity.class,"bool",6),
                  new Item("📄","مدرک","اسناد و انقضا",DocsActivity.class,"bool",5));
        pair(root,new Item("🏠","سرویس خانه","نگهداری دوره‌ای",HomeCareActivity.class,"bool",3),
                  new Item("🚗","خودرو","سرویس و سوخت",GarageActivity.class,null,7));
        setContentView(sc);
    }
    private void section(LinearLayout root,String title){
        root.addView(UiKit.sectionTitle(this,title),UiKit.matchWrap(this,8,8));
    }
    private void pair(LinearLayout root,Item first,Item second){
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        addTile(row,first,false);addTile(row,second,true);
        root.addView(row,UiKit.matchWrap(this,0,9));
    }
    private void addTile(LinearLayout row,Item item,boolean margin){
        LinearLayout tile=NexaActionUi.tile(this,item.icon,item.label,item.detail,item.color);
        tile.setOnClickListener(v->open(item.target,item.quick));
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        if(margin)lp.setMargins(UiKit.dp(this,8),0,0,0);
        row.addView(tile,lp);
    }
    private void open(Class<?> cls,String quick){
        Intent intent=new Intent(this,cls);
        if("shopping".equals(quick)||"todo".equals(quick))intent.putExtra("quick_add",quick);
        else if("bool".equals(quick))intent.putExtra("quick_add",true);
        startActivity(intent);finish();
    }
    private static final class Item{
        final String icon,label,detail,quick;final Class<?> target;final int color;
        Item(String icon,String label,String detail,Class<?> target,String quick,int color){
            this.icon=icon;this.label=label;this.detail=detail;this.target=target;this.quick=quick;this.color=color;
        }
    }
}
