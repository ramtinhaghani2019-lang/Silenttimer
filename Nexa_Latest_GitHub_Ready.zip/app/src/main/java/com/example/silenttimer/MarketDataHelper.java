package com.example.silenttimer;

import android.app.Activity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

/** Fetches reference global market data. Invalid/partial responses never replace the last good snapshot. */
public final class MarketDataHelper {
    private MarketDataHelper() {}
    public static final String METALS_SOURCE = "Gold API";
    public static final String FX_SOURCE = "ExchangeRate-API (open)";
    private static final AtomicBoolean REFRESHING = new AtomicBoolean(false);
    private static final int MAX_RESPONSE_CHARS = 256 * 1024;

    public interface Callback { void onDone(boolean ok, String message); }

    public static void refresh(Activity a, Callback cb) {
        if (!REFRESHING.compareAndSet(false, true)) { cb.onDone(false, "به‌روزرسانی قیمت‌ها در حال انجام است."); return; }
        NexaStore.setMarketLastAttempt(a, System.currentTimeMillis(), false);
        new Thread(() -> {
            try {
                double gold = fetchPrice("XAU");
                double silver = fetchPrice("XAG");
                double copper = fetchPrice("HG");
                double eurPerUsd = fetchEurPerUsd();
                if (!isValidSnapshot(gold, silver, copper, eurPerUsd))
                    throw new IllegalStateException("incomplete market snapshot");
                long now = System.currentTimeMillis();
                NexaStore.setMarketSnapshot(a, gold, silver, copper, eurPerUsd, now);
                NexaStore.setMarketSources(a, METALS_SOURCE, FX_SOURCE);
                NexaStore.setMarketLastAttempt(a, now, true);
                a.runOnUiThread(() -> cb.onDone(true, "قیمت‌های مرجع جهانی با موفقیت به‌روزرسانی شد."));
            } catch (Exception e) {
                // Preserve the last known-good snapshot. Never replace it with zero/partial data.
                a.runOnUiThread(() -> cb.onDone(false, "دریافت آنلاین ناموفق بود؛ آخرین داده معتبر حفظ شد."));
            } finally { REFRESHING.set(false); }
        }).start();
    }

    static boolean isValidSnapshot(double gold,double silver,double copper,double eurPerUsd) {
        return inRange(gold, 100d, 100000d) && inRange(silver, 1d, 10000d)
                && inRange(copper, 0.01d, 100000d) && inRange(eurPerUsd, 0.1d, 10d);
    }
    static boolean positiveFinite(double v) { return v > 0d && !Double.isNaN(v) && !Double.isInfinite(v); }
    static boolean inRange(double v,double min,double max) { return positiveFinite(v) && v >= min && v <= max; }

    private static double fetchPrice(String symbol) throws Exception {
        JSONObject j = getJson("https://api.gold-api.com/price/" + symbol);
        double value = j.optDouble("price", 0);
        if (!positiveFinite(value)) throw new IllegalStateException("invalid price " + symbol);
        return value;
    }

    private static double fetchEurPerUsd() throws Exception {
        JSONObject j = getJson("https://open.er-api.com/v6/latest/USD");
        String result=j.optString("result", "success");
        if (!"success".equalsIgnoreCase(result)) throw new IllegalStateException("fx service failure");
        JSONObject rates = j.optJSONObject("rates");
        double value = rates == null ? 0 : rates.optDouble("EUR", 0);
        if (!positiveFinite(value)) throw new IllegalStateException("invalid EUR rate");
        return value;
    }

    private static JSONObject getJson(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        try {
            con.setConnectTimeout(12000); con.setReadTimeout(12000);
            con.setRequestProperty("User-Agent", "Nexa/5.4.55");
            con.setRequestProperty("Accept", "application/json");
            int code=con.getResponseCode();
            if(code<200 || code>=300) throw new IllegalStateException("HTTP "+code);
            try(BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream(), StandardCharsets.UTF_8))) {
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = br.readLine()) != null) { sb.append(line); if (sb.length() > MAX_RESPONSE_CHARS) throw new IllegalStateException("response too large"); }
                if(sb.length()==0) throw new IllegalStateException("empty response");
                return new JSONObject(sb.toString());
            }
        } finally { con.disconnect(); }
    }
}
