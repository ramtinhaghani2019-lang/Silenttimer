package com.example.silenttimer;

import android.app.Activity;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public final class MarketDataHelper {
    private MarketDataHelper() {}

    public interface Callback {
        void onDone(boolean ok, String message);
    }

    public static void refresh(Activity a, Callback cb) {
        new Thread(() -> {
            try {
                double gold = fetchPrice("XAU");
                double silver = fetchPrice("XAG");
                double copper = fetchPrice("HG");
                double eurPerUsd = fetchEurPerUsd();

                NexaStore.setMarketSnapshot(
                        a,
                        gold,
                        silver,
                        copper,
                        eurPerUsd,
                        System.currentTimeMillis()
                );

                a.runOnUiThread(() -> cb.onDone(true, "قیمت‌های مرجع جهانی به‌روزرسانی شد."));
            } catch (Exception e) {
                a.runOnUiThread(() -> cb.onDone(false, "به‌روزرسانی آنلاین انجام نشد. اینترنت را بررسی کن."));
            }
        }).start();
    }

    private static double fetchPrice(String symbol) throws Exception {
        JSONObject j = getJson("https://api.gold-api.com/price/" + symbol);
        return j.optDouble("price", 0);
    }

    private static double fetchEurPerUsd() throws Exception {
        JSONObject j = getJson("https://open.er-api.com/v6/latest/USD");
        JSONObject rates = j.optJSONObject("rates");
        return rates == null ? 0 : rates.optDouble("EUR", 0);
    }

    private static JSONObject getJson(String url) throws Exception {
        HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
        con.setConnectTimeout(12000);
        con.setReadTimeout(12000);
        con.setRequestProperty("User-Agent", "Nexa/5.1");

        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;

        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        con.disconnect();

        return new JSONObject(sb.toString());
    }
}
