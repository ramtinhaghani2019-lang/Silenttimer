package com.example.silenttimer;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.json.JSONObject;
import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.util.concurrent.atomic.AtomicBoolean;

/** Iranian free-market snapshot. Invalid/partial responses never replace the last known-good snapshot. */
public final class MarketDataHelper {
    private MarketDataHelper() {}
    public static final String IRAN_SOURCE="Nexa Iran Market Feed";
    private static final String LIVE_URL="https://nerkh.jahankhahan.shop/data/live.json";
    private static final AtomicBoolean REFRESHING=new AtomicBoolean(false);
    private static final int MAX_RESPONSE_CHARS=256*1024;
    private static final long MAX_SNAPSHOT_AGE_MS=30*60_000L;
    public interface Callback { void onDone(boolean ok,String message); }
    public static void refresh(Activity a,Callback cb){ refresh((Context)a,cb); }
    public static void refresh(Context a,Callback cb){
        if(!REFRESHING.compareAndSet(false,true)){cb.onDone(false,"به‌روزرسانی قیمت‌ها در حال انجام است.");return;}
        NexaStore.setMarketLastAttempt(a,System.currentTimeMillis(),false);
        new Thread(()->{try{JSONObject j=getJson(LIVE_URL);JSONObject r=j.optJSONObject("rates");if(r==null)throw new IllegalStateException("rates missing");
            double usd=pick(r,"dollar","usd"),eur=pick(r,"euro","eur"),g18=pick(r,"gold","gold18","gold_18"),g24=pick(r,"gold24","gold_24","24k");
            double ounce=j.optDouble("ounce",pick(r,"ounce","xauusd","gold_global"));double emami=pick(r,"emami","coin_emami","sekke_emami"),bahar=pick(r,"bahar","azadi","coin_bahar"),half=pick(r,"half","half_coin"),quarter=pick(r,"quarter","quarter_coin"),gerami=pick(r,"gerami","gram_coin");
            if(g24<=0&&g18>0)g24=g18/0.75d; // deterministic purity conversion only when feed omits 24k
            if(!isValidIranSnapshot(usd,eur,g18,g24,ounce))throw new IllegalStateException("invalid iran snapshot");
            long feedTime=readFeedTime(j); if(feedTime>0 && System.currentTimeMillis()-feedTime>MAX_SNAPSHOT_AGE_MS)throw new IllegalStateException("stale iran snapshot");
            long now=System.currentTimeMillis();NexaStore.setIranMarketSnapshot(a,usd,eur,g18,g24,ounce,emami,bahar,half,quarter,gerami,now);NexaStore.recordIranMarketHistory(a,now,usd,eur,g18,g24,ounce,emami,bahar,half,quarter,gerami);NexaStore.setIranMarketSource(a,IRAN_SOURCE);NexaStore.setMarketLastAttempt(a,now,true);
            main(()->cb.onDone(true,"قیمت‌های بازار ایران به‌روزرسانی شد."));
        }catch(Exception e){main(()->cb.onDone(false,"دریافت بازار ایران ناموفق بود؛ آخرین قیمت معتبر حفظ شد."));}finally{REFRESHING.set(false);}}).start();
    }
    private static void main(Runnable r){new Handler(Looper.getMainLooper()).post(r);}
    static boolean isValidIranSnapshot(double usd,double eur,double g18,double g24,double ounce){return inRange(usd,1000,10000000)&&inRange(eur,1000,15000000)&&inRange(g18,100000,100000000)&&inRange(g24,100000,150000000)&&inRange(ounce,100,100000);}
    static boolean positiveFinite(double v){return v>0&&!Double.isNaN(v)&&!Double.isInfinite(v);} static boolean inRange(double v,double min,double max){return positiveFinite(v)&&v>=min&&v<=max;}
    static boolean isFreshSnapshot(long now,long feedTime){return feedTime<=0 || (feedTime<=now && now-feedTime<=MAX_SNAPSHOT_AGE_MS);}
    private static long readFeedTime(JSONObject j){for(String k:new String[]{"timestamp","updated_at","updatedAt","time"}){Object v=j.opt(k);if(v instanceof Number){long n=((Number)v).longValue();if(n>0&&n<10_000_000_000L)n*=1000L;return n;}if(v instanceof String){try{long n=Long.parseLong(((String)v).trim());if(n>0&&n<10_000_000_000L)n*=1000L;return n;}catch(Exception ignored){}}}return 0;}
    private static double pick(JSONObject o,String...keys){for(String k:keys){double v=o.optDouble(k,0);if(positiveFinite(v))return v;}return 0;}
    private static JSONObject getJson(String url)throws Exception{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();try{c.setConnectTimeout(12000);c.setReadTimeout(12000);c.setRequestProperty("User-Agent","Nexa/5.4.91");c.setRequestProperty("Accept","application/json");int code=c.getResponseCode();if(code<200||code>=300)throw new IllegalStateException("HTTP "+code);try(BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),StandardCharsets.UTF_8))){StringBuilder sb=new StringBuilder();String line;while((line=br.readLine())!=null){sb.append(line);if(sb.length()>MAX_RESPONSE_CHARS)throw new IllegalStateException("response too large");}return new JSONObject(sb.toString());}}finally{c.disconnect();}}
}
