package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.net.Uri;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.HorizontalScrollView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import android.widget.CheckBox;

public class RemindersActivity extends Activity {
    private static final int REQ_ICS_EXPORT = 7341;
    private ArrayList<String> pendingCalendarIds = new ArrayList<>();
    private boolean pendingCalendarDetails = false;
    private LinearLayout list;
    private TextView summary, results, selectionSummary;
    private LinearLayout reminderMetrics, quickFilters;
    private Button filterButton,clearSearchButton;
    private EditText inlineSearch;
    private LinearLayout selectionToolbar;
    private final Set<String> selectedIds = new HashSet<>();
    private boolean selectionMode = false;
    private String filter = "all", order = "smart", searchText = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        if (b != null) {
            pendingCalendarIds=b.getStringArrayList("pendingCalendarIds");
            if(pendingCalendarIds==null)pendingCalendarIds=new ArrayList<>();
            pendingCalendarDetails=b.getBoolean("pendingCalendarDetails",false);
            filter=b.getString("filter","all");
            order=b.getString("order","smart");
            searchText=b.getString("search","");
            selectionMode=b.getBoolean("selectionMode",false);
            ArrayList<String> saved=b.getStringArrayList("selectedIds");
            if(saved!=null)selectedIds.addAll(saved);
        }
        build();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putStringArrayList("pendingCalendarIds",new ArrayList<>(pendingCalendarIds));
        out.putBoolean("pendingCalendarDetails",pendingCalendarDetails);
        out.putString("filter",filter);
        out.putString("order",order);
        out.putString("search",searchText);
        out.putBoolean("selectionMode",selectionMode);
        out.putStringArrayList("selectedIds",new ArrayList<>(selectedIds));
        super.onSaveInstanceState(out);
    }
    @Override protected void onResume() { super.onResume();render(); }

    /** Compact-first layout: deadlines, not instructions or settings, own the screen. */
    private void build() {
        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,14),UiKit.dp(this,9),UiKit.dp(this,14),UiKit.dp(this,18));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        head.addView(back);
        TextView title=UiKit.title(this,"یادآورها");
        LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0,-2,1f);
        titleParams.setMargins(UiKit.dp(this,8),0,0,0);
        head.addView(title,titleParams);
        Button add=UiKit.primaryButton(this,"＋ جدید");
        add.setOnClickListener(v->startActivity(new Intent(this,ReminderEditActivity.class)));
        head.addView(add,new LinearLayout.LayoutParams(-2,UiKit.dp(this,46)));
        root.addView(head,UiKit.matchWrap(this,0,3));

        reminderMetrics=new LinearLayout(this);
        reminderMetrics.setOrientation(LinearLayout.VERTICAL);
        root.addView(reminderMetrics,UiKit.matchWrap(this,0,9));
        summary=UiKit.muted(this,"");
        summary.setTextSize(12f);
        summary.setSingleLine(false);
        root.addView(summary,UiKit.matchWrap(this,0,9));

        // Search is directly available without opening a modal; state is still retained on rotation.
        LinearLayout searchBar=new LinearLayout(this);
        searchBar.setGravity(Gravity.CENTER_VERTICAL);
        searchBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        inlineSearch=UiKit.styleField(this,new EditText(this),"جست‌وجو در یادآورها…");
        inlineSearch.setSingleLine(true);
        inlineSearch.setText(searchText);
        inlineSearch.setContentDescription("جست‌وجو در عنوان و جزئیات یادآورها");
        searchBar.addView(inlineSearch,new LinearLayout.LayoutParams(0,UiKit.dp(this,52),1f));
        clearSearchButton=UiKit.secondaryButton(this,"✕");
        clearSearchButton.setContentDescription("پاک کردن متن جست‌وجو");
        clearSearchButton.setMinWidth(0);
        clearSearchButton.setOnClickListener(v->inlineSearch.setText(""));
        LinearLayout.LayoutParams clearSearchParams=new LinearLayout.LayoutParams(UiKit.dp(this,50),UiKit.dp(this,50));
        clearSearchParams.setMargins(UiKit.dp(this,7),0,0,0);
        searchBar.addView(clearSearchButton,clearSearchParams);
        root.addView(searchBar,UiKit.matchWrap(this,0,9));
        inlineSearch.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){
                searchText=s.toString();render();
            }
            @Override public void afterTextChanged(Editable text){}
        });

        LinearLayout commands=new LinearLayout(this);
        filterButton=UiKit.secondaryButton(this,"⌕ فیلتر و جستجو");
        filterButton.setOnClickListener(v->showFilterDialog());
        commands.addView(filterButton,new LinearLayout.LayoutParams(0,UiKit.dp(this,46),1.25f));
        Button tools=UiKit.secondaryButton(this,"⋯ ابزارها");
        tools.setOnClickListener(v->showToolsDialog());
        LinearLayout.LayoutParams toolsParams=new LinearLayout.LayoutParams(0,UiKit.dp(this,46),.85f);
        toolsParams.setMargins(UiKit.dp(this,7),0,0,0);
        commands.addView(tools,toolsParams);
        root.addView(commands,UiKit.matchWrap(this,0,8));
        Button occasions=UiKit.secondaryButton(this,"🎂 مناسبت‌ها و سالگردهای سالانه");
        occasions.setOnClickListener(v->startActivity(new Intent(this,AnnualOccasionsActivity.class)));
        root.addView(occasions,UiKit.matchWrap(this,0,10));

        quickFilters=new LinearLayout(this);
        quickFilters.setOrientation(LinearLayout.HORIZONTAL);
        quickFilters.setGravity(Gravity.CENTER_VERTICAL);
        quickFilters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        // Fixed four-column chips squeezed Persian labels on narrow phones.
        HorizontalScrollView filterScroller=new HorizontalScrollView(this);
        filterScroller.setHorizontalScrollBarEnabled(false);
        filterScroller.setFillViewport(false);
        filterScroller.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        filterScroller.addView(quickFilters);
        root.addView(filterScroller,UiKit.matchWrap(this,0,12));

        selectionToolbar=new LinearLayout(this);
        selectionToolbar.setOrientation(LinearLayout.VERTICAL);
        selectionSummary=UiKit.muted(this,"");
        selectionToolbar.addView(selectionSummary,UiKit.matchWrap(this,0,2));
        LinearLayout selectorRow=new LinearLayout(this);
        Button selectVisible=UiKit.secondaryButton(this,"انتخاب همه");
        selectVisible.setOnClickListener(v->selectVisible());
        selectorRow.addView(selectVisible,new LinearLayout.LayoutParams(0,-2,1f));
        Button clear=UiKit.secondaryButton(this,"لغو انتخاب");
        clear.setOnClickListener(v->{selectedIds.clear();render();});
        LinearLayout.LayoutParams clearParams=new LinearLayout.LayoutParams(0,-2,1f);
        clearParams.setMargins(UiKit.dp(this,5),0,0,0);
        selectorRow.addView(clear,clearParams);
        selectionToolbar.addView(selectorRow,UiKit.matchWrap(this,0,4));
        LinearLayout batchRow=new LinearLayout(this);
        String[] names={"توقف","فعال","انجام"};
        String[] actions={ReminderBatchManager.PAUSE,ReminderBatchManager.RESUME,ReminderBatchManager.DONE};
        for(int i=0;i<names.length;i++) {
            final String operation=actions[i];
            Button button=UiKit.secondaryButton(this,names[i]);
            button.setOnClickListener(v->confirmBatch(operation));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
            if(i>0)lp.setMargins(UiKit.dp(this,5),0,0,0);
            batchRow.addView(button,lp);
        }
        selectionToolbar.addView(batchRow,UiKit.matchWrap(this,0,4));
        root.addView(selectionToolbar,UiKit.matchWrap(this,0,3));

        results=UiKit.muted(this,"");
        results.setTextSize(12f);
        root.addView(results,UiKit.matchWrap(this,0,3));
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(sc);
        render();
    }

    private void showFilterDialog(){
        final String[] labels={"همه","در انتظار","معوق","متوقف","انجام‌شده","۷ روز آینده"};
        final String[] values={"all","pending","overdue","paused","done","week"};
        final String[] orderLabels={"اولویت هوشمند","موعد نزدیک‌تر","موعد دورتر","عنوان"};
        final String[] orderValues={"smart","due","recent","title"};
        LinearLayout panel=UiKit.dialogPanel(this);
        panel.setFocusableInTouchMode(true);
        EditText find=UiKit.styleField(this,new EditText(this),"جستجوی یادآورها");
        find.setSingleLine(true);
        find.setText(searchText);
        panel.addView(find,UiKit.matchWrap(this,0,9));
        Spinner categories=UiKit.styledSpinner(this);
        ArrayAdapter<String> fa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        fa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categories.setAdapter(fa);
        for(int i=0;i<values.length;i++)if(values[i].equals(filter))categories.setSelection(i);
        panel.addView(categories,UiKit.matchWrap(this,0,8));
        Spinner ordering=UiKit.styledSpinner(this);
        ArrayAdapter<String> oa=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,orderLabels);
        oa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ordering.setAdapter(oa);
        for(int i=0;i<orderValues.length;i++)if(orderValues[i].equals(order))ordering.setSelection(i);
        panel.addView(ordering,UiKit.matchWrap(this,0,4));
        panel.requestFocus();
        new AlertDialog.Builder(this).setTitle("فیلتر و مرتب‌سازی")
            .setView(panel)
            .setPositiveButton("اعمال",(d,w)->{
                searchText=find.getText().toString();
                if(inlineSearch!=null && !searchText.equals(inlineSearch.getText().toString()))
                    inlineSearch.setText(searchText);
                filter=values[categories.getSelectedItemPosition()];
                order=orderValues[ordering.getSelectedItemPosition()];
                render();
            })
            .setNeutralButton("پاک کردن",(d,w)->{
                searchText="";filter="all";order="smart";
                if(inlineSearch!=null)inlineSearch.setText("");
                render();
            }).setNegativeButton("بستن",null).show();
    }

    private void showToolsDialog(){
        final String[] options={"امروز","جستجوی سراسری","خط زمانی","افزودن سریع",
                "خروجی تقویم ICS",selectionMode?"پایان مدیریت گروهی":"مدیریت گروهی"};
        new AlertDialog.Builder(this).setTitle("ابزارهای یادآور")
            .setItems(options,(d,which)->{
                switch(which){
                    case 0:startActivity(new Intent(this,TodayActivity.class));break;
                    case 1:startActivity(new Intent(this,SearchActivity.class));break;
                    case 2:startActivity(new Intent(this,TimelineActivity.class));break;
                    case 3:startActivity(new Intent(this,QuickAddActivity.class));break;
                    case 4:chooseCalendarExport();break;
                    case 5:selectionMode=!selectionMode;
                        if(!selectionMode)selectedIds.clear();render();break;
                }
            }).setNegativeButton("بستن",null).show();
    }

    /** No calendar write permission or direct write to the phone's calendar is required. */
    private void chooseCalendarExport() {
        final List<NexaStore.Reminder> all=NexaStore.reminders(this);
        final List<NexaStore.Reminder> visible=new ArrayList<>();
        long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:ReminderOrganizer.ordered(all,order,now)) {
            if(ReminderOrganizer.visible(r,filter,now) && ReminderOrganizer.matches(r,searchText))
                visible.add(r);
        }
        final List<NexaStore.Reminder> chosen=new ArrayList<>();
        if(selectionMode && !selectedIds.isEmpty()) {
            for(NexaStore.Reminder r:all)if(selectedIds.contains(r.id))chosen.add(r);
        }
        List<String> choices=new ArrayList<>();
        if(!chosen.isEmpty())choices.add("یادآورهای انتخاب‌شده ("+chosen.size()+" مورد)");
        choices.add("نتایج جستجو / فیلتر فعلی ("+visible.size()+" مورد)");
        new AlertDialog.Builder(this).setTitle("خروجی تقویم ICS")
                .setItems(choices.toArray(new String[0]),(dialog,which)->{
                    boolean useChosen=!chosen.isEmpty() && which==0;
                    confirmCalendarDetails(useChosen?chosen:visible);
                }).setNegativeButton("انصراف",null).show();
    }

    private void confirmCalendarDetails(List<NexaStore.Reminder> source) {
        List<NexaStore.Reminder> candidates=ReminderCalendarExport.eligible(source);
        if(candidates.isEmpty()){
            Toast.makeText(this,"یادآور فعال و انجام‌نشده‌ای برای خروجی وجود ندارد",Toast.LENGTH_LONG).show();
            return;
        }
        final ArrayList<String> ids=new ArrayList<>();
        for(NexaStore.Reminder r:candidates)ids.add(r.id);
        String[] options={"فقط عنوان و زمان (پیشنهادی)","همراه یادداشت و مشخصات پزشک"};
        new AlertDialog.Builder(this).setTitle("خروجی "+ids.size()+" یادآور")
                .setMessage("مدت هر رویداد ۳۰ دقیقه است. زنگ‌های مبتنی بر فاصله دقیقه‌ای منتقل می‌شوند؛ قوانین ساعت مشخصِ چند روز قبل (D@) منتقل نمی‌شوند.\n"
                        +"رویدادهای تکراری در منطقه زمانی تقویم مقصد تفسیر می‌شوند.\n"
                        +"فایل ICS رمزگذاری نمی‌شود؛ ورود به تقویم مقصد را خودتان انجام می‌دهید.")
                .setItems(options,(dialog,index)->openCalendarFilePicker(ids,index==1))
                .setNegativeButton("انصراف",null).show();
    }

    private void openCalendarFilePicker(ArrayList<String> ids,boolean withDetails) {
        pendingCalendarIds=new ArrayList<>(ids);
        pendingCalendarDetails=withDetails;
        Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        create.addCategory(Intent.CATEGORY_OPENABLE);
        create.setType("text/calendar");
        create.putExtra(Intent.EXTRA_TITLE,"Nexa_Reminders.ics");
        try {startActivityForResult(create,REQ_ICS_EXPORT);}
        catch(Exception e){
            Toast.makeText(this,"انتخابگر ذخیره فایل در دسترس نیست",Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=REQ_ICS_EXPORT)return;
        if(resultCode!=RESULT_OK || data==null || data.getData()==null) {
            pendingCalendarIds.clear();return;
        }
        Uri destination=data.getData();
        Set<String> requested=new HashSet<>(pendingCalendarIds);
        // Re-read latest data: a reminder may have been disabled while document picker was open.
        List<NexaStore.Reminder> export=new ArrayList<>();
        for(NexaStore.Reminder r:NexaStore.reminders(this)) {
            if(requested.contains(r.id) && ReminderCalendarExport.eligible(r))export.add(r);
        }
        if(export.isEmpty()){
            pendingCalendarIds.clear();
            Toast.makeText(this,"یادآور قابل خروجی باقی نمانده است",Toast.LENGTH_LONG).show();
            return;
        }
        try(OutputStream stream=getContentResolver().openOutputStream(destination,"w")) {
            if(stream==null)throw new java.io.IOException("Cannot write selected document");
            String ics=ReminderCalendarExport.generate(export,System.currentTimeMillis(),pendingCalendarDetails);
            stream.write(ics.getBytes(StandardCharsets.UTF_8));
            stream.flush();
            Toast.makeText(this,"فایل تقویم با "+export.size()+" یادآور ذخیره شد",Toast.LENGTH_LONG).show();
        }catch(Exception e) {
            Toast.makeText(this,"ذخیره فایل تقویم ناموفق بود؛ مسیر دیگری انتخاب کنید",Toast.LENGTH_LONG).show();
        }finally{
            pendingCalendarIds.clear();
            pendingCalendarDetails=false;
        }
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.Reminder> all=NexaStore.reminders(this);
        Set<String> allIds=new HashSet<>();
        for(NexaStore.Reminder saved:all)allIds.add(saved.id);
        selectedIds.retainAll(allIds);
        selectionToolbar.setVisibility(selectionMode?View.VISIBLE:View.GONE);
        selectionSummary.setText(selectedIds.size()+" انتخاب‌شده");
        long now=System.currentTimeMillis();
        int pending=0,overdue=0,paused=0,completed=0;
        for(NexaStore.Reminder r:all){
            if(r.done)completed++;
            else if(!r.active)paused++;
            else if(ReminderOrganizer.effectiveDue(r,now)<now)overdue++;
            else pending++;
        }
        if(clearSearchButton!=null)clearSearchButton.setVisibility(searchText.isEmpty()?View.GONE:View.VISIBLE);
        reminderMetrics.removeAllViews();
        reminderMetrics.addView(NexaReminderUi.metrics(this,pending,overdue,completed));
        summary.setText(paused>0?"⏸ "+paused+" یادآور متوقف‌شده":
                "برای دیدن جزئیات، روی هر یادآور بزنید");
        showQuickFilters();
        boolean refined=!"all".equals(filter)||!"smart".equals(order)||!searchText.trim().isEmpty();
        filterButton.setText(refined?"⌕ فیلتر فعال":"⌕ فیلتر و جستجو");
        int shown=0;
        for(NexaStore.Reminder r:ReminderOrganizer.ordered(all,order,now)){
            if(!ReminderOrganizer.visible(r,filter,now)||!ReminderOrganizer.matches(r,searchText))continue;
            shown++;
            addReminderCard(r,now);
        }
        results.setVisibility(refined||selectionMode?View.VISIBLE:View.GONE);
        results.setText(shown+" از "+all.size()+" یادآور"+(selectionMode?"  •  "+selectedIds.size()+" انتخاب":""));
        if(shown==0){
            TextView empty=UiKit.muted(this,all.isEmpty()?"هنوز یادآوری نداری.":"نتیجه‌ای پیدا نشد.");
            empty.setGravity(Gravity.CENTER);
            list.addView(empty,UiKit.matchWrap(this,15,0));
        }
    }

    /** Quick chips only change the pre-existing filter; full filter and search remain available. */
    private void showQuickFilters(){
        quickFilters.removeAllViews();
        String[] titles={"همه","در انتظار","معوق","۷ روز"};
        String[] values={"all","pending","overdue","week"};
        for(int i=0;i<values.length;i++){
            final String value=values[i];
            TextView chip=NexaReminderUi.filterChip(this,titles[i],value.equals(filter));
            chip.setOnClickListener(v->{filter=value;render();});
            chip.setMinimumWidth(UiKit.dp(this,91));
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,48));
            lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
            quickFilters.addView(chip,lp);
        }
    }

    /** Title, due date and primary action remain visible. Long notes live in Details. */
    private void addReminderCard(NexaStore.Reminder r,long now) {
        long displayDue=ReminderOrganizer.effectiveDue(r,now);
        boolean overdue=!r.done&&r.active&&displayDue<now;
        LinearLayout card=NexaReminderUi.reminderCard(this,overdue,r.done);
        LinearLayout line=new LinearLayout(this);
        line.setGravity(Gravity.CENTER_VERTICAL);
        if(selectionMode){
            CheckBox check=new CheckBox(this);
            check.setContentDescription("انتخاب "+r.title);
            check.setChecked(selectedIds.contains(r.id));
            check.setOnCheckedChangeListener((button,checked)->{
                if(checked)selectedIds.add(r.id); else selectedIds.remove(r.id);
                selectionSummary.setText(selectedIds.size()+" انتخاب‌شده");
            });
            line.addView(check,new LinearLayout.LayoutParams(UiKit.dp(this,43),UiKit.dp(this,44)));
        }
        TextView icon=UiKit.muted(this,r.icon==null||r.icon.isEmpty()?"📅":r.icon);
        icon.setTextSize(22f);icon.setGravity(Gravity.CENTER);
        line.addView(icon,new LinearLayout.LayoutParams(UiKit.dp(this,34),UiKit.dp(this,46)));
        TextView name=UiKit.sectionTitle(this,r.title);
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setTextSize(15.5f);
        name.setOnClickListener(v->showReminderDetails(r));
        line.addView(name,new LinearLayout.LayoutParams(0,-2,1f));
        if(!selectionMode){
            Button done=UiKit.secondaryButton(this,r.done?"↶":"✓");
            done.setContentDescription(r.done?"بازگشایی یادآور":"ثبت انجام‌شدن یادآور");
            done.setTextSize(17f);
            done.setMinWidth(0);
            done.setPadding(0,0,0,0);
            done.setOnClickListener(v->markDone(r));
            line.addView(done,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            Button more=UiKit.secondaryButton(this,"⋮");
            more.setContentDescription("گزینه‌های "+r.title);
            more.setTextSize(20f);
            more.setMinWidth(0);
            more.setPadding(0,0,0,0);
            more.setOnClickListener(v->showReminderMenu(r));
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
            mp.setMargins(UiKit.dp(this,4),0,0,0);
            line.addView(more,mp);
        }
        card.addView(line);
        String state=r.done?"انجام‌شده":!r.active?"متوقف":overdue?"معوق":"در انتظار";
        int tone=r.done?UiKit.GREEN:!r.active?UiKit.MUTED:overdue?UiKit.RED:UiKit.PURPLE;
        LinearLayout detailRow=new LinearLayout(this);
        detailRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        detailRow.setGravity(Gravity.CENTER_VERTICAL);
        String duePrefix=r.active&&!r.done&&ReminderRecurrence.isRecurring(r.recurrence)?"نوبت جاری: ":"";
        TextView details=UiKit.muted(this,duePrefix+PersianDateUtil.pretty(displayDue)
                +ReminderRecurrence.labelSuffix(r.recurrence));
        details.setTextSize(12f);
        details.setMaxLines(2);
        details.setEllipsize(android.text.TextUtils.TruncateAt.END);
        if(overdue)details.setTextColor(UiKit.RED);
        detailRow.addView(details,new LinearLayout.LayoutParams(0,-2,1f));
        TextView badge=NexaReminderUi.state(this,state,tone);
        detailRow.addView(badge,new LinearLayout.LayoutParams(-2,-2));
        card.addView(detailRow,UiKit.matchWrap(this,7,0));
        card.setContentDescription(r.title+"، "+state+"، "+PersianDateUtil.pretty(displayDue));
        card.setOnClickListener(v->showReminderDetails(r));
        UiKit.touchFeedback(this,card,UiKit.PURPLE,18);
        list.addView(card,UiKit.matchWrap(this,0,7));
        if(ReminderRecurrence.isRecurring(r.recurrence)){
            long last=ReminderRecurrence.lastCompletedDue(r);
            if(last>0 && (!r.done || last!=r.whenMillis))addOccurrenceRow(r,last,true);
            if(r.active&&!r.done){
                long next=ReminderRecurrence.after(r.whenMillis,r.recurrence,now);
                if(next>now){
                    addOccurrenceRow(r,next,false);
                    long following=ReminderRecurrence.oneStep(next,r.recurrence);
                    if(following>next)addOccurrenceRow(r,following,false);
                }
            }
        }
    }

    /** A recurrence is a series: future dates are visible without duplicating alarms or payment data. */
    private void addOccurrenceRow(NexaStore.Reminder parent,long due,boolean completed){
        TextView row=UiKit.muted(this,(completed?"✓ انجام‌شده":"↻ نوبت آینده")+"  •  "+PersianDateUtil.format(due));
        row.setTextSize(12f);
        row.setSingleLine(true);
        row.setEllipsize(android.text.TextUtils.TruncateAt.END);
        row.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        row.setMinHeight(UiKit.dp(this,44));
        row.setPadding(UiKit.dp(this,10),UiKit.dp(this,4),UiKit.dp(this,10),UiKit.dp(this,4));
        row.setBackground(completed?UiKit.subtlePastStripe(this):UiKit.field(this));
        if(completed)row.setTextColor(0xFFD99599);
        row.setOnClickListener(v->{
            if(completed){showReminderDetails(parent);return;}
            long next=ReminderRecurrence.after(parent.whenMillis,parent.recurrence,System.currentTimeMillis());
            long[] more=ReminderRecurrence.previewFollowing(next,parent.recurrence,5);
            StringBuilder lines=new StringBuilder("موعدهای تکراری فقط برای نمایش هستند؛ ثبت جدا یا زنگ اضافه ایجاد نمی‌شود.\n\n");
            lines.append("۱. ").append(PersianDateUtil.pretty(next)).append("\n");
            for(int i=0;i<more.length;i++)lines.append(i+2).append(". ").append(PersianDateUtil.pretty(more[i])).append("\n");
            new AlertDialog.Builder(this).setTitle(parent.title+" • نوبت‌های آینده")
                    .setMessage(lines.toString()).setPositiveButton("بستن",null).show();
        });
        list.addView(row,UiKit.matchWrap(this,0,4));
    }

    private void showReminderDetails(NexaStore.Reminder r){
        StringBuilder desc=new StringBuilder();
        desc.append(r.category).append("\n").append(PersianDateUtil.pretty(r.whenMillis));
        String repeat=ReminderRecurrence.labelSuffix(r.recurrence);
        if(!repeat.isEmpty())desc.append("\n").append(repeat);
        if(!r.note.isEmpty())desc.append("\n\n").append(r.note);
        if(!r.doctorName.isEmpty())desc.append("\nپزشک: ").append(r.doctorName);
        if(!r.doctorFileNumber.isEmpty())desc.append("\nشماره پرونده: ").append(r.doctorFileNumber);
        if(!r.doctorCenter.isEmpty())desc.append("\nمرکز: ").append(r.doctorCenter);
        if(!r.doctorPhone.isEmpty())desc.append("\nتماس: ").append(r.doctorPhone);
        if(!r.doctorAddress.isEmpty())desc.append("\nآدرس: ").append(r.doctorAddress);

        new AlertDialog.Builder(this).setTitle(r.title).setMessage(desc.toString())
            .setPositiveButton("ویرایش",(d,w)->openEditor(r.id))
            .setNegativeButton("بستن",null).show();
    }

    private void showReminderMenu(NexaStore.Reminder r){
        final String[] options=r.done
            ?new String[]{"جزئیات","ویرایش","بازگشایی","تغییر موعد","کپی","حذف"}
            :new String[]{"جزئیات","ویرایش","انجام شد",r.active?"توقف":"فعال‌سازی",
                    "تغییر موعد","کپی","حذف"};
        new AlertDialog.Builder(this).setTitle(r.title)
            .setItems(options,(d,which)->{
                if(which==0)showReminderDetails(r);
                else if(which==1)openEditor(r.id);
                else if(which==2)markDone(r);
                else if(r.done){
                    if(which==3)showPostponeDialog(r);
                    else if(which==4)copyReminder(r);
                    else if(which==5)confirmDeleteReminder(r);
                }else{
                    if(which==3)togglePaused(r);
                    else if(which==4)showPostponeDialog(r);
                    else if(which==5)copyReminder(r);
                    else if(which==6)confirmDeleteReminder(r);
                }
            }).setNegativeButton("بستن",null).show();
    }

    private void confirmDeleteReminder(NexaStore.Reminder r){
        new AlertDialog.Builder(this).setTitle("حذف یادآور؟").setMessage(r.title)
            .setPositiveButton("حذف",(d,w)->{
                ReminderScheduler.cancelReminder(this,r);
                NexaStore.removeReminder(this,r.id);
                NexaStore.addHistory(this,"یادآور","حذف شد: "+r.title);
                ReminderScheduler.updateLockCard(this);
                TodayNotificationManager.refresh(this);
                render();
            }).setNegativeButton("انصراف",null).show();
    }

    private void selectVisible(){
        if(!selectionMode)return;
        long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:NexaStore.reminders(this)) {
            if(ReminderOrganizer.visible(r,filter,now) && ReminderOrganizer.matches(r,searchText))
                selectedIds.add(r.id);
        }
        render();
    }

    private void confirmBatch(String action){
        if(!selectionMode || selectedIds.isEmpty()){
            Toast.makeText(this,"ابتدا چند یادآور انتخاب کنید",Toast.LENGTH_SHORT).show();
            return;
        }
        int eligible=0;
        long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            if(selectedIds.contains(r.id) && ReminderBatchManager.eligible(r,action,now))eligible++;
        }
        if(eligible==0){
            Toast.makeText(this,"هیچ یادآور قابل اعمالی وجود ندارد؛ موعد گذشته را ابتدا تغییر دهید",Toast.LENGTH_LONG).show();
            return;
        }
        String label=ReminderBatchManager.PAUSE.equals(action)?"توقف":
                ReminderBatchManager.RESUME.equals(action)?"فعال‌سازی":"انجام‌شدن";
        int ignored=selectedIds.size()-eligible;
        String message="تعداد "+eligible+" یادآور با عمل «"+label+"» تغییر می‌کنند."
                +(ignored>0?"\n"+ignored+" مورد نامعتبر یا دارای موعد گذشته بدون تغییر می‌مانند.":"")
                +(ReminderBatchManager.DONE.equals(action)?
                "\nبرای یادآور تکرارشونده، نوبت بعدی به‌طور خودکار تنظیم می‌شود.":"");
        new AlertDialog.Builder(this)
                .setTitle("تأیید "+label+" گروهی")
                .setMessage(message)
                .setNegativeButton("انصراف",null)
                .setPositiveButton("تأیید",(dialog,which)->applyBatch(action))
                .show();
    }

    private void applyBatch(String action){
        long now=System.currentTimeMillis();
        List<NexaStore.Reminder> current=NexaStore.reminders(this);
        List<NexaStore.Reminder> toSchedule=new ArrayList<>();
        int changed=0;
        for(NexaStore.Reminder r:current){
            if(!selectedIds.contains(r.id) || !ReminderBatchManager.eligible(r,action,now))continue;
            ReminderScheduler.cancelReminder(this,r);
            if(ReminderBatchManager.apply(r,action,now)){
                changed++;
                if(r.active && !r.done)toSchedule.add(r);
            }
        }
        if(changed==0){
            Toast.makeText(this,"وضعیت یادآورها تغییر نکرد",Toast.LENGTH_SHORT).show();
            render();
            return;
        }
        // Single persistence operation: avoid one store rewrite per selected item.
        NexaStore.saveReminders(this,current);
        if(ReminderBatchManager.DONE.equals(action))for(NexaStore.Reminder r:toSchedule){
            if(ReminderRecurrence.isRecurring(r.recurrence))LinkedReminderHelper.syncNextOccurrence(this,r);
        }
        for(NexaStore.Reminder r:toSchedule)ReminderScheduler.scheduleReminder(this,r);
        String label=ReminderBatchManager.PAUSE.equals(action)?"توقف":
                ReminderBatchManager.RESUME.equals(action)?"فعال‌سازی":"انجام‌شدن";
        NexaStore.addHistory(this,"یادآور","عملیات گروهی "+label+": "+changed+" مورد");
        ReminderScheduler.updateLockCard(this);
        TodayNotificationManager.refresh(this);
        selectedIds.clear();
        selectionMode=false;
        Toast.makeText(this,changed+" یادآور به‌روزرسانی شد",Toast.LENGTH_LONG).show();
        render();
    }

    private void openEditor(String id){
        Intent intent=new Intent(this,ReminderEditActivity.class);
        intent.putExtra("edit_id",id);
        startActivity(intent);
    }

    private void showPostponeDialog(NexaStore.Reminder r) {
        String title=ReminderRecurrence.isRecurring(r.recurrence)
                ?"تغییر موعد؛ تکرارهای بعدی نیز از موعد جدید محاسبه می‌شوند"
                :"موعد جدید «"+r.title+"»";
        new AlertDialog.Builder(this).setTitle(title)
                .setItems(new String[]{"۱۵ دقیقه دیگر","۱ ساعت دیگر","فردا در ساعت قبلی","انتخاب تاریخ و ساعت"},
                        (dialog,which)->{
                            if(which==3)openEditor(r.id);
                            else postpone(r,which);
                        })
                .setNegativeButton("انصراف",null).show();
    }

    private void postpone(NexaStore.Reminder r,int choice) {
        long now=System.currentTimeMillis();
        long next=ReminderOrganizer.postponedUntil(r.whenMillis,now,choice);
        if(next<=now){Toast.makeText(this,"زمان جدید معتبر نیست",Toast.LENGTH_SHORT).show();return;}
        ReminderScheduler.cancelReminder(this,r);
        // A previously delivered notification must not be able to complete the new occurrence.
        for(String rule:AlertRules.split(r.offsetsMinutes)) {
            NexaStore.dismissToken(this,ReminderScheduler.occurrenceToken(r.id,rule,r.whenMillis));
        }
        r.whenMillis=next;
        r.active=true;
        r.done=false;
        NexaStore.updateReminder(this,r);
        LinkedReminderHelper.syncNextOccurrence(this,r);
        ReminderScheduler.scheduleReminder(this,r);
        NexaStore.addHistory(this,"یادآور","موعد جدید: "+r.title+" • "+PersianDateUtil.pretty(next));
        TodayNotificationManager.refresh(this);
        render();
    }

    private void togglePaused(NexaStore.Reminder r) {
        if(r.done)return;
        if(r.active){
            ReminderScheduler.cancelReminder(this,r);
            r.active=false;
            NexaStore.updateReminder(this,r);
            NexaStore.addHistory(this,"یادآور","موقتاً متوقف شد: "+r.title);
            ReminderScheduler.updateLockCard(this);
            TodayNotificationManager.refresh(this);
            render();
        }else if(r.whenMillis<=System.currentTimeMillis()){
            // Restoring an elapsed deadline without moving it would create no future alarm.
            showPostponeDialog(r);
        }else{
            r.active=true;
            NexaStore.updateReminder(this,r);
            ReminderScheduler.scheduleReminder(this,r);
            NexaStore.addHistory(this,"یادآور","دوباره فعال شد: "+r.title);
            TodayNotificationManager.refresh(this);
            render();
        }
    }

    private void markDone(NexaStore.Reminder r) {
        if(r.done){
            if(r.whenMillis<=System.currentTimeMillis()){
                showPostponeDialog(r);
                return;
            }
            r.done=false;
            r.active=true;
            NexaStore.updateReminder(this,r);
            ReminderScheduler.scheduleReminder(this,r);
            NexaStore.addHistory(this,"یادآور","بازگشایی شد: "+r.title);
        }else{
            ReminderScheduler.cancelReminder(this,r);
            ReminderRecurrence.recordCompleted(r);
            if(ReminderRecurrence.advanceAfterDone(r,System.currentTimeMillis())){
                NexaStore.updateReminder(this,r);
                LinkedReminderHelper.syncNextOccurrence(this,r);
                ReminderScheduler.scheduleReminder(this,r);
                NexaStore.addHistory(this,"یادآور","انجام شد؛ نوبت بعد تنظیم شد: "+r.title);
            }else{
                r.done=true;
                r.active=false;
                NexaStore.updateReminder(this,r);
                NexaStore.addHistory(this,"یادآور","انجام شد: "+r.title);
            }
        }
        ReminderScheduler.updateLockCard(this);
        TodayNotificationManager.refresh(this);
        render();
    }

    private void copyReminder(NexaStore.Reminder r) {
        NexaStore.Reminder n=new NexaStore.Reminder();
        n.title=r.title+" (کپی)";
        n.category=r.category;
        n.icon=r.icon;
        n.note=r.note;
        n.whenMillis=ReminderOrganizer.copiedDue(r.whenMillis,System.currentTimeMillis());
        n.offsetsMinutes=r.offsetsMinutes;
        n.repeatMinutes=r.repeatMinutes;
        n.customSoundUri=r.customSoundUri;
        n.doctorName=r.doctorName;
        n.doctorFileNumber=r.doctorFileNumber;
        n.doctorCenter=r.doctorCenter;
        n.doctorPhone=r.doctorPhone;
        n.doctorAddress=r.doctorAddress;
        n.recurrence=r.recurrence;
        NexaStore.addReminder(this,n);
        ReminderScheduler.scheduleReminder(this,n);
        NexaStore.addHistory(this,"یادآور","کپی شد: "+n.title);
        TodayNotificationManager.refresh(this);
        render();
    }
}
