package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import android.widget.CheckBox;

public class RemindersActivity extends Activity {
    private LinearLayout list;
    private TextView summary, results, selectionSummary;
    private LinearLayout selectionToolbar;
    private final Set<String> selectedIds = new HashSet<>();
    private boolean selectionMode = false;
    private static final int CREATE_ICALENDAR = 742;
    private static final int OPEN_ICALENDAR = 743;
    private String pendingImportUri;
    private final Set<String> pendingImportExcluded=new HashSet<>();
    private boolean pendingImportNotes=false;
    private final Set<String> pendingCalendarIds = new HashSet<>();
    private boolean pendingCalendarDetails = false;
    private String filter = "all", order = "smart", searchText = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        if (b != null) {
            filter=b.getString("filter","all");
            order=b.getString("order","smart");
            searchText=b.getString("search","");
            selectionMode=b.getBoolean("selectionMode",false);
            ArrayList<String> saved=b.getStringArrayList("selectedIds");
            if(saved!=null)selectedIds.addAll(saved);
            ArrayList<String> pending=b.getStringArrayList("pendingCalendarIds");
            if(pending!=null)pendingCalendarIds.addAll(pending);
            pendingCalendarDetails=b.getBoolean("pendingCalendarDetails",false);
            pendingImportUri=b.getString("pendingImportUri");
            pendingImportNotes=b.getBoolean("pendingImportNotes",false);
            ArrayList<String> excluded=b.getStringArrayList("pendingImportExcluded");
            if(excluded!=null)pendingImportExcluded.addAll(excluded);
        }
        build();
        // Re-open preview on configuration recreation without saving file contents in Bundle.
        if(pendingImportUri!=null){
            String uri=pendingImportUri;
            getWindow().getDecorView().post(()->previewCalendarImport(Uri.parse(uri)));
        }
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putString("filter",filter);
        out.putString("order",order);
        out.putString("search",searchText);
        out.putBoolean("selectionMode",selectionMode);
        out.putStringArrayList("selectedIds",new ArrayList<>(selectedIds));
        out.putStringArrayList("pendingCalendarIds",new ArrayList<>(pendingCalendarIds));
        out.putBoolean("pendingCalendarDetails",pendingCalendarDetails);
        out.putString("pendingImportUri",pendingImportUri);
        out.putBoolean("pendingImportNotes",pendingImportNotes);
        out.putStringArrayList("pendingImportExcluded",new ArrayList<>(pendingImportExcluded));
        super.onSaveInstanceState(out);
    }
    @Override protected void onResume() { super.onResume();render(); }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);
        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        head.addView(back);
        TextView title=UiKit.title(this,"یادآورها");
        LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0,-2,1f);
        titleParams.setMargins(UiKit.dp(this,12),0,0,0);
        head.addView(title,titleParams);
        root.addView(head,UiKit.matchWrap(this,0,16));

        LinearLayout hero=UiKit.featureHero(this,"reminder","یادآور هوشمند",
                "تقویم شمسی • هشدار چندمرحله‌ای • مدیریت سریع");
        Button add=UiKit.primaryButton(this,"＋ یادآور جدید");
        add.setOnClickListener(v->startActivity(new Intent(this,ReminderEditActivity.class)));
        hero.addView(add);
        root.addView(hero,UiKit.matchWrap(this,0,14));
        summary=UiKit.muted(this,"");
        summary.setGravity(Gravity.CENTER);
        root.addView(summary,UiKit.matchWrap(this,0,10));

        LinearLayout shortcuts=new LinearLayout(this);
        Button today=UiKit.secondaryButton(this,"امروز");
        today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        shortcuts.addView(today,new LinearLayout.LayoutParams(0,-2,1f));
        Button searchPage=UiKit.secondaryButton(this,"جستجوی سراسری");
        searchPage.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        LinearLayout.LayoutParams searchParams=new LinearLayout.LayoutParams(0,-2,1f);
        searchParams.setMargins(UiKit.dp(this,6),0,0,0);
        shortcuts.addView(searchPage,searchParams);
        root.addView(shortcuts,UiKit.matchWrap(this,0,6));

        LinearLayout more=new LinearLayout(this);
        Button timeline=UiKit.secondaryButton(this,"خط زمانی");
        timeline.setOnClickListener(v->startActivity(new Intent(this,TimelineActivity.class)));
        more.addView(timeline,new LinearLayout.LayoutParams(0,-2,1f));
        Button quick=UiKit.secondaryButton(this,"＋ افزودن سریع");
        quick.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        LinearLayout.LayoutParams quickParams=new LinearLayout.LayoutParams(0,-2,1f);
        quickParams.setMargins(UiKit.dp(this,6),0,0,0);
        more.addView(quick,quickParams);
        root.addView(more,UiKit.matchWrap(this,0,10));
        Button calendar=UiKit.secondaryButton(this,"📅 خروجی تقویم از نتایج فیلتر (ICS)");
        calendar.setOnClickListener(v->confirmCalendarExport(false));
        root.addView(calendar,UiKit.matchWrap(this,0,5));
        Button importCalendar=UiKit.secondaryButton(this,"📥 ورود فایل تقویم به یادآورها (ICS)");
        importCalendar.setOnClickListener(v->chooseCalendarImport());
        root.addView(importCalendar,UiKit.matchWrap(this,0,9));

        root.addView(UiKit.sectionTitle(this,"🔎 پیدا کردن و مرتب‌سازی"),UiKit.matchWrap(this,12,5));
        EditText find=UiKit.styleField(this,new EditText(this),"جستجو در عنوان، دسته، توضیح یا پزشک");
        find.setSingleLine(true);
        find.setText(searchText);
        find.setSelection(find.length());
        find.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int st,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                searchText=s.toString();render();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        root.addView(find,UiKit.matchWrap(this,0,7));
        Spinner ordering=UiKit.styledSpinner(this);
        String[] labels={"اولویت هوشمند (معوق اول)","موعد نزدیک‌تر", "موعد دورتر", "ترتیب عنوان"};
        String[] values={"smart","due","recent","title"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ordering.setAdapter(adapter);
        for(int i=0;i<values.length;i++)if(values[i].equals(order))ordering.setSelection(i);
        ordering.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id) {
                order=values[pos];render();
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        root.addView(ordering,UiKit.matchWrap(this,0,8));

        LinearLayout filters=new LinearLayout(this);
        filters.setOrientation(LinearLayout.VERTICAL);
        LinearLayout first=new LinearLayout(this),second=new LinearLayout(this);
        addFilter(first,"همه","all");
        addFilter(first,"در انتظار","pending");
        addFilter(first,"معوق","overdue");
        addFilter(second,"توقف‌شده","paused");
        addFilter(second,"انجام‌شده","done");
        addFilter(second,"۷ روز آینده","week");
        filters.addView(first);
        filters.addView(second,UiKit.matchWrap(this,4,0));
        root.addView(filters,UiKit.matchWrap(this,0,8));
        Button selectMode=UiKit.secondaryButton(this,"☑ مدیریت گروهی یادآورها");
        selectMode.setOnClickListener(v->{
            selectionMode=!selectionMode;
            if(!selectionMode)selectedIds.clear();
            render();
        });
        root.addView(selectMode,UiKit.matchWrap(this,3,6));
        selectionToolbar=new LinearLayout(this);
        selectionToolbar.setOrientation(LinearLayout.VERTICAL);
        selectionSummary=UiKit.muted(this,"");
        selectionToolbar.addView(selectionSummary,UiKit.matchWrap(this,0,5));
        LinearLayout selectorRow=new LinearLayout(this);
        Button selectVisible=UiKit.secondaryButton(this,"انتخاب تمام نتایج");
        selectVisible.setOnClickListener(v->selectVisible());
        selectorRow.addView(selectVisible,new LinearLayout.LayoutParams(0,-2,1f));
        Button clear=UiKit.secondaryButton(this,"لغو انتخاب‌ها");
        clear.setOnClickListener(v->{selectedIds.clear();render();});
        LinearLayout.LayoutParams clearParams=new LinearLayout.LayoutParams(0,-2,1f);
        clearParams.setMargins(UiKit.dp(this,6),0,0,0);
        selectorRow.addView(clear,clearParams);
        selectionToolbar.addView(selectorRow,UiKit.matchWrap(this,0,5));
        Button pause=UiKit.secondaryButton(this,"⏸ توقف گروهی");
        pause.setOnClickListener(v->confirmBatch(ReminderBatchManager.PAUSE));
        selectionToolbar.addView(pause,UiKit.matchWrap(this,0,4));
        Button resume=UiKit.secondaryButton(this,"▶ فعال‌سازی گروهی");
        resume.setOnClickListener(v->confirmBatch(ReminderBatchManager.RESUME));
        selectionToolbar.addView(resume,UiKit.matchWrap(this,0,4));
        Button doneBatch=UiKit.secondaryButton(this,"✓ ثبت انجام‌شدن گروهی");
        doneBatch.setOnClickListener(v->confirmBatch(ReminderBatchManager.DONE));
        selectionToolbar.addView(doneBatch,UiKit.matchWrap(this,0,4));
        Button calendarSelection=UiKit.secondaryButton(this,"📅 خروجی تقویم از موارد انتخاب‌شده");
        calendarSelection.setOnClickListener(v->confirmCalendarExport(true));
        selectionToolbar.addView(calendarSelection,UiKit.matchWrap(this,0,4));
        selectionToolbar.addView(UiKit.muted(this,
            "فعال‌سازی فقط برای موعدهای آینده انجام می‌شود. برای موعد گذشته ابتدا زمان جدید تعیین کنید. حذف گروهی عمداً غیرفعال است."),
            UiKit.matchWrap(this,3,6));
        root.addView(selectionToolbar,UiKit.matchWrap(this,0,6));
        results=UiKit.muted(this,"");
        root.addView(results,UiKit.matchWrap(this,0,8));
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(sc);
        render();
    }

    private void addFilter(LinearLayout row,String title,String value) {
        Button b=UiKit.secondaryButton(this,title);
        b.setOnClickListener(v->{filter=value;render();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
        row.addView(b,lp);
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.Reminder> all=NexaStore.reminders(this);
        Set<String> allIds=new HashSet<>();
        for(NexaStore.Reminder saved:all)allIds.add(saved.id);
        selectedIds.retainAll(allIds);
        selectionToolbar.setVisibility(selectionMode?View.VISIBLE:View.GONE);
        selectionSummary.setText("☑ "+selectedIds.size()+" یادآور انتخاب‌شده — عملیات فقط روی موارد انتخابی انجام می‌شود.");
        long now=System.currentTimeMillis();
        int pending=0,overdue=0,paused=0,completed=0,recurring=0;
        NexaStore.Reminder next=null;
        for(NexaStore.Reminder r:all){
            if(r.done)completed++;
            else if(!r.active)paused++;
            else if(r.whenMillis<now)overdue++;
            else pending++;
            if(!r.done&&r.active&&ReminderRecurrence.isRecurring(r.recurrence))recurring++;
            if(!r.done&&r.active&&r.whenMillis>=now&&
                    (next==null||r.whenMillis<next.whenMillis))next=r;
        }
        String nextText=next==null?"":"\n⏭ نزدیک‌ترین: "+next.title+" • "+PersianDateUtil.pretty(next.whenMillis);
        summary.setText("🟢 "+pending+" در انتظار   •   🔴 "+overdue+" معوق"
                +"   •   ⏸ "+paused+" متوقف   •   ✅ "+completed+" انجام‌شده"
                +"   •   🔁 "+recurring+" تکرارشونده"+nextText);
        int shown=0;
        for(NexaStore.Reminder r:ReminderOrganizer.ordered(all,order,now)){
            if(!ReminderOrganizer.visible(r,filter,now)||!ReminderOrganizer.matches(r,searchText))continue;
            shown++;
            addReminderCard(r,now);
        }
        results.setText("نتایج فیلتر و جستجو: "+shown+" مورد از "+all.size()
                +(selectionMode?" • "+selectedIds.size()+" انتخاب‌شده":""));
        if(shown==0){
            TextView empty=UiKit.muted(this,all.isEmpty()?"هنوز یادآوری ثبت نشده.":"موردی مطابق جستجو یا فیلتر یافت نشد.");
            empty.setGravity(Gravity.CENTER);
            list.addView(empty,UiKit.matchWrap(this,20,0));
        }
    }

    private void addReminderCard(NexaStore.Reminder r,long now) {
        LinearLayout card=UiKit.colorfulCardLayout(this,Math.abs(r.category.hashCode())%4);
        if(selectionMode){
            CheckBox check=new CheckBox(this);
            check.setText("انتخاب برای عملیات گروهی");
            check.setChecked(selectedIds.contains(r.id));
            check.setOnCheckedChangeListener((button,checked)->{
                if(checked)selectedIds.add(r.id);
                else selectedIds.remove(r.id);
                selectionSummary.setText("☑ "+selectedIds.size()+" یادآور انتخاب‌شده — عملیات فقط روی موارد انتخابی انجام می‌شود.");
            });
            card.addView(check,UiKit.matchWrap(this,0,4));
        }
        card.addView(UiKit.sectionTitle(this,r.icon+"  "+r.title));
        card.addView(UiKit.muted(this,r.category+" • "+PersianDateUtil.pretty(r.whenMillis)
                +ReminderRecurrence.labelSuffix(r.recurrence)),UiKit.matchWrap(this,6,3));
        if(!r.doctorName.isEmpty())card.addView(UiKit.muted(this,"🩺 پزشک: "+r.doctorName),UiKit.matchWrap(this,4,0));
        if(!r.doctorFileNumber.isEmpty())card.addView(UiKit.muted(this,"شماره پرونده: "+r.doctorFileNumber),UiKit.matchWrap(this,3,0));
        if(!r.doctorCenter.isEmpty())card.addView(UiKit.muted(this,"مرکز: "+r.doctorCenter),UiKit.matchWrap(this,3,0));
        if(!r.doctorPhone.isEmpty())card.addView(UiKit.muted(this,"تماس: "+r.doctorPhone),UiKit.matchWrap(this,3,0));
        if(!r.doctorAddress.isEmpty())card.addView(UiKit.muted(this,"آدرس: "+r.doctorAddress),UiKit.matchWrap(this,3,0));
        if(!r.note.isEmpty())card.addView(UiKit.muted(this,r.note),UiKit.matchWrap(this,4,0));
        if(!ReminderSoundSelection.normalize(r.customSoundUri).isEmpty())
            card.addView(UiKit.muted(this,"🎵 "+ReminderSoundSelection.displayName(this,r.customSoundUri)),
                    UiKit.matchWrap(this,3,0));
        String status=r.done?"✅ انجام‌شده":!r.active?"⏸ متوقف":
                r.whenMillis<now?"🔴 معوق":"🟢 در انتظار";
        card.addView(UiKit.muted(this,status),UiKit.matchWrap(this,4,3));

        // Safe quick operations do not require opening the editor or changing recurrence rules.
        LinearLayout actions=new LinearLayout(this);
        Button done=UiKit.secondaryButton(this,r.done?"↶ بازگشایی":"✓ انجام شد");
        done.setOnClickListener(v->markDone(r));
        actions.addView(done,new LinearLayout.LayoutParams(0,-2,1f));
        if(!r.done){
            Button toggle=UiKit.secondaryButton(this,r.active?"⏸ توقف":"▶ فعال‌سازی");
            toggle.setOnClickListener(v->togglePaused(r));
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1f);
            bp.setMargins(UiKit.dp(this,6),0,0,0);
            actions.addView(toggle,bp);
        }
        card.addView(actions,UiKit.matchWrap(this,5,4));
        if(!r.done){
            Button postpone=UiKit.secondaryButton(this,"⏰ تغییر سریع موعد (۱۵ دقیقه / ۱ ساعت / فردا)");
            postpone.setOnClickListener(v->showPostponeDialog(r));
            card.addView(postpone,UiKit.matchWrap(this,0,4));
        }

        LinearLayout row=new LinearLayout(this);
        Button edit=UiKit.editIconButton(this);
        edit.setOnClickListener(v->openEditor(r.id));
        row.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        Button copy=UiKit.secondaryButton(this,"کپی");
        copy.setOnClickListener(v->copyReminder(r));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1f));
        Button del=UiKit.deleteIconButton(this);
        del.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("حذف یادآور؟").setMessage(r.title)
                .setPositiveButton("حذف",(d,w)->{
                    ReminderScheduler.cancelReminder(this,r);
                    NexaStore.removeReminder(this,r.id);
                    NexaStore.addHistory(this,"یادآور","حذف شد: "+r.title);
                    ReminderScheduler.updateLockCard(this);
                    TodayNotificationManager.refresh(this);
                    render();
                }).setNegativeButton("انصراف",null).show());
        LinearLayout.LayoutParams deleteParams=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        deleteParams.setMargins(UiKit.dp(this,5),0,0,0);
        row.addView(del,deleteParams);
        card.addView(row,UiKit.matchWrap(this,10,0));
        list.addView(card,UiKit.matchWrap(this,0,12));
    }

    /** Export doesn't modify Nexa reminders or require calendar/storage permission. */
    private void confirmCalendarExport(boolean selectedOnly) {
        long now=System.currentTimeMillis();
        List<NexaStore.Reminder> current=NexaStore.reminders(this);
        Set<String> ids=new HashSet<>();
        if(selectedOnly){
            if(!selectionMode || selectedIds.isEmpty()){
                Toast.makeText(this,"ابتدا یادآورها را انتخاب کنید",Toast.LENGTH_SHORT).show();
                return;
            }
            ids.addAll(selectedIds);
        }else{
            for(NexaStore.Reminder r:current){
                if(ReminderOrganizer.visible(r,filter,now) && ReminderOrganizer.matches(r,searchText))
                    ids.add(r.id);
            }
        }
        List<NexaStore.Reminder> exportable=ReminderCalendarExporter.pick(current,ids,now);
        if(exportable.isEmpty()){
            Toast.makeText(this,"یادآور فعال با موعد آینده برای خروجی وجود ندارد",Toast.LENGTH_LONG).show();
            return;
        }
        boolean special=false;
        for(NexaStore.Reminder r:exportable)if(ReminderCalendarExporter.hasUnportableAlerts(r))special=true;
        final CheckBox includeDetails=new CheckBox(this);
        includeDetails.setText("افزودن توضیحات و دسته‌بندی به فایل (اختیاری)");
        includeDetails.setChecked(false);
        String description="خروجی "+exportable.size()+" یادآور فعال و آینده از "+ids.size()+" مورد."
                +"\nیادآورهای متوقف، انجام‌شده و دارای موعد گذشته منتقل نمی‌شوند."
                +"\nصداهای سفارشی، اطلاعات پزشک و تنظیمات داخلی Nexa منتقل نمی‌شوند."
                +"\nزمان تکرارها براساس ساعت محلی گوشی ثبت می‌شود؛ در تقویم مقصد مستقل خواهند بود."
                +"\nدر صورت واردکردن فایل به تقویم گوشی، ممکن است اعلان‌های تقویم در کنار هشدارهای Nexa نمایش داده شوند."
                +(special?"\n⚠ هشدارهای ویژه با روز/ساعت اختصاصی در تقویم استاندارد قابل انتقال دقیق نیستند.":"");
        LinearLayout content=new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);
        TextView text=UiKit.muted(this,description);
        content.addView(text);
        content.addView(includeDetails);
        new AlertDialog.Builder(this).setTitle("دریافت فایل تقویم (ICS)")
                .setView(content).setNegativeButton("انصراف",null)
                .setPositiveButton("انتخاب محل ذخیره",(d,w)->{
                    pendingCalendarIds.clear();
                    for(NexaStore.Reminder r:exportable)pendingCalendarIds.add(r.id);
                    pendingCalendarDetails=includeDetails.isChecked();
                    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.setType("text/calendar");
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_TITLE,"Nexa_Reminders.ics");
                    try { startActivityForResult(intent,CREATE_ICALENDAR); }
                    catch(android.content.ActivityNotFoundException e){
                        pendingCalendarIds.clear();
                        Toast.makeText(this,"برنامه‌ای برای ذخیره فایل یافت نشد",Toast.LENGTH_LONG).show();
                    }
                }).show();
    }

    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);
        if(request==OPEN_ICALENDAR){
            if(result==RESULT_OK && data!=null && data.getData()!=null)
                previewCalendarImport(data.getData());
            return;
        }
        if(request!=CREATE_ICALENDAR)return;
        try {
            if(result!=RESULT_OK || data==null || data.getData()==null)return;
            Uri document=data.getData();
            List<NexaStore.Reminder> ready=ReminderCalendarExporter.pick(
                    NexaStore.reminders(this),pendingCalendarIds,System.currentTimeMillis());
            if(ready.isEmpty()){
                Toast.makeText(this,"موعدها تغییر کرده‌اند؛ خروجی ساخته نشد",Toast.LENGTH_LONG).show();
                return;
            }
            String ics=ReminderCalendarExporter.create(ready,pendingCalendarDetails,System.currentTimeMillis());
            try(OutputStream output=getContentResolver().openOutputStream(document,"w")){
                if(output==null)throw new java.io.IOException("Cannot open calendar document");
                output.write(ics.getBytes(StandardCharsets.UTF_8));
                output.flush();
            }
            Toast.makeText(this,"فایل تقویم "+ready.size()+" یادآور ذخیره شد",Toast.LENGTH_LONG).show();
        } catch(Exception e){
            Toast.makeText(this,"ذخیره خروجی تقویم ناموفق بود",Toast.LENGTH_LONG).show();
        } finally {
            pendingCalendarIds.clear();
            pendingCalendarDetails=false;
        }
    }

    /** SAF grants access to one user-chosen document, not to the whole storage. */
    private void chooseCalendarImport() {
        pendingImportExcluded.clear();
        pendingImportNotes=false;
        Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        try {startActivityForResult(intent,OPEN_ICALENDAR);}
        catch(android.content.ActivityNotFoundException e){
            Toast.makeText(this,"برنامه‌ای برای انتخاب فایل یافت نشد",Toast.LENGTH_LONG).show();
        }
    }

    private static String readCalendarDocument(java.io.InputStream stream) throws java.io.IOException {
        if(stream==null)throw new java.io.IOException("Unable to open calendar");
        java.io.ByteArrayOutputStream bytes=new java.io.ByteArrayOutputStream();
        byte[] block=new byte[8192];int read;
        while((read=stream.read(block))!=-1){
            if(bytes.size()+read>ReminderCalendarImporter.MAX_BYTES)
                throw new java.io.IOException("Calendar too large");
            bytes.write(block,0,read);
        }
        try {
            return StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                    .onUnmappableCharacter(java.nio.charset.CodingErrorAction.REPORT)
                    .decode(java.nio.ByteBuffer.wrap(bytes.toByteArray())).toString();
        }catch(java.nio.charset.CharacterCodingException e){
            throw new java.io.IOException("Invalid UTF-8 calendar",e);
        }
    }

    private void previewCalendarImport(Uri uri) {
        if(uri==null)return;
        pendingImportUri=uri.toString();
        ReminderCalendarImporter.Preview parsed;
        try(java.io.InputStream input=getContentResolver().openInputStream(uri)){
            parsed=ReminderCalendarImporter.inspect(
                    readCalendarDocument(input),System.currentTimeMillis(),NexaStore.reminders(this));
        }catch(Exception e){
            pendingImportUri=null;
            new AlertDialog.Builder(this).setTitle("خواندن فایل انجام نشد")
                    .setMessage("فایل انتخاب‌شده قابل‌خواندن نیست، UTF-8 نیست یا از محدودیت یک مگابایت بزرگ‌تر است.")
                    .setPositiveButton("متوجه شدم",null).show();
            return;
        }
        if(!parsed.valid()){
            pendingImportUri=null;
            new AlertDialog.Builder(this).setTitle("فایل ICS پشتیبانی نمی‌شود")
                    .setMessage(parsed.error).setPositiveButton("بستن",null).show();
            return;
        }
        int count=parsed.candidates.size();
        String intro="رویدادهای فایل: "+parsed.total+" • قابل ورود: "+count
                +"\nتکراری: "+parsed.duplicates+" • قدیمی: "+parsed.past
                +" • لغوشده: "+parsed.cancelled+" • ناسازگار: "+parsed.unsupported
                +"\nرویدادهای تمام‌روز، استثناهای تکرار و الگوهای غیرقابل‌انتقال وارد نمی‌شوند."
                +"\nیادآورهای جدید هنگام رسیدن موعد در Nexa هشدار می‌دهند؛ اگر هشدار سازگار نداشته باشند، هشدار در زمان موعد فعال می‌شود."
                +"\nدر ورود دوباره همان فایل، رویدادهای قبلی دوباره ثبت نمی‌شوند."
                +(parsed.alarmsDropped>0?"\n⚠ "+parsed.alarmsDropped+" مورد هشدار غیرقابل‌انتقال داشتند.":"");
        LinearLayout panel=new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        panel.setPadding(UiKit.dp(this,18),UiKit.dp(this,10),UiKit.dp(this,18),UiKit.dp(this,10));
        panel.addView(UiKit.muted(this,intro),UiKit.matchWrap(this,0,10));
        CheckBox notes=new CheckBox(this);
        notes.setText("افزودن توضیحات فایل به یادآورها (اختیاری؛ ممکن است اطلاعات خصوصی داشته باشد)");
        notes.setChecked(pendingImportNotes);
        notes.setOnCheckedChangeListener((button,checked)->pendingImportNotes=checked);
        panel.addView(notes,UiKit.matchWrap(this,0,8));
        final boolean[] chosen=new boolean[count];
        if(count>0){
            TextView header=UiKit.sectionTitle(this,"انتخاب رویدادها برای ورود");
            panel.addView(header,UiKit.matchWrap(this,0,6));
            for(int i=0;i<count;i++){
                final int index=i;
                NexaStore.Reminder r=parsed.candidates.get(i).reminder;
                chosen[i]=!pendingImportExcluded.contains(parsed.candidates.get(i).reminder.sourceKey);
                CheckBox event=new CheckBox(this);
                event.setText(r.title+"\n"+PersianDateUtil.pretty(r.whenMillis)
                        +ReminderRecurrence.labelSuffix(r.recurrence));
                event.setChecked(chosen[i]);
                event.setOnCheckedChangeListener((button,checked)->{
                    chosen[index]=checked;
                    String key=parsed.candidates.get(index).reminder.sourceKey;
                    if(checked)pendingImportExcluded.remove(key);
                    else pendingImportExcluded.add(key);
                });
                panel.addView(event,UiKit.matchWrap(this,0,5));
            }
        }
        ScrollView scroll=new ScrollView(this);
        scroll.addView(panel);
        AlertDialog.Builder dialog=new AlertDialog.Builder(this)
                .setTitle("پیش‌نمایش ورود تقویم (ICS)")
                .setView(scroll)
                .setNegativeButton("انصراف",(d,w)->pendingImportUri=null);
        if(count>0)dialog.setPositiveButton("ورود موارد انتخاب‌شده",(d,w)->{
            pendingImportUri=null;
            List<NexaStore.Reminder> all=NexaStore.reminders(this);
            List<NexaStore.Reminder> newItems=ReminderCalendarImporter.choose(parsed,chosen,
                    all,System.currentTimeMillis(),notes.isChecked());
            if(newItems.isEmpty()){
                Toast.makeText(this,"مورد تازه‌ای برای ورود وجود ندارد",Toast.LENGTH_LONG).show();
                return;
            }
            all.addAll(newItems);
            NexaStore.saveReminders(this,all);
            ReminderScheduler.scheduleImportedBatch(this,newItems);
            TodayNotificationManager.refresh(this);
            NexaStore.addHistory(this,"یادآور","ورود "+newItems.size()+" رویداد تقویم از فایل ICS");
            Toast.makeText(this,newItems.size()+" یادآور به Nexa افزوده شد",Toast.LENGTH_LONG).show();
            render();
        });
        else dialog.setPositiveButton("بستن",(d,w)->pendingImportUri=null);
        AlertDialog shown=dialog.create();
        shown.setOnCancelListener(d->pendingImportUri=null);
        shown.show();
    }

    private void selectVisible(){
        if(!selectionMode)return;
        long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:NexaStore.reminders(this)) {
            if(ReminderOrganizer.visible(r,filter,now) && ReminderOrganizer.matches(r,searchText))
                selectedIds.add(r.id);
        }
        render();
    }

    private void confirmBatch(String action){
        if(!selectionMode || selectedIds.isEmpty()){
            Toast.makeText(this,"ابتدا چند یادآور انتخاب کنید",Toast.LENGTH_SHORT).show();
            return;
        }
        int eligible=0;
        long now=System.currentTimeMillis();
        for(NexaStore.Reminder r:NexaStore.reminders(this)){
            if(selectedIds.contains(r.id) && ReminderBatchManager.eligible(r,action,now))eligible++;
        }
        if(eligible==0){
            Toast.makeText(this,"هیچ یادآور قابل اعمالی وجود ندارد؛ موعد گذشته را ابتدا تغییر دهید",Toast.LENGTH_LONG).show();
            return;
        }
        String label=ReminderBatchManager.PAUSE.equals(action)?"توقف":
                ReminderBatchManager.RESUME.equals(action)?"فعال‌سازی":"انجام‌شدن";
        int ignored=selectedIds.size()-eligible;
        String message="تعداد "+eligible+" یادآور با عمل «"+label+"» تغییر می‌کنند."
                +(ignored>0?"\n"+ignored+" مورد نامعتبر یا دارای موعد گذشته بدون تغییر می‌مانند.":"")
                +(ReminderBatchManager.DONE.equals(action)?
                "\nبرای یادآور تکرارشونده، نوبت بعدی به‌طور خودکار تنظیم می‌شود.":"");
        new AlertDialog.Builder(this)
                .setTitle("تأیید "+label+" گروهی")
                .setMessage(message)
                .setNegativeButton("انصراف",null)
                .setPositiveButton("تأیید",(dialog,which)->applyBatch(action))
                .show();
    }

    private void applyBatch(String action){
        long now=System.currentTimeMillis();
        List<NexaStore.Reminder> current=NexaStore.reminders(this);
        List<NexaStore.Reminder> toSchedule=new ArrayList<>();
        int changed=0;
        for(NexaStore.Reminder r:current){
            if(!selectedIds.contains(r.id) || !ReminderBatchManager.eligible(r,action,now))continue;
            ReminderScheduler.cancelReminder(this,r);
            if(ReminderBatchManager.apply(r,action,now)){
                changed++;
                if(r.active && !r.done)toSchedule.add(r);
            }
        }
        if(changed==0){
            Toast.makeText(this,"وضعیت یادآورها تغییر نکرد",Toast.LENGTH_SHORT).show();
            render();
            return;
        }
        // Single persistence operation: avoid one store rewrite per selected item.
        NexaStore.saveReminders(this,current);
        for(NexaStore.Reminder r:toSchedule)ReminderScheduler.scheduleReminder(this,r);
        String label=ReminderBatchManager.PAUSE.equals(action)?"توقف":
                ReminderBatchManager.RESUME.equals(action)?"فعال‌سازی":"انجام‌شدن";
        NexaStore.addHistory(this,"یادآور","عملیات گروهی "+label+": "+changed+" مورد");
        ReminderScheduler.updateLockCard(this);
        TodayNotificationManager.refresh(this);
        selectedIds.clear();
        selectionMode=false;
        Toast.makeText(this,changed+" یادآور به‌روزرسانی شد",Toast.LENGTH_LONG).show();
        render();
    }

    private void openEditor(String id){
        Intent intent=new Intent(this,ReminderEditActivity.class);
        intent.putExtra("edit_id",id);
        startActivity(intent);
    }

    private void showPostponeDialog(NexaStore.Reminder r) {
        String title=ReminderRecurrence.isRecurring(r.recurrence)
                ?"تغییر موعد؛ تکرارهای بعدی نیز از موعد جدید محاسبه می‌شوند"
                :"موعد جدید «"+r.title+"»";
        new AlertDialog.Builder(this).setTitle(title)
                .setItems(new String[]{"۱۵ دقیقه دیگر","۱ ساعت دیگر","فردا در ساعت قبلی","انتخاب تاریخ و ساعت"},
                        (dialog,which)->{
                            if(which==3)openEditor(r.id);
                            else postpone(r,which);
                        })
                .setNegativeButton("انصراف",null).show();
    }

    private void postpone(NexaStore.Reminder r,int choice) {
        long now=System.currentTimeMillis();
        long next=ReminderOrganizer.postponedUntil(r.whenMillis,now,choice);
        if(next<=now){Toast.makeText(this,"زمان جدید معتبر نیست",Toast.LENGTH_SHORT).show();return;}
        ReminderScheduler.cancelReminder(this,r);
        // A previously delivered notification must not be able to complete the new occurrence.
        for(String rule:AlertRules.split(r.offsetsMinutes)) {
            NexaStore.dismissToken(this,ReminderScheduler.occurrenceToken(r.id,rule,r.whenMillis));
        }
        r.whenMillis=next;
        r.active=true;
        r.done=false;
        NexaStore.updateReminder(this,r);
        ReminderScheduler.scheduleReminder(this,r);
        NexaStore.addHistory(this,"یادآور","موعد جدید: "+r.title+" • "+PersianDateUtil.pretty(next));
        TodayNotificationManager.refresh(this);
        render();
    }

    private void togglePaused(NexaStore.Reminder r) {
        if(r.done)return;
        if(r.active){
            ReminderScheduler.cancelReminder(this,r);
            r.active=false;
            NexaStore.updateReminder(this,r);
            NexaStore.addHistory(this,"یادآور","موقتاً متوقف شد: "+r.title);
            ReminderScheduler.updateLockCard(this);
            TodayNotificationManager.refresh(this);
            render();
        }else if(r.whenMillis<=System.currentTimeMillis()){
            // Restoring an elapsed deadline without moving it would create no future alarm.
            showPostponeDialog(r);
        }else{
            r.active=true;
            NexaStore.updateReminder(this,r);
            ReminderScheduler.scheduleReminder(this,r);
            NexaStore.addHistory(this,"یادآور","دوباره فعال شد: "+r.title);
            TodayNotificationManager.refresh(this);
            render();
        }
    }

    private void markDone(NexaStore.Reminder r) {
        if(r.done){
            if(r.whenMillis<=System.currentTimeMillis()){
                showPostponeDialog(r);
                return;
            }
            r.done=false;
            r.active=true;
            NexaStore.updateReminder(this,r);
            ReminderScheduler.scheduleReminder(this,r);
            NexaStore.addHistory(this,"یادآور","بازگشایی شد: "+r.title);
        }else{
            ReminderScheduler.cancelReminder(this,r);
            if(ReminderRecurrence.advanceAfterDone(r,System.currentTimeMillis())){
                NexaStore.updateReminder(this,r);
                ReminderScheduler.scheduleReminder(this,r);
                NexaStore.addHistory(this,"یادآور","انجام شد؛ نوبت بعد تنظیم شد: "+r.title);
            }else{
                r.done=true;
                r.active=false;
                NexaStore.updateReminder(this,r);
                NexaStore.addHistory(this,"یادآور","انجام شد: "+r.title);
            }
        }
        ReminderScheduler.updateLockCard(this);
        TodayNotificationManager.refresh(this);
        render();
    }

    private void copyReminder(NexaStore.Reminder r) {
        NexaStore.Reminder n=new NexaStore.Reminder();
        n.title=r.title+" (کپی)";
        n.category=r.category;
        n.icon=r.icon;
        n.note=r.note;
        n.whenMillis=ReminderOrganizer.copiedDue(r.whenMillis,System.currentTimeMillis());
        n.offsetsMinutes=r.offsetsMinutes;
        n.repeatMinutes=r.repeatMinutes;
        n.customSoundUri=r.customSoundUri;
        n.doctorName=r.doctorName;
        n.doctorFileNumber=r.doctorFileNumber;
        n.doctorCenter=r.doctorCenter;
        n.doctorPhone=r.doctorPhone;
        n.doctorAddress=r.doctorAddress;
        n.recurrence=r.recurrence;
        NexaStore.addReminder(this,n);
        ReminderScheduler.scheduleReminder(this,n);
        NexaStore.addHistory(this,"یادآور","کپی شد: "+n.title);
        TodayNotificationManager.refresh(this);
        render();
    }
}
