package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class RemindersActivity extends Activity {
    private LinearLayout list;
    private TextView summary, results;
    private String filter = "all", order = "smart", searchText = "";

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        if (b != null) {
            filter=b.getString("filter","all");
            order=b.getString("order","smart");
            searchText=b.getString("search","");
        }
        build();
    }
    @Override protected void onSaveInstanceState(Bundle out) {
        out.putString("filter",filter);
        out.putString("order",order);
        out.putString("search",searchText);
        super.onSaveInstanceState(out);
    }
    @Override protected void onResume() { super.onResume();render(); }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);
        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        head.addView(back);
        TextView title=UiKit.title(this,"یادآورها");
        LinearLayout.LayoutParams titleParams=new LinearLayout.LayoutParams(0,-2,1f);
        titleParams.setMargins(UiKit.dp(this,12),0,0,0);
        head.addView(title,titleParams);
        root.addView(head,UiKit.matchWrap(this,0,16));

        LinearLayout hero=UiKit.featureHero(this,"reminder","یادآور هوشمند",
                "تقویم شمسی • هشدار چندمرحله‌ای • مدیریت سریع");
        Button add=UiKit.primaryButton(this,"＋ یادآور جدید");
        add.setOnClickListener(v->startActivity(new Intent(this,ReminderEditActivity.class)));
        hero.addView(add);
        root.addView(hero,UiKit.matchWrap(this,0,14));
        summary=UiKit.muted(this,"");
        summary.setGravity(Gravity.CENTER);
        root.addView(summary,UiKit.matchWrap(this,0,10));

        LinearLayout shortcuts=new LinearLayout(this);
        Button today=UiKit.secondaryButton(this,"امروز");
        today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));
        shortcuts.addView(today,new LinearLayout.LayoutParams(0,-2,1f));
        Button searchPage=UiKit.secondaryButton(this,"جستجوی سراسری");
        searchPage.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));
        LinearLayout.LayoutParams searchParams=new LinearLayout.LayoutParams(0,-2,1f);
        searchParams.setMargins(UiKit.dp(this,6),0,0,0);
        shortcuts.addView(searchPage,searchParams);
        root.addView(shortcuts,UiKit.matchWrap(this,0,6));

        LinearLayout more=new LinearLayout(this);
        Button timeline=UiKit.secondaryButton(this,"خط زمانی");
        timeline.setOnClickListener(v->startActivity(new Intent(this,TimelineActivity.class)));
        more.addView(timeline,new LinearLayout.LayoutParams(0,-2,1f));
        Button quick=UiKit.secondaryButton(this,"＋ افزودن سریع");
        quick.setOnClickListener(v->startActivity(new Intent(this,QuickAddActivity.class)));
        LinearLayout.LayoutParams quickParams=new LinearLayout.LayoutParams(0,-2,1f);
        quickParams.setMargins(UiKit.dp(this,6),0,0,0);
        more.addView(quick,quickParams);
        root.addView(more,UiKit.matchWrap(this,0,10));

        root.addView(UiKit.sectionTitle(this,"🔎 پیدا کردن و مرتب‌سازی"),UiKit.matchWrap(this,12,5));
        EditText find=UiKit.styleField(this,new EditText(this),"جستجو در عنوان، دسته، توضیح یا پزشک");
        find.setSingleLine(true);
        find.setText(searchText);
        find.setSelection(find.length());
        find.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int st,int count,int after) {}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count) {
                searchText=s.toString();render();
            }
            @Override public void afterTextChanged(Editable s) {}
        });
        root.addView(find,UiKit.matchWrap(this,0,7));
        Spinner ordering=UiKit.styledSpinner(this);
        String[] labels={"اولویت هوشمند (معوق اول)","موعد نزدیک‌تر", "موعد دورتر", "ترتیب عنوان"};
        String[] values={"smart","due","recent","title"};
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        ordering.setAdapter(adapter);
        for(int i=0;i<values.length;i++)if(values[i].equals(order))ordering.setSelection(i);
        ordering.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p,View v,int pos,long id) {
                order=values[pos];render();
            }
            @Override public void onNothingSelected(AdapterView<?> p) {}
        });
        root.addView(ordering,UiKit.matchWrap(this,0,8));

        LinearLayout filters=new LinearLayout(this);
        filters.setOrientation(LinearLayout.VERTICAL);
        LinearLayout first=new LinearLayout(this),second=new LinearLayout(this);
        addFilter(first,"همه","all");
        addFilter(first,"در انتظار","pending");
        addFilter(first,"معوق","overdue");
        addFilter(second,"توقف‌شده","paused");
        addFilter(second,"انجام‌شده","done");
        filters.addView(first);
        filters.addView(second,UiKit.matchWrap(this,4,0));
        root.addView(filters,UiKit.matchWrap(this,0,8));
        results=UiKit.muted(this,"");
        root.addView(results,UiKit.matchWrap(this,0,8));
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(sc);
        render();
    }

    private void addFilter(LinearLayout row,String title,String value) {
        Button b=UiKit.secondaryButton(this,title);
        b.setOnClickListener(v->{filter=value;render();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);
        lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);
        row.addView(b,lp);
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.Reminder> all=NexaStore.reminders(this);
        long now=System.currentTimeMillis();
        int pending=0,overdue=0,paused=0,completed=0,recurring=0;
        NexaStore.Reminder next=null;
        for(NexaStore.Reminder r:all){
            if(r.done)completed++;
            else if(!r.active)paused++;
            else if(r.whenMillis<now)overdue++;
            else pending++;
            if(!r.done&&r.active&&ReminderRecurrence.isRecurring(r.recurrence))recurring++;
            if(!r.done&&r.active&&r.whenMillis>=now&&
                    (next==null||r.whenMillis<next.whenMillis))next=r;
        }
        String nextText=next==null?"":"\n⏭ نزدیک‌ترین: "+next.title+" • "+PersianDateUtil.pretty(next.whenMillis);
        summary.setText("🟢 "+pending+" در انتظار   •   🔴 "+overdue+" معوق"
                +"   •   ⏸ "+paused+" متوقف   •   ✅ "+completed+" انجام‌شده"
                +"   •   🔁 "+recurring+" تکرارشونده"+nextText);
        int shown=0;
        for(NexaStore.Reminder r:ReminderOrganizer.ordered(all,order,now)){
            if(!ReminderOrganizer.visible(r,filter,now)||!ReminderOrganizer.matches(r,searchText))continue;
            shown++;
            addReminderCard(r,now);
        }
        results.setText("نتایج فیلتر و جستجو: "+shown+" مورد از "+all.size());
        if(shown==0){
            TextView empty=UiKit.muted(this,all.isEmpty()?"هنوز یادآوری ثبت نشده.":"موردی مطابق جستجو یا فیلتر یافت نشد.");
            empty.setGravity(Gravity.CENTER);
            list.addView(empty,UiKit.matchWrap(this,20,0));
        }
    }

    private void addReminderCard(NexaStore.Reminder r,long now) {
        LinearLayout card=UiKit.colorfulCardLayout(this,Math.abs(r.category.hashCode())%4);
        card.addView(UiKit.sectionTitle(this,r.icon+"  "+r.title));
        card.addView(UiKit.muted(this,r.category+" • "+PersianDateUtil.pretty(r.whenMillis)
                +ReminderRecurrence.labelSuffix(r.recurrence)),UiKit.matchWrap(this,6,3));
        if(!r.doctorName.isEmpty())card.addView(UiKit.muted(this,"🩺 پزشک: "+r.doctorName),UiKit.matchWrap(this,4,0));
        if(!r.doctorFileNumber.isEmpty())card.addView(UiKit.muted(this,"شماره پرونده: "+r.doctorFileNumber),UiKit.matchWrap(this,3,0));
        if(!r.doctorCenter.isEmpty())card.addView(UiKit.muted(this,"مرکز: "+r.doctorCenter),UiKit.matchWrap(this,3,0));
        if(!r.doctorPhone.isEmpty())card.addView(UiKit.muted(this,"تماس: "+r.doctorPhone),UiKit.matchWrap(this,3,0));
        if(!r.doctorAddress.isEmpty())card.addView(UiKit.muted(this,"آدرس: "+r.doctorAddress),UiKit.matchWrap(this,3,0));
        if(!r.note.isEmpty())card.addView(UiKit.muted(this,r.note),UiKit.matchWrap(this,4,0));
        if(!ReminderSoundSelection.normalize(r.customSoundUri).isEmpty())
            card.addView(UiKit.muted(this,"🎵 "+ReminderSoundSelection.displayName(this,r.customSoundUri)),
                    UiKit.matchWrap(this,3,0));
        String status=r.done?"✅ انجام‌شده":!r.active?"⏸ متوقف":
                r.whenMillis<now?"🔴 معوق":"🟢 در انتظار";
        card.addView(UiKit.muted(this,status),UiKit.matchWrap(this,4,3));

        // Safe quick operations do not require opening the editor or changing recurrence rules.
        LinearLayout actions=new LinearLayout(this);
        Button done=UiKit.secondaryButton(this,r.done?"↶ بازگشایی":"✓ انجام شد");
        done.setOnClickListener(v->markDone(r));
        actions.addView(done,new LinearLayout.LayoutParams(0,-2,1f));
        if(!r.done){
            Button toggle=UiKit.secondaryButton(this,r.active?"⏸ توقف":"▶ فعال‌سازی");
            toggle.setOnClickListener(v->togglePaused(r));
            LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(0,-2,1f);
            bp.setMargins(UiKit.dp(this,6),0,0,0);
            actions.addView(toggle,bp);
        }
        card.addView(actions,UiKit.matchWrap(this,5,4));
        if(!r.done){
            Button postpone=UiKit.secondaryButton(this,"⏰ تغییر سریع موعد (۱۵ دقیقه / ۱ ساعت / فردا)");
            postpone.setOnClickListener(v->showPostponeDialog(r));
            card.addView(postpone,UiKit.matchWrap(this,0,4));
        }

        LinearLayout row=new LinearLayout(this);
        Button edit=UiKit.editIconButton(this);
        edit.setOnClickListener(v->openEditor(r.id));
        row.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
        Button copy=UiKit.secondaryButton(this,"کپی");
        copy.setOnClickListener(v->copyReminder(r));
        row.addView(copy,new LinearLayout.LayoutParams(0,-2,1f));
        Button del=UiKit.deleteIconButton(this);
        del.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("حذف یادآور؟").setMessage(r.title)
                .setPositiveButton("حذف",(d,w)->{
                    ReminderScheduler.cancelReminder(this,r);
                    NexaStore.removeReminder(this,r.id);
                    NexaStore.addHistory(this,"یادآور","حذف شد: "+r.title);
                    ReminderScheduler.updateLockCard(this);
                    TodayNotificationManager.refresh(this);
                    render();
                }).setNegativeButton("انصراف",null).show());
        LinearLayout.LayoutParams deleteParams=new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48));
        deleteParams.setMargins(UiKit.dp(this,5),0,0,0);
        row.addView(del,deleteParams);
        card.addView(row,UiKit.matchWrap(this,10,0));
        list.addView(card,UiKit.matchWrap(this,0,12));
    }

    private void openEditor(String id){
        Intent intent=new Intent(this,ReminderEditActivity.class);
        intent.putExtra("edit_id",id);
        startActivity(intent);
    }

    private void showPostponeDialog(NexaStore.Reminder r) {
        String title=ReminderRecurrence.isRecurring(r.recurrence)
                ?"تغییر موعد؛ تکرارهای بعدی نیز از موعد جدید محاسبه می‌شوند"
                :"موعد جدید «"+r.title+"»";
        new AlertDialog.Builder(this).setTitle(title)
                .setItems(new String[]{"۱۵ دقیقه دیگر","۱ ساعت دیگر","فردا در ساعت قبلی","انتخاب تاریخ و ساعت"},
                        (dialog,which)->{
                            if(which==3)openEditor(r.id);
                            else postpone(r,which);
                        })
                .setNegativeButton("انصراف",null).show();
    }

    private void postpone(NexaStore.Reminder r,int choice) {
        long now=System.currentTimeMillis();
        long next=ReminderOrganizer.postponedUntil(r.whenMillis,now,choice);
        if(next<=now){Toast.makeText(this,"زمان جدید معتبر نیست",Toast.LENGTH_SHORT).show();return;}
        ReminderScheduler.cancelReminder(this,r);
        // A previously delivered notification must not be able to complete the new occurrence.
        for(String rule:AlertRules.split(r.offsetsMinutes)) {
            NexaStore.dismissToken(this,ReminderScheduler.occurrenceToken(r.id,rule,r.whenMillis));
        }
        r.whenMillis=next;
        r.active=true;
        r.done=false;
        NexaStore.updateReminder(this,r);
        ReminderScheduler.scheduleReminder(this,r);
        NexaStore.addHistory(this,"یادآور","موعد جدید: "+r.title+" • "+PersianDateUtil.pretty(next));
        TodayNotificationManager.refresh(this);
        render();
    }

    private void togglePaused(NexaStore.Reminder r) {
        if(r.done)return;
        if(r.active){
            ReminderScheduler.cancelReminder(this,r);
            r.active=false;
            NexaStore.updateReminder(this,r);
            NexaStore.addHistory(this,"یادآور","موقتاً متوقف شد: "+r.title);
            ReminderScheduler.updateLockCard(this);
            TodayNotificationManager.refresh(this);
            render();
        }else if(r.whenMillis<=System.currentTimeMillis()){
            // Restoring an elapsed deadline without moving it would create no future alarm.
            showPostponeDialog(r);
        }else{
            r.active=true;
            NexaStore.updateReminder(this,r);
            ReminderScheduler.scheduleReminder(this,r);
            NexaStore.addHistory(this,"یادآور","دوباره فعال شد: "+r.title);
            TodayNotificationManager.refresh(this);
            render();
        }
    }

    private void markDone(NexaStore.Reminder r) {
        if(r.done){
            if(r.whenMillis<=System.currentTimeMillis()){
                showPostponeDialog(r);
                return;
            }
            r.done=false;
            r.active=true;
            NexaStore.updateReminder(this,r);
            ReminderScheduler.scheduleReminder(this,r);
            NexaStore.addHistory(this,"یادآور","بازگشایی شد: "+r.title);
        }else{
            ReminderScheduler.cancelReminder(this,r);
            if(ReminderRecurrence.advanceAfterDone(r,System.currentTimeMillis())){
                NexaStore.updateReminder(this,r);
                ReminderScheduler.scheduleReminder(this,r);
                NexaStore.addHistory(this,"یادآور","انجام شد؛ نوبت بعد تنظیم شد: "+r.title);
            }else{
                r.done=true;
                r.active=false;
                NexaStore.updateReminder(this,r);
                NexaStore.addHistory(this,"یادآور","انجام شد: "+r.title);
            }
        }
        ReminderScheduler.updateLockCard(this);
        TodayNotificationManager.refresh(this);
        render();
    }

    private void copyReminder(NexaStore.Reminder r) {
        NexaStore.Reminder n=new NexaStore.Reminder();
        n.title=r.title+" (کپی)";
        n.category=r.category;
        n.icon=r.icon;
        n.note=r.note;
        n.whenMillis=ReminderOrganizer.copiedDue(r.whenMillis,System.currentTimeMillis());
        n.offsetsMinutes=r.offsetsMinutes;
        n.repeatMinutes=r.repeatMinutes;
        n.customSoundUri=r.customSoundUri;
        n.doctorName=r.doctorName;
        n.doctorFileNumber=r.doctorFileNumber;
        n.doctorCenter=r.doctorCenter;
        n.doctorPhone=r.doctorPhone;
        n.doctorAddress=r.doctorAddress;
        n.recurrence=r.recurrence;
        NexaStore.addReminder(this,n);
        ReminderScheduler.scheduleReminder(this,n);
        NexaStore.addHistory(this,"یادآور","کپی شد: "+n.title);
        TodayNotificationManager.refresh(this);
        render();
    }
}
