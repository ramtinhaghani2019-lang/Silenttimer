package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class RemindersActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private String filter = "all";
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());h.addView(back);TextView title=UiKit.title(this,"Nexa Reminder");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1f);tp.setMargins(UiKit.dp(this,12),0,0,0);h.addView(title,tp);root.addView(h,UiKit.matchWrap(this,0,16));LinearLayout hero=UiKit.colorfulCardLayout(this,6);hero.addView(UiKit.sectionTitle(this,"📅 تقویم شمسی + هشدار چندمرحله‌ای"));hero.addView(UiKit.muted(this,"قرار، دکتر، چک، قسط، تولد و هر چیزی که نباید فراموش شود."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ یادآور جدید");add.setOnClickListener(v->startActivity(new Intent(this,ReminderEditActivity.class)));hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));
summary=UiKit.muted(this,"");summary.setGravity(Gravity.CENTER);root.addView(summary,UiKit.matchWrap(this,0,10));
LinearLayout shortcuts=new LinearLayout(this);shortcuts.setOrientation(LinearLayout.HORIZONTAL);
Button today=UiKit.secondaryButton(this,"امروز");today.setOnClickListener(v->startActivity(new Intent(this,TodayActivity.class)));shortcuts.addView(today,new LinearLayout.LayoutParams(0,-2,1f));
Button search=UiKit.secondaryButton(this,"جستجو");search.setOnClickListener(v->startActivity(new Intent(this,SearchActivity.class)));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-2,1f);sp.setMargins(UiKit.dp(this,6),0,0,0);shortcuts.addView(search,sp);root.addView(shortcuts,UiKit.matchWrap(this,0,10));
LinearLayout filters=new LinearLayout(this);filters.setOrientation(LinearLayout.HORIZONTAL);
addFilter(filters,"همه","all");addFilter(filters,"در انتظار","pending");addFilter(filters,"معوق","overdue");addFilter(filters,"انجام‌شده","done");root.addView(filters,UiKit.matchWrap(this,0,12));
list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private void addFilter(LinearLayout row,String label,String value){Button b=UiKit.secondaryButton(this,label);b.setOnClickListener(v->{filter=value;render();});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1f);lp.setMargins(UiKit.dp(this,3),0,UiKit.dp(this,3),0);row.addView(b,lp);}
    private boolean visible(NexaStore.Reminder r,long now){if("done".equals(filter))return r.done;if("overdue".equals(filter))return !r.done&&r.active&&r.whenMillis<now;if("pending".equals(filter))return !r.done&&r.active&&r.whenMillis>=now;return true;}
    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Reminder> rs=NexaStore.reminders(this);long now=System.currentTimeMillis();int pending=0,overdue=0,doneCount=0;for(NexaStore.Reminder x:rs){if(x.done)doneCount++;else if(x.active&&x.whenMillis<now)overdue++;else if(x.active)pending++;}if(summary!=null)summary.setText("🟢 "+pending+" در انتظار   •   🔴 "+overdue+" معوق   •   ✅ "+doneCount+" انجام‌شده");if(rs.isEmpty()){TextView e=UiKit.muted(this,"هنوز یادآوری ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}boolean any=false;for(NexaStore.Reminder r:rs){if(!visible(r,now))continue;any=true;LinearLayout c=UiKit.colorfulCardLayout(this,Math.abs(r.category.hashCode())%4);TextView t=UiKit.sectionTitle(this,r.icon+"  "+r.title);c.addView(t);c.addView(UiKit.muted(this,r.category+" • "+PersianDateUtil.pretty(r.whenMillis)+ReminderRecurrence.labelSuffix(r.recurrence)),UiKit.matchWrap(this,6,3));if(!r.doctorName.isEmpty())c.addView(UiKit.muted(this,"🩺 پزشک: "+r.doctorName),UiKit.matchWrap(this,4,0));
if(!r.doctorFileNumber.isEmpty())c.addView(UiKit.muted(this,"شماره پرونده: "+r.doctorFileNumber),UiKit.matchWrap(this,3,0));
if(!r.doctorCenter.isEmpty())c.addView(UiKit.muted(this,"مرکز: "+r.doctorCenter),UiKit.matchWrap(this,3,0));
if(!r.doctorPhone.isEmpty())c.addView(UiKit.muted(this,"تماس: "+r.doctorPhone),UiKit.matchWrap(this,3,0));
if(!r.doctorAddress.isEmpty())c.addView(UiKit.muted(this,"آدرس: "+r.doctorAddress),UiKit.matchWrap(this,3,0));
if(!r.note.isEmpty())c.addView(UiKit.muted(this,r.note),UiKit.matchWrap(this,4,0));
String status=r.done?"✅ انجام‌شده":!r.active?"⏸ غیرفعال":r.whenMillis<System.currentTimeMillis()?"🔴 معوق":"🟢 در انتظار";
c.addView(UiKit.muted(this,status),UiKit.matchWrap(this,4,2));
Button done=UiKit.secondaryButton(this,r.done?"↶ انجام‌نشده":"✓ انجام شد");done.setOnClickListener(v->{boolean wasDone=r.done;if(!r.done)ReminderScheduler.cancelReminder(this,r);if(!r.done&&ReminderRecurrence.isRecurring(r.recurrence)){r.whenMillis=ReminderRecurrence.next(r.whenMillis,r.recurrence,System.currentTimeMillis());r.done=false;r.active=true;NexaStore.updateReminder(this,r);ReminderScheduler.scheduleReminder(this,r);NexaStore.addHistory(this,"یادآور","انجام شد؛ نوبت بعد تنظیم شد: "+r.title);}else{r.done=!r.done;r.active=!r.done;NexaStore.updateReminder(this,r);if(r.active)ReminderScheduler.scheduleReminder(this,r);NexaStore.addHistory(this,"یادآور",(wasDone?"بازگشایی شد: ":"انجام شد: ")+r.title);}ReminderScheduler.updateLockCard(this);render();});if(r.done || (r.active && r.whenMillis<=System.currentTimeMillis()))c.addView(done);
LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->{Intent i=new Intent(this,ReminderEditActivity.class);i.putExtra("edit_id",r.id);startActivity(i);});
row.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
Button copy=UiKit.secondaryButton(this,"کپی");copy.setOnClickListener(v->{NexaStore.Reminder n=new NexaStore.Reminder();n.title=r.title+" (کپی)";n.category=r.category;n.icon=r.icon;n.note=r.note;n.whenMillis=r.whenMillis+86400000L;n.offsetsMinutes=r.offsetsMinutes;n.repeatMinutes=r.repeatMinutes;n.doctorName=r.doctorName;n.doctorFileNumber=r.doctorFileNumber;n.doctorCenter=r.doctorCenter;n.doctorPhone=r.doctorPhone;n.doctorAddress=r.doctorAddress;n.recurrence=r.recurrence;NexaStore.addReminder(this,n);ReminderScheduler.scheduleReminder(this,n);render();});row.addView(copy,new LinearLayout.LayoutParams(0,-2,1f));
Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new android.app.AlertDialog.Builder(this)
.setTitle("حذف یادآور؟").setMessage(r.title).setPositiveButton("حذف",(d,w)->{
ReminderScheduler.cancelReminder(this,r);NexaStore.removeReminder(this,r.id);NexaStore.addHistory(this,"یادآور","حذف شد: "+r.title);
ReminderScheduler.updateLockCard(this);render();}).setNegativeButton("انصراف",null).show());
LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dlp.setMargins(UiKit.dp(this,5),0,0,0);row.addView(del,dlp);c.addView(row,UiKit.matchWrap(this,10,0));list.addView(c,UiKit.matchWrap(this,0,12));}if(!any){TextView e=UiKit.muted(this,"موردی در این فیلتر وجود ندارد.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));}}
}
