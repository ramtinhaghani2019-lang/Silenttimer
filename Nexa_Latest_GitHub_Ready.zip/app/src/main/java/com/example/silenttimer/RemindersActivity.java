package com.example.silenttimer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class RemindersActivity extends Activity {
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackground(UiKit.screenBackground(this));sc.addView(root);LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());h.addView(back);TextView title=UiKit.title(this,"Nexa Reminder");LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1f);tp.setMargins(UiKit.dp(this,12),0,0,0);h.addView(title,tp);root.addView(h,UiKit.matchWrap(this,0,16));LinearLayout hero=UiKit.colorfulCardLayout(this,6);hero.addView(UiKit.sectionTitle(this,"📅 تقویم شمسی + هشدار چندمرحله‌ای"));hero.addView(UiKit.muted(this,"قرار، دکتر، چک، قسط، تولد و هر چیزی که نباید فراموش شود."),UiKit.matchWrap(this,6,14));Button add=UiKit.primaryButton(this,"＋ یادآور جدید");add.setOnClickListener(v->startActivity(new Intent(this,ReminderEditActivity.class)));hero.addView(add);root.addView(hero,UiKit.matchWrap(this,0,14));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);setContentView(sc);render();}
    private void render(){if(list==null)return;list.removeAllViews();List<NexaStore.Reminder> rs=NexaStore.reminders(this);if(rs.isEmpty()){TextView e=UiKit.muted(this,"هنوز یادآوری ثبت نشده.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;}for(NexaStore.Reminder r:rs){LinearLayout c=UiKit.colorfulCardLayout(this,Math.abs(r.category.hashCode())%4);TextView t=UiKit.sectionTitle(this,r.icon+"  "+r.title);c.addView(t);c.addView(UiKit.muted(this,r.category+" • "+PersianDateUtil.pretty(r.whenMillis)),UiKit.matchWrap(this,6,3));if(!r.doctorName.isEmpty())c.addView(UiKit.muted(this,"🩺 پزشک: "+r.doctorName),UiKit.matchWrap(this,4,0));
if(!r.doctorFileNumber.isEmpty())c.addView(UiKit.muted(this,"شماره پرونده: "+r.doctorFileNumber),UiKit.matchWrap(this,3,0));
if(!r.doctorCenter.isEmpty())c.addView(UiKit.muted(this,"مرکز: "+r.doctorCenter),UiKit.matchWrap(this,3,0));
if(!r.doctorPhone.isEmpty())c.addView(UiKit.muted(this,"تماس: "+r.doctorPhone),UiKit.matchWrap(this,3,0));
if(!r.doctorAddress.isEmpty())c.addView(UiKit.muted(this,"آدرس: "+r.doctorAddress),UiKit.matchWrap(this,3,0));
if(!r.note.isEmpty())c.addView(UiKit.muted(this,r.note),UiKit.matchWrap(this,4,0));
String status=r.done?"✅ انجام‌شده":!r.active?"⏸ غیرفعال":r.whenMillis<System.currentTimeMillis()?"🔴 معوق":"🟢 در انتظار";
c.addView(UiKit.muted(this,status),UiKit.matchWrap(this,4,2));
Button done=UiKit.secondaryButton(this,r.done?"↶ انجام‌نشده":"✓ انجام شد");done.setOnClickListener(v->{if(!r.done)ReminderScheduler.cancelReminder(this,r);r.done=!r.done;r.active=!r.done;NexaStore.updateReminder(this,r);if(r.active)ReminderScheduler.scheduleReminder(this,r);ReminderScheduler.updateLockCard(this);render();});if(r.done || (r.active && r.whenMillis<=System.currentTimeMillis()))c.addView(done);
LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->{Intent i=new Intent(this,ReminderEditActivity.class);i.putExtra("edit_id",r.id);startActivity(i);});
row.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
Button copy=UiKit.secondaryButton(this,"کپی");copy.setOnClickListener(v->{NexaStore.Reminder n=new NexaStore.Reminder();n.title=r.title+" (کپی)";n.category=r.category;n.icon=r.icon;n.note=r.note;n.whenMillis=r.whenMillis+86400000L;n.offsetsMinutes=r.offsetsMinutes;n.repeatMinutes=r.repeatMinutes;n.doctorName=r.doctorName;n.doctorFileNumber=r.doctorFileNumber;n.doctorCenter=r.doctorCenter;n.doctorPhone=r.doctorPhone;n.doctorAddress=r.doctorAddress;NexaStore.addReminder(this,n);ReminderScheduler.scheduleReminder(this,n);render();});row.addView(copy,new LinearLayout.LayoutParams(0,-2,1f));
Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new android.app.AlertDialog.Builder(this)
.setTitle("حذف یادآور؟").setMessage(r.title).setPositiveButton("حذف",(d,w)->{
ReminderScheduler.cancelReminder(this,r);NexaStore.removeReminder(this,r.id);
ReminderScheduler.updateLockCard(this);render();}).setNegativeButton("انصراف",null).show());
LinearLayout.LayoutParams dlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dlp.setMargins(UiKit.dp(this,5),0,0,0);row.addView(del,dlp);c.addView(row,UiKit.matchWrap(this,10,0));list.addView(c,UiKit.matchWrap(this,0,12));}}
}
