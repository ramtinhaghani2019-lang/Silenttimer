package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null || !shouldReschedule(intent.getAction())) return;
        // TIME_SET and TIMEZONE_CHANGED can invalidate the wall-clock triggers
        // for calendar-day advance rules (e.g. D3@09:00).
        BackgroundReliability.run(context, "boot.reminders", () -> ReminderScheduler.rescheduleAll(context));
        BackgroundReliability.run(context, "boot.emergency", () -> EmergencyCardManager.refresh(context));
        BackgroundReliability.run(context, "boot.today", () -> TodayNotificationManager.refresh(context));
        BackgroundReliability.run(context, "boot.garage", () -> GarageNotifier.refresh(context));
        BackgroundReliability.run(context, "boot.market", () -> PriceMonitorReceiver.schedule(context));
        BackgroundReliability.run(context, "boot.weather", () -> WeatherAlertReceiver.schedule(context));
        boolean bootOrUpdate = Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction());
        if (bootOrUpdate) {
            BackgroundReliability.run(context, "boot.theft", () -> AppPrefs.clearTheftPlugState(context));
        }

        // Exact-alarm permission can be granted outside Nexa. Reschedule immediately
        // so medicine/reminder alarms switch from best-effort to exact scheduling.
        if (!bootOrUpdate) return;

        boolean needsPersistentMonitor = AppPrefs.isMonitoringEnabled(context)
                || AppPrefs.isChargeAlarmEnabled(context)
                || AppPrefs.isLowBatteryAlarmEnabled(context)
                || AppPrefs.isTheftGuardEnabled(context);
        if (!needsPersistentMonitor) return;

        Intent service = new Intent(context, SilentTimerService.class);
        service.setAction(SilentTimerService.ACTION_MONITOR);

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (RuntimeException error) { BackgroundReliability.record(context, "boot.monitor-start", error); }
    }

    /** Only protected platform events may cause bulk rescheduling.
     * Ignore externally supplied or unknown actions on this exported receiver. */
    public static boolean shouldReschedule(String action) {
        return Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)
                || android.app.AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action);
    }
}
