package com.example.silenttimer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        ReminderScheduler.rescheduleAll(context);
        EmergencyCardManager.refresh(context);
        TodayNotificationManager.refresh(context);
        try { GarageNotifier.refresh(context); } catch (Exception ignored) {}
        PriceMonitorReceiver.schedule(context);
        AppPrefs.clearTheftPlugState(context); // establish a fresh charger baseline after boot/update

        // Exact-alarm permission can be granted outside Nexa. Reschedule immediately
        // so medicine/reminder alarms switch from best-effort to exact scheduling.
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(intent.getAction())) {
            // Continue below for normal boot/update monitoring restore.
        } else {
            return;
        }

        boolean needsPersistentMonitor = AppPrefs.isMonitoringEnabled(context)
                || AppPrefs.isChargeAlarmEnabled(context)
                || AppPrefs.isLowBatteryAlarmEnabled(context)
                || AppPrefs.isTheftGuardEnabled(context);
        if (!needsPersistentMonitor) return;

        Intent service = new Intent(context, SilentTimerService.class);
        service.setAction(SilentTimerService.ACTION_MONITOR);

        try {
            if (Build.VERSION.SDK_INT >= 26) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (Exception ignored) {}
    }
}
