package com.example.silenttimer;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative Persian commands. Never writes user data or infers financial direction silently. */
public final class VoiceCommandParser {
    private VoiceCommandParser(){}
    public static final class Finance {
        public final String party,kind;
        public final long amount;
        Finance(String p,String k,long a){party=p;kind=k;amount=a;}
    }
    public static String normalize(String text){
        if(text==null)return "";
        String s=text.trim().replace('ي','ی').replace('ك','ک')
                .replace('\u200c',' ').replace('٫','.').replace('٬',',');
        StringBuilder out=new StringBuilder();
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(c>='۰' && c<='۹')c=(char)('0'+c-'۰');
            if(c>='٠' && c<='٩')c=(char)('0'+c-'٠');
            out.append(c);
        }
        return out.toString().replaceAll("\\s+"," ").trim();
    }
    public static String identity(String s){return normalize(s).replaceAll("\\s+","").toLowerCase(Locale.ROOT);}
    private static final Map<String,Long> NUM=new HashMap<>();
    static{
        String[] basics={"صفر","یک","دو","سه","چهار","پنج","شش","هفت","هشت","نه",
                "ده","یازده","دوازده","سیزده","چهارده","پانزده","شانزده","هفده","هجده","نوزده"};
        for(int i=0;i<basics.length;i++)NUM.put(basics[i],(long)i);
        NUM.put("یه",1L);NUM.put("شیش",6L);
        NUM.put("بیست",20L);NUM.put("سی",30L);NUM.put("چهل",40L);NUM.put("پنجاه",50L);
        NUM.put("شصت",60L);NUM.put("هفتاد",70L);NUM.put("هشتاد",80L);NUM.put("نود",90L);
        NUM.put("صد",100L);NUM.put("یکصد",100L);NUM.put("دویست",200L);
        NUM.put("سیصد",300L);NUM.put("چهارصد",400L);NUM.put("پانصد",500L);
        NUM.put("ششصد",600L);NUM.put("هفتصد",700L);NUM.put("هشتصد",800L);NUM.put("نهصد",900L);
    }
    /**
     * Parse a single explicit Persian amount without silently dropping a trailing unit.
     * In particular "۵۰ میلیون و ۲۰۰ هزار" must be 50,200,000, not 50,000,000.
     * Ambiguous shorthand, fractions, reversed units and overflow fail closed.
     */
    public static long amountToman(String raw){
        String s=normalize(raw);
        if(s.isEmpty() || s.contains("ریال") || s.contains("منفی") ||
                s.contains("نیم") || s.contains("ممیز") ||
                s.matches(".*\\d\\s*[./]\\s*\\d.*"))return 0;
        String[] words=s.split(" ");
        long total=0,group=0;
        int lastRank=4;
        boolean started=false,unitSeen=false,currencySeen=false,join=false;
        for(int i=0;i<words.length;i++){
            String word=words[i];
            Long value=NUM.get(word);
            if(value==null && word.matches("(?:[0-9]{1,3}(?:,[0-9]{3})+|[0-9]{1,15})")){
                try{value=Long.parseLong(word.replace(",",""));}catch(NumberFormatException ignored){return 0;}
            }
            if(value!=null){
                try{group=Math.addExact(group,value);}catch(ArithmeticException e){return 0;}
                started=true;join=false;continue;
            }
            if(!started)continue;
            if("و".equals(word)){
                if(join || (group==0 && !unitSeen))return 0;
                join=true;continue;
            }
            int rank="میلیارد".equals(word)?3:"میلیون".equals(word)?2:"هزار".equals(word)?1:0;
            if(rank>0){
                if(group<=0 || rank>=lastRank || join)return 0;
                long factor=rank==3?1_000_000_000L:rank==2?1_000_000L:1000L;
                try{total=Math.addExact(total,Math.multiplyExact(group,factor));}
                catch(ArithmeticException e){return 0;}
                lastRank=rank;group=0;unitSeen=true;continue;
            }
            if("تومان".equals(word) || "تومن".equals(word)){
                if(join)return 0;
                currencySeen=true;
                // A second numeric phrase after the currency must not be silently discarded.
                for(int j=i+1;j<words.length;j++){
                    String tail=words[j];
                    if(NUM.containsKey(tail) || tail.matches(".*[0-9].*") ||
                            "هزار".equals(tail) || "میلیون".equals(tail) || "میلیارد".equals(tail))return 0;
                }
                break;
            }
            if(join)return 0; // "پنجاه میلیون و ..." cannot be partially accepted.
            break;
        }
        if(!started || join || (unitSeen && group>0) || (!unitSeen && !currencySeen))return 0;
        try{return Math.addExact(total,group)>0?Math.addExact(total,group):0;}
        catch(ArithmeticException e){return 0;}
    }
    public static Finance finance(String raw){
        String s=normalize(raw);
        if(s.contains("ریال") || s.contains("منفی") || s.contains("نیم") ||
                s.matches(".*\\d\\s*[./]\\s*\\d.*"))return null;
        boolean debt=s.contains("بدهی به ")||s.contains("بدهکارم به ")||s.contains("من به ");
        boolean credit=s.contains("طلب از ")||s.contains("طلبم از ")||
                (s.contains("از ")&&s.contains(" طلب"));
        boolean payment=s.contains("پرداخت به ")||s.contains("پرداخت کردم به ");
        boolean receipt=s.contains("دریافت از ")||s.contains("گرفتم از ");
        if((debt?1:0)+(credit?1:0)+(payment?1:0)+(receipt?1:0)!=1)return null;
        String kind=debt?"DEBT":credit?"CREDIT":payment?"PAYMENT":"RECEIPT";
        String party="";
        if(credit && s.contains(" از ") && !s.contains("طلب از ") && !s.contains("طلبم از ")){
            Matcher m=Pattern.compile("(?:^|\\s)از\\s+([\\p{L}\\s]{2,50}?)\\s+طلب(?:\\s|$)").matcher(s);
            if(m.find())party=m.group(1).trim();
        }else{
            String marker=(credit||receipt)?"از ":"به ";
            int ix=s.lastIndexOf(marker);
            if(ix>=0)party=s.substring(ix+marker.length());
        }
        party=party.replaceFirst("(?:\\s+(?:ثبت کن|ثبت شود|بزن|لطفا|لطفاً|تومان|تومن))(?=\\s|$).*", "").trim();
        if(!party.matches("[\\p{L}\\s]{2,50}"))return null;
        long amount=amountToman(s);
        if(amount<=0)return null;
        return new Finance(party,kind,amount);
    }
    /** Nonfinancial routing only. The destination form performs the actual save. */
    public static final class FormDraft {
        public final String destination, title, type;
        FormDraft(String destination,String title){this(destination,title,"");}
        FormDraft(String destination,String title,String type){
            this.destination=destination;this.title=title;this.type=type;
        }
    }
    private static String cleanDraft(String raw){
        if(raw==null)return "";
        return raw.trim().replaceFirst("(?:\\s+(?:رو|را))?\\s+(?:ثبت کن|اضافه کن|یادداشت کن|درست کن|بساز)\\s*$","").trim();
    }
    public static FormDraft nonFinancialForm(String raw){
        String s=normalize(raw);
        // Never let an ambiguous money instruction end up in a shopping/task record.
        if(s.contains("بدهی")||s.contains("طلب")||s.contains("پرداخت")||s.contains("دریافت"))return null;
        String task=null,shopping=null;
        if(s.startsWith("کار جدید "))task=s.substring("کار جدید ".length());
        else if(s.startsWith("یه کار "))task=s.substring("یه کار ".length());
        else if(s.startsWith("یک کار "))task=s.substring("یک کار ".length());
        else if(s.startsWith("کار "))task=s.substring("کار ".length());
        else if(s.startsWith("به کارها اضافه کن "))task=s.substring("به کارها اضافه کن ".length());
        if(s.startsWith("لیست خرید "))shopping=s.substring("لیست خرید ".length());
        else if(s.startsWith("یه لیست خرید "))shopping=s.substring("یه لیست خرید ".length());
        else if(s.startsWith("یک لیست خرید "))shopping=s.substring("یک لیست خرید ".length());
        // Explicit bill category is a draft only: amounts and due dates are entered in the form.
        // A spoken amount must not silently become part of a title or be stored as zero.
        String[] billPrefixes={"قبض جدید ","قسط جدید ","اجاره جدید ",
                "اشتراک جدید ","بیمه جدید ","چک جدید "};
        String[] billTypes={"قبض","قسط","اجاره","اشتراک","بیمه","چک"};
        for(int i=0;i<billPrefixes.length;i++){
            if(!s.startsWith(billPrefixes[i]))continue;
            String title=cleanDraft(s.substring(billPrefixes[i].length()));
            if(title.length()<2 || title.length()>100)return null;
            // Reject spoken financial amounts unless a dedicated amount parser is used.
            if(title.matches(".*[0-9].*") ||
                    title.matches(".*(?:میلیون|میلیارد|هزار|تومان|تومن|ریال).*"))return null;
            return new FormDraft("bills",title,billTypes[i]);
        }
        String asset=null,vehicle=null;
        if(s.startsWith("دارایی جدید "))asset=s.substring("دارایی جدید ".length());
        else if(s.startsWith("دارایی "))asset=s.substring("دارایی ".length());
        if(s.startsWith("وسیله جدید "))vehicle=s.substring("وسیله جدید ".length());
        else if(s.startsWith("خودرو جدید "))vehicle=s.substring("خودرو جدید ".length());
        if(asset!=null){asset=cleanDraft(asset);if(asset.length()>=2 && asset.length()<=100)return new FormDraft("assets",asset);}
        if(vehicle!=null){vehicle=cleanDraft(vehicle);if(vehicle.length()>=2 && vehicle.length()<=100)return new FormDraft("vehicle",vehicle);}
        if(task!=null){task=cleanDraft(task);if(task.length()>=2 && task.length()<=100)return new FormDraft("todo",task);}
        if(shopping!=null){shopping=cleanDraft(shopping);if(shopping.length()>=2 && shopping.length()<=100)return new FormDraft("shopping",shopping);}
        return null;
    }
    /** Explicit recurring phrases; no schedule is silently saved. */
    public static String spokenRecurrence(String raw){
        String s=normalize(raw);
        Matcher m=Pattern.compile("(?:^|\\s)هر\\s+(?:(\\d{1,3}|یک|یه|دو|سه|چهار|پنج|شش|هفت|هشت|نه|ده)\\s+)?(روز|هفته|ماه|سال)(?:\\s|$)").matcher(s);
        if(!m.find())return "none";
        String n=m.group(1);
        int count=1;
        if(n!=null){
            Long v=NUM.get(n);
            if(v!=null)count=v.intValue();
            else try{count=Integer.parseInt(n);}catch(NumberFormatException ignored){return "none";}
        }
        String u="روز".equals(m.group(2))?"day":"هفته".equals(m.group(2))?"week":"ماه".equals(m.group(2))?"month":"year";
        return count>=1 && count<=("day".equals(u)?3650:"week".equals(u)?520:"month".equals(u)?120:20)?"every:"+count+":"+u:"none";
    }
    public static String reminderTitle(String raw){
        String s=normalize(raw);
        if(!(s.contains("یادآور")||s.contains("یادم بنداز")||s.contains("یادم بینداز")))return null;
        return s.replaceFirst("^(?:یه )?(?:یادآوری کن|یادآور ثبت کن|یادآور|یادم بنداز|یادم بینداز)(?: که)?\\s*","").trim();
    }
}
