package com.example.silenttimer;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Conservative Persian commands. Never writes user data or infers financial direction silently. */
public final class VoiceCommandParser {
    private VoiceCommandParser(){}
    public static final class Finance {
        public final String party,kind;
        public final long amount;
        Finance(String p,String k,long a){party=p;kind=k;amount=a;}
    }
    public static String normalize(String text){
        if(text==null)return "";
        String s=text.trim().replace('ي','ی').replace('ك','ک')
                .replace('\u200c',' ').replace('٫','.').replace('٬',',');
        StringBuilder out=new StringBuilder();
        for(int i=0;i<s.length();i++){
            char c=s.charAt(i);
            if(c>='۰' && c<='۹')c=(char)('0'+c-'۰');
            if(c>='٠' && c<='٩')c=(char)('0'+c-'٠');
            out.append(c);
        }
        return out.toString().replaceAll("\\s+"," ").trim();
    }
    public static String identity(String s){return normalize(s).replaceAll("\\s+","").toLowerCase(Locale.ROOT);}
    private static final Map<String,Long> NUM=new HashMap<>();
    static{
        String[] basics={"صفر","یک","دو","سه","چهار","پنج","شش","هفت","هشت","نه",
                "ده","یازده","دوازده","سیزده","چهارده","پانزده","شانزده","هفده","هجده","نوزده"};
        for(int i=0;i<basics.length;i++)NUM.put(basics[i],(long)i);
        NUM.put("یه",1L);NUM.put("شیش",6L);
        NUM.put("بیست",20L);NUM.put("سی",30L);NUM.put("چهل",40L);NUM.put("پنجاه",50L);
        NUM.put("شصت",60L);NUM.put("هفتاد",70L);NUM.put("هشتاد",80L);NUM.put("نود",90L);
        NUM.put("صد",100L);NUM.put("یکصد",100L);NUM.put("دویست",200L);
        NUM.put("سیصد",300L);NUM.put("چهارصد",400L);NUM.put("پانصد",500L);
        NUM.put("ششصد",600L);NUM.put("هفتصد",700L);NUM.put("هشتصد",800L);NUM.put("نهصد",900L);
    }
    /** Only parse explicit unambiguous quantities; unclear/decimal/negative values are rejected. */
    public static long amountToman(String raw){
        String s=normalize(raw);
        Matcher digits=Pattern.compile("(?<!\\d)(\\d{1,15}(?:,\\d{3})*)(?:\\s*)(میلیارد|میلیون|هزار)?").matcher(s);
        if(digits.find()){
            try{
                long x=Long.parseLong(digits.group(1).replace(",",""));
                String u=digits.group(2);
                long factor="میلیارد".equals(u)?1_000_000_000L:"میلیون".equals(u)?1_000_000L:"هزار".equals(u)?1000L:1L;
                return x>0?Math.multiplyExact(x,factor):0;
            }catch(Exception ignored){return 0;}
        }
        String[] words=s.split(" ");
        long current=0,total=0;
        boolean hasNumber=false;
        for(String word:words){
            if("و".equals(word)&&hasNumber)continue;
            Long v=NUM.get(word);
            if(v!=null){current+=v;hasNumber=true;continue;}
            long multiplier="میلیارد".equals(word)?1_000_000_000L:"میلیون".equals(word)?1_000_000L:"هزار".equals(word)?1000:0;
            if(multiplier!=0&&hasNumber){
                try{total=Math.addExact(total,Math.multiplyExact(current,multiplier));}
                catch(ArithmeticException e){return 0;}
                current=0;continue;
            }
            if(hasNumber)break;
        }
        return hasNumber?total+current:0;
    }
    public static Finance finance(String raw){
        String s=normalize(raw);
        if(s.contains("ریال")||s.contains("منفی")||s.matches(".*\\d[.٫]\\d.*"))return null;
        if(!s.contains("بده")&&!s.contains("طلب")&&!s.contains("پرداخت")&&!s.contains("دریافت"))return null;
        // Direction must be explicit; 'احمدی بدهکار' without 'به من' is ambiguous.
        String kind;
        if(s.contains("به من بدهکار") || s.contains("از احمدی طلب") || s.contains("طلب از ") || s.contains("طلبم از "))kind="CREDIT";
        else if(s.contains("بدهی به ")||s.contains("بدهکارم به ")||s.contains("من به "))kind="DEBT";
        else if(s.contains("پرداخت به ") || s.contains("پرداخت کردم به "))kind="PAYMENT";
        else if(s.contains("دریافت از ")||s.contains("گرفتم از "))kind="RECEIPT";
        else return null;
        String party="";
        String marker=("CREDIT".equals(kind)||"RECEIPT".equals(kind))?"از ":"به ";
        int ix=s.lastIndexOf(marker);
        if(ix>=0)party=s.substring(ix+marker.length());
        if(party.isEmpty()&&"CREDIT".equals(kind)&&s.contains("به من بدهکار")){
            int p=s.indexOf("به من بدهکار");
            party=s.substring(0,p).replaceAll(".*?(?:تومان|میلیون|میلیارد|هزار)\\s*","").trim();
        }
        party=party.replaceFirst("(?:\\s+(?:ثبت کن|ثبت شود|بزن|لطفا|لطفاً|تومان|تومن))(?=\\s|$).*", "").trim();
        if(!party.matches("[\\p{L}\\s]{2,50}"))return null;
        long amount=amountToman(s);
        if(amount<=0)return null;
        return new Finance(party,kind,amount);
    }
    public static String reminderTitle(String raw){
        String s=normalize(raw);
        if(!(s.contains("یادآور")||s.contains("یادم بنداز")||s.contains("یادم بینداز")))return null;
        return s.replaceFirst("^(?:یه )?(?:یادآوری کن|یادآور ثبت کن|یادآور|یادم بنداز|یادم بینداز)(?: که)?\\s*","").trim();
    }
}
