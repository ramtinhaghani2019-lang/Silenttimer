package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView;
import java.util.Calendar;
import java.util.Locale;

/** Premium compact form: original date, calendar type, warning time and annual recurrence. */
public class OccasionEditActivity extends Activity {
    private final String[] types={"تولد","سالگرد ازدواج","سالگرد فوت","مناسبت شخصی"};
    private final String[] values={"birthday","marriage","memorial","personal"};
    private final String[] calendars={"شمسی","میلادی"};
    private OccasionStore.Occasion editing;
    private EditText title,note;
    private Spinner type,calendar;
    private Button dateButton,timeButton;
    private CheckBox before1,before3,before7,enabled;
    private int year,month,day,hour,minute;
    private String currentCalendar;
    private Bundle formState;
    @Override protected void onCreate(Bundle state){super.onCreate(state);UiKit.applyWindow(this);
        editing=OccasionStore.find(this,getIntent().getStringExtra("id"));
        Calendar c=Calendar.getInstance();int[] j=PersianDateUtil.fromMillis(System.currentTimeMillis());
        year=editing==null?j[0]:editing.year;month=editing==null?j[1]:editing.month;day=editing==null?j[2]:editing.day;
        hour=editing==null?9:editing.hour;minute=editing==null?0:editing.minute;
        currentCalendar=editing==null?"jalali":editing.calendar;
        formState=state;
        if(state!=null){year=state.getInt("year",year);month=state.getInt("month",month);day=state.getInt("day",day);
            hour=state.getInt("hour",hour);minute=state.getInt("minute",minute);
            currentCalendar=state.getString("calendar",currentCalendar);}
        build();
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putInt("year",year);out.putInt("month",month);out.putInt("day",day);out.putInt("hour",hour);out.putInt("minute",minute);
        out.putString("calendar",calendarValue());
        out.putString("titleText",title.getText().toString());out.putString("noteText",note.getText().toString());
        out.putInt("typeIndex",type.getSelectedItemPosition());
        out.putBoolean("oneDay",before1.isChecked());out.putBoolean("threeDays",before3.isChecked());
        out.putBoolean("sevenDays",before7.isChecked());out.putBoolean("enabled",enabled.isChecked());
        super.onSaveInstanceState(out);
    }
    private String calendarValue(){return calendar.getSelectedItemPosition()==1?"gregorian":"jalali";}
    private static int index(String[] arr,String value){for(int i=0;i<arr.length;i++)if(arr[i].equals(value))return i;return 0;}
    private EditText input(String hint){return UiKit.styleField(this,new EditText(this),hint);}
    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));root.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,25));sc.addView(root);
        root.addView(UiKit.header(this,editing==null?"افزودن مناسبت":"ویرایش مناسبت",v->finish()),UiKit.matchWrap(this,0,8));
        root.addView(UiKit.muted(this,"سالگردها هر سال خودکار تکرار می‌شوند؛ تاریخ اصلی پاک یا جابه‌جا نمی‌شود."),UiKit.matchWrap(this,0,11));
        LinearLayout card=NexaReminderUi.formSection(this,"🎂 جزئیات مناسبت","نوع رویداد، نام و تاریخ اصلی");root.addView(card);
        title=input("مثلاً تولد سارا یا سالگرد ازدواج ما");card.addView(UiKit.fieldLabel(this,"عنوان"));card.addView(title,UiKit.matchWrap(this,0,9));
        type=UiKit.styledSpinner(this);ArrayAdapter<String> typeAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,types);
        typeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);type.setAdapter(typeAdapter);
        card.addView(UiKit.fieldLabel(this,"نوع مناسبت"));card.addView(type,UiKit.matchWrap(this,0,9));
        calendar=UiKit.styledSpinner(this);ArrayAdapter<String> cAdapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,calendars);
        cAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);calendar.setAdapter(cAdapter);
        calendar.setSelection("gregorian".equals(currentCalendar)?1:0);
        card.addView(UiKit.fieldLabel(this,"تقویم تاریخ اصلی"));card.addView(calendar,UiKit.matchWrap(this,0,8));
        dateButton=UiKit.secondaryButton(this,"");dateButton.setOnClickListener(v->pickOriginalDate());
        card.addView(UiKit.fieldLabel(this,"روز، ماه و سال اصلی مناسبت"));card.addView(dateButton,UiKit.matchWrap(this,0,7));
        card.addView(UiKit.muted(this,"برای سال‌های آینده فقط روز و ماه همین تاریخ تکرار می‌شود؛ در سال‌های غیرکبیسه، آخرین روز ماه انتخاب می‌شود."),UiKit.matchWrap(this,0,8));
        note=input("یادداشت اختیاری");card.addView(note,UiKit.matchWrap(this,0,6));
        LinearLayout alerts=NexaReminderUi.formSection(this,"🔔 هشدار سالانه","هر سال بدون نیاز به ثبت دوباره");
        root.addView(alerts,UiKit.matchWrap(this,12,0));
        timeButton=UiKit.secondaryButton(this,"");timeButton.setOnClickListener(v->PersianDatePickerHelper.pickTime(this,hour,minute,"ساعت هشدار",(h,m)->{hour=h;minute=m;updateTime();}));
        alerts.addView(UiKit.fieldLabel(this,"ساعت هشدار در روز مناسبت"));alerts.addView(timeButton,UiKit.matchWrap(this,0,8));
        before1=check("۱ روز قبل هم اطلاع بده",editing==null||editing.oneDay);
        before3=check("۳ روز قبل هم اطلاع بده",editing!=null&&editing.threeDays);
        before7=check("۷ روز قبل هم اطلاع بده",editing!=null&&editing.sevenDays);
        enabled=check("مناسبت فعال باشد",editing==null||editing.active);
        alerts.addView(before1);alerts.addView(before3);alerts.addView(before7);alerts.addView(enabled);
        root.addView(UiKit.muted(this,"آلارم روز مناسبت همیشه فعال است. صدای هشدار از تنظیمات عمومی نکسا استفاده می‌کند."),UiKit.matchWrap(this,11,6));
        Button save=UiKit.primaryButton(this,"✓ ذخیره مناسبت و فعال‌سازی تکرار سالانه");
        save.setOnClickListener(v->save());root.addView(save,UiKit.matchWrap(this,9,0));
        if(editing!=null){title.setText(editing.title);note.setText(editing.note);type.setSelection(index(values,editing.type));}
        if(formState!=null){title.setText(formState.getString("titleText",title.getText().toString()));
            note.setText(formState.getString("noteText",note.getText().toString()));
            type.setSelection(formState.getInt("typeIndex",type.getSelectedItemPosition()));
            before1.setChecked(formState.getBoolean("oneDay",before1.isChecked()));
            before3.setChecked(formState.getBoolean("threeDays",before3.isChecked()));
            before7.setChecked(formState.getBoolean("sevenDays",before7.isChecked()));
            enabled.setChecked(formState.getBoolean("enabled",enabled.isChecked()));}
        calendar.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> parent,View v,int position,long id){
                String selected=calendarValue();
                if(!selected.equals(currentCalendar)){
                    Calendar now=Calendar.getInstance();
                    if("gregorian".equals(selected)){year=now.get(Calendar.YEAR);month=now.get(Calendar.MONTH)+1;day=now.get(Calendar.DAY_OF_MONTH);}
                    else{int[] j=PersianDateUtil.fromMillis(System.currentTimeMillis());year=j[0];month=j[1];day=j[2];}
                    currentCalendar=selected;
                }
                updateDate();
            }
            @Override public void onNothingSelected(AdapterView<?> parent){}
        });
        updateDate();updateTime();setContentView(sc);
    }
    private CheckBox check(String text,boolean value){
        CheckBox c=new CheckBox(this);c.setText(text);c.setTextColor(UiKit.TEXT);c.setTextSize(14f);
        c.setMinHeight(UiKit.dp(this,44));c.setChecked(value);return c;
    }
    private void updateDate(){if(dateButton!=null)dateButton.setText("📅  "+year+" / "+month+" / "+day+"  •  "+("gregorian".equals(currentCalendar)?"میلادی":"شمسی"));}
    private void updateTime(){if(timeButton!=null)timeButton.setText(String.format(Locale.US,"🕒  %02d:%02d",hour,minute));}
    private void pickOriginalDate(){
        final String kind=calendarValue();
        LinearLayout box=UiKit.dialogPanel(this);
        box.addView(UiKit.muted(this,"تاریخ واقعی تولد، ازدواج یا فوت را حتی اگر مربوط به گذشته است انتخاب کنید."),UiKit.matchWrap(this,0,10));
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        NumberPicker yearPicker=new NumberPicker(this),monthPicker=new NumberPicker(this),dayPicker=new NumberPicker(this);
        int minimum="gregorian".equals(kind)?1800:1250,maximum="gregorian".equals(kind)?2100:1600;
        yearPicker.setMinValue(minimum);yearPicker.setMaxValue(maximum);yearPicker.setValue(Math.max(minimum,Math.min(maximum,year)));
        monthPicker.setMinValue(1);monthPicker.setMaxValue(12);monthPicker.setValue(month);
        dayPicker.setMinValue(1);dayPicker.setMaxValue(maxDay(kind,yearPicker.getValue(),month));dayPicker.setValue(Math.min(day,dayPicker.getMaxValue()));
        row.addView(dayPicker,new LinearLayout.LayoutParams(0,-2,1f));
        row.addView(monthPicker,new LinearLayout.LayoutParams(0,-2,1f));
        row.addView(yearPicker,new LinearLayout.LayoutParams(0,-2,1.2f));box.addView(row);
        Runnable refresh=()->{
            int max=maxDay(kind,yearPicker.getValue(),monthPicker.getValue());
            if(dayPicker.getValue()>max)dayPicker.setValue(max);
            dayPicker.setMaxValue(max);
        };
        yearPicker.setOnValueChangedListener((p,o,n)->refresh.run());monthPicker.setOnValueChangedListener((p,o,n)->refresh.run());
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("تاریخ اصلی مناسبت ("+("gregorian".equals(kind)?"میلادی":"شمسی")+")")
            .setView(box).setPositiveButton("تأیید",(d,w)->{year=yearPicker.getValue();month=monthPicker.getValue();day=dayPicker.getValue();updateDate();})
            .setNegativeButton("انصراف",null).create();dlg.show();
    }
    private int maxDay(String kind,int yy,int mm){return "gregorian".equals(kind)?AnnualOccasionDates.gregorianDays(yy,mm):PersianDateUtil.monthLength(yy,mm);}
    private void save(){
        String name=title.getText().toString().trim();if(name.isEmpty()){title.setError("عنوان را وارد کن");return;}
        String cal=calendarValue();if(!AnnualOccasionDates.valid(cal,year,month,day)){Toast.makeText(this,"تاریخ مناسبت صحیح نیست",Toast.LENGTH_LONG).show();return;}
        OccasionStore.Occasion e=editing==null?new OccasionStore.Occasion():editing;
        OccasionScheduler.cancel(this,e);
        e.title=name;e.note=note.getText().toString().trim();e.type=values[type.getSelectedItemPosition()];
        e.calendar=cal;e.year=year;e.month=month;e.day=day;e.hour=hour;e.minute=minute;
        e.oneDay=before1.isChecked();e.threeDays=before3.isChecked();e.sevenDays=before7.isChecked();e.active=enabled.isChecked();
        OccasionStore.save(this,e);OccasionScheduler.schedule(this,e);
        NexaStore.addHistory(this,"مناسبت",(editing==null?"ثبت: ":"ویرایش: ")+name);
        TodayNotificationManager.refresh(this);finish();
    }
}
