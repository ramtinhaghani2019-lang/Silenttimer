package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class DocsActivity extends Activity {
    private LinearLayout list, metricsBox, quickFilters;
    private TextView summary;
    private String filter="همه";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 250);
        }
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,26));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        root.addView(UiKit.header(this,"اسناد و مدارک",v->finish()),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"مدارک مهم و تمدیدها، یک‌جا و در دسترس"),UiKit.matchWrap(this,0,12));

        LinearLayout hero=UiKit.colorfulCardLayout(this,1);
        hero.addView(UiKit.sectionTitle(this,"📄 مدارک و تمدیدها"));
        hero.addView(UiKit.muted(this,"هشدار پیش‌فرض: ۳۰ روز، ۷ روز، ۱ روز قبل و روز انقضا."),UiKit.matchWrap(this,6,10));
        Button add=UiKit.primaryButton(this,"＋ ثبت مدرک");
        add.setOnClickListener(v->addDialog());
        hero.addView(add);
        root.addView(hero,UiKit.matchWrap(this,0,10));
        metricsBox=new LinearLayout(this);metricsBox.setOrientation(LinearLayout.VERTICAL);
        root.addView(metricsBox,UiKit.matchWrap(this,0,10));
        summary=UiKit.muted(this,"");root.addView(summary,UiKit.matchWrap(this,0,8));
        quickFilters=new LinearLayout(this);quickFilters.setGravity(Gravity.CENTER_VERTICAL);
        quickFilters.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.addView(quickFilters,UiKit.matchWrap(this,0,12));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint){return UiKit.styleField(this,new EditText(this),hint);}

    private void addDialog() { editDialog(null); }
    private void editDialog(NexaStore.DocumentItem existing) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        Spinner type=UiKit.styledSpinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"کارت ملی","گواهینامه","پاسپورت","بیمه","معاینه فنی","قرارداد","مجوز","سایر"}
        ));

        EditText title=field("عنوان مدرک");
        EditText number=field("شماره / شناسه");
        EditText note=field("توضیحات");

        final long[] issue={System.currentTimeMillis()};
        final long[] expiry={System.currentTimeMillis()+365L*24L*60L*60L*1000L};

        Button issueBtn=UiKit.secondaryButton(this,"تاریخ صدور: "+PersianDateUtil.pretty(issue[0]));
        issueBtn.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,issue[0],"تاریخ و ساعت صدور",ms->{issue[0]=ms;issueBtn.setText("تاریخ صدور: "+PersianDateUtil.pretty(ms));}));

        Button expiryBtn=UiKit.secondaryButton(this,"تاریخ انقضا: "+PersianDateUtil.pretty(expiry[0]));
        expiryBtn.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,expiry[0],"تاریخ و ساعت انقضا",ms->{expiry[0]=ms;expiryBtn.setText("تاریخ انقضا: "+PersianDateUtil.pretty(ms));}));

        box.addView(NexaCareUi.formHeading(this,"📄 اطلاعات مدرک"));
        box.addView(UiKit.fieldLabel(this,"نوع مدرک"));box.addView(type);
        box.addView(UiKit.fieldLabel(this,"عنوان"));box.addView(title);
        box.addView(UiKit.fieldLabel(this,"شماره یا شناسه"));box.addView(number);
        box.addView(UiKit.fieldLabel(this,"یادداشت"));box.addView(note);
        box.addView(NexaCareUi.formHeading(this,"📆 زمان و تمدید"));
        box.addView(issueBtn);box.addView(expiryBtn);
        RepeatIntervalPicker interval=new RepeatIntervalPicker(this,box,existing==null?"none":existing.recurrence);
        if(existing!=null){type.setSelection(Math.max(0,java.util.Arrays.asList("کارت ملی","گواهینامه","پاسپورت","بیمه","معاینه فنی","قرارداد","مجوز","سایر").indexOf(existing.type)));
        title.setText(existing.title);number.setText(existing.number);note.setText(existing.note);
        issue[0]=existing.issueDate;expiry[0]=existing.expiryDate;
        issueBtn.setText("تاریخ صدور: "+PersianDateUtil.pretty(issue[0]));expiryBtn.setText("تاریخ انقضا: "+PersianDateUtil.pretty(expiry[0]));}
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"43200,10080,1440,0":existing.alertRules,existing==null?5:existing.alertRepeat);

        ScrollView formScroll=new ScrollView(this);formScroll.setFillViewport(false);formScroll.addView(box);
        new AlertDialog.Builder(this)
                .setTitle(existing==null?"مدرک جدید":"ویرایش مدرک")
                .setView(formScroll)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(type.getSelectedItem());

                    NexaStore.DocumentItem x=existing==null?new NexaStore.DocumentItem():existing;
                    x.alertRules=alerts.rules();x.alertRepeat=alerts.repeatMinutes();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.number=number.getText().toString().trim();
                    x.note=note.getText().toString().trim();
                    x.issueDate=issue[0];
                    x.expiryDate=expiry[0];x.recurrence=interval.rule();

                    if(existing==null)NexaStore.addDocument(this,x);else NexaStore.updateDocument(this,x);
                    LinkedReminderHelper.upsert(
                            this,
                            "doc:"+x.id,
                            "تمدید "+x.title,
                            "مدارک",
                            "📄",
                            x.number.isEmpty()?x.note:("شماره: "+x.number+" • "+x.note),
                            x.expiryDate,
                            x.alertRules,
                            x.alertRepeat,
                            x.recurrence
                    );
                    NexaStore.addHistory(this,"مدارک","ثبت شد: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    /** Fast filter chips retain the four original filter values and do not touch stored documents. */
    private void showQuickFilters(){
        quickFilters.removeAllViews();
        for(String item:new String[]{"همه","منقضی","۳۰ روز","معتبر"}){
            TextView chip=NexaCareUi.filter(this,item,item.equals(filter));
            chip.setOnClickListener(v->{filter=item;render();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,UiKit.dp(this,44),1f);
            if(quickFilters.getChildCount()>0)lp.leftMargin=UiKit.dp(this,5);
            quickFilters.addView(chip,lp);
        }
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.DocumentItem> data=NexaStore.documents(this);

        long now=System.currentTimeMillis();
        int expired=0, soon=0, valid=0;
        for(NexaStore.DocumentItem x:data){long d=TimeUnit.MILLISECONDS.toDays(x.expiryDate-now);if(d<0)expired++;else if(d<=30)soon++;else valid++;}
        metricsBox.removeAllViews();
        metricsBox.addView(NexaCareUi.metrics(this,new String[]{"منقضی","تا ۳۰ روز","معتبر"},
                new int[]{expired,soon,valid},new int[]{UiKit.RED,UiKit.GOLD,UiKit.GREEN}));
        summary.setText("مجموع "+data.size()+" مدرک • برای ویرایش، از دکمه کنار هر مورد استفاده کن");
        showQuickFilters();
        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"هنوز مدرکی ثبت نشده؛ از دکمه ثبت مدرک شروع کن.");
            e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));return;
        }
        int shown=0;
        for(NexaStore.DocumentItem x:data){
            long days=TimeUnit.MILLISECONDS.toDays(x.expiryDate-now);
            if("منقضی".equals(filter) && days>=0)continue;
            if("۳۰ روز".equals(filter) && (days<0 || days>30))continue;
            if("معتبر".equals(filter) && days<=30)continue;
            shown++;
            LinearLayout c=NexaCareUi.record(this,days<0,days>=0&&days<=30);
            c.addView(UiKit.sectionTitle(this,"📄 "+x.title));
            c.addView(UiKit.muted(this,x.type+" • انقضا "+PersianDateUtil.format(x.expiryDate)+ReminderRecurrence.labelSuffix(x.recurrence)),UiKit.matchWrap(this,5,8));
            String stateText=days<0?"منقضی • "+Math.abs(days)+" روز گذشته":
                    days<=30?"نیاز به تمدید • "+days+" روز":"معتبر • "+days+" روز باقی‌مانده";
            c.addView(NexaCareUi.state(this,stateText,days<0?UiKit.RED:days<=30?UiKit.GOLD:UiKit.GREEN));

            if(!x.number.isEmpty())c.addView(UiKit.muted(this,"شماره: "+x.number),UiKit.matchWrap(this,4,0));
            if(!x.note.isEmpty())c.addView(UiKit.muted(this,x.note),UiKit.matchWrap(this,4,0));

            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editDialog(x));
            LinearLayout iconActions=new LinearLayout(this);iconActions.setGravity(Gravity.CENTER_VERTICAL);iconActions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
            Button del=UiKit.deleteIconButton(this);
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                .setMessage(x.title).setPositiveButton("حذف",(d,w)->{
                LinkedReminderHelper.remove(this,"doc:"+x.id);
                NexaStore.removeDocument(this,x.id);render();
                }).setNegativeButton("انصراف",null).show());
            LinearLayout.LayoutParams idlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));idlp.setMargins(UiKit.dp(this,5),0,0,0);iconActions.addView(del,idlp);c.addView(iconActions,UiKit.matchWrap(this,8,0));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
        if(shown==0){TextView e=UiKit.muted(this,"مدرکی برای این فیلتر وجود ندارد.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));}
    }
}
