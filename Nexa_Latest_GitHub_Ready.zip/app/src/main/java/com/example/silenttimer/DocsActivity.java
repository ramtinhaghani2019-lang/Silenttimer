package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class DocsActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private String filter="همه";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 250);
        }
    }

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"اسناد و مدارک"),UiKit.matchWrap(this,0,4));
        root.addView(UiKit.muted(this,"مدارک مهم، تاریخ انقضا و هشدار تمدید"),UiKit.matchWrap(this,0,14));

        LinearLayout hero=UiKit.colorfulCardLayout(this,1);
        hero.addView(UiKit.sectionTitle(this,"📄 مدارک و تمدیدها"));
        hero.addView(UiKit.muted(this,"هشدار پیش‌فرض: ۳۰ روز، ۷ روز، ۱ روز قبل و روز انقضا."),UiKit.matchWrap(this,6,10));
        Button add=UiKit.primaryButton(this,"＋ ثبت مدرک");
        add.setOnClickListener(v->addDialog());
        hero.addView(add);
        root.addView(hero,UiKit.matchWrap(this,0,10));
        summary=UiKit.muted(this,""); root.addView(summary,UiKit.matchWrap(this,0,8));
        LinearLayout filters=new LinearLayout(this); filters.setGravity(Gravity.CENTER_VERTICAL);
        for(String f:new String[]{"همه","منقضی","۳۰ روز","معتبر"}){Button b=UiKit.secondaryButton(this,f);b.setOnClickListener(v->{filter=f;render();});filters.addView(b,new LinearLayout.LayoutParams(0,-2,1f));}
        root.addView(filters,UiKit.matchWrap(this,0,12));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() { editDialog(null); }
    private void editDialog(NexaStore.DocumentItem existing) {
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(UiKit.dp(this,18),UiKit.dp(this,8),UiKit.dp(this,18),0);

        Spinner type=UiKit.styledSpinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"کارت ملی","گواهینامه","پاسپورت","بیمه","معاینه فنی","قرارداد","مجوز","سایر"}
        ));

        EditText title=field("عنوان مدرک");
        EditText number=field("شماره / شناسه");
        EditText note=field("توضیحات");

        final long[] issue={System.currentTimeMillis()};
        final long[] expiry={System.currentTimeMillis()+365L*24L*60L*60L*1000L};

        Button issueBtn=UiKit.secondaryButton(this,"تاریخ صدور: "+PersianDateUtil.pretty(issue[0]));
        issueBtn.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,issue[0],"تاریخ و ساعت صدور",ms->{issue[0]=ms;issueBtn.setText("تاریخ صدور: "+PersianDateUtil.pretty(ms));}));

        Button expiryBtn=UiKit.secondaryButton(this,"تاریخ انقضا: "+PersianDateUtil.pretty(expiry[0]));
        expiryBtn.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,expiry[0],"تاریخ و ساعت انقضا",ms->{expiry[0]=ms;expiryBtn.setText("تاریخ انقضا: "+PersianDateUtil.pretty(ms));}));

        box.addView(type);box.addView(title);box.addView(number);box.addView(note);box.addView(issueBtn);box.addView(expiryBtn);
        RepeatIntervalPicker interval=new RepeatIntervalPicker(this,box,existing==null?"none":existing.recurrence);
        if(existing!=null){type.setSelection(Math.max(0,java.util.Arrays.asList("کارت ملی","گواهینامه","پاسپورت","بیمه","معاینه فنی","قرارداد","مجوز","سایر").indexOf(existing.type)));
        title.setText(existing.title);number.setText(existing.number);note.setText(existing.note);
        issue[0]=existing.issueDate;expiry[0]=existing.expiryDate;
        issueBtn.setText("تاریخ صدور: "+PersianDateUtil.pretty(issue[0]));expiryBtn.setText("تاریخ انقضا: "+PersianDateUtil.pretty(expiry[0]));}
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"43200,10080,1440,0":existing.alertRules,existing==null?5:existing.alertRepeat);

        new AlertDialog.Builder(this)
                .setTitle("مدرک جدید")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(type.getSelectedItem());

                    NexaStore.DocumentItem x=existing==null?new NexaStore.DocumentItem():existing;
                    x.alertRules=alerts.rules();x.alertRepeat=alerts.repeatMinutes();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.number=number.getText().toString().trim();
                    x.note=note.getText().toString().trim();
                    x.issueDate=issue[0];
                    x.expiryDate=expiry[0];x.recurrence=interval.rule();

                    if(existing==null)NexaStore.addDocument(this,x);else NexaStore.updateDocument(this,x);
                    LinkedReminderHelper.upsert(
                            this,
                            "doc:"+x.id,
                            "تمدید "+x.title,
                            "مدارک",
                            "📄",
                            x.number.isEmpty()?x.note:("شماره: "+x.number+" • "+x.note),
                            x.expiryDate,
                            x.alertRules,
                            x.alertRepeat,
                            x.recurrence
                    );
                    NexaStore.addHistory(this,"مدارک","ثبت شد: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void render() {
        if(list==null)return;
        list.removeAllViews();
        List<NexaStore.DocumentItem> data=NexaStore.documents(this);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"مدرکی ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        long now=System.currentTimeMillis();
        int expired=0, soon=0, valid=0;
        for(NexaStore.DocumentItem x:data){long d=TimeUnit.MILLISECONDS.toDays(x.expiryDate-now);if(d<0)expired++;else if(d<=30)soon++;else valid++;}
        if(summary!=null)summary.setText("کل: "+data.size()+"  •  منقضی: "+expired+"  •  تا ۳۰ روز: "+soon+"  •  معتبر: "+valid);
        int shown=0;
        for(NexaStore.DocumentItem x:data){
            long days=TimeUnit.MILLISECONDS.toDays(x.expiryDate-now);
            if("منقضی".equals(filter) && days>=0)continue;
            if("۳۰ روز".equals(filter) && (days<0 || days>30))continue;
            if("معتبر".equals(filter) && days<=30)continue;
            shown++;
            LinearLayout c=UiKit.colorfulCardLayout(this,days<30?3:1);
            c.addView(UiKit.sectionTitle(this,"📄 "+x.title));
            c.addView(UiKit.muted(this,x.type+" • انقضا "+PersianDateUtil.format(x.expiryDate)+ReminderRecurrence.labelSuffix(x.recurrence)),UiKit.matchWrap(this,5,2));

            TextView state=UiKit.muted(this,days>=0?(days+" روز تا انقضا"):("منقضی شده • "+Math.abs(days)+" روز گذشته"));
            state.setTextColor(days<0?UiKit.PINK:(days<30?UiKit.GOLD:UiKit.TEAL));
            c.addView(state);

            if(!x.number.isEmpty())c.addView(UiKit.muted(this,"شماره: "+x.number),UiKit.matchWrap(this,4,0));
            if(!x.note.isEmpty())c.addView(UiKit.muted(this,x.note),UiKit.matchWrap(this,4,0));

            Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->editDialog(x));
            LinearLayout iconActions=new LinearLayout(this);iconActions.setGravity(Gravity.CENTER_VERTICAL);iconActions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
            Button del=UiKit.deleteIconButton(this);
            del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                .setMessage(x.title).setPositiveButton("حذف",(d,w)->{
                LinkedReminderHelper.remove(this,"doc:"+x.id);
                NexaStore.removeDocument(this,x.id);render();
                }).setNegativeButton("انصراف",null).show());
            LinearLayout.LayoutParams idlp=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));idlp.setMargins(UiKit.dp(this,5),0,0,0);iconActions.addView(del,idlp);c.addView(iconActions,UiKit.matchWrap(this,8,0));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
        if(shown==0){TextView e=UiKit.muted(this,"مدرکی برای این فیلتر وجود ندارد.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));}
    }
}
