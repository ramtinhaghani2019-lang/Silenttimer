package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Consistent, compact Jalali recurrence editor across payment and reminder screens. */
public final class RepeatIntervalPicker {
    private final Activity activity;
    private String rule;
    private final Button button;
    private static final String[] OPTIONS={"بدون تکرار", "روزانه", "هفتگی", "ماهانه (شمسی)", "سالانه (شمسی)"};
    private static final String[] UNITS={"none", "day", "week", "month", "year"};
    public RepeatIntervalPicker(Activity activity, LinearLayout holder, String current) {
        this.activity=activity;
        rule=ReminderRecurrence.normalize(current);
        button=UiKit.secondaryButton(activity, "");
        update();
        holder.addView(UiKit.muted(activity, "تکرار پرداخت یا یادآوری"), UiKit.matchWrap(activity, 6, 2));
        holder.addView(button, UiKit.matchWrap(activity, 0, 8));
        button.setOnClickListener(v->show());
    }
    public String rule(){return rule;}
    private void update(){button.setText("↻  "+ReminderRecurrence.label(rule)+"  ▾");}
    private int selected(){
        String u=ReminderRecurrence.unit(rule);
        if("gregorian-month".equals(u))return 3;
        for(int i=0;i<UNITS.length;i++)if(UNITS[i].equals(u))return i;
        return 0;
    }
    private void show(){
        // Preserve older Gregorian schedules until the user explicitly changes them.
        new AlertDialog.Builder(activity).setTitle("تکرار چند وقت یک‌بار باشد؟")
                .setSingleChoiceItems(OPTIONS, selected(), (d,choice)->{
                    d.dismiss();
                    if(choice==0){rule="none";update();return;}
                    showInterval(choice);
                }).setNegativeButton("انصراف",null).show();
    }
    private void showInterval(int choice){
        String unit=UNITS[choice];
        int previous=unit.equals(ReminderRecurrence.unit(rule))?Math.max(1,ReminderRecurrence.interval(rule)):1;
        LinearLayout box=UiKit.dialogPanel(activity);
        TextView explanation=UiKit.sectionTitle(activity,"هر چند "+new String[]{"", "روز", "هفته", "ماه", "سال"}[choice]+" یک‌بار؟");
        box.addView(explanation,UiKit.matchWrap(activity,0,6));
        EditText number=UiKit.styleField(activity,new EditText(activity),"مثلاً ۲");
        number.setInputType(InputType.TYPE_CLASS_NUMBER);
        number.setSingleLine(true);
        number.setText(String.valueOf(previous));
        box.addView(number,UiKit.matchWrap(activity,0,8));
        TextView preview=UiKit.muted(activity,"");
        box.addView(preview,UiKit.matchWrap(activity,0,4));
        Runnable updatePreview=()->{
            int n=readInterval(number,1);
            preview.setText("نتیجه: "+ReminderRecurrence.label("every:"+n+":"+unit)
                +(choice>=3?" • بر اساس تقویم شمسی":" • با حفظ ساعت ثبت‌شده"));
        };
        number.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){updatePreview.run();}
            public void afterTextChanged(android.text.Editable e){}
        });
        updatePreview.run();
        AlertDialog dialog=new AlertDialog.Builder(activity).setTitle(OPTIONS[choice])
            .setView(box).setPositiveButton("تأیید",null).setNegativeButton("انصراف",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int n=readInterval(number,0);
            int max=choice==1?3650:choice==2?520:choice==3?120:20;
            if(n<1||n>max){number.setError("عددی بین ۱ و "+max+" وارد کن");return;}
            rule="every:"+n+":"+unit;
            update();dialog.dismiss();
        }));
        dialog.show();
    }
    private static int readInterval(EditText input,int fallback){
        try {return Integer.parseInt(input.getText().toString().trim());}
        catch(Exception e){return fallback;}
    }
}
