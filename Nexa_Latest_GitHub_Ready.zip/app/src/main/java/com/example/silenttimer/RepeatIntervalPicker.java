package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

/** One RTL recurrence selector shared by all date-bearing editors. */
public final class RepeatIntervalPicker {
    private final Activity activity;
    private String rule;
    private final Button button;
    public RepeatIntervalPicker(Activity activity,LinearLayout holder,String current){
        this.activity=activity;this.rule=ReminderRecurrence.normalize(current);
        button=UiKit.secondaryButton(activity,"");update();
        holder.addView(UiKit.muted(activity,"تکرار خودکار کار / قرار"),UiKit.matchWrap(activity,5,2));
        holder.addView(button,UiKit.matchWrap(activity,0,8));
        button.setOnClickListener(v->show());
    }
    public String rule(){return rule;}
    private void update(){button.setText("🔁 "+ReminderRecurrence.label(rule)+"  ▾");}
    private void show(){
        LinearLayout box=UiKit.dialogPanel(activity);
        Spinner units=UiKit.styledSpinner(activity);
        String[] labels={"بدون تکرار","هر چند روز","هر چند هفته","هر چند ماه شمسی","هر چند سال شمسی"};
        String[] codes={"none","day","week","month","year"};
        units.setAdapter(new ArrayAdapter<>(activity,android.R.layout.simple_spinner_dropdown_item,labels));
        String unit=ReminderRecurrence.unit(rule);int selected=0;
        for(int i=1;i<codes.length;i++)if(codes[i].equals(unit)){selected=i;break;}
        if("gregorian-month".equals(unit))selected=3;
        units.setSelection(selected);
        EditText quantity=UiKit.styleField(activity,new EditText(activity),"هر چند بار؟ مثلاً ۲ برای یک هفته در میان");
        quantity.setInputType(InputType.TYPE_CLASS_NUMBER);
        quantity.setText(String.valueOf(Math.max(1,ReminderRecurrence.interval(rule))));
        box.addView(UiKit.muted(activity,"واحد تکرار"),UiKit.matchWrap(activity,0,4));
        box.addView(units,UiKit.matchWrap(activity,0,8));
        box.addView(UiKit.muted(activity,"فاصله: برای «یک هفته در میان» عدد ۲ و واحد هفته را انتخاب کن."),UiKit.matchWrap(activity,0,4));
        box.addView(quantity,UiKit.matchWrap(activity,0,6));
        box.addView(UiKit.muted(activity,"ماه و سال بر اساس تقویم شمسی محاسبه می‌شوند. روز و هفته ساعت قرار را حفظ می‌کنند."),UiKit.matchWrap(activity,0,4));
        new AlertDialog.Builder(activity).setTitle("تنظیم تکرار").setView(box)
          .setPositiveButton("تأیید",(dialog,which)->{
             int idx=units.getSelectedItemPosition();
             if(idx<=0){rule="none";update();return;}
             int value=1;try{value=Integer.parseInt(quantity.getText().toString().trim());}catch(Exception ignored){}
             int max=idx==1?3650:idx==2?520:idx==3?120:20;
             value=Math.max(1,Math.min(max,value));
             rule="every:"+value+":"+codes[idx];update();
          }).setNegativeButton("انصراف",null).show();
    }
}
