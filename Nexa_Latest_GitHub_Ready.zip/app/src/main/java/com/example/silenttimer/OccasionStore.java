package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Separate, backward-compatible storage: no changes to Nexa's existing reminders. */
public final class OccasionStore {
    private static final String PREF="nexa_annual_occasions";
    private OccasionStore(){}
    public static final class Occasion {
        public String id=UUID.randomUUID().toString(), title="", type="birthday", calendar="jalali", note="";
        public int year=1400,month=1,day=1,hour=9,minute=0;
        public boolean active=true, oneDay=true,threeDays=false,sevenDays=false;
        public String icon(){return "birthday".equals(type)?"🎂":"marriage".equals(type)?"💍":"memorial".equals(type)?"🕯️":"📅";}
        public String typeLabel(){return "birthday".equals(type)?"تولد":"marriage".equals(type)?"سالگرد ازدواج":"memorial".equals(type)?"سالگرد فوت":"مناسبت شخصی";}
        JSONObject json()throws Exception{
            JSONObject o=new JSONObject();o.put("id",id);o.put("title",title);o.put("type",type);o.put("calendar",calendar);
            o.put("note",note);o.put("year",year);o.put("month",month);o.put("day",day);o.put("hour",hour);o.put("minute",minute);
            o.put("active",active);o.put("oneDay",oneDay);o.put("threeDays",threeDays);o.put("sevenDays",sevenDays);return o;
        }
        static Occasion from(JSONObject o){
            Occasion e=new Occasion();e.id=o.optString("id",e.id);e.title=o.optString("title","");
            e.type=o.optString("type","personal");e.calendar=o.optString("calendar","jalali");e.note=o.optString("note","");
            e.year=o.optInt("year",1400);e.month=o.optInt("month",1);e.day=o.optInt("day",1);
            e.hour=o.optInt("hour",9);e.minute=o.optInt("minute",0);
            e.active=o.optBoolean("active",true);e.oneDay=o.optBoolean("oneDay",true);
            e.threeDays=o.optBoolean("threeDays",false);e.sevenDays=o.optBoolean("sevenDays",false);return e;
        }
    }
    public static List<Occasion> all(Context c){
        ArrayList<Occasion> out=new ArrayList<>();
        try{JSONArray a=new JSONArray(c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("items","[]"));
            for(int i=0;i<a.length();i++){Occasion e=Occasion.from(a.getJSONObject(i));if(AnnualOccasionDates.valid(e.calendar,e.year,e.month,e.day))out.add(e);}
        }catch(Exception ignored){}return out;
    }
    private static void write(Context c,List<Occasion> data){
        JSONArray a=new JSONArray();for(Occasion e:data)try{a.put(e.json());}catch(Exception ignored){}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("items",a.toString()).apply();
    }
    public static Occasion find(Context c,String id){
        if(id==null)return null;for(Occasion e:all(c))if(id.equals(e.id))return e;return null;
    }
    public static void save(Context c,Occasion e){
        List<Occasion> all=all(c);for(int i=0;i<all.size();i++)if(all.get(i).id.equals(e.id)){all.set(i,e);write(c,all);return;}
        all.add(e);write(c,all);
    }
    public static void delete(Context c,String id){
        List<Occasion> all=all(c);all.removeIf(e->e.id.equals(id));write(c,all);
    }
}
