package com.example.silenttimer;

import android.content.Context;
import android.content.pm.PackageInfo;

public final class VersionUtil {
    private VersionUtil(){}
    public static String name(Context c){
        try{
            PackageInfo p=c.getPackageManager().getPackageInfo(c.getPackageName(),0);
            return p.versionName==null?"":p.versionName;
        }catch(Exception e){return "";}
    }
}
