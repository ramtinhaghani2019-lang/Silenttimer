package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class BillsActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private TextView forecastTotals;
    private LinearLayout forecastRows;
    private int forecastDays=30;
    private String filter="همه";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            list.postDelayed(this::addDialog, 250);
        }
    }

    @Override protected void onResume(){super.onResume();render();}

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"قبوض و پرداخت‌ها"),UiKit.matchWrap(this,0,4));


        Button add=UiKit.primaryButton(this,"＋ پرداخت جدید");
        add.setOnClickListener(v->addDialog());
        root.addView(add,UiKit.matchWrap(this,0,7));

        summary=UiKit.muted(this,"");
        root.addView(summary,UiKit.matchWrap(this,0,8));

        LinearLayout forecastCard=UiKit.colorfulCardLayout(this,3);
        forecastCard.addView(UiKit.sectionTitle(this,"📅 پیش‌بینی تعهدات مالی"));

        LinearLayout periodButtons=new LinearLayout(this);
        for(final int days:new int[]{30,90}){
            Button period=UiKit.secondaryButton(this,days+" روز آینده");
            period.setOnClickListener(v->{forecastDays=days;render();});
            periodButtons.addView(period,new LinearLayout.LayoutParams(0,-2,1f));
        }
        forecastCard.addView(periodButtons,UiKit.matchWrap(this,2,6));
        forecastTotals=UiKit.muted(this,"");
        forecastCard.addView(forecastTotals,UiKit.matchWrap(this,4,5));
        forecastRows=new LinearLayout(this);forecastRows.setOrientation(LinearLayout.VERTICAL);
        forecastCard.addView(forecastRows,UiKit.matchWrap(this,4,0));
        Button showForecast=UiKit.secondaryButton(this,"پیش‌بینی و گزارش  ▾");
        forecastCard.setVisibility(View.GONE);
        showForecast.setOnClickListener(v->{boolean show=forecastCard.getVisibility()!=View.VISIBLE;
            forecastCard.setVisibility(show?View.VISIBLE:View.GONE);
            showForecast.setText(show?"بستن گزارش  ▴":"پیش‌بینی و گزارش  ▾");});
        root.addView(showForecast,UiKit.matchWrap(this,0,6));
        root.addView(forecastCard,UiKit.matchWrap(this,0,5));

        LinearLayout filters=new LinearLayout(this); filters.setGravity(Gravity.CENTER_VERTICAL);
        for(String f:new String[]{"همه","معوق","آینده","پرداخت‌شده"}){ Button b=UiKit.secondaryButton(this,f); b.setOnClickListener(v->{filter=f;render();}); filters.addView(b,new LinearLayout.LayoutParams(0,-2,1f)); }
        root.addView(filters,UiKit.matchWrap(this,0,12));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() { editDialog(null); }
    private void editDialog(NexaStore.BillItem existing) {
        LinearLayout box=UiKit.dialogPanel(this);

        Spinner type=UiKit.styledSpinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"قسط","قبض","اجاره","اشتراک","بیمه","چک","سایر"}
        ));

        EditText title=field("عنوان؛ مثلاً قسط وام");
        EditText amount=field("مبلغ تومان");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(amount);
        EditText note=field("توضیحات");
        final String[] sellerId={existing==null?"":existing.sellerId};
        final String[] bankCardId={existing==null?"":existing.bankCardId};
        Button sellerBtn=UiKit.secondaryButton(this,"فروشنده / دریافت‌کننده: انتخاب نشده");
        NexaStore.ShoppingSeller oldSeller=existing==null?null:NexaStore.sellerById(this,existing.sellerId);if(oldSeller!=null)sellerBtn.setText("فروشنده / دریافت‌کننده: "+oldSeller.name);
        sellerBtn.setOnClickListener(v->pickSeller(sellerId,sellerBtn));
        Button cardBtn=UiKit.secondaryButton(this,"کارت پرداخت: انتخاب نشده");
        NexaStore.BankCard oldCard=existing==null?null:NexaStore.bankCardById(this,existing.bankCardId);if(oldCard!=null)cardBtn.setText("کارت پرداخت: "+oldCard.display());
        cardBtn.setOnClickListener(v->pickCard(bankCardId,cardBtn));

        // Recurrence uses the same interval selector as reminders and other deadlines.
        final long[] due={System.currentTimeMillis()+24L*60L*60L*1000L};
        Button date=UiKit.secondaryButton(this,"سررسید: "+PersianDateUtil.pretty(due[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,due[0],"تاریخ و ساعت سررسید",ms->{due[0]=ms;date.setText("سررسید: "+PersianDateUtil.pretty(ms));}));

        box.addView(type);box.addView(title);box.addView(amount);box.addView(note);box.addView(sellerBtn);box.addView(cardBtn);box.addView(date);
        RepeatIntervalPicker repeat=new RepeatIntervalPicker(this,box,existing==null?"none":existing.recurrence);
        if(existing!=null){type.setSelection(Math.max(0,java.util.Arrays.asList("قسط","قبض","اجاره","اشتراک","بیمه","چک","سایر").indexOf(existing.type)));
        title.setText(existing.title);amount.setText(NumberFormatUtil.grouped(existing.amount));note.setText(existing.note);
        
        due[0]=existing.dueDate;date.setText("سررسید: "+PersianDateUtil.pretty(due[0]));}
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"1440,120,0":existing.alertRules,existing==null?5:existing.alertRepeat);

        new AlertDialog.Builder(this)
                .setTitle("سررسید جدید")
                .setView(box)
                .setPositiveButton("ذخیره",(d,w)->{
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(type.getSelectedItem());

                    NexaStore.BillItem x=existing==null?new NexaStore.BillItem():existing;
                    x.alertRules=alerts.rules();x.alertRepeat=alerts.repeatMinutes();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.amount=NumberFormatUtil.longValue(amount.getText());
                    x.recurrence=repeat.rule();
                    x.note=note.getText().toString().trim();
                    x.sellerId=sellerId[0];x.bankCardId=bankCardId[0];
                    x.dueDate=due[0];
                    if(existing==null)NexaStore.addBill(this,x);else NexaStore.updateBill(this,x);
                    schedule(x);
                    NexaStore.addHistory(this,"پرداخت","ثبت شد: "+x.title);
                    render();
                })
                .setNegativeButton("انصراف",null)
                .show();
    }

    private void schedule(NexaStore.BillItem x) {
        LinkedReminderHelper.upsert(
                this,
                "bill:"+x.id,
                x.title,
                x.type,
                "💳",
                (x.amount>0?String.format(Locale.US,"%,d تومان",x.amount):"")+(x.note.isEmpty()?"":" • "+x.note),
                x.dueDate,
                x.alertRules,
                            x.alertRepeat
        );
    }

    private void markPaid(NexaStore.BillItem x) {
        if(ReminderRecurrence.isRecurring(x.recurrence)){
            x.dueDate=ReminderRecurrence.after(x.dueDate,x.recurrence,System.currentTimeMillis());
            x.paid=false;
            NexaStore.updateBill(this,x);
            schedule(x);
            NexaStore.addHistory(this,"پرداخت","پرداخت شد و سررسید بعدی ثبت شد: "+x.title);
        }else{
            x.paid=true;
            NexaStore.updateBill(this,x);
            LinkedReminderHelper.remove(this,"bill:"+x.id);
            NexaStore.addHistory(this,"پرداخت","پرداخت شد: "+x.title);
        }
        render();
    }

    private void pickSeller(String[] out,Button btn){java.util.List<NexaStore.ShoppingSeller> data=NexaStore.sellers(this);LinearLayout box=UiKit.dialogPanel(this);if(data.isEmpty())box.addView(UiKit.muted(this,"فروشنده‌ای ثبت نشده؛ از تنظیمات > دفتر مشترک اضافه کن."));for(NexaStore.ShoppingSeller s:data){Button b=UiKit.secondaryButton(this,s.name+(s.category.isEmpty()?"":" • "+s.category));b.setOnClickListener(v->{out[0]=s.id;btn.setText("فروشنده / دریافت‌کننده: "+s.name);});box.addView(b,UiKit.matchWrap(this,0,5));}new AlertDialog.Builder(this).setTitle("انتخاب از دفتر مشترک").setView(box).setPositiveButton("بستن",null).show();}
    private void pickCard(String[] out,Button btn){java.util.List<NexaStore.BankCard> data=NexaStore.bankCards(this);LinearLayout box=UiKit.dialogPanel(this);if(data.isEmpty())box.addView(UiKit.muted(this,"کارتی ثبت نشده؛ از تنظیمات > دفتر مشترک اضافه کن."));for(NexaStore.BankCard c:data){Button b=UiKit.secondaryButton(this,c.display());b.setOnClickListener(v->{out[0]=c.id;btn.setText("کارت پرداخت: "+c.display());});box.addView(b,UiKit.matchWrap(this,0,5));}new AlertDialog.Builder(this).setTitle("انتخاب کارت").setView(box).setPositiveButton("بستن",null).show();}

    private void renderForecast(List<NexaStore.BillItem> bills){
        if(forecastTotals==null||forecastRows==null)return;
        forecastRows.removeAllViews();
        List<BillForecast.Entry> source=new java.util.ArrayList<>();
        for(NexaStore.BillItem x:bills)
            source.add(new BillForecast.Entry(x.id,x.title,x.type,x.amount,x.dueDate,x.recurrence,x.paid));
        long now=System.currentTimeMillis();
        BillForecast.Result forecast=BillForecast.calculate(source,now,forecastDays);
        long firstWeek=BillForecast.sumBefore(forecast.upcoming,BillForecast.horizon(now,7));
        forecastTotals.setText("۷ روز: "+NumberFormatUtil.grouped(firstWeek)+" تومان"
                +"\n"+forecastDays+" روز: "+NumberFormatUtil.grouped(forecast.upcomingTotal)+" تومان"
                +"  •  "+forecast.upcoming.size()+" سررسید"
                +"\nمعوق جداگانه: "+NumberFormatUtil.grouped(forecast.overdueTotal)+" تومان"
                +"  •  "+forecast.overdue.size()+" مورد");
        if(forecast.upcoming.isEmpty()){
            forecastRows.addView(UiKit.muted(this,"در این بازه سررسید فعالی ثبت نشده است."),UiKit.matchWrap(this,4,0));
        }else{
            int visible=Math.min(8,forecast.upcoming.size());
            for(int i=0;i<visible;i++){
                BillForecast.Occurrence occ=forecast.upcoming.get(i);
                TextView line=UiKit.muted(this,"• "+occ.title+" • "+PersianDateUtil.pretty(occ.at)
                    +" • "+NumberFormatUtil.grouped(occ.amount)+" تومان"
                    +(occ.projected?" (تکرار پیش‌بینی‌شده)":"")+"  ✎");
                line.setMinHeight(UiKit.dp(this,44));
                line.setOnClickListener(v->{
                    for(NexaStore.BillItem bill:NexaStore.bills(this)){
                        if(occ.id.equals(bill.id)){editDialog(bill);return;}
                    }
                    android.widget.Toast.makeText(this,"این مورد دیگر وجود ندارد.",android.widget.Toast.LENGTH_SHORT).show();
                    render();
                });
                forecastRows.addView(line,UiKit.matchWrap(this,7,0));
            }
            if(forecast.upcoming.size()>visible)
                forecastRows.addView(UiKit.muted(this,"و "+(forecast.upcoming.size()-visible)+" سررسید دیگر در این بازه"),UiKit.matchWrap(this,7,0));
        }
    }

    private void showBillActions(NexaStore.BillItem x){
        String[] options=x.paid?new String[]{"ویرایش","حذف"}:
            new String[]{"پرداخت شد","ویرایش","حذف"};
        new AlertDialog.Builder(this).setTitle(x.title)
            .setItems(options,(d,which)->{
                String choice=options[which];
                if("پرداخت شد".equals(choice))markPaid(x);
                else if("ویرایش".equals(choice))editDialog(x);
                else new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                    .setMessage(x.title).setPositiveButton("حذف",(dialog,w)->{
                        LinkedReminderHelper.remove(this,"bill:"+x.id);
                        NexaStore.removeBill(this,x.id);render();
                    }).setNegativeButton("انصراف",null).show();
            }).show();
    }

    private void render() {
        if(list==null)return;
        List<NexaStore.BillItem> data=NexaStore.bills(this);
        renderForecast(data);
        list.removeAllViews();
        long now=System.currentTimeMillis(), pendingTotal=0; int overdue=0, upcoming=0, paidCount=0;
        for(NexaStore.BillItem x:data){ if(x.paid){paidCount++;continue;} pendingTotal+=x.amount; if(x.dueDate<now)overdue++; else upcoming++; }
        if(summary!=null) summary.setText("در انتظار: "+NumberFormatUtil.grouped(pendingTotal)+" تومان  •  معوق: "+overdue+"  •  آینده: "+upcoming+"  •  پرداخت‌شده: "+paidCount);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"سررسیدی ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        int shown=0;
        for(NexaStore.BillItem x:data){
            boolean isOverdue=!x.paid && x.dueDate<now;
            if("معوق".equals(filter) && !isOverdue) continue;
            if("آینده".equals(filter) && (x.paid || isOverdue)) continue;
            if("پرداخت‌شده".equals(filter) && !x.paid) continue;
            shown++;
            LinearLayout c=UiKit.colorfulCardLayout(this,x.paid?2:1);
            c.setAlpha(x.paid?0.55f:1f);
            LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout labels=new LinearLayout(this);labels.setOrientation(LinearLayout.VERTICAL);
            labels.addView(UiKit.sectionTitle(this,x.title));
            labels.addView(UiKit.muted(this,PersianDateUtil.pretty(x.dueDate)+ReminderRecurrence.labelSuffix(x.recurrence)),UiKit.matchWrap(this,3,0));
            TextView amount=UiKit.muted(this,NumberFormatUtil.grouped(x.amount)+" تومان"+(x.paid?" • پرداخت‌شده":""));
            amount.setTextColor(x.paid?UiKit.GREEN:isOverdue?UiKit.RED:UiKit.GOLD);
            labels.addView(amount,UiKit.matchWrap(this,3,0));
            header.addView(labels,new LinearLayout.LayoutParams(0,-2,1f));
            Button more=UiKit.iconButton(this,"⋮","عملیات پرداخت",UiKit.GOLD);
            more.setOnClickListener(v->showBillActions(x));
            header.addView(more,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            c.addView(header);c.setOnClickListener(v->showBillActions(x));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
        if(shown==0){TextView e=UiKit.muted(this,"موردی برای این فیلتر وجود ندارد.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));}
    }
}
