package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class BillsActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    private TextView forecastTotals;
    private LinearLayout forecastRows;
    private int forecastDays=30;
    private String filter="همه";
    private Button filterButton;
    private String pendingVoiceTitle="",pendingVoiceType="",pendingVoiceRepeat="none";
    private long pendingVoiceAmount=0L;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        pendingVoiceTitle=getIntent().getStringExtra("voice_title");
        pendingVoiceType=getIntent().getStringExtra("voice_bill_type");
        pendingVoiceAmount=getIntent().getLongExtra("voice_bill_amount",0L);
        pendingVoiceRepeat=getIntent().getStringExtra("voice_repeat");
        if(pendingVoiceRepeat==null)pendingVoiceRepeat="none";
        if(pendingVoiceTitle==null)pendingVoiceTitle="";
        if(pendingVoiceType==null)pendingVoiceType="";
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            getIntent().removeExtra("quick_add");
            list.post(this::addDialog);
        }
    }

    @Override protected void onResume(){super.onResume();render();}

    private void build() {
        ScrollView sc=new ScrollView(this);
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        Button back=UiKit.backButton(this);
        back.setOnClickListener(v->finish());
        root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));

        root.addView(UiKit.title(this,"قبوض و پرداخت‌ها"),UiKit.matchWrap(this,0,4));


        Button add=UiKit.primaryButton(this,"＋ پرداخت جدید");
        add.setOnClickListener(v->addDialog());
        root.addView(add,UiKit.matchWrap(this,0,7));

        summary=UiKit.muted(this,"");
        root.addView(summary,UiKit.matchWrap(this,0,8));

        LinearLayout forecastCard=UiKit.colorfulCardLayout(this,3);
        forecastCard.addView(UiKit.sectionTitle(this,"📅 پیش‌بینی تعهدات مالی"));

        LinearLayout periodButtons=new LinearLayout(this);
        for(final int days:new int[]{30,90}){
            Button period=UiKit.secondaryButton(this,days+" روز آینده");
            period.setOnClickListener(v->{forecastDays=days;render();});
            periodButtons.addView(period,new LinearLayout.LayoutParams(0,-2,1f));
        }
        forecastCard.addView(periodButtons,UiKit.matchWrap(this,2,6));
        forecastTotals=UiKit.muted(this,"");
        forecastCard.addView(forecastTotals,UiKit.matchWrap(this,4,5));
        forecastRows=new LinearLayout(this);forecastRows.setOrientation(LinearLayout.VERTICAL);
        forecastCard.addView(forecastRows,UiKit.matchWrap(this,4,0));
        Button showForecast=UiKit.secondaryButton(this,"پیش‌بینی و گزارش  ▾");
        forecastCard.setVisibility(View.GONE);
        showForecast.setOnClickListener(v->{boolean show=forecastCard.getVisibility()!=View.VISIBLE;
            forecastCard.setVisibility(show?View.VISIBLE:View.GONE);
            showForecast.setText(show?"بستن گزارش  ▴":"پیش‌بینی و گزارش  ▾");});
        root.addView(showForecast,UiKit.matchWrap(this,0,6));
        root.addView(forecastCard,UiKit.matchWrap(this,0,5));

        filterButton=UiKit.secondaryButton(this,"⌕ فیلتر: "+filter);
        filterButton.setOnClickListener(v->new AlertDialog.Builder(this)
                .setTitle("نمایش پرداخت‌ها")
                .setSingleChoiceItems(new String[]{"همه","معوق","آینده","پرداخت‌شده"},
                        java.util.Arrays.asList("همه","معوق","آینده","پرداخت‌شده").indexOf(filter),
                        (dialog,index)->{
                            filter=new String[]{"همه","معوق","آینده","پرداخت‌شده"}[index];
                            filterButton.setText("⌕ فیلتر: "+filter);
                            dialog.dismiss();render();
                        })
                .setNegativeButton("بستن",null).show());
        root.addView(filterButton,UiKit.matchWrap(this,0,8));

        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);

        setContentView(sc);
        render();
    }

    private EditText field(String hint) {
        EditText e=new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this,14),UiKit.dp(this,12),UiKit.dp(this,14),UiKit.dp(this,12));
        return e;
    }

    private void addDialog() { editDialog(null); }
    private void editDialog(NexaStore.BillItem existing) {
        LinearLayout box=UiKit.dialogPanel(this);

        Spinner type=UiKit.styledSpinner(this);
        type.setAdapter(new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"قسط","قبض","اجاره","اشتراک","بیمه","چک","سایر"}
        ));

        EditText title=field("عنوان؛ مثلاً قسط وام");
        final boolean voiceDraft=existing==null && !pendingVoiceTitle.isEmpty();
        final long suggestedVoiceAmount=voiceDraft?pendingVoiceAmount:0L;
        final String suggestedVoiceRepeat=voiceDraft?pendingVoiceRepeat:"none";
        if(voiceDraft){
            title.setText(pendingVoiceTitle);
            pendingVoiceTitle=""; // A later manual add must start empty.
            int typeIndex=java.util.Arrays.asList("قسط","قبض","اجاره","اشتراک","بیمه","چک","سایر").indexOf(pendingVoiceType);
            if(typeIndex>=0)type.setSelection(typeIndex);
            pendingVoiceType="";
            pendingVoiceAmount=0L;
            pendingVoiceRepeat="none";
        }
        EditText amount=field(voiceDraft?"مبلغ تومان (تأیید قبل از ذخیره)":"مبلغ تومان");
        amount.setInputType(InputType.TYPE_CLASS_NUMBER);NumberFormatUtil.attachThousands(amount);
        if(suggestedVoiceAmount>0)amount.setText(NumberFormatUtil.grouped(suggestedVoiceAmount));
        EditText note=field("توضیحات");
        final String[] sellerId={existing==null?"":existing.sellerId};
        final String[] bankCardId={existing==null?"":existing.bankCardId};
        Button sellerBtn=UiKit.secondaryButton(this,"فروشنده / دریافت‌کننده: انتخاب نشده");
        NexaStore.ShoppingSeller oldSeller=existing==null?null:NexaStore.sellerById(this,existing.sellerId);if(oldSeller!=null)sellerBtn.setText("فروشنده / دریافت‌کننده: "+oldSeller.name);
        sellerBtn.setOnClickListener(v->pickSeller(sellerId,sellerBtn));
        Button cardBtn=UiKit.secondaryButton(this,"کارت مقصد: انتخاب نشده");
        NexaStore.BankCard oldCard=existing==null?null:NexaStore.bankCardById(this,existing.bankCardId);if(oldCard!=null)cardBtn.setText("کارت مقصد: "+oldCard.display());
        cardBtn.setOnClickListener(v->pickCard(bankCardId,cardBtn));

        // Recurrence uses the same interval selector as reminders and other deadlines.
        final long[] due={System.currentTimeMillis()+24L*60L*60L*1000L};
        Button date=UiKit.secondaryButton(this,"سررسید: "+PersianDateUtil.pretty(due[0]));
        date.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,due[0],"تاریخ و ساعت سررسید",ms->{due[0]=ms;date.setText("سررسید: "+PersianDateUtil.pretty(ms));}));

        box.addView(type);box.addView(title);box.addView(amount);box.addView(note);
        box.addView(UiKit.muted(this,"اطلاعات پرداخت (اختیاری)؛ با ＋ در پنجره انتخاب، شخص و کارت جدید بسازید."));
        box.addView(sellerBtn);box.addView(cardBtn);
        Button copyCard=UiKit.secondaryButton(this,"⧉ کپی شماره کارت مقصد");
        copyCard.setOnClickListener(v->android.widget.Toast.makeText(this,
            PaymentCardSecrets.copy(this,bankCardId[0])?"شماره کارت کپی شد":"برای این مورد شماره کارت کاملی ذخیره نشده است",android.widget.Toast.LENGTH_SHORT).show());
        box.addView(copyCard);box.addView(date);
        if(voiceDraft){
            box.addView(UiKit.muted(this,"پیش‌نویس صوتی: مبلغ، نوع پرداخت، تاریخ سررسید و تکرار را قبل از ذخیره بررسی کن. تاریخ پیش‌فرض فرداست."),UiKit.matchWrap(this,3,7));
        }
        RepeatIntervalPicker repeat=new RepeatIntervalPicker(this,box,existing==null?suggestedVoiceRepeat:existing.recurrence);
        if(existing!=null){type.setSelection(Math.max(0,java.util.Arrays.asList("قسط","قبض","اجاره","اشتراک","بیمه","چک","سایر").indexOf(existing.type)));
        title.setText(existing.title);amount.setText(NumberFormatUtil.grouped(existing.amount));note.setText(existing.note);
        
        due[0]=existing.dueDate;date.setText("سررسید: "+PersianDateUtil.pretty(due[0]));}
        AlertEditor alerts=new AlertEditor(this,box,existing==null?"1440,120,0":existing.alertRules,existing==null?5:existing.alertRepeat);

        ScrollView formScroll=new ScrollView(this);
        formScroll.setFillViewport(false);
        formScroll.addView(box);
        AlertDialog editor=new AlertDialog.Builder(this)
                .setTitle(existing==null?"سررسید جدید":"ویرایش سررسید")
                .setView(formScroll)
                .setPositiveButton("ذخیره",null)
                .setNegativeButton("انصراف",null)
                .create();
        editor.setOnShowListener(d->{
            Button save=editor.getButton(AlertDialog.BUTTON_POSITIVE);
            save.setOnClickListener(v->{
                    long toman=NumberFormatUtil.longValue(amount.getText());
                    if(!BillFormRules.validAmount(toman)){
                        amount.setError("مبلغ پرداخت باید بیشتر از صفر باشد");
                        amount.requestFocus();
                        return;
                    }
                    if(due[0]<=0){
                        android.widget.Toast.makeText(this,"یک تاریخ سررسید معتبر انتخاب کن",android.widget.Toast.LENGTH_SHORT).show();
                        return;
                    }
                    String t=title.getText().toString().trim();
                    if(t.isEmpty())t=String.valueOf(type.getSelectedItem());

                    NexaStore.BillItem x=existing==null?new NexaStore.BillItem():existing;
                    x.alertRules=alerts.rules();x.alertRepeat=alerts.repeatMinutes();
                    x.type=String.valueOf(type.getSelectedItem());
                    x.title=t;
                    x.amount=toman;
                    x.recurrence=repeat.rule();
                    x.note=note.getText().toString().trim();
                    x.sellerId=sellerId[0];x.bankCardId=bankCardId[0];
                    x.dueDate=due[0];
                    if(existing==null)NexaStore.addBill(this,x);else NexaStore.updateBill(this,x);
                    schedule(x);
                    NexaStore.addHistory(this,"پرداخت","ثبت شد: "+x.title);
                    editor.dismiss();
                    render();
            });
        });
        editor.show();
    }

    private void schedule(NexaStore.BillItem x) {
        LinkedReminderHelper.upsert(
                this,
                "bill:"+x.id,
                x.title,
                x.type,
                "💳",
                (x.amount>0?String.format(Locale.US,"%,d تومان",x.amount):"")+(x.note.isEmpty()?"":" • "+x.note),
                x.dueDate,
                x.alertRules,
                            x.alertRepeat
        );
    }

    private void markPaid(NexaStore.BillItem x) {
        if(ReminderRecurrence.isRecurring(x.recurrence)){
            x.dueDate=ReminderRecurrence.after(x.dueDate,x.recurrence,System.currentTimeMillis());
            x.paid=false;
            NexaStore.updateBill(this,x);
            schedule(x);
            NexaStore.addHistory(this,"پرداخت","پرداخت شد و سررسید بعدی ثبت شد: "+x.title);
        }else{
            x.paid=true;
            NexaStore.updateBill(this,x);
            LinkedReminderHelper.remove(this,"bill:"+x.id);
            NexaStore.addHistory(this,"پرداخت","پرداخت شد: "+x.title);
        }
        render();
    }

    private void pickSeller(String[] out,Button button){
        DirectoryPicker.seller(this,s->{out[0]=s.id;button.setText("دریافت‌کننده: "+s.name);});
    }
    private void pickCard(String[] out,Button button){
        DirectoryPicker.card(this,c->{out[0]=c.id;button.setText("کارت مقصد: "+c.display());});
    }
    private void renderForecast(List<NexaStore.BillItem> bills){
        if(forecastTotals==null||forecastRows==null)return;
        forecastRows.removeAllViews();
        List<BillForecast.Entry> source=new java.util.ArrayList<>();
        for(NexaStore.BillItem x:bills)
            source.add(new BillForecast.Entry(x.id,x.title,x.type,x.amount,x.dueDate,x.recurrence,x.paid));
        long now=System.currentTimeMillis();
        BillForecast.Result forecast=BillForecast.calculate(source,now,forecastDays);
        long firstWeek=BillForecast.sumBefore(forecast.upcoming,BillForecast.horizon(now,7));
        forecastTotals.setText("۷ روز: "+NumberFormatUtil.grouped(firstWeek)+" تومان"
                +"\n"+forecastDays+" روز: "+NumberFormatUtil.grouped(forecast.upcomingTotal)+" تومان"
                +"  •  "+forecast.upcoming.size()+" سررسید"
                +"\nمعوق جداگانه: "+NumberFormatUtil.grouped(forecast.overdueTotal)+" تومان"
                +"  •  "+forecast.overdue.size()+" مورد");
        if(forecast.upcoming.isEmpty()){
            forecastRows.addView(UiKit.muted(this,"در این بازه سررسید فعالی ثبت نشده است."),UiKit.matchWrap(this,4,0));
        }else{
            int visible=Math.min(8,forecast.upcoming.size());
            for(int i=0;i<visible;i++){
                BillForecast.Occurrence occ=forecast.upcoming.get(i);
                TextView line=UiKit.muted(this,"• "+occ.title+" • "+PersianDateUtil.pretty(occ.at)
                    +" • "+NumberFormatUtil.grouped(occ.amount)+" تومان"
                    +(occ.projected?" (تکرار پیش‌بینی‌شده)":"")+"  ✎");
                line.setMinHeight(UiKit.dp(this,44));
                line.setOnClickListener(v->{
                    for(NexaStore.BillItem bill:NexaStore.bills(this)){
                        if(occ.id.equals(bill.id)){editDialog(bill);return;}
                    }
                    android.widget.Toast.makeText(this,"این مورد دیگر وجود ندارد.",android.widget.Toast.LENGTH_SHORT).show();
                    render();
                });
                forecastRows.addView(line,UiKit.matchWrap(this,7,0));
            }
            if(forecast.upcoming.size()>visible)
                forecastRows.addView(UiKit.muted(this,"و "+(forecast.upcoming.size()-visible)+" سررسید دیگر در این بازه"),UiKit.matchWrap(this,7,0));
        }
    }

    private void showBillActions(NexaStore.BillItem x){
        String[] options=x.paid?new String[]{"ویرایش","حذف"}:
            new String[]{"پرداخت شد","ویرایش","حذف"};
        new AlertDialog.Builder(this).setTitle(x.title)
            .setItems(options,(d,which)->{
                String choice=options[which];
                if("پرداخت شد".equals(choice))markPaid(x);
                else if("ویرایش".equals(choice))editDialog(x);
                else new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                    .setMessage(x.title).setPositiveButton("حذف",(dialog,w)->{
                        LinkedReminderHelper.remove(this,"bill:"+x.id);
                        NexaStore.removeBill(this,x.id);render();
                    }).setNegativeButton("انصراف",null).show();
            }).show();
    }

    private void render() {
        if(list==null)return;
        List<NexaStore.BillItem> data=NexaStore.bills(this);
        renderForecast(data);
        list.removeAllViews();
        long now=System.currentTimeMillis(), pendingTotal=0; int overdue=0, upcoming=0, paidCount=0;
        for(NexaStore.BillItem x:data){ if(x.paid){paidCount++;continue;} pendingTotal+=x.amount; if(x.dueDate<now)overdue++; else upcoming++; }
        if(summary!=null) summary.setText("در انتظار: "+NumberFormatUtil.grouped(pendingTotal)+" تومان  •  معوق: "+overdue+"  •  آینده: "+upcoming+"  •  پرداخت‌شده: "+paidCount);

        if(data.isEmpty()){
            TextView e=UiKit.muted(this,"سررسیدی ثبت نشده.");
            e.setGravity(Gravity.CENTER);
            list.addView(e,UiKit.matchWrap(this,20,0));
            return;
        }

        int shown=0;
        for(NexaStore.BillItem x:data){
            boolean isOverdue=!x.paid && x.dueDate<now;
            if("معوق".equals(filter) && !isOverdue) continue;
            if("آینده".equals(filter) && (x.paid || isOverdue)) continue;
            if("پرداخت‌شده".equals(filter) && !x.paid) continue;
            shown++;
            LinearLayout c=UiKit.colorfulCardLayout(this,x.paid?2:1);
            c.setAlpha(x.paid?0.55f:1f);
            LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout labels=new LinearLayout(this);labels.setOrientation(LinearLayout.VERTICAL);
            labels.addView(UiKit.sectionTitle(this,x.title));
            labels.addView(UiKit.muted(this,PersianDateUtil.pretty(x.dueDate)+ReminderRecurrence.labelSuffix(x.recurrence)),UiKit.matchWrap(this,3,0));
            TextView amount=UiKit.muted(this,NumberFormatUtil.grouped(x.amount)+" تومان"+(x.paid?" • پرداخت‌شده":""));
            amount.setTextColor(x.paid?UiKit.GREEN:isOverdue?UiKit.RED:UiKit.GOLD);
            labels.addView(amount,UiKit.matchWrap(this,3,0));
            if(x.bankCardId!=null&&!x.bankCardId.isEmpty()){
                NexaStore.BankCard destination=NexaStore.bankCardById(this,x.bankCardId);
                if(destination!=null){
                    LinearLayout payRow=new LinearLayout(this);
                    payRow.setGravity(Gravity.CENTER_VERTICAL);
                    payRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                    TextView label=UiKit.muted(this,(destination.owner.isEmpty()?"کارت مقصد: "+destination.bank:destination.owner)+" • "+PaymentCardSecrets.masked(this,x.bankCardId));
                    payRow.addView(label,new LinearLayout.LayoutParams(0,-2,1f));
                    Button copy=UiKit.iconButton(this,"⧉","کپی شماره کارت مقصد",UiKit.GOLD);
                    copy.setOnClickListener(v->android.widget.Toast.makeText(this,
                        PaymentCardSecrets.copy(this,x.bankCardId)?"شماره کارت کپی شد":"شماره کامل کارت موجود نیست",android.widget.Toast.LENGTH_SHORT).show());
                    payRow.addView(copy,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));
                    labels.addView(payRow,UiKit.matchWrap(this,4,0));
                }
            }
            header.addView(labels,new LinearLayout.LayoutParams(0,-2,1f));
            Button more=UiKit.iconButton(this,"⋮","عملیات پرداخت",UiKit.GOLD);
            more.setOnClickListener(v->showBillActions(x));
            header.addView(more,new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48)));
            c.addView(header);c.setOnClickListener(v->showBillActions(x));
            list.addView(c,UiKit.matchWrap(this,0,10));
        }
        if(shown==0){TextView e=UiKit.muted(this,"موردی برای این فیلتر وجود ندارد.");e.setGravity(Gravity.CENTER);list.addView(e,UiKit.matchWrap(this,20,0));}
    }
}
