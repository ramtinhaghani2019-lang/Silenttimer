package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Mileage-aware accordion history for each vehicle and maintenance type. */
public class VehicleActivity extends Activity {
    private NexaStore.Vehicle vehicle;
    private LinearLayout records,categoryList;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        vehicle=NexaStore.vehicle(this,getIntent().getStringExtra("id"));
        if(vehicle==null){finish();return;}build();}
    private EditText field(String hint,int type){EditText e=UiKit.styleField(this,new EditText(this),hint);e.setInputType(type);if(type==InputType.TYPE_CLASS_NUMBER)NumberFormatUtil.attachThousands(e);return e;}
    private int intValue(EditText e){return NumberFormatUtil.intValue(e.getText());}
    private long longValue(EditText e){return NumberFormatUtil.longValue(e.getText());}
    private String money(long amount){return String.format(Locale.US,"%,d تومان",amount);}
    private void build(){ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(UiKit.dp(this,18),UiKit.dp(this,16),UiKit.dp(this,18),UiKit.dp(this,28));
        root.setBackground(UiKit.screenBackground(this));sc.addView(root);
        Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());root.addView(back,new LinearLayout.LayoutParams(UiKit.dp(this,40),UiKit.dp(this,40)));
        root.addView(UiKit.title(this,vehicle.name),UiKit.matchWrap(this,0,8));
        root.addView(UiKit.featureHero(this,"vehicle","گاراژ من","کیلومتر، سرویس، تعمیر و سوخت"),UiKit.matchWrap(this,0,12));
        LinearLayout info=UiKit.colorfulCardLayout(this,4);
        TextView km=UiKit.sectionTitle(this,String.format(Locale.US,"کیلومتر فعلی: %,d",vehicle.currentKm));
        info.addView(km);Button update=UiKit.secondaryButton(this,"✎ ثبت کیلومتر جدید");
        update.setOnClickListener(v->updateKm(km));info.addView(update,UiKit.matchWrap(this,10,0));
        root.addView(info,UiKit.matchWrap(this,0,12));
        LinearLayout actions=new LinearLayout(this);
        Button service=UiKit.primaryButton(this,"＋ سرویس / تعمیر");service.setOnClickListener(v->serviceDialog(null));
        Button fuel=UiKit.primaryButton(this,"⛽ سوخت");fuel.setOnClickListener(v->fuelDialog(null));
        actions.addView(service,new LinearLayout.LayoutParams(0,-2,1f));actions.addView(fuel,new LinearLayout.LayoutParams(0,-2,1f));
        root.addView(actions,UiKit.matchWrap(this,0,14));
        // Category shortcuts belong in an on-demand dialog, not an 11-row always-visible directory.
        Button categoriesButton=UiKit.secondaryButton(this,"☷  انتخاب دسته سرویس");
        categoriesButton.setOnClickListener(v->showCategoryActions());
        root.addView(categoriesButton,UiKit.matchWrap(this,0,9));
        records=new LinearLayout(this);records.setOrientation(LinearLayout.VERTICAL);root.addView(records);setContentView(sc);render();
    }
    private void updateKm(TextView label){EditText e=field("کیلومتر فعلی",InputType.TYPE_CLASS_NUMBER);
        e.setText(NumberFormatUtil.grouped(vehicle.currentKm));
        new AlertDialog.Builder(this).setTitle("ثبت کیلومتر").setView(e)
            .setPositiveButton("ثبت",(d,w)->{int next=intValue(e);
                if(next<vehicle.currentKm){Toast.makeText(this,"کیلومتر جدید نمی‌تواند کمتر از قبلی باشد.",Toast.LENGTH_LONG).show();return;}
                vehicle.currentKm=next;NexaStore.updateVehicle(this,vehicle);GarageNotifier.check(this,vehicle);
                label.setText(String.format(Locale.US,"کیلومتر فعلی: %,d",next));render();
            }).setNegativeButton("انصراف",null).show();
    }
    private List<String> categories(){List<String> all=new ArrayList<>();
        java.util.Collections.addAll(all,"🛢 روغن موتور","🧰 فیلترها","🛑 لنت جلو","🛑 لنت عقب","🛞 لاستیک","🔋 باتری","⚙ گیربکس","🔧 جلوبندی","🌀 کمک‌فنر","🔩 تعمیر موتور","📋 سرویس دوره‌ای");
        all.addAll(NexaStore.garageCategories(this));for(NexaStore.ServiceRecord r:NexaStore.servicesFor(this,vehicle.id))if(!all.contains(r.category))all.add(r.category);
        return all;
    }
    private void serviceDialog(NexaStore.ServiceRecord old){serviceDialog(old,null);}
    private void serviceDialog(NexaStore.ServiceRecord old,String presetCategory){
        LinearLayout form=UiKit.dialogPanel(this);
        List<String> cats=categories();final String[] selectedCat={old!=null?old.category:(presetCategory!=null?presetCategory:(cats.isEmpty()?"🔧 سرویس دوره‌ای":cats.get(0)))};
        Button categoryBtn=UiKit.secondaryButton(this,"دسته سرویس: "+selectedCat[0]);
        categoryBtn.setOnClickListener(v->showServiceCategoryDirectory(cats,selectedCat,categoryBtn));
        EditText km=field("کیلومتر زمان سرویس",InputType.TYPE_CLASS_NUMBER);
        EditText note=field("توضیحات / برند / تعمیرگاه",InputType.TYPE_CLASS_TEXT);
        EditText cost=field("هزینه تومان",InputType.TYPE_CLASS_NUMBER);
        EditText next=field("موعد بعدی به کیلومتر (اختیاری)",InputType.TYPE_CLASS_NUMBER);
        final long[] serviceDate={old==null?System.currentTimeMillis():old.dateMillis};
        final long[] dueDate={old==null?0L:old.nextDueDate};
        Button serviceTime=UiKit.secondaryButton(this,"تاریخ سرویس: "+PersianDateUtil.pretty(serviceDate[0]));
        serviceTime.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,serviceDate[0],"تاریخ و ساعت سرویس",ms->{serviceDate[0]=ms;serviceTime.setText("تاریخ سرویس: "+PersianDateUtil.pretty(ms));}));
        Button dueTime=UiKit.secondaryButton(this,"موعد زمانی بعدی: "+(dueDate[0]>0?PersianDateUtil.pretty(dueDate[0]):"ثبت نشده"));
        dueTime.setOnClickListener(v->PersianDatePickerHelper.pickDateTime(this,dueDate[0]>0?dueDate[0]:System.currentTimeMillis()+86400000L,"موعد سرویس بعدی",ms->{dueDate[0]=ms;dueTime.setText("موعد بعدی: "+PersianDateUtil.pretty(ms));}));
        if(old!=null){km.setText(NumberFormatUtil.grouped(old.km));note.setText(old.note);if(old.cost>0)cost.setText(NumberFormatUtil.grouped(old.cost));if(old.nextDueKm>0)next.setText(NumberFormatUtil.grouped(old.nextDueKm));}
        else km.setText(NumberFormatUtil.grouped(vehicle.currentKm));
        for(View v:new View[]{categoryBtn,km,note,cost,next,serviceTime,dueTime})form.addView(v,UiKit.matchWrap(this,0,8));
        RepeatIntervalPicker interval=new RepeatIntervalPicker(this,form,old==null?"none":old.recurrence);
        AlertEditor alerts=new AlertEditor(this,form,"D7@09:00,D1@09:00,0",5);
        ScrollView scroll=new ScrollView(this);scroll.addView(form);
        new AlertDialog.Builder(this).setTitle(old==null?"سرویس / تعمیر جدید":"ویرایش سرویس")
            .setView(scroll).setPositiveButton("ذخیره",(d,w)->{
                NexaStore.ServiceRecord r=old==null?new NexaStore.ServiceRecord():old;
                r.vehicleId=vehicle.id;r.category=selectedCat[0];
                r.icon=r.category.contains(" ")?r.category.substring(0,r.category.indexOf(' ')):"🔧";
                r.km=intValue(km);r.note=note.getText().toString().trim();r.cost=longValue(cost);
                r.nextDueKm=intValue(next);r.dateMillis=serviceDate[0];r.nextDueDate=dueDate[0];r.recurrence=interval.rule();
                if(old==null)NexaStore.addService(this,r);else NexaStore.updateService(this,r);
                if(r.nextDueDate>System.currentTimeMillis())LinkedReminderHelper.upsert(this,"service:"+r.id,
                    "سرویس "+vehicle.name+" • "+r.category,"گاراژ","🚗",r.note,r.nextDueDate,alerts.rules(),alerts.repeatMinutes(),r.recurrence);
                else LinkedReminderHelper.remove(this,"service:"+r.id);
                if(r.km>vehicle.currentKm){vehicle.currentKm=r.km;NexaStore.updateVehicle(this,vehicle);}
                GarageNotifier.check(this,vehicle);TodayNotificationManager.refresh(this);render();
            }).setNegativeButton("انصراف",null).show();
    }

    private void showServiceCategoryDirectory(List<String> cats,String[] selected,Button target){
        LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"دسته‌های سرویس"),UiKit.matchWrap(this,0,8));
        final AlertDialog[] picker={null};
        for(String cat:cats){Button b=UiKit.secondaryButton(this,cat);b.setOnClickListener(v->{selected[0]=cat;target.setText("دسته سرویس: "+cat);if(picker[0]!=null)picker[0].dismiss();});box.addView(b,UiKit.matchWrap(this,0,5));}
        box.addView(UiKit.muted(this,"ساخت دسته جدید از لیست دسته‌های صفحه دفترچه انجام می‌شود."),UiKit.matchWrap(this,8,0));
        picker[0]=new AlertDialog.Builder(this).setTitle("انتخاب دسته").setView(box).setNegativeButton("بستن",null).show();
    }
    private void showCategoryActions(){
        final List<String> available=categories();
        new AlertDialog.Builder(this).setTitle("ثبت سریع سرویس")
                .setItems(available.toArray(new String[0]),(d,which)->serviceDialog(null,available.get(which)))
                .setNeutralButton("دسته جدید",(d,w)->addGarageCategoryDialog())
                .setNegativeButton("بستن",null).show();
    }
    private void addGarageCategoryDialog(){
        EditText input=field("نام دسته جدید",InputType.TYPE_CLASS_TEXT);
        new AlertDialog.Builder(this).setTitle("دسته سرویس جدید").setView(input).setPositiveButton("ثبت",(d,w)->{String n=input.getText().toString().trim();if(n.isEmpty())return;String type=n.matches("^[\\p{So}].*")?n:"🔖 "+n;NexaStore.addGarageCategory(this,type);renderCategories();}).setNegativeButton("انصراف",null).show();
    }
    private void renderCategories(){
        if(categoryList==null)return;categoryList.removeAllViews();
        for(String cat:categories()){Button b=UiKit.secondaryButton(this,cat);b.setOnClickListener(v->serviceDialog(null,cat));categoryList.addView(b,UiKit.matchWrap(this,0,5));}
    }
    private void fuelDialog(NexaStore.FuelRecord old){
        LinearLayout box=UiKit.dialogPanel(this);
        EditText km=field("کیلومتر",InputType.TYPE_CLASS_NUMBER);km.setText(NumberFormatUtil.grouped(old==null?vehicle.currentKm:old.km));
        EditText liters=field("لیتر",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        EditText cost=field("مبلغ تومان",InputType.TYPE_CLASS_NUMBER);
        if(old!=null){liters.setText(String.valueOf(old.liters));if(old.cost>0)cost.setText(NumberFormatUtil.grouped(old.cost));}
        for(View v:new View[]{km,liters,cost})box.addView(v,UiKit.matchWrap(this,0,8));
        new AlertDialog.Builder(this).setTitle(old==null?"ثبت سوخت":"ویرایش سوخت").setView(box)
            .setPositiveButton("ذخیره",(d,w)->{NexaStore.FuelRecord f=old==null?new NexaStore.FuelRecord():old;
                f.vehicleId=vehicle.id;f.km=intValue(km);try{f.liters=Double.parseDouble(liters.getText().toString());}catch(Exception e){f.liters=0;}
                f.cost=longValue(cost);if(old==null)NexaStore.addFuel(this,f);else NexaStore.updateFuel(this,f);
                if(f.km>vehicle.currentKm){vehicle.currentKm=f.km;NexaStore.updateVehicle(this,vehicle);GarageNotifier.check(this,vehicle);}
                render();}).setNegativeButton("انصراف",null).show();
    }
    private void render(){
        renderCategories();
        if(records==null)return;records.removeAllViews();List<NexaStore.ServiceRecord> services=NexaStore.servicesFor(this,vehicle.id);
        List<NexaStore.FuelRecord> fuels=NexaStore.fuelsFor(this,vehicle.id);
        long serviceSum=0,fuelSum=0;for(NexaStore.ServiceRecord r:services)serviceSum+=r.cost;
        for(NexaStore.FuelRecord f:fuels)fuelSum+=f.cost;
        LinearLayout sum=UiKit.colorfulCardLayout(this,7);
        sum.addView(UiKit.sectionTitle(this,"هزینه کل: "+money(serviceSum+fuelSum)));
        sum.addView(UiKit.muted(this,"سرویس: "+money(serviceSum)+" • سوخت: "+money(fuelSum)),UiKit.matchWrap(this,6,0));
        int overdue=0,soon=0;for(NexaStore.ServiceRecord r:services){if(r.nextDueKm>0){int left=r.nextDueKm-vehicle.currentKm;if(left<=0)overdue++;else if(left<=500)soon++;}}
        double totalLiters=0;int minFuelKm=Integer.MAX_VALUE,maxFuelKm=-1;for(NexaStore.FuelRecord f:fuels){totalLiters+=f.liters;minFuelKm=Math.min(minFuelKm,f.km);maxFuelKm=Math.max(maxFuelKm,f.km);}
        sum.addView(UiKit.muted(this,"سرویس عقب‌افتاده: "+overdue+" • نزدیک موعد: "+soon+" • رکورد سوخت: "+fuels.size()),UiKit.matchWrap(this,5,0));
        if(totalLiters>0)sum.addView(UiKit.muted(this,String.format(Locale.US,"سوخت ثبت‌شده: %.1f لیتر • میانگین قیمت: %,.0f تومان/لیتر",totalLiters,fuelSum/totalLiters)),UiKit.matchWrap(this,5,0));
        if(fuels.size()>=2 && maxFuelKm>minFuelKm && totalLiters>0)sum.addView(UiKit.muted(this,String.format(Locale.US,"شاخص مصرف تقریبی: %.1f لیتر در ۱۰۰km",totalLiters*100.0/(maxFuelKm-minFuelKm))),UiKit.matchWrap(this,5,0));
        records.addView(sum,UiKit.matchWrap(this,0,12));
        Map<String,List<NexaStore.ServiceRecord>> grouped=new LinkedHashMap<>();
        for(NexaStore.ServiceRecord r:services){
            if(!grouped.containsKey(r.category))grouped.put(r.category,new ArrayList<>());
            grouped.get(r.category).add(r);
        }
        for(Map.Entry<String,List<NexaStore.ServiceRecord>> entry:grouped.entrySet()){
            LinearLayout card=UiKit.colorfulCardLayout(this,4),body=new LinearLayout(this);
            body.setOrientation(LinearLayout.VERTICAL);body.setVisibility(View.GONE);
            long categoryTotal=0;for(NexaStore.ServiceRecord x:entry.getValue())categoryTotal+=x.cost;
            Button head=UiKit.secondaryButton(this,"▸ "+entry.getKey()+" ("+entry.getValue().size()+")");
            head.setOnClickListener(v->{boolean show=body.getVisibility()!=View.VISIBLE;
                body.setVisibility(show?View.VISIBLE:View.GONE);
                head.setText((show?"▾ ":"▸ ")+entry.getKey()+" ("+entry.getValue().size()+")");});
            card.addView(head);card.addView(UiKit.muted(this,"مجموع: "+money(categoryTotal)),UiKit.matchWrap(this,5,7));
            NexaStore.ServiceRecord latest=entry.getValue().get(0);
            if(latest.nextDueKm>0){int remaining=latest.nextDueKm-vehicle.currentKm;
                TextView status=UiKit.sectionTitle(this,remaining<0?"🔴 "+(-remaining)+" کیلومتر دیرکرد":
                    remaining<=500?"🟡 "+remaining+" کیلومتر مانده":"🟢 "+remaining+" کیلومتر مانده");
                status.setTextColor(remaining<0?UiKit.PINK:(remaining<=500?UiKit.GOLD:UiKit.TEAL));
                card.addView(status,UiKit.matchWrap(this,4,0));
            }
            long previous=-1L;
            for(NexaStore.ServiceRecord r:entry.getValue()){
                LinearLayout row=UiKit.cardLayout(this);row.addView(UiKit.sectionTitle(this,PersianDateUtil.pretty(r.dateMillis)));
                row.addView(UiKit.muted(this,String.format(Locale.US,"%,d km • %s",r.km,money(r.cost))),UiKit.matchWrap(this,5,0));
                if(!r.note.isEmpty())row.addView(UiKit.muted(this,r.note));
                if(r.nextDueKm>0)row.addView(UiKit.muted(this,String.format(Locale.US,"موعد بعدی: %,d km",r.nextDueKm)));
                int ix=entry.getValue().indexOf(r);
                if(ix<entry.getValue().size()-1){NexaStore.ServiceRecord prior=entry.getValue().get(ix+1);
                    if(prior.cost>0)row.addView(UiKit.muted(this,String.format(Locale.US,"تغییر هزینه نسبت به دفعه قبل: %+,d تومان (%.1f%%)",r.cost-prior.cost,(r.cost-prior.cost)*100.0/prior.cost)));}
                LinearLayout buttons=new LinearLayout(this);buttons.setGravity(android.view.Gravity.CENTER_VERTICAL);
                Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->serviceDialog(r));
                Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this)
                    .setTitle("حذف سرویس؟").setMessage(r.category).setPositiveButton("حذف",(d,w)->{
                        NexaStore.removeService(this,r.id);LinkedReminderHelper.remove(this,"service:"+r.id);TodayNotificationManager.refresh(this);render();})
                    .setNegativeButton("انصراف",null).show());
                buttons.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dl.setMargins(UiKit.dp(this,6),0,0,0);buttons.addView(del,dl);
                row.addView(buttons,UiKit.matchWrap(this,6,0));body.addView(row,UiKit.matchWrap(this,6,0));
            }
            card.addView(body);records.addView(card,UiKit.matchWrap(this,0,12));
        }
        if(!fuels.isEmpty()){
            LinearLayout card=UiKit.colorfulCardLayout(this,2);card.addView(UiKit.sectionTitle(this,"⛽ سوخت ("+fuels.size()+")"));
            for(NexaStore.FuelRecord f:fuels){LinearLayout row=UiKit.cardLayout(this);
                row.addView(UiKit.sectionTitle(this,String.format(Locale.US,"%.2f لیتر • %s",f.liters,money(f.cost))));
                row.addView(UiKit.muted(this,PersianDateUtil.pretty(f.dateMillis)+" • "+f.km+" km"));
                LinearLayout actions=new LinearLayout(this);Button edit=UiKit.editIconButton(this);edit.setOnClickListener(v->fuelDialog(f));actions.addView(edit,new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44)));Button del=UiKit.deleteIconButton(this);del.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("حذف سوخت؟").setPositiveButton("حذف",(d,w)->{NexaStore.removeFuel(this,f.id);render();}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,44),UiKit.dp(this,44));dl.setMargins(UiKit.dp(this,6),0,0,0);actions.addView(del,dl);row.addView(actions,UiKit.matchWrap(this,4,0));card.addView(row,UiKit.matchWrap(this,5,0));
            }
            records.addView(card,UiKit.matchWrap(this,0,12));
        }
    }
}
