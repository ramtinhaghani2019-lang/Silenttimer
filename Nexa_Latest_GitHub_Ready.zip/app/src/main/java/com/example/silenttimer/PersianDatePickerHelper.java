package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.NumberPicker;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.view.View;
import android.widget.TextView;
import android.widget.EditText;

import java.util.Calendar;

public final class PersianDatePickerHelper {
    private PersianDatePickerHelper() {}

    public interface Callback { void onPicked(long millis); }
    public interface TimeCallback { void onPicked(int hour,int minute); }

    public static void pickTime(Activity a,int hour,int minute,String title,TimeCallback cb){
        LinearLayout box=UiKit.dialogPanel(a);
        TextView heading=UiKit.sectionTitle(a,title);heading.setTextSize(21);box.addView(heading,UiKit.matchWrap(a,0,10));
        LinearLayout row=new LinearLayout(a);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(LinearLayout.LAYOUT_DIRECTION_LTR);
        String[] hours=new String[24],minutes=new String[60];for(int i=0;i<24;i++)hours[i]=String.format(java.util.Locale.US,"%02d",i);for(int i=0;i<60;i++)minutes[i]=String.format(java.util.Locale.US,"%02d",i);
        NumberPicker h=new NumberPicker(a),m=new NumberPicker(a);
        h.setMinValue(0);h.setMaxValue(23);h.setDisplayedValues(hours);h.setValue(Math.max(0,Math.min(23,hour)));h.setWrapSelectorWheel(true);
        m.setMinValue(0);m.setMaxValue(59);m.setDisplayedValues(minutes);m.setValue(Math.max(0,Math.min(59,minute)));m.setWrapSelectorWheel(true);
        styleNumberPicker(a,h);styleNumberPicker(a,m);
        row.addView(h,new LinearLayout.LayoutParams(0,UiKit.dp(a,120),1f));TextView colon=UiKit.sectionTitle(a,":");colon.setTextSize(24);colon.setGravity(Gravity.CENTER);row.addView(colon,new LinearLayout.LayoutParams(UiKit.dp(a,34),UiKit.dp(a,120)));row.addView(m,new LinearLayout.LayoutParams(0,UiKit.dp(a,120),1f));box.addView(row);
        TextView hint=UiKit.muted(a,"ساعت و دقیقه را انتخاب کن");hint.setGravity(Gravity.CENTER);box.addView(hint,UiKit.matchWrap(a,8,0));
        AlertDialog dialog=new AlertDialog.Builder(a).setView(box).setNegativeButton("انصراف",null).setPositiveButton("تأیید",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(UiKit.palette(a)[4]);dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(UiKit.palette(a)[5]);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{cb.onPicked(h.getValue(),m.getValue());dialog.dismiss();});});
        dialog.show();
    }

    private static void styleNumberPicker(Activity a,NumberPicker picker){
        picker.setBackground(UiKit.field(a));
        picker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        for(int i=0;i<picker.getChildCount();i++){
            View child=picker.getChildAt(i);
            if(child instanceof EditText){
                EditText e=(EditText)child;
                e.setTextColor(UiKit.palette(a)[3]);
                e.setTextSize(20);
                e.setGravity(Gravity.CENTER);
            }
        }
    }

    private static ArrayAdapter<String> pickerAdapter(Activity a,String[] values){
        return new ArrayAdapter<String>(a,android.R.layout.simple_spinner_item,values){
            @Override public View getView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getView(p,v,g);t.setTextColor(UiKit.palette(a)[3]);t.setTextSize(18);t.setGravity(Gravity.CENTER);t.setBackground(UiKit.field(a));return t;}
            @Override public View getDropDownView(int p,View v,android.view.ViewGroup g){TextView t=(TextView)super.getDropDownView(p,v,g);t.setTextColor(UiKit.palette(a)[3]);t.setTextSize(18);t.setGravity(Gravity.CENTER);t.setPadding(12,12,12,12);t.setBackground(UiKit.field(a));return t;}
        };
    }

    public static void pickDateTime(Activity a,long current,String title,Callback cb){
        if(current<=0)current=System.currentTimeMillis();
        final long[] selected={current};
        int[] j=PersianDateUtil.fromMillis(current);
        Calendar c=Calendar.getInstance();c.setTimeInMillis(current);
        final int[] hm={c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)};

        LinearLayout box=UiKit.dialogPanel(a);
        TextView heading=UiKit.sectionTitle(a,title);heading.setTextSize(22);box.addView(heading,UiKit.matchWrap(a,0,8));
        TextView summary=UiKit.muted(a,PersianDateUtil.pretty(current));summary.setTextSize(15);summary.setGravity(Gravity.CENTER);box.addView(summary,UiKit.matchWrap(a,0,10));

        LinearLayout row=new LinearLayout(a);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(LinearLayout.LAYOUT_DIRECTION_LTR);
        NumberPicker day=new NumberPicker(a),month=new NumberPicker(a),year=new NumberPicker(a);
        year.setMinValue(j[0]-5);year.setMaxValue(j[0]+20);year.setValue(j[0]);
        month.setMinValue(1);month.setMaxValue(12);month.setDisplayedValues(PersianDateUtil.MONTHS);month.setValue(j[1]);
        day.setMinValue(1);day.setMaxValue(PersianDateUtil.monthLength(j[0],j[1]));day.setValue(j[2]);
        row.addView(day,new LinearLayout.LayoutParams(0,-2,1f));row.addView(month,new LinearLayout.LayoutParams(0,-2,1.25f));row.addView(year,new LinearLayout.LayoutParams(0,-2,1f));box.addView(row);

        Runnable refresh=()->{int yy=year.getValue(),mm=month.getValue();day.setMaxValue(PersianDateUtil.monthLength(yy,mm));int dd=Math.min(day.getValue(),day.getMaxValue());long ms=PersianDateUtil.toMillis(yy,mm,dd,hm[0],hm[1]);selected[0]=ms;summary.setText(PersianDateUtil.pretty(ms));};
        NumberPicker.OnValueChangeListener listener=(p,o,n)->refresh.run();year.setOnValueChangedListener(listener);month.setOnValueChangedListener(listener);day.setOnValueChangedListener(listener);

        Button time=UiKit.secondaryButton(a,String.format(java.util.Locale.US,"🕒 ساعت %02d:%02d",hm[0],hm[1]));
        time.setOnClickListener(v->pickTime(a,hm[0],hm[1],"انتخاب ساعت",(h,m)->{hm[0]=h;hm[1]=m;time.setText(String.format(java.util.Locale.US,"🕒 ساعت %02d:%02d",h,m));refresh.run();}));
        box.addView(time,UiKit.matchWrap(a,10,0));

        AlertDialog dialog=new AlertDialog.Builder(a).setView(box).setNegativeButton("انصراف",null).setPositiveButton("تأیید",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(UiKit.TEAL);dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(UiKit.MUTED);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{refresh.run();cb.onPicked(selected[0]);dialog.dismiss();});});
        dialog.show();
    }

    public static void pickDate(Activity a,long current,String title,Callback cb){
        if(current<=0)current=System.currentTimeMillis();
        final long base=current;
        int[] j=PersianDateUtil.fromMillis(current);
        LinearLayout box=UiKit.dialogPanel(a);
        TextView heading=UiKit.sectionTitle(a,title);heading.setTextSize(22);box.addView(heading,UiKit.matchWrap(a,0,8));
        TextView summary=UiKit.muted(a,PersianDateUtil.pretty(current).replaceAll(" • .*",""));summary.setTextSize(15);summary.setGravity(Gravity.CENTER);box.addView(summary,UiKit.matchWrap(a,0,10));
        LinearLayout row=new LinearLayout(a);row.setOrientation(LinearLayout.HORIZONTAL);row.setLayoutDirection(LinearLayout.LAYOUT_DIRECTION_LTR);
        NumberPicker day=new NumberPicker(a),month=new NumberPicker(a),year=new NumberPicker(a);
        year.setMinValue(j[0]-5);year.setMaxValue(j[0]+20);year.setValue(j[0]);month.setMinValue(1);month.setMaxValue(12);month.setDisplayedValues(PersianDateUtil.MONTHS);month.setValue(j[1]);day.setMinValue(1);day.setMaxValue(PersianDateUtil.monthLength(j[0],j[1]));day.setValue(j[2]);
        row.addView(day,new LinearLayout.LayoutParams(0,-2,1f));row.addView(month,new LinearLayout.LayoutParams(0,-2,1.25f));row.addView(year,new LinearLayout.LayoutParams(0,-2,1f));box.addView(row);
        Runnable refresh=()->{int yy=year.getValue(),mm=month.getValue();day.setMaxValue(PersianDateUtil.monthLength(yy,mm));int dd=Math.min(day.getValue(),day.getMaxValue());long ms=PersianDateUtil.toMillis(yy,mm,dd,9,0);summary.setText(PersianDateUtil.pretty(ms).replaceAll(" • .*",""));};
        NumberPicker.OnValueChangeListener l=(p,o,n)->refresh.run();year.setOnValueChangedListener(l);month.setOnValueChangedListener(l);day.setOnValueChangedListener(l);
        AlertDialog dialog=new AlertDialog.Builder(a).setView(box).setNegativeButton("انصراف",null).setPositiveButton("تأیید",null).create();
        dialog.setOnShowListener(x->{dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(UiKit.TEAL);dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setTextColor(UiKit.MUTED);dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{int yy=year.getValue(),mm=month.getValue(),dd=Math.min(day.getValue(),PersianDateUtil.monthLength(yy,mm));Calendar c=Calendar.getInstance();c.setTimeInMillis(base);cb.onPicked(PersianDateUtil.toMillis(yy,mm,dd,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE)));dialog.dismiss();});});
        dialog.show();
    }
}
