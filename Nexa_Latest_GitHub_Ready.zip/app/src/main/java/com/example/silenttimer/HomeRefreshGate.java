package com.example.silenttimer;

/** Pure time gate for the home dashboard. The live timer is never throttled. */
public final class HomeRefreshGate {
    private HomeRefreshGate() {}
    public static final long OVERVIEW_MS=30_000L;
    public static final long FINANCE_MS=60_000L;

    public static boolean due(long now,long last,long interval) {
        if(interval<=0) throw new IllegalArgumentException("Invalid refresh interval");
        // Force refresh for first render, returning from a feature page and clock rollback.
        return last<=0 || now<last || now-last>=interval;
    }
}
