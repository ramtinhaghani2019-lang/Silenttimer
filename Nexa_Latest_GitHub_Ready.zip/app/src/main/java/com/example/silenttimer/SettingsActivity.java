package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;

public class SettingsActivity extends Activity {
    public static final String EXTRA_START_SETUP="start_setup";
    private static final int REQ_RUNTIME=7101,REQ_CALL_SCREENING=7102,REQ_EXPORT=7103,REQ_IMPORT=7104,REQ_UNLOCK=7190,REQ_SMS_CONTACT=7191,REQ_VAULT_EXPORT=7192,REQ_VAULT_IMPORT=7193,REQ_SOUND_DOCUMENT=7194,REQ_SOUND_SYSTEM=7195;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean setupInProgress=false,autoFirstRunSetup=false;private int waitingSpecialStep=0;
    private TextView overlayStatus,dndStatus,phoneStatus,screeningStatus,exactAlarmStatus,fullScreenStatus,batteryStatus,smsSavedStatus;private Button setupButton,saveSms;private EditText smsNumber,smsCode;private Switch smsSwitch,smsAnyone;
    private int pendingSoundProfile=NexaAudioController.SOUND_ALARM;
    private boolean verifiedSettings=false,awaitingSettingsUnlock=false;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        boolean firstSetup=getIntent().getBooleanExtra(EXTRA_START_SETUP,false)&&!AppPrefs.isSetupCompleted(this);
        if(firstSetup||!NexaStore.pinConfigured(this)||SecurityGate.isUnlocked()){verifiedSettings=true;openSettings();}
        else if(!awaitingSettingsUnlock){awaitingSettingsUnlock=true;startActivityForResult(new Intent(this,UnlockActivity.class),REQ_UNLOCK);}
    }
    private void openSettings(){buildUi();if(getIntent().getBooleanExtra(EXTRA_START_SETUP,false)){
        autoFirstRunSetup=!AppPrefs.isSetupCompleted(this);
        new android.app.AlertDialog.Builder(this)
            .setTitle("دسترسی‌های Nexa")
            .setMessage("برای اینکه تماس‌های مجاز، هشدارها، پیام اضطراری و زمان‌بندی‌ها درست کار کنند، Nexa فقط دسترسی‌های لازم را مرحله‌به‌مرحله درخواست می‌کند. اگر دسترسی‌ای را نخواهی، همان قابلیت محدود می‌شود و بعداً از تنظیمات می‌توانی فعالش کنی.")
            .setPositiveButton("ادامه و بررسی دسترسی‌ها",(d,w)->{setupInProgress=true;handler.postDelayed(this::continueSetup,250);})
            .setNegativeButton("فعلاً نه",null).show();
    }}
    @Override protected void onResume(){super.onResume();refreshStatuses();if(setupInProgress&&waitingSpecialStep!=0){int step=waitingSpecialStep;waitingSpecialStep=0;if(!stepGranted(step)){setupInProgress=false;Toast.makeText(this,"این دسترسی تأیید نشد. از همین صفحه دوباره راه‌اندازی کامل را بزن.",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this::continueSetup,300);}}
    private final java.util.ArrayList<LinearLayout> expandedSettings = new java.util.ArrayList<>();
    private final java.util.ArrayList<Button> settingsToggles = new java.util.ArrayList<>();
    private final java.util.ArrayList<String> settingsTitles = new java.util.ArrayList<>();
    // Compact, in-place accordion: preserves existing form state and actions.
    private void addCollapsibleSettingsSection(LinearLayout root, LinearLayout content, String title){
        Button toggle=UiKit.secondaryButton(this,title+"  ▾");
        root.addView(toggle,UiKit.matchWrap(this,0,6));
        expandedSettings.add(content); settingsToggles.add(toggle); settingsTitles.add(title);
        content.setVisibility(View.GONE);
        root.addView(content,UiKit.matchWrap(this,0,14));
        toggle.setOnClickListener(v->{
            boolean expand=content.getVisibility()!=View.VISIBLE;
            if(expand){
                for(int i=0;i<expandedSettings.size();i++){
                    expandedSettings.get(i).setVisibility(View.GONE);
                    settingsToggles.get(i).setText(settingsTitles.get(i)+"  ▾");
                }
            }
            content.setVisibility(expand?View.VISIBLE:View.GONE);
            toggle.setText(title+(expand?"  ▴":"  ▾"));
        });
    }
    private void buildUi(){expandedSettings.clear();settingsToggles.clear();settingsTitles.clear();ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,20),UiKit.dp(this,18),UiKit.dp(this,20),UiKit.dp(this,30));root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());head.addView(back);LinearLayout tb=new LinearLayout(this);tb.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(0,-2,1f);tl.setMargins(UiKit.dp(this,12),0,0,0);head.addView(tb,tl);tb.addView(UiKit.title(this,"تنظیمات"));tb.addView(UiKit.muted(this,"Nexa • Emerald Gold"));root.addView(head,UiKit.matchWrap(this,0,18));
        root.addView(UiKit.featureHero(this,"settings","تنظیمات نِکسا","امنیت، دسترسی‌ها و تنظیمات برنامه"),UiKit.matchWrap(this,0,14));
        LinearLayout account=UiKit.colorfulCardLayout(this,1);
        account.addView(UiKit.sectionTitle(this,"👤 حساب کاربری و ایمیل"));
        account.addView(UiKit.muted(this,"نام: "+NexaStore.accountName(this)+" • ایمیل ثبت‌شده: "+NexaStore.accountEmail(this)+
            "\nبرای بازیابی آنلاین، ایمیل را ثبت و پنل ارسال ایمیل را در همین صفحه تنظیم کن."),UiKit.matchWrap(this,7,8));
        Button editAccount=UiKit.secondaryButton(this,"✎ ویرایش مشخصات");
        editAccount.setOnClickListener(v->startActivity(new Intent(this,AccountSetupActivity.class)));
        account.addView(editAccount);addCollapsibleSettingsSection(root,account,"👤 حساب کاربری و ایمیل");
        LinearLayout email=UiKit.colorfulCardLayout(this,6);email.addView(UiKit.sectionTitle(this,"✉ پنل ارسال ایمیل و بازیابی"));
        email.addView(UiKit.muted(this,"برای ارسال واقعی کد تأیید، اطلاعات پروژه Supabase را وارد کن. Anon Key عمومی است؛ رمز ایمیل شخصی لازم نیست.\nوضعیت: "+(NexaStore.emailSupabaseUrl(this).trim().isEmpty()?"پیکربندی نشده":(NexaStore.emailVerified(this)?"متصل • ایمیل تأییدشده ✓":"پیکربندی شده • ایمیل هنوز تأیید نشده"))),UiKit.matchWrap(this,6,10));
        EditText emailUrl=field("Supabase URL");emailUrl.setText(NexaStore.emailSupabaseUrl(this));email.addView(emailUrl,UiKit.matchWrap(this,0,6));
        EditText emailKey=field("Supabase Anon Key");emailKey.setText(NexaStore.emailSupabaseAnon(this));emailKey.setTextDirection(View.TEXT_DIRECTION_LTR);email.addView(emailKey,UiKit.matchWrap(this,0,8));
        LinearLayout emailActions=new LinearLayout(this);Button saveEmail=UiKit.secondaryButton(this,"ذخیره تنظیمات");Button testEmail=UiKit.secondaryButton(this,"ارسال کد آزمایشی");
        saveEmail.setOnClickListener(v->{NexaStore.setEmailPanel(this,emailUrl.getText().toString().trim(),emailKey.getText().toString().trim());Toast.makeText(this,"تنظیمات ایمیل ذخیره شد.",Toast.LENGTH_SHORT).show();});
        testEmail.setOnClickListener(v->{NexaStore.setEmailPanel(this,emailUrl.getText().toString().trim(),emailKey.getText().toString().trim());String target=NexaStore.accountEmail(this);if(target.trim().isEmpty()){Toast.makeText(this,"ابتدا ایمیل حساب کاربری را ثبت کن.",Toast.LENGTH_LONG).show();return;}testEmail.setEnabled(false);testEmail.setText("در حال ارسال…");EmailRecoveryClient.sendOtp(this,target,(ok,msg)->{testEmail.setEnabled(true);testEmail.setText("ارسال کد آزمایشی");Toast.makeText(this,msg,Toast.LENGTH_LONG).show();});});
        emailActions.addView(saveEmail,new LinearLayout.LayoutParams(0,-2,1f));emailActions.addView(testEmail,new LinearLayout.LayoutParams(0,-2,1f));email.addView(emailActions);addCollapsibleSettingsSection(root,email,"✉ پنل ارسال ایمیل و بازیابی");
        LinearLayout secure=UiKit.colorfulCardLayout(this,3);secure.addView(UiKit.sectionTitle(this,"🔐 امنیت و Backup صندوق امن"));secure.addView(UiKit.muted(this,"Recovery Code، قفل خودکار و Backup رمزگذاری‌شده Vault. فایل Vault بدون گذرواژه قابل خواندن نیست."),UiKit.matchWrap(this,6,10));Button sec=UiKit.secondaryButton(this,"تنظیمات امنیتی");sec.setOnClickListener(v->startActivity(new Intent(this,SecurityActivity.class)));secure.addView(sec,UiKit.matchWrap(this,0,7));LinearLayout vb=new LinearLayout(this);Button ve=UiKit.secondaryButton(this,"خروجی امن Vault");Button vi=UiKit.secondaryButton(this,"بازیابی Vault");ve.setOnClickListener(v->askVaultPassword(true));vi.setOnClickListener(v->askVaultPassword(false));vb.addView(ve,new LinearLayout.LayoutParams(0,-2,1f));vb.addView(vi,new LinearLayout.LayoutParams(0,-2,1f));secure.addView(vb);addCollapsibleSettingsSection(root,secure,"🔐 امنیت و Backup صندوق امن");
        LinearLayout access=UiKit.colorfulCardLayout(this,0);access.addView(UiKit.sectionTitle(this,"راه‌اندازی کامل دسترسی‌ها"));access.addView(UiKit.muted(this,"در نصب اول خودکار اجرا می‌شود؛ هر صفحه را تأیید کنی، صفحه بعدی خودش باز می‌شود."),UiKit.matchWrap(this,6,14));setupButton=UiKit.primaryButton(this,"شروع راه‌اندازی کامل");setupButton.setOnClickListener(v->{setupInProgress=true;waitingSpecialStep=0;continueSetup();});access.addView(setupButton);addCollapsibleSettingsSection(root,access,"🛠 راه‌اندازی دسترسی‌ها");LinearLayout checklist=UiKit.colorfulCardLayout(this,1);checklist.addView(UiKit.sectionTitle(this,"وضعیت دسترسی‌ها"));overlayStatus=status("نمایش روی برنامه‌ها");dndStatus=status("کنترل Silent / Vibrate");phoneStatus=status("تماس، مخاطبین، پیامک و اعلان‌ها");screeningStatus=status("Call Screening تماس‌های مجاز");exactAlarmStatus=status("آلارم دقیق");fullScreenStatus=status("نمایش تمام‌صفحه هشدار روی Lock Screen");batteryStatus=status("فعالیت پس‌زمینه بدون محدودیت");checklist.addView(overlayStatus,UiKit.matchWrap(this,12,5));checklist.addView(dndStatus,UiKit.matchWrap(this,0,5));checklist.addView(phoneStatus,UiKit.matchWrap(this,0,5));checklist.addView(screeningStatus,UiKit.matchWrap(this,0,5));checklist.addView(exactAlarmStatus,UiKit.matchWrap(this,0,5));checklist.addView(fullScreenStatus,UiKit.matchWrap(this,0,5));checklist.addView(batteryStatus);
        LinearLayout accessActions=new LinearLayout(this);Button exactSettings=UiKit.secondaryButton(this,"آلارم دقیق");Button batterySettings=UiKit.secondaryButton(this,"باتری");
        exactSettings.setOnClickListener(v->{try{if(Build.VERSION.SDK_INT>=31)startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}});
        batterySettings.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}});
        accessActions.addView(exactSettings,new LinearLayout.LayoutParams(0,-2,1f));accessActions.addView(batterySettings,new LinearLayout.LayoutParams(0,-2,1f));checklist.addView(accessActions,UiKit.matchWrap(this,9,0));addCollapsibleSettingsSection(root,checklist,"📋 وضعیت دسترسی‌ها");
        LinearLayout sms=UiKit.colorfulCardLayout(this,2);sms.addView(UiKit.sectionTitle(this,"📩 کد اضطراری پیامکی"));sms.addView(UiKit.muted(this,"فقط اگر پیامک از شماره تعریف‌شده باشد و کد داخل متن باشد، گوشی از Silent/Vibrate خارج می‌شود."),UiKit.matchWrap(this,6,10));smsSwitch=UiKit.styledSwitch(this);smsSwitch.setText("فعال");smsSwitch.setTextColor(UiKit.TEXT);smsSwitch.setChecked(NexaStore.smsEnabled(this));sms.addView(smsSwitch);smsNumber=field("شماره مجاز برای پیامک اضطراری");smsNumber.setInputType(InputType.TYPE_CLASS_PHONE);smsNumber.setText(NexaStore.smsNumber(this));sms.addView(smsNumber,UiKit.matchWrap(this,8,6));smsCode=field("کد محرمانه؛ مثلاً NX-4827");smsCode.setText(NexaStore.smsCode(this));sms.addView(smsCode,UiKit.matchWrap(this,0,8));smsAnyone=UiKit.styledSwitch(this);smsAnyone.setText("اجازه استفاده از کد از هر شماره (با احتیاط)");
        smsAnyone.setTextColor(UiKit.TEXT);smsAnyone.setChecked(NexaStore.smsFromAnyone(this));sms.addView(smsAnyone);
        sms.addView(UiKit.muted(this,"برای چند مخاطب، شماره‌ها را با «،» یا خط جدید جدا کن. کد باید حداقل ۸ کاراکتر باشد و متن پیامک دقیقاً همان کد باشد."),UiKit.matchWrap(this,6,8));
        Button smsContact=UiKit.secondaryButton(this,"➕ انتخاب مخاطب مجاز");
        smsContact.setOnClickListener(v->{Intent intent=new Intent(Intent.ACTION_PICK,
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI);startActivityForResult(intent,REQ_SMS_CONTACT);});
        sms.addView(smsContact,UiKit.matchWrap(this,0,9));
        smsSavedStatus=UiKit.muted(this,NexaStore.smsCode(this).isEmpty()?"هنوز کدی ذخیره نشده.":"✓ کد اضطراری ذخیره شده و فعال است.");if(!NexaStore.smsCode(this).isEmpty())smsSavedStatus.setTextColor(UiKit.TEAL);sms.addView(smsSavedStatus,UiKit.matchWrap(this,0,8));
        saveSms=UiKit.secondaryButton(this,NexaStore.smsCode(this).isEmpty()?"ذخیره کد اضطراری":"✓ کد اضطراری ذخیره شده");saveSms.setOnClickListener(v->{String code=smsCode.getText().toString().trim();
            if(smsSwitch.isChecked()&&code.length()<8){Toast.makeText(this,"کد اضطراری باید حداقل ۸ کاراکتر باشد.",Toast.LENGTH_LONG).show();return;}
            NexaStore.setSmsEnabled(this,smsSwitch.isChecked());NexaStore.setSmsNumber(this,smsNumber.getText().toString().trim());
            NexaStore.setSmsFromAnyone(this,smsAnyone.isChecked());NexaStore.setSmsCode(this,code);saveSms.setText("✓ کد اضطراری ذخیره شده");smsSavedStatus.setText("✓ تنظیمات پیامک اضطراری ذخیره شد.");smsSavedStatus.setTextColor(UiKit.TEAL);Toast.makeText(this,"ذخیره شد.",Toast.LENGTH_SHORT).show();});sms.addView(saveSms);addCollapsibleSettingsSection(root,sms,"📩 کد اضطراری پیامکی");
        LinearLayout tools=UiKit.colorfulCardLayout(this,3);tools.addView(UiKit.sectionTitle(this,"امنیت و پشتیبان‌گیری"));Button security=UiKit.secondaryButton(this,"🔐 PIN و اثر انگشت");security.setOnClickListener(v->startActivity(new Intent(this,SecurityActivity.class)));tools.addView(security,UiKit.matchWrap(this,10,8));Button export=UiKit.secondaryButton(this,"⬆ تهیه فایل Backup");export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Nexa_Backup.json");startActivityForResult(i,REQ_EXPORT);});tools.addView(export,UiKit.matchWrap(this,0,8));Button imp=UiKit.secondaryButton(this,"⬇ بازیابی Backup");imp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");startActivityForResult(i,REQ_IMPORT);});tools.addView(imp,UiKit.matchWrap(this,0,8));tools.addView(UiKit.muted(this,"برای امنیت، رمزهای Nexa Vault در Backup عمومی منتقل نمی‌شوند؛ کلید Vault فقط داخل Android Keystore همین دستگاه است."),UiKit.matchWrap(this,0,8));Button test=UiKit.secondaryButton(this,"🧪 Nexa Test Center");test.setOnClickListener(v->startActivity(new Intent(this,TestCenterActivity.class)));tools.addView(test);addCollapsibleSettingsSection(root,tools,"🛡 امنیت و پشتیبان‌گیری");
        LinearLayout sounds=UiKit.colorfulCardLayout(this,5);
        sounds.addView(UiKit.sectionTitle(this,"🎵 صدای هشدارهای Nexa"));
        sounds.addView(UiKit.muted(this,"برای هر دسته، صدای پیش‌فرض، زنگ‌های گوشی یا فایل صوتی حافظه داخلی/کارت حافظه را انتخاب کن. فایل خارجی تا وقتی متصل و قابل‌خواندن باشد پخش می‌شود."),UiKit.matchWrap(this,6,10));
        int[] profiles={NexaAudioController.SOUND_ALARM,NexaAudioController.SOUND_REMINDER,
                NexaAudioController.SOUND_BATTERY,NexaAudioController.SOUND_THEFT,
                NexaAudioController.SOUND_SILENT_EXIT};
        String[] labels={"دارو و هشدار عمومی","یادآورها و قرارها","باتری و شارژ","امنیت و ضدسرقت","پایان حالت سکوت"};
        for(int j=0;j<profiles.length;j++){
            final int profile=profiles[j];
            Button choose=UiKit.secondaryButton(this,"🎵 "+labels[j]+" — انتخاب صدا");
            choose.setOnClickListener(v->showSoundChoices(profile));
            sounds.addView(choose,UiKit.matchWrap(this,0,7));
        }
        addCollapsibleSettingsSection(root,sounds,"🎵 انتخاب صدای هشدارها");
        LinearLayout alarmPrefs=UiKit.colorfulCardLayout(this,5);alarmPrefs.addView(UiKit.sectionTitle(this,"⏰ رفتار زنگ هشدار"));alarmPrefs.addView(UiKit.muted(this,"پیش‌فرض Nexa این است که زنگ و ویبره تا تأیید خودت ادامه داشته باشد. اگر خواستی می‌توانی مدت زنگ را محدود کنی؛ تکرار ۵ دقیقه‌ای تا تأیید همچنان برقرار می‌ماند."),UiKit.matchWrap(this,6,10));
        Spinner ringDuration=UiKit.styledSpinner(this);String[] ringLabels={"تا تأیید من زنگ بزند","۳۰ ثانیه","۱ دقیقه","۲ دقیقه","۵ دقیقه"};long[] ringValues={0L,30_000L,60_000L,120_000L,300_000L};ArrayAdapter<String> ringAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,ringLabels){@Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);return t;}@Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);return t;}};ringDuration.setAdapter(ringAdapter);long currentRing=AppPrefs.getAlarmRingDurationMs(this);for(int i=0;i<ringValues.length;i++)if(ringValues[i]==currentRing)ringDuration.setSelection(i);ringDuration.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){AppPrefs.setAlarmRingDurationMs(SettingsActivity.this,ringValues[pos]);}public void onNothingSelected(android.widget.AdapterView<?> p){}});alarmPrefs.addView(ringDuration);addCollapsibleSettingsSection(root,alarmPrefs,"⏰ رفتار زنگ هشدار");
        LinearLayout dataTools=UiKit.colorfulCardLayout(this,4);dataTools.addView(UiKit.sectionTitle(this,"دفتر مشترک و فایل‌های Nexa"));Button entityManager=UiKit.secondaryButton(this,"🏪 فروشندگان، بانک‌ها و کارت‌ها");entityManager.setOnClickListener(v->startActivity(new Intent(this,SharedEntitiesActivity.class)));dataTools.addView(entityManager,UiKit.matchWrap(this,10,8));Button mediaManager=UiKit.secondaryButton(this,"🖼 مدیریت مرکزی فایل‌ها و فاکتورها");mediaManager.setOnClickListener(v->startActivity(new Intent(this,FileCenterActivity.class)));dataTools.addView(mediaManager);addCollapsibleSettingsSection(root,dataTools,"🗂 دفتر مشترک و فایل‌های Nexa");
        LinearLayout monitor=UiKit.cardLayout(this);LinearLayout mr=new LinearLayout(this);mr.setGravity(Gravity.CENTER_VERTICAL);TextView mt=UiKit.sectionTitle(this,"تشخیص خودکار Silent / Vibrate");mr.addView(mt,new LinearLayout.LayoutParams(0,-2,1f));Switch sw=UiKit.styledSwitch(this);sw.setChecked(AppPrefs.isMonitoringEnabled(this));sw.setText(sw.isChecked()?"روشن":"خاموش");mr.addView(sw);monitor.addView(mr);monitor.addView(UiKit.muted(this,"پس از روشن‌شدن گوشی، Nexa دوباره آماده می‌شود."),UiKit.matchWrap(this,8,0));sw.setOnCheckedChangeListener((b,v)->{AppPrefs.setMonitoringEnabled(this,v);sw.setText(v?"روشن":"خاموش");});addCollapsibleSettingsSection(root,monitor,"🔕 تشخیص خودکار Silent / Vibrate");
        LinearLayout compat=UiKit.colorfulCardLayout(this,6);compat.addView(UiKit.sectionTitle(this,"📱 سازگاری این دستگاه"));
        String device=android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL+" • Android "+android.os.Build.VERSION.RELEASE+" (API "+android.os.Build.VERSION.SDK_INT+")";
        String maker=Build.MANUFACTURER==null?"":Build.MANUFACTURER.toLowerCase(java.util.Locale.US);String brandHint="";
        if(maker.contains("xiaomi")||maker.contains("redmi"))brandHint="\nنکته Xiaomi/Redmi: برای هشدارهای مطمئن، Autostart و Battery saver برنامه را هم بررسی کن.";
        else if(maker.contains("samsung"))brandHint="\nنکته Samsung: اگر هشدارها دیر می‌رسند، Nexa را از Sleeping/Deep sleeping apps خارج کن.";
        else if(maker.contains("huawei")||maker.contains("honor"))brandHint="\nنکته Huawei/Honor: اجرای پس‌زمینه Nexa را در App launch روی حالت دستی و مجاز بررسی کن.";
        else if(maker.contains("oneplus")||maker.contains("oppo")||maker.contains("realme"))brandHint="\nنکته دستگاه: Battery optimization و Auto launch را برای Nexa بررسی کن.";
        compat.addView(UiKit.muted(this,device+"\nNexa از Android 8 به بالا پشتیبانی می‌کند. وضعیت مجوزهای هشدار و اجرای پس‌زمینه از بخش «وضعیت دسترسی‌ها» قابل بررسی است."+brandHint),UiKit.matchWrap(this,6,10));
        LinearLayout compatActions=new LinearLayout(this);Button appSettings=UiKit.secondaryButton(this,"تنظیمات برنامه");Button notifSettings=UiKit.secondaryButton(this,"تنظیمات اعلان‌ها");
        appSettings.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}});
        notifSettings.setOnClickListener(v->{try{Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());startActivity(i);}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}});
        compatActions.addView(appSettings,new LinearLayout.LayoutParams(0,-2,1f));compatActions.addView(notifSettings,new LinearLayout.LayoutParams(0,-2,1f));compat.addView(compatActions);addCollapsibleSettingsSection(root,compat,"📱 سازگاری این دستگاه");
        LinearLayout about=UiKit.cardLayout(this);about.setBackground(UiKit.accentCard(this));about.addView(UiKit.sectionTitle(this,"درباره Nexa"));TextView info=UiKit.muted(this,"NEXA "+VersionUtil.name(this)+"\nObsidian Personal Assistant\n\nسازنده: Darvish\nشماره تماس سازنده: 09354485733\nایمیل: "+(NexaStore.emailSupabaseUrl(this).trim().isEmpty()?"پیکربندی نشده":(NexaStore.emailVerified(this)?"تأیید شده":"پیکربندی شده")));info.setTextSize(14);about.addView(info,UiKit.matchWrap(this,8,0));addCollapsibleSettingsSection(root,about,"ℹ درباره Nexa");setContentView(sc);refreshStatuses();}
    private void showSoundChoices(int profile){
        pendingSoundProfile=profile;
        new android.app.AlertDialog.Builder(this).setTitle("انتخاب صدای هشدار")
            .setItems(new String[]{"صدای پیش‌فرض Nexa","زنگ‌ها و اعلان‌های گوشی",
                "فایل صوتی حافظه داخلی یا خارجی","شنیدن صدای فعلی (۵ ثانیه)"},(d,which)->{
                if(which==0){
                    AlarmSoundSelection.save(this,profile,null);
                    Toast.makeText(this,"صدای پیش‌فرض انتخاب شد",Toast.LENGTH_SHORT).show();
                }else if(which==1){
                    Intent i=new Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER);
                    i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE,
                        android.media.RingtoneManager.TYPE_ALARM|
                        android.media.RingtoneManager.TYPE_RINGTONE|
                        android.media.RingtoneManager.TYPE_NOTIFICATION);
                    i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,false);
                    i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                        AlarmSoundSelection.resolve(this,profile));
                    try{startActivityForResult(i,REQ_SOUND_SYSTEM);}
                    catch(Exception e){Toast.makeText(this,"انتخابگر زنگ در این گوشی موجود نیست",Toast.LENGTH_LONG).show();}
                }else if(which==2){
                    try{startActivityForResult(AlarmSoundSelection.audioDocumentIntent(),REQ_SOUND_DOCUMENT);}
                    catch(Exception e){Toast.makeText(this,"انتخاب فایل صوتی ممکن نیست",Toast.LENGTH_LONG).show();}
                }else{
                    if(NexaAudioController.getActivePriority()>NexaAudioController.PRIORITY_NORMAL){
                        Toast.makeText(this,"ابتدا هشدار فعال را متوقف کنید",Toast.LENGTH_SHORT).show();
                        return;
                    }
                    NexaAudioController.startAlarm(this,"sound-preview",
                        NexaAudioController.PRIORITY_NORMAL,profile);
                    handler.postDelayed(()->NexaAudioController.stopOwner("sound-preview"),5000);
                }
            }).setNegativeButton("بستن",null).show();
    }

    private void showBankManager(){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"کارت‌های بانکی"),UiKit.matchWrap(this,0,8));java.util.List<NexaStore.BankCard> cards=NexaStore.bankCards(this);if(cards.isEmpty())box.addView(UiKit.muted(this,"هنوز کارتی ثبت نشده."),UiKit.matchWrap(this,0,8));for(NexaStore.BankCard c:cards){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.addView(UiKit.muted(this,c.display()),new LinearLayout.LayoutParams(0,-2,1f));Button e=UiKit.editIconButton(this);e.setOnClickListener(v->bankEditDialog(c));row.addView(e,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));Button d=UiKit.deleteIconButton(this);d.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("حذف کارت؟").setMessage(c.display()).setPositiveButton("حذف",(x,w)->{NexaStore.removeBankCard(this,c.id);showBankManager();}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42));dl.setMargins(UiKit.dp(this,4),0,0,0);row.addView(d,dl);box.addView(row,UiKit.matchWrap(this,0,5));}Button add=UiKit.addIconButton(this);add.setOnClickListener(v->bankEditDialog(null));box.addView(add,UiKit.matchWrap(this,8,0));new android.app.AlertDialog.Builder(this).setTitle("مدیریت بانک‌ها").setView(box).setNegativeButton("بستن",null).show();}
    private void bankEditDialog(NexaStore.BankCard existing){LinearLayout box=UiKit.dialogPanel(this);EditText bank=field("نام بانک");EditText label=field("عنوان؛ مثلاً کارت روزمره");EditText last4=field("۴ رقم آخر کارت (اختیاری)");last4.setInputType(InputType.TYPE_CLASS_NUMBER);if(existing!=null){bank.setText(existing.bank);label.setText(existing.label);last4.setText(existing.last4);}box.addView(bank);box.addView(label);box.addView(last4);new android.app.AlertDialog.Builder(this).setTitle(existing==null?"کارت جدید":"ویرایش کارت").setView(box).setPositiveButton("ذخیره",(d,w)->{if(bank.getText().toString().trim().isEmpty())return;NexaStore.BankCard c=existing==null?new NexaStore.BankCard():existing;c.bank=bank.getText().toString().trim();c.label=label.getText().toString().trim();String l=last4.getText().toString().trim();c.last4=l.length()>4?l.substring(l.length()-4):l;NexaStore.upsertBankCard(this,c);Toast.makeText(this,"کارت ذخیره شد.",Toast.LENGTH_SHORT).show();}).setNegativeButton("انصراف",null).show();}
    private String mediaModuleLabel(String module){if("shopping".equals(module))return "فاکتورهای خرید";if("docs".equals(module))return "مدارک";if("garage".equals(module))return "گاراژ";if("home".equals(module))return "خانه";if("case".equals(module))return "پرونده‌ها";if("assets".equals(module))return "دارایی‌ها";return module;}
    private void showMediaManager(){int count=AttachmentStore.count(this);long bytes=AttachmentStore.totalBytes(this);LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"تصاویر ذخیره‌شده در Nexa"));box.addView(UiKit.muted(this,count+" تصویر • "+AttachmentStore.humanSize(bytes)),UiKit.matchWrap(this,6,10));String[] modules={"shopping","docs","garage","home","case","assets","general"};boolean any=false;for(String module:modules){int mc=AttachmentStore.countExistingModule(this,module);if(mc<=0)continue;any=true;Button b=UiKit.secondaryButton(this,"🗂 "+mediaModuleLabel(module)+" • "+mc+" تصویر • "+AttachmentStore.humanSize(AttachmentStore.bytesExistingModule(this,module)));b.setOnClickListener(v->confirmDeleteMedia(module));box.addView(b,UiKit.matchWrap(this,0,7));}if(!any)box.addView(UiKit.muted(this,"هنوز تصویر ذخیره‌شده‌ای وجود ندارد."),UiKit.matchWrap(this,0,8));Button all=UiKit.secondaryButton(this,"🗑 حذف همه تصاویر Nexa");all.setOnClickListener(v->confirmDeleteMedia("all"));box.addView(all,UiKit.matchWrap(this,5,0));new android.app.AlertDialog.Builder(this).setView(box).setNegativeButton("بستن",null).show();}
    private void confirmDeleteMedia(String scope){boolean all="all".equals(scope);String label=all?"همه تصاویر Nexa":mediaModuleLabel(scope);int count=all?AttachmentStore.count(this):AttachmentStore.countExistingModule(this,scope);String title=label+" پاک شود؟";new android.app.AlertDialog.Builder(this).setTitle(title).setMessage(count+" تصویر انتخاب شده است. این کار برگشت‌پذیر نیست؛ عکس اصلی گالری گوشی حذف نمی‌شود.").setPositiveButton("ادامه",(d,w)->new android.app.AlertDialog.Builder(this).setTitle("تأیید نهایی").setMessage("حذف "+label+" قطعی است. مطمئنی؟").setPositiveButton("مطمئنم، پاک کن",(d2,w2)->{if(all){AttachmentStore.deleteAll(this);NexaStore.clearShoppingReceipts(this);}else{if("shopping".equals(scope)){for(NexaStore.ShoppingReceipt r:NexaStore.shoppingReceipts(this))AttachmentStore.deletePath(r.localPath);NexaStore.clearShoppingReceipts(this);}AttachmentStore.deleteExistingModule(this,scope);}Toast.makeText(this,"تصاویر انتخاب‌شده از Nexa پاک شدند.",Toast.LENGTH_LONG).show();}).setNegativeButton("انصراف",null).show()).setNegativeButton("انصراف",null).show();}
    private String pendingVaultPassword="";
    private void askVaultPassword(boolean export){EditText p=field(export?"گذرواژه Backup (حداقل ۸ کاراکتر)":"گذرواژه فایل Vault");p.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);new android.app.AlertDialog.Builder(this).setTitle(export?"Backup رمزگذاری‌شده Vault":"بازیابی Vault").setMessage(export?"این گذرواژه را فراموش نکن؛ بدون آن فایل قابل بازیابی نیست.":"Restore، محتوای فعلی Vault را جایگزین می‌کند.").setView(p).setPositiveButton("ادامه",(d,w)->{String pass=p.getText().toString();if(pass.length()<8){Toast.makeText(this,"گذرواژه باید حداقل ۸ کاراکتر باشد.",Toast.LENGTH_LONG).show();return;}pendingVaultPassword=pass;if(export){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Nexa_Vault_"+VersionUtil.name(this)+".nexavault");startActivityForResult(i,REQ_VAULT_EXPORT);}else{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");startActivityForResult(i,REQ_VAULT_IMPORT);}}).setNegativeButton("انصراف",null).show();}
    private EditText field(String h){return UiKit.styleField(this,new EditText(this),h);}
    private TextView status(String x){TextView t=UiKit.muted(this,x);t.setTextSize(14);return t;}
    private String pfx(boolean x){return x?"✓  ":"○  ";}
    private boolean runtimeReady(){return checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED&&(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED);}
    private boolean screening(){if(Build.VERSION.SDK_INT<29)return true;RoleManager rm=getSystemService(RoleManager.class);return rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)&&rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);}
    private void refreshStatuses(){if(overlayStatus==null)return;NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);boolean o=Settings.canDrawOverlays(this),d=nm.isNotificationPolicyAccessGranted(),r=runtimeReady(),s=screening(),exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms(),full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent(),bat=pm.isIgnoringBatteryOptimizations(getPackageName());overlayStatus.setText(pfx(o)+"نمایش روی برنامه‌ها");dndStatus.setText(pfx(d)+"کنترل Silent / Vibrate");phoneStatus.setText(pfx(r)+"تماس، مخاطبین، پیامک و اعلان‌ها");screeningStatus.setText(pfx(s)+"Call Screening تماس‌های مجاز");exactAlarmStatus.setText(pfx(exact)+"آلارم دقیق");fullScreenStatus.setText(pfx(full)+"نمایش تمام‌صفحه هشدار روی Lock Screen");batteryStatus.setText(pfx(bat)+"فعالیت پس‌زمینه بدون محدودیت");setupButton.setText(o&&d&&r&&s&&exact&&full&&bat?"همه دسترسی‌ها آماده‌اند ✓":"شروع راه‌اندازی کامل");}
    private boolean stepGranted(int s){if(s==1)return Settings.canDrawOverlays(this);if(s==2)return ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted();if(s==3)return Build.VERSION.SDK_INT<31||((AlarmManager)getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();if(s==4)return Build.VERSION.SDK_INT<34||((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent();if(s==5)return ((PowerManager)getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());return true;}
    private void continueSetup(){refreshStatuses();if(!Settings.canDrawOverlays(this)){waitingSpecialStep=1;startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;}NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);if(!nm.isNotificationPolicyAccessGranted()){waitingSpecialStep=2;startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));return;}ArrayList<String> rt=new ArrayList<>();if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.READ_PHONE_STATE);if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.READ_CONTACTS);if(checkSelfPermission(Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.RECEIVE_SMS);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.POST_NOTIFICATIONS);if(!rt.isEmpty()){requestPermissions(rt.toArray(new String[0]),REQ_RUNTIME);return;}if(Build.VERSION.SDK_INT>=29&&!screening()){RoleManager rm=getSystemService(RoleManager.class);startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),REQ_CALL_SCREENING);return;}AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){waitingSpecialStep=3;try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){setupInProgress=false;}return;}if(Build.VERSION.SDK_INT>=34&&!nm.canUseFullScreenIntent()){waitingSpecialStep=4;try{startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));}catch(Exception e){setupInProgress=false;}return;}PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);if(!pm.isIgnoringBatteryOptimizations(getPackageName())){waitingSpecialStep=5;try{startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}return;}setupInProgress=false;AppPrefs.setSetupCompleted(this,true);ReminderScheduler.rescheduleAll(this);Intent mon=new Intent(this,SilentTimerService.class);mon.setAction(SilentTimerService.ACTION_MONITOR);try{if(Build.VERSION.SDK_INT>=26)startForegroundService(mon);else startService(mon);}catch(Exception ignored){}refreshStatuses();Toast.makeText(this,"راه‌اندازی Nexa کامل شد.",Toast.LENGTH_LONG).show();if(autoFirstRunSetup)handler.postDelayed(this::finish,700);}
    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);if(r!=REQ_RUNTIME)return;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED){setupInProgress=false;Toast.makeText(this,"برای ادامه، دسترسی‌های این مرحله باید تأیید شوند.",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this::continueSetup,250);}
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);
        if(r==REQ_SOUND_DOCUMENT || r==REQ_SOUND_SYSTEM){
            if(result==RESULT_OK && data!=null){
                Uri uri=r==REQ_SOUND_DOCUMENT?data.getData():
                    (Uri)data.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if(uri!=null){
                    if(r==REQ_SOUND_DOCUMENT){
                        try{getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);}
                        catch(SecurityException ignored){}
                    }
                    if(!AlarmSoundSelection.isSupportedUri(uri)){
                        Toast.makeText(this,"آدرس فایل صوتی معتبر نیست",Toast.LENGTH_LONG).show();
                    }else if(!AlarmSoundSelection.isReadable(this,uri)){
                        Toast.makeText(this,"فایل صوتی قابل خواندن نیست؛ انتخاب قبلی حفظ شد",Toast.LENGTH_LONG).show();
                    }else{
                        AlarmSoundSelection.save(this,pendingSoundProfile,uri);
                        Toast.makeText(this,"صدای انتخاب‌شده ذخیره شد",Toast.LENGTH_SHORT).show();
                    }
                }
            }
            return;
        }
if(r==REQ_UNLOCK){awaitingSettingsUnlock=false;if(result==RESULT_OK&&SecurityGate.isUnlocked()){
            if(!verifiedSettings){verifiedSettings=true;openSettings();}}else finish();return;}
        if(r==REQ_SMS_CONTACT){if(result==RESULT_OK&&data!=null&&data.getData()!=null){
            try(android.database.Cursor cr=getContentResolver().query(data.getData(),new String[]{
                android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
                if(cr!=null&&cr.moveToFirst()&&smsNumber!=null){
                    String entry=cr.getString(0)+"|"+cr.getString(1);
                    smsNumber.setText(smsNumber.getText().toString()+
                        (smsNumber.length()>0?";":"")+entry);
                }
            }catch(Exception ignored){}
        }return;}if(r==REQ_CALL_SCREENING){if(!screening()){setupInProgress=false;Toast.makeText(this,"Call Screening فعال نشد.",Toast.LENGTH_LONG).show();}else handler.postDelayed(this::continueSetup,250);return;}if(result!=RESULT_OK||data==null||data.getData()==null)return;if(r==REQ_VAULT_EXPORT||r==REQ_VAULT_IMPORT){try{if(r==REQ_VAULT_EXPORT){String raw=VaultBackupUtil.exportVault(this,pendingVaultPassword);OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(raw.getBytes(java.nio.charset.StandardCharsets.UTF_8));out.close();Toast.makeText(this,"Backup رمزگذاری‌شده Vault ساخته شد.",Toast.LENGTH_LONG).show();}else{BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData())));StringBuilder q=new StringBuilder();String ln;while((ln=br.readLine())!=null)q.append(ln);br.close();boolean ok=VaultBackupUtil.importVault(this,q.toString(),pendingVaultPassword);Toast.makeText(this,ok?"Vault با موفقیت بازیابی شد.":"گذرواژه یا فایل Vault معتبر نیست.",Toast.LENGTH_LONG).show();}}catch(Exception e){Toast.makeText(this,"عملیات Vault انجام نشد.",Toast.LENGTH_LONG).show();}finally{pendingVaultPassword="";}return;}try{if(r==REQ_EXPORT){OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(NexaStore.exportJson(this).getBytes(java.nio.charset.StandardCharsets.UTF_8));out.close();Toast.makeText(this,"Backup ساخته شد.",Toast.LENGTH_SHORT).show();}else if(r==REQ_IMPORT){BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData())));StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null)s.append(line);br.close();if(NexaStore.importJson(this,s.toString())){ReminderScheduler.rescheduleAll(this);EmergencyCardManager.refresh(this);Toast.makeText(this,"Backup بازیابی شد.",Toast.LENGTH_LONG).show();recreate();}else Toast.makeText(this,"فایل معتبر نیست.",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"خطا در فایل Backup.",Toast.LENGTH_SHORT).show();}}
}
