package com.example.silenttimer;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.HorizontalScrollView;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.ArrayList;

public class SettingsActivity extends Activity {
    public static final String EXTRA_START_SETUP="start_setup";
    private static final int REQ_RUNTIME=7101,REQ_CALL_SCREENING=7102,REQ_EXPORT=7103,REQ_IMPORT=7104,REQ_UNLOCK=7190,REQ_SMS_CONTACT=7191,REQ_VAULT_EXPORT=7192,REQ_VAULT_IMPORT=7193,REQ_SOUND_DOCUMENT=7194,REQ_SOUND_SYSTEM=7195;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean setupInProgress=false,autoFirstRunSetup=false;private int waitingSpecialStep=0;
    private TextView overlayStatus,dndStatus,phoneStatus,screeningStatus,exactAlarmStatus,fullScreenStatus,batteryStatus,smsSavedStatus;private Button setupButton,saveSms;private EditText smsNumber,smsCode;private Switch smsSwitch,smsAnyone;
    private int pendingSoundProfile=NexaAudioController.SOUND_ALARM;
    private final java.util.Map<Integer,Button> soundButtons=new java.util.HashMap<>();
    private android.media.MediaPlayer activeSoundPreview;
    private final Runnable stopSoundPreview=()->stopPreview();
    private void stopPreview(){
        handler.removeCallbacks(stopSoundPreview);
        if(activeSoundPreview!=null){
            try{activeSoundPreview.stop();}catch(Exception ignored){}
            try{activeSoundPreview.release();}catch(Exception ignored){}
            activeSoundPreview=null;
        }
    }
    private void refreshSoundButton(int profile){
        Button b=soundButtons.get(profile);
        if(b!=null)b.setText("🎵 "+soundProfileLabel(profile)+"\n↳ "+AlarmSoundSelection.displayName(this,profile));
    }
    private void previewSound(int profile){
        if(!AlarmSoundSelection.canPreview(NexaAudioController.getActivePriority())){
            Toast.makeText(this,"برای پیش‌شنیدن ابتدا هشدار فعال را متوقف کنید",Toast.LENGTH_SHORT).show();
            return;
        }
        stopPreview();
        try{
            Uri uri=AlarmSoundSelection.readableOrFallback(this,profile);
            if(uri==null)throw new IllegalStateException("No preview sound");
            android.media.MediaPlayer preview=new android.media.MediaPlayer();
            try{
                preview.setAudioAttributes(new android.media.AudioAttributes.Builder()
                    .setUsage(profile==NexaAudioController.SOUND_SILENT_EXIT?
                        android.media.AudioAttributes.USAGE_NOTIFICATION_EVENT:
                        android.media.AudioAttributes.USAGE_ALARM)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
                preview.setDataSource(this,uri);
                preview.setLooping(false);
                float gain=AlarmSoundSelection.volumeGain(this,profile);
                preview.setVolume(gain,gain);
                preview.prepare();
                activeSoundPreview=preview;
                preview.setOnCompletionListener(mp->{
                    if(activeSoundPreview==mp)stopPreview();
                });
                preview.start();
                handler.postDelayed(stopSoundPreview,5000L);
            }catch(Exception e){
                if(activeSoundPreview==preview)activeSoundPreview=null;
                try{preview.release();}catch(Exception ignored){}
                throw e;
            }
        }catch(Exception e){
            stopPreview();
            Toast.makeText(this,"پیش‌شنیدن این صدا ممکن نیست",Toast.LENGTH_LONG).show();
        }
    }
    private String soundProfileLabel(int p){
        if(p==NexaAudioController.SOUND_ALARM)return "دارو و هشدار عمومی";
        if(p==NexaAudioController.SOUND_REMINDER)return "یادآورها و قرارها";
        if(p==NexaAudioController.SOUND_BATTERY)return "باتری و شارژ";
        if(p==NexaAudioController.SOUND_THEFT)return "امنیت و ضدسرقت";
        return "پایان حالت سکوت";
    }
    @Override protected void onStop(){stopPreview();super.onStop();}
    private boolean verifiedSettings=false,awaitingSettingsUnlock=false;
    @Override protected void onCreate(Bundle b){super.onCreate(b);UiKit.applyWindow(this);
        boolean firstSetup=getIntent().getBooleanExtra(EXTRA_START_SETUP,false)&&!AppPrefs.isSetupCompleted(this);
        if(firstSetup||!NexaStore.pinConfigured(this)||SecurityGate.isUnlocked()){verifiedSettings=true;openSettings();}
        else if(!awaitingSettingsUnlock){awaitingSettingsUnlock=true;startActivityForResult(new Intent(this,UnlockActivity.class),REQ_UNLOCK);}
    }
    private void openSettings(){buildUi();if(getIntent().getBooleanExtra(EXTRA_START_SETUP,false)){
        autoFirstRunSetup=!AppPrefs.isSetupCompleted(this);
        new android.app.AlertDialog.Builder(this)
            .setTitle("دسترسی‌های Nexa")
            .setMessage("برای اینکه تماس‌های مجاز، هشدارها، پیام اضطراری و زمان‌بندی‌ها درست کار کنند، Nexa فقط دسترسی‌های لازم را مرحله‌به‌مرحله درخواست می‌کند. اگر دسترسی‌ای را نخواهی، همان قابلیت محدود می‌شود و بعداً از تنظیمات می‌توانی فعالش کنی.")
            .setPositiveButton("ادامه و بررسی دسترسی‌ها",(d,w)->{setupInProgress=true;handler.postDelayed(this::continueSetup,250);})
            .setNegativeButton("فعلاً نه",null).show();
    }}
    @Override protected void onResume(){super.onResume();refreshStatuses();if(setupInProgress&&waitingSpecialStep!=0){int step=waitingSpecialStep;waitingSpecialStep=0;if(!stepGranted(step)){setupInProgress=false;Toast.makeText(this,"این دسترسی تأیید نشد. از همین صفحه دوباره راه‌اندازی کامل را بزن.",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this::continueSetup,300);}}
    private final java.util.ArrayList<LinearLayout> expandedSettings = new java.util.ArrayList<>();
    private final java.util.ArrayList<LinearLayout> settingsRows = new java.util.ArrayList<>();
    private final java.util.ArrayList<TextView> settingsArrows = new java.util.ArrayList<>();
    private final java.util.ArrayList<String> settingsTitles = new java.util.ArrayList<>();
    private ScrollView settingsScroll;
    private TextView settingsSearchSummary, settingsNoResults;
    private EditText settingsSearch;

    private String sectionHint(String title){
        if(title.contains("حساب کاربری"))return "مشخصات و نشانی ایمیل";
        if(title.contains("پنل ارسال"))return "اتصال ایمیل و کد بازیابی";
        if(title.contains("صندوق امن"))return "رمزگذاری و پشتیبان امن";
        if(title.contains("راه‌اندازی"))return "مجوزهای لازم و راه‌اندازی";
        if(title.contains("وضعیت دسترسی"))return "بررسی مجوزهای گوشی";
        if(title.contains("کد اضطراری"))return "شماره و رمز پیامکی";
        if(title.contains("پشتیبان‌گیری"))return "PIN، اثر انگشت و بکاپ";
        if(title.contains("انتخاب صدای"))return "صدای هشدارها و شدت آن‌ها";
        if(title.contains("رفتار زنگ"))return "مدت زنگ و تکرار هشدار";
        if(title.contains("دفتر مشترک"))return "بانک‌ها، کارت‌ها و فایل‌ها";
        if(title.contains("تشخیص خودکار"))return "پایش حالت سکوت گوشی";
        if(title.contains("سازگاری"))return "اعلان‌ها و تنظیمات دستگاه";
        return "نسخه و اطلاعات برنامه";
    }
    private void openSettingsSection(int index,boolean expand,boolean scrollToRow){
        if(index<0||index>=expandedSettings.size())return;
        for(int i=0;i<expandedSettings.size();i++){
            boolean active=expand&&i==index;
            expandedSettings.get(i).setVisibility(active?View.VISIBLE:View.GONE);
            settingsArrows.get(i).setText(active?"⌃":"⌄");
            settingsRows.get(i).setContentDescription((active?"بستن ":"باز کردن ")+settingsTitles.get(i));
        }
        if(expand&&scrollToRow&&settingsScroll!=null){
            LinearLayout chosen=settingsRows.get(index);
            settingsScroll.post(()->settingsScroll.smoothScrollTo(0,Math.max(0,chosen.getTop()-UiKit.dp(this,18))));
        }
    }
    private void filterSettings(String query){
        int visible=0;
        for(int i=0;i<settingsTitles.size();i++){
            boolean matches=SettingsDirectory.matches(settingsTitles.get(i)+" "+sectionHint(settingsTitles.get(i)),query);
            settingsRows.get(i).setVisibility(matches?View.VISIBLE:View.GONE);
            // Hiding a section never deletes its content or resets editable values.
            if(!matches)expandedSettings.get(i).setVisibility(View.GONE);
            settingsArrows.get(i).setText(expandedSettings.get(i).getVisibility()==View.VISIBLE?"⌃":"⌄");
            if(matches)visible++;
        }
        if(settingsSearchSummary!=null)settingsSearchSummary.setText(
                visible+" بخش از "+settingsTitles.size()+" بخش تنظیمات");
        if(settingsNoResults!=null)settingsNoResults.setVisibility(visible==0?View.VISIBLE:View.GONE);
    }
    private void openNamedSettings(String text){
        if(settingsSearch!=null)settingsSearch.setText("");
        for(int i=0;i<settingsTitles.size();i++){
            if(settingsTitles.get(i).contains(text)){openSettingsSection(i,true,true);return;}
        }
    }
    // Each pre-existing settings content view and all of its listeners are kept intact.
    private void addCollapsibleSettingsSection(LinearLayout root,LinearLayout content,String title){
        int firstSpace=title.indexOf(' ');
        String emoji=firstSpace>0?title.substring(0,firstSpace):"⚙️";
        String label=firstSpace>0?title.substring(firstSpace+1):title;
        LinearLayout row=UiKit.settingsDirectoryRow(this,emoji,label,sectionHint(title));
        root.addView(row,UiKit.matchWrap(this,0,7));
        settingsRows.add(row);settingsTitles.add(title);
        TextView arrow=(TextView)row.getChildAt(2);settingsArrows.add(arrow);
        expandedSettings.add(content);
        content.setVisibility(View.GONE);
        root.addView(content,UiKit.matchWrap(this,0,11));
        final int index=settingsRows.size()-1;
        row.setOnClickListener(v->openSettingsSection(index,
                expandedSettings.get(index).getVisibility()!=View.VISIBLE,false));
    }
    private void buildUi(){expandedSettings.clear();settingsRows.clear();settingsArrows.clear();settingsTitles.clear();ScrollView sc=new ScrollView(this);settingsScroll=sc;sc.setFillViewport(true);sc.setClipToPadding(false);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(UiKit.dp(this,16),UiKit.dp(this,18),UiKit.dp(this,16),UiKit.dp(this,34));root.setBackground(UiKit.screenBackground(this));root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);sc.addView(root);LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=UiKit.backButton(this);back.setOnClickListener(v->finish());head.addView(back);LinearLayout tb=new LinearLayout(this);tb.setOrientation(LinearLayout.VERTICAL);LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(0,-2,1f);tl.setMargins(UiKit.dp(this,12),0,0,0);head.addView(tb,tl);tb.addView(UiKit.title(this,"تنظیمات"));root.addView(head,UiKit.matchWrap(this,0,12));
        TextView pageIntro=UiKit.muted(this,"هر تنظیمی را سریع پیدا کن؛ همه گزینه‌های قبلی در همین صفحه در دسترس‌اند.");
        root.addView(pageIntro,UiKit.matchWrap(this,0,4));
        LinearLayout searchContainer=UiKit.cardLayout(this);
        searchContainer.setPadding(UiKit.dp(this,11),UiKit.dp(this,9),UiKit.dp(this,11),UiKit.dp(this,9));
        settingsSearch=UiKit.styleField(this,new EditText(this),"🔎 جست‌وجوی تنظیمات؛ مثل صدا، باتری، پشتیبان ...");
        settingsSearch.setSingleLine(true);
        settingsSearch.setTextSize(14f);
        settingsSearch.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        settingsSearch.setContentDescription("جست‌وجو در همه گروه‌های تنظیمات Nexa");
        settingsSearch.setOnEditorActionListener((v,action,event)->{
            if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){
                android.view.inputmethod.InputMethodManager keyboard=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                if(keyboard!=null)keyboard.hideSoftInputFromWindow(settingsSearch.getWindowToken(),0);
                settingsSearch.clearFocus();
                return true;
            }
            return false;
        });
        searchContainer.addView(settingsSearch);
        root.addView(searchContainer,UiKit.matchWrap(this,0,7));
        settingsSearchSummary=UiKit.muted(this,"");
        root.addView(settingsSearchSummary,UiKit.matchWrap(this,0,11));
        TextView shortcutsLabel=UiKit.sectionTitle(this,"دسترسی سریع");shortcutsLabel.setTextSize(14f);
        root.addView(shortcutsLabel,UiKit.matchWrap(this,0,6));
        HorizontalScrollView quickScroll=new HorizontalScrollView(this);
        quickScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout quickLinks=new LinearLayout(this);
        quickLinks.setOrientation(LinearLayout.HORIZONTAL);
        quickLinks.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] quickTitles={"🎵 صداها","📋 دسترسی‌ها","🔐 امنیت","📱 دستگاه"};
        String[] quickTargets={"انتخاب صدای","وضعیت دسترسی","امنیت و پشتیبان","سازگاری"};
        for(int i=0;i<quickTitles.length;i++){
            final String target=quickTargets[i];
            Button quick=UiKit.secondaryButton(this,quickTitles[i]);quick.setTextSize(12.5f);
            LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,48));
            qp.setMargins(0,0,UiKit.dp(this,7),0);
            quickLinks.addView(quick,qp);
            quick.setOnClickListener(v->openNamedSettings(target));
        }
        quickScroll.addView(quickLinks);
        root.addView(quickScroll,UiKit.matchWrap(this,0,11));
        TextView sectionsLabel=UiKit.sectionTitle(this,"همه تنظیمات");
        sectionsLabel.setTextColor(UiKit.TEXT);root.addView(sectionsLabel,UiKit.matchWrap(this,0,9));
        settingsNoResults=UiKit.muted(this,"برای این عبارت گزینه‌ای پیدا نشد. عبارت کوتاه‌تری بنویس.");
        settingsNoResults.setVisibility(View.GONE);
        root.addView(settingsNoResults,UiKit.matchWrap(this,0,9));
        settingsSearch.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){filterSettings(s.toString());}
            @Override public void afterTextChanged(Editable e){}
        });
        // Compact master settings: no decorative hero. All detail panels stay accessible below.
        LinearLayout account=UiKit.colorfulCardLayout(this,1);
        account.addView(UiKit.sectionTitle(this,"👤 حساب کاربری و ایمیل"));
        account.addView(UiKit.muted(this,"نام: "+NexaStore.accountName(this)+" • ایمیل ثبت‌شده: "+NexaStore.accountEmail(this)+
            "\nبرای بازیابی آنلاین، ایمیل را ثبت و پنل ارسال ایمیل را در همین صفحه تنظیم کن."),UiKit.matchWrap(this,7,8));
        Button editAccount=UiKit.secondaryButton(this,"✎ ویرایش مشخصات");
        editAccount.setOnClickListener(v->startActivity(new Intent(this,AccountSetupActivity.class)));
        account.addView(editAccount);addCollapsibleSettingsSection(root,account,"👤 حساب کاربری و ایمیل");
        LinearLayout email=UiKit.colorfulCardLayout(this,6);email.addView(UiKit.sectionTitle(this,"✉ پنل ارسال ایمیل و بازیابی"));
        email.addView(UiKit.muted(this,"برای ارسال واقعی کد تأیید، اطلاعات پروژه Supabase را وارد کن. Anon Key عمومی است؛ رمز ایمیل شخصی لازم نیست.\nوضعیت: "+(NexaStore.emailSupabaseUrl(this).trim().isEmpty()?"پیکربندی نشده":(NexaStore.emailVerified(this)?"متصل • ایمیل تأییدشده ✓":"پیکربندی شده • ایمیل هنوز تأیید نشده"))),UiKit.matchWrap(this,6,10));
        EditText emailUrl=field("Supabase URL");emailUrl.setText(NexaStore.emailSupabaseUrl(this));email.addView(emailUrl,UiKit.matchWrap(this,0,6));
        EditText emailKey=field("Supabase Anon Key");emailKey.setText(NexaStore.emailSupabaseAnon(this));emailKey.setTextDirection(View.TEXT_DIRECTION_LTR);email.addView(emailKey,UiKit.matchWrap(this,0,8));
        LinearLayout emailActions=new LinearLayout(this);Button saveEmail=UiKit.secondaryButton(this,"ذخیره تنظیمات");Button testEmail=UiKit.secondaryButton(this,"ارسال کد آزمایشی");
        saveEmail.setOnClickListener(v->{NexaStore.setEmailPanel(this,emailUrl.getText().toString().trim(),emailKey.getText().toString().trim());Toast.makeText(this,"تنظیمات ایمیل ذخیره شد.",Toast.LENGTH_SHORT).show();});
        testEmail.setOnClickListener(v->{NexaStore.setEmailPanel(this,emailUrl.getText().toString().trim(),emailKey.getText().toString().trim());String target=NexaStore.accountEmail(this);if(target.trim().isEmpty()){Toast.makeText(this,"ابتدا ایمیل حساب کاربری را ثبت کن.",Toast.LENGTH_LONG).show();return;}testEmail.setEnabled(false);testEmail.setText("در حال ارسال…");EmailRecoveryClient.sendOtp(this,target,(ok,msg)->{testEmail.setEnabled(true);testEmail.setText("ارسال کد آزمایشی");Toast.makeText(this,msg,Toast.LENGTH_LONG).show();});});
        emailActions.addView(saveEmail,new LinearLayout.LayoutParams(0,-2,1f));emailActions.addView(testEmail,new LinearLayout.LayoutParams(0,-2,1f));email.addView(emailActions);addCollapsibleSettingsSection(root,email,"✉ پنل ارسال ایمیل و بازیابی");
        LinearLayout secure=UiKit.colorfulCardLayout(this,3);secure.addView(UiKit.sectionTitle(this,"🔐 امنیت و Backup صندوق امن"));secure.addView(UiKit.muted(this,"Recovery Code، قفل خودکار و Backup رمزگذاری‌شده Vault. فایل Vault بدون گذرواژه قابل خواندن نیست."),UiKit.matchWrap(this,6,10));Button sec=UiKit.secondaryButton(this,"تنظیمات امنیتی");sec.setOnClickListener(v->startActivity(new Intent(this,SecurityActivity.class)));secure.addView(sec,UiKit.matchWrap(this,0,7));LinearLayout vb=new LinearLayout(this);Button ve=UiKit.secondaryButton(this,"خروجی امن Vault");Button vi=UiKit.secondaryButton(this,"بازیابی Vault");ve.setOnClickListener(v->askVaultPassword(true));vi.setOnClickListener(v->askVaultPassword(false));vb.addView(ve,new LinearLayout.LayoutParams(0,-2,1f));vb.addView(vi,new LinearLayout.LayoutParams(0,-2,1f));secure.addView(vb);addCollapsibleSettingsSection(root,secure,"🔐 امنیت و Backup صندوق امن");
        LinearLayout access=UiKit.colorfulCardLayout(this,0);access.addView(UiKit.sectionTitle(this,"راه‌اندازی کامل دسترسی‌ها"));access.addView(UiKit.muted(this,"در نصب اول خودکار اجرا می‌شود؛ هر صفحه را تأیید کنی، صفحه بعدی خودش باز می‌شود."),UiKit.matchWrap(this,6,14));setupButton=UiKit.primaryButton(this,"شروع راه‌اندازی کامل");setupButton.setOnClickListener(v->{setupInProgress=true;waitingSpecialStep=0;continueSetup();});access.addView(setupButton);addCollapsibleSettingsSection(root,access,"🛠 راه‌اندازی دسترسی‌ها");LinearLayout checklist=UiKit.colorfulCardLayout(this,1);checklist.addView(UiKit.sectionTitle(this,"وضعیت دسترسی‌ها"));overlayStatus=status("نمایش روی برنامه‌ها");dndStatus=status("کنترل Silent / Vibrate");phoneStatus=status("تماس، مخاطبین، پیامک و اعلان‌ها");screeningStatus=status("Call Screening تماس‌های مجاز");exactAlarmStatus=status("آلارم دقیق");fullScreenStatus=status("نمایش تمام‌صفحه هشدار روی Lock Screen");batteryStatus=status("فعالیت پس‌زمینه بدون محدودیت");checklist.addView(overlayStatus,UiKit.matchWrap(this,12,5));checklist.addView(dndStatus,UiKit.matchWrap(this,0,5));checklist.addView(phoneStatus,UiKit.matchWrap(this,0,5));checklist.addView(screeningStatus,UiKit.matchWrap(this,0,5));checklist.addView(exactAlarmStatus,UiKit.matchWrap(this,0,5));checklist.addView(fullScreenStatus,UiKit.matchWrap(this,0,5));checklist.addView(batteryStatus);
        LinearLayout accessActions=new LinearLayout(this);Button exactSettings=UiKit.secondaryButton(this,"آلارم دقیق");Button batterySettings=UiKit.secondaryButton(this,"باتری");
        exactSettings.setOnClickListener(v->{try{if(Build.VERSION.SDK_INT>=31)startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}});
        batterySettings.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}});
        accessActions.addView(exactSettings,new LinearLayout.LayoutParams(0,-2,1f));accessActions.addView(batterySettings,new LinearLayout.LayoutParams(0,-2,1f));checklist.addView(accessActions,UiKit.matchWrap(this,9,0));addCollapsibleSettingsSection(root,checklist,"📋 وضعیت دسترسی‌ها");
        LinearLayout sms=UiKit.colorfulCardLayout(this,2);sms.addView(UiKit.sectionTitle(this,"📩 کد اضطراری پیامکی"));sms.addView(UiKit.muted(this,"فقط اگر پیامک از شماره تعریف‌شده باشد و کد داخل متن باشد، گوشی از Silent/Vibrate خارج می‌شود."),UiKit.matchWrap(this,6,10));smsSwitch=UiKit.styledSwitch(this);smsSwitch.setText("فعال");smsSwitch.setTextColor(UiKit.TEXT);smsSwitch.setChecked(NexaStore.smsEnabled(this));sms.addView(smsSwitch);smsNumber=field("شماره مجاز برای پیامک اضطراری");smsNumber.setInputType(InputType.TYPE_CLASS_PHONE);smsNumber.setText(NexaStore.smsNumber(this));sms.addView(smsNumber,UiKit.matchWrap(this,8,6));smsCode=field("کد محرمانه؛ مثلاً NX-4827");smsCode.setText(NexaStore.smsCode(this));sms.addView(smsCode,UiKit.matchWrap(this,0,8));smsAnyone=UiKit.styledSwitch(this);smsAnyone.setText("اجازه استفاده از کد از هر شماره (با احتیاط)");
        smsAnyone.setTextColor(UiKit.TEXT);smsAnyone.setChecked(NexaStore.smsFromAnyone(this));sms.addView(smsAnyone);
        sms.addView(UiKit.muted(this,"برای چند مخاطب، شماره‌ها را با «،» یا خط جدید جدا کن. کد باید حداقل ۸ کاراکتر باشد و متن پیامک دقیقاً همان کد باشد."),UiKit.matchWrap(this,6,8));
        Button smsContact=UiKit.secondaryButton(this,"➕ انتخاب مخاطب مجاز");
        smsContact.setOnClickListener(v->{Intent intent=new Intent(Intent.ACTION_PICK,
            android.provider.ContactsContract.CommonDataKinds.Phone.CONTENT_URI);startActivityForResult(intent,REQ_SMS_CONTACT);});
        sms.addView(smsContact,UiKit.matchWrap(this,0,9));
        smsSavedStatus=UiKit.muted(this,NexaStore.smsCode(this).isEmpty()?"هنوز کدی ذخیره نشده.":"✓ کد اضطراری ذخیره شده و فعال است.");if(!NexaStore.smsCode(this).isEmpty())smsSavedStatus.setTextColor(UiKit.TEAL);sms.addView(smsSavedStatus,UiKit.matchWrap(this,0,8));
        saveSms=UiKit.secondaryButton(this,NexaStore.smsCode(this).isEmpty()?"ذخیره کد اضطراری":"✓ کد اضطراری ذخیره شده");saveSms.setOnClickListener(v->{String code=smsCode.getText().toString().trim();
            if(smsSwitch.isChecked()&&code.length()<8){Toast.makeText(this,"کد اضطراری باید حداقل ۸ کاراکتر باشد.",Toast.LENGTH_LONG).show();return;}
            NexaStore.setSmsEnabled(this,smsSwitch.isChecked());NexaStore.setSmsNumber(this,smsNumber.getText().toString().trim());
            NexaStore.setSmsFromAnyone(this,smsAnyone.isChecked());NexaStore.setSmsCode(this,code);saveSms.setText("✓ کد اضطراری ذخیره شده");smsSavedStatus.setText("✓ تنظیمات پیامک اضطراری ذخیره شد.");smsSavedStatus.setTextColor(UiKit.TEAL);Toast.makeText(this,"ذخیره شد.",Toast.LENGTH_SHORT).show();});sms.addView(saveSms);addCollapsibleSettingsSection(root,sms,"📩 کد اضطراری پیامکی");
        LinearLayout tools=UiKit.colorfulCardLayout(this,3);tools.addView(UiKit.sectionTitle(this,"امنیت و پشتیبان‌گیری"));Button security=UiKit.secondaryButton(this,"🔐 PIN و اثر انگشت");security.setOnClickListener(v->startActivity(new Intent(this,SecurityActivity.class)));tools.addView(security,UiKit.matchWrap(this,10,8));Button export=UiKit.secondaryButton(this,"⬆ تهیه فایل Backup");export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Nexa_Backup.json");startActivityForResult(i,REQ_EXPORT);});tools.addView(export,UiKit.matchWrap(this,0,8));Button imp=UiKit.secondaryButton(this,"⬇ بازیابی Backup");imp.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");startActivityForResult(i,REQ_IMPORT);});tools.addView(imp,UiKit.matchWrap(this,0,8));tools.addView(UiKit.muted(this,"برای امنیت، رمزهای Nexa Vault در Backup عمومی منتقل نمی‌شوند؛ کلید Vault فقط داخل Android Keystore همین دستگاه است."),UiKit.matchWrap(this,0,8));Button test=UiKit.secondaryButton(this,"🧪 Nexa Test Center");test.setOnClickListener(v->startActivity(new Intent(this,TestCenterActivity.class)));tools.addView(test);addCollapsibleSettingsSection(root,tools,"🛡 امنیت و پشتیبان‌گیری");
        LinearLayout sounds=UiKit.colorfulCardLayout(this,5);
        sounds.addView(UiKit.sectionTitle(this,"🎵 صدای هشدارهای Nexa"));

        int[] profiles={NexaAudioController.SOUND_ALARM,NexaAudioController.SOUND_REMINDER,
                NexaAudioController.SOUND_BATTERY,NexaAudioController.SOUND_THEFT,
                NexaAudioController.SOUND_SILENT_EXIT};
        String[] labels={"دارو و هشدار عمومی","یادآورها و قرارها","باتری و شارژ","امنیت و ضدسرقت","پایان حالت سکوت"};
        soundButtons.clear();
        java.util.ArrayList<Runnable> refreshAudioControls=new java.util.ArrayList<>();
        for(int j=0;j<profiles.length;j++){
            final int profile=profiles[j];
            final String profileLabel=labels[j];
            Button profileToggle=UiKit.secondaryButton(this,profileLabel+"  ▾");
            sounds.addView(profileToggle,UiKit.matchWrap(this,0,5));
            LinearLayout profilePanel=new LinearLayout(this);
            profilePanel.setOrientation(LinearLayout.VERTICAL);
            profilePanel.setVisibility(View.GONE);
            profilePanel.setPadding(UiKit.dp(this,8),UiKit.dp(this,5),UiKit.dp(this,8),UiKit.dp(this,8));
            profileToggle.setOnClickListener(v->{boolean expanded=profilePanel.getVisibility()!=View.VISIBLE;
                profilePanel.setVisibility(expanded?View.VISIBLE:View.GONE);
                profileToggle.setText(profileLabel+(expanded?"  ▴":"  ▾"));});
            Button choose=UiKit.secondaryButton(this,"🎵 "+labels[j]);
            soundButtons.put(profile,choose);
            refreshSoundButton(profile);
            choose.setOnClickListener(v->showSoundChoices(profile));
            profilePanel.addView(choose,UiKit.matchWrap(this,0,7));
            Button quickPreview=UiKit.secondaryButton(this,"▶ پخش آزمایشی «"+labels[j]+"» — ۵ ثانیه");
            quickPreview.setOnClickListener(v->previewSound(profile));
            profilePanel.addView(quickPreview,UiKit.matchWrap(this,0,4));
            final int min=AlarmSoundSelection.minVolumePercent(profile);
            TextView volumeTitle=UiKit.muted(this,"");
            profilePanel.addView(volumeTitle,UiKit.matchWrap(this,7,3));
            SeekBar volume=new SeekBar(this);
            volume.setMax(100);
            volume.setProgress(AlarmSoundSelection.volumePercent(this,profile));
            volume.setContentDescription("شدت صدای "+labels[j]);
            profilePanel.addView(volume,UiKit.matchWrap(this,0,4));
            volume.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
                @Override public void onProgressChanged(SeekBar bar,int progress,boolean fromUser){
                    if(!fromUser)return;
                    int corrected=AlarmSoundSelection.normalizedVolumePercent(profile,progress);
                    if(corrected!=progress)bar.setProgress(corrected);
                    AlarmSoundSelection.setVolumePercent(SettingsActivity.this,profile,corrected);
                    volumeTitle.setText("🔊 شدت صدای نسبی: "+corrected+"٪"+
                        (min>0?" (حداقل ایمن "+min+"٪)":""));
                }
                @Override public void onStartTrackingTouch(SeekBar bar){stopPreview();}
                @Override public void onStopTrackingTouch(SeekBar bar){}
            });
            volumeTitle.setText("🔊 شدت صدای نسبی: "+volume.getProgress()+"٪"+
                (min>0?" (حداقل ایمن "+min+"٪)":""));
            if(profile==NexaAudioController.SOUND_THEFT){
                profilePanel.addView(UiKit.muted(this,"🔒 ویبره ضدسرقت همیشه روشن است و شدت صدا کمتر از ۸۰٪ نمی‌شود."),UiKit.matchWrap(this,0,4));
                refreshAudioControls.add(()->{
                    volume.setProgress(AlarmSoundSelection.volumePercent(this,profile));
                    volumeTitle.setText("🔊 شدت صدای نسبی: "+volume.getProgress()+"٪ (حداقل ایمن ۸۰٪)");
                });
            }else if(profile==NexaAudioController.SOUND_SILENT_EXIT){
                refreshAudioControls.add(()->{
                    volume.setProgress(AlarmSoundSelection.volumePercent(this,profile));
                    volumeTitle.setText("🔊 شدت صدای نسبی: "+volume.getProgress()+"٪");
                });
            }else{
                Switch vibrate=UiKit.styledSwitch(this);
                vibrate.setText("ویبره این دسته هشدار");
                vibrate.setChecked(AlarmSoundSelection.vibrationEnabled(this,profile));
                vibrate.setOnCheckedChangeListener((button,enabled)->
                    AlarmSoundSelection.setVibrationEnabled(this,profile,enabled));
                profilePanel.addView(vibrate,UiKit.matchWrap(this,0,7));
                refreshAudioControls.add(()->{
                    volume.setProgress(AlarmSoundSelection.volumePercent(this,profile));
                    volumeTitle.setText("🔊 شدت صدای نسبی: "+volume.getProgress()+"٪"+
                        " (حداقل ایمن "+min+"٪)");
                    vibrate.setChecked(AlarmSoundSelection.vibrationEnabled(this,profile));
                });
            }
            sounds.addView(profilePanel,UiKit.matchWrap(this,0,2));
        }

        Button resetSounds=UiKit.secondaryButton(this,"↺ بازنشانی صدا، شدت و ویبره همه هشدارها");
        resetSounds.setOnClickListener(v->new android.app.AlertDialog.Builder(this)
            .setTitle("بازنشانی صدای هشدارها")
            .setMessage("صدای انتخابی، شدت صدا و ویبره پنج دسته Nexa به حالت پیش‌فرض برمی‌گردند. تنظیمات اعلان‌های اندروید تغییر نمی‌کنند.")
            .setNegativeButton("انصراف",null)
            .setPositiveButton("بازنشانی",(dialog,which)->{
                stopPreview();
                AlarmSoundSelection.resetAll(this);
                for(int profile:profiles)refreshSoundButton(profile);
                for(Runnable refresh:refreshAudioControls)refresh.run();
                Toast.makeText(this,"صدا، شدت و ویبره هشدارها بازنشانی شد",Toast.LENGTH_SHORT).show();
            }).show());
        sounds.addView(resetSounds,UiKit.matchWrap(this,8,7));

        Button systemChannels=UiKit.secondaryButton(this,"⚙ تنظیم صدای اعلان‌های اندروید");
        systemChannels.setOnClickListener(v->{
            try{startActivity(AlarmSoundSelection.notificationSettingsIntent(this));}
            catch(Exception e){Toast.makeText(this,"تنظیمات اعلان‌های گوشی در دسترس نیست",Toast.LENGTH_LONG).show();}
        });
        sounds.addView(systemChannels,UiKit.matchWrap(this,0,7));
        addCollapsibleSettingsSection(root,sounds,"🎵 انتخاب صدای هشدارها");
        LinearLayout alarmPrefs=UiKit.colorfulCardLayout(this,5);alarmPrefs.addView(UiKit.sectionTitle(this,"⏰ رفتار زنگ هشدار"));alarmPrefs.addView(UiKit.muted(this,"پیش‌فرض Nexa این است که زنگ و ویبره تا تأیید خودت ادامه داشته باشد. اگر خواستی می‌توانی مدت زنگ را محدود کنی؛ تکرار ۵ دقیقه‌ای تا تأیید همچنان برقرار می‌ماند."),UiKit.matchWrap(this,6,10));
        Spinner ringDuration=UiKit.styledSpinner(this);String[] ringLabels={"تا تأیید من زنگ بزند","۳۰ ثانیه","۱ دقیقه","۲ دقیقه","۵ دقیقه"};long[] ringValues={0L,30_000L,60_000L,120_000L,300_000L};ArrayAdapter<String> ringAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,ringLabels){@Override public View getView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getView(p,v,par);t.setTextColor(UiKit.TEXT);return t;}@Override public View getDropDownView(int p,View v,android.view.ViewGroup par){TextView t=(TextView)super.getDropDownView(p,v,par);t.setTextColor(UiKit.TEXT);t.setBackgroundColor(UiKit.CARD_2);return t;}};ringDuration.setAdapter(ringAdapter);long currentRing=AppPrefs.getAlarmRingDurationMs(this);for(int i=0;i<ringValues.length;i++)if(ringValues[i]==currentRing)ringDuration.setSelection(i);ringDuration.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){AppPrefs.setAlarmRingDurationMs(SettingsActivity.this,ringValues[pos]);}public void onNothingSelected(android.widget.AdapterView<?> p){}});alarmPrefs.addView(ringDuration);addCollapsibleSettingsSection(root,alarmPrefs,"⏰ رفتار زنگ هشدار");
        LinearLayout dataTools=UiKit.colorfulCardLayout(this,4);dataTools.addView(UiKit.sectionTitle(this,"دفتر مشترک و فایل‌های Nexa"));Button entityManager=UiKit.secondaryButton(this,"🏪 فروشندگان، بانک‌ها و کارت‌ها");entityManager.setOnClickListener(v->startActivity(new Intent(this,SharedEntitiesActivity.class)));dataTools.addView(entityManager,UiKit.matchWrap(this,10,8));Button mediaManager=UiKit.secondaryButton(this,"🖼 مدیریت مرکزی فایل‌ها و فاکتورها");mediaManager.setOnClickListener(v->startActivity(new Intent(this,FileCenterActivity.class)));dataTools.addView(mediaManager);addCollapsibleSettingsSection(root,dataTools,"🗂 دفتر مشترک و فایل‌های Nexa");
        LinearLayout monitor=UiKit.cardLayout(this);LinearLayout mr=new LinearLayout(this);mr.setGravity(Gravity.CENTER_VERTICAL);TextView mt=UiKit.sectionTitle(this,"تشخیص خودکار Silent / Vibrate");mr.addView(mt,new LinearLayout.LayoutParams(0,-2,1f));Switch sw=UiKit.styledSwitch(this);sw.setChecked(AppPrefs.isMonitoringEnabled(this));sw.setText(sw.isChecked()?"روشن":"خاموش");mr.addView(sw);monitor.addView(mr);monitor.addView(UiKit.muted(this,"پس از روشن‌شدن گوشی، Nexa دوباره آماده می‌شود."),UiKit.matchWrap(this,8,0));sw.setOnCheckedChangeListener((b,v)->{AppPrefs.setMonitoringEnabled(this,v);sw.setText(v?"روشن":"خاموش");});addCollapsibleSettingsSection(root,monitor,"🔕 تشخیص خودکار Silent / Vibrate");
        LinearLayout compat=UiKit.colorfulCardLayout(this,6);compat.addView(UiKit.sectionTitle(this,"📱 سازگاری این دستگاه"));
        String device=android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL+" • Android "+android.os.Build.VERSION.RELEASE+" (API "+android.os.Build.VERSION.SDK_INT+")";
        String maker=Build.MANUFACTURER==null?"":Build.MANUFACTURER.toLowerCase(java.util.Locale.US);String brandHint="";
        if(maker.contains("xiaomi")||maker.contains("redmi"))brandHint="\nنکته Xiaomi/Redmi: برای هشدارهای مطمئن، Autostart و Battery saver برنامه را هم بررسی کن.";
        else if(maker.contains("samsung"))brandHint="\nنکته Samsung: اگر هشدارها دیر می‌رسند، Nexa را از Sleeping/Deep sleeping apps خارج کن.";
        else if(maker.contains("huawei")||maker.contains("honor"))brandHint="\nنکته Huawei/Honor: اجرای پس‌زمینه Nexa را در App launch روی حالت دستی و مجاز بررسی کن.";
        else if(maker.contains("oneplus")||maker.contains("oppo")||maker.contains("realme"))brandHint="\nنکته دستگاه: Battery optimization و Auto launch را برای Nexa بررسی کن.";
        compat.addView(UiKit.muted(this,device+"\nNexa از Android 8 به بالا پشتیبانی می‌کند. وضعیت مجوزهای هشدار و اجرای پس‌زمینه از بخش «وضعیت دسترسی‌ها» قابل بررسی است."+brandHint),UiKit.matchWrap(this,6,10));
        LinearLayout compatActions=new LinearLayout(this);Button appSettings=UiKit.secondaryButton(this,"تنظیمات برنامه");Button notifSettings=UiKit.secondaryButton(this,"تنظیمات اعلان‌ها");
        appSettings.setOnClickListener(v->{try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}});
        notifSettings.setOnClickListener(v->{try{Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);i.putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName());startActivity(i);}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName())));}catch(Exception ignored){}}});
        compatActions.addView(appSettings,new LinearLayout.LayoutParams(0,-2,1f));compatActions.addView(notifSettings,new LinearLayout.LayoutParams(0,-2,1f));compat.addView(compatActions);addCollapsibleSettingsSection(root,compat,"📱 سازگاری این دستگاه");
        LinearLayout about=UiKit.cardLayout(this);about.setBackground(UiKit.accentCard(this));about.addView(UiKit.sectionTitle(this,"درباره Nexa"));TextView info=UiKit.muted(this,"NEXA "+VersionUtil.name(this)+"\nObsidian Personal Assistant\n\nسازنده: Darvish\nشماره تماس سازنده: 09354485733\nایمیل: "+(NexaStore.emailSupabaseUrl(this).trim().isEmpty()?"پیکربندی نشده":(NexaStore.emailVerified(this)?"تأیید شده":"پیکربندی شده")));info.setTextSize(14);about.addView(info,UiKit.matchWrap(this,8,0));addCollapsibleSettingsSection(root,about,"ℹ درباره Nexa");filterSettings("");setContentView(sc);refreshStatuses();}
    private void showSoundChoices(int profile){
        pendingSoundProfile=profile;
        new android.app.AlertDialog.Builder(this).setTitle("انتخاب صدای هشدار")
            .setItems(new String[]{"صدای پیش‌فرض Nexa","زنگ‌ها و اعلان‌های گوشی",
                "فایل صوتی حافظه داخلی یا خارجی","شنیدن صدای فعلی (۵ ثانیه)"},(d,which)->{
                if(which==0){
                    stopPreview();
                    AlarmSoundSelection.save(this,profile,null);
                    refreshSoundButton(profile);
                    Toast.makeText(this,"صدای پیش‌فرض انتخاب شد",Toast.LENGTH_SHORT).show();
                }else if(which==1){
                    Intent i=new Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER);
                    i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE,
                        android.media.RingtoneManager.TYPE_ALARM|
                        android.media.RingtoneManager.TYPE_RINGTONE|
                        android.media.RingtoneManager.TYPE_NOTIFICATION);
                    i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT,false);
                    i.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI,
                        AlarmSoundSelection.resolve(this,profile));
                    try{startActivityForResult(i,REQ_SOUND_SYSTEM);}
                    catch(Exception e){Toast.makeText(this,"انتخابگر زنگ در این گوشی موجود نیست",Toast.LENGTH_LONG).show();}
                }else if(which==2){
                    try{startActivityForResult(AlarmSoundSelection.audioDocumentIntent(),REQ_SOUND_DOCUMENT);}
                    catch(Exception e){Toast.makeText(this,"انتخاب فایل صوتی ممکن نیست",Toast.LENGTH_LONG).show();}
                }else{
                    previewSound(profile);
                }
            }).setNegativeButton("بستن",null).show();
    }

    private void showBankManager(){LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"کارت‌های بانکی"),UiKit.matchWrap(this,0,8));java.util.List<NexaStore.BankCard> cards=NexaStore.bankCards(this);if(cards.isEmpty())box.addView(UiKit.muted(this,"هنوز کارتی ثبت نشده."),UiKit.matchWrap(this,0,8));for(NexaStore.BankCard c:cards){LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.addView(UiKit.muted(this,c.display()),new LinearLayout.LayoutParams(0,-2,1f));Button e=UiKit.editIconButton(this);e.setOnClickListener(v->bankEditDialog(c));row.addView(e,new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42)));Button d=UiKit.deleteIconButton(this);d.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("حذف کارت؟").setMessage(c.display()).setPositiveButton("حذف",(x,w)->{NexaStore.removeBankCard(this,c.id);showBankManager();}).setNegativeButton("انصراف",null).show());LinearLayout.LayoutParams dl=new LinearLayout.LayoutParams(UiKit.dp(this,42),UiKit.dp(this,42));dl.setMargins(UiKit.dp(this,4),0,0,0);row.addView(d,dl);box.addView(row,UiKit.matchWrap(this,0,5));}Button add=UiKit.addIconButton(this);add.setOnClickListener(v->bankEditDialog(null));box.addView(add,UiKit.matchWrap(this,8,0));new android.app.AlertDialog.Builder(this).setTitle("مدیریت بانک‌ها").setView(box).setNegativeButton("بستن",null).show();}
    private void bankEditDialog(NexaStore.BankCard existing){LinearLayout box=UiKit.dialogPanel(this);EditText bank=field("نام بانک");EditText label=field("عنوان؛ مثلاً کارت روزمره");EditText last4=field("۴ رقم آخر کارت (اختیاری)");last4.setInputType(InputType.TYPE_CLASS_NUMBER);if(existing!=null){bank.setText(existing.bank);label.setText(existing.label);last4.setText(existing.last4);}box.addView(bank);box.addView(label);box.addView(last4);new android.app.AlertDialog.Builder(this).setTitle(existing==null?"کارت جدید":"ویرایش کارت").setView(box).setPositiveButton("ذخیره",(d,w)->{if(bank.getText().toString().trim().isEmpty())return;NexaStore.BankCard c=existing==null?new NexaStore.BankCard():existing;c.bank=bank.getText().toString().trim();c.label=label.getText().toString().trim();String l=last4.getText().toString().trim();c.last4=l.length()>4?l.substring(l.length()-4):l;NexaStore.upsertBankCard(this,c);Toast.makeText(this,"کارت ذخیره شد.",Toast.LENGTH_SHORT).show();}).setNegativeButton("انصراف",null).show();}
    private String mediaModuleLabel(String module){if("shopping".equals(module))return "فاکتورهای خرید";if("docs".equals(module))return "مدارک";if("garage".equals(module))return "گاراژ";if("home".equals(module))return "خانه";if("case".equals(module))return "پرونده‌ها";if("assets".equals(module))return "دارایی‌ها";return module;}
    private void showMediaManager(){int count=AttachmentStore.count(this);long bytes=AttachmentStore.totalBytes(this);LinearLayout box=UiKit.dialogPanel(this);box.addView(UiKit.sectionTitle(this,"تصاویر ذخیره‌شده در Nexa"));box.addView(UiKit.muted(this,count+" تصویر • "+AttachmentStore.humanSize(bytes)),UiKit.matchWrap(this,6,10));String[] modules={"shopping","docs","garage","home","case","assets","general"};boolean any=false;for(String module:modules){int mc=AttachmentStore.countExistingModule(this,module);if(mc<=0)continue;any=true;Button b=UiKit.secondaryButton(this,"🗂 "+mediaModuleLabel(module)+" • "+mc+" تصویر • "+AttachmentStore.humanSize(AttachmentStore.bytesExistingModule(this,module)));b.setOnClickListener(v->confirmDeleteMedia(module));box.addView(b,UiKit.matchWrap(this,0,7));}if(!any)box.addView(UiKit.muted(this,"هنوز تصویر ذخیره‌شده‌ای وجود ندارد."),UiKit.matchWrap(this,0,8));Button all=UiKit.secondaryButton(this,"🗑 حذف همه تصاویر Nexa");all.setOnClickListener(v->confirmDeleteMedia("all"));box.addView(all,UiKit.matchWrap(this,5,0));new android.app.AlertDialog.Builder(this).setView(box).setNegativeButton("بستن",null).show();}
    private void confirmDeleteMedia(String scope){boolean all="all".equals(scope);String label=all?"همه تصاویر Nexa":mediaModuleLabel(scope);int count=all?AttachmentStore.count(this):AttachmentStore.countExistingModule(this,scope);String title=label+" پاک شود؟";new android.app.AlertDialog.Builder(this).setTitle(title).setMessage(count+" تصویر انتخاب شده است. این کار برگشت‌پذیر نیست؛ عکس اصلی گالری گوشی حذف نمی‌شود.").setPositiveButton("ادامه",(d,w)->new android.app.AlertDialog.Builder(this).setTitle("تأیید نهایی").setMessage("حذف "+label+" قطعی است. مطمئنی؟").setPositiveButton("مطمئنم، پاک کن",(d2,w2)->{if(all){AttachmentStore.deleteAll(this);NexaStore.clearShoppingReceipts(this);}else{if("shopping".equals(scope)){for(NexaStore.ShoppingReceipt r:NexaStore.shoppingReceipts(this))AttachmentStore.deletePath(r.localPath);NexaStore.clearShoppingReceipts(this);}AttachmentStore.deleteExistingModule(this,scope);}Toast.makeText(this,"تصاویر انتخاب‌شده از Nexa پاک شدند.",Toast.LENGTH_LONG).show();}).setNegativeButton("انصراف",null).show()).setNegativeButton("انصراف",null).show();}
    private String pendingVaultPassword="";
    private void askVaultPassword(boolean export){EditText p=field(export?"گذرواژه Backup (حداقل ۸ کاراکتر)":"گذرواژه فایل Vault");p.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);new android.app.AlertDialog.Builder(this).setTitle(export?"Backup رمزگذاری‌شده Vault":"بازیابی Vault").setMessage(export?"این گذرواژه را فراموش نکن؛ بدون آن فایل قابل بازیابی نیست.":"Restore، محتوای فعلی Vault را جایگزین می‌کند.").setView(p).setPositiveButton("ادامه",(d,w)->{String pass=p.getText().toString();if(pass.length()<8){Toast.makeText(this,"گذرواژه باید حداقل ۸ کاراکتر باشد.",Toast.LENGTH_LONG).show();return;}pendingVaultPassword=pass;if(export){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"Nexa_Vault_"+VersionUtil.name(this)+".nexavault");startActivityForResult(i,REQ_VAULT_EXPORT);}else{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("*/*");startActivityForResult(i,REQ_VAULT_IMPORT);}}).setNegativeButton("انصراف",null).show();}
    private EditText field(String h){return UiKit.styleField(this,new EditText(this),h);}
    private TextView status(String x){TextView t=UiKit.muted(this,x);t.setTextSize(14);return t;}
    private String pfx(boolean x){return x?"✓  ":"○  ";}
    private boolean runtimeReady(){return checkSelfPermission(Manifest.permission.READ_PHONE_STATE)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.READ_CONTACTS)==PackageManager.PERMISSION_GRANTED&&checkSelfPermission(Manifest.permission.RECEIVE_SMS)==PackageManager.PERMISSION_GRANTED&&(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED);}
    private boolean screening(){if(Build.VERSION.SDK_INT<29)return true;RoleManager rm=getSystemService(RoleManager.class);return rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)&&rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING);}
    private void refreshStatuses(){if(overlayStatus==null)return;NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);boolean o=Settings.canDrawOverlays(this),d=nm.isNotificationPolicyAccessGranted(),r=runtimeReady(),s=screening(),exact=Build.VERSION.SDK_INT<31||am.canScheduleExactAlarms(),full=Build.VERSION.SDK_INT<34||nm.canUseFullScreenIntent(),bat=pm.isIgnoringBatteryOptimizations(getPackageName());overlayStatus.setText(pfx(o)+"نمایش روی برنامه‌ها");dndStatus.setText(pfx(d)+"کنترل Silent / Vibrate");phoneStatus.setText(pfx(r)+"تماس، مخاطبین، پیامک و اعلان‌ها");screeningStatus.setText(pfx(s)+"Call Screening تماس‌های مجاز");exactAlarmStatus.setText(pfx(exact)+"آلارم دقیق");fullScreenStatus.setText(pfx(full)+"نمایش تمام‌صفحه هشدار روی Lock Screen");batteryStatus.setText(pfx(bat)+"فعالیت پس‌زمینه بدون محدودیت");setupButton.setText(o&&d&&r&&s&&exact&&full&&bat?"همه دسترسی‌ها آماده‌اند ✓":"شروع راه‌اندازی کامل");}
    private boolean stepGranted(int s){if(s==1)return Settings.canDrawOverlays(this);if(s==2)return ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).isNotificationPolicyAccessGranted();if(s==3)return Build.VERSION.SDK_INT<31||((AlarmManager)getSystemService(Context.ALARM_SERVICE)).canScheduleExactAlarms();if(s==4)return Build.VERSION.SDK_INT<34||((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).canUseFullScreenIntent();if(s==5)return ((PowerManager)getSystemService(Context.POWER_SERVICE)).isIgnoringBatteryOptimizations(getPackageName());return true;}
    private void continueSetup(){refreshStatuses();if(!Settings.canDrawOverlays(this)){waitingSpecialStep=1;startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));return;}NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);if(!nm.isNotificationPolicyAccessGranted()){waitingSpecialStep=2;startActivity(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));return;}ArrayList<String> rt=new ArrayList<>();if(checkSelfPermission(Manifest.permission.READ_PHONE_STATE)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.READ_PHONE_STATE);if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.READ_CONTACTS);if(checkSelfPermission(Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.RECEIVE_SMS);if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)rt.add(Manifest.permission.POST_NOTIFICATIONS);if(!rt.isEmpty()){requestPermissions(rt.toArray(new String[0]),REQ_RUNTIME);return;}if(Build.VERSION.SDK_INT>=29&&!screening()){RoleManager rm=getSystemService(RoleManager.class);startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING),REQ_CALL_SCREENING);return;}AlarmManager am=(AlarmManager)getSystemService(Context.ALARM_SERVICE);if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){waitingSpecialStep=3;try{startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));}catch(Exception e){setupInProgress=false;}return;}if(Build.VERSION.SDK_INT>=34&&!nm.canUseFullScreenIntent()){waitingSpecialStep=4;try{startActivity(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,Uri.parse("package:"+getPackageName())));}catch(Exception e){setupInProgress=false;}return;}PowerManager pm=(PowerManager)getSystemService(Context.POWER_SERVICE);if(!pm.isIgnoringBatteryOptimizations(getPackageName())){waitingSpecialStep=5;try{startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,Uri.parse("package:"+getPackageName())));}catch(Exception e){startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}return;}setupInProgress=false;AppPrefs.setSetupCompleted(this,true);ReminderScheduler.rescheduleAll(this);Intent mon=new Intent(this,SilentTimerService.class);mon.setAction(SilentTimerService.ACTION_MONITOR);try{if(Build.VERSION.SDK_INT>=26)startForegroundService(mon);else startService(mon);}catch(Exception ignored){}refreshStatuses();Toast.makeText(this,"راه‌اندازی Nexa کامل شد.",Toast.LENGTH_LONG).show();if(autoFirstRunSetup)handler.postDelayed(this::finish,700);}
    @Override public void onRequestPermissionsResult(int r,String[]p,int[]g){super.onRequestPermissionsResult(r,p,g);if(r!=REQ_RUNTIME)return;for(int x:g)if(x!=PackageManager.PERMISSION_GRANTED){setupInProgress=false;Toast.makeText(this,"برای ادامه، دسترسی‌های این مرحله باید تأیید شوند.",Toast.LENGTH_LONG).show();return;}handler.postDelayed(this::continueSetup,250);}
    @Override protected void onActivityResult(int r,int result,Intent data){super.onActivityResult(r,result,data);
        if(r==REQ_SOUND_DOCUMENT || r==REQ_SOUND_SYSTEM){
            if(result==RESULT_OK && data!=null){
                Uri uri=r==REQ_SOUND_DOCUMENT?data.getData():
                    (Uri)data.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
                if(uri!=null){
                    if(r==REQ_SOUND_DOCUMENT){
                        try{getContentResolver().takePersistableUriPermission(uri,
                            Intent.FLAG_GRANT_READ_URI_PERMISSION);}
                        catch(SecurityException ignored){}
                    }
                    if(!AlarmSoundSelection.isSupportedUri(uri)){
                        Toast.makeText(this,"آدرس فایل صوتی معتبر نیست",Toast.LENGTH_LONG).show();
                    }else if(!AlarmSoundSelection.isReadable(this,uri)){
                        Toast.makeText(this,"فایل صوتی قابل خواندن نیست؛ انتخاب قبلی حفظ شد",Toast.LENGTH_LONG).show();
                    }else{
                        stopPreview();
                        AlarmSoundSelection.save(this,pendingSoundProfile,uri);
                        refreshSoundButton(pendingSoundProfile);
                        Toast.makeText(this,"صدای انتخاب‌شده ذخیره شد",Toast.LENGTH_SHORT).show();
                    }
                }
            }
            return;
        }
if(r==REQ_UNLOCK){awaitingSettingsUnlock=false;if(result==RESULT_OK&&SecurityGate.isUnlocked()){
            if(!verifiedSettings){verifiedSettings=true;openSettings();}}else finish();return;}
        if(r==REQ_SMS_CONTACT){if(result==RESULT_OK&&data!=null&&data.getData()!=null){
            try(android.database.Cursor cr=getContentResolver().query(data.getData(),new String[]{
                android.provider.ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                android.provider.ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,null)){
                if(cr!=null&&cr.moveToFirst()&&smsNumber!=null){
                    String entry=cr.getString(0)+"|"+cr.getString(1);
                    smsNumber.setText(smsNumber.getText().toString()+
                        (smsNumber.length()>0?";":"")+entry);
                }
            }catch(Exception ignored){}
        }return;}if(r==REQ_CALL_SCREENING){if(!screening()){setupInProgress=false;Toast.makeText(this,"Call Screening فعال نشد.",Toast.LENGTH_LONG).show();}else handler.postDelayed(this::continueSetup,250);return;}if(result!=RESULT_OK||data==null||data.getData()==null)return;if(r==REQ_VAULT_EXPORT||r==REQ_VAULT_IMPORT){try{if(r==REQ_VAULT_EXPORT){String raw=VaultBackupUtil.exportVault(this,pendingVaultPassword);OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(raw.getBytes(java.nio.charset.StandardCharsets.UTF_8));out.close();Toast.makeText(this,"Backup رمزگذاری‌شده Vault ساخته شد.",Toast.LENGTH_LONG).show();}else{BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData())));StringBuilder q=new StringBuilder();String ln;while((ln=br.readLine())!=null)q.append(ln);br.close();boolean ok=VaultBackupUtil.importVault(this,q.toString(),pendingVaultPassword);Toast.makeText(this,ok?"Vault با موفقیت بازیابی شد.":"گذرواژه یا فایل Vault معتبر نیست.",Toast.LENGTH_LONG).show();}}catch(Exception e){Toast.makeText(this,"عملیات Vault انجام نشد.",Toast.LENGTH_LONG).show();}finally{pendingVaultPassword="";}return;}try{if(r==REQ_EXPORT){OutputStream out=getContentResolver().openOutputStream(data.getData());out.write(NexaStore.exportJson(this).getBytes(java.nio.charset.StandardCharsets.UTF_8));out.close();Toast.makeText(this,"Backup ساخته شد.",Toast.LENGTH_SHORT).show();}else if(r==REQ_IMPORT){BufferedReader br=new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(data.getData())));StringBuilder s=new StringBuilder();String line;while((line=br.readLine())!=null)s.append(line);br.close();if(NexaStore.importJson(this,s.toString())){ReminderScheduler.rescheduleAll(this);EmergencyCardManager.refresh(this);Toast.makeText(this,"Backup بازیابی شد.",Toast.LENGTH_LONG).show();recreate();}else Toast.makeText(this,"فایل معتبر نیست.",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"خطا در فایل Backup.",Toast.LENGTH_SHORT).show();}}
}
