package com.example.silenttimer;

/**
 * Mode to restore after a manual ringer transition (e.g. NORMAL -> SILENT).
 * Unlike an app-started timer, the system has *already* changed ringer mode
 * when the manual timer prompt is shown. This policy is pure Java for tests.
 */
public final class ManualTimerRestorePolicy {
    private ManualTimerRestorePolicy() {}

    public static int originalMode(int observedBefore, int requestedMode) {
        // AudioManager.RINGER_MODE_* constants are 0 SILENT, 1 VIBRATE, 2 NORMAL.
        // When the prior state is missing or identical to the newly selected
        // mute state, prefer an audible NORMAL exit over trapping the phone mute.
        if (observedBefore < 0 || observedBefore > 2 || observedBefore == requestedMode)
            return 2;
        return observedBefore;
    }
}
