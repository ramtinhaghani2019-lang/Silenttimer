package com.example.silenttimer;

import android.app.*;
import android.content.*;
import android.os.BatteryManager;
import androidx.core.app.NotificationCompat;

/** Battery threshold engine. One notification per threshold crossing; automatically rearms. */
public final class BatteryAlertManager {
    public static final int CHARGE_ID=7420, LOW_ID=7421;
    private BatteryAlertManager(){}
    public static void onBatteryChanged(Context c, Intent i){
        if(c==null||i==null)return;
        int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1), scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);
        if(level<0)return; int pct=Math.round(level*100f/Math.max(1,scale));
        int plugged=i.getIntExtra(BatteryManager.EXTRA_PLUGGED,0);
        boolean charging=plugged!=0;
        int high=AppPrefs.getChargeAlarmThreshold(c), low=AppPrefs.getLowBatteryThreshold(c);
        if(AppPrefs.isChargeAlarmEnabled(c)){
            if(charging && pct>=high && !AppPrefs.isChargeAlarmLatched(c)){notify(c,NotificationChannelHelper.CHANNEL_BATTERY_ALARM,CHARGE_ID,"شارژ به حد تعیین‌شده رسید",pct+"٪ • حد هشدار "+high+"٪");AppPrefs.setChargeAlarmLatched(c,true);}
            else if(pct<Math.max(1,high-3)) AppPrefs.setChargeAlarmLatched(c,false);
        } else AppPrefs.setChargeAlarmLatched(c,false);
        if(AppPrefs.isLowBatteryAlarmEnabled(c)){
            if(!charging && pct<=low && !AppPrefs.isLowBatteryAlarmLatched(c)){notify(c,NotificationChannelHelper.CHANNEL_LOW_BATTERY,LOW_ID,"باتری کم است",pct+"٪ • حد هشدار "+low+"٪");AppPrefs.setLowBatteryAlarmLatched(c,true);}
            else if(charging || pct>=Math.min(100,low+3)) AppPrefs.setLowBatteryAlarmLatched(c,false);
        } else AppPrefs.setLowBatteryAlarmLatched(c,false);
    }
    private static void notify(Context c,String channel,int id,String title,String text){
        NotificationChannelHelper.ensureCoreChannels(c);
        Intent open=new Intent(c,BatteryGuardActivity.class); PendingIntent pi=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new NotificationCompat.Builder(c,channel).setSmallIcon(com.example.silenttimer.R.drawable.app_icon).setContentTitle(title).setContentText(text).setStyle(new NotificationCompat.BigTextStyle().bigText(text)).setPriority(NotificationCompat.PRIORITY_HIGH).setVisibility(NotificationCompat.VISIBILITY_PUBLIC).setAutoCancel(true).setContentIntent(pi).build();
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.notify(id,n);
    }
}
