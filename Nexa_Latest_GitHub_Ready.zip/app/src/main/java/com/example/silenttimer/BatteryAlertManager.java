package com.example.silenttimer;

import android.app.*;
import android.content.*;
import android.os.BatteryManager;

/** Battery threshold engine. One notification per threshold crossing; automatically rearms. */
public final class BatteryAlertManager {
    public static final int CHARGE_ID=7420, LOW_ID=7421;
    private BatteryAlertManager(){}
    static boolean shouldTriggerCharge(boolean enabled, boolean charging, int pct, int threshold, boolean latched){
        return enabled && charging && pct>=threshold && !latched;
    }
    static boolean shouldRearmCharge(int pct,int threshold){ return pct<Math.max(1,threshold-3); }
    static boolean shouldTriggerLow(boolean enabled, boolean charging, int pct, int threshold, boolean latched){
        return enabled && !charging && pct<=threshold && !latched;
    }
    static boolean shouldRearmLow(boolean charging,int pct,int threshold){ return charging || pct>=Math.min(100,threshold+3); }
    public static void onBatteryChanged(Context c, Intent i){
        if(c==null||i==null)return;
        int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1), scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);
        if(level<0)return; int pct=Math.round(level*100f/Math.max(1,scale));
        int plugged=i.getIntExtra(BatteryManager.EXTRA_PLUGGED,0);
        boolean charging=plugged!=0;
        TheftGuardManager.onBatteryChanged(c,i);
        int high=AppPrefs.getChargeAlarmThreshold(c), low=AppPrefs.getLowBatteryThreshold(c);
        if(AppPrefs.isChargeAlarmEnabled(c)){
            if(shouldTriggerCharge(true,charging,pct,high,AppPrefs.isChargeAlarmLatched(c))){notify(c,NotificationChannelHelper.CHANNEL_BATTERY_ALARM,CHARGE_ID,"شارژ به حد تعیین‌شده رسید",pct+"٪ • حد هشدار "+high+"٪");AppPrefs.setChargeAlarmLatched(c,true);}
            else if(shouldRearmCharge(pct,high)) AppPrefs.setChargeAlarmLatched(c,false);
        } else AppPrefs.setChargeAlarmLatched(c,false);
        if(AppPrefs.isLowBatteryAlarmEnabled(c)){
            if(shouldTriggerLow(true,charging,pct,low,AppPrefs.isLowBatteryAlarmLatched(c))){notify(c,NotificationChannelHelper.CHANNEL_LOW_BATTERY,LOW_ID,"باتری کم است",pct+"٪ • حد هشدار "+low+"٪");AppPrefs.setLowBatteryAlarmLatched(c,true);}
            else if(shouldRearmLow(charging,pct,low)) AppPrefs.setLowBatteryAlarmLatched(c,false);
        } else AppPrefs.setLowBatteryAlarmLatched(c,false);
    }
    private static void notify(Context c,String channel,int id,String title,String text){
        NotificationChannelHelper.ensureCoreChannels(c);
        Intent open=new Intent(c,BatteryGuardActivity.class); PendingIntent pi=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=new Notification.Builder(c,channel);
        Notification n=b.setSmallIcon(com.example.silenttimer.R.drawable.app_icon).setContentTitle(title).setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setVisibility(Notification.VISIBILITY_PUBLIC).setAutoCancel(true).setContentIntent(pi).build();
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.notify(id,n);
    }
}
