package com.example.silenttimer;

import android.app.*;
import android.content.*;
import android.os.BatteryManager;

/** Battery threshold engine. One alarm per threshold crossing; automatically rearms. */
public final class BatteryAlertManager {
    public static final int CHARGE_ID=7420, LOW_ID=7421;
    private BatteryAlertManager(){}
    static boolean shouldTriggerCharge(boolean enabled, boolean charging, int pct, int threshold, boolean latched){return enabled&&charging&&pct>=threshold&&!latched;}
    static boolean shouldRearmCharge(int pct,int threshold){return pct<Math.max(1,threshold-3);}
    static boolean shouldTriggerLow(boolean enabled, boolean charging, int pct, int threshold, boolean latched){return enabled&&!charging&&pct<=threshold&&!latched;}
    static boolean shouldRearmLow(boolean charging,int pct,int threshold){return charging||pct>=Math.min(100,threshold+3);}
    /** Stop the threshold alarm as soon as external power is removed.
     * This is deliberately independent of the anti-theft alarm, which may start on unplug.
     * Keep the threshold latch until the level actually drops below its re-arm margin.
     */
    public static void onChargerDisconnected(Context c){
        if(c==null)return;
        NexaAudioController.stopOwner(BatteryAlarmActionReceiver.OWNER_CHARGE);
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)nm.cancel(CHARGE_ID);
    }
    public static void onBatteryChanged(Context c, Intent i){
        if(c==null||i==null)return; int level=i.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=i.getIntExtra(BatteryManager.EXTRA_SCALE,100);if(level<0)return;
        int pct=Math.round(level*100f/Math.max(1,scale));boolean charging=i.getIntExtra(BatteryManager.EXTRA_PLUGGED,0)!=0;TheftGuardManager.onBatteryChanged(c,i);if(!charging)onChargerDisconnected(c);
        int high=AppPrefs.getChargeAlarmThreshold(c),low=AppPrefs.getLowBatteryThreshold(c);
        if(AppPrefs.isChargeAlarmEnabled(c)){
            if(shouldTriggerCharge(true,charging,pct,high,AppPrefs.isChargeAlarmLatched(c))){
                NexaAudioController.startAlarm(c,BatteryAlarmActionReceiver.OWNER_CHARGE,NexaAudioController.PRIORITY_BATTERY,NexaAudioController.SOUND_BATTERY);
                notifyCharge(c,pct,high);AppPrefs.setChargeAlarmLatched(c,true);
            } else if(shouldRearmCharge(pct,high)){AppPrefs.setChargeAlarmLatched(c,false);NexaAudioController.stopOwner(BatteryAlarmActionReceiver.OWNER_CHARGE);}
        }else{AppPrefs.setChargeAlarmLatched(c,false);NexaAudioController.stopOwner(BatteryAlarmActionReceiver.OWNER_CHARGE);}
        if(AppPrefs.isLowBatteryAlarmEnabled(c)){
            if(shouldTriggerLow(true,charging,pct,low,AppPrefs.isLowBatteryAlarmLatched(c))){notifySimple(c,NotificationChannelHelper.CHANNEL_LOW_BATTERY,LOW_ID,"باتری کم است",pct+"٪ • حد هشدار "+low+"٪");AppPrefs.setLowBatteryAlarmLatched(c,true);}
            else if(shouldRearmLow(charging,pct,low))AppPrefs.setLowBatteryAlarmLatched(c,false);
        }else AppPrefs.setLowBatteryAlarmLatched(c,false);
    }
    private static void notifyCharge(Context c,int pct,int threshold){
        NotificationChannelHelper.ensureCoreChannels(c);
        Intent open=new Intent(c,BatteryGuardActivity.class);PendingIntent content=PendingIntent.getActivity(c,CHARGE_ID,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Intent stop=new Intent(c,BatteryAlarmActionReceiver.class).setAction(BatteryAlarmActionReceiver.ACTION_STOP);PendingIntent stopPi=PendingIntent.getBroadcast(c,CHARGE_ID+1,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String text="شارژ "+pct+"٪ شد • حد انتخابی "+threshold+"٪ • شارژر را جدا کنید";
        Notification n=new Notification.Builder(c,NotificationChannelHelper.CHANNEL_BATTERY_ALARM).setSmallIcon(R.drawable.app_icon).setContentTitle("⚡ حد شارژ Nexa رسید").setContentText(text).setStyle(new Notification.BigTextStyle().bigText(text)).setVisibility(Notification.VISIBILITY_PUBLIC).setOngoing(true).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_MAX).setContentIntent(content).addAction(new Notification.Action.Builder(null,"قطع هشدار",stopPi).build()).build();
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.notify(CHARGE_ID,n);
    }
    private static void notifySimple(Context c,String channel,int id,String title,String text){NotificationChannelHelper.ensureCoreChannels(c);Intent open=new Intent(c,BatteryGuardActivity.class);PendingIntent pi=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification n=new Notification.Builder(c,channel).setSmallIcon(R.drawable.app_icon).setContentTitle(title).setContentText(text).setVisibility(Notification.VISIBILITY_PUBLIC).setAutoCancel(true).setContentIntent(pi).build();NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm!=null)nm.notify(id,n);}
}
