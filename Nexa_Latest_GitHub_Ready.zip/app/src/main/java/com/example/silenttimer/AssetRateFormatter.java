package com.example.silenttimer;

/** Data-safe formatting for provider-supplied rates; never guesses the source's unit. */
public final class AssetRateFormatter {
    private AssetRateFormatter(){}
    public static String display(double rate){
        return rate>0&&Double.isFinite(rate)?PersianFinancialDisplay.amount(rate):"—";
    }
    public static String freshness(long ageMillis){
        if(ageMillis>86400000L)return "داده قدیمی";
        if(ageMillis>1800000L)return "نیازمند تازه‌سازی";
        return "به‌روز";
    }
}
