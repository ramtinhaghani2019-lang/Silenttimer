package com.example.silenttimer;

import java.util.Calendar;
import java.util.Locale;

/** Presentation-only helpers. Filtering never changes historical ledger balances. */
public final class LedgerCompactUi {
    private LedgerCompactUi() {}

    public static String sortLabel(boolean newestFirst) {
        return newestFirst ? "↓ جدیدترین" : "↑ قدیمی‌ترین";
    }

    public static boolean hasActiveFilters(String kind, int days, String query) {
        return (kind != null && !LedgerHistoryFilter.ALL.equals(kind))
                || days > 0 || (query != null && !query.trim().isEmpty());
    }

    /** Visible even while the options are folded away, to avoid hidden active filters. */
    public static String activeSummary(String kind, int days, String query) {
        StringBuilder b = new StringBuilder();
        if (kind != null && !LedgerHistoryFilter.ALL.equals(kind)) {
            b.append(LedgerPresentation.shortLabel(kind));
        }
        if (days > 0) {
            if (b.length() > 0) b.append(" • ");
            b.append(days).append(" روز اخیر");
        }
        if (query != null && !query.trim().isEmpty()) {
            if (b.length() > 0) b.append(" • ");
            b.append("جستجو: ").append(query.trim());
        }
        return b.length() == 0 ? "" : "فیلتر فعال: " + b;
    }

    public static String timeOnly(long millis) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(millis);
        return String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
    }

    public static String dayHeading(long millis) {
        String pretty = PersianDateUtil.pretty(millis);
        int separator = pretty.indexOf(" • ");
        return separator < 0 ? pretty : pretty.substring(0, separator);
    }
}
