package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.os.Build;

/**
 * Central notification posting/building entry point for Nexa.
 *
 * Build 53 starts migration with Medicine notifications while preserving
 * the existing alarm actions, full-screen behavior and notification id.
 */
public final class NexaNotificationEngine {
    private NexaNotificationEngine() {}

    public static void post(Context context, int id, Notification notification) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(id, notification);
        }
    }

    public static void showMedicineNotification(
            Context context,
            NexaStore.Medicine medicine,
            PendingIntent ringIntent,
            PendingIntent takenOnTimeIntent,
            PendingIntent takenNowIntent,
            PendingIntent snoozeIntent) {

        NotificationChannelHelper.ensureMedicine(context);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, MedicineAlarmReceiver.CHANNEL)
                : new Notification.Builder(context);

        Notification notification = builder
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("💊 زمان مصرف " + medicine.name)
                .setContentText((medicine.dose.isEmpty() ? "نوبت دارو رسیده" : medicine.dose)
                        + " • " + PersianDateUtil.pretty(medicine.nextDoseMillis))
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(false)
                .setContentIntent(ringIntent)
                .setFullScreenIntent(ringIntent, true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.checkbox_on_background,
                        "سر وقت خوردم",
                        takenOnTimeIntent).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_recent_history,
                        "الان خوردم",
                        takenNowIntent).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_popup_reminder,
                        "۵ دقیقه بعد",
                        snoozeIntent).build())
                .build();

        post(context, ("med" + medicine.id).hashCode(), notification);
    }
}
