package com.example.silenttimer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Central notification building/posting entry point for Nexa.
 *
 * Build 54 keeps the existing Medicine behavior, migrates alarm-style Reminder
 * notifications to the same engine and adds a short duplicate-delivery guard.
 */
public final class NexaNotificationEngine {
    private static final String PREFS = "nexa_notification_engine";
    private static final String LAST_PREFIX = "last_delivery:";
    private static final long DUPLICATE_WINDOW_MS = 2_500L;
    public static final String MISSED_CALL_CHANNEL = "nexa_missed_call";
    public static final int MISSED_CALL_NOTIFICATION_ID = 0x4E584D43;

    private NexaNotificationEngine() {}

    /**
     * Claims a logical notification delivery for a short time window.
     * This prevents an accidental double BroadcastReceiver delivery from creating
     * duplicate alarm work, while normal 5+ minute alarm repeats remain unaffected.
     */
    public static boolean acquireDelivery(Context context, String key) {
        if (context == null || key == null || key.trim().isEmpty()) return true;
        Context app = context.getApplicationContext();
        SharedPreferences prefs = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String prefKey = LAST_PREFIX + key;
        long now = System.currentTimeMillis();
        synchronized (NexaNotificationEngine.class) {
            long last = prefs.getLong(prefKey, 0L);
            if (last > 0L && now >= last && now - last < DUPLICATE_WINDOW_MS) {
                return false;
            }
            prefs.edit().putLong(prefKey, now).apply();
            return true;
        }
    }

    public static void post(Context context, int id, Notification notification) {
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(id, notification);
        }
    }

    public static void showMedicineNotification(
            Context context,
            NexaStore.Medicine medicine,
            PendingIntent ringIntent,
            PendingIntent takenOnTimeIntent,
            PendingIntent takenNowIntent,
            PendingIntent snoozeIntent) {

        NotificationChannelHelper.ensureMedicine(context);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, MedicineAlarmReceiver.CHANNEL)
                : new Notification.Builder(context);

        Notification notification = builder
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentTitle("💊 زمان مصرف " + medicine.name)
                .setContentText((medicine.dose.isEmpty() ? "نوبت دارو رسیده" : medicine.dose)
                        + " • " + PersianDateUtil.pretty(medicine.nextDoseMillis))
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(false)
                .setOnlyAlertOnce(false)
                .setContentIntent(ringIntent)
                .setFullScreenIntent(ringIntent, true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.checkbox_on_background,
                        "سر وقت خوردم",
                        takenOnTimeIntent).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_recent_history,
                        "الان خوردم",
                        takenNowIntent).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_popup_reminder,
                        "۵ دقیقه بعد",
                        snoozeIntent).build())
                .build();

        post(context, ("med" + medicine.id).hashCode(), notification);
    }

    public static void showReminderNotification(
            Context context,
            NexaStore.Reminder reminder,
            String token,
            PendingIntent openIntent,
            PendingIntent ringIntent,
            PendingIntent dismissIntent,
            PendingIntent snoozeIntent) {

        ReminderScheduler.createChannels(context);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, ReminderScheduler.CHANNEL)
                : new Notification.Builder(context);

        String icon = reminder.icon == null ? "" : reminder.icon.trim();
        String title = (icon.isEmpty() ? "🔔" : icon) + "  " + reminder.title;
        StringBuilder text = new StringBuilder();
        text.append(reminder.category).append(" • ").append(PersianDateUtil.pretty(reminder.whenMillis));
        if (!reminder.doctorName.isEmpty()) text.append(" • پزشک ").append(reminder.doctorName);
        if (!reminder.doctorFileNumber.isEmpty()) text.append(" • پرونده ").append(reminder.doctorFileNumber);
        if (!reminder.note.isEmpty()) text.append(" • ").append(reminder.note);

        Notification notification = builder
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(title)
                .setContentText(text.toString())
                .setCategory(Notification.CATEGORY_ALARM)
                .setPriority(Notification.PRIORITY_MAX)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setAutoCancel(false)
                .setOngoing(true)
                .setOnlyAlertOnce(false)
                .setContentIntent(openIntent)
                .setFullScreenIntent(ringIntent, true)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel,
                        "خاموش",
                        dismissIntent).build())
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_popup_reminder,
                        "یادآوری بعداً",
                        snoozeIntent).build())
                .build();

        post(context, token.hashCode(), notification);
    }

    public static void showMissedCallNotification(
            Context context,
            String contactName,
            String number,
            long whenMillis,
            boolean showTime,
            int count) {
        if (context == null) return;
        ensureMissedCallChannel(context);

        String safeName = contactName == null ? "" : contactName.trim();
        String safeNumber = number == null ? "" : number.trim();
        String title = count > 1
                ? "📞 " + count + " تماس از دست‌رفته"
                : "📞 تماس از دست‌رفته";

        StringBuilder text = new StringBuilder();
        if (!safeName.isEmpty()) text.append(safeName);
        if (!safeNumber.isEmpty()) {
            if (text.length() > 0) text.append(" • ");
            text.append(safeNumber);
        }
        if (showTime) {
            if (text.length() > 0) text.append(" • ");
            text.append(new SimpleDateFormat("HH:mm", Locale.getDefault())
                    .format(new Date(whenMillis > 0L ? whenMillis : System.currentTimeMillis())));
        }
        if (text.length() == 0) text.append("تماس پاسخ داده نشد");

        Intent open = new Intent(context, MissedCallActionReceiver.class)
                .setAction(MissedCallActionReceiver.ACTION_OPEN_DIALER)
                .putExtra(MissedCallActionReceiver.EXTRA_NUMBER, safeNumber);
        PendingIntent openPending = PendingIntent.getBroadcast(
                context,
                0x4D430001,
                open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Intent clear = new Intent(context, MissedCallActionReceiver.class)
                .setAction(MissedCallActionReceiver.ACTION_CLEAR);
        PendingIntent clearPending = PendingIntent.getBroadcast(
                context,
                0x4D430002,
                clear,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                ? new Notification.Builder(context, MISSED_CALL_CHANNEL)
                : new Notification.Builder(context);

        builder.setSmallIcon(R.drawable.app_icon)
                .setContentTitle(title)
                .setContentText(text.toString())
                .setCategory(Notification.CATEGORY_CALL)
                .setPriority(Notification.PRIORITY_HIGH)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setWhen(whenMillis > 0L ? whenMillis : System.currentTimeMillis())
                .setShowWhen(true)
                .setNumber(Math.max(1, count))
                .setOnlyAlertOnce(false)
                .setAutoCancel(true)
                .setContentIntent(openPending)
                .setDeleteIntent(clearPending);

        if (!safeNumber.isEmpty()) {
            builder.addAction(new Notification.Action.Builder(
                    R.drawable.app_icon,
                    "تماس",
                    openPending).build());
        }

        post(context, MISSED_CALL_NOTIFICATION_ID, builder.build());
    }

    private static void ensureMissedCallChannel(Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || context == null) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel existing = nm.getNotificationChannel(MISSED_CALL_CHANNEL);
        if (existing != null) return;

        NotificationChannel channel = new NotificationChannel(
                MISSED_CALL_CHANNEL,
                "تماس‌های از دست‌رفته",
                NotificationManager.IMPORTANCE_HIGH);
        channel.setDescription("نمایش واضح تماس‌های از دست‌رفته Nexa روی صفحه قفل");
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        channel.setShowBadge(true);
        channel.setBypassDnd(false);
        nm.createNotificationChannel(channel);
    }

}
