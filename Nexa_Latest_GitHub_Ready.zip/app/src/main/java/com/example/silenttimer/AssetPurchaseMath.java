package com.example.silenttimer;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Exact-decimal entry math; monetary display may round to 2 digits, quantity never does. */
public final class AssetPurchaseMath {
    private AssetPurchaseMath() {}
    public static boolean valid(double paidRial,double unitRial,double feeRial){
        return Double.isFinite(paidRial)&&Double.isFinite(unitRial)&&Double.isFinite(feeRial)
            &&paidRial>0&&unitRial>0&&feeRial>=0&&feeRial<paidRial;
    }
    /** Fee is part of gross cash spent and is NOT a second deduction from saved units. */
    public static double netQuantity(double paidRial,double unitRial,double feeRial){
        if(!valid(paidRial,unitRial,feeRial))return Double.NaN;
        BigDecimal cash=BigDecimal.valueOf(paidRial);
        BigDecimal fee=BigDecimal.valueOf(feeRial);
        BigDecimal unit=BigDecimal.valueOf(unitRial);
        return cash.subtract(fee).divide(unit,8,RoundingMode.HALF_UP).doubleValue();
    }
    public static String quantityText(double quantity){
        if(!Double.isFinite(quantity)||quantity<0)return "—";
        return BigDecimal.valueOf(quantity).setScale(8,RoundingMode.HALF_UP)
            .stripTrailingZeros().toPlainString();
    }
}
