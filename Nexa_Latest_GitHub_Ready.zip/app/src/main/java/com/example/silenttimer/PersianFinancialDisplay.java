package com.example.silenttimer;

/** Presentation-only digit localization; never used for arithmetic or persistence. */
public final class PersianFinancialDisplay {
    private PersianFinancialDisplay() {}
    public static String digits(String input) {
        if (input == null) return "";
        StringBuilder result = new StringBuilder(input.length());
        for (int i=0;i<input.length();i++) {
            char c=input.charAt(i);
            if(c>='0'&&c<='9') c=(char)('۰'+c-'0');
            else if(c==',') c='٬';
            else if(c=='.') c='٫';
            result.append(c);
        }
        return result.toString();
    }
    /** Exact formatting for integer monetary amounts, including values above 2^53. */
    public static String amount(long value) {
        java.text.DecimalFormatSymbols symbols = new java.text.DecimalFormatSymbols(java.util.Locale.US);
        java.text.DecimalFormat formatter = new java.text.DecimalFormat("#,##0", symbols);
        formatter.setGroupingUsed(true);
        return digits(formatter.format(value));
    }
    /** Formats a finite raw financial amount without changing the stored number. */
    public static String amount(double value) {
        if (!Double.isFinite(value)) return "—";
        // IEEE-754 negative zero must display identically to positive zero.
        if (value == 0d) return "۰";
        java.text.DecimalFormatSymbols symbols = new java.text.DecimalFormatSymbols(java.util.Locale.US);
        java.text.DecimalFormat formatter = new java.text.DecimalFormat("#,##0.########", symbols);
        formatter.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return digits(formatter.format(value));
    }
}
