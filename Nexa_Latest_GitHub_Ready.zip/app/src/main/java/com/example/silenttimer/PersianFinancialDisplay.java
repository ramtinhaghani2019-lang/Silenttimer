package com.example.silenttimer;

/** Presentation-only digit localization; never used for arithmetic or persistence. */
public final class PersianFinancialDisplay {
    private PersianFinancialDisplay() {}
    public static String digits(String input) {
        if (input == null) return "";
        StringBuilder result = new StringBuilder(input.length());
        for (int i=0;i<input.length();i++) {
            char c=input.charAt(i);
            if(c>='0'&&c<='9') c=(char)('۰'+c-'0');
            else if(c==',') c='٬';
            else if(c=='.') c='٫';
            result.append(c);
        }
        return result.toString();
    }
}
