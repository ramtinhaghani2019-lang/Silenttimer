package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.AutoCompleteTextView;
import android.widget.ArrayAdapter;
import android.widget.HorizontalScrollView;

import java.util.List;

public class CaseActivity extends Activity {
    private LinearLayout list;
    private LinearLayout metricsHost;
    private LinearLayout filterRow;
    private TextView resultCount;
    private String selectedFilter = "همه";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        UiKit.applyWindow(this);
        build();
        if (getIntent().getBooleanExtra("quick_add", false)) {
            getIntent().removeExtra("quick_add");
            list.post(this::addDialog);
        }
    }

    @Override protected void onResume() { super.onResume(); render(); }

    private void build() {
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setClipToPadding(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(UiKit.dp(this, 16), UiKit.dp(this, 16), UiKit.dp(this, 16), UiKit.dp(this, 32));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        sc.addView(root);

        root.addView(UiKit.header(this, "⚖️ پرونده‌ها و امور حقوقی", v -> finish()), UiKit.matchWrap(this, 0, 4));
        root.addView(UiKit.muted(this, "پرونده‌ها، جلسه‌ها، دادگاه‌ها و وکلا در یک نما"), UiKit.matchWrap(this, 0, 11));

        metricsHost = new LinearLayout(this);
        metricsHost.setOrientation(LinearLayout.VERTICAL);
        root.addView(metricsHost, UiKit.matchWrap(this, 0, 12));

        Button add = UiKit.primaryButton(this, "＋ ثبت پرونده یا وقت دادگاه");
        add.setMinHeight(UiKit.dp(this, 48));
        add.setOnClickListener(v -> addDialog());
        root.addView(add, UiKit.matchWrap(this, 0, 12));

        LinearLayout dirBody = new LinearLayout(this);
        dirBody.setOrientation(LinearLayout.VERTICAL);
        Button courts = UiKit.secondaryButton(this, "دادگاه‌های ذخیره‌شده");
        courts.setOnClickListener(v -> manageNamed(true));
        dirBody.addView(courts, UiKit.matchWrap(this, 0, 7));
        Button lawyers = UiKit.secondaryButton(this, "وکلای ذخیره‌شده");
        lawyers.setOnClickListener(v -> manageNamed(false));
        dirBody.addView(lawyers);
        root.addView(UiKit.collapsible(this, "case_directory", "دفتر مشترک دادگاه و وکیل",
                "انتخاب و ثبت سریع دادگاه‌ها و وکلا", 5, false, dirBody), UiKit.matchWrap(this, 0, 13));

        root.addView(UiKit.sectionTitle(this, "فهرست پرونده‌ها"), UiKit.matchWrap(this, 0, 5));
        HorizontalScrollView filterScroll = new HorizontalScrollView(this);
        filterScroll.setHorizontalScrollBarEnabled(false);
        filterRow = new LinearLayout(this);
        filterRow.setOrientation(LinearLayout.HORIZONTAL);
        filterRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        filterScroll.addView(filterRow);
        root.addView(filterScroll, UiKit.matchWrap(this, 0, 6));
        resultCount = UiKit.muted(this, "");
        resultCount.setTextSize(12.5f);
        root.addView(resultCount, UiKit.matchWrap(this, 0, 7));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);
        setContentView(sc);
        refreshFilterChips();
        render();
    }

    private void refreshFilterChips() {
        if (filterRow == null) return;
        filterRow.removeAllViews();
        for (String choice : new String[]{"همه", "آینده", "گذشته"}) {
            Button chip = NexaCaseUi.chip(this, choice, choice.equals(selectedFilter));
            chip.setOnClickListener(v -> {
                selectedFilter = choice;
                refreshFilterChips();
                render();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, UiKit.dp(this, 48));
            lp.setMargins(0, 0, UiKit.dp(this, 7), 0);
            filterRow.addView(chip, lp);
        }
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 12), UiKit.dp(this, 14), UiKit.dp(this, 12));
        return e;
    }

    private AutoCompleteTextView choiceField(String hint, java.util.List<String> values) {
        AutoCompleteTextView e = new AutoCompleteTextView(this);
        e.setHint(hint);
        e.setHintTextColor(UiKit.MUTED);
        e.setTextColor(UiKit.TEXT);
        e.setBackground(UiKit.field(this));
        e.setPadding(UiKit.dp(this, 14), UiKit.dp(this, 12), UiKit.dp(this, 14), UiKit.dp(this, 12));
        e.setThreshold(0);
        e.setSingleLine(true);
        e.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_dropdown_item_1line, values));
        e.setOnClickListener(v -> e.showDropDown());
        return e;
    }

    private void addDialog() { editDialog(null); }

    private void editDialog(NexaStore.CaseItem existing) {
        LinearLayout box = UiKit.dialogPanel(this);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.addView(UiKit.sectionTitle(this, "مشخصات پرونده"), UiKit.matchWrap(this, 0, 7));

        EditText title = field("عنوان پرونده (الزامی)");
        EditText caseNumber = field("شماره پرونده");
        caseNumber.setTextDirection(View.TEXT_DIRECTION_LTR);
        caseNumber.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        AutoCompleteTextView court = choiceField("نام دادگاه / انتخاب از ذخیره‌شده‌ها", NexaStore.courts(this));
        EditText branch = field("شعبه");
        EditText party = field("طرف پرونده");
        AutoCompleteTextView lawyer = choiceField("نام وکیل / انتخاب از ذخیره‌شده‌ها", NexaStore.lawyers(this));
        EditText note = field("توضیحات");
        EditText paid = field("مجموع پرداخت پرونده (تومان)");
        paid.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        NumberFormatUtil.attachThousands(paid);
        EditText docs = field("اسناد / پیوست‌ها / یادداشت مدارک");

        final long[] when = {System.currentTimeMillis() + 24L * 60L * 60L * 1000L};
        Button date = UiKit.secondaryButton(this, "تاریخ جلسه: " + PersianDateUtil.pretty(when[0]));
        date.setOnClickListener(v -> PersianDatePickerHelper.pickDateTime(this, when[0], "تاریخ و ساعت جلسه",
                ms -> { when[0] = ms; date.setText("تاریخ جلسه: " + PersianDateUtil.pretty(ms)); }));

        box.addView(title);
        box.addView(caseNumber);
        box.addView(court);
        box.addView(branch);
        box.addView(party);
        box.addView(lawyer);
        box.addView(UiKit.sectionTitle(this, "هزینه‌ها و اسناد"), UiKit.matchWrap(this, 9, 6));
        box.addView(paid);
        box.addView(docs);
        box.addView(note);
        box.addView(UiKit.sectionTitle(this, "جلسه و یادآوری"), UiKit.matchWrap(this, 9, 6));
        box.addView(date);
        RepeatIntervalPicker interval = new RepeatIntervalPicker(this, box,
                existing == null ? "none" : existing.recurrence);
        if (existing != null) {
            title.setText(existing.title);
            caseNumber.setText(existing.caseNumber);
            court.setText(existing.court);
            branch.setText(existing.branch);
            party.setText(existing.counterparty);
            lawyer.setText(existing.lawyer);
            note.setText(existing.note);
            paid.setText(existing.paidAmount > 0 ? NumberFormatUtil.grouped(existing.paidAmount) : "");
            docs.setText(existing.documentNote);
            when[0] = existing.whenMillis;
            date.setText("تاریخ جلسه: " + PersianDateUtil.pretty(when[0]));
        }
        AlertEditor alerts = new AlertEditor(this, box,
                existing == null ? "10080,1440,0" : existing.alertRules,
                existing == null ? 5 : existing.alertRepeat);

        ScrollView formScroll = new ScrollView(this);
        formScroll.setFillViewport(false);
        formScroll.addView(box);
        AlertDialog editor = new AlertDialog.Builder(this)
                .setTitle(existing == null ? "پرونده جدید" : "ویرایش پرونده")
                .setView(formScroll)
                .setPositiveButton("ذخیره", null)
                .setNegativeButton("انصراف", null)
                .create();
        editor.setOnShowListener(d -> editor.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String t = title.getText().toString().trim();
            if (t.isEmpty()) {
                title.setError("عنوان پرونده را وارد کنید");
                title.requestFocus();
                formScroll.smoothScrollTo(0, 0);
                return;
            }
            if (when[0] <= 0) {
                date.setError("تاریخ جلسه معتبر نیست");
                return;
            }
            NexaStore.CaseItem x = existing == null ? new NexaStore.CaseItem() : existing;
            x.alertRules = alerts.rules();
            x.alertRepeat = alerts.repeatMinutes();
            x.title = t;
            x.caseNumber = caseNumber.getText().toString().trim();
            x.court = court.getText().toString().trim();
            x.branch = branch.getText().toString().trim();
            x.counterparty = party.getText().toString().trim();
            x.lawyer = lawyer.getText().toString().trim();
            x.note = note.getText().toString().trim();
            x.paidAmount = NumberFormatUtil.longValue(paid.getText());
            x.documentNote = docs.getText().toString().trim();
            NexaStore.addCourt(this, x.court);
            NexaStore.addLawyer(this, x.lawyer);
            x.whenMillis = when[0];
            x.recurrence = interval.rule();
            if (existing == null) NexaStore.addCase(this, x);
            else NexaStore.updateCase(this, x);
            LinkedReminderHelper.upsert(
                    this, "case:" + x.id, "وقت دادگاه: " + x.title, "دادگاه", "⚖️",
                    "شماره پرونده: " + x.caseNumber + " • " + x.court + " " + x.branch,
                    x.whenMillis, x.alertRules, x.alertRepeat, x.recurrence);
            NexaStore.addHistory(this, "دادگاه", "ثبت شد: " + x.title);
            editor.dismiss();
            render();
        }));
        editor.show();
    }

    private void manageNamed(boolean courtMode) {
        java.util.List<String> data = courtMode ? NexaStore.courts(this) : NexaStore.lawyers(this);
        LinearLayout box = UiKit.dialogPanel(this);
        if (data.isEmpty()) box.addView(UiKit.muted(this, "هنوز نامی ثبت نشده است."), UiKit.matchWrap(this, 0, 7));
        for (String x : data) {
            TextView r = UiKit.muted(this, "• " + x);
            box.addView(r, UiKit.matchWrap(this, 0, 5));
        }
        EditText e = field(courtMode ? "نام دادگاه جدید" : "نام وکیل جدید");
        box.addView(e, UiKit.matchWrap(this, 8, 0));
        ScrollView sc = new ScrollView(this);
        sc.addView(box);
        new AlertDialog.Builder(this)
                .setTitle(courtMode ? "دفتر دادگاه‌ها" : "دفتر وکلا")
                .setView(sc)
                .setPositiveButton("افزودن", (d, w) -> {
                    if (courtMode) NexaStore.addCourt(this, e.getText().toString());
                    else NexaStore.addLawyer(this, e.getText().toString());
                })
                .setNegativeButton("بستن", null).show();
    }

    private void render() {
        if (list == null) return;
        list.removeAllViews();
        List<NexaStore.CaseItem> data = NexaStore.cases(this);
        long now = System.currentTimeMillis();
        int future = 0, past = 0, shown = 0;
        for (NexaStore.CaseItem x : data) {
            long date = CaseOverviewPolicy.shownDate(x.whenMillis, x.recurrence, now);
            if (CaseOverviewPolicy.isPast(date, now)) past++;
            else if (date >= now) future++;
        }
        if (metricsHost != null) {
            metricsHost.removeAllViews();
            metricsHost.addView(NexaCaseUi.metrics(this, data.size(), future, past));
        }
        for (NexaStore.CaseItem x : data) {
            long shownDate = CaseOverviewPolicy.shownDate(x.whenMillis, x.recurrence, now);
            if (!CaseOverviewPolicy.matches(selectedFilter, shownDate, now)) continue;
            shown++;
            boolean old = CaseOverviewPolicy.isPast(shownDate, now);
            LinearLayout card = UiKit.cardLayout(this);
            card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
            card.setMinimumHeight(UiKit.dp(this, 116));
            card.addView(NexaCaseUi.status(this, old), UiKit.matchWrap(this, 0, 7));
            TextView heading = UiKit.sectionTitle(this, "⚖️ " + x.title);
            heading.setMaxLines(3);
            card.addView(heading);
            boolean virtualNext = shownDate != x.whenMillis && shownDate > 0;
            TextView whenLabel = UiKit.muted(this,
                    (virtualNext ? "نوبت بعدی: " : "جلسه: ") + PersianDateUtil.pretty(shownDate)
                            + ReminderRecurrence.labelSuffix(x.recurrence));
            whenLabel.setTextColor(old ? UiKit.RED : UiKit.BLUE);
            card.addView(whenLabel, UiKit.matchWrap(this, 6, 2));
            if (!x.caseNumber.isEmpty()) card.addView(UiKit.muted(this, "شماره پرونده: " + x.caseNumber));
            if (!x.court.isEmpty()) card.addView(UiKit.muted(this, "دادگاه: " + x.court
                    + (x.branch.isEmpty() ? "" : " • شعبه " + x.branch)));
            if (!x.counterparty.isEmpty()) card.addView(UiKit.muted(this, "طرف پرونده: " + x.counterparty));
            if (!x.lawyer.isEmpty()) card.addView(UiKit.muted(this, "وکیل: " + x.lawyer));
            if (x.paidAmount > 0) card.addView(UiKit.muted(this,
                    "پرداخت‌ها: " + NumberFormatUtil.grouped(x.paidAmount) + " تومان"));
            if (!x.documentNote.isEmpty()) card.addView(UiKit.muted(this, "اسناد: " + x.documentNote));
            if (!x.note.isEmpty()) card.addView(UiKit.muted(this, x.note), UiKit.matchWrap(this, 5, 0));
            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.CENTER_VERTICAL);
            Button edit = UiKit.editIconButton(this);
            edit.setContentDescription("ویرایش پرونده " + x.title);
            edit.setOnClickListener(v -> editDialog(x));
            actions.addView(edit, new LinearLayout.LayoutParams(UiKit.dp(this, 48), UiKit.dp(this, 48)));
            Button del = UiKit.deleteIconButton(this);
            del.setContentDescription("حذف پرونده " + x.title);
            del.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("حذف این مورد؟")
                    .setMessage(x.title).setPositiveButton("حذف", (d, w) -> {
                        LinkedReminderHelper.remove(this, "case:" + x.id);
                        NexaStore.removeCase(this, x.id);
                        render();
                    }).setNegativeButton("انصراف", null).show());
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(UiKit.dp(this, 48), UiKit.dp(this, 48));
            lp.setMargins(UiKit.dp(this, 6), 0, 0, 0);
            actions.addView(del, lp);
            card.addView(actions, UiKit.matchWrap(this, 8, 0));
            list.addView(card, UiKit.matchWrap(this, 0, 9));
        }
        if (resultCount != null) resultCount.setText("نمایش " + shown + " مورد از " + data.size() + " پرونده");
        if (shown == 0) list.addView(NexaCaseUi.empty(this, !"همه".equals(selectedFilter)),
                UiKit.matchWrap(this, 5, 0));
    }
}
