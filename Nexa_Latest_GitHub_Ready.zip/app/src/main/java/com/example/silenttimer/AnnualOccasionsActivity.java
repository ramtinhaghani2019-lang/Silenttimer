package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.List;

/** Yearly occasions: accessible search, filter and management without home-screen clutter. */
public class AnnualOccasionsActivity extends Activity {
    private static final String[] FILTERS={OccasionDirectoryPolicy.ALL,OccasionDirectoryPolicy.SOON,
            OccasionDirectoryPolicy.BIRTHDAY,OccasionDirectoryPolicy.MARRIAGE,
            OccasionDirectoryPolicy.MEMORIAL,OccasionDirectoryPolicy.PERSONAL,OccasionDirectoryPolicy.PAUSED};
    private static final String[] LABELS={"همه","۳۰ روز آینده","تولد","ازدواج","یادبود","شخصی","متوقف"};
    private LinearLayout list,chips;
    private TextView summary;
    private EditText search;
    private String filter=OccasionDirectoryPolicy.ALL;

    @Override protected void onCreate(Bundle saved){
        super.onCreate(saved);UiKit.applyWindow(this);
        if(saved!=null)filter=saved.getString("occasion_filter",OccasionDirectoryPolicy.ALL);
        build();
        if(saved!=null)search.setText(saved.getString("occasion_search",""));
    }
    @Override protected void onSaveInstanceState(Bundle state){
        state.putString("occasion_filter",filter);
        state.putString("occasion_search",search==null?"":search.getText().toString());
        super.onSaveInstanceState(state);
    }
    @Override protected void onResume(){super.onResume();render();}

    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));
        root.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,25));sc.addView(root);
        root.addView(UiKit.header(this,"مناسبت‌ها",v->finish()),UiKit.matchWrap(this,0,7));
        root.addView(UiKit.muted(this,"تولدها، سالگردها و یادبودها؛ هر سال به‌طور خودکار"),UiKit.matchWrap(this,0,9));
        Button add=UiKit.primaryButton(this,"＋ افزودن مناسبت");
        add.setOnClickListener(v->startActivity(new Intent(this,OccasionEditActivity.class)));
        root.addView(add,UiKit.matchWrap(this,0,12));

        search=UiKit.styleField(this,new EditText(this),"جست‌وجوی مناسبت…");
        search.setSingleLine(true);
        search.setContentDescription("جست‌وجو در عنوان، نوع و تاریخ مناسبت");
        search.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            @Override public void onTextChanged(CharSequence s,int start,int before,int count){render();}
            @Override public void afterTextChanged(Editable e){}
        });
        root.addView(search,UiKit.matchWrap(this,0,9));

        HorizontalScrollView strip=new HorizontalScrollView(this);strip.setHorizontalScrollBarEnabled(false);
        strip.setFillViewport(false);
        chips=new LinearLayout(this);chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        chips.setGravity(Gravity.CENTER_VERTICAL);strip.addView(chips);
        root.addView(strip,UiKit.matchWrap(this,0,10));
        summary=UiKit.sectionTitle(this,"");root.addView(summary,UiKit.matchWrap(this,0,10));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        setContentView(sc);render();
    }
    private void renderChips(){
        if(chips==null)return;
        chips.removeAllViews();
        for(int i=0;i<FILTERS.length;i++){
            final String key=FILTERS[i];
            boolean selected=key.equals(filter);
            TextView chip=UiKit.chip(this,LABELS[i],selected);
            chip.setMinHeight(UiKit.dp(this,48));
            chip.setMinWidth(UiKit.dp(this,56));
            chip.setGravity(Gravity.CENTER);
            chip.setFocusable(true);chip.setClickable(true);
            chip.setContentDescription("فیلتر "+LABELS[i]+(selected?"، انتخاب‌شده":""));
            chip.setOnClickListener(v->{filter=key;render();});
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,UiKit.dp(this,48));
            lp.setMargins(UiKit.dp(this,5),0,UiKit.dp(this,5),0);
            chips.addView(chip,lp);
        }
    }
    private void render(){
        if(list==null || summary==null)return;
        renderChips();list.removeAllViews();
        List<OccasionStore.Occasion> all=OccasionStore.all(this);
        long now=System.currentTimeMillis();
        String query=search==null?"":search.getText().toString();
        List<OccasionStore.Occasion> shown=OccasionDirectoryPolicy.select(all,query,filter,now);
        int active=0;for(OccasionStore.Occasion e:all)if(e.active)active++;
        summary.setText("📅 "+shown.size()+" از "+all.size()+" مناسبت  •  "+active+" فعال");
        if(shown.isEmpty()){
            String message=all.isEmpty()?"هنوز مناسبتی ثبت نشده. یک تولد یا سالگرد اضافه کنید؛ هشدار سال‌های بعد خودکار خواهد بود.":
                    "با این جست‌وجو یا فیلتر، مناسبتی پیدا نشد.";
            list.addView(UiKit.emptyState(this,"مناسبتی برای نمایش نیست",message),UiKit.matchWrap(this,10,8));
            if(!all.isEmpty()){
                Button clear=UiKit.secondaryButton(this,"نمایش همه مناسبت‌ها");
                clear.setOnClickListener(v->{filter=OccasionDirectoryPolicy.ALL;search.setText("");render();});
                list.addView(clear,UiKit.matchWrap(this,4,8));
            }
            return;
        }
        for(OccasionStore.Occasion e:shown){
            LinearLayout card=NexaReminderUi.reminderCard(this,false,false);
            card.setMinimumHeight(UiKit.dp(this,106));
            card.addView(UiKit.sectionTitle(this,e.icon()+"  "+e.title));
            card.addView(UiKit.muted(this,e.typeLabel()+"  •  "+AnnualOccasionDates.dateLabel(e)),UiKit.matchWrap(this,5,0));
            long next=AnnualOccasionDates.next(e,now);
            String nextText=e.active?"🔔 نوبت بعد: "+PersianDateUtil.pretty(next)+"  •  تکرار هر سال":"⏸ هشدار متوقف است";
            card.addView(UiKit.muted(this,nextText),UiKit.matchWrap(this,5,0));

            LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);
            Button edit=UiKit.secondaryButton(this,"ویرایش");
            edit.setContentDescription("ویرایش مناسبت "+e.title);
            edit.setOnClickListener(v->open(e));
            controls.addView(edit,new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f));
            Button manage=UiKit.secondaryButton(this,"مدیریت ⋯");
            manage.setContentDescription("مدیریت هشدار و حذف مناسبت "+e.title);
            manage.setOnClickListener(v->manage(e));
            LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f);
            mp.setMargins(UiKit.dp(this,8),0,0,0);
            controls.addView(manage,mp);card.addView(controls,UiKit.matchWrap(this,11,0));
            card.setOnClickListener(v->open(e));
            card.setFocusable(true);
            card.setContentDescription("مناسبت "+e.title+"؛ "+e.typeLabel()+"؛ "+nextText+"؛ برای ویرایش باز کنید");
            list.addView(card,UiKit.matchWrap(this,0,9));
        }
    }
    private void open(OccasionStore.Occasion e){
        Intent i=new Intent(this,OccasionEditActivity.class);i.putExtra("id",e.id);startActivity(i);
    }
    private void manage(OccasionStore.Occasion e){
        String first=e.active?"⏸ توقف هشدار سالانه":"🔔 فعال‌سازی هشدار سالانه";
        new AlertDialog.Builder(this).setTitle(e.title)
                .setItems(new String[]{first,"حذف مناسبت"},(d,choice)->{
                    if(choice==0){
                        OccasionScheduler.cancel(this,e);
                        e.active=!e.active;
                        OccasionStore.save(this,e);
                        if(e.active)OccasionScheduler.schedule(this,e);
                        render();
                    }else delete(e);
                }).setNegativeButton("انصراف",null).show();
    }
    private void delete(OccasionStore.Occasion e){
        new AlertDialog.Builder(this).setTitle("حذف مناسبت")
            .setMessage("«"+e.title+"» و هشدار سالانه‌اش حذف شود؟")
            .setPositiveButton("حذف",(d,w)->{OccasionScheduler.cancel(this,e);OccasionStore.delete(this,e.id);render();})
            .setNegativeButton("انصراف",null).show();
    }
}
