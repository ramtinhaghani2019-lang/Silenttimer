package com.example.silenttimer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;

/** Dedicated accessible yearly occasion directory, without cluttering the home dashboard. */
public class AnnualOccasionsActivity extends Activity {
    private LinearLayout list;
    private TextView summary;
    @Override protected void onCreate(Bundle saved){super.onCreate(saved);UiKit.applyWindow(this);build();}
    @Override protected void onResume(){super.onResume();render();}
    private void build(){
        ScrollView sc=new ScrollView(this);sc.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackground(UiKit.screenBackground(this));root.setPadding(UiKit.dp(this,16),UiKit.dp(this,12),UiKit.dp(this,16),UiKit.dp(this,25));sc.addView(root);
        root.addView(UiKit.header(this,"مناسبت‌ها",v->finish()),UiKit.matchWrap(this,0,7));
        root.addView(UiKit.muted(this,"تولدها، سالگردها و یادبودها؛ هر سال به‌طور خودکار"),UiKit.matchWrap(this,0,9));
        Button add=UiKit.primaryButton(this,"＋ افزودن مناسبت");
        add.setOnClickListener(v->startActivity(new Intent(this,OccasionEditActivity.class)));
        root.addView(add,UiKit.matchWrap(this,0,12));
        summary=UiKit.sectionTitle(this,"");root.addView(summary,UiKit.matchWrap(this,0,11));
        list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list);setContentView(sc);render();
    }
    private void render(){
        if(list==null)return;list.removeAllViews();
        List<OccasionStore.Occasion> all=new ArrayList<>(OccasionStore.all(this));long now=System.currentTimeMillis();
        all.sort(Comparator.comparingLong(e->AnnualOccasionDates.next(e,now)));
        int active=0;for(OccasionStore.Occasion e:all)if(e.active)active++;
        summary.setText("📅 "+all.size()+" مناسبت ثبت‌شده  •  "+active+" فعال");
        if(all.isEmpty()){
            TextView empty=UiKit.muted(this,"هنوز مناسبتی ثبت نشده. یک تولد یا سالگرد اضافه کنید؛ هشدار سال‌های بعد خودکار خواهد بود.");
            empty.setGravity(Gravity.CENTER);list.addView(empty,UiKit.matchWrap(this,16,6));return;
        }
        for(OccasionStore.Occasion e:all){
            LinearLayout card=NexaReminderUi.reminderCard(this,false,false);
            card.addView(UiKit.sectionTitle(this,e.icon()+"  "+e.title));
            card.addView(UiKit.muted(this,e.typeLabel()+"  •  "+AnnualOccasionDates.dateLabel(e)),UiKit.matchWrap(this,5,0));
            long next=AnnualOccasionDates.next(e,now);
            String nextText=e.active?"🔔 نوبت بعد: "+PersianDateUtil.pretty(next)+"  •  تکرار هر سال":"⏸ هشدار متوقف است";
            card.addView(UiKit.muted(this,nextText),UiKit.matchWrap(this,5,0));
            LinearLayout controls=new LinearLayout(this);controls.setGravity(Gravity.CENTER_VERTICAL);
            Button edit=UiKit.secondaryButton(this,"ویرایش");edit.setOnClickListener(v->open(e));
            controls.addView(edit,new LinearLayout.LayoutParams(0,UiKit.dp(this,46),1f));
            Button toggle=UiKit.secondaryButton(this,e.active?"توقف":"فعال‌سازی");
            toggle.setOnClickListener(v->{OccasionScheduler.cancel(this,e);e.active=!e.active;OccasionStore.save(this,e);OccasionScheduler.schedule(this,e);render();});
            LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,UiKit.dp(this,46),1f);tp.setMargins(UiKit.dp(this,5),0,0,0);
            controls.addView(toggle,tp);
            Button remove=UiKit.secondaryButton(this,"حذف");remove.setOnClickListener(v->delete(e));
            LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(0,UiKit.dp(this,46),.8f);rp.setMargins(UiKit.dp(this,5),0,0,0);
            controls.addView(remove,rp);card.addView(controls,UiKit.matchWrap(this,11,0));
            card.setOnClickListener(v->open(e));list.addView(card,UiKit.matchWrap(this,0,9));
        }
    }
    private void open(OccasionStore.Occasion e){Intent i=new Intent(this,OccasionEditActivity.class);i.putExtra("id",e.id);startActivity(i);}
    private void delete(OccasionStore.Occasion e){
        new AlertDialog.Builder(this).setTitle("حذف مناسبت")
            .setMessage("«"+e.title+"» و هشدار سالانه‌اش حذف شود؟")
            .setPositiveButton("حذف",(d,w)->{OccasionScheduler.cancel(this,e);OccasionStore.delete(this,e.id);render();})
            .setNegativeButton("انصراف",null).show();
    }
}
