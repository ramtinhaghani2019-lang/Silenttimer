package com.example.silenttimer;

import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;
import android.telephony.TelephonyManager;

/**
 * Lightweight missed-call tracker used by the Nexa lock-screen guard.
 *
 * The CallScreening service records the incoming number when available and the
 * PHONE_STATE receiver decides whether the call was answered (OFFHOOK) or ended
 * while still unanswered (RINGING -> IDLE). State is persisted so process death
 * between telephony callbacks does not create a false reset.
 */
public final class MissedCallGuard {
    private static final String PREFS = "nexa_missed_call_guard";
    private static final String KEY_ACTIVE = "active";
    private static final String KEY_NUMBER = "number";
    private static final String KEY_STARTED_AT = "started_at";
    private static final String KEY_ANSWERED = "answered";
    private static final String KEY_COUNT = "unviewed_count";
    private static final String KEY_LAST_MISSED_AT = "last_missed_at";
    private static final long MAX_CALL_WINDOW_MS = 15L * 60L * 1000L;
    private static final long COUNT_RESET_WINDOW_MS = 12L * 60L * 60L * 1000L;

    private MissedCallGuard() {}

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    /** Called by CallScreeningService as early as possible for an incoming call. */
    public static void noteIncoming(Context context, String number) {
        if (context == null || !AppPrefs.isMissedCallGuardEnabled(context)) return;
        SharedPreferences sp = prefs(context);
        long now = System.currentTimeMillis();
        String clean = safeNumber(number);

        synchronized (MissedCallGuard.class) {
            boolean active = sp.getBoolean(KEY_ACTIVE, false);
            long startedAt = sp.getLong(KEY_STARTED_AT, 0L);
            boolean stale = !active || startedAt <= 0L || now - startedAt > MAX_CALL_WINDOW_MS;

            SharedPreferences.Editor editor = sp.edit();
            if (stale) {
                editor.putBoolean(KEY_ACTIVE, true)
                        .putLong(KEY_STARTED_AT, now)
                        .putBoolean(KEY_ANSWERED, false);
            }
            if (!clean.isEmpty()) {
                editor.putString(KEY_NUMBER, clean);
            }
            editor.apply();
        }
    }

    /** Receives raw TelephonyManager state transitions from CallStateReceiver. */
    public static void onPhoneState(Context context, String state, String incomingNumber) {
        if (context == null || state == null) return;
        if (!AppPrefs.isMissedCallGuardEnabled(context)) {
            clearActiveCall(context);
            return;
        }

        SharedPreferences sp = prefs(context);
        long now = System.currentTimeMillis();

        synchronized (MissedCallGuard.class) {
            if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
                boolean active = sp.getBoolean(KEY_ACTIVE, false);
                long startedAt = sp.getLong(KEY_STARTED_AT, 0L);
                boolean stale = !active || startedAt <= 0L || now - startedAt > MAX_CALL_WINDOW_MS;
                SharedPreferences.Editor editor = sp.edit();
                if (stale) {
                    editor.putBoolean(KEY_ACTIVE, true)
                            .putLong(KEY_STARTED_AT, now)
                            .putBoolean(KEY_ANSWERED, false);
                }
                String clean = safeNumber(incomingNumber);
                if (!clean.isEmpty()) editor.putString(KEY_NUMBER, clean);
                editor.apply();
                return;
            }

            if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
                if (sp.getBoolean(KEY_ACTIVE, false)) {
                    sp.edit().putBoolean(KEY_ANSWERED, true).apply();
                }
                return;
            }

            if (!TelephonyManager.EXTRA_STATE_IDLE.equals(state)) return;
            if (!sp.getBoolean(KEY_ACTIVE, false)) return;

            long startedAt = sp.getLong(KEY_STARTED_AT, 0L);
            boolean answered = sp.getBoolean(KEY_ANSWERED, false);
            String number = sp.getString(KEY_NUMBER, "");
            boolean plausible = startedAt > 0L && now >= startedAt && now - startedAt <= MAX_CALL_WINDOW_MS;

            clearActiveCallLocked(sp);

            if (!answered && plausible) {
                deliverMissedCall(context, number, startedAt);
            }
        }
    }

    private static void deliverMissedCall(Context context, String number, long startedAt) {
        String deliveryKey = "missed-call:" + safeNumber(number) + ":" + startedAt;
        if (!NexaNotificationEngine.acquireDelivery(context, deliveryKey)) return;

        SharedPreferences sp = prefs(context);
        long now = System.currentTimeMillis();
        long lastMissedAt = sp.getLong(KEY_LAST_MISSED_AT, 0L);
        int count = sp.getInt(KEY_COUNT, 0);
        if (lastMissedAt <= 0L || now - lastMissedAt > COUNT_RESET_WINDOW_MS) {
            count = 0;
        }
        count++;
        sp.edit()
                .putInt(KEY_COUNT, count)
                .putLong(KEY_LAST_MISSED_AT, now)
                .apply();

        String name = AppPrefs.isMissedCallShowName(context)
                ? resolveContactName(context, number)
                : "";
        NexaNotificationEngine.showMissedCallNotification(
                context,
                name,
                AppPrefs.isMissedCallShowNumber(context) ? safeNumber(number) : "",
                startedAt,
                AppPrefs.isMissedCallShowTime(context),
                count
        );
    }

    public static void resetMissedCount(Context context) {
        if (context == null) return;
        prefs(context).edit()
                .remove(KEY_COUNT)
                .remove(KEY_LAST_MISSED_AT)
                .apply();
    }

    public static int getUnviewedCount(Context context) {
        if (context == null) return 0;
        SharedPreferences sp = prefs(context);
        long last = sp.getLong(KEY_LAST_MISSED_AT, 0L);
        if (last <= 0L || System.currentTimeMillis() - last > COUNT_RESET_WINDOW_MS) return 0;
        return Math.max(0, sp.getInt(KEY_COUNT, 0));
    }

    public static void clearActiveCall(Context context) {
        if (context == null) return;
        synchronized (MissedCallGuard.class) {
            clearActiveCallLocked(prefs(context));
        }
    }

    private static void clearActiveCallLocked(SharedPreferences sp) {
        sp.edit()
                .remove(KEY_ACTIVE)
                .remove(KEY_NUMBER)
                .remove(KEY_STARTED_AT)
                .remove(KEY_ANSWERED)
                .apply();
    }

    private static String resolveContactName(Context context, String number) {
        String clean = safeNumber(number);
        if (clean.isEmpty()) return "";
        Cursor cursor = null;
        try {
            Uri uri = Uri.withAppendedPath(
                    ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                    Uri.encode(clean));
            cursor = context.getContentResolver().query(
                    uri,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},
                    null,
                    null,
                    null);
            if (cursor != null && cursor.moveToFirst()) {
                String value = cursor.getString(0);
                return value == null ? "" : value.trim();
            }
        } catch (SecurityException ignored) {
            // READ_CONTACTS may be intentionally denied; number-only notification still works.
        } catch (Exception ignored) {
        } finally {
            if (cursor != null) cursor.close();
        }
        return "";
    }

    private static String safeNumber(String number) {
        return number == null ? "" : number.trim();
    }
}
