package com.example.silenttimer;

import static org.junit.Assert.*;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;
import java.util.Arrays;
import java.util.List;

/** Financial examples are deterministic, with no live market service or device data. */
@RunWith(AndroidJUnit4.class)
public class AssetGroupQuoteRegressionTest {
    private NexaStore.AssetEntry item(String type,double qty,double paid,double fee,double current){
        NexaStore.AssetEntry x=new NexaStore.AssetEntry();
        x.type=type;x.amount=qty;x.buyUnitPrice=paid;x.fee=fee;x.currentUnitPrice=current;
        return x;
    }
    @Test public void sharedFundQuoteRevaluesEveryLotWithoutChangingPurchaseHistory(){
        NexaStore.AssetEntry a=item("صندوق کاریزما",2,100,10,110);
        NexaStore.AssetEntry b=item("صندوق کاریزما",3,120,0,105);
        NexaStore.AssetEntry c=item("صندوق کاریزما",5,90,5,115);
        NexaStore.AssetEntry other=item("دلار",2,80,0,100);
        a.autoPrice=true;b.autoPrice=true;c.autoPrice=true;
        List<NexaStore.AssetEntry> data=Arrays.asList(a,b,c,other);
        assertTrue(Double.isNaN(AssetGroupQuoteEngine.sharedQuote(Arrays.asList(a,b,c))));
        double oldCost=AssetFinanceEngine.totalOpenCost(Arrays.asList(a,b,c));
        assertEquals(1025d,oldCost,0.000001);
        int count=AssetGroupQuoteEngine.applyQuote(data,"صندوق کاریزما",125d,123456789L);
        assertEquals(3,count);
        assertEquals(125d,a.currentUnitPrice,0d);
        assertEquals(125d,b.currentUnitPrice,0d);
        assertEquals(125d,c.currentUnitPrice,0d);
        assertEquals(100d,other.currentUnitPrice,0d);
        assertEquals(100d,a.buyUnitPrice,0d);
        assertEquals(120d,b.buyUnitPrice,0d);
        assertEquals(90d,c.buyUnitPrice,0d);
        assertEquals(10d,a.fee,0d);
        assertEquals(1025d,AssetFinanceEngine.totalOpenCost(Arrays.asList(a,b,c)),0.000001);
        assertEquals(1250d,AssetFinanceEngine.totalMarketValue(Arrays.asList(a,b,c)),0.000001);
        assertEquals(225d,AssetFinanceEngine.totalProfit(Arrays.asList(a,b,c)),0.000001);
        assertEquals(225d/1025d*100d,AssetFinanceEngine.totalProfit(Arrays.asList(a,b,c))/oldCost*100d,0.000001);
        assertEquals(125d,AssetGroupQuoteEngine.sharedQuote(Arrays.asList(a,b,c)),0d);
        assertFalse(a.autoPrice);assertFalse(b.autoPrice);assertFalse(c.autoPrice);
        assertEquals(123456789L,a.quoteUpdatedAt);
    }
    @Test public void soldLotsRetainRealizedProfitAndOnlyRemainingUnitsRevalue(){
        NexaStore.AssetEntry a=item("صندوق کاریزما",10,100,20,100);
        assertTrue(AssetFinanceEngine.sell(a,4,150,1000L));
        assertEquals(6d,a.amount,0d);
        assertEquals(12d,a.fee,0.000001);
        assertEquals(192d,a.realizedProfit,0.000001);
        assertEquals(612d,AssetFinanceEngine.openCost(a),0.000001);
        assertEquals(1,AssetGroupQuoteEngine.applyQuote(Arrays.asList(a),"صندوق کاریزما",125,2000L));
        assertEquals(750d,AssetFinanceEngine.marketValue(a),0.000001);
        assertEquals(138d,AssetFinanceEngine.unrealizedProfit(a),0.000001);
        assertEquals(138d/612d*100d,AssetFinanceEngine.returnPercent(a),0.000001);
        assertEquals(192d,a.realizedProfit,0.000001);
        assertEquals(330d,AssetFinanceEngine.totalProfit(Arrays.asList(a)),0.000001);
        assertEquals(1020d,AssetFinanceEngine.totalInvestedCost(Arrays.asList(a)),0.000001);
        assertEquals(330d/1020d*100d,AssetFinanceEngine.totalReturnPercent(Arrays.asList(a)),0.000001);
    }
    @Test public void invalidQuoteNeverModifiesAnyLot(){
        NexaStore.AssetEntry a=item("صندوق کاریزما",1,100,0,100);
        NexaStore.AssetEntry b=item("صندوق کاریزما",Double.POSITIVE_INFINITY,100,0,100);
        List<NexaStore.AssetEntry> entries=Arrays.asList(a,b);
        assertEquals(0,AssetGroupQuoteEngine.applyQuote(entries,"صندوق کاریزما",200,1));
        assertEquals(100,a.currentUnitPrice,0);
        b.amount=2;
        assertEquals(0,AssetGroupQuoteEngine.applyQuote(entries,"صندوق کاریزما",Double.NaN,1));
        assertEquals(0,AssetGroupQuoteEngine.applyQuote(entries,"صندوق کاریزما",0,1));
        assertEquals(0,AssetGroupQuoteEngine.applyQuote(entries,"صندوق کاریزما",Double.MAX_VALUE,1));
        assertEquals(0,AssetGroupQuoteEngine.applyQuote(entries,"صندوق کاریزما",200,0));
        assertEquals(100,b.currentUnitPrice,0);
    }
    @Test public void unknownCostUsesNoArtificialPercent(){
        NexaStore.AssetEntry a=item("صندوق کاریزما",1,0,0,100);
        assertEquals(0d,AssetFinanceEngine.openCost(a),0d);
        assertEquals(100d,AssetGroupQuoteEngine.sharedQuote(Arrays.asList(a)),0d);
    }
}
