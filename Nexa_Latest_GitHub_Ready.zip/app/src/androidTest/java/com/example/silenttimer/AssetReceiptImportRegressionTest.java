package com.example.silenttimer;

import static org.junit.Assert.*;
import android.content.Context;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Receipt OCR UI/parser contracts: no duplicate fee or auto-save on image selection. */
@RunWith(AndroidJUnit4.class)
public final class AssetReceiptImportRegressionTest {
    @Test public void persianKarizmaReceiptDistinguishesGrossFromNet(){
        String sample="نام ابزار: حساب با پشتوانه نقره\\n"+
            "تاریخ تراکنش ۱۴۰۵/۰۸/۰۵\\nمبلغ ۱,۰۰۰,۰۰۰,۰۰۰ ریال\\n"+
            "مقدار ۲۰۸/۲۵۵۹۳۸۹ گرم\\nقیمت هر گرم طرح نقره در لحظه ثبت ۴,۸۰۱,۷۸۴ ریال\\n"+
            "کارمزد ریالی تراکنش ۵,۰۰۰,۰۰۰ ریال\\nکارمزد گرمی تراکنش ۱/۰۴۱۲۷۹۷ گرم\\n"+
            "مقدار دارایی بعد از تراکنش ۲۲۱/۵۶۷۵۴ گرم\\n";
        sample=sample.replace("\\n","\n");
        AssetReceiptParser.Result d=AssetReceiptParser.parse(sample);
        assertEquals("1000000000",d.amountRial);
        assertEquals("4801784",d.unitPriceRial);
        assertEquals("5000000",d.cashFeeRial);
        assertEquals("208.2559389",d.grossQuantity);
        assertEquals("207.2146592",d.netQuantity);
        assertEquals("صندوق نقره کاریزما",d.assetType);
    }
    @Test public void karizmaReceiptOnlyImportsWhenNumbersReconcile(){
        AssetReceiptParser.Result ok=new AssetReceiptParser.Result();
        ok.assetType="صندوق نقره کاریزما";ok.hasDate=true;
        ok.amountRial="1000000000";ok.unitPriceRial="4801784";
        ok.grossQuantity="208.2559389";ok.gramFee="1.0412797";
        ok.netQuantity="207.2146592";ok.cashFeeRial="5000000";
        assertTrue(AssetReceiptParser.verifiedForAutomaticImport(ok));
        ok.unitPriceRial="4852684"; // Price from DIFFERENT purchase; should never prefill.
        assertFalse(AssetReceiptParser.verifiedForAutomaticImport(ok));
        ok.unitPriceRial="4801784";
        ok.netQuantity="221.56754"; // Entire portfolio total, not net of this purchase.
        assertFalse(AssetReceiptParser.verifiedForAutomaticImport(ok));
        ok.netQuantity="207.2146592";ok.gramFee=""; // Fee unreadable; no guessing.
        assertFalse(AssetReceiptParser.verifiedForAutomaticImport(ok));
    }
    @Test public void partialOcrCannotOverwriteFinancialPurchase(){
        AssetReceiptParser.Result bad=new AssetReceiptParser.Result();
        bad.assetType="صندوق نقره کاریزما";bad.hasDate=true;
        bad.amountRial="1000000000";bad.unitPriceRial="4801784";
        bad.netQuantity="207.2146592";
        assertFalse(AssetReceiptParser.verifiedForAutomaticImport(bad));
    }
    @Test public void karizmaRowOcrReconciliationRequiresCrossFieldProof(){
        AssetReceiptParser.Result base=new AssetReceiptParser.Result();
        base.assetType="صندوق نقره کاریزما";base.hasDate=true;
        base.jalaliYear=1405;base.jalaliMonth=8;base.jalaliDay=5;
        AssetReceiptFieldFusion.Candidates rows=new AssetReceiptFieldFusion.Candidates();
        rows.add("amount","۱,۰۰۰,۰۰۰,۰۰۰ ریال");
        rows.add("gross","۲۰۸/۲۵۵۹۳۸۹ گرم");
        rows.add("price","۴,۸۰۱,۷۸۴ ریال");
        rows.add("cashFee","۵,۰۰۰,۰۰۰ ریال");
        rows.add("gramFee","۱/۰۴۱۲۷۹۷ گرم");
        AssetReceiptParser.Result repaired=AssetReceiptFieldFusion.fuse(base,rows);
        assertTrue(AssetReceiptParser.verifiedForAutomaticImport(repaired));
        assertEquals("207.2146592",repaired.netQuantity);
        rows.price.clear();rows.price.add("4852684");
        assertFalse(AssetReceiptParser.verifiedForAutomaticImport(
                AssetReceiptFieldFusion.fuse(base,rows)));
    }
    @Test public void imageShareRouteAndModelExist(){
        Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertNotNull(c.getAssets());
        try{
            assertTrue(c.getAssets().open("tessdata/fas.traineddata").available()>10_000);
            assertTrue(c.getAssets().open("tessdata/eng.traineddata").available()>10_000);
        }catch(Exception e){throw new AssertionError(e);}
    }
}
