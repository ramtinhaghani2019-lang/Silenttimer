package com.example.silenttimer;

import static org.junit.Assert.*;
import android.content.Context;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Receipt OCR UI/parser contracts: no duplicate fee or auto-save on image selection. */
@RunWith(AndroidJUnit4.class)
public final class AssetReceiptImportRegressionTest {
    @Test public void persianKarizmaReceiptDistinguishesGrossFromNet(){
        String sample="نام ابزار: حساب با پشتوانه نقره\\n"+
            "تاریخ تراکنش ۱۴۰۵/۰۸/۰۵\\nمبلغ ۱,۰۰۰,۰۰۰,۰۰۰ ریال\\n"+
            "مقدار ۲۰۸/۲۵۵۹۳۸۹ گرم\\nقیمت هر گرم طرح نقره در لحظه ثبت ۴,۸۰۱,۷۸۴ ریال\\n"+
            "کارمزد ریالی تراکنش ۵,۰۰۰,۰۰۰ ریال\\nکارمزد گرمی تراکنش ۱/۰۴۱۲۷۹۷ گرم\\n"+
            "مقدار دارایی بعد از تراکنش ۲۲۱/۵۶۷۵۴ گرم\\n";
        sample=sample.replace("\\n","\n");
        AssetReceiptParser.Result d=AssetReceiptParser.parse(sample);
        assertEquals("1000000000",d.amountRial);
        assertEquals("4801784",d.unitPriceRial);
        assertEquals("5000000",d.cashFeeRial);
        assertEquals("208.2559389",d.grossQuantity);
        assertEquals("207.2146592",d.netQuantity);
        assertEquals("صندوق نقره کاریزما",d.assetType);
    }
    @Test public void imageShareRouteAndModelExist(){
        Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
        assertNotNull(c.getAssets());
        try{
            assertTrue(c.getAssets().open("tessdata/fas.traineddata").available()>10_000);
            assertTrue(c.getAssets().open("tessdata/eng.traineddata").available()>10_000);
        }catch(Exception e){throw new AssertionError(e);}
    }
}
