package com.example.silenttimer;

import static org.junit.Assert.*;

import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationManager;
import android.service.notification.StatusBarNotification;

import androidx.test.platform.app.InstrumentationRegistry;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class NexaRegressionTest {
    private Context context;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
    }

    @Test
    public void medicineDoseLogs_roundTripAndClear_areStable() {
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = "regression-med";
        log.scheduledAt = 1700000000000L;
        log.takenAt = 1700000300000L;

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        NexaStore.addMedicineDoseLog(context, log);

        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, "regression-med");
        assertEquals(1, saved.size());
        assertEquals(1700000300000L, saved.get(0).takenAt);

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        assertTrue(NexaStore.medicineDoseLogsFor(context, "regression-med").isEmpty());
    }

    @Test
    public void appVersion_remains5428Build50() throws Exception {
        android.content.pm.PackageInfo info = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
        assertEquals("5.4.28", info.versionName);
        assertEquals(50L, info.getLongVersionCode());
    }
    @Test
    public void medicineAlarm_buildsVisibleAlarmNotificationWithActions() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();

        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-alarm-med";
        m.name = "Regression Medicine";
        m.dose = "1 tablet";
        m.intervalHours = 8;
        m.nextDoseMillis = System.currentTimeMillis() + 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);

            Intent alarm = new Intent(context, MedicineAlarmReceiver.class);
            alarm.putExtra("id", m.id);
            new MedicineAlarmReceiver().onReceive(context, alarm);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification found = null;
            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                if (sbn.getId() == ("med" + m.id).hashCode()) {
                    found = sbn.getNotification();
                    break;
                }
            }
            assertNotNull("Medicine alarm notification must be posted", found);
            assertEquals(Notification.CATEGORY_ALARM, found.category);
            assertEquals(Notification.VISIBILITY_PUBLIC, found.visibility);
            assertNotNull("Medicine alarm must have a full-screen intent", found.fullScreenIntent);
            assertNotNull("Medicine alarm tap must open the ring screen", found.contentIntent);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel channel = nm.getNotificationChannel(MedicineAlarmReceiver.CHANNEL);
                assertNotNull("Medicine alarm channel must exist", channel);
                assertTrue("Medicine alarm channel must be HIGH importance", channel.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
                // On Android 14 the framework/emulator may report VISIBILITY_NO_OVERRIDE (-1000)
                // even when the notification itself explicitly uses VISIBILITY_PUBLIC.
                // Validate that the channel does not explicitly hide lock-screen notifications.
                assertTrue("Medicine alarm channel must not be SECRET on lock screen",
                        channel.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
            }
            assertNotNull(found.actions);
            assertEquals(3, found.actions.length);
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE)).contains(m.name));
        } finally {
            AlarmSoundPlayer.stopAll();
            ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE))
                    .cancel(("med" + m.id).hashCode());
            MedicineScheduler.cancel(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }

    @Test
    public void medicineTakenNow_updatesNextDoseFromActualCompletion() {
        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-taken-now";
        m.name = "Regression Taken Now";
        m.intervalHours = 4;
        m.nextDoseMillis = System.currentTimeMillis() - 5 * 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);
            NexaStore.clearMedicineDoseLogs(context, m.id);

            long before = System.currentTimeMillis();
            Intent taken = new Intent(context, MedicineActionReceiver.class);
            taken.setAction("TAKEN_NOW");
            taken.putExtra("id", m.id);
            new MedicineActionReceiver().onReceive(context, taken);
            long after = System.currentTimeMillis();

            NexaStore.Medicine saved = NexaStore.medicine(context, m.id);
            assertNotNull(saved);
            long interval = 4L * 60L * 60L * 1000L;
            assertTrue(saved.nextDoseMillis >= before + interval);
            assertTrue(saved.nextDoseMillis <= after + interval);
            List<NexaStore.MedicineDoseLog> logs = NexaStore.medicineDoseLogsFor(context, m.id);
            assertEquals(1, logs.size());
            assertEquals("taken_now", logs.get(0).status);
        } finally {
            MedicineScheduler.cancel(context, m.id);
            NexaStore.clearMedicineDoseLogs(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }


    @Test
    public void criticalPermissionState_canBeReadFromAndroid() {
        android.app.NotificationManager nm=(android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.AlarmManager am=(android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        android.os.PowerManager pm=(android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
        assertNotNull(nm);
        assertNotNull(am);
        assertNotNull(pm);
        if(android.os.Build.VERSION.SDK_INT>=34) { boolean ignored=nm.canUseFullScreenIntent(); }
        if(android.os.Build.VERSION.SDK_INT>=31) { boolean ignored=am.canScheduleExactAlarms(); }
        boolean ignoredBattery=pm.isIgnoringBatteryOptimizations(context.getPackageName());
    }
}
