package com.example.silenttimer;

import static org.junit.Assert.*;

import android.content.Context;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class NexaRegressionTest {
    private Context context;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
    }

    @Test
    public void medicineDoseLogs_roundTripAndClear_areStable() {
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = "regression-med";
        log.scheduledAt = 1700000000000L;
        log.takenAt = 1700000300000L;

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        NexaStore.addMedicineDoseLog(context, log);

        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, "regression-med");
        assertEquals(1, saved.size());
        assertEquals(1700000300000L, saved.get(0).takenAt);

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        assertTrue(NexaStore.medicineDoseLogsFor(context, "regression-med").isEmpty());
    }

    @Test
    public void appVersion_remains549Build31() throws Exception {
        android.content.pm.PackageInfo info = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
        assertEquals("5.4.9", info.versionName);
        assertEquals(31L, info.getLongVersionCode());
    }
}
