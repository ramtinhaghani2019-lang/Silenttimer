package com.example.silenttimer;

import static org.junit.Assert.*;

import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationManager;
import android.service.notification.StatusBarNotification;

import androidx.test.platform.app.InstrumentationRegistry;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class NexaRegressionTest {
    private Context context;

    @Test
    public void numberFormat_fullwidthInput_normalizesWithoutPrecisionLoss() {
        assertEquals("1234567890", NumberFormatUtil.toLatin("１２３４５６７８９０"));
        assertEquals("+1,234,567", NumberFormatUtil.groupIntegerText("＋１２３４５６７"));
        assertEquals("-1,234,567", NumberFormatUtil.groupIntegerText("－１２３４５６７"));
        assertEquals("+1,234.0500", NumberFormatUtil.groupDecimalText("＋１２３４．０５００"));
        assertEquals("-1,234.0500", NumberFormatUtil.groupDecimalText("－１２３４．０５００"));
        assertEquals("9,223,372,036,854,775,808", NumberFormatUtil.groupIntegerText("９２２３３７２０３６８５４７７５８０８"));
        assertEquals("1,234", NumberFormatUtil.groupIntegerText("۱۲۳۴"));
    }

    @Test
    public void numberFormat_copiedLocaleGroupingSeparators() {
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1\u202F234\u202F567"));
        assertEquals("-1,234,567", NumberFormatUtil.groupIntegerText("−1\u00A0234\u00A0567"));
        assertEquals("1,234,567.0500", NumberFormatUtil.groupDecimalText("1\u202F234\u00A0567٫۰۵۰۰"));
        assertEquals("123 4567", NumberFormatUtil.groupIntegerText("123 4567"));
        assertEquals(1234567L, NumberFormatUtil.longValue("1\u202F234\u00A0567"));
        assertEquals(1234567, NumberFormatUtil.intValue("1\u202F234\u00A0567"));
        assertEquals(1234.5, NumberFormatUtil.doubleValue("1\u202F234.5"), 0.000001);
    }

    @Test
    public void numberFormat_caretMappingAcrossLocaleSeparators() {
        assertEquals(5, NumberFormatUtil.mappedCaret("1\u202F234", "1,234", 5));
        assertEquals(5, NumberFormatUtil.mappedCaret("1\u00A0234", "1,234", 5));
        assertEquals(2, NumberFormatUtil.mappedCaret("1\u202F234", "1,234", 2));
        assertEquals(2, NumberFormatUtil.mappedCaret("1\u00A0234", "1,234", 2));
        assertEquals(1, NumberFormatUtil.mappedCaret("1\u202F234", "1,234", 1));
        assertEquals(6, NumberFormatUtil.mappedCaret("1\u202F234\u00A0567", "1,234,567", 6));
        assertEquals(9, NumberFormatUtil.mappedCaret("1\u202F234\u00A0567", "1,234,567", 9));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1\u202F234\u00A0567"));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1٬234٬567"));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1\u2009234\u2007567"));
        assertEquals("-1,234.0500", NumberFormatUtil.groupDecimalText("-1\u2009234.0500"));
        assertEquals(1234567L, NumberFormatUtil.longValue("1\u2009234\u2007567"));
        assertEquals(1234567, NumberFormatUtil.intValue("1\u2009234\u2007567"));
        assertEquals(2, NumberFormatUtil.mappedCaret("1\u2009234", "1,234", 2));
        assertEquals(5, NumberFormatUtil.mappedCaret("1\u2007234", "1,234", 5));
    }

    @Test
    public void numberFormat_intValue_saturatesBeyondLongWithoutWrapping() {
        assertEquals(Integer.MAX_VALUE, NumberFormatUtil.intValue("9,223,372,036,854,775,808"));
        assertEquals(Integer.MIN_VALUE, NumberFormatUtil.intValue("-9,223,372,036,854,775,809"));
        assertEquals(Integer.MAX_VALUE, NumberFormatUtil.intValue("۲۱۴۷۴۸۳۶۴۸"));
        assertEquals(Integer.MIN_VALUE, NumberFormatUtil.intValue("-۲۱۴۷۴۸۳۶۴۹"));
        assertEquals(2147483647, NumberFormatUtil.intValue("2,147,483,647"));
        assertEquals(-2147483648, NumberFormatUtil.intValue("-2,147,483,648"));
        assertEquals(0, NumberFormatUtil.intValue("not a number"));
    }

    @Test
    public void numberFormat_longValue_saturatesOverflowAndParsesLocalizedDigits() {
        assertEquals(Long.MAX_VALUE, NumberFormatUtil.longValue("9,223,372,036,854,775,807"));
        assertEquals(Long.MIN_VALUE, NumberFormatUtil.longValue("-9,223,372,036,854,775,808"));
        assertEquals(Long.MAX_VALUE, NumberFormatUtil.longValue("9,223,372,036,854,775,808"));
        assertEquals(Long.MIN_VALUE, NumberFormatUtil.longValue("-9,223,372,036,854,775,809"));
        assertEquals(Long.MAX_VALUE, NumberFormatUtil.longValue("۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹"));
        assertEquals(Long.MIN_VALUE, NumberFormatUtil.longValue("-９９９９９９９９９９９９９９９９９９９９９９"));
        assertEquals(1234567L, NumberFormatUtil.longValue("＋۱٬۲۳۴٬۵۶۷"));
        assertEquals(0L, NumberFormatUtil.longValue("invalid"));
    }

    @Test
    public void weather_delayedResponseMustNotReplaceDifferentSelectedCity() {
        WeatherRepository.Data d = new WeatherRepository.Data();
        d.city = "تهران";
        assertTrue(WeatherRepository.shouldSaveResult("تهران", d));
        assertFalse(WeatherRepository.shouldSaveResult("اصفهان", d));
        assertFalse(WeatherRepository.shouldSaveResult("", d));
        assertFalse(WeatherRepository.shouldSaveResult("تهران", null));
    }

    @Test
    public void weather_cacheMustMatchRequestedCityAndValidTimestamp() {
        WeatherRepository.Data d = new WeatherRepository.Data();
        d.city = "تهران";
        d.updatedAt = 1000000L;
        assertTrue(WeatherRepository.matchesCity(d, " تهران "));
        assertFalse(WeatherRepository.matchesCity(d, "اصفهان"));
        assertFalse(WeatherRepository.matchesCity(null, "تهران"));
        assertTrue(WeatherRepository.usableCache(d, 1000000L));
        assertFalse(WeatherRepository.usableCache(d, 0L));
        d.updatedAt = 0L;
        assertFalse(WeatherRepository.usableCache(d, 1000000L));
    }

    @Test
    public void weather_backgroundAlertsRequireEnabledCurrentCityAndValidForecast() {
        WeatherRepository.Data d = new WeatherRepository.Data();
        d.city = "تهران";
        d.updatedAt = System.currentTimeMillis();
        assertTrue(WeatherAlertReceiver.shouldNotifyForSelection(true," تهران ",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(false,"تهران",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"اصفهان",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"تهران",null));
        d.updatedAt = 0L;
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"تهران",d));
    }

    @Test
    public void medicineCourse_preventsAlertsAfterEndOrDisableAndBoundsRepeats() {
        NexaStore.Medicine m = new NexaStore.Medicine();
        m.active = true;
        m.nextDoseMillis = 1000L;
        m.endMillis = 2000L;
        assertTrue(MedicineScheduler.canSchedule(m, 2000L));
        assertFalse(MedicineScheduler.canSchedule(m, 2001L));
        assertFalse(MedicineScheduler.canSchedule(m, 0L));
        m.active = false;
        assertFalse(MedicineScheduler.canSchedule(m, 1500L));
        m.active = true;
        m.endMillis = 0L;
        assertTrue(MedicineScheduler.canSchedule(m, 3000L));
        assertEquals(300000L, MedicineScheduler.nextRepeatAt(0L, 0));
        assertEquals(60000L, MedicineScheduler.nextRepeatAt(0L, 1));
        assertEquals(Long.MAX_VALUE, MedicineScheduler.nextRepeatAt(Long.MAX_VALUE-1, 5));
    }

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
    }

    @Test
    public void assetFinance_karizmaPurchases_noTenfoldInflation() {
        NexaStore.AssetEntry first = new NexaStore.AssetEntry();
        first.amount = 9.34; first.buyUnitPrice = 3312000d;
        NexaStore.AssetEntry second = new NexaStore.AssetEntry();
        second.amount = 0.22; second.buyUnitPrice = 3295711.7d;
        java.util.List<NexaStore.AssetEntry> entries = java.util.Arrays.asList(first, second);
        double expected = 9.34d * 3312000d + 0.22d * 3295711.7d;
        assertEquals(expected, AssetFinanceEngine.totalOpenCost(entries), 0.01d);
        assertTrue(AssetFinanceEngine.totalOpenCost(entries) < 40000000d);
    }

    @Test
    public void financialDisplay_persianDigitsDoNotChangeRawArithmetic() {
        assertEquals("۳۵٬۰۹۶٬۰۲۴٫۵", PersianFinancialDisplay.digits("35,096,024.5"));
        assertEquals("", PersianFinancialDisplay.digits(null));
        assertEquals(9.34d*3312000d, 30934080d, 0.01d);
    }

    @Test
    public void assetSell_rejectsNonFiniteStoredValuesWithoutMutation() {
        NexaStore.AssetEntry x = new NexaStore.AssetEntry();
        x.amount=2; x.buyUnitPrice=100; x.fee=10;
        x.realizedProfit=Double.NaN;
        assertFalse(AssetFinanceEngine.sell(x,1,150,123L));
        assertEquals(2d,x.amount,0d);
        assertEquals(10d,x.fee,0d);
        x.realizedProfit=0;
        assertFalse(AssetFinanceEngine.sell(x,2,Double.MAX_VALUE,123L));
        assertEquals(2d,x.amount,0d);
        assertTrue(AssetFinanceEngine.sell(x,1,150,123L));
        assertEquals(1d,x.amount,0d);
        assertEquals(45d,x.realizedProfit,0.001d);
        assertEquals(5d,x.fee,0d);
    }

    @Test
    public void medicineDoseLogs_roundTripAndClear_areStable() {
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = "regression-med";
        log.scheduledAt = 1700000000000L;
        log.takenAt = 1700000300000L;

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        NexaStore.addMedicineDoseLog(context, log);

        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, "regression-med");
        assertEquals(1, saved.size());
        assertEquals(1700000300000L, saved.get(0).takenAt);

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        assertTrue(NexaStore.medicineDoseLogsFor(context, "regression-med").isEmpty());
    }

    @Test
    public void cryptoSymbol_normalizationAndProviderSupport() {
        assertEquals("ETH", CryptoSymbol.normalize(" eth "));
        assertEquals("USDT", CryptoSymbol.normalize("uSdT"));
        assertEquals("", CryptoSymbol.normalize("ETH/USDT"));
        assertEquals("", CryptoSymbol.normalize(null));
        java.util.Set<String> available = new java.util.HashSet<>(java.util.Arrays.asList("ETH", "USDT"));
        assertTrue(CryptoSymbol.isSupportedByProvider("eth", available));
        assertFalse(CryptoSymbol.isSupportedByProvider("DOGE", available));
        assertFalse(CryptoSymbol.isSupportedByProvider("ETH", null));
    }

    @Test
    public void financialDisplay_amountGroupingAndInvalidValues() {
        assertEquals("۳۵٬۰۹۶٬۰۲۴٫۵", PersianFinancialDisplay.amount(35096024.5d));
        assertEquals("−۱٬۲۳۴٫۵", PersianFinancialDisplay.amount(-1234.5d).replace('-', '−'));
        assertEquals("۰", PersianFinancialDisplay.amount(0d));
        assertEquals("—", PersianFinancialDisplay.amount(Double.NaN));
        assertEquals("—", PersianFinancialDisplay.amount(Double.POSITIVE_INFINITY));
    }

    @Test
    public void financialDisplay_marketAndPortfolioFormatting() {
        assertEquals("۱٬۲۳۴٬۵۶۷٫۲۵", PersianFinancialDisplay.amount(1234567.25));
        assertEquals("−۹٬۸۷۶٫۵", PersianFinancialDisplay.amount(-9876.5).replace('-', '−'));
        assertEquals("—", PersianFinancialDisplay.amount(Double.NEGATIVE_INFINITY));
        assertEquals("۰", PersianFinancialDisplay.amount(-0.0));
        assertEquals(PersianFinancialDisplay.amount(0.0), PersianFinancialDisplay.amount(-0.0));
    }

    @Test
    public void financialDisplay_exactLongAmountsAvoidFloatingPointLoss() {
        assertEquals("۹٬۰۰۷٬۱۹۹٬۲۵۴٬۷۴۰٬۹۹۳", PersianFinancialDisplay.amount(9007199254740993L));
        assertEquals("−۹٬۲۲۳٬۳۷۲٬۰۳۶٬۸۵۴٬۷۷۵٬۸۰۸", PersianFinancialDisplay.amount(Long.MIN_VALUE).replace('-', '−'));
        assertEquals("۰", PersianFinancialDisplay.amount(0L));
        assertEquals("۱٬۲۳۴", PersianFinancialDisplay.amount(1234L));
    }

    @Test
    public void numberFormat_groupIntegerText_preservesHugeExactValues() {
        assertEquals("9,223,372,036,854,775,808", NumberFormatUtil.groupIntegerText("9223372036854775808"));
        assertEquals("-9,223,372,036,854,775,809", NumberFormatUtil.groupIntegerText("-9223372036854775809"));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("۱۲۳۴۵۶۷"));
        assertEquals("0", NumberFormatUtil.groupIntegerText("-000"));
        assertEquals("1,234", NumberFormatUtil.groupIntegerText("001234"));
        assertEquals("-", NumberFormatUtil.groupIntegerText("-"));
    }

    @Test
    public void numberFormat_caretRemainsNearEditedDigit() {
        assertEquals(3, NumberFormatUtil.mappedCaret("1234", "1,234", 2));
        assertEquals(4, NumberFormatUtil.mappedCaret("1234", "1,234", 3));
        assertEquals(5, NumberFormatUtil.mappedCaret("1234", "1,234", 4));
        assertEquals(2, NumberFormatUtil.mappedCaret("1,234", "1234", 3));
        assertEquals(0, NumberFormatUtil.mappedCaret("1234", "1,234", 0));
        assertEquals(7, NumberFormatUtil.mappedCaret("1234.56", "1,234.56", 6));
        assertEquals(1, NumberFormatUtil.mappedCaret("1234", "1,234", 1));
        assertEquals(3, NumberFormatUtil.mappedCaret("1,234", "1234", 4));
    }

    @Test
    public void numberFormat_groupDecimalText_preservesExactFractionAndLargeIntegers() {
        assertEquals("9,223,372,036,854,775,808.123456789", NumberFormatUtil.groupDecimalText("9223372036854775808.123456789"));
        assertEquals("1,234.0500", NumberFormatUtil.groupDecimalText("۱۲۳۴٫۰۵۰۰"));
        assertEquals("-1,234.5", NumberFormatUtil.groupDecimalText("-١٢٣٤.٥"));
        assertEquals("0.00", NumberFormatUtil.groupDecimalText("-000.00"));
        assertEquals("-0.01", NumberFormatUtil.groupDecimalText("-000.01"));
        assertEquals("1,234.", NumberFormatUtil.groupDecimalText("1234."));
        assertEquals("-.", NumberFormatUtil.groupDecimalText("-."));
        assertEquals("12..3", NumberFormatUtil.groupDecimalText("12..3"));
    }

    @Test
    public void numberFormat_explicitPositiveSignPreservesExactDigits() {
        assertEquals("+1,234,567", NumberFormatUtil.groupIntegerText("+۰۰۱۲۳۴۵۶۷"));
        assertEquals("0", NumberFormatUtil.groupIntegerText("+000"));
        assertEquals("+1,234.0500", NumberFormatUtil.groupDecimalText("+۱۲۳۴٫۰۵۰۰"));
        assertEquals("0.00", NumberFormatUtil.groupDecimalText("+000.00"));
        assertEquals("+0.01", NumberFormatUtil.groupDecimalText("+000.01"));
        assertEquals("+.", NumberFormatUtil.groupDecimalText("+."));
        assertEquals("+", NumberFormatUtil.groupDecimalText("+"));
    }

    @Test
    public void appVersion_is54121Build143() throws Exception {
        android.content.pm.PackageInfo info = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
        assertEquals("5.4.121", info.versionName);
        assertEquals(143L, info.getLongVersionCode());
    }

    @Test
    public void medicineSkippedDose_roundTripsAsExplicitMissedDose() {
        String id = "regression-skipped-med";
        NexaStore.clearMedicineDoseLogs(context, id);
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = id;
        log.scheduledAt = 1700000000000L;
        log.takenAt = 0L;
        log.status = "skipped";
        NexaStore.addMedicineDoseLog(context, log);
        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, id);
        assertEquals(1, saved.size());
        assertEquals("skipped", saved.get(0).status);
        assertEquals(0L, saved.get(0).takenAt);
        NexaStore.clearMedicineDoseLogs(context, id);
    }

    @Test
    public void vaultDefaultGroups_doNotExposeEmailCategory() {
        String joined = java.util.Arrays.toString(NexaStore.defaultVaultGroups());
        assertFalse(joined.contains("ایمیل"));
        assertTrue(joined.contains("بانک"));
        assertTrue(joined.contains("سایت"));
    }

    @Test
    public void audioController_priorityOrderAndRingerModes_areStable() {
        assertTrue(NexaAudioController.PRIORITY_THEFT > NexaAudioController.PRIORITY_SECURITY);
        assertTrue(NexaAudioController.PRIORITY_SECURITY > NexaAudioController.PRIORITY_BATTERY);
        assertTrue(NexaAudioController.PRIORITY_BATTERY > NexaAudioController.PRIORITY_MEDICINE);
        assertTrue(NexaAudioController.PRIORITY_MEDICINE > NexaAudioController.PRIORITY_REMINDER);
        assertTrue(NexaAudioController.PRIORITY_REMINDER > NexaAudioController.PRIORITY_NORMAL);
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_NORMAL));
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_SILENT));
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_VIBRATE));
        assertFalse(NexaAudioController.isSupportedRingerMode(99));
        NexaAudioController.stopAll();
        assertEquals(0, NexaAudioController.getActivePriority());
        assertEquals("", NexaAudioController.getActiveOwner());
    }


    @Test
    public void silentTimer_previousRingerMode_roundTripsAndClears() {
        AppPrefs.clearTimer(context);
        AppPrefs.setTimerPreviousRingerMode(context, android.media.AudioManager.RINGER_MODE_VIBRATE);
        assertTrue(AppPrefs.hasTimerPreviousRingerMode(context));
        assertEquals(android.media.AudioManager.RINGER_MODE_VIBRATE,
                AppPrefs.getTimerPreviousRingerMode(context));
        AppPrefs.clearTimer(context);
        assertFalse(AppPrefs.hasTimerPreviousRingerMode(context));
    }

    @Test
    public void audioController_currentRingerMode_isAlwaysSupported() {
        int mode = NexaAudioController.getRingerMode(context);
        assertTrue(NexaAudioController.isSupportedRingerMode(mode));
    }

    @Test
    public void notificationEngine_blocksImmediateDuplicateDelivery() {
        String key = "regression-duplicate-" + System.nanoTime();
        assertTrue(NexaNotificationEngine.acquireDelivery(context, key));
        assertFalse(NexaNotificationEngine.acquireDelivery(context, key));
    }

    @Test
    public void medicineAlarm_buildsVisibleAlarmNotificationWithActions() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();

        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-alarm-med";
        m.name = "Regression Medicine";
        m.dose = "1 tablet";
        m.intervalHours = 8;
        m.nextDoseMillis = System.currentTimeMillis() + 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);

            Intent alarm = new Intent(context, MedicineAlarmReceiver.class);
            alarm.putExtra("id", m.id);
            new MedicineAlarmReceiver().onReceive(context, alarm);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification found = null;
            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                if (sbn.getId() == ("med" + m.id).hashCode()) {
                    found = sbn.getNotification();
                    break;
                }
            }
            assertNotNull("Medicine alarm notification must be posted", found);
            assertEquals(Notification.CATEGORY_ALARM, found.category);
            assertEquals(Notification.VISIBILITY_PUBLIC, found.visibility);
            assertNotNull("Medicine alarm must have a full-screen intent", found.fullScreenIntent);
            assertNotNull("Medicine alarm tap must open the ring screen", found.contentIntent);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel channel = nm.getNotificationChannel(MedicineAlarmReceiver.CHANNEL);
                assertNotNull("Medicine alarm channel must exist", channel);
                assertTrue("Medicine alarm channel must be HIGH importance", channel.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
                // On Android 14 the framework/emulator may report VISIBILITY_NO_OVERRIDE (-1000)
                // even when the notification itself explicitly uses VISIBILITY_PUBLIC.
                // Validate that the channel does not explicitly hide lock-screen notifications.
                assertTrue("Medicine alarm channel must not be SECRET on lock screen",
                        channel.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
            }
            assertNotNull(found.actions);
            // 5.4.48 adds a dedicated "Stop sound" action in addition to the
            // existing medicine actions. Keep this regression aligned with the
            // intended four-action notification contract.
            assertEquals(4, found.actions.length);
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE)).contains(m.name));
        } finally {
            AlarmSoundPlayer.stopAll();
            ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE))
                    .cancel(("med" + m.id).hashCode());
            MedicineScheduler.cancel(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }

    @Test
    public void medicineTakenNow_updatesNextDoseFromActualCompletion() {
        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-taken-now";
        m.name = "Regression Taken Now";
        m.intervalHours = 4;
        m.nextDoseMillis = System.currentTimeMillis() - 5 * 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);
            NexaStore.clearMedicineDoseLogs(context, m.id);

            long before = System.currentTimeMillis();
            Intent taken = new Intent(context, MedicineActionReceiver.class);
            taken.setAction("TAKEN_NOW");
            taken.putExtra("id", m.id);
            new MedicineActionReceiver().onReceive(context, taken);
            long after = System.currentTimeMillis();

            NexaStore.Medicine saved = NexaStore.medicine(context, m.id);
            assertNotNull(saved);
            long interval = 4L * 60L * 60L * 1000L;
            assertTrue(saved.nextDoseMillis >= before + interval);
            assertTrue(saved.nextDoseMillis <= after + interval);
            List<NexaStore.MedicineDoseLog> logs = NexaStore.medicineDoseLogsFor(context, m.id);
            assertEquals(1, logs.size());
            assertEquals("taken_now", logs.get(0).status);
        } finally {
            MedicineScheduler.cancel(context, m.id);
            NexaStore.clearMedicineDoseLogs(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }


    @Test
    public void medicineStats_countsTakenSkippedAndMissedWithoutMutatingData() {
        NexaStore.Medicine m=new NexaStore.Medicine();
        long hour=60L*60L*1000L, now=1700000000000L;
        m.firstDoseMillis=now-12*hour; m.intervalHours=4; m.endMillis=0;
        java.util.ArrayList<NexaStore.MedicineDoseLog> logs=new java.util.ArrayList<>();
        NexaStore.MedicineDoseLog a=new NexaStore.MedicineDoseLog();a.scheduledAt=m.firstDoseMillis;a.takenAt=a.scheduledAt;a.status="taken_on_time";logs.add(a);
        NexaStore.MedicineDoseLog b=new NexaStore.MedicineDoseLog();b.scheduledAt=m.firstDoseMillis+4*hour;b.status="skipped";b.takenAt=0;logs.add(b);
        NexaStore.MedicineDoseLog c=new NexaStore.MedicineDoseLog();c.scheduledAt=m.firstDoseMillis+8*hour;c.takenAt=c.scheduledAt+10*60_000L;c.status="taken_now";logs.add(c);
        MedicineStats.Summary x=MedicineStats.summarize(m,logs,now,7);
        assertEquals(4,x.scheduled); assertEquals(2,x.taken); assertEquals(1,x.onTime); assertEquals(1,x.late); assertEquals(1,x.skipped); assertEquals(2,x.missed); assertEquals(50,x.adherencePercent());
    }

    @Test
    public void criticalPermissionState_canBeReadFromAndroid() {
        android.app.NotificationManager nm=(android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.AlarmManager am=(android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        android.os.PowerManager pm=(android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
        assertNotNull(nm);
        assertNotNull(am);
        assertNotNull(pm);
        if(android.os.Build.VERSION.SDK_INT>=34) { boolean ignored=nm.canUseFullScreenIntent(); }
        if(android.os.Build.VERSION.SDK_INT>=31) { boolean ignored=am.canScheduleExactAlarms(); }
        boolean ignoredBattery=pm.isIgnoringBatteryOptimizations(context.getPackageName());
    }

    @Test
    public void missedCallGuard_ringingThenIdle_postsVisibleLockScreenNotification() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        long permissionDeadline = System.currentTimeMillis() + 2000L;
        while (android.os.Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
                && System.currentTimeMillis() < permissionDeadline) {
            Thread.sleep(50L);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                    context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS));
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        boolean oldShowName = AppPrefs.isMissedCallShowName(context);
        boolean oldShowNumber = AppPrefs.isMissedCallShowNumber(context);
        boolean oldShowTime = AppPrefs.isMissedCallShowTime(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            AppPrefs.setMissedCallShowName(context, false);
            AppPrefs.setMissedCallShowNumber(context, true);
            AppPrefs.setMissedCallShowTime(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);

            String number = "+15551234567";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, number);

            Notification found = null;
            long notificationDeadline = System.currentTimeMillis() + 2500L;
            while (found == null && System.currentTimeMillis() < notificationDeadline) {
                for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                    if (sbn.getId() == NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID) {
                        found = sbn.getNotification();
                        break;
                    }
                }
                if (found == null) Thread.sleep(50L);
            }
            assertNotNull("Missed-call guard must post a notification", found);
            assertEquals(Notification.CATEGORY_CALL, found.category);
            assertEquals(Notification.VISIBILITY_PUBLIC, found.visibility);
            assertNotNull("Missed-call notification must carry a full-screen lock card intent", found.fullScreenIntent);
            assertTrue("Missed-call notification must expose Call/Clear actions", found.actions != null && found.actions.length >= 2);
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE))
                    .contains("تماس از دست‌رفته"));
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TEXT))
                    .contains(number));
            assertEquals(1, MissedCallGuard.getUnviewedCount(context));
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel channel = nm.getNotificationChannel(
                        NexaNotificationEngine.MISSED_CALL_CHANNEL);
                assertNotNull(channel);
                assertTrue(channel.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
                assertTrue(channel.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
            }
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
            AppPrefs.setMissedCallShowName(context, oldShowName);
            AppPrefs.setMissedCallShowNumber(context, oldShowNumber);
            AppPrefs.setMissedCallShowTime(context, oldShowTime);
        }
    }

    @Test
    public void missedCallGuard_answeredCall_doesNotPostMissedNotification() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        long permissionDeadline = System.currentTimeMillis() + 2000L;
        while (android.os.Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
                && System.currentTimeMillis() < permissionDeadline) {
            Thread.sleep(50L);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                    context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS));
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            String number = "+15557654321";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_OFFHOOK, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, number);

            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                assertNotEquals(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID, sbn.getId());
            }
            assertEquals(0, MissedCallGuard.getUnviewedCount(context));
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
        }
    }

    @Test
    public void missedCallGuard_multipleMissedCalls_updatesCountAndVisibleList() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        boolean oldShowName = AppPrefs.isMissedCallShowName(context);
        boolean oldShowNumber = AppPrefs.isMissedCallShowNumber(context);
        boolean oldShowTime = AppPrefs.isMissedCallShowTime(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            AppPrefs.setMissedCallShowName(context, false);
            AppPrefs.setMissedCallShowNumber(context, true);
            AppPrefs.setMissedCallShowTime(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

            String first = "+15550000001";
            String second = "+15550000002";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, first);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, first);
            Thread.sleep(50L);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, second);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, second);

            // NotificationManager replacement is asynchronous on the emulator. Do not
            // accept the stale first-call notification while the second missed call has
            // already been persisted; wait until the visible notification reflects both.
            Notification found = null;
            long deadline = System.currentTimeMillis() + 4000L;
            while (System.currentTimeMillis() < deadline) {
                Notification candidate = null;
                for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                    if (sbn.getId() == NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID) {
                        candidate = sbn.getNotification();
                        break;
                    }
                }
                if (candidate != null) {
                    String candidateTitle = String.valueOf(candidate.extras.getCharSequence(Notification.EXTRA_TITLE));
                    String candidateBig = String.valueOf(candidate.extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
                    if (candidateTitle.contains("2") && candidateBig.contains(first) && candidateBig.contains(second)) {
                        found = candidate;
                        break;
                    }
                }
                Thread.sleep(50L);
            }
            assertEquals(2, MissedCallGuard.getUnviewedCount(context));
            assertNotNull("Updated missed-call notification must show both calls", found);
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
            AppPrefs.setMissedCallShowName(context, oldShowName);
            AppPrefs.setMissedCallShowNumber(context, oldShowNumber);
            AppPrefs.setMissedCallShowTime(context, oldShowTime);
        }
    }

    @Test
    public void missedCallGuard_recentListCapacity_supportsSeveralCalls() {
        assertTrue("Lock-screen list must retain several missed calls", MissedCallGuard.recentCallCapacity() >= 8);
    }

    @Test
    public void notificationEngine_coreChannels_arePublicAndSeparated() {
        NotificationChannelHelper.ensureCoreChannels(context);
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        String[] ids = new String[]{
                NotificationChannelHelper.CHANNEL_MISSED_CALL,
                NotificationChannelHelper.CHANNEL_REMINDER,
                NotificationChannelHelper.CHANNEL_BATTERY_ALARM,
                NotificationChannelHelper.CHANNEL_LOW_BATTERY,
                NotificationChannelHelper.CHANNEL_THEFT_ALARM,
                NotificationChannelHelper.CHANNEL_SECURITY
        };
        java.util.HashSet<String> unique = new java.util.HashSet<>();
        for (String id : ids) {
            assertTrue(unique.add(id));
            android.app.NotificationChannel ch = nm.getNotificationChannel(id);
            assertNotNull("Core Nexa channel must exist: " + id, ch);
            assertTrue(ch.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
            assertTrue(ch.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
        }
    }



    @Test
    public void caseDirectories_roundTripWithoutDuplicates() {
        NexaStore.addCourt(context, "دادگاه تست ۴۳");
        NexaStore.addCourt(context, "دادگاه تست ۴۳");
        NexaStore.addLawyer(context, "وکیل تست ۴۳");
        assertTrue(NexaStore.courts(context).contains("دادگاه تست ۴۳"));
        assertTrue(NexaStore.lawyers(context).contains("وکیل تست ۴۳"));
        int count = 0; for (String x : NexaStore.courts(context)) if ("دادگاه تست ۴۳".equals(x)) count++;
        assertEquals(1, count);
    }

    @Test
    public void removedThemeEngine_isNotPresentInRuntimePackage() throws Exception {
        try { Class.forName("com.example.silenttimer.ThemeManager"); fail("ThemeManager must remain removed"); }
        catch (ClassNotFoundException expected) { assertTrue(true); }
    }

    @Test
    public void emergencyContactLabels_haveSafeDefaultsAndRoundTrip() {
        NexaStore.setEmergencyLabel1(context, "مادر");
        NexaStore.setEmergencyLabel2(context, "پدر");
        assertEquals("مادر", NexaStore.emergencyLabel1(context));
        assertEquals("پدر", NexaStore.emergencyLabel2(context));
        NexaStore.setEmergencyLabel1(context, "");
        NexaStore.setEmergencyLabel2(context, "");
        assertEquals("مادر", NexaStore.emergencyLabel1(context));
        assertEquals("پدر", NexaStore.emergencyLabel2(context));
    }
    @Test
    public void batteryAlertSettings_roundTripAndClamp() {
        AppPrefs.setChargeAlarmThreshold(context, 95); assertEquals(95, AppPrefs.getChargeAlarmThreshold(context));
        AppPrefs.setLowBatteryThreshold(context, 10); assertEquals(10, AppPrefs.getLowBatteryThreshold(context));
        AppPrefs.setChargeAlarmThreshold(context, 150); assertEquals(100, AppPrefs.getChargeAlarmThreshold(context));
        AppPrefs.setLowBatteryThreshold(context, -2); assertEquals(1, AppPrefs.getLowBatteryThreshold(context));
        assertTrue(BatteryAlertManager.CHARGE_ID != BatteryAlertManager.LOW_ID);
    }

    @Test
    public void theftGuard_settingsAndPriority_areStable() {
        AppPrefs.setTheftGuardEnabled(context, true);
        assertTrue(AppPrefs.isTheftGuardEnabled(context));
        AppPrefs.setTheftAlarmActive(context, true);
        assertTrue(AppPrefs.isTheftAlarmActive(context));
        AppPrefs.setTheftLastPlugged(context, true);
        assertTrue(AppPrefs.isTheftPlugStateKnown(context));
        assertTrue(AppPrefs.getTheftLastPlugged(context));
        assertEquals(NexaAudioController.PRIORITY_THEFT, 100);
        assertEquals("theft_guard", TheftGuardManager.OWNER);
        assertTrue(TheftGuardManager.NOTIFICATION_ID != BatteryAlertManager.CHARGE_ID);
        assertTrue(TheftGuardManager.NOTIFICATION_ID != BatteryAlertManager.LOW_ID);
        TheftGuardManager.stop(context);
        assertFalse(AppPrefs.isTheftAlarmActive(context));
        AppPrefs.setTheftGuardEnabled(context, false);
        AppPrefs.clearTheftPlugState(context);
    }


    @Test
    public void audioController_hasDistinctProfilesAndMedicineDebounce() {
        assertTrue(NexaAudioController.SOUND_ALARM != NexaAudioController.SOUND_REMINDER);
        assertTrue(NexaAudioController.SOUND_REMINDER != NexaAudioController.SOUND_BATTERY);
        assertTrue(NexaAudioController.SAME_OWNER_DEBOUNCE_MS >= 10_000L);
        assertTrue(NexaAudioController.PRIORITY_MEDICINE > NexaAudioController.PRIORITY_REMINDER);
    }

    @Test
    public void recurringReminder_doneAdvancesAndStaysActive() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=System.currentTimeMillis()-8L*24L*60L*60L*1000L;
        r.recurrence="weekly";
        long now=System.currentTimeMillis();
        assertTrue(ReminderRecurrence.advanceAfterDone(r,now));
        assertTrue(r.whenMillis>now);
        assertTrue(r.active);
        assertFalse(r.done);
    }

    @Test
    public void oneTimeReminder_doneDoesNotAdvance() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=System.currentTimeMillis()-1000L;
        r.recurrence="none";
        long before=r.whenMillis;
        assertFalse(ReminderRecurrence.advanceAfterDone(r,System.currentTimeMillis()));
        assertEquals(before,r.whenMillis);
    }

    @Test
    public void batteryAndReminderChannels_areSeparated() {
        assertFalse(NotificationChannelHelper.CHANNEL_BATTERY_ALARM.equals(ReminderScheduler.CHANNEL));
        assertFalse(NotificationChannelHelper.CHANNEL_LOW_BATTERY.equals(ReminderScheduler.CHANNEL));
        assertFalse(MedicineAlarmReceiver.CHANNEL.equals(ReminderScheduler.CHANNEL));
    }

    @Test
    public void ledger_partiesAndBalanceRoundTrip() {
        NexaStore.LedgerParty p = new NexaStore.LedgerParty(); p.name="احمدی تست ۴۹"; NexaStore.upsertLedgerParty(context,p);
        NexaStore.LedgerEntry debt=new NexaStore.LedgerEntry(); debt.partyId=p.id; debt.kind="DEBT"; debt.amount=5_000_000L; NexaStore.addLedgerEntry(context,debt);
        NexaStore.LedgerEntry pay=new NexaStore.LedgerEntry(); pay.partyId=p.id; pay.kind="PAYMENT"; pay.amount=2_000_000L; NexaStore.addLedgerEntry(context,pay);
        assertEquals(-3_000_000L,NexaStore.ledgerBalance(context,p.id));
        assertEquals(2,NexaStore.ledgerEntriesFor(context,p.id).size());
        NexaStore.removeLedgerEntry(context,debt.id); NexaStore.removeLedgerEntry(context,pay.id); NexaStore.removeLedgerParty(context,p.id);
    }

    @Test
    public void notificationEngine_priorityContract_isStable() {
        assertTrue(NexaNotificationEngine.PRIORITY_THEFT > NexaNotificationEngine.PRIORITY_SECURITY);
        assertTrue(NexaNotificationEngine.PRIORITY_SECURITY > NexaNotificationEngine.PRIORITY_BATTERY);
        assertTrue(NexaNotificationEngine.PRIORITY_BATTERY > NexaNotificationEngine.PRIORITY_MEDICINE);
        assertTrue(NexaNotificationEngine.PRIORITY_MEDICINE > NexaNotificationEngine.PRIORITY_REMINDER);
        assertEquals(NexaNotificationEngine.PRIORITY_THEFT, NexaNotificationEngine.priorityForChannel(NotificationChannelHelper.CHANNEL_THEFT_ALARM));
        assertEquals(NexaNotificationEngine.PRIORITY_BATTERY, NexaNotificationEngine.priorityForChannel(NotificationChannelHelper.CHANNEL_LOW_BATTERY));
        assertEquals(NexaNotificationEngine.PRIORITY_REMINDER, NexaNotificationEngine.priorityForChannel(NotificationChannelHelper.CHANNEL_REMINDER));
    }

    @Test
    public void notificationEngine_coreChannels_areCreated() {
        NexaNotificationEngine.ensureChannels(context);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm=(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_REMINDER));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_BATTERY_ALARM));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_THEFT_ALARM));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_SECURITY));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_MEDICINE_CONTROL));
        }
    }

    @Test
    public void ledger_deletePartyCascadesEntries() {
        NexaStore.LedgerParty p=new NexaStore.LedgerParty(); p.name="حذف آبشاری تست ۵۳"; NexaStore.upsertLedgerParty(context,p);
        NexaStore.LedgerEntry x=new NexaStore.LedgerEntry(); x.partyId=p.id; x.amount=123456L; x.kind="DEBT"; NexaStore.addLedgerEntry(context,x);
        assertEquals(1,NexaStore.ledgerEntriesFor(context,p.id).size());
        NexaStore.removeLedgerParty(context,p.id);
        assertEquals(0,NexaStore.ledgerEntriesFor(context,p.id).size());
    }

    @Test
    public void ledger_dueMillisRoundTrip() {
        NexaStore.LedgerParty p=new NexaStore.LedgerParty(); p.name="موعد تست ۵۳"; NexaStore.upsertLedgerParty(context,p);
        NexaStore.LedgerEntry x=new NexaStore.LedgerEntry(); x.partyId=p.id; x.amount=1000; x.dueMillis=System.currentTimeMillis()+86400000L; NexaStore.addLedgerEntry(context,x);
        assertEquals(x.dueMillis,NexaStore.ledgerEntriesFor(context,p.id).get(0).dueMillis);
        NexaStore.removeLedgerParty(context,p.id);
    }

    @Test
    public void marketSnapshotValidation_rejectsZeroNanAndPartialData() {
        assertTrue(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(0,300000,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,Double.NaN,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,Double.POSITIVE_INFINITY,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,0));
    }

    @Test
    public void marketSourceMetadata_roundTrips() {
        NexaStore.setMarketSources(context,"metals-test","fx-test");
        assertEquals("metals-test",NexaStore.marketMetalsSource(context));
        assertEquals("fx-test",NexaStore.marketFxSource(context));
    }

    @Test
    public void marketSnapshotValidation_rejectsImplausibleOutliers() {
        assertFalse(MarketDataHelper.isValidIranSnapshot(99,300000,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,0.5,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,0.01));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,11));
    }

    @Test
    public void marketAttemptMetadata_roundTrips() {
        NexaStore.setMarketLastAttempt(context,1700000000000L,false);
        assertEquals(1700000000000L,NexaStore.marketLastAttempt(context));
        assertFalse(NexaStore.marketLastAttemptOk(context));
        NexaStore.setMarketLastAttempt(context,1700000001000L,true);
        assertTrue(NexaStore.marketLastAttemptOk(context));
    }


    @Test
    public void assetPriceAlert_fieldsRoundTrip() {
        java.util.List<NexaStore.AssetEntry> original=NexaStore.assets(context);
        try {
            NexaStore.AssetEntry x=new NexaStore.AssetEntry();x.type="دلار";x.amount=1;x.buyUnitPrice=90000;x.currentUnitPrice=95000;x.alertTarget=100000;x.alertDirection="up";x.alertAtBuy=true;x.alertLastNotifiedAt=12345L;x.lastAlertObservedPrice=94000;
            java.util.List<NexaStore.AssetEntry> one=new java.util.ArrayList<>();one.add(x);NexaStore.saveAssets(context,one);
            NexaStore.AssetEntry y=NexaStore.assets(context).get(0);assertEquals("up",y.alertDirection);assertEquals(100000d,y.alertTarget,0.01);assertTrue(y.alertAtBuy);assertEquals(12345L,y.alertLastNotifiedAt);assertEquals(94000d,y.lastAlertObservedPrice,0.01);
        } finally {NexaStore.saveAssets(context,original);}
    }

    @Test
    public void assetMarketEngine_mapsIranPricesOnly() {
        NexaStore.setIranMarketSnapshot(context,91000,106000,11200000,14933333,4200,120000000,110000000,62000000,36000000,18000000,System.currentTimeMillis());
        assertEquals(91000d,AssetMarketEngine.marketPrice(context,"دلار"),0.01);assertEquals(11200000d,AssetMarketEngine.marketPrice(context,"طلای ۱۸ عیار"),0.01);assertEquals(14933333d,AssetMarketEngine.marketPrice(context,"طلای ۲۴ عیار"),0.01);assertEquals(0d,AssetMarketEngine.marketPrice(context,"سهام / بورس"),0.01);
    }

    @Test
    public void assetFinance_partialSale_preservesOpenPositionAndRealizedProfit() {
        NexaStore.AssetEntry x=new NexaStore.AssetEntry();x.amount=10;x.buyUnitPrice=100;x.currentUnitPrice=130;x.fee=100;
        assertTrue(AssetFinanceEngine.sell(x,4,150,1700000000000L));
        assertEquals(6d,x.amount,0.0001);assertEquals(4d,x.soldAmount,0.0001);
        assertEquals(160d,x.realizedProfit,0.0001);assertEquals(60d,x.fee,0.0001);
        assertEquals(660d,AssetFinanceEngine.openCost(x),0.0001);
        assertEquals(120d,AssetFinanceEngine.unrealizedProfit(x),0.0001);
    }

    @Test
    public void assetFinance_rejectsOversellAndCalculatesPortfolioTotals() {
        NexaStore.AssetEntry x=new NexaStore.AssetEntry();x.amount=2;x.buyUnitPrice=100;x.currentUnitPrice=125;
        assertFalse(AssetFinanceEngine.sell(x,3,130,System.currentTimeMillis()));
        java.util.List<NexaStore.AssetEntry> list=new java.util.ArrayList<>();list.add(x);
        assertEquals(200d,AssetFinanceEngine.totalOpenCost(list),0.0001);
        assertEquals(250d,AssetFinanceEngine.totalMarketValue(list),0.0001);
        assertEquals(50d,AssetFinanceEngine.totalProfit(list),0.0001);
    }
    @Test
    public void iranMarketHistory_roundTripsAndPreservesValues(){
        NexaStore.clearMarketHistory(context);long t=System.currentTimeMillis();
        NexaStore.recordIranMarketHistory(context,t,100000,120000,7000000,9300000,2600,80000000,70000000,45000000,25000000,12000000);
        List<NexaStore.MarketHistoryPoint> h=NexaStore.marketHistory(context);assertEquals(1,h.size());assertEquals(100000d,h.get(0).usd,0.01);assertEquals(7000000d,h.get(0).gold18,0.01);assertEquals(2600d,h.get(0).ounce,0.01);NexaStore.clearMarketHistory(context);
    }

    @Test
    public void reminderRecurrence_advancesPastOccurrencesIntoFuture() {
        long now=1700000000000L;
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=now-20L*24L*60L*60L*1000L;
        r.recurrence="weekly"; r.done=true; r.active=false;
        assertTrue(ReminderRecurrence.advanceAfterDone(r,now));
        assertTrue(r.whenMillis>now);
        assertFalse(r.done);
        assertTrue(r.active);
    }

    @Test
    public void reminderRecurrence_none_doesNotMutateOneTimeReminder() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=1700000000000L; r.recurrence="none"; r.done=false; r.active=true;
        assertFalse(ReminderRecurrence.advanceAfterDone(r,1700000100000L));
        assertEquals(1700000000000L,r.whenMillis);
        assertFalse(r.done);
        assertTrue(r.active);
    }

    @Test
    public void vaultCustomGroup_renameAndDelete_preserveEntries() {
        java.util.List<NexaStore.VaultEntry> original=NexaStore.vault(context);
        try {
            NexaStore.addVaultGroup(context,"Regression Vault Group");
            NexaStore.VaultEntry x=new NexaStore.VaultEntry();x.type="Regression Vault Group";x.title="Regression Secret";NexaStore.addVault(context,x);
            assertTrue(NexaStore.renameVaultGroup(context,"Regression Vault Group","Regression Vault Renamed"));
            boolean renamed=false;for(NexaStore.VaultEntry e:NexaStore.vault(context))if(x.id.equals(e.id)){renamed=true;assertEquals("Regression Vault Renamed",e.type);}assertTrue(renamed);
            assertTrue(NexaStore.removeVaultGroup(context,"Regression Vault Renamed","سایر"));
            boolean moved=false;for(NexaStore.VaultEntry e:NexaStore.vault(context))if(x.id.equals(e.id)){moved=true;assertEquals("سایر",e.type);}assertTrue(moved);
        } finally {NexaStore.replaceVault(context,original);}
    }

    @Test
    public void vaultEntry_updatedAt_roundTrips() {
        java.util.List<NexaStore.VaultEntry> original=NexaStore.vault(context);
        try {NexaStore.VaultEntry x=new NexaStore.VaultEntry();x.title="Timestamp";x.updatedAt=1700000000123L;java.util.List<NexaStore.VaultEntry> one=new java.util.ArrayList<>();one.add(x);NexaStore.replaceVault(context,one);assertEquals(1700000000123L,NexaStore.vault(context).get(0).updatedAt);} finally {NexaStore.replaceVault(context,original);}
    }


    @Test
    public void batteryThreshold_crossingAndThreePercentRearm_areStable() {
        assertTrue(BatteryAlertManager.shouldTriggerCharge(true,true,80,80,false));
        assertFalse(BatteryAlertManager.shouldTriggerCharge(true,true,80,80,true));
        assertFalse(BatteryAlertManager.shouldRearmCharge(78,80));
        assertTrue(BatteryAlertManager.shouldRearmCharge(76,80));
        assertTrue(BatteryAlertManager.shouldTriggerLow(true,false,15,15,false));
        assertFalse(BatteryAlertManager.shouldTriggerLow(true,true,15,15,false));
        assertFalse(BatteryAlertManager.shouldRearmLow(false,17,15));
        assertTrue(BatteryAlertManager.shouldRearmLow(false,18,15));
    }

    @Test
    public void batteryAndTheft_priorityContract_isStable() {
        assertTrue(NexaAudioController.PRIORITY_THEFT > NexaAudioController.PRIORITY_SECURITY);
        assertTrue(NexaAudioController.PRIORITY_SECURITY > NexaAudioController.PRIORITY_BATTERY);
        assertEquals("nexa_battery_alarm_v3", NotificationChannelHelper.CHANNEL_BATTERY_ALARM);
        assertEquals("nexa_low_battery_v2", NotificationChannelHelper.CHANNEL_LOW_BATTERY);
        assertEquals("nexa_theft_alarm_v1", NotificationChannelHelper.CHANNEL_THEFT_ALARM);
    }
    @Test public void weatherCode_labelsAreStable(){ assertEquals("صاف",WeatherRepository.label(0)); assertEquals("بارانی",WeatherRepository.label(61)); assertEquals("برفی",WeatherRepository.label(73)); assertEquals("رعدوبرق",WeatherRepository.label(95)); }
    @Test public void weatherCache_roundTrips(){ WeatherRepository.Data d=new WeatherRepository.Data();d.city="تهران";d.temp=22.5;d.source="Regression";d.updatedAt=1700000000000L;WeatherRepository.save(context,d);WeatherRepository.Data x=WeatherRepository.cached(context);assertNotNull(x);assertEquals("تهران",x.city);assertEquals(22.5,x.temp,0.01); }


    @Test
    public void unifiedUi_touchTargetsMeetAccessibilityMinimum() {
        android.widget.Button primary = UiKit.primaryButton(context, "ذخیره");
        android.widget.Button secondary = UiKit.secondaryButton(context, "ویرایش");
        android.widget.Button icon = UiKit.editIconButton(context);
        int min = UiKit.dp(context, 48);
        assertTrue(primary.getMinimumHeight() >= min);
        assertTrue(secondary.getMinimumHeight() >= min);
        assertTrue(icon.getMinimumHeight() >= min);
        assertTrue(icon.getMinimumWidth() >= min);
    }
    @Test
    public void portableBackup_roundTrip_preservesCoreDataAndLocalVault() {
        String originalBackup = NexaStore.exportJson(context);
        java.util.List<NexaStore.VaultEntry> originalVault = NexaStore.vault(context);
        try {
            NexaStore.setSecurityAutoLockMinutes(context, 17);
            String backup = NexaStore.exportJson(context);
            assertTrue("Portable backup must declare schema 2", backup.contains("\"schema\":2"));
            assertTrue("Portable backup must explicitly exclude Vault", backup.contains("vault_note"));
            assertTrue(NexaStore.importJson(context, backup));
            assertEquals(17, NexaStore.securityAutoLockMinutes(context));
            assertEquals("Portable restore must not overwrite the device-local Vault",
                    originalVault.size(), NexaStore.vault(context).size());
        } finally {
            NexaStore.importJson(context, originalBackup);
        }
    }

    @Test
    public void bootReceiver_manifestRestoresAfterBootAndUpgrade() throws Exception {
        android.content.pm.ActivityInfo receiver = context.getPackageManager().getReceiverInfo(
                new android.content.ComponentName(context, BootReceiver.class), 0);
        assertNotNull(receiver);
        android.content.Intent boot = new android.content.Intent(android.content.Intent.ACTION_BOOT_COMPLETED);
        boot.setPackage(context.getPackageName());
        assertFalse(context.getPackageManager().queryBroadcastReceivers(boot, 0).isEmpty());
        android.content.Intent replaced = new android.content.Intent(android.content.Intent.ACTION_MY_PACKAGE_REPLACED);
        replaced.setPackage(context.getPackageName());
        assertFalse(context.getPackageManager().queryBroadcastReceivers(replaced, 0).isEmpty());
    }

    @Test
    public void releaseCandidate_hasRequiredCorePermissionsDeclared() {
        String pkg = context.getPackageName();
        assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                context.getPackageManager().checkPermission(android.Manifest.permission.RECEIVE_BOOT_COMPLETED, pkg));
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            // Runtime grant is intentionally user-controlled; declaration is validated by package metadata.
            try {
                android.content.pm.PackageInfo pi = context.getPackageManager().getPackageInfo(
                        pkg, android.content.pm.PackageManager.GET_PERMISSIONS);
                java.util.List<String> requested = java.util.Arrays.asList(pi.requestedPermissions == null ? new String[0] : pi.requestedPermissions);
                assertTrue(requested.contains(android.Manifest.permission.POST_NOTIFICATIONS));
            } catch (Exception e) {
                fail(e.getMessage());
            }
        }
    }


    @Test
    public void marketSourceLabel_isExplicitAndNotOfficialClaim() {
        assertEquals("Nexa Iran Market Feed", MarketDataHelper.IRAN_SOURCE);
        assertFalse(MarketDataHelper.IRAN_SOURCE.toLowerCase(java.util.Locale.ROOT).contains("official"));
    }
    @Test
    public void batteryThreshold_boundariesAndRearm_areStable() {
        assertTrue(BatteryAlertManager.shouldTriggerCharge(true, true, 80, 80, false));
        assertFalse(BatteryAlertManager.shouldTriggerCharge(true, true, 80, 80, true));
        assertFalse(BatteryAlertManager.shouldTriggerCharge(true, false, 90, 80, false));
        assertFalse(BatteryAlertManager.shouldRearmCharge(78, 80));
        assertTrue(BatteryAlertManager.shouldRearmCharge(76, 80));
        assertTrue(BatteryAlertManager.shouldTriggerLow(true, false, 15, 15, false));
        assertFalse(BatteryAlertManager.shouldTriggerLow(true, true, 10, 15, false));
        assertTrue(BatteryAlertManager.shouldRearmLow(true, 10, 15));
        assertTrue(BatteryAlertManager.shouldRearmLow(false, 18, 15));
    }

    @Test
    public void priceAlertEngine_activeAlertDetection_roundTrips() {
        java.util.List<NexaStore.AssetEntry> original = NexaStore.assets(context);
        try {
            java.util.List<NexaStore.AssetEntry> data = new java.util.ArrayList<>();
            NexaStore.AssetEntry x = new NexaStore.AssetEntry();
            x.name = "Regression Price Alert";
            x.type = "دلار";
            x.buyUnitPrice = 100000;
            x.currentUnitPrice = 110000;
            x.alertTarget = 120000;
            x.alertAtBuy = false;
            data.add(x);
            NexaStore.saveAssets(context, data);
            assertTrue(AssetMarketEngine.hasActiveAlerts(context));
            x.alertTarget = 0;
            x.alertAtBuy = false;
            NexaStore.saveAssets(context, data);
            assertFalse(AssetMarketEngine.hasActiveAlerts(context));
            x.alertAtBuy = true;
            NexaStore.saveAssets(context, data);
            assertTrue(AssetMarketEngine.hasActiveAlerts(context));
        } finally {
            NexaStore.saveAssets(context, original);
            PriceMonitorReceiver.cancel(context);
        }
    }

    @Test
    public void assetFinance_invalidOnlinePricesNeverCorruptTotals() {
        NexaStore.AssetEntry x=new NexaStore.AssetEntry();
        x.amount=2; x.buyUnitPrice=100; x.currentUnitPrice=Double.NaN;
        assertEquals(200d,AssetFinanceEngine.openCost(x),0.001);
        assertEquals(0d,AssetFinanceEngine.marketValue(x),0.001);
        x.currentUnitPrice=Double.POSITIVE_INFINITY;
        assertEquals(0d,AssetFinanceEngine.marketValue(x),0.001);
        assertFalse(AssetFinanceEngine.sell(x,Double.NaN,200,System.currentTimeMillis()));
        assertFalse(AssetFinanceEngine.sell(x,1,Double.POSITIVE_INFINITY,System.currentTimeMillis()));
        assertEquals(2d,x.amount,0.001);
    }

    @Test
    public void exactBigDecimalDisplay_preservesHugeIntegersAndFractionalScale() {
        assertEquals("۹٬۰۰۷٬۱۹۹٬۲۵۴٬۷۴۰٬۹۹۳٫۱۲۳۴۵۶۷۸۹۰۱۲۳۴۵۶۷۸۹",
                PersianFinancialDisplay.amount(new java.math.BigDecimal("9007199254740993.1234567890123456789")));
        assertEquals("-۱٬۲۳۴٫۰۰۵۰",
                PersianFinancialDisplay.amount(new java.math.BigDecimal("-1234.0050")));
        assertEquals("۰", PersianFinancialDisplay.amount(new java.math.BigDecimal("-0.000")));
        assertEquals("—", PersianFinancialDisplay.amount((java.math.BigDecimal) null));
        assertEquals("۰٫۰۰۰۰۰۰۰۰۰۱", PersianFinancialDisplay.amount(new java.math.BigDecimal("0.0000000001")));
    }

    @Test
    public void numberFormat_unicodeMinusNormalizesWithoutLosingPrecision() {
        assertEquals("-1,234,567", NumberFormatUtil.groupIntegerText("−۱۲۳۴۵۶۷"));
        assertEquals("-1,234.0500", NumberFormatUtil.groupDecimalText("−۱۲۳۴٫۰۵۰۰"));
        assertEquals("-1234.5", NumberFormatUtil.toLatin("−۱۲۳۴٫۵").replace("٫", "."));
        assertEquals("-", NumberFormatUtil.toLatin("−"));
    }

    @Test
    public void numberFormat_selectionEndpointsMapAcrossGrouping() {
        String before = "1234567.8900";
        String after = NumberFormatUtil.groupDecimalText(before);
        assertEquals("1,234,567.8900", after);
        assertEquals(1, NumberFormatUtil.mappedCaret(before, after, 1));
        assertEquals(9, NumberFormatUtil.mappedCaret(before, after, 7));
        assertEquals(14, NumberFormatUtil.mappedCaret(before, after, before.length()));
        assertEquals(0, NumberFormatUtil.mappedCaret(before, after, 0));
    }

    @Test
    public void medicineActions_rejectExpiredOrDisabledAndPreventOverflow() {
        NexaStore.Medicine m=new NexaStore.Medicine();
        m.id="regression-medicine";
        m.active=true;
        m.endMillis=1000L;
        assertTrue(MedicineScheduler.canAct(m,1000L));
        assertFalse(MedicineScheduler.canAct(m,1001L));
        m.active=false;
        assertFalse(MedicineScheduler.canAct(m,500L));
        m.active=true;
        m.endMillis=0;
        assertTrue(MedicineScheduler.canAct(m,Long.MAX_VALUE));
        assertEquals(-1L,MedicineScheduler.nextDoseAt(Long.MAX_VALUE-100L,24));
        assertEquals(-1L,MedicineScheduler.nextDoseAt(1000L,0));
        assertEquals(3601000L,MedicineScheduler.nextDoseAt(1000L,1));
        assertEquals(-1L,MedicineScheduler.nextDoseAt(0L,1));
    }

    @Test
    public void medicineScheduling_rejectsInvalidIdsAndRepeatOverflow() {
        NexaStore.Medicine m=new NexaStore.Medicine();
        m.active=true;
        m.nextDoseMillis=5000L;
        // Medicine generates a UUID by default; explicitly test an invalid ID.
        m.id=null;
        assertFalse(MedicineScheduler.validId(m.id));
        m.id="dose-1";
        assertTrue(MedicineScheduler.validId(m.id));
        assertTrue(MedicineScheduler.canSchedule(m,5000L));
        m.id="  ";
        assertFalse(MedicineScheduler.validId(m.id));
        assertEquals(Long.MAX_VALUE,MedicineScheduler.nextRepeatAt(Long.MAX_VALUE-100L,5));
        assertEquals(300000L,MedicineScheduler.nextRepeatAt(0L,5));
        assertEquals(360000L,MedicineScheduler.nextRepeatAt(60000L,5));
    }

}
