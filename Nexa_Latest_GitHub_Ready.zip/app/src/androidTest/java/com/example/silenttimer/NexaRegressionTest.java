package com.example.silenttimer;

import static org.junit.Assert.*;

import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationManager;
import android.service.notification.StatusBarNotification;

import androidx.test.platform.app.InstrumentationRegistry;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class NexaRegressionTest {
    private Context context;

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
    }

    @Test
    public void medicineDoseLogs_roundTripAndClear_areStable() {
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = "regression-med";
        log.scheduledAt = 1700000000000L;
        log.takenAt = 1700000300000L;

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        NexaStore.addMedicineDoseLog(context, log);

        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, "regression-med");
        assertEquals(1, saved.size());
        assertEquals(1700000300000L, saved.get(0).takenAt);

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        assertTrue(NexaStore.medicineDoseLogsFor(context, "regression-med").isEmpty());
    }

    @Test
    public void appVersion_remains5448Build70() throws Exception {
        android.content.pm.PackageInfo info = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
        assertEquals("5.4.48", info.versionName);
        assertEquals(70L, info.getLongVersionCode());
    }

    @Test
    public void medicineSkippedDose_roundTripsAsExplicitMissedDose() {
        String id = "regression-skipped-med";
        NexaStore.clearMedicineDoseLogs(context, id);
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = id;
        log.scheduledAt = 1700000000000L;
        log.takenAt = 0L;
        log.status = "skipped";
        NexaStore.addMedicineDoseLog(context, log);
        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, id);
        assertEquals(1, saved.size());
        assertEquals("skipped", saved.get(0).status);
        assertEquals(0L, saved.get(0).takenAt);
        NexaStore.clearMedicineDoseLogs(context, id);
    }

    @Test
    public void vaultDefaultGroups_doNotExposeEmailCategory() {
        String joined = java.util.Arrays.toString(NexaStore.defaultVaultGroups());
        assertFalse(joined.contains("ایمیل"));
        assertTrue(joined.contains("بانک"));
        assertTrue(joined.contains("سایت"));
    }

    @Test
    public void audioController_priorityOrderAndRingerModes_areStable() {
        assertTrue(NexaAudioController.PRIORITY_THEFT > NexaAudioController.PRIORITY_SECURITY);
        assertTrue(NexaAudioController.PRIORITY_SECURITY > NexaAudioController.PRIORITY_BATTERY);
        assertTrue(NexaAudioController.PRIORITY_BATTERY > NexaAudioController.PRIORITY_MEDICINE);
        assertTrue(NexaAudioController.PRIORITY_MEDICINE > NexaAudioController.PRIORITY_REMINDER);
        assertTrue(NexaAudioController.PRIORITY_REMINDER > NexaAudioController.PRIORITY_NORMAL);
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_NORMAL));
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_SILENT));
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_VIBRATE));
        assertFalse(NexaAudioController.isSupportedRingerMode(99));
        NexaAudioController.stopAll();
        assertEquals(0, NexaAudioController.getActivePriority());
        assertEquals("", NexaAudioController.getActiveOwner());
    }


    @Test
    public void silentTimer_previousRingerMode_roundTripsAndClears() {
        AppPrefs.clearTimer(context);
        AppPrefs.setTimerPreviousRingerMode(context, android.media.AudioManager.RINGER_MODE_VIBRATE);
        assertTrue(AppPrefs.hasTimerPreviousRingerMode(context));
        assertEquals(android.media.AudioManager.RINGER_MODE_VIBRATE,
                AppPrefs.getTimerPreviousRingerMode(context));
        AppPrefs.clearTimer(context);
        assertFalse(AppPrefs.hasTimerPreviousRingerMode(context));
    }

    @Test
    public void audioController_currentRingerMode_isAlwaysSupported() {
        int mode = NexaAudioController.getRingerMode(context);
        assertTrue(NexaAudioController.isSupportedRingerMode(mode));
    }

    @Test
    public void notificationEngine_blocksImmediateDuplicateDelivery() {
        String key = "regression-duplicate-" + System.nanoTime();
        assertTrue(NexaNotificationEngine.acquireDelivery(context, key));
        assertFalse(NexaNotificationEngine.acquireDelivery(context, key));
    }

    @Test
    public void medicineAlarm_buildsVisibleAlarmNotificationWithActions() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();

        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-alarm-med";
        m.name = "Regression Medicine";
        m.dose = "1 tablet";
        m.intervalHours = 8;
        m.nextDoseMillis = System.currentTimeMillis() + 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);

            Intent alarm = new Intent(context, MedicineAlarmReceiver.class);
            alarm.putExtra("id", m.id);
            new MedicineAlarmReceiver().onReceive(context, alarm);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification found = null;
            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                if (sbn.getId() == ("med" + m.id).hashCode()) {
                    found = sbn.getNotification();
                    break;
                }
            }
            assertNotNull("Medicine alarm notification must be posted", found);
            assertEquals(Notification.CATEGORY_ALARM, found.category);
            assertEquals(Notification.VISIBILITY_PUBLIC, found.visibility);
            assertNotNull("Medicine alarm must have a full-screen intent", found.fullScreenIntent);
            assertNotNull("Medicine alarm tap must open the ring screen", found.contentIntent);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel channel = nm.getNotificationChannel(MedicineAlarmReceiver.CHANNEL);
                assertNotNull("Medicine alarm channel must exist", channel);
                assertTrue("Medicine alarm channel must be HIGH importance", channel.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
                // On Android 14 the framework/emulator may report VISIBILITY_NO_OVERRIDE (-1000)
                // even when the notification itself explicitly uses VISIBILITY_PUBLIC.
                // Validate that the channel does not explicitly hide lock-screen notifications.
                assertTrue("Medicine alarm channel must not be SECRET on lock screen",
                        channel.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
            }
            assertNotNull(found.actions);
            // 5.4.48 adds a dedicated "Stop sound" action in addition to the
            // existing medicine actions. Keep this regression aligned with the
            // intended four-action notification contract.
            assertEquals(4, found.actions.length);
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE)).contains(m.name));
        } finally {
            AlarmSoundPlayer.stopAll();
            ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE))
                    .cancel(("med" + m.id).hashCode());
            MedicineScheduler.cancel(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }

    @Test
    public void medicineTakenNow_updatesNextDoseFromActualCompletion() {
        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-taken-now";
        m.name = "Regression Taken Now";
        m.intervalHours = 4;
        m.nextDoseMillis = System.currentTimeMillis() - 5 * 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);
            NexaStore.clearMedicineDoseLogs(context, m.id);

            long before = System.currentTimeMillis();
            Intent taken = new Intent(context, MedicineActionReceiver.class);
            taken.setAction("TAKEN_NOW");
            taken.putExtra("id", m.id);
            new MedicineActionReceiver().onReceive(context, taken);
            long after = System.currentTimeMillis();

            NexaStore.Medicine saved = NexaStore.medicine(context, m.id);
            assertNotNull(saved);
            long interval = 4L * 60L * 60L * 1000L;
            assertTrue(saved.nextDoseMillis >= before + interval);
            assertTrue(saved.nextDoseMillis <= after + interval);
            List<NexaStore.MedicineDoseLog> logs = NexaStore.medicineDoseLogsFor(context, m.id);
            assertEquals(1, logs.size());
            assertEquals("taken_now", logs.get(0).status);
        } finally {
            MedicineScheduler.cancel(context, m.id);
            NexaStore.clearMedicineDoseLogs(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }


    @Test
    public void criticalPermissionState_canBeReadFromAndroid() {
        android.app.NotificationManager nm=(android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.AlarmManager am=(android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        android.os.PowerManager pm=(android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
        assertNotNull(nm);
        assertNotNull(am);
        assertNotNull(pm);
        if(android.os.Build.VERSION.SDK_INT>=34) { boolean ignored=nm.canUseFullScreenIntent(); }
        if(android.os.Build.VERSION.SDK_INT>=31) { boolean ignored=am.canScheduleExactAlarms(); }
        boolean ignoredBattery=pm.isIgnoringBatteryOptimizations(context.getPackageName());
    }

    @Test
    public void missedCallGuard_ringingThenIdle_postsVisibleLockScreenNotification() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        long permissionDeadline = System.currentTimeMillis() + 2000L;
        while (android.os.Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
                && System.currentTimeMillis() < permissionDeadline) {
            Thread.sleep(50L);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                    context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS));
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        boolean oldShowName = AppPrefs.isMissedCallShowName(context);
        boolean oldShowNumber = AppPrefs.isMissedCallShowNumber(context);
        boolean oldShowTime = AppPrefs.isMissedCallShowTime(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            AppPrefs.setMissedCallShowName(context, false);
            AppPrefs.setMissedCallShowNumber(context, true);
            AppPrefs.setMissedCallShowTime(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);

            String number = "+15551234567";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, number);

            Notification found = null;
            long notificationDeadline = System.currentTimeMillis() + 2500L;
            while (found == null && System.currentTimeMillis() < notificationDeadline) {
                for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                    if (sbn.getId() == NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID) {
                        found = sbn.getNotification();
                        break;
                    }
                }
                if (found == null) Thread.sleep(50L);
            }
            assertNotNull("Missed-call guard must post a notification", found);
            assertEquals(Notification.CATEGORY_CALL, found.category);
            assertEquals(Notification.VISIBILITY_PUBLIC, found.visibility);
            assertNotNull("Missed-call notification must carry a full-screen lock card intent", found.fullScreenIntent);
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE))
                    .contains("تماس از دست‌رفته"));
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TEXT))
                    .contains(number));
            assertEquals(1, MissedCallGuard.getUnviewedCount(context));
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel channel = nm.getNotificationChannel(
                        NexaNotificationEngine.MISSED_CALL_CHANNEL);
                assertNotNull(channel);
                assertTrue(channel.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
                assertTrue(channel.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
            }
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
            AppPrefs.setMissedCallShowName(context, oldShowName);
            AppPrefs.setMissedCallShowNumber(context, oldShowNumber);
            AppPrefs.setMissedCallShowTime(context, oldShowTime);
        }
    }

    @Test
    public void missedCallGuard_answeredCall_doesNotPostMissedNotification() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        long permissionDeadline = System.currentTimeMillis() + 2000L;
        while (android.os.Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
                && System.currentTimeMillis() < permissionDeadline) {
            Thread.sleep(50L);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                    context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS));
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            String number = "+15557654321";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_OFFHOOK, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, number);

            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                assertNotEquals(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID, sbn.getId());
            }
            assertEquals(0, MissedCallGuard.getUnviewedCount(context));
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
        }
    }

    @Test
    public void missedCallGuard_multipleMissedCalls_updatesCountAndVisibleList() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        boolean oldShowName = AppPrefs.isMissedCallShowName(context);
        boolean oldShowNumber = AppPrefs.isMissedCallShowNumber(context);
        boolean oldShowTime = AppPrefs.isMissedCallShowTime(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            AppPrefs.setMissedCallShowName(context, false);
            AppPrefs.setMissedCallShowNumber(context, true);
            AppPrefs.setMissedCallShowTime(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

            String first = "+15550000001";
            String second = "+15550000002";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, first);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, first);
            Thread.sleep(50L);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, second);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, second);

            Notification found = null;
            long deadline = System.currentTimeMillis() + 2500L;
            while (found == null && System.currentTimeMillis() < deadline) {
                for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                    if (sbn.getId() == NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID) {
                        found = sbn.getNotification();
                        break;
                    }
                }
                if (found == null) Thread.sleep(50L);
            }
            assertNotNull(found);
            assertEquals(2, MissedCallGuard.getUnviewedCount(context));
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE)).contains("2"));
            String big = String.valueOf(found.extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
            assertTrue(big.contains(first));
            assertTrue(big.contains(second));
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
            AppPrefs.setMissedCallShowName(context, oldShowName);
            AppPrefs.setMissedCallShowNumber(context, oldShowNumber);
            AppPrefs.setMissedCallShowTime(context, oldShowTime);
        }
    }

    @Test
    public void missedCallGuard_recentListCapacity_supportsSeveralCalls() {
        assertTrue("Lock-screen list must retain several missed calls", MissedCallGuard.recentCallCapacity() >= 8);
    }

    @Test
    public void notificationEngine_coreChannels_arePublicAndSeparated() {
        NotificationChannelHelper.ensureCoreChannels(context);
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        String[] ids = new String[]{
                NotificationChannelHelper.CHANNEL_MISSED_CALL,
                NotificationChannelHelper.CHANNEL_REMINDER,
                NotificationChannelHelper.CHANNEL_BATTERY_ALARM,
                NotificationChannelHelper.CHANNEL_LOW_BATTERY,
                NotificationChannelHelper.CHANNEL_THEFT_ALARM,
                NotificationChannelHelper.CHANNEL_SECURITY
        };
        java.util.HashSet<String> unique = new java.util.HashSet<>();
        for (String id : ids) {
            assertTrue(unique.add(id));
            android.app.NotificationChannel ch = nm.getNotificationChannel(id);
            assertNotNull("Core Nexa channel must exist: " + id, ch);
            assertTrue(ch.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
            assertTrue(ch.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
        }
    }



    @Test
    public void caseDirectories_roundTripWithoutDuplicates() {
        NexaStore.addCourt(context, "دادگاه تست ۴۳");
        NexaStore.addCourt(context, "دادگاه تست ۴۳");
        NexaStore.addLawyer(context, "وکیل تست ۴۳");
        assertTrue(NexaStore.courts(context).contains("دادگاه تست ۴۳"));
        assertTrue(NexaStore.lawyers(context).contains("وکیل تست ۴۳"));
        int count = 0; for (String x : NexaStore.courts(context)) if ("دادگاه تست ۴۳".equals(x)) count++;
        assertEquals(1, count);
    }

    @Test
    public void removedThemeEngine_isNotPresentInRuntimePackage() throws Exception {
        try { Class.forName("com.example.silenttimer.ThemeManager"); fail("ThemeManager must remain removed"); }
        catch (ClassNotFoundException expected) { assertTrue(true); }
    }

    @Test
    public void emergencyContactLabels_haveSafeDefaultsAndRoundTrip() {
        NexaStore.setEmergencyLabel1(context, "مادر");
        NexaStore.setEmergencyLabel2(context, "پدر");
        assertEquals("مادر", NexaStore.emergencyLabel1(context));
        assertEquals("پدر", NexaStore.emergencyLabel2(context));
        NexaStore.setEmergencyLabel1(context, "");
        NexaStore.setEmergencyLabel2(context, "");
        assertEquals("مادر", NexaStore.emergencyLabel1(context));
        assertEquals("پدر", NexaStore.emergencyLabel2(context));
    }
    @Test
    public void batteryAlertSettings_roundTripAndClamp() {
        AppPrefs.setChargeAlarmThreshold(context, 95); assertEquals(95, AppPrefs.getChargeAlarmThreshold(context));
        AppPrefs.setLowBatteryThreshold(context, 10); assertEquals(10, AppPrefs.getLowBatteryThreshold(context));
        AppPrefs.setChargeAlarmThreshold(context, 150); assertEquals(100, AppPrefs.getChargeAlarmThreshold(context));
        AppPrefs.setLowBatteryThreshold(context, -2); assertEquals(1, AppPrefs.getLowBatteryThreshold(context));
        assertTrue(BatteryAlertManager.CHARGE_ID != BatteryAlertManager.LOW_ID);
    }

    @Test
    public void theftGuard_settingsAndPriority_areStable() {
        AppPrefs.setTheftGuardEnabled(context, true);
        assertTrue(AppPrefs.isTheftGuardEnabled(context));
        AppPrefs.setTheftAlarmActive(context, true);
        assertTrue(AppPrefs.isTheftAlarmActive(context));
        AppPrefs.setTheftLastPlugged(context, true);
        assertTrue(AppPrefs.isTheftPlugStateKnown(context));
        assertTrue(AppPrefs.getTheftLastPlugged(context));
        assertEquals(NexaAudioController.PRIORITY_THEFT, 100);
        assertEquals("theft_guard", TheftGuardManager.OWNER);
        assertTrue(TheftGuardManager.NOTIFICATION_ID != BatteryAlertManager.CHARGE_ID);
        assertTrue(TheftGuardManager.NOTIFICATION_ID != BatteryAlertManager.LOW_ID);
        TheftGuardManager.stop(context);
        assertFalse(AppPrefs.isTheftAlarmActive(context));
        AppPrefs.setTheftGuardEnabled(context, false);
        AppPrefs.clearTheftPlugState(context);
    }


    @Test
    public void audioController_hasDistinctProfilesAndMedicineDebounce() {
        assertTrue(NexaAudioController.SOUND_ALARM != NexaAudioController.SOUND_REMINDER);
        assertTrue(NexaAudioController.SOUND_REMINDER != NexaAudioController.SOUND_BATTERY);
        assertTrue(NexaAudioController.SAME_OWNER_DEBOUNCE_MS >= 10_000L);
        assertTrue(NexaAudioController.PRIORITY_MEDICINE > NexaAudioController.PRIORITY_REMINDER);
    }

    @Test
    public void batteryAndReminderChannels_areSeparated() {
        assertFalse(NotificationChannelHelper.CHANNEL_BATTERY_ALARM.equals(ReminderScheduler.CHANNEL));
        assertFalse(NotificationChannelHelper.CHANNEL_LOW_BATTERY.equals(ReminderScheduler.CHANNEL));
        assertFalse(MedicineAlarmReceiver.CHANNEL.equals(ReminderScheduler.CHANNEL));
    }

}
