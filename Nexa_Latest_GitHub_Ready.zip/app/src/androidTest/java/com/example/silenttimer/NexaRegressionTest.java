package com.example.silenttimer;

import static org.junit.Assert.*;

import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import android.app.NotificationManager;
import android.service.notification.StatusBarNotification;

import androidx.test.platform.app.InstrumentationRegistry;

import androidx.test.core.app.ApplicationProvider;
import androidx.test.ext.junit.runners.AndroidJUnit4;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import java.util.List;

@RunWith(AndroidJUnit4.class)
public class NexaRegressionTest {
    @Test
    public void build224_dailyEntryAndHomeUseCompactAccessiblePictograms(){
        Context c=contextOrApp();
        android.widget.LinearLayout action=NexaActionUi.compactTile(c,"🎙️","ثبت صوتی","ثبت فرمان با گفتار",7);
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,action.getLayoutDirection());
        assertTrue(action.getMinimumHeight()>=UiKit.dp(c,64));
        assertEquals(3,action.getChildCount());
        assertTrue(action.getChildAt(0) instanceof android.widget.LinearLayout);
        assertTrue(((android.widget.LinearLayout)action.getChildAt(0)).getChildAt(0) instanceof NexaOutlineIcon);
        assertTrue(action.isClickable());
        assertTrue(action.isFocusable());
        assertTrue(action.getContentDescription().toString().contains("ثبت صوتی"));
        android.widget.LinearLayout shortCut=HomeUi.shortcut(c,"📅","یادآورها","هشدارها و برنامه‌ها");
        assertTrue(shortCut.getMinimumHeight()>=UiKit.dp(c,64));
        assertEquals(3,shortCut.getChildCount());
        assertTrue(((android.widget.LinearLayout)shortCut.getChildAt(0)).getChildAt(0) instanceof NexaOutlineIcon);
        assertTrue(shortCut.isClickable());
        assertTrue(shortCut.getContentDescription().toString().contains("یادآورها"));
        android.widget.FrameLayout iconAction=UiKit.outlineIconAction(c,"voice","ثبت با صدا",UiKit.TEAL);
        assertTrue(iconAction.getMinimumHeight()>=UiKit.dp(c,48));
        assertTrue(iconAction.getMinimumWidth()>=UiKit.dp(c,48));
        assertTrue(iconAction.getChildAt(0) instanceof NexaOutlineIcon);
        assertEquals("ثبت با صدا",iconAction.getContentDescription().toString());
        assertNotNull(new Intent(c,VoiceQuickAddActivity.class));
        assertNotNull(new Intent(c,ReminderEditActivity.class));
        assertNotNull(new Intent(c,LedgerActivity.class));
        assertNotNull(new Intent(c,QuickAddActivity.class));
    }

    @Test
    public void build223_directoryUsesRealIconsAndCompactSharedNavigation(){
        Context c=contextOrApp();
        android.widget.LinearLayout nav=UiKit.bottomNav(c,2,v->{},v->{},v->{},v->{});
        assertEquals(4,nav.getChildCount());
        for(int i=0;i<4;i++){
            assertTrue(nav.getChildAt(i) instanceof android.widget.LinearLayout);
            android.widget.LinearLayout tab=(android.widget.LinearLayout)nav.getChildAt(i);
            assertEquals(2,tab.getChildCount());
            assertTrue(tab.getChildAt(0) instanceof NexaOutlineIcon);
            assertTrue(tab.getChildAt(1) instanceof android.widget.TextView);
            assertTrue(tab.isClickable());
            assertTrue(tab.isFocusable());
            assertNotNull(tab.getContentDescription());
        }
        assertTrue(nav.getChildAt(2).isSelected());
        assertTrue(nav.getChildAt(2).getContentDescription().toString().contains("ثبت سریع"));
        android.widget.LinearLayout feature=UiKit.featureDirectoryRow(c,"📄","فایل‌ها و فاکتورها",4);
        assertEquals(3,feature.getChildCount());
        assertTrue(feature.getChildAt(0) instanceof android.widget.LinearLayout);
        assertTrue(((android.widget.LinearLayout)feature.getChildAt(0)).getChildAt(0) instanceof NexaOutlineIcon);
        android.widget.LinearLayout setting=UiKit.settingsDirectoryRow(c,"🔋","باتری و شارژ","وضعیت");
        assertEquals(3,setting.getChildCount());
        assertTrue(setting.getChildAt(0) instanceof android.widget.LinearLayout);
        String[] kinds={"assets","ledger","bills","docs","shared","medicine",
                "vehicle","home","case","weather","reminders","occasions","silent",
                "battery","emergency","vault","files","search","timeline","history",
                "settings","lists","today","quick"};
        for(String kind:kinds){
            NexaOutlineIcon icon=new NexaOutlineIcon(c,kind,UiKit.BLUE);
            int size=UiKit.dp(c,48);
            icon.layout(0,0,size,size);
            android.graphics.Bitmap bitmap=android.graphics.Bitmap.createBitmap(
                    size,size,android.graphics.Bitmap.Config.ARGB_8888);
            icon.draw(new android.graphics.Canvas(bitmap));
            assertFalse(bitmap.isRecycled());
            bitmap.recycle();
        }
    }

    @Test
    public void build222_todayAndTimelineUseTheSameAccessibleNavigationAndPagedLists(){
        Context c=contextOrApp();
        android.widget.LinearLayout today=UiKit.bottomNav(c,1,v->{},v->{},v->{},v->{});
        android.widget.LinearLayout timeline=UiKit.bottomNav(c,3,v->{},v->{},v->{},v->{});
        assertEquals(4,today.getChildCount());
        assertTrue(today.getChildAt(1).isSelected());
        assertTrue(timeline.getChildAt(3).isSelected());
        assertTrue(today.getChildAt(1).getContentDescription().toString().contains("امروز"));
        assertTrue(timeline.getChildAt(3).getContentDescription().toString().contains("خط زمانی"));
        assertEquals(8,TodayPresentationPolicy.nextVisibleCount(100,0));
        assertEquals(16,TodayPresentationPolicy.nextVisibleCount(100,8));
        assertEquals(11,TodayPresentationPolicy.nextVisibleCount(11,8));
        assertNotNull(new Intent(c,TodayActivity.class));
        assertNotNull(new Intent(c,TimelineActivity.class));
        assertNotNull(new Intent(c,ReminderEditActivity.class));
        android.widget.LinearLayout event=NexaAgendaUi.event(c,"📅","قرار", "امروز",
                "",UiKit.PURPLE,true);
        assertTrue(event.getMinimumHeight()>=UiKit.dp(c,72));
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,event.getLayoutDirection());
    }

    @Test
    public void build222_timelineCalendarWindowUsesRealLocalDayBoundary(){
        long now=System.currentTimeMillis();
        long start=AgendaDuePolicy.startOfDay(now);
        long tomorrow=AgendaDuePolicy.afterCalendarDays(start,1);
        long end=AgendaDuePolicy.afterCalendarDays(start,7);
        assertTrue(start<=now);
        assertTrue(now<tomorrow);
        assertTrue(tomorrow<end);
        assertEquals(AgendaDuePolicy.TODAY,AgendaDuePolicy.bucket(start,false,
                start,tomorrow,AgendaDuePolicy.afterCalendarDays(start,2),
                AgendaDuePolicy.afterCalendarDays(start,8)));
    }

    @Test
    public void build221_moduleDirectoryProvidesAllRoutesAndUsefulPersianSearch(){
        assertEquals(5,ModulesCatalog.GROUPS.length);
        assertTrue(ModulesCatalog.ALL.length>=22);
        java.util.Set<Class<?>> destinations=new java.util.HashSet<>();
        for(ModulesCatalog.Item module:ModulesCatalog.ALL){
            assertTrue(module.group>0&&module.group<ModulesCatalog.GROUPS.length);
            assertNotNull(module.destination);
            assertFalse(module.title.isEmpty());
            destinations.add(module.destination);
        }
        assertEquals(ModulesCatalog.ALL.length,destinations.size());
        assertEquals(ModulesCatalog.ALL.length,ModulesCatalog.filter("",0).size());
        assertEquals(1,ModulesCatalog.filter("قسط",0).size());
        assertEquals("قبوض و اقساط",ModulesCatalog.filter("قسط",0).get(0).title);
        assertEquals(1,ModulesCatalog.filter("بانك",1).size());
        assertEquals("دفتر مشترک",ModulesCatalog.filter("بانك",1).get(0).title);
        assertTrue(ModulesCatalog.filter("دارو",1).isEmpty());
        assertEquals("یادآورها",ModulesCatalog.filter("يادآورها",3).get(0).title);
        assertNotNull(new Intent(contextOrApp(),ModulesActivity.class));
    }

    @Test
    public void build221_historyIsReadableByDefaultAndSharedNavNamesRealDestination(){
        Context c=contextOrApp();
        android.widget.LinearLayout nav=UiKit.bottomNav(c,-1,v->{},v->{},v->{},v->{});
        assertTrue(nav.getChildAt(3).getContentDescription().toString().contains("خط زمانی"));
        assertFalse(nav.getChildAt(3).isSelected());
        assertTrue(UiKit.featureDirectoryRow(c,"📄","تاریخچه",4).getMinimumHeight()>=UiKit.dp(c,62));
        assertNotNull(new Intent(c,HistoryActivity.class));
        assertNotNull(new Intent(c,TimelineActivity.class));
    }

    @Test
    public void build220_sharedDesignFontsAndSurfaceHierarchyRemainAccessible(){
        Context c=contextOrApp();
        assertNotNull(c.getResources().getFont(R.font.nexa_fa_regular));
        assertNotNull(c.getResources().getFont(R.font.nexa_fa_bold));
        assertNotNull(UiKit.appFace(c,false));
        assertNotNull(UiKit.appFace(c,true));
        assertNotNull(UiKit.card(c));
        assertNotNull(UiKit.colorfulCard(c,4));
        assertNotNull(UiKit.screenBackground(c));
        assertNotNull(UiKit.heroSurface(c));
        assertNotNull(UiKit.bottomNavBackground(c));
        assertTrue(UiKit.primaryButton(c,"ثبت").getMinimumHeight()>=UiKit.dp(c,50));
        assertTrue(UiKit.secondaryButton(c,"جزئیات").getMinimumHeight()>=UiKit.dp(c,48));
        assertEquals("◉",UiKit.symbolFor("🎙️"));
        assertEquals("▦",UiKit.symbolFor("📅"));
        assertEquals("⌁",UiKit.symbolFor("📈"));
    }

    @Test
    public void build220_disclosureIsCollapsedAndPreservesDetails(){
        Context c=contextOrApp();
        String key="build220_regression_unique_accordion";
        c.getSharedPreferences("nexa_ui_sections",Context.MODE_PRIVATE).edit()
            .remove(key+"_pinned").remove(key+"_open").commit();
        android.widget.LinearLayout section=UiKit.collapsible(c,key,"تنظیمات بازار",
                "توضیح مربوط به تنظیمات بازار",1,false,new android.widget.TextView(c));
        assertEquals(2,section.getChildCount());
        android.widget.LinearLayout head=(android.widget.LinearLayout)section.getChildAt(0);
        android.widget.LinearLayout body=(android.widget.LinearLayout)section.getChildAt(1);
        assertEquals(android.view.View.GONE,body.getVisibility());
        assertTrue(head.isClickable());
        assertTrue(head.getContentDescription().toString().contains("باز کردن"));
        head.performClick();
        assertEquals(android.view.View.VISIBLE,body.getVisibility());
        assertTrue(head.getContentDescription().toString().contains("بستن"));
        assertEquals(3,body.getChildCount());
        c.getSharedPreferences("nexa_ui_sections",Context.MODE_PRIVATE).edit()
            .remove(key+"_pinned").remove(key+"_open").commit();
    }

    @Test
    public void build219_assetPortfolioRetainsAccessibleCardsAndFinanceFilters(){
        Context c=contextOrApp();
        android.widget.LinearLayout hero=NexaAssetsUi.hero(c);
        assertNotNull(hero.getBackground());
        assertTrue(hero.getMinimumHeight()>=UiKit.dp(c,118));
        android.widget.LinearLayout profitCard=NexaAssetsUi.purchaseCard(c,120d);
        android.widget.LinearLayout lossCard=NexaAssetsUi.purchaseCard(c,-120d);
        assertNotNull(profitCard.getBackground());
        assertNotNull(lossCard.getBackground());
        assertTrue(profitCard.getMinimumHeight()>=UiKit.dp(c,110));
        assertTrue(AssetOverviewPolicy.matches(AssetOverviewPolicy.ALL,90d,110d,false));
        assertTrue(AssetOverviewPolicy.matches(AssetOverviewPolicy.GAIN,90d,110d,false));
        assertTrue(AssetOverviewPolicy.matches(AssetOverviewPolicy.LOSS,110d,90d,false));
        assertTrue(AssetOverviewPolicy.matches(AssetOverviewPolicy.ALERT,100d,100d,true));
        android.widget.TextView chip=NexaAssetsUi.filter(c,"زیان‌ده",true);
        // Regression for the GitHub emulator failure at this assertion:
        // setMinHeight is NOT a substitute for setMinimumHeight.
        assertTrue(chip.getMinimumHeight()>=UiKit.dp(c,48));
        assertTrue(chip.getMinimumWidth()>=UiKit.dp(c,76));
        assertTrue(chip.getContentDescription().toString().contains("زیان‌ده"));
        assertTrue(chip.getContentDescription().toString().contains("فعال"));
        android.widget.TextView inactive=NexaAssetsUi.filter(c,"همه",false);
        assertTrue(inactive.getMinimumHeight()>=UiKit.dp(c,48));
        assertTrue(inactive.getContentDescription().toString().contains("همه"));
    }

    @Test
    public void build217_quickAddAdaptiveLayoutAndEntryPointsAreAvailable(){
        assertTrue(QuickAddLayoutPolicy.shouldStack(320f,1.0f));
        assertTrue(QuickAddLayoutPolicy.shouldStack(389f,1.0f));
        assertTrue(QuickAddLayoutPolicy.shouldStack(420f,1.2f));
        assertFalse(QuickAddLayoutPolicy.shouldStack(390f,1.0f));
        assertFalse(QuickAddLayoutPolicy.shouldStack(430f,1.15f));
        Context c=contextOrApp();
        assertNotNull(new Intent(c,VoiceQuickAddActivity.class));
        assertNotNull(new Intent(c,OccasionEditActivity.class));
        android.widget.LinearLayout nav=UiKit.bottomNav(c,2,v->{},v->{},v->{},v->{});
        assertEquals(4,nav.getChildCount());
        assertTrue(nav.getChildAt(2).isSelected());
        android.widget.LinearLayout compact=NexaActionUi.compactTile(c,"🎙️","ثبت صوتی","گفتار",0);
        assertTrue(compact.isClickable());
        assertEquals(android.widget.LinearLayout.HORIZONTAL,compact.getOrientation());
        assertTrue(compact.getMinimumHeight()>=UiKit.dp(c,80));
        assertTrue(compact.getContentDescription().toString().contains("ثبت صوتی"));
    }

    @Test
    public void build216_reminderOverviewCompactFiltersAndTalkBackRemainSafe(){
        Context c=contextOrApp();
        long now=1_800_000_000_000L;
        NexaStore.Reminder upcoming=new NexaStore.Reminder();
        upcoming.active=true;upcoming.whenMillis=now+60_000L;
        NexaStore.Reminder overdue=new NexaStore.Reminder();
        overdue.active=true;overdue.whenMillis=now-60_000L;
        NexaStore.Reminder paused=new NexaStore.Reminder();
        paused.active=false;paused.whenMillis=now-60_000L;
        NexaStore.Reminder finished=new NexaStore.Reminder();
        finished.done=true;finished.whenMillis=now-60_000L;
        ReminderOverviewPolicy.Counts stats=ReminderOverviewPolicy.count(
                java.util.Arrays.asList(upcoming,overdue,paused,finished),now);
        assertEquals(1,stats.pending);assertEquals(1,stats.overdue);
        assertEquals(1,stats.paused);assertEquals(1,stats.completed);
        assertTrue(ReminderOverviewPolicy.toggleLabel(stats,false).contains("در انتظار"));
        assertTrue(ReminderOverviewPolicy.toggleLabel(stats,true).contains("بستن آمار"));
        assertTrue(ReminderOverviewPolicy.toggleDescription(stats,false).contains("انجام‌شده"));
        android.widget.Button control=UiKit.secondaryButton(c,"▾ مشاهده آمار");
        assertTrue(control.getMinimumHeight()>=UiKit.dp(c,48));
        for(String name:new String[]{"متوقف","انجام‌شده"}){
            android.widget.TextView chip=NexaReminderUi.filterChip(c,name,true);
            assertNotNull(chip.getBackground());
            assertTrue(chip.getContentDescription().toString().contains("انتخاب‌شده"));
        }
    }

    @Test
    public void build214_navigationTargetsAndAccessibleSelectionRemainConsistent(){
        Context c=contextOrApp();
        android.widget.LinearLayout nav=UiKit.bottomNav(c,2,v->{},v->{},v->{},v->{});
        String[] names={"خانه","امروز","ثبت سریع","خط زمانی"};
        assertEquals(4,nav.getChildCount());
        for(int i=0;i<4;i++){
            android.view.View tab=nav.getChildAt(i);
            assertTrue(tab.isClickable());
            assertTrue(tab.isFocusable());
            assertTrue(tab.getMinimumHeight()>=UiKit.dp(c,56));
            assertEquals(i==2,tab.isSelected());
            assertTrue(tab.getContentDescription().toString().contains(names[i]));
        }
        assertTrue(nav.getChildAt(2).getContentDescription().toString().contains("انتخاب‌شده"));
    }

    @Test
    public void build212_occasionDirectorySearchAndFiltersAreSafe(){
        Context c=contextOrApp();
        android.widget.EditText field=UiKit.styleField(c,new android.widget.EditText(c),"جست‌وجوی مناسبت");
        assertTrue(field.getMinimumHeight()>=UiKit.dp(c,48));
        android.widget.TextView chip=UiKit.chip(c,"۳۰ روز آینده",true);
        assertNotNull(chip.getBackground());
        OccasionStore.Occasion e=new OccasionStore.Occasion();
        e.title="تولد حسین";e.type="birthday";e.calendar="gregorian";
        e.year=2020;e.month=11;e.day=4;e.hour=9;e.minute=0;
        long now=AnnualOccasionDates.yearDate("gregorian",2026,11,2,0,0);
        java.util.List<OccasionStore.Occasion> all=java.util.Collections.singletonList(e);
        assertEquals(1,OccasionDirectoryPolicy.select(all,"حسين","all",now).size());
        assertEquals(1,OccasionDirectoryPolicy.select(all,"","soon",now).size());
        assertEquals(0,OccasionDirectoryPolicy.select(all,"","marriage",now).size());
        e.active=false;
        assertEquals(0,OccasionDirectoryPolicy.select(all,"","soon",now).size());
        assertEquals(1,OccasionDirectoryPolicy.select(all,"","paused",now).size());
        assertNotNull(new Intent(c,AnnualOccasionsActivity.class));
    }

    @Test
    public void build211_presetLayoutAndStopCommandStaySafe(){
        assertTrue(HomeTimerLayoutPolicy.stackPresets(290f,1f));
        assertTrue(HomeTimerLayoutPolicy.stackPresets(400f,1.2f));
        assertFalse(HomeTimerLayoutPolicy.stackPresets(430f,1.0f));
        assertEquals("com.example.silenttimer.STOP",SilentTimerService.ACTION_STOP);
        Context c=contextOrApp();
        android.widget.Button stop=UiKit.secondaryButton(c,"■ توقف تایمر فعال");
        assertTrue(stop.getMinimumHeight()>=UiKit.dp(c,48));
        assertNotNull(stop.getForeground());
    }

    @Test
    public void build210_dashboardTouchTargetsAndCardAccessibilityStayStable(){
        Context c=contextOrApp();
        android.widget.LinearLayout debt=HomeUi.balanceCard(c,"بدهی من",UiKit.RED);
        HomeUi.destination(c,debt,"خلاصه بدهی‌ها",UiKit.RED);
        assertTrue(debt.isClickable());
        assertTrue(debt.isFocusable());
        assertEquals("خلاصه بدهی‌ها",debt.getContentDescription().toString());
        assertTrue(debt.getMinimumHeight()>=UiKit.dp(c,96));
        assertNotNull(debt.getForeground());
        android.widget.LinearLayout link=HomeUi.shortcut(c,"🎂","مناسبت‌ها","تولد و سالگردها");
        assertTrue(link.isClickable());
        assertTrue(link.isFocusable());
        assertTrue(link.getContentDescription().toString().contains("مناسبت‌ها"));
        assertNotNull(link.getForeground());
    }

    @Test
    public void build209_homeOccasionPreviewIsStableAndDoesNotMutateEvents(){
        long now=AnnualOccasionDates.yearDate("gregorian",2026,11,2,9,0);
        OccasionStore.Occasion soon=new OccasionStore.Occasion();
        soon.calendar="gregorian";soon.year=1990;soon.month=11;soon.day=3;soon.hour=9;soon.title="تولد سارا";
        OccasionStore.Occasion late=new OccasionStore.Occasion();
        late.calendar="gregorian";late.year=1995;late.month=12;late.day=3;late.hour=9;late.title="سالگرد ازدواج";
        OccasionStore.Occasion inactive=new OccasionStore.Occasion();
        inactive.calendar="gregorian";inactive.year=1985;inactive.month=11;inactive.day=2;inactive.active=false;
        java.util.List<OccasionStore.Occasion> all=java.util.Arrays.asList(late,inactive,soon);
        HomeOccasionPolicy.Match picked=HomeOccasionPolicy.closest(all,now);
        assertNotNull(picked);
        assertEquals("تولد سارا",picked.occasion.title);
        assertTrue(picked.due>now);
        assertEquals(1990,soon.year); // original anniversary year is never overwritten
        assertNull(HomeOccasionPolicy.closest(java.util.Collections.singletonList(inactive),now));
        assertNull(HomeOccasionPolicy.closest(null,now));
        assertTrue(HomeOccasionPolicy.hasScheduled(all,now));
    }

    @Test
    public void build207_todayAndRecurringDeadlinesDoNotDuplicateOrMislabelPausedItems(){
        java.util.Calendar c=java.util.Calendar.getInstance();
        c.set(2026,java.util.Calendar.NOVEMBER,2,16,15,0);
        c.set(java.util.Calendar.MILLISECOND,0);
        long now=c.getTimeInMillis();
        long start=AgendaDuePolicy.startOfDay(now);
        long tomorrow=AgendaDuePolicy.afterCalendarDays(start,1);
        long afterTomorrow=AgendaDuePolicy.afterCalendarDays(start,2);
        long weekEnd=AgendaDuePolicy.afterCalendarDays(start,8);
        assertEquals(AgendaDuePolicy.TODAY,AgendaDuePolicy.bucket(start+1000,false,start,tomorrow,afterTomorrow,weekEnd));
        assertEquals(AgendaDuePolicy.TOMORROW,AgendaDuePolicy.bucket(tomorrow,false,start,tomorrow,afterTomorrow,weekEnd));
        assertEquals(AgendaDuePolicy.LATER_THIS_WEEK,AgendaDuePolicy.bucket(afterTomorrow,false,start,tomorrow,afterTomorrow,weekEnd));
        assertEquals(AgendaDuePolicy.OUTSIDE,AgendaDuePolicy.bucket(weekEnd,false,start,tomorrow,afterTomorrow,weekEnd));
        assertEquals(AgendaDuePolicy.COMPLETED,AgendaDuePolicy.bucket(start+1000,true,start,tomorrow,afterTomorrow,weekEnd));
        assertFalse(AgendaDuePolicy.includeReminder(false,false));
        assertTrue(AgendaDuePolicy.includeReminder(false,true));
        assertEquals(start+1000,AgendaDuePolicy.shownDue(start+1000,"none",start));
        long veryOld=AgendaDuePolicy.afterCalendarDays(start,-100);
        assertEquals(start+9*60*60*1000,AgendaDuePolicy.shownDue(veryOld+9*60*60*1000,"daily",start));
        assertFalse(AgendaDuePolicy.overdueForAttention(veryOld+9*60*60*1000,"weekly",start+1000));
        assertTrue(AgendaDuePolicy.overdueForAttention(veryOld+9*60*60*1000,"daily",now));
    }

    @Test
    public void build206_universalSearchIncludesLedgerAndNormalizesPersianSafely(){
        assertEquals("حسین رضایی",SearchQueryPolicy.normalize("حسين\u200cرضايي"));
        assertTrue(SearchQueryPolicy.matches("احمدی 09123456789 یادداشت","۰۹۱۲۳۴۵۶۷۸۹"));
        assertTrue(SearchQueryPolicy.matches("احمدی قسط شهریور","شهریور احمدی"));
        assertFalse(SearchQueryPolicy.matches("رضایی","احمدی"));
        assertEquals(4,SearchQueryPolicy.score("احمدی","احمدی"));
        assertEquals(1,SearchQueryPolicy.score("احمدی موعد جدید","جدید احمدی"));
        assertTrue(SearchDisplayPolicy.matches(SearchDisplayPolicy.FINANCE,SearchDisplayPolicy.FINANCE));
        android.content.Intent account=new android.content.Intent(contextOrApp(),LedgerActivity.class);
        account.putExtra(LedgerActivity.EXTRA_OPEN_PARTY_ID,"search-test-party");
        assertEquals("search-test-party",account.getStringExtra(LedgerActivity.EXTRA_OPEN_PARTY_ID));
    }

    @Test
    public void build205_billsSummaryFiltersAndPaymentStatusStayAccessible(){
        android.content.Context c=contextOrApp();
        long now=System.currentTimeMillis();
        assertTrue(BillListPolicy.overdue(false,now-1,now));
        assertFalse(BillListPolicy.overdue(true,now-1,now));
        assertTrue(BillListPolicy.soon(false,now+60_000,now));
        assertTrue(BillListPolicy.matches(BillListPolicy.SEVEN_DAY_FILTER,false,now+60_000,now));
        assertTrue(BillListPolicy.compare(false,now-1,false,now+60_000,now)<0);
        java.util.List<BillListPolicy.Entry> sample=java.util.Arrays.asList(
            new BillListPolicy.Entry(false,now-1,20),
            new BillListPolicy.Entry(false,now+60_000,30),
            new BillListPolicy.Entry(true,now-1,50));
        BillListPolicy.Summary totals=BillListPolicy.summarize(sample,now);
        assertEquals(50L,totals.pendingAmount);
        assertEquals(1,totals.overdueCount);
        assertEquals(1,totals.soonCount);
        android.widget.HorizontalScrollView overview=NexaBillsUi.metrics(c,1,1,1);
        android.widget.LinearLayout row=(android.widget.LinearLayout)overview.getChildAt(0);
        assertEquals(3,row.getChildCount());
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,row.getLayoutDirection());
        assertNotNull(overview.getContentDescription());
        assertTrue(NexaBillsUi.status(c,false,true,false).getContentDescription().toString().contains("معوق"));
        assertTrue(NexaBillsUi.status(c,false,false,true).getContentDescription().toString().contains("هفت روز"));
        assertNotNull(new android.content.Intent(c,BillsActivity.class));
    }

    private Context context;

    @Test
    public void build204_caseOverviewDoesNotMutateSavedDatesAndControlsAreAccessible(){
        android.content.Context c = contextOrApp();
        long now = System.currentTimeMillis();
        long old = now - 4L * 24L * 60L * 60L * 1000L;
        long next = CaseOverviewPolicy.shownDate(old, "every:1:day", now);
        assertTrue("Recurring cases should show the next upcoming occurrence", next > now);
        assertEquals("One-time past case should keep its original date", old,
                CaseOverviewPolicy.shownDate(old, "none", now));
        assertFalse(CaseOverviewPolicy.isPast(next, now));
        assertTrue(CaseOverviewPolicy.matches("آینده", next, now));
        assertFalse(CaseOverviewPolicy.matches("گذشته", next, now));
        assertTrue(CaseOverviewPolicy.matches("گذشته", old, now));
        assertTrue(CaseOverviewPolicy.matches("همه", old, now));
        android.widget.HorizontalScrollView metrics = NexaCaseUi.metrics(c, 4, 3, 1);
        android.widget.LinearLayout row = (android.widget.LinearLayout) metrics.getChildAt(0);
        assertEquals(3, row.getChildCount());
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL, row.getLayoutDirection());
        assertNotNull(metrics.getContentDescription());
        android.widget.Button chip = NexaCaseUi.chip(c, "آینده", true);
        assertTrue(chip.getMinHeight() >= UiKit.dp(c, 48));
        assertTrue(chip.getContentDescription().toString().contains("انتخاب‌شده"));
        assertEquals("جلسه گذشته", NexaCaseUi.status(c, true).getContentDescription().toString());
        assertTrue(NexaCaseUi.empty(c, false).getMinimumHeight() >= UiKit.dp(c, 104));
        assertNotNull(new android.content.Intent(c, CaseActivity.class));
    }

    @Test
    public void build203_safetySummaryAndEmergencyControlsAreAccessible(){
        android.content.Context c=contextOrApp();
        android.widget.HorizontalScrollView calls=NexaSafetyUi.callMetrics(c,2,true,false);
        android.widget.LinearLayout callRow=(android.widget.LinearLayout)calls.getChildAt(0);
        assertEquals(3,callRow.getChildCount());
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,callRow.getLayoutDirection());
        assertNotNull(calls.getContentDescription());
        android.widget.LinearLayout contact=NexaSafetyUi.contactCard(c,"مخاطب","09120000000");
        assertTrue(contact.getMinimumHeight()>=UiKit.dp(c,84));
        assertNotNull(contact.getContentDescription());
        android.widget.HorizontalScrollView emergency=NexaSafetyUi.emergencyMetrics(c,false,true,false);
        assertEquals(3,((android.widget.LinearLayout)emergency.getChildAt(0)).getChildCount());
        assertFalse(emergency.getContentDescription().toString().contains("0912"));
        assertTrue(NexaSafetyUi.empty(c).getMinimumHeight()>=UiKit.dp(c,100));
        assertNotNull(new android.content.Intent(c,AllowedCallsActivity.class));
        assertNotNull(new android.content.Intent(c,EmergencyActivity.class));
    }

    @Test
    public void build202_focusMetricsCardsAndStatusStayAccessible(){
        android.content.Context c=contextOrApp();
        android.widget.HorizontalScrollView view=NexaFocusUi.metrics(c,3,2,5);
        assertEquals(3,((android.widget.LinearLayout)view.getChildAt(0)).getChildCount());
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,view.getChildAt(0).getLayoutDirection());
        assertNotNull(view.getContentDescription());
        android.widget.LinearLayout profile=NexaFocusUi.record(c,"⚡","جلسه","۴۵ دقیقه",UiKit.PURPLE);
        assertTrue(profile.getMinimumHeight()>=UiKit.dp(c,116));
        assertNotNull(profile.getContentDescription());
        android.widget.TextView state=NexaFocusUi.status(c,"فعال",UiKit.GREEN);
        assertTrue(state.getMinHeight()>=UiKit.dp(c,34));
        assertNotNull(state.getContentDescription());
        assertNotNull(new android.content.Intent(c,SilentHubActivity.class));
        assertNotNull(new android.content.Intent(c,ProfilesActivity.class));
    }

    @Test
    public void build201_archiveSurfacesUseRtlTouchTargetsAndScopeGuards(){
        android.content.Context c=contextOrApp();
        android.widget.HorizontalScrollView strip=NexaArchiveUi.metrics(c,
            new String[]{"همه","هفته","امروز"},new String[]{"18","6","2"},
            new int[]{UiKit.PURPLE,UiKit.BLUE,UiKit.GREEN});
        assertNotNull(strip.getChildAt(0));
        android.widget.LinearLayout items=(android.widget.LinearLayout)strip.getChildAt(0);
        assertEquals(3,items.getChildCount());
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,items.getLayoutDirection());
        assertTrue(NexaArchiveUi.chip(c,"۷ روز",true).getMinHeight()>=UiKit.dp(c,44));
        assertTrue(NexaArchiveUi.chip(c,"۷ روز",true).getContentDescription().toString().contains("انتخاب‌شده"));
        android.widget.LinearLayout record=NexaArchiveUi.record(c,"عنوان","شرح","ذخیره‌شده",UiKit.GREEN);
        assertTrue(record.getMinimumHeight()>=UiKit.dp(c,80));
        assertNotNull(record.getContentDescription());
        long now=System.currentTimeMillis();
        assertTrue(HistoryScopePolicy.matches("today",now,now,"ثبت","یادآوری","ثبت"));
        assertFalse(HistoryScopePolicy.matches("today",now-86_400_001L,now,"ثبت","یادآوری","ثبت"));
    }

    @Test
    public void build200_actionHubAndSearchFiltersStayTouchAccessible(){
        android.content.Context c=contextOrApp();
        android.widget.LinearLayout tile=NexaActionUi.tile(c,"💊","دارو","ثبت مصرف",4);
        assertTrue(tile.getMinimumHeight()>=UiKit.dp(c,112));
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,tile.getLayoutDirection());
        assertNotNull(tile.getContentDescription());
        android.widget.LinearLayout result=NexaActionUi.result(c,"📄 مدرک","موعد انقضا","سایر",true);
        assertTrue(result.getMinimumHeight()>=UiKit.dp(c,82));
        assertTrue(result.isClickable());
        assertTrue(NexaActionUi.categoryChip(c,"مالی",true).getMinHeight()>=UiKit.dp(c,44));
        assertTrue(SearchDisplayPolicy.matches(SearchDisplayPolicy.ALL,SearchDisplayPolicy.CARE));
        assertFalse(SearchDisplayPolicy.matches(SearchDisplayPolicy.FINANCE,SearchDisplayPolicy.HEALTH));
        assertTrue(SearchDisplayPolicy.compare(4,7,2,0)<0);
        assertTrue(SearchDisplayPolicy.compare(3,0,3,1)<0);
    }

    @Test
    public void build197_garageVisualsAreResponsiveRtlAndPreserveReadableActions(){
        android.content.Context c=contextOrApp();
        android.widget.LinearLayout metrics=NexaGarageUi.metrics(c,3,1,2);
        assertEquals(3,metrics.getChildCount());
        android.widget.LinearLayout serviceMetrics=NexaGarageUi.serviceMetrics(c,8,1,2);
        assertEquals(3,serviceMetrics.getChildCount());
        assertTrue(serviceMetrics.getChildAt(0).getContentDescription().toString().contains("سرویس"));
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,metrics.getLayoutDirection());
        for(int i=0;i<3;i++){
            android.view.View tile=metrics.getChildAt(i);
            assertTrue(tile.getMinimumHeight()>=UiKit.dp(c,78));
            assertNotNull(tile.getContentDescription());
        }
        android.widget.LinearLayout vehicle=NexaGarageUi.vehicleCard(c,true,false);
        assertTrue(vehicle.getMinimumHeight()>=UiKit.dp(c,112));
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,vehicle.getLayoutDirection());
        assertNotNull(vehicle.getBackground());
        assertNotNull(NexaGarageUi.serviceGroup(c,true,false).getBackground());
        assertTrue(NexaGarageUi.historyRecord(c).getMinimumHeight()>=UiKit.dp(c,76));
        assertTrue(NexaGarageUi.state(c,"نیازمند سرویس",UiKit.RED).getMinHeight()>=UiKit.dp(c,34));
        assertNotNull(NexaGarageUi.sectionLabel(c,"اطلاعات سرویس"));
    }

    @Test
    public void build196_documentsAndHomeCareShareAccessiblePremiumSurfaces(){
        android.content.Context c=contextOrApp();
        android.widget.LinearLayout strip=NexaCareUi.metrics(c,
                new String[]{"منقضی","نزدیک","معتبر"},new int[]{2,3,5},
                new int[]{UiKit.RED,UiKit.GOLD,UiKit.GREEN});
        assertEquals(3,strip.getChildCount());
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,strip.getLayoutDirection());
        for(int i=0;i<3;i++){
            assertTrue(strip.getChildAt(i).getMinimumHeight()>=UiKit.dp(c,78));
            assertNotNull(strip.getChildAt(i).getContentDescription());
        }
        android.widget.TextView chosen=NexaCareUi.filter(c,"منقضی",true);
        assertTrue(chosen.getMinHeight()>=UiKit.dp(c,44));
        assertTrue(chosen.getContentDescription().toString().contains("انتخاب‌شده"));
        android.widget.LinearLayout expired=NexaCareUi.record(c,true,false);
        assertNotNull(expired.getBackground());
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,expired.getLayoutDirection());
        assertTrue(expired.getMinimumHeight()>=UiKit.dp(c,90));
        assertNotNull(NexaCareUi.state(c,"منقضی",UiKit.RED).getBackground());
        assertNotNull(NexaCareUi.formHeading(c,"جزئیات"));
    }

    @Test
    public void build195_remindersPremiumUiPreservesActionsAndAccessibleFilters(){
        android.content.Context c=contextOrApp();
        android.widget.LinearLayout stats=NexaReminderUi.metrics(c,4,2,1);
        assertEquals(3,stats.getChildCount());
        for(int i=0;i<3;i++){
            android.view.View metric=stats.getChildAt(i);
            assertTrue(metric.getMinimumHeight()>=UiKit.dp(c,79));
            assertNotNull(metric.getContentDescription());
        }
        android.widget.TextView selected=NexaReminderUi.filterChip(c,"معوق",true);
        assertTrue(selected.getMinimumHeight()>=UiKit.dp(c,44));
        assertTrue(selected.getContentDescription().toString().contains("انتخاب‌شده"));
        android.widget.LinearLayout overdue=NexaReminderUi.reminderCard(c,true,false);
        assertTrue(overdue.getMinimumHeight()>=UiKit.dp(c,82));
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,overdue.getLayoutDirection());
        assertNotNull(NexaReminderUi.state(c,"معوق",UiKit.RED).getBackground());
        assertTrue(NexaReminderUi.formSection(c,"عنوان","توضیح").getChildCount()>=2);
    }

    @Test
    public void build193_globalPremiumDesignMaintainsFinancialSemanticColors(){
        android.content.Context c=contextOrApp();
        assertTrue(UiKit.screenBackground(c) instanceof NexaAuroraDrawable);
        assertEquals(0xFFF2C75C,UiKit.GOLD); // Credit stays yellow
        assertNotEquals(UiKit.RED,UiKit.PURPLE);
        assertNotEquals(UiKit.GREEN,UiKit.PURPLE);
        assertEquals(4,UiKit.bottomNav(c,0,null,null,null,null).getChildCount());
        assertNotNull(UiKit.primaryButton(c,"ثبت").getBackground());
    }

    @Test
    public void build193_financialMetricNativeAccessibility(){
        android.content.Context c=contextOrApp();
        android.widget.LinearLayout credit=UiKit.financialMetric(c,"طلب", "۱٬۲۰۰ تومان",UiKit.GOLD);
        assertEquals(2,credit.getChildCount());
        assertTrue(credit.getMinimumHeight()>=UiKit.dp(c,92));
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,credit.getLayoutDirection());
        assertTrue(credit.getContentDescription().toString().contains("۱٬۲۰۰"));
        android.widget.TextView value=(android.widget.TextView)credit.getChildAt(1);
        assertEquals(UiKit.GOLD,value.getCurrentTextColor());
    }

    @Test
    public void build192_settingsDirectorySearchAndReadableRows(){
        android.content.Context c=contextOrApp();
        assertTrue(SettingsDirectory.matches("🎵 انتخاب صدای هشدارها","باتری"));
        assertTrue(SettingsDirectory.matches("📋 وضعیت دسترسی‌ها","مجوز"));
        assertTrue(SettingsDirectory.matches("🔕 تشخیص خودکار Silent / Vibrate","سايلنت"));
        assertTrue(SettingsDirectory.matches("🛡 امنیت و پشتیبان‌گیری","بکاپ"));
        assertTrue(SettingsDirectory.matches("📱 سازگاری این دستگاه","سامسونگ"));
        assertFalse(SettingsDirectory.matches("👤 حساب کاربری و ایمیل","ساروس"));
        android.widget.LinearLayout row=UiKit.settingsDirectoryRow(c,"🔋","باتری و شارژ","وضعیت شارژ");
        assertEquals(3,row.getChildCount());
        assertTrue(row.getMinimumHeight()>=UiKit.dp(c,70));
        assertTrue(row.isClickable()&&row.isFocusable());
    }

    @Test
    public void build191_nativeDesignSystemKeepsReadableActionsAndAllDirectoryEntries(){
        android.content.Context c=contextOrApp();
        assertNotNull(UiKit.featureDirectoryRow(c,"🔋","باتری و شارژ",1));
        android.widget.LinearLayout row=UiKit.featureDirectoryRow(c,"🔐","امنیت و حریم خصوصی",2);
        assertEquals("باز کردن امنیت و حریم خصوصی",row.getContentDescription().toString());
        assertTrue(row.getMinimumHeight()>=UiKit.dp(c,60));
        assertEquals(3,row.getChildCount());
        assertEquals(19,FeatureEmoji.directoryIcons().length);
        assertTrue(UiKit.primaryButton(c,"افزودن").getMinHeight()>=UiKit.dp(c,48));
        assertTrue(UiKit.secondaryButton(c,"انصراف").getMinHeight()>=UiKit.dp(c,48));
        assertTrue(UiKit.masterHero(c,"🔔","یادآورها","اطلاع‌رسانی",2).getChildCount()>=2);
    }

    @Test
    public void build190_manualMutePromptRemembersPreMuteMode(){
        // On entering Silent via system quick settings, the prompt sees current
        // mode SILENT but MUST restore the mode from the preceding broadcast.
        assertEquals(android.media.AudioManager.RINGER_MODE_NORMAL,
                ManualTimerRestorePolicy.originalMode(2,0));
        assertEquals(android.media.AudioManager.RINGER_MODE_VIBRATE,
                ManualTimerRestorePolicy.originalMode(1,0));
        assertEquals(android.media.AudioManager.RINGER_MODE_NORMAL,
                ManualTimerRestorePolicy.originalMode(-1,0));
        assertEquals(android.media.AudioManager.RINGER_MODE_NORMAL,
                ManualTimerRestorePolicy.originalMode(0,0));
        assertEquals(android.media.AudioManager.RINGER_MODE_SILENT,
                ManualTimerRestorePolicy.originalMode(0,1));
    }

    @Test
    public void build189_expiryRecoveryOnlyOwnsRealDueTimer(){
        assertFalse(TimerExpiryRecovery.isDue(0L,10000L));
        assertFalse(TimerExpiryRecovery.isDue(12000L,10000L));
        assertTrue(TimerExpiryRecovery.isDue(10000L,10000L));
        assertTrue(TimerExpiryRecovery.isDue(10000L,10001L));
        assertTrue(TimerExpiryRecovery.isDue(10000L,8500L));
    }

    @Test
    public void build189_unplugCancelsChargeNotificationWithoutChangingTheftSettings(){
        android.app.NotificationManager nm=(android.app.NotificationManager)
                contextOrApp().getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        boolean theftEnabled=AppPrefs.isTheftGuardEnabled(contextOrApp());
        BatteryAlertManager.onChargerDisconnected(contextOrApp());
        assertEquals(theftEnabled, AppPrefs.isTheftGuardEnabled(contextOrApp()));
        assertFalse(BatteryAlarmActionReceiver.OWNER_CHARGE.equals(NexaAudioController.getActiveOwner()));
    }

    @Test
    public void build184_cardNumberValidation_andLegacyBankCardAreSafe() throws Exception {
        assertEquals("6037991234567890",PaymentCardSecrets.digits("۶۰۳۷ ۹۹۱۲ ۳۴۵۶ ۷۸۹۰"));
        assertTrue(PaymentCardSecrets.isValid("6037 9912 3456 7890"));
        assertFalse(PaymentCardSecrets.isValid("6037 9912 3456"));
        assertFalse(PaymentCardSecrets.isValid("6037 99XX 3456 7890"));
        NexaStore.BankCard old=new NexaStore.BankCard();
        old.bank="بانک نمونه";old.last4="7890";
        org.json.JSONObject json=old.json();
        assertFalse("Full PAN must never be serialized in standard JSON",json.has("number"));
        NexaStore.BankCard loaded=NexaStore.BankCard.from(json);
        assertEquals("",loaded.owner);
        assertEquals("7890",loaded.last4);
        loaded.owner="علی رضایی";
        assertEquals("علی رضایی",NexaStore.BankCard.from(loaded.json()).owner);
    }

    @Test
    public void build188_dashboardResponsiveRules_requireStackOnSmallScreens(){
        android.content.res.Resources res=contextOrApp().getResources();
        // The new dashboard shares one explicit sizing rule between money cards
        // and shortcuts; no content is hidden or removed when the font is enlarged.
        assertNotNull(res);
        assertNotNull(HomeUi.panel(contextOrApp(),true));
        assertTrue(HomeUi.directoryLink(contextOrApp(),"همه بخش‌ها").getMinHeight()>0);
        assertEquals(19,FeatureEmoji.count());
    }

    @Test
    public void build208_annualOccasionsPreserveOriginalLeapDatesAndPersistence(){
        OccasionStore.Occasion e=new OccasionStore.Occasion();
        e.type="birthday";e.title="تولد آزمایشی";e.calendar="gregorian";
        e.year=2020;e.month=2;e.day=29;e.hour=9;e.minute=0;
        assertTrue(AnnualOccasionDates.valid(e.calendar,e.year,e.month,e.day));
        assertFalse(AnnualOccasionDates.valid("gregorian",2025,2,29));
        java.util.Calendar year=java.util.Calendar.getInstance();
        year.setTimeInMillis(AnnualOccasionDates.yearDate(e.calendar,2025,e.month,e.day,e.hour,e.minute));
        assertEquals(28,year.get(java.util.Calendar.DAY_OF_MONTH));
        year.setTimeInMillis(AnnualOccasionDates.yearDate(e.calendar,2028,e.month,e.day,e.hour,e.minute));
        assertEquals(29,year.get(java.util.Calendar.DAY_OF_MONTH));
        Context c=contextOrApp();OccasionStore.save(c,e);
        try{
            OccasionStore.Occasion loaded=OccasionStore.find(c,e.id);
            assertNotNull(loaded);assertEquals(29,loaded.day);
            assertTrue(AnnualOccasionDates.next(loaded,System.currentTimeMillis())>System.currentTimeMillis());
        }finally{OccasionStore.delete(c,e.id);}
    }

    private Context contextOrApp(){
        return androidx.test.core.app.ApplicationProvider.getApplicationContext();
    }

    @Test
    public void build187_directoryRestoresOriginalColorEmojiWithoutRemovingDestinations(){
        String[] emoji=FeatureEmoji.directoryIcons();
        assertEquals("The original 18 entries and annual occasions must have emoji",19,emoji.length);
        assertEquals("⚖️",emoji[6]);
        assertEquals("☁️",emoji[7]);
        assertEquals("🔕",emoji[8]);
        assertEquals("🔋",emoji[9]);
        assertEquals("🔐",emoji[10]);
        assertEquals("🆘",emoji[11]);
        assertEquals("🔎",emoji[13]);
        assertEquals("🕒",emoji[14]);
        for(String item:emoji) assertTrue(item!=null && !item.trim().isEmpty());
        // A consumer cannot change the shared icon catalog in place.
        emoji[0]="deleted";
        assertEquals("💊",FeatureEmoji.directoryIcons()[0]);
        assertEquals("🎂",FeatureEmoji.directoryIcons()[18]);
    }

    @Test
    public void build186_directorySearch_handlesPersianArabicVariantsAndAliases(){
        assertTrue(FeatureSearch.matches("قبوض و اقساط", "پرداخت قبض", "امور مالی", "قسط"));
        assertTrue(FeatureSearch.matches("قبوض و اقساط", "پرداخت قبض", "امور مالی", "قبض"));
        assertTrue(FeatureSearch.matches("قبوض و اقساط", "پرداخت قبض", "امور مالی", "مالی قسط"));
        assertTrue(FeatureSearch.matches("امنیت و حریم خصوصی", "قفل", "تنظیمات", "حريم خصوصي"));
        assertFalse(FeatureSearch.matches("هواشناسی", "آب و هوا", "زندگی", "قبض"));
        assertEquals("کارت بانکی",FeatureSearch.normalize("كارت\u200cبانكي"));
    }

    @Test
    public void build185_paymentAmountMustBePositive_forAllEntryPaths(){
        assertFalse(BillFormRules.validAmount(0));
        assertFalse(BillFormRules.validAmount(-1));
        assertTrue(BillFormRules.validAmount(1));
        assertTrue(BillFormRules.validAmount(2700000L));
    }

    @Test
    public void homeDashboardRefresh_isThrottledButForcedOnReturnOrClockRollback(){
        long start=1_700_000_000_000L;
        assertTrue(HomeRefreshGate.due(start,0,HomeRefreshGate.OVERVIEW_MS));
        assertFalse(HomeRefreshGate.due(start+1000,start,HomeRefreshGate.OVERVIEW_MS));
        assertTrue(HomeRefreshGate.due(start+30_000,start,HomeRefreshGate.OVERVIEW_MS));
        assertFalse(HomeRefreshGate.due(start+59_999,start,HomeRefreshGate.FINANCE_MS));
        assertTrue(HomeRefreshGate.due(start+60_000,start,HomeRefreshGate.FINANCE_MS));
        assertTrue(HomeRefreshGate.due(start-10_000,start,HomeRefreshGate.FINANCE_MS));
    }

    @Test
    public void mainHomeDashboard_isAttachedAndScrollableAboveBottomNavigation(){
        // Build 180 had the bottom bar only, despite constructing the dashboard.
        android.widget.LinearLayout screen=new android.widget.LinearLayout(context);
        screen.setOrientation(android.widget.LinearLayout.VERTICAL);
        android.widget.ScrollView content=new android.widget.ScrollView(context);
        android.widget.LinearLayout dashboard=new android.widget.LinearLayout(context);
        dashboard.addView(new android.widget.TextView(context));
        content.addView(dashboard);
        android.widget.LinearLayout navigation=new android.widget.LinearLayout(context);
        MainActivity.attachHomeContent(screen,content,navigation,
                new android.widget.LinearLayout.LayoutParams(-1,-2));
        assertEquals("The home screen must contain both dashboard and nav",2,screen.getChildCount());
        assertSame("Dashboard must be first",content,screen.getChildAt(0));
        assertSame("Navigation must be last",navigation,screen.getChildAt(1));
        android.widget.LinearLayout.LayoutParams params=
                (android.widget.LinearLayout.LayoutParams)content.getLayoutParams();
        assertEquals(0,params.height);
        assertEquals(1f,params.weight,0f);
        assertEquals(1,content.getChildCount());
        assertTrue("Dashboard cannot be empty",dashboard.getChildCount()>0);
    }

    @Test
    public void voiceFinancialCommands_requireClearPartyAndFinancialDirection(){
        VoiceCommandParser.Finance debt=VoiceCommandParser.finance("۵۰ میلیون بدهی به احمدی ثبت کن");
        assertNotNull(debt);
        assertEquals("DEBT",debt.kind);
        assertEquals("احمدی",debt.party);
        assertEquals(50_000_000L,debt.amount);
        VoiceCommandParser.Finance credit=VoiceCommandParser.finance("پنجاه میلیون طلب از احمدی ثبت کن");
        assertNotNull(credit);
        assertEquals("CREDIT",credit.kind);
        assertEquals(50_000_000L,credit.amount);
        assertNull(VoiceCommandParser.finance("۵۰ میلیون بدهکار احمدی"));
        assertNull(VoiceCommandParser.finance("۵۰ میلیون ریال بدهی به احمدی"));
        assertEquals(25_000_000L,VoiceCommandParser.amountToman("۲۵٬۰۰۰٬۰۰۰ تومان"));
        assertEquals(50_200_000L,VoiceCommandParser.amountToman("۵۰ میلیون و ۲۰۰ هزار"));
        assertEquals(123_450_000L,VoiceCommandParser.amountToman("صد و بیست و سه میلیون و چهارصد و پنجاه هزار تومان"));
        assertEquals(0L,VoiceCommandParser.amountToman("۵۰ میلیون و ۲۰۰"));
        assertEquals(0L,VoiceCommandParser.amountToman("۵۰ میلیون تومان و ۲۰۰ هزار"));
        assertNull(VoiceCommandParser.finance("۵۰ هزار و ۲ میلیون بدهی به احمدی"));
        assertNull(VoiceCommandParser.finance("۵۰ میلیون بدهی به احمدی و طلب از رضا"));
        VoiceCommandParser.Finance compound=VoiceCommandParser.finance("۵۰ میلیون و ۲۰۰ هزار بدهی به احمدی");
        assertNotNull(compound);
        assertEquals(50_200_000L,compound.amount);
        VoiceCommandParser.Finance creditNatural=VoiceCommandParser.finance("پنجاه میلیون از احمدی طلب دارم");
        assertNotNull(creditNatural);
        assertEquals("احمدی",creditNatural.party);
        assertEquals("فردا با احمدی تماس بگیرم",
                VoiceCommandParser.reminderTitle("یادم بنداز فردا با احمدی تماس بگیرم"));
    }

    @Test
    public void billVoiceDraft_amountAndRecurringRuleRequireExplicitValidMoney(){
        VoiceCommandParser.FormDraft f=VoiceCommandParser.nonFinancialForm(
                "قبض جدید برق خانه هر ماه مبلغ ۲۵۰ هزار تومان ثبت کن");
        assertNotNull(f);
        assertEquals("bills",f.destination);
        assertEquals("قبض",f.type);
        assertEquals("برق خانه",f.title);
        assertEquals(250_000L,f.amount);
        assertEquals("every:1:month",f.recurrence);
        VoiceCommandParser.FormDraft c=VoiceCommandParser.nonFinancialForm(
                "قسط جدید بانک ملت مبلغ ۵۰ میلیون و ۲۰۰ هزار تومان");
        assertNotNull(c);
        assertEquals("بانک ملت",c.title);
        assertEquals(50_200_000L,c.amount);
        assertEquals("none",c.recurrence);
        VoiceCommandParser.FormDraft draft=VoiceCommandParser.nonFinancialForm("قسط جدید پژو ۲۰۷");
        assertNotNull(draft);
        assertEquals("پژو 207",draft.title);
        assertEquals(0L,draft.amount); // A number in the title is not the amount.
        assertNull(VoiceCommandParser.nonFinancialForm("قبض جدید برق خانه مبلغ ۵۰ میلیون و ۲۰۰"));
        assertNull(VoiceCommandParser.nonFinancialForm("قبض جدید برق خانه مبلغ ۵۰ میلیون ریال"));
        assertNull(VoiceCommandParser.nonFinancialForm("قبض جدید برق خانه مبلغ -۵۰ تومان"));
        assertNull(VoiceCommandParser.nonFinancialForm("قبض جدید برق خانه ۲۰۰ هزار تومان"));
    }

    @Test
    public void voiceMedicineDraft_opensEditableFormAndNeverGuessesDosage(){
        VoiceCommandParser.FormDraft medication=VoiceCommandParser.nonFinancialForm(
                "داروی جدید استامینوفن ثبت کن");
        assertNotNull(medication);
        assertEquals("medicine",medication.destination);
        assertEquals("استامینوفن",medication.title);
        assertEquals(0L,medication.amount);
        assertEquals("none",medication.recurrence);
        VoiceCommandParser.FormDraft supplement=VoiceCommandParser.nonFinancialForm(
                "دارو جدید ویتامین D3 اضافه کن");
        assertNotNull(supplement);
        assertEquals("ویتامین D3",supplement.title);
        assertNull(VoiceCommandParser.nonFinancialForm("داروی جدید"));
        assertNull(VoiceCommandParser.nonFinancialForm("پزشک دارو بده"));
    }

    @Test
    public void voiceNonFinancialForms_arePrefilledButNotAutoCommitted(){
        VoiceCommandParser.FormDraft todo=VoiceCommandParser.nonFinancialForm("کار جدید خرید کتاب ثبت کن");
        assertNotNull(todo);
        assertEquals("todo",todo.destination);
        assertEquals("خرید کتاب",todo.title);
        VoiceCommandParser.FormDraft shopping=VoiceCommandParser.nonFinancialForm("لیست خرید مهمانی درست کن");
        assertNotNull(shopping);
        assertEquals("shopping",shopping.destination);
        assertEquals("مهمانی",shopping.title);
        assertNull(VoiceCommandParser.nonFinancialForm("۵۰ میلیون بدهی به احمدی ثبت کن"));
        assertNull(VoiceCommandParser.nonFinancialForm("کار"));
        VoiceCommandParser.FormDraft asset=VoiceCommandParser.nonFinancialForm("دارایی جدید طلای جوادی ثبت کن");
        assertNotNull(asset);
        assertEquals("assets",asset.destination);
        assertEquals("طلای جوادی",asset.title);
        VoiceCommandParser.FormDraft vehicle=VoiceCommandParser.nonFinancialForm("وسیله جدید پژو ۲۰۷ من");
        assertNotNull(vehicle);
        assertEquals("vehicle",vehicle.destination);
        assertEquals("پژو 207 من",vehicle.title);
        assertEquals("every:2:week",VoiceCommandParser.spokenRecurrence("یادم بنداز هر دو هفته برم شرکت"));
        assertEquals("every:3:month",VoiceCommandParser.spokenRecurrence("هر ۳ ماه یک بار"));
        assertEquals("none",VoiceCommandParser.spokenRecurrence("یادم بنداز به احمدی زنگ بزنم"));
    }

    @Test
    public void previewRecurringDates_doNotMutateReminderOrCreateExtraAlarms(){
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=PersianDateUtil.toMillis(1405,8,5,9,30);
        r.recurrence="every:2:week";
        long first=r.whenMillis;
        long[] next=ReminderRecurrence.previewFollowing(first,r.recurrence,2);
        assertEquals(2,next.length);
        assertEquals(ReminderRecurrence.oneStep(first,r.recurrence),next[0]);
        assertEquals(ReminderRecurrence.oneStep(next[0],r.recurrence),next[1]);
        assertEquals(first,r.whenMillis);
        assertEquals(0,ReminderRecurrence.previewFollowing(first,"none",2).length);
        assertEquals(6,ReminderRecurrence.previewFollowing(first,"weekly",1000).length);
    }

    @Test
    public void recurringReminder_completionArchiveSurvivesSerializationAndAdvancement()throws Exception{
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.recurrence="every:2:week";
        r.whenMillis=PersianDateUtil.toMillis(1405,8,5,10,0);
        long old=r.whenMillis;
        ReminderRecurrence.recordCompleted(r);
        ReminderRecurrence.recordCompleted(r);
        assertEquals(old,ReminderRecurrence.lastCompletedDue(r));
        assertEquals(Long.toString(old),r.completedDueDates);
        assertTrue(ReminderRecurrence.advanceAfterDone(r,old+1));
        assertFalse(r.done);
        assertTrue(r.whenMillis>old);
        NexaStore.Reminder restored=NexaStore.Reminder.from(r.json());
        assertEquals(old,ReminderRecurrence.lastCompletedDue(restored));
        assertEquals(r.whenMillis,restored.whenMillis);
    }


    @Test
    public void soundPreferences_remainSavedForEachProfile() {
        int[] profiles={NexaAudioController.SOUND_ALARM,NexaAudioController.SOUND_REMINDER,
                NexaAudioController.SOUND_BATTERY,NexaAudioController.SOUND_THEFT,
                NexaAudioController.SOUND_SILENT_EXIT};
        for(int profile:profiles){
            android.net.Uri before=AlarmSoundSelection.chosen(context,profile);
            try{
                android.net.Uri selected=android.net.Uri.parse(
                    "android.resource://"+context.getPackageName()+"/raw/nexa_charge_alarm");
                AlarmSoundSelection.save(context,profile,selected);
                assertEquals(selected,AlarmSoundSelection.chosen(context,profile));
                assertEquals(selected,AlarmSoundSelection.resolve(context,profile));
            }finally{AlarmSoundSelection.save(context,profile,before);}
        }
    }

    @Test
    public void chargerDisconnection_stopsThresholdAlarmWithoutResettingPreferences() {
        boolean enabled=AppPrefs.isChargeAlarmEnabled(context);
        boolean latched=AppPrefs.isChargeAlarmLatched(context);
        try{
            AppPrefs.setChargeAlarmEnabled(context,true);
            AppPrefs.setChargeAlarmLatched(context,true);
            BatteryAlertManager.onChargerDisconnected(context);
            // The alarm must not re-arm at the same percentage just because a cable moved.
            assertTrue(AppPrefs.isChargeAlarmLatched(context));
            assertTrue(AppPrefs.isChargeAlarmEnabled(context));
        }finally{
            AppPrefs.setChargeAlarmLatched(context,latched);
            AppPrefs.setChargeAlarmEnabled(context,enabled);
        }
    }

    @Test
    public void recurrence_customIntervalsAreCalendarBasedAndBackwardsCompatible() {
        java.util.TimeZone old=java.util.TimeZone.getDefault();
        try {
            java.util.TimeZone.setDefault(java.util.TimeZone.getTimeZone("Asia/Tehran"));
            long start=PersianDateUtil.toMillis(1405,8,5,10,30);
            long alternateWeek=ReminderRecurrence.oneStep(start,"every:2:week");
            assertEquals(14L*24L*60L*60L*1000L,alternateWeek-start);
            int[] month=PersianDateUtil.fromMillis(ReminderRecurrence.oneStep(start,"every:1:month"));
            assertArrayEquals(new int[]{1405,9,5},month);
            assertEquals("FREQ=WEEKLY;INTERVAL=2",ReminderCalendarExport.recurrenceRule("biweekly"));
            assertEquals("FREQ=WEEKLY;INTERVAL=2",ReminderCalendarExport.recurrenceRule("every:2:week"));
            assertFalse(ReminderRecurrence.isRecurring("none"));
            assertTrue(ReminderRecurrence.isRecurring("ماهانه"));
            assertEquals("ماهانه (نسخه قدیمی)",ReminderRecurrence.label("monthly"));
        } finally { java.util.TimeZone.setDefault(old); }
    }

    @Test
    public void recurrence_financeForecastDoesNotCreateNewTransactions() {
        long start=System.currentTimeMillis()+24L*60L*60L*1000L;
        java.util.List<BillForecast.Entry> bills=java.util.Collections.singletonList(
                new BillForecast.Entry("bill","قبض","قبض",900,start,"every:2:week",false));
        BillForecast.Result f=BillForecast.calculate(bills,System.currentTimeMillis(),60);
        assertEquals(5,f.upcoming.size());
        assertEquals(4500L,f.upcomingTotal);
        assertFalse(f.upcoming.get(0).projected);
        assertTrue(f.upcoming.get(1).projected);
    }

    @Test
    public void listShare_defaultScopeExcludesDone() {
        java.util.List<ListShareExport.Entry> items=java.util.Arrays.asList(
            new ListShareExport.Entry("نان", "۲ عدد", "خوراکی", false, true),
            new ListShareExport.Entry("شیر", "۱ لیتر", "خوراکی", true, false));
        assertEquals(1,ListShareExport.select(items,false).size());
        assertEquals(2,ListShareExport.select(items,true).size());
        String text=ListShareExport.text("خانه",items,false,false);
        assertTrue(text.contains("نان"));
        assertFalse(text.contains("شیر"));
        assertTrue(text.contains("⭐"));
    }

    @Test
    public void listShare_csvPersianAndExcelFormulaProtection() {
        java.util.List<ListShareExport.Entry> items=java.util.Collections.singletonList(
            new ListShareExport.Entry("=HYPERLINK(\"bad\")", "۱ عدد", "+A1", false, false));
        String csv=ListShareExport.csv("خرید",items,false,false);
        assertTrue(csv.startsWith("\ufeff"));
        assertTrue(csv.contains("\r\n"));
        assertTrue(csv.contains("'="));
        assertTrue(csv.contains("'+A1"));
        assertTrue(csv.contains("\"\"bad\"\""));
    }

    @Test
    public void listShare_untrustedLineBreaksCannotForgeRows() {
        java.util.List<ListShareExport.Entry> entries=java.util.Collections.singletonList(
            new ListShareExport.Entry("قلم\r\nسطر دوم", "۱\nکیلو", "خوراکی", false, false));
        String text=ListShareExport.text("خانه\nشخصی",entries,false,false);
        assertTrue(text.contains("خانه شخصی"));
        assertTrue(text.contains("قلم سطر دوم"));
        assertFalse(text.contains("قلم\r\nسطر دوم"));
        String csv=ListShareExport.csv("خانه",entries,false,false);
        assertEquals(3,csv.split("\r\n",-1).length);
    }

    @Test
    public void listShare_todoUsesOnlyExplicitDisplayFields() {
        java.util.List<ListShareExport.Entry> entries=java.util.Collections.singletonList(
            new ListShareExport.Entry("تماس با دکتر", "۱۴۰۵/۰۸/۰۱", "شخصی", false, false));
        String csv=ListShareExport.csv("کارهای روزانه",entries,false,true);
        assertTrue(csv.contains("۱۴۰۵/۰۸/۰۱"));
        assertTrue(csv.contains("\"کار\""));
        assertFalse(csv.contains("bankCardId"));
        assertFalse(csv.contains("sellerQuotedTotal"));
    }

    @Test
    public void listShare_ignoresNullAndEmptyEntries() {
        java.util.List<ListShareExport.Entry> entries=java.util.Arrays.asList(null,
            new ListShareExport.Entry("", "", "", false, false),
            new ListShareExport.Entry("​", "", "", false, false));
        assertTrue(ListShareExport.select(entries,true).isEmpty());
        assertTrue(ListShareExport.select(null,false).isEmpty());
    }

    @Test
    public void numberFormat_fullwidthInput_normalizesWithoutPrecisionLoss() {
        assertEquals("1234567890", NumberFormatUtil.toLatin("１２３４５６７８９０"));
        assertEquals("+1,234,567", NumberFormatUtil.groupIntegerText("＋１２３４５６７"));
        assertEquals("-1,234,567", NumberFormatUtil.groupIntegerText("－１２３４５６７"));
        assertEquals("+1,234.0500", NumberFormatUtil.groupDecimalText("＋１２３４．０５００"));
        assertEquals("-1,234.0500", NumberFormatUtil.groupDecimalText("－１２３４．０５００"));
        assertEquals("9,223,372,036,854,775,808", NumberFormatUtil.groupIntegerText("９２２３３７２０３６８５４７７５８０８"));
        assertEquals("1,234", NumberFormatUtil.groupIntegerText("۱۲۳۴"));
    }

    @Test
    public void numberFormat_copiedLocaleGroupingSeparators() {
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1\u202F234\u202F567"));
        assertEquals("-1,234,567", NumberFormatUtil.groupIntegerText("−1\u00A0234\u00A0567"));
        assertEquals("1,234,567.0500", NumberFormatUtil.groupDecimalText("1\u202F234\u00A0567٫۰۵۰۰"));
        assertEquals("123 4567", NumberFormatUtil.groupIntegerText("123 4567"));
        assertEquals(1234567L, NumberFormatUtil.longValue("1\u202F234\u00A0567"));
        assertEquals(1234567, NumberFormatUtil.intValue("1\u202F234\u00A0567"));
        assertEquals(1234.5, NumberFormatUtil.doubleValue("1\u202F234.5"), 0.000001);
    }

    @Test
    public void numberFormat_caretMappingAcrossLocaleSeparators() {
        assertEquals(5, NumberFormatUtil.mappedCaret("1\u202F234", "1,234", 5));
        assertEquals(5, NumberFormatUtil.mappedCaret("1\u00A0234", "1,234", 5));
        assertEquals(2, NumberFormatUtil.mappedCaret("1\u202F234", "1,234", 2));
        assertEquals(2, NumberFormatUtil.mappedCaret("1\u00A0234", "1,234", 2));
        assertEquals(1, NumberFormatUtil.mappedCaret("1\u202F234", "1,234", 1));
        assertEquals(6, NumberFormatUtil.mappedCaret("1\u202F234\u00A0567", "1,234,567", 6));
        assertEquals(9, NumberFormatUtil.mappedCaret("1\u202F234\u00A0567", "1,234,567", 9));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1\u202F234\u00A0567"));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1٬234٬567"));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("1\u2009234\u2007567"));
        assertEquals("-1,234.0500", NumberFormatUtil.groupDecimalText("-1\u2009234.0500"));
        assertEquals(1234567L, NumberFormatUtil.longValue("1\u2009234\u2007567"));
        assertEquals(1234567, NumberFormatUtil.intValue("1\u2009234\u2007567"));
        assertEquals(2, NumberFormatUtil.mappedCaret("1\u2009234", "1,234", 2));
        assertEquals(5, NumberFormatUtil.mappedCaret("1\u2007234", "1,234", 5));
    }

    @Test
    public void numberFormat_intValue_saturatesBeyondLongWithoutWrapping() {
        assertEquals(Integer.MAX_VALUE, NumberFormatUtil.intValue("9,223,372,036,854,775,808"));
        assertEquals(Integer.MIN_VALUE, NumberFormatUtil.intValue("-9,223,372,036,854,775,809"));
        assertEquals(Integer.MAX_VALUE, NumberFormatUtil.intValue("۲۱۴۷۴۸۳۶۴۸"));
        assertEquals(Integer.MIN_VALUE, NumberFormatUtil.intValue("-۲۱۴۷۴۸۳۶۴۹"));
        assertEquals(2147483647, NumberFormatUtil.intValue("2,147,483,647"));
        assertEquals(-2147483648, NumberFormatUtil.intValue("-2,147,483,648"));
        assertEquals(0, NumberFormatUtil.intValue("not a number"));
    }

    @Test
    public void numberFormat_longValue_saturatesOverflowAndParsesLocalizedDigits() {
        assertEquals(Long.MAX_VALUE, NumberFormatUtil.longValue("9,223,372,036,854,775,807"));
        assertEquals(Long.MIN_VALUE, NumberFormatUtil.longValue("-9,223,372,036,854,775,808"));
        assertEquals(Long.MAX_VALUE, NumberFormatUtil.longValue("9,223,372,036,854,775,808"));
        assertEquals(Long.MIN_VALUE, NumberFormatUtil.longValue("-9,223,372,036,854,775,809"));
        assertEquals(Long.MAX_VALUE, NumberFormatUtil.longValue("۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹"));
        assertEquals(Long.MIN_VALUE, NumberFormatUtil.longValue("-９９９９９９９９９９９９９９９９９９９９９９"));
        assertEquals(1234567L, NumberFormatUtil.longValue("＋۱٬۲۳۴٬۵۶۷"));
        assertEquals(0L, NumberFormatUtil.longValue("invalid"));
    }

    @Test
    public void weather_delayedResponseMustNotReplaceDifferentSelectedCity() {
        WeatherRepository.Data d = new WeatherRepository.Data();
        d.city = "تهران";
        assertTrue(WeatherRepository.shouldSaveResult("تهران", d));
        assertFalse(WeatherRepository.shouldSaveResult("اصفهان", d));
        assertFalse(WeatherRepository.shouldSaveResult("", d));
        assertFalse(WeatherRepository.shouldSaveResult("تهران", null));
    }

    @Test
    public void weather_cacheMustMatchRequestedCityAndValidTimestamp() {
        WeatherRepository.Data d = new WeatherRepository.Data();
        d.city = "تهران";
        d.updatedAt = 1000000L;
        assertTrue(WeatherRepository.matchesCity(d, " تهران "));
        assertFalse(WeatherRepository.matchesCity(d, "اصفهان"));
        assertFalse(WeatherRepository.matchesCity(null, "تهران"));
        assertTrue(WeatherRepository.usableCache(d, 1000000L));
        assertFalse(WeatherRepository.usableCache(d, 0L));
        d.updatedAt = 0L;
        assertFalse(WeatherRepository.usableCache(d, 1000000L));
    }

    @Test
    public void weather_backgroundAlertsRequireEnabledCurrentCityAndValidForecast() {
        WeatherRepository.Data d = new WeatherRepository.Data();
        d.city = "تهران";
        d.updatedAt = System.currentTimeMillis();
        assertTrue(WeatherAlertReceiver.shouldNotifyForSelection(true," تهران ",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(false,"تهران",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"اصفهان",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"",d));
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"تهران",null));
        d.updatedAt = 0L;
        assertFalse(WeatherAlertReceiver.shouldNotifyForSelection(true,"تهران",d));
    }

    @Test
    public void medicineCourse_preventsAlertsAfterEndOrDisableAndBoundsRepeats() {
        NexaStore.Medicine m = new NexaStore.Medicine();
        m.active = true;
        m.nextDoseMillis = 1000L;
        m.endMillis = 2000L;
        assertTrue(MedicineScheduler.canSchedule(m, 2000L));
        assertFalse(MedicineScheduler.canSchedule(m, 2001L));
        assertFalse(MedicineScheduler.canSchedule(m, 0L));
        m.active = false;
        assertFalse(MedicineScheduler.canSchedule(m, 1500L));
        m.active = true;
        m.endMillis = 0L;
        assertTrue(MedicineScheduler.canSchedule(m, 3000L));
        assertEquals(300000L, MedicineScheduler.nextRepeatAt(0L, 0));
        assertEquals(60000L, MedicineScheduler.nextRepeatAt(0L, 1));
        assertEquals(Long.MAX_VALUE, MedicineScheduler.nextRepeatAt(Long.MAX_VALUE-1, 5));
    }

    @Before
    public void setUp() {
        context = ApplicationProvider.getApplicationContext();
    }

    @Test
    public void assetFinance_karizmaPurchases_noTenfoldInflation() {
        NexaStore.AssetEntry first = new NexaStore.AssetEntry();
        first.amount = 9.34; first.buyUnitPrice = 3312000d;
        NexaStore.AssetEntry second = new NexaStore.AssetEntry();
        second.amount = 0.22; second.buyUnitPrice = 3295711.7d;
        java.util.List<NexaStore.AssetEntry> entries = java.util.Arrays.asList(first, second);
        double expected = 9.34d * 3312000d + 0.22d * 3295711.7d;
        assertEquals(expected, AssetFinanceEngine.totalOpenCost(entries), 0.01d);
        assertTrue(AssetFinanceEngine.totalOpenCost(entries) < 40000000d);
    }

    @Test
    public void financialDisplay_persianDigitsDoNotChangeRawArithmetic() {
        assertEquals("۳۵٬۰۹۶٬۰۲۴٫۵", PersianFinancialDisplay.digits("35,096,024.5"));
        assertEquals("", PersianFinancialDisplay.digits(null));
        assertEquals(9.34d*3312000d, 30934080d, 0.01d);
    }

    @Test
    public void assetSell_rejectsNonFiniteStoredValuesWithoutMutation() {
        NexaStore.AssetEntry x = new NexaStore.AssetEntry();
        x.amount=2; x.buyUnitPrice=100; x.fee=10;
        x.realizedProfit=Double.NaN;
        assertFalse(AssetFinanceEngine.sell(x,1,150,123L));
        assertEquals(2d,x.amount,0d);
        assertEquals(10d,x.fee,0d);
        x.realizedProfit=0;
        assertFalse(AssetFinanceEngine.sell(x,2,Double.MAX_VALUE,123L));
        assertEquals(2d,x.amount,0d);
        assertTrue(AssetFinanceEngine.sell(x,1,150,123L));
        assertEquals(1d,x.amount,0d);
        assertEquals(45d,x.realizedProfit,0.001d);
        assertEquals(5d,x.fee,0d);
    }

    @Test
    public void medicineDoseLogs_roundTripAndClear_areStable() {
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = "regression-med";
        log.scheduledAt = 1700000000000L;
        log.takenAt = 1700000300000L;

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        NexaStore.addMedicineDoseLog(context, log);

        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, "regression-med");
        assertEquals(1, saved.size());
        assertEquals(1700000300000L, saved.get(0).takenAt);

        NexaStore.clearMedicineDoseLogs(context, "regression-med");
        assertTrue(NexaStore.medicineDoseLogsFor(context, "regression-med").isEmpty());
    }

    @Test
    public void cryptoSymbol_normalizationAndProviderSupport() {
        assertEquals("ETH", CryptoSymbol.normalize(" eth "));
        assertEquals("USDT", CryptoSymbol.normalize("uSdT"));
        assertEquals("", CryptoSymbol.normalize("ETH/USDT"));
        assertEquals("", CryptoSymbol.normalize(null));
        java.util.Set<String> available = new java.util.HashSet<>(java.util.Arrays.asList("ETH", "USDT"));
        assertTrue(CryptoSymbol.isSupportedByProvider("eth", available));
        assertFalse(CryptoSymbol.isSupportedByProvider("DOGE", available));
        assertFalse(CryptoSymbol.isSupportedByProvider("ETH", null));
    }

    @Test
    public void financialDisplay_amountGroupingAndInvalidValues() {
        assertEquals("۳۵٬۰۹۶٬۰۲۴٫۵", PersianFinancialDisplay.amount(35096024.5d));
        assertEquals("−۱٬۲۳۴٫۵", PersianFinancialDisplay.amount(-1234.5d).replace('-', '−'));
        assertEquals("۰", PersianFinancialDisplay.amount(0d));
        assertEquals("—", PersianFinancialDisplay.amount(Double.NaN));
        assertEquals("—", PersianFinancialDisplay.amount(Double.POSITIVE_INFINITY));
    }

    @Test
    public void financialDisplay_marketAndPortfolioFormatting() {
        assertEquals("۱٬۲۳۴٬۵۶۷٫۲۵", PersianFinancialDisplay.amount(1234567.25));
        assertEquals("−۹٬۸۷۶٫۵", PersianFinancialDisplay.amount(-9876.5).replace('-', '−'));
        assertEquals("—", PersianFinancialDisplay.amount(Double.NEGATIVE_INFINITY));
        assertEquals("۰", PersianFinancialDisplay.amount(-0.0));
        assertEquals(PersianFinancialDisplay.amount(0.0), PersianFinancialDisplay.amount(-0.0));
    }

    @Test
    public void financialDisplay_exactLongAmountsAvoidFloatingPointLoss() {
        assertEquals("۹٬۰۰۷٬۱۹۹٬۲۵۴٬۷۴۰٬۹۹۳", PersianFinancialDisplay.amount(9007199254740993L));
        assertEquals("−۹٬۲۲۳٬۳۷۲٬۰۳۶٬۸۵۴٬۷۷۵٬۸۰۸", PersianFinancialDisplay.amount(Long.MIN_VALUE).replace('-', '−'));
        assertEquals("۰", PersianFinancialDisplay.amount(0L));
        assertEquals("۱٬۲۳۴", PersianFinancialDisplay.amount(1234L));
    }

    @Test
    public void numberFormat_groupIntegerText_preservesHugeExactValues() {
        assertEquals("9,223,372,036,854,775,808", NumberFormatUtil.groupIntegerText("9223372036854775808"));
        assertEquals("-9,223,372,036,854,775,809", NumberFormatUtil.groupIntegerText("-9223372036854775809"));
        assertEquals("1,234,567", NumberFormatUtil.groupIntegerText("۱۲۳۴۵۶۷"));
        assertEquals("0", NumberFormatUtil.groupIntegerText("-000"));
        assertEquals("1,234", NumberFormatUtil.groupIntegerText("001234"));
        assertEquals("-", NumberFormatUtil.groupIntegerText("-"));
    }

    @Test
    public void numberFormat_caretRemainsNearEditedDigit() {
        assertEquals(3, NumberFormatUtil.mappedCaret("1234", "1,234", 2));
        assertEquals(4, NumberFormatUtil.mappedCaret("1234", "1,234", 3));
        assertEquals(5, NumberFormatUtil.mappedCaret("1234", "1,234", 4));
        assertEquals(2, NumberFormatUtil.mappedCaret("1,234", "1234", 3));
        assertEquals(0, NumberFormatUtil.mappedCaret("1234", "1,234", 0));
        assertEquals(7, NumberFormatUtil.mappedCaret("1234.56", "1,234.56", 6));
        assertEquals(1, NumberFormatUtil.mappedCaret("1234", "1,234", 1));
        assertEquals(3, NumberFormatUtil.mappedCaret("1,234", "1234", 4));
    }

    @Test
    public void numberFormat_groupDecimalText_preservesExactFractionAndLargeIntegers() {
        assertEquals("9,223,372,036,854,775,808.123456789", NumberFormatUtil.groupDecimalText("9223372036854775808.123456789"));
        assertEquals("1,234.0500", NumberFormatUtil.groupDecimalText("۱۲۳۴٫۰۵۰۰"));
        assertEquals("-1,234.5", NumberFormatUtil.groupDecimalText("-١٢٣٤.٥"));
        assertEquals("0.00", NumberFormatUtil.groupDecimalText("-000.00"));
        assertEquals("-0.01", NumberFormatUtil.groupDecimalText("-000.01"));
        assertEquals("1,234.", NumberFormatUtil.groupDecimalText("1234."));
        assertEquals("-.", NumberFormatUtil.groupDecimalText("-."));
        assertEquals("12..3", NumberFormatUtil.groupDecimalText("12..3"));
    }

    @Test
    public void numberFormat_explicitPositiveSignPreservesExactDigits() {
        assertEquals("+1,234,567", NumberFormatUtil.groupIntegerText("+۰۰۱۲۳۴۵۶۷"));
        assertEquals("0", NumberFormatUtil.groupIntegerText("+000"));
        assertEquals("+1,234.0500", NumberFormatUtil.groupDecimalText("+۱۲۳۴٫۰۵۰۰"));
        assertEquals("0.00", NumberFormatUtil.groupDecimalText("+000.00"));
        assertEquals("+0.01", NumberFormatUtil.groupDecimalText("+000.01"));
        assertEquals("+.", NumberFormatUtil.groupDecimalText("+."));
        assertEquals("+", NumberFormatUtil.groupDecimalText("+"));
    }

    @Test
    public void ledgerCompactUi_showsActiveHiddenFiltersAndShortDateLabels() {
        assertEquals("↓ جدیدترین",LedgerCompactUi.sortLabel(true));
        assertEquals("↑ قدیمی‌ترین",LedgerCompactUi.sortLabel(false));
        assertFalse(LedgerCompactUi.hasActiveFilters("ALL",0,""));
        assertTrue(LedgerCompactUi.hasActiveFilters("DEBT",0,""));
        assertTrue(LedgerCompactUi.hasActiveFilters("ALL",90,""));
        assertTrue(LedgerCompactUi.hasActiveFilters("ALL",0,"  ۱۲۳  "));
        assertEquals("",LedgerCompactUi.activeSummary("ALL",0,""));
        String summary=LedgerCompactUi.activeSummary("RECEIPT",7," ۲۵۰ ");
        assertTrue(summary.contains("دریافت"));
        assertTrue(summary.contains("7 روز"));
        assertTrue(summary.contains("۲۵۰"));
        String date=LedgerCompactUi.dayHeading(System.currentTimeMillis());
        assertFalse(date.contains(" • "));
        assertEquals(5,LedgerCompactUi.timeOnly(System.currentTimeMillis()).length());
    }

    @Test
    public void ledger_transactionPaletteMaintainsFourDistinctMeanings() {
        String[] kinds={"DEBT","CREDIT","PAYMENT","RECEIPT"};
        int[] colors={0xFFFF646A,0xFFF5CD58,0xFF4DD998,0xFFC199FC};
        for(int i=0;i<kinds.length;i++) {
            assertEquals(kinds[i],LedgerPresentation.KINDS[i]);
            assertEquals(colors[i],LedgerPresentation.color(kinds[i]));
            assertFalse(LedgerPresentation.label(kinds[i]).isEmpty());
        }
        assertEquals("۱٬۲۳۴٬۵۶۷",LedgerPresentation.persian("1,234,567"));
        assertEquals(1_234_567L,LedgerPresentation.positiveAmount("۱٬۲۳۴٬۵۶۷"));
        assertEquals(0L,LedgerPresentation.positiveAmount("-2,000"));
    }

    @Test
    public void ledger_fourKindsKeepSignedBalancesAndChronologicalRunningAmounts() {
        NexaStore.LedgerParty party=new NexaStore.LedgerParty();party.id="single";party.name="کرمی";
        java.util.List<NexaStore.LedgerEntry> entries=java.util.Arrays.asList(
            ledgerTestEntry("4","single",40,"RECEIPT",10),
            ledgerTestEntry("2","single",20,"CREDIT",5),
            ledgerTestEntry("3","single",30,"PAYMENT",20),
            ledgerTestEntry("1","single",10,"DEBT",50));
        LedgerReport.Result result=LedgerReport.generate(
            java.util.Collections.singletonList(party),entries,"single",Long.MIN_VALUE,Long.MAX_VALUE);
        assertEquals(4,result.rows.size());
        assertEquals(-50,result.rows.get(0).runningBalance);
        assertEquals(-45,result.rows.get(1).runningBalance);
        assertEquals(-25,result.rows.get(2).runningBalance);
        assertEquals(-35,result.rows.get(3).runningBalance);
        assertEquals(-35,result.closingNet);
        java.util.List<LedgerReport.Row> reversed=new java.util.ArrayList<>(result.rows);
        java.util.Collections.reverse(reversed);
        assertEquals(-35,reversed.get(0).runningBalance);
        assertEquals(-50,reversed.get(3).runningBalance);
        assertEquals(-35,result.closingNet); // changing display order must not modify balances
    }

    @Test
    public void ledgerHistoryFilter_findsKindsNotesAndPersianAmountsWithoutBalanceChanges() {
        NexaStore.LedgerParty p=new NexaStore.LedgerParty();p.id="p";p.name="کرمی";
        NexaStore.LedgerEntry debt=ledgerTestEntry("a","p",10,"DEBT",2_000_000);
        debt.note="اجاره خانه";
        NexaStore.LedgerEntry paid=ledgerTestEntry("b","p",20,"PAYMENT",500_000);
        paid.note="قسط بانك";
        NexaStore.LedgerEntry received=ledgerTestEntry("c","p",30,"RECEIPT",100_000);
        received.note="دريافت";
        LedgerReport.Result r=LedgerReport.generate(java.util.Collections.singletonList(p),
            java.util.Arrays.asList(received,paid,debt),"p",Long.MIN_VALUE,Long.MAX_VALUE);
        assertEquals(3,r.rows.size());
        assertEquals(-1_600_000L,r.closingNet);
        assertEquals(1,LedgerHistoryFilter.select(r.rows,"DEBT","").size());
        assertEquals(1,LedgerHistoryFilter.select(r.rows,"PAYMENT","۵۰۰٬۰۰۰").size());
        assertEquals("b",LedgerHistoryFilter.select(r.rows,"ALL","بانک").get(0).entry.id);
        assertEquals("c",LedgerHistoryFilter.select(r.rows,"ALL","دریافت").get(0).entry.id);
        assertEquals(0,LedgerHistoryFilter.select(r.rows,"CREDIT","").size());
        assertEquals(0,LedgerHistoryFilter.select(r.rows,"PAYMENT","ناموجود").size());
        assertEquals(-1_500_000L,LedgerHistoryFilter.select(r.rows,"PAYMENT","").get(0).runningBalance);
        assertEquals(-1_600_000L,r.closingNet);
        assertEquals("a",r.rows.get(0).entry.id);
        assertEquals(3,LedgerHistoryFilter.select(r.rows,"ALL","").size());
    }

    @Test
    public void ledgerChronologicalOrder_isDateBasedForEveryKindAndPreservesBalances() {
        NexaStore.LedgerParty party=new NexaStore.LedgerParty();party.id="p";party.name="کرمی";
        NexaStore.LedgerEntry debt=ledgerTestEntry("d1","p",300L,"DEBT",500L);
        NexaStore.LedgerEntry paid=ledgerTestEntry("p1","p",100L,"PAYMENT",100L);
        NexaStore.LedgerEntry credit=ledgerTestEntry("c1","p",200L,"CREDIT",700L);
        NexaStore.LedgerEntry receipt=ledgerTestEntry("r1","p",400L,"RECEIPT",50L);
        LedgerReport.Result report=LedgerReport.generate(java.util.Collections.singletonList(party),
            java.util.Arrays.asList(debt,receipt,credit,paid),"p",Long.MIN_VALUE,Long.MAX_VALUE);
        java.util.List<LedgerReport.Row> shuffled=java.util.Arrays.asList(report.rows.get(2),report.rows.get(0),report.rows.get(3),report.rows.get(1));
        java.util.List<LedgerReport.Row> descending=LedgerReport.orderedRows(shuffled,true);
        java.util.List<LedgerReport.Row> ascending=LedgerReport.orderedRows(shuffled,false);
        assertEquals("r1",descending.get(0).entry.id);
        assertEquals("p1",descending.get(3).entry.id);
        assertEquals("p1",ascending.get(0).entry.id);
        assertEquals("r1",ascending.get(3).entry.id);
        assertEquals(report.closingNet,descending.get(0).runningBalance);
        assertEquals("d1",LedgerReport.orderedRows(LedgerHistoryFilter.select(shuffled,"DEBT",""),true).get(0).entry.id);
        assertEquals("c1",LedgerReport.orderedRows(LedgerHistoryFilter.select(shuffled,"CREDIT",""),true).get(0).entry.id);
        assertEquals("p1",LedgerReport.orderedRows(LedgerHistoryFilter.select(shuffled,"PAYMENT",""),true).get(0).entry.id);
        assertEquals("r1",LedgerReport.orderedRows(LedgerHistoryFilter.select(shuffled,"RECEIPT",""),true).get(0).entry.id);
    }

    @Test
    public void ledgerHistoryFilter_doesNotMutateSourceOrIgnoreNulls() {
        assertTrue(LedgerHistoryFilter.select(null,"ALL",null).isEmpty());
        assertFalse(LedgerHistoryFilter.matches(null,"ALL",""));
        assertEquals("كری ۱۲۳".replace("ك","ک").replace("۱۲۳","123"),
            LedgerHistoryFilter.normalize("كری ۱۲۳"));
        assertEquals("250000",LedgerHistoryFilter.normalize("۲۵۰٬۰۰۰"));
        assertEquals("250000",LedgerHistoryFilter.normalize("250,000"));
    }

    @Test
    public void ledgerHistory_localCalendarWindowAndColorKindsDoNotMutateBalances() {
        java.util.TimeZone tz=java.util.TimeZone.getTimeZone("Europe/Helsinki");
        java.util.Calendar now=java.util.Calendar.getInstance(tz);
        now.clear();now.set(2026,java.util.Calendar.OCTOBER,25,19,0);
        long start=LedgerHistoryFilter.recentStart(7,now.getTimeInMillis(),tz);
        java.util.Calendar boundary=java.util.Calendar.getInstance(tz);
        boundary.clear();boundary.set(2026,java.util.Calendar.OCTOBER,19,0,0);
        assertEquals(boundary.getTimeInMillis(),start);
        assertEquals(20261025,LedgerHistoryFilter.dayKey(now.getTimeInMillis(),tz));
        NexaStore.LedgerParty party=new NexaStore.LedgerParty();party.id="p";party.name="کرمی";
        NexaStore.LedgerEntry old=ledgerTestEntry("old","p",start-1,"DEBT",2000);
        NexaStore.LedgerEntry credit=ledgerTestEntry("cr","p",start,"CREDIT",500);
        NexaStore.LedgerEntry payment=ledgerTestEntry("pay","p",start+1000,"PAYMENT",700);
        NexaStore.LedgerEntry receipt=ledgerTestEntry("rc","p",start+2000,"RECEIPT",100);
        LedgerReport.Result report=LedgerReport.generate(java.util.Collections.singletonList(party),
            java.util.Arrays.asList(receipt,payment,credit,old),"p",Long.MIN_VALUE,Long.MAX_VALUE);
        java.util.List<LedgerReport.Row> shown=LedgerHistoryFilter.selectBetween(report.rows,"ALL","",start,now.getTimeInMillis());
        assertEquals(3,shown.size());
        assertEquals("cr",shown.get(0).entry.id);
        assertEquals(-1500L,shown.get(0).runningBalance);
        assertEquals(1,LedgerHistoryFilter.selectBetween(report.rows,"PAYMENT","۷۰۰",start,now.getTimeInMillis()).size());
        assertEquals(0,LedgerHistoryFilter.selectBetween(report.rows,"DEBT","",start,now.getTimeInMillis()).size());
        java.util.List<LedgerReport.Row> newest=LedgerReport.orderedRows(shown,true);
        assertEquals("rc",newest.get(0).entry.id);
        assertEquals(-900L,newest.get(0).runningBalance);
        assertEquals(-900L,report.closingNet);
    }

    @Test
    public void ledgerReport_periodAccountingPreservesOpeningBalanceAndOriginalData() {
        NexaStore.LedgerParty ali=new NexaStore.LedgerParty(); ali.id="ali";ali.name="علی";
        NexaStore.LedgerParty sara=new NexaStore.LedgerParty(); sara.id="sara";sara.name="سارا";
        NexaStore.LedgerEntry credit=ledgerTestEntry("a","ali",10,"CREDIT",100);
        NexaStore.LedgerEntry payment=ledgerTestEntry("b","ali",20,"PAYMENT",25);
        NexaStore.LedgerEntry debt=ledgerTestEntry("c","sara",30,"DEBT",40);
        NexaStore.LedgerEntry received=ledgerTestEntry("d","sara",40,"RECEIPT",10);
        NexaStore.LedgerEntry future=ledgerTestEntry("e","ali",50,"CREDIT",55);
        java.util.List<NexaStore.LedgerEntry> all=java.util.Arrays.asList(future,debt,credit,received,payment);
        LedgerReport.Result report=LedgerReport.generate(java.util.Arrays.asList(ali,sara),all,null,20,40);
        assertEquals(3, report.rows.size());
        assertEquals(100L,report.openingNet);
        assertEquals(75L,report.closingNet);
        assertEquals(-25L,report.periodChange);
        assertEquals(40L,report.debtAdded);
        assertEquals(0L,report.creditAdded);
        assertEquals(25L,report.paid);
        assertEquals(10L,report.received);
        assertEquals("b",report.rows.get(0).entry.id);
        assertEquals(125L,report.rows.get(0).runningBalance);
        assertEquals(-40L,report.rows.get(1).runningBalance);
        assertEquals(-50L,report.rows.get(2).runningBalance);
        assertEquals("e",all.get(0).id); // reporting must not mutate persisted list order
        assertEquals(100L,credit.amount);
        LedgerReport.Result one=LedgerReport.generate(java.util.Arrays.asList(ali,sara),all,"ali",20,40);
        assertEquals(1,one.rows.size());
        assertEquals(100L,one.openingNet);
        assertEquals(125L,one.closingNet);
        assertEquals(25L,one.periodChange);
    }

    @Test
    public void ledgerReport_csvProtectsFormulaTextAndKeepsNegativeAmountsNumeric() {
        assertEquals("\"' =SUM(1,2)\"",LedgerReport.csvCell(" =SUM(1,2)"));
        assertEquals("\"'@evil\"",LedgerReport.csvCell("@evil"));
        assertEquals("\"line \"\"quote\"\"\\nnext\"".replace("\\n","\n"),LedgerReport.csvCell("line \"quote\"\nnext"));
        NexaStore.LedgerParty p=new NexaStore.LedgerParty();p.id="p";p.name="=HYPERLINK(\"x\")";
        NexaStore.LedgerEntry e=ledgerTestEntry("x","p",100,"DEBT",40);
        e.note="=1+1";
        LedgerReport.Result report=LedgerReport.generate(java.util.Collections.singletonList(p),java.util.Collections.singletonList(e),null,Long.MIN_VALUE,Long.MAX_VALUE);
        String csv=LedgerReport.toCsv(report);
        assertTrue(csv.startsWith("\uFEFF"));
        assertTrue(csv.contains("\"'=HYPERLINK("));
        assertTrue(csv.contains("\"'=1+1\""));
        assertTrue(csv.contains(",40,-40,-40,"));
        assertEquals(1,report.rows.size());
    }

    @Test
    public void ledgerReport_dateWindowsAreBoundedWithoutOverflow() {
        assertEquals(Long.MIN_VALUE,LedgerReport.startMillis(0,100L));
        assertEquals(86400000L,LedgerReport.startMillis(1,172800000L));
        assertEquals(-30L*86400000L,LedgerReport.startMillis(30,0L));
        assertEquals(Long.MIN_VALUE,LedgerReport.startMillis(30,Long.MIN_VALUE+100L));
        assertEquals(100L-90L*86400000L,LedgerReport.startMillis(90,100L));
    }

    private static NexaStore.LedgerEntry ledgerTestEntry(String id,String party,long date,String kind,long amount) {
        NexaStore.LedgerEntry e=new NexaStore.LedgerEntry();
        e.id=id;e.partyId=party;e.dateMillis=date;e.kind=kind;e.amount=amount;
        return e;
    }

    @Test
    public void calendarExport_oneTimeEventsAreUtcAndHaveStableUid() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.id="meeting-fixed";
        r.title="جلسه";
        r.category="قرار";
        r.whenMillis=1704067200000L; // 2024-01-01 00:00:00 UTC
        r.offsetsMinutes="0,10,10,D3@09:00";
        String once=ReminderCalendarExport.generate(java.util.Collections.singletonList(r),
                1704067200000L,false);
        String again=ReminderCalendarExport.generate(java.util.Collections.singletonList(r),
                1704067205000L,false);
        assertTrue(once.contains("DTSTART:20240101T000000Z\r\n"));
        assertTrue(once.contains("DTEND:20240101T003000Z\r\n"));
        assertTrue(once.contains("TRIGGER:-PT10M\r\n"));
        assertTrue(once.contains("TRIGGER:PT0M\r\n"));
        assertEquals(2,once.split("BEGIN:VALARM",-1).length-1);
        assertFalse(once.contains("D3@09:00"));
        assertEquals(once.split("UID:")[1].split("\r\n")[0],
                again.split("UID:")[1].split("\r\n")[0]);
        assertFalse(once.contains("CATEGORIES:"));
    }

    @Test
    public void calendarExport_recurringRulesMatchNexaRecurrence() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=1704067200000L;
        r.recurrence="biweekly";
        String ics=ReminderCalendarExport.generate(java.util.Collections.singletonList(r),0L,false);
        assertTrue(ics.contains("RRULE:FREQ=WEEKLY;INTERVAL=2\r\n"));
        assertTrue(ics.contains("DURATION:PT30M\r\n"));
        assertTrue(ics.contains("DTSTART:"));
        assertFalse(ics.contains("DTSTART:20240101T000000Z"));
        assertEquals("FREQ=MONTHLY",ReminderCalendarExport.recurrenceRule("monthly"));
        assertEquals("FREQ=DAILY",ReminderCalendarExport.recurrenceRule("daily"));
        assertEquals("FREQ=WEEKLY",ReminderCalendarExport.recurrenceRule("weekly"));
        assertEquals("",ReminderCalendarExport.recurrenceRule("none"));
    }

    @Test
    public void calendarExport_onlyActiveUncompletedAndNeverMutatesInput() {
        NexaStore.Reminder active=new NexaStore.Reminder();
        active.id="a";active.title="فعال";active.whenMillis=1704067200000L;
        NexaStore.Reminder paused=new NexaStore.Reminder();
        paused.id="p";paused.title="متوقف";paused.whenMillis=1704067200000L;paused.active=false;
        NexaStore.Reminder done=new NexaStore.Reminder();
        done.id="d";done.title="تمام";done.whenMillis=1704067200000L;done.done=true;
        List<NexaStore.Reminder> input=java.util.Arrays.asList(active,paused,done,active);
        assertEquals(1,ReminderCalendarExport.eligible(input).size());
        String ics=ReminderCalendarExport.generate(input,1704067200000L,false);
        assertEquals(1,ics.split("BEGIN:VEVENT",-1).length-1);
        assertTrue(ics.contains("SUMMARY:فعال\r\n"));
        assertFalse(ics.contains("متوقف"));
        assertFalse(ics.contains("تمام"));
        assertEquals(4,input.size());
        assertFalse(active.done);
        assertTrue(active.active);
        assertEquals(1704067200000L,active.whenMillis);
    }

    @Test
    public void calendarExport_privateDescriptionsOnlyWithConsent() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.id="medical";r.title="وقت دکتر";r.category="پزشکی";
        r.whenMillis=1704067200000L;
        r.note="پرونده\nمحرمانه";r.doctorPhone="secretphone";
        r.doctorAddress="secretaddress";
        String minimal=ReminderCalendarExport.generate(java.util.Collections.singletonList(r),0L,false);
        String full=ReminderCalendarExport.generate(java.util.Collections.singletonList(r),0L,true);
        assertFalse(minimal.contains("secretphone"));
        assertFalse(minimal.contains("secretaddress"));
        assertFalse(minimal.contains("CATEGORIES:"));
        assertTrue(full.contains("secretphone"));
        assertTrue(full.contains("secretaddress"));
        assertTrue(full.contains("DESCRIPTION:"));
        assertTrue(full.contains("LOCATION:secretaddress"));
        assertTrue(full.contains("CATEGORIES:پزشکی"));
    }

    @Test
    public void calendarExport_escapesUntrustedFieldsAndFoldsUtf8At75Bytes() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=1704067200000L;
        r.title="الف،؛\\\nBEGIN:FAKE" + new String(new char[80]).replace("\0","ش");
        String ics=ReminderCalendarExport.generate(java.util.Collections.singletonList(r),0L,false);
        assertTrue(ics.contains("BEGIN:VCALENDAR\r\n"));
        assertTrue(ics.endsWith("END:VCALENDAR\r\n"));
        for(String line:ics.split("\r\n")) {
            assertTrue("Long iCalendar physical line: "+line,
                    line.getBytes(java.nio.charset.StandardCharsets.UTF_8).length<=75);
        }
        String unfolded=ics.replace("\r\n ","");
        assertTrue(unfolded.contains("SUMMARY:الف،؛\\\\\\nBEGIN:FAKE"));
        assertEquals(1,ics.split("BEGIN:VEVENT",-1).length-1);
        assertEquals("\\n",ReminderCalendarExport.escape("\r\n"));
        assertEquals("bad ",ReminderCalendarExport.escape("bad\0"));
    }

    @Test
    public void timerSession_manualSilentCannotBeOverwrittenByIdleStop() {
        assertFalse(TimerSessionGuard.hasSession(0L, 0L));
        assertFalse(TimerSessionGuard.hasSession(-1L, -1L));
        assertTrue(TimerSessionGuard.hasSession(1000L, 0L));
        assertTrue(TimerSessionGuard.hasSession(0L, 1000L));
        // An expired session still owns the original ringer state until restored.
        assertTrue(TimerSessionGuard.hasSession(1L, 0L));
    }

    @Test
    public void backgroundReport_rejectsPersonalDataAndMalformedRecords() {
        String raw = "1234567890000 | service.ticker | SecurityException"
                + "\n1234567890001 | ERROR password=abc | RuntimeException"
                + "\n1234567890002 | service.battery | phone-number+123456"
                + "\nhello | service.test | IOException";
        String safe = BackgroundReliability.sanitizeEntries(raw);
        assertEquals("1234567890000 | service.ticker | SecurityException", safe);
        assertFalse(safe.contains("password"));
        assertFalse(safe.contains("phone-number"));
        assertEquals("", BackgroundReliability.sanitizeEntries(null));
    }

    @Test
    public void appVersion_matchesInstalledBuildConfiguration() throws Exception {
        android.content.pm.PackageInfo info = context.getPackageManager()
                .getPackageInfo(context.getPackageName(), 0);
        // Keep this test tied to the actual Gradle configuration, not the
        // version number of the previous release. Future builds should not
        // fail merely because this test has a stale hard-coded version.
        assertEquals(BuildConfig.APPLICATION_ID, info.packageName);
        assertEquals(BuildConfig.VERSION_NAME, info.versionName);
        assertEquals((long) BuildConfig.VERSION_CODE, info.getLongVersionCode());
        // Reject an accidentally retained pre-Build-166 source APK.
        assertTrue("Expected Nexa Build 168 or newer",
                info.getLongVersionCode() >= 168L);
    }

    @Test
    public void medicineSkippedDose_roundTripsAsExplicitMissedDose() {
        String id = "regression-skipped-med";
        NexaStore.clearMedicineDoseLogs(context, id);
        NexaStore.MedicineDoseLog log = new NexaStore.MedicineDoseLog();
        log.medicineId = id;
        log.scheduledAt = 1700000000000L;
        log.takenAt = 0L;
        log.status = "skipped";
        NexaStore.addMedicineDoseLog(context, log);
        List<NexaStore.MedicineDoseLog> saved = NexaStore.medicineDoseLogsFor(context, id);
        assertEquals(1, saved.size());
        assertEquals("skipped", saved.get(0).status);
        assertEquals(0L, saved.get(0).takenAt);
        NexaStore.clearMedicineDoseLogs(context, id);
    }

    @Test
    public void vaultDefaultGroups_doNotExposeEmailCategory() {
        String joined = java.util.Arrays.toString(NexaStore.defaultVaultGroups());
        assertFalse(joined.contains("ایمیل"));
        assertTrue(joined.contains("بانک"));
        assertTrue(joined.contains("سایت"));
    }

    @Test
    public void audioController_priorityOrderAndRingerModes_areStable() {
        assertTrue(NexaAudioController.PRIORITY_THEFT > NexaAudioController.PRIORITY_SECURITY);
        assertTrue(NexaAudioController.PRIORITY_SECURITY > NexaAudioController.PRIORITY_BATTERY);
        assertTrue(NexaAudioController.PRIORITY_BATTERY > NexaAudioController.PRIORITY_MEDICINE);
        assertTrue(NexaAudioController.PRIORITY_MEDICINE > NexaAudioController.PRIORITY_REMINDER);
        assertTrue(NexaAudioController.PRIORITY_REMINDER > NexaAudioController.PRIORITY_NORMAL);
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_NORMAL));
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_SILENT));
        assertTrue(NexaAudioController.isSupportedRingerMode(android.media.AudioManager.RINGER_MODE_VIBRATE));
        assertFalse(NexaAudioController.isSupportedRingerMode(99));
        NexaAudioController.stopAll();
        assertEquals(0, NexaAudioController.getActivePriority());
        assertEquals("", NexaAudioController.getActiveOwner());
    }


    @Test
    public void silentTimer_previousRingerMode_roundTripsAndClears() {
        AppPrefs.clearTimer(context);
        AppPrefs.setTimerPreviousRingerMode(context, android.media.AudioManager.RINGER_MODE_VIBRATE);
        assertTrue(AppPrefs.hasTimerPreviousRingerMode(context));
        assertEquals(android.media.AudioManager.RINGER_MODE_VIBRATE,
                AppPrefs.getTimerPreviousRingerMode(context));
        AppPrefs.clearTimer(context);
        assertFalse(AppPrefs.hasTimerPreviousRingerMode(context));
    }

    @Test
    public void audioController_currentRingerMode_isAlwaysSupported() {
        int mode = NexaAudioController.getRingerMode(context);
        assertTrue(NexaAudioController.isSupportedRingerMode(mode));
    }

    @Test
    public void notificationEngine_blocksImmediateDuplicateDelivery() {
        String key = "regression-duplicate-" + System.nanoTime();
        assertTrue(NexaNotificationEngine.acquireDelivery(context, key));
        assertFalse(NexaNotificationEngine.acquireDelivery(context, key));
    }

    @Test
    public void medicineAlarm_buildsVisibleAlarmNotificationWithActions() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();

        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-alarm-med";
        m.name = "Regression Medicine";
        m.dose = "1 tablet";
        m.intervalHours = 8;
        m.nextDoseMillis = System.currentTimeMillis() + 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);

            Intent alarm = new Intent(context, MedicineAlarmReceiver.class);
            alarm.putExtra("id", m.id);
            new MedicineAlarmReceiver().onReceive(context, alarm);

            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            Notification found = null;
            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                if (sbn.getId() == ("med" + m.id).hashCode()) {
                    found = sbn.getNotification();
                    break;
                }
            }
            assertNotNull("Medicine alarm notification must be posted", found);
            assertEquals(Notification.CATEGORY_ALARM, found.category);
            assertEquals(Notification.VISIBILITY_PUBLIC, found.visibility);
            assertNotNull("Medicine alarm must have a full-screen intent", found.fullScreenIntent);
            assertNotNull("Medicine alarm tap must open the ring screen", found.contentIntent);
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel channel = nm.getNotificationChannel(MedicineAlarmReceiver.CHANNEL);
                assertNotNull("Medicine alarm channel must exist", channel);
                assertTrue("Medicine alarm channel must be HIGH importance", channel.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
                // On Android 14 the framework/emulator may report VISIBILITY_NO_OVERRIDE (-1000)
                // even when the notification itself explicitly uses VISIBILITY_PUBLIC.
                // Validate that the channel does not explicitly hide lock-screen notifications.
                assertTrue("Medicine alarm channel must not be SECRET on lock screen",
                        channel.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
            }
            assertNotNull(found.actions);
            // 5.4.48 adds a dedicated "Stop sound" action in addition to the
            // existing medicine actions. Keep this regression aligned with the
            // intended four-action notification contract.
            assertEquals(4, found.actions.length);
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE)).contains(m.name));
        } finally {
            AlarmSoundPlayer.stopAll();
            ((NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE))
                    .cancel(("med" + m.id).hashCode());
            MedicineScheduler.cancel(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }

    @Test
    public void medicineTakenNow_updatesNextDoseFromActualCompletion() {
        NexaStore.Medicine m = new NexaStore.Medicine();
        m.id = "regression-taken-now";
        m.name = "Regression Taken Now";
        m.intervalHours = 4;
        m.nextDoseMillis = System.currentTimeMillis() - 5 * 60_000L;
        m.active = true;

        List<NexaStore.Medicine> original = NexaStore.medicines(context);
        try {
            List<NexaStore.Medicine> copy = new java.util.ArrayList<>(original);
            copy.removeIf(x -> m.id.equals(x.id));
            copy.add(m);
            NexaStore.saveMedicines(context, copy);
            NexaStore.clearMedicineDoseLogs(context, m.id);

            long before = System.currentTimeMillis();
            Intent taken = new Intent(context, MedicineActionReceiver.class);
            taken.setAction("TAKEN_NOW");
            taken.putExtra("id", m.id);
            new MedicineActionReceiver().onReceive(context, taken);
            long after = System.currentTimeMillis();

            NexaStore.Medicine saved = NexaStore.medicine(context, m.id);
            assertNotNull(saved);
            long interval = 4L * 60L * 60L * 1000L;
            assertTrue(saved.nextDoseMillis >= before + interval);
            assertTrue(saved.nextDoseMillis <= after + interval);
            List<NexaStore.MedicineDoseLog> logs = NexaStore.medicineDoseLogsFor(context, m.id);
            assertEquals(1, logs.size());
            assertEquals("taken_now", logs.get(0).status);
        } finally {
            MedicineScheduler.cancel(context, m.id);
            NexaStore.clearMedicineDoseLogs(context, m.id);
            NexaStore.saveMedicines(context, original);
        }
    }


    @Test
    public void medicineStats_countsTakenSkippedAndMissedWithoutMutatingData() {
        NexaStore.Medicine m=new NexaStore.Medicine();
        long hour=60L*60L*1000L, now=1700000000000L;
        m.firstDoseMillis=now-12*hour; m.intervalHours=4; m.endMillis=0;
        java.util.ArrayList<NexaStore.MedicineDoseLog> logs=new java.util.ArrayList<>();
        NexaStore.MedicineDoseLog a=new NexaStore.MedicineDoseLog();a.scheduledAt=m.firstDoseMillis;a.takenAt=a.scheduledAt;a.status="taken_on_time";logs.add(a);
        NexaStore.MedicineDoseLog b=new NexaStore.MedicineDoseLog();b.scheduledAt=m.firstDoseMillis+4*hour;b.status="skipped";b.takenAt=0;logs.add(b);
        NexaStore.MedicineDoseLog c=new NexaStore.MedicineDoseLog();c.scheduledAt=m.firstDoseMillis+8*hour;c.takenAt=c.scheduledAt+10*60_000L;c.status="taken_now";logs.add(c);
        MedicineStats.Summary x=MedicineStats.summarize(m,logs,now,7);
        assertEquals(4,x.scheduled); assertEquals(2,x.taken); assertEquals(1,x.onTime); assertEquals(1,x.late); assertEquals(1,x.skipped); assertEquals(2,x.missed); assertEquals(50,x.adherencePercent());
    }

    @Test
    public void criticalPermissionState_canBeReadFromAndroid() {
        android.app.NotificationManager nm=(android.app.NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        android.app.AlarmManager am=(android.app.AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        android.os.PowerManager pm=(android.os.PowerManager) context.getSystemService(Context.POWER_SERVICE);
        assertNotNull(nm);
        assertNotNull(am);
        assertNotNull(pm);
        if(android.os.Build.VERSION.SDK_INT>=34) { boolean ignored=nm.canUseFullScreenIntent(); }
        if(android.os.Build.VERSION.SDK_INT>=31) { boolean ignored=am.canScheduleExactAlarms(); }
        boolean ignoredBattery=pm.isIgnoringBatteryOptimizations(context.getPackageName());
    }

    @Test
    public void missedCallGuard_ringingThenIdle_postsVisibleLockScreenNotification() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        long permissionDeadline = System.currentTimeMillis() + 2000L;
        while (android.os.Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
                && System.currentTimeMillis() < permissionDeadline) {
            Thread.sleep(50L);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                    context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS));
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        boolean oldShowName = AppPrefs.isMissedCallShowName(context);
        boolean oldShowNumber = AppPrefs.isMissedCallShowNumber(context);
        boolean oldShowTime = AppPrefs.isMissedCallShowTime(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            AppPrefs.setMissedCallShowName(context, false);
            AppPrefs.setMissedCallShowNumber(context, true);
            AppPrefs.setMissedCallShowTime(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);

            String number = "+15551234567";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, number);

            Notification found = null;
            long notificationDeadline = System.currentTimeMillis() + 2500L;
            while (found == null && System.currentTimeMillis() < notificationDeadline) {
                for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                    if (sbn.getId() == NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID) {
                        found = sbn.getNotification();
                        break;
                    }
                }
                if (found == null) Thread.sleep(50L);
            }
            assertNotNull("Missed-call guard must post a notification", found);
            assertEquals(Notification.CATEGORY_CALL, found.category);
            assertEquals(Notification.VISIBILITY_PUBLIC, found.visibility);
            assertNotNull("Missed-call notification must carry a full-screen lock card intent", found.fullScreenIntent);
            assertTrue("Missed-call notification must expose Call/Clear actions", found.actions != null && found.actions.length >= 2);
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TITLE))
                    .contains("تماس از دست‌رفته"));
            assertTrue(String.valueOf(found.extras.getCharSequence(Notification.EXTRA_TEXT))
                    .contains(number));
            assertEquals(1, MissedCallGuard.getUnviewedCount(context));
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel channel = nm.getNotificationChannel(
                        NexaNotificationEngine.MISSED_CALL_CHANNEL);
                assertNotNull(channel);
                assertTrue(channel.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
                assertTrue(channel.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
            }
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
            AppPrefs.setMissedCallShowName(context, oldShowName);
            AppPrefs.setMissedCallShowNumber(context, oldShowNumber);
            AppPrefs.setMissedCallShowTime(context, oldShowTime);
        }
    }

    @Test
    public void missedCallGuard_answeredCall_doesNotPostMissedNotification() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        long permissionDeadline = System.currentTimeMillis() + 2000L;
        while (android.os.Build.VERSION.SDK_INT >= 33
                && context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != android.content.pm.PackageManager.PERMISSION_GRANTED
                && System.currentTimeMillis() < permissionDeadline) {
            Thread.sleep(50L);
        }
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                    context.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS));
        }

        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            String number = "+15557654321";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_OFFHOOK, number);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, number);

            for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                assertNotEquals(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID, sbn.getId());
            }
            assertEquals(0, MissedCallGuard.getUnviewedCount(context));
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
        }
    }

    @Test
    public void missedCallGuard_multipleMissedCalls_updatesCountAndVisibleList() throws Exception {
        InstrumentationRegistry.getInstrumentation().getUiAutomation()
                .executeShellCommand("pm grant " + context.getPackageName() + " android.permission.POST_NOTIFICATIONS")
                .close();
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        boolean oldEnabled = AppPrefs.isMissedCallGuardEnabled(context);
        boolean oldShowName = AppPrefs.isMissedCallShowName(context);
        boolean oldShowNumber = AppPrefs.isMissedCallShowNumber(context);
        boolean oldShowTime = AppPrefs.isMissedCallShowTime(context);
        try {
            AppPrefs.setMissedCallGuardEnabled(context, true);
            AppPrefs.setMissedCallShowName(context, false);
            AppPrefs.setMissedCallShowNumber(context, true);
            AppPrefs.setMissedCallShowTime(context, true);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);

            String first = "+15550000001";
            String second = "+15550000002";
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, first);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, first);
            Thread.sleep(50L);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_RINGING, second);
            MissedCallGuard.onPhoneState(context, android.telephony.TelephonyManager.EXTRA_STATE_IDLE, second);

            // NotificationManager replacement is asynchronous on the emulator. Do not
            // accept the stale first-call notification while the second missed call has
            // already been persisted; wait until the visible notification reflects both.
            Notification found = null;
            long deadline = System.currentTimeMillis() + 4000L;
            while (System.currentTimeMillis() < deadline) {
                Notification candidate = null;
                for (StatusBarNotification sbn : nm.getActiveNotifications()) {
                    if (sbn.getId() == NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID) {
                        candidate = sbn.getNotification();
                        break;
                    }
                }
                if (candidate != null) {
                    String candidateTitle = String.valueOf(candidate.extras.getCharSequence(Notification.EXTRA_TITLE));
                    String candidateBig = String.valueOf(candidate.extras.getCharSequence(Notification.EXTRA_BIG_TEXT));
                    if (candidateTitle.contains("2") && candidateBig.contains(first) && candidateBig.contains(second)) {
                        found = candidate;
                        break;
                    }
                }
                Thread.sleep(50L);
            }
            assertEquals(2, MissedCallGuard.getUnviewedCount(context));
            assertNotNull("Updated missed-call notification must show both calls", found);
        } finally {
            nm.cancel(NexaNotificationEngine.MISSED_CALL_NOTIFICATION_ID);
            MissedCallGuard.clearActiveCall(context);
            MissedCallGuard.resetMissedCount(context);
            AppPrefs.setMissedCallGuardEnabled(context, oldEnabled);
            AppPrefs.setMissedCallShowName(context, oldShowName);
            AppPrefs.setMissedCallShowNumber(context, oldShowNumber);
            AppPrefs.setMissedCallShowTime(context, oldShowTime);
        }
    }

    @Test
    public void missedCallGuard_recentListCapacity_supportsSeveralCalls() {
        assertTrue("Lock-screen list must retain several missed calls", MissedCallGuard.recentCallCapacity() >= 8);
    }

    @Test
    public void notificationEngine_coreChannels_arePublicAndSeparated() {
        NotificationChannelHelper.ensureCoreChannels(context);
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        assertNotNull(nm);
        String[] ids = new String[]{
                NotificationChannelHelper.CHANNEL_MISSED_CALL,
                NotificationChannelHelper.CHANNEL_REMINDER,
                NotificationChannelHelper.CHANNEL_BATTERY_ALARM,
                NotificationChannelHelper.CHANNEL_LOW_BATTERY,
                NotificationChannelHelper.CHANNEL_THEFT_ALARM,
                NotificationChannelHelper.CHANNEL_SECURITY
        };
        java.util.HashSet<String> unique = new java.util.HashSet<>();
        for (String id : ids) {
            assertTrue(unique.add(id));
            android.app.NotificationChannel ch = nm.getNotificationChannel(id);
            assertNotNull("Core Nexa channel must exist: " + id, ch);
            assertTrue(ch.getImportance() >= NotificationManager.IMPORTANCE_HIGH);
            assertTrue(ch.getLockscreenVisibility() != Notification.VISIBILITY_SECRET);
        }
    }



    @Test
    public void caseDirectories_roundTripWithoutDuplicates() {
        NexaStore.addCourt(context, "دادگاه تست ۴۳");
        NexaStore.addCourt(context, "دادگاه تست ۴۳");
        NexaStore.addLawyer(context, "وکیل تست ۴۳");
        assertTrue(NexaStore.courts(context).contains("دادگاه تست ۴۳"));
        assertTrue(NexaStore.lawyers(context).contains("وکیل تست ۴۳"));
        int count = 0; for (String x : NexaStore.courts(context)) if ("دادگاه تست ۴۳".equals(x)) count++;
        assertEquals(1, count);
    }

    @Test
    public void removedThemeEngine_isNotPresentInRuntimePackage() throws Exception {
        try { Class.forName("com.example.silenttimer.ThemeManager"); fail("ThemeManager must remain removed"); }
        catch (ClassNotFoundException expected) { assertTrue(true); }
    }

    @Test
    public void emergencyContactLabels_haveSafeDefaultsAndRoundTrip() {
        NexaStore.setEmergencyLabel1(context, "مادر");
        NexaStore.setEmergencyLabel2(context, "پدر");
        assertEquals("مادر", NexaStore.emergencyLabel1(context));
        assertEquals("پدر", NexaStore.emergencyLabel2(context));
        NexaStore.setEmergencyLabel1(context, "");
        NexaStore.setEmergencyLabel2(context, "");
        assertEquals("مادر", NexaStore.emergencyLabel1(context));
        assertEquals("پدر", NexaStore.emergencyLabel2(context));
    }
    @Test
    public void batteryAlertSettings_roundTripAndClamp() {
        AppPrefs.setChargeAlarmThreshold(context, 95); assertEquals(95, AppPrefs.getChargeAlarmThreshold(context));
        AppPrefs.setLowBatteryThreshold(context, 10); assertEquals(10, AppPrefs.getLowBatteryThreshold(context));
        AppPrefs.setChargeAlarmThreshold(context, 150); assertEquals(100, AppPrefs.getChargeAlarmThreshold(context));
        AppPrefs.setLowBatteryThreshold(context, -2); assertEquals(1, AppPrefs.getLowBatteryThreshold(context));
        assertTrue(BatteryAlertManager.CHARGE_ID != BatteryAlertManager.LOW_ID);
    }

    @Test
    public void theftGuard_settingsAndPriority_areStable() {
        AppPrefs.setTheftGuardEnabled(context, true);
        assertTrue(AppPrefs.isTheftGuardEnabled(context));
        AppPrefs.setTheftAlarmActive(context, true);
        assertTrue(AppPrefs.isTheftAlarmActive(context));
        AppPrefs.setTheftLastPlugged(context, true);
        assertTrue(AppPrefs.isTheftPlugStateKnown(context));
        assertTrue(AppPrefs.getTheftLastPlugged(context));
        assertEquals(NexaAudioController.PRIORITY_THEFT, 100);
        assertEquals("theft_guard", TheftGuardManager.OWNER);
        assertTrue(TheftGuardManager.NOTIFICATION_ID != BatteryAlertManager.CHARGE_ID);
        assertTrue(TheftGuardManager.NOTIFICATION_ID != BatteryAlertManager.LOW_ID);
        TheftGuardManager.stop(context);
        assertFalse(AppPrefs.isTheftAlarmActive(context));
        AppPrefs.setTheftGuardEnabled(context, false);
        AppPrefs.clearTheftPlugState(context);
    }


    @Test
    public void audioController_hasDistinctProfilesAndMedicineDebounce() {
        assertTrue(NexaAudioController.SOUND_ALARM != NexaAudioController.SOUND_REMINDER);
        assertTrue(NexaAudioController.SOUND_REMINDER != NexaAudioController.SOUND_BATTERY);
        assertTrue(NexaAudioController.SAME_OWNER_DEBOUNCE_MS >= 10_000L);
        assertTrue(NexaAudioController.PRIORITY_MEDICINE > NexaAudioController.PRIORITY_REMINDER);
    }

    @Test
    public void recurringReminder_doneAdvancesAndStaysActive() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=System.currentTimeMillis()-8L*24L*60L*60L*1000L;
        r.recurrence="weekly";
        long now=System.currentTimeMillis();
        assertTrue(ReminderRecurrence.advanceAfterDone(r,now));
        assertTrue(r.whenMillis>now);
        assertTrue(r.active);
        assertFalse(r.done);
    }

    @Test
    public void oneTimeReminder_doneDoesNotAdvance() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=System.currentTimeMillis()-1000L;
        r.recurrence="none";
        long before=r.whenMillis;
        assertFalse(ReminderRecurrence.advanceAfterDone(r,System.currentTimeMillis()));
        assertEquals(before,r.whenMillis);
    }

    @Test
    public void batteryAndReminderChannels_areSeparated() {
        assertFalse(NotificationChannelHelper.CHANNEL_BATTERY_ALARM.equals(ReminderScheduler.CHANNEL));
        assertFalse(NotificationChannelHelper.CHANNEL_LOW_BATTERY.equals(ReminderScheduler.CHANNEL));
        assertFalse(MedicineAlarmReceiver.CHANNEL.equals(ReminderScheduler.CHANNEL));
    }

    @Test
    public void ledger_partiesAndBalanceRoundTrip() {
        NexaStore.LedgerParty p = new NexaStore.LedgerParty(); p.name="احمدی تست ۴۹"; NexaStore.upsertLedgerParty(context,p);
        NexaStore.LedgerEntry debt=new NexaStore.LedgerEntry(); debt.partyId=p.id; debt.kind="DEBT"; debt.amount=5_000_000L; NexaStore.addLedgerEntry(context,debt);
        NexaStore.LedgerEntry pay=new NexaStore.LedgerEntry(); pay.partyId=p.id; pay.kind="PAYMENT"; pay.amount=2_000_000L; NexaStore.addLedgerEntry(context,pay);
        assertEquals(-3_000_000L,NexaStore.ledgerBalance(context,p.id));
        assertEquals(2,NexaStore.ledgerEntriesFor(context,p.id).size());
        NexaStore.removeLedgerEntry(context,debt.id); NexaStore.removeLedgerEntry(context,pay.id); NexaStore.removeLedgerParty(context,p.id);
    }

    @Test
    public void notificationEngine_priorityContract_isStable() {
        assertTrue(NexaNotificationEngine.PRIORITY_THEFT > NexaNotificationEngine.PRIORITY_SECURITY);
        assertTrue(NexaNotificationEngine.PRIORITY_SECURITY > NexaNotificationEngine.PRIORITY_BATTERY);
        assertTrue(NexaNotificationEngine.PRIORITY_BATTERY > NexaNotificationEngine.PRIORITY_MEDICINE);
        assertTrue(NexaNotificationEngine.PRIORITY_MEDICINE > NexaNotificationEngine.PRIORITY_REMINDER);
        assertEquals(NexaNotificationEngine.PRIORITY_THEFT, NexaNotificationEngine.priorityForChannel(NotificationChannelHelper.CHANNEL_THEFT_ALARM));
        assertEquals(NexaNotificationEngine.PRIORITY_BATTERY, NexaNotificationEngine.priorityForChannel(NotificationChannelHelper.CHANNEL_LOW_BATTERY));
        assertEquals(NexaNotificationEngine.PRIORITY_REMINDER, NexaNotificationEngine.priorityForChannel(NotificationChannelHelper.CHANNEL_REMINDER));
    }

    @Test
    public void notificationEngine_coreChannels_areCreated() {
        NexaNotificationEngine.ensureChannels(context);
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm=(NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_REMINDER));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_BATTERY_ALARM));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_THEFT_ALARM));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_SECURITY));
            assertNotNull(nm.getNotificationChannel(NotificationChannelHelper.CHANNEL_MEDICINE_CONTROL));
        }
    }

    @Test
    public void ledger_deletePartyCascadesEntries() {
        NexaStore.LedgerParty p=new NexaStore.LedgerParty(); p.name="حذف آبشاری تست ۵۳"; NexaStore.upsertLedgerParty(context,p);
        NexaStore.LedgerEntry x=new NexaStore.LedgerEntry(); x.partyId=p.id; x.amount=123456L; x.kind="DEBT"; NexaStore.addLedgerEntry(context,x);
        assertEquals(1,NexaStore.ledgerEntriesFor(context,p.id).size());
        NexaStore.removeLedgerParty(context,p.id);
        assertEquals(0,NexaStore.ledgerEntriesFor(context,p.id).size());
    }

    @Test
    public void ledger_dueMillisRoundTrip() {
        NexaStore.LedgerParty p=new NexaStore.LedgerParty(); p.name="موعد تست ۵۳"; NexaStore.upsertLedgerParty(context,p);
        NexaStore.LedgerEntry x=new NexaStore.LedgerEntry(); x.partyId=p.id; x.amount=1000; x.dueMillis=System.currentTimeMillis()+86400000L; NexaStore.addLedgerEntry(context,x);
        assertEquals(x.dueMillis,NexaStore.ledgerEntriesFor(context,p.id).get(0).dueMillis);
        NexaStore.removeLedgerParty(context,p.id);
    }

    @Test
    public void marketSnapshotValidation_rejectsZeroNanAndPartialData() {
        assertTrue(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(0,300000,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,Double.NaN,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,Double.POSITIVE_INFINITY,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,0));
    }

    @Test
    public void marketSourceMetadata_roundTrips() {
        NexaStore.setMarketSources(context,"metals-test","fx-test");
        assertEquals("metals-test",NexaStore.marketMetalsSource(context));
        assertEquals("fx-test",NexaStore.marketFxSource(context));
    }

    @Test
    public void marketSnapshotValidation_rejectsImplausibleOutliers() {
        assertFalse(MarketDataHelper.isValidIranSnapshot(99,300000,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,0.5,20000000,26666666,4200));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,0.01));
        assertFalse(MarketDataHelper.isValidIranSnapshot(250000,300000,20000000,26666666,11));
    }

    @Test
    public void marketAttemptMetadata_roundTrips() {
        NexaStore.setMarketLastAttempt(context,1700000000000L,false);
        assertEquals(1700000000000L,NexaStore.marketLastAttempt(context));
        assertFalse(NexaStore.marketLastAttemptOk(context));
        NexaStore.setMarketLastAttempt(context,1700000001000L,true);
        assertTrue(NexaStore.marketLastAttemptOk(context));
    }


    @Test
    public void assetPriceAlert_fieldsRoundTrip() {
        java.util.List<NexaStore.AssetEntry> original=NexaStore.assets(context);
        try {
            NexaStore.AssetEntry x=new NexaStore.AssetEntry();x.type="دلار";x.amount=1;x.buyUnitPrice=90000;x.currentUnitPrice=95000;x.alertTarget=100000;x.alertDirection="up";x.alertAtBuy=true;x.alertLastNotifiedAt=12345L;x.lastAlertObservedPrice=94000;
            java.util.List<NexaStore.AssetEntry> one=new java.util.ArrayList<>();one.add(x);NexaStore.saveAssets(context,one);
            NexaStore.AssetEntry y=NexaStore.assets(context).get(0);assertEquals("up",y.alertDirection);assertEquals(100000d,y.alertTarget,0.01);assertTrue(y.alertAtBuy);assertEquals(12345L,y.alertLastNotifiedAt);assertEquals(94000d,y.lastAlertObservedPrice,0.01);
        } finally {NexaStore.saveAssets(context,original);}
    }

    @Test
    public void assetMarketEngine_mapsIranPricesOnly() {
        NexaStore.setIranMarketSnapshot(context,91000,106000,11200000,14933333,4200,120000000,110000000,62000000,36000000,18000000,System.currentTimeMillis());
        assertEquals(91000d,AssetMarketEngine.marketPrice(context,"دلار"),0.01);assertEquals(11200000d,AssetMarketEngine.marketPrice(context,"طلای ۱۸ عیار"),0.01);assertEquals(14933333d,AssetMarketEngine.marketPrice(context,"طلای ۲۴ عیار"),0.01);assertEquals(0d,AssetMarketEngine.marketPrice(context,"سهام / بورس"),0.01);
    }

    @Test
    public void assetFinance_partialSale_preservesOpenPositionAndRealizedProfit() {
        NexaStore.AssetEntry x=new NexaStore.AssetEntry();x.amount=10;x.buyUnitPrice=100;x.currentUnitPrice=130;x.fee=100;
        assertTrue(AssetFinanceEngine.sell(x,4,150,1700000000000L));
        assertEquals(6d,x.amount,0.0001);assertEquals(4d,x.soldAmount,0.0001);
        assertEquals(160d,x.realizedProfit,0.0001);assertEquals(60d,x.fee,0.0001);
        assertEquals(660d,AssetFinanceEngine.openCost(x),0.0001);
        assertEquals(120d,AssetFinanceEngine.unrealizedProfit(x),0.0001);
    }

    @Test
    public void assetFinance_rejectsOversellAndCalculatesPortfolioTotals() {
        NexaStore.AssetEntry x=new NexaStore.AssetEntry();x.amount=2;x.buyUnitPrice=100;x.currentUnitPrice=125;
        assertFalse(AssetFinanceEngine.sell(x,3,130,System.currentTimeMillis()));
        java.util.List<NexaStore.AssetEntry> list=new java.util.ArrayList<>();list.add(x);
        assertEquals(200d,AssetFinanceEngine.totalOpenCost(list),0.0001);
        assertEquals(250d,AssetFinanceEngine.totalMarketValue(list),0.0001);
        assertEquals(50d,AssetFinanceEngine.totalProfit(list),0.0001);
    }
    @Test
    public void iranMarketHistory_roundTripsAndPreservesValues(){
        NexaStore.clearMarketHistory(context);long t=System.currentTimeMillis();
        NexaStore.recordIranMarketHistory(context,t,100000,120000,7000000,9300000,2600,80000000,70000000,45000000,25000000,12000000);
        List<NexaStore.MarketHistoryPoint> h=NexaStore.marketHistory(context);assertEquals(1,h.size());assertEquals(100000d,h.get(0).usd,0.01);assertEquals(7000000d,h.get(0).gold18,0.01);assertEquals(2600d,h.get(0).ounce,0.01);NexaStore.clearMarketHistory(context);
    }

    @Test
    public void reminderRecurrence_advancesPastOccurrencesIntoFuture() {
        long now=1700000000000L;
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=now-20L*24L*60L*60L*1000L;
        r.recurrence="weekly"; r.done=true; r.active=false;
        assertTrue(ReminderRecurrence.advanceAfterDone(r,now));
        assertTrue(r.whenMillis>now);
        assertFalse(r.done);
        assertTrue(r.active);
    }

    @Test
    public void reminderRecurrence_none_doesNotMutateOneTimeReminder() {
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.whenMillis=1700000000000L; r.recurrence="none"; r.done=false; r.active=true;
        assertFalse(ReminderRecurrence.advanceAfterDone(r,1700000100000L));
        assertEquals(1700000000000L,r.whenMillis);
        assertFalse(r.done);
        assertTrue(r.active);
    }

    @Test
    public void vaultCustomGroup_renameAndDelete_preserveEntries() {
        java.util.List<NexaStore.VaultEntry> original=NexaStore.vault(context);
        try {
            NexaStore.addVaultGroup(context,"Regression Vault Group");
            NexaStore.VaultEntry x=new NexaStore.VaultEntry();x.type="Regression Vault Group";x.title="Regression Secret";NexaStore.addVault(context,x);
            assertTrue(NexaStore.renameVaultGroup(context,"Regression Vault Group","Regression Vault Renamed"));
            boolean renamed=false;for(NexaStore.VaultEntry e:NexaStore.vault(context))if(x.id.equals(e.id)){renamed=true;assertEquals("Regression Vault Renamed",e.type);}assertTrue(renamed);
            assertTrue(NexaStore.removeVaultGroup(context,"Regression Vault Renamed","سایر"));
            boolean moved=false;for(NexaStore.VaultEntry e:NexaStore.vault(context))if(x.id.equals(e.id)){moved=true;assertEquals("سایر",e.type);}assertTrue(moved);
        } finally {NexaStore.replaceVault(context,original);}
    }

    @Test
    public void vaultEntry_updatedAt_roundTrips() {
        java.util.List<NexaStore.VaultEntry> original=NexaStore.vault(context);
        try {NexaStore.VaultEntry x=new NexaStore.VaultEntry();x.title="Timestamp";x.updatedAt=1700000000123L;java.util.List<NexaStore.VaultEntry> one=new java.util.ArrayList<>();one.add(x);NexaStore.replaceVault(context,one);assertEquals(1700000000123L,NexaStore.vault(context).get(0).updatedAt);} finally {NexaStore.replaceVault(context,original);}
    }


    @Test
    public void batteryThreshold_crossingAndThreePercentRearm_areStable() {
        assertTrue(BatteryAlertManager.shouldTriggerCharge(true,true,80,80,false));
        assertFalse(BatteryAlertManager.shouldTriggerCharge(true,true,80,80,true));
        assertFalse(BatteryAlertManager.shouldRearmCharge(78,80));
        assertTrue(BatteryAlertManager.shouldRearmCharge(76,80));
        assertTrue(BatteryAlertManager.shouldTriggerLow(true,false,15,15,false));
        assertFalse(BatteryAlertManager.shouldTriggerLow(true,true,15,15,false));
        assertFalse(BatteryAlertManager.shouldRearmLow(false,17,15));
        assertTrue(BatteryAlertManager.shouldRearmLow(false,18,15));
    }

    @Test
    public void batteryAndTheft_priorityContract_isStable() {
        assertTrue(NexaAudioController.PRIORITY_THEFT > NexaAudioController.PRIORITY_SECURITY);
        assertTrue(NexaAudioController.PRIORITY_SECURITY > NexaAudioController.PRIORITY_BATTERY);
        assertEquals("nexa_battery_alarm_v3", NotificationChannelHelper.CHANNEL_BATTERY_ALARM);
        assertEquals("nexa_low_battery_v2", NotificationChannelHelper.CHANNEL_LOW_BATTERY);
        assertEquals("nexa_theft_alarm_v1", NotificationChannelHelper.CHANNEL_THEFT_ALARM);
    }
    @Test public void weatherCode_labelsAreStable(){ assertEquals("صاف",WeatherRepository.label(0)); assertEquals("بارانی",WeatherRepository.label(61)); assertEquals("برفی",WeatherRepository.label(73)); assertEquals("رعدوبرق",WeatherRepository.label(95)); }
    @Test public void weatherCache_roundTrips(){ WeatherRepository.Data d=new WeatherRepository.Data();d.city="تهران";d.temp=22.5;d.source="Regression";d.updatedAt=1700000000000L;WeatherRepository.save(context,d);WeatherRepository.Data x=WeatherRepository.cached(context);assertNotNull(x);assertEquals("تهران",x.city);assertEquals(22.5,x.temp,0.01); }


    @Test
    public void unifiedUi_touchTargetsMeetAccessibilityMinimum() {
        android.widget.Button primary = UiKit.primaryButton(context, "ذخیره");
        android.widget.Button secondary = UiKit.secondaryButton(context, "ویرایش");
        android.widget.Button icon = UiKit.editIconButton(context);
        int min = UiKit.dp(context, 48);
        assertTrue(primary.getMinimumHeight() >= min);
        assertTrue(secondary.getMinimumHeight() >= min);
        assertTrue(icon.getMinimumHeight() >= min);
        assertTrue(icon.getMinimumWidth() >= min);
    }
    @Test
    public void portableBackup_roundTrip_preservesCoreDataAndLocalVault() {
        String originalBackup = NexaStore.exportJson(context);
        java.util.List<NexaStore.VaultEntry> originalVault = NexaStore.vault(context);
        try {
            NexaStore.setSecurityAutoLockMinutes(context, 17);
            String backup = NexaStore.exportJson(context);
            assertTrue("Portable backup must declare schema 2", backup.contains("\"schema\":2"));
            assertTrue("Portable backup must explicitly exclude Vault", backup.contains("vault_note"));
            assertTrue(NexaStore.importJson(context, backup));
            assertEquals(17, NexaStore.securityAutoLockMinutes(context));
            assertEquals("Portable restore must not overwrite the device-local Vault",
                    originalVault.size(), NexaStore.vault(context).size());
        } finally {
            NexaStore.importJson(context, originalBackup);
        }
    }

    @Test
    public void bootReceiver_manifestRestoresAfterBootAndUpgrade() throws Exception {
        android.content.pm.ActivityInfo receiver = context.getPackageManager().getReceiverInfo(
                new android.content.ComponentName(context, BootReceiver.class), 0);
        assertNotNull(receiver);
        android.content.Intent boot = new android.content.Intent(android.content.Intent.ACTION_BOOT_COMPLETED);
        boot.setPackage(context.getPackageName());
        assertFalse(context.getPackageManager().queryBroadcastReceivers(boot, 0).isEmpty());
        android.content.Intent replaced = new android.content.Intent(android.content.Intent.ACTION_MY_PACKAGE_REPLACED);
        replaced.setPackage(context.getPackageName());
        assertFalse(context.getPackageManager().queryBroadcastReceivers(replaced, 0).isEmpty());
    }

    @Test
    public void reminderOccurrence_editOrRecurrenceInvalidatesOldAlarmAndActions() {
        NexaStore.Reminder r = new NexaStore.Reminder();
        r.id = "regression-occasion";
        r.active = true;
        r.done = false;
        r.whenMillis = 1792940000000L;
        r.offsetsMinutes = "0, 15, D3@09:00";
        String onTime = ReminderScheduler.occurrenceToken(r.id, "0", r.whenMillis);
        String before = ReminderScheduler.occurrenceToken(r.id, "15", r.whenMillis);
        String dayRule = ReminderScheduler.occurrenceToken(r.id, "D3@09:00", r.whenMillis);
        assertTrue(ReminderScheduler.isCurrentOccurrence(r, onTime));
        assertTrue(ReminderScheduler.isCurrentOccurrence(r, before));
        assertTrue(ReminderScheduler.isCurrentOccurrence(r, dayRule));
        assertFalse(ReminderScheduler.isCurrentOccurrence(r, "another-reminder:0:" + r.whenMillis));
        assertFalse(ReminderScheduler.isCurrentOccurrence(r, null));
        r.whenMillis += 60000L;
        assertFalse("Old due time must be rejected after edit", ReminderScheduler.isCurrentOccurrence(r, onTime));
        r.whenMillis -= 60000L;
        r.offsetsMinutes = "0";
        assertFalse("Removed rule must not ring", ReminderScheduler.isCurrentOccurrence(r, before));
        assertTrue(ReminderScheduler.isCurrentOccurrence(r, onTime));
        r.done = true;
        assertFalse(ReminderScheduler.isCurrentOccurrence(r, onTime));
        r.done = false;
        r.active = false;
        assertFalse(ReminderScheduler.isCurrentOccurrence(r, onTime));
    }

    @Test
    public void bootReceiver_reschedulesOnlyTrustedClockOrInstallActions() {
        assertTrue(BootReceiver.shouldReschedule(Intent.ACTION_BOOT_COMPLETED));
        assertTrue(BootReceiver.shouldReschedule(Intent.ACTION_MY_PACKAGE_REPLACED));
        assertTrue(BootReceiver.shouldReschedule(Intent.ACTION_TIME_CHANGED));
        assertTrue(BootReceiver.shouldReschedule(Intent.ACTION_TIMEZONE_CHANGED));
        assertTrue(BootReceiver.shouldReschedule(
                android.app.AlarmManager.ACTION_SCHEDULE_EXACT_ALARM_PERMISSION_STATE_CHANGED));
        assertFalse(BootReceiver.shouldReschedule(null));
        assertFalse(BootReceiver.shouldReschedule("unexpected.third.party.action"));
        Intent timeSet = new Intent(Intent.ACTION_TIME_CHANGED).setPackage(context.getPackageName());
        assertFalse("Clock-change receiver must be declared in Manifest",
                context.getPackageManager().queryBroadcastReceivers(timeSet, 0).isEmpty());
        Intent timezone = new Intent(Intent.ACTION_TIMEZONE_CHANGED).setPackage(context.getPackageName());
        assertFalse("Timezone receiver must be declared in Manifest",
                context.getPackageManager().queryBroadcastReceivers(timezone, 0).isEmpty());
    }

    @Test
    public void releaseCandidate_hasRequiredCorePermissionsDeclared() {
        String pkg = context.getPackageName();
        assertEquals(android.content.pm.PackageManager.PERMISSION_GRANTED,
                context.getPackageManager().checkPermission(android.Manifest.permission.RECEIVE_BOOT_COMPLETED, pkg));
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            // Runtime grant is intentionally user-controlled; declaration is validated by package metadata.
            try {
                android.content.pm.PackageInfo pi = context.getPackageManager().getPackageInfo(
                        pkg, android.content.pm.PackageManager.GET_PERMISSIONS);
                java.util.List<String> requested = java.util.Arrays.asList(pi.requestedPermissions == null ? new String[0] : pi.requestedPermissions);
                assertTrue(requested.contains(android.Manifest.permission.POST_NOTIFICATIONS));
            } catch (Exception e) {
                fail(e.getMessage());
            }
        }
    }


    @Test
    public void marketSourceLabel_isExplicitAndNotOfficialClaim() {
        assertEquals("Nexa Iran Market Feed", MarketDataHelper.IRAN_SOURCE);
        assertFalse(MarketDataHelper.IRAN_SOURCE.toLowerCase(java.util.Locale.ROOT).contains("official"));
    }
    @Test
    public void batteryThreshold_boundariesAndRearm_areStable() {
        assertTrue(BatteryAlertManager.shouldTriggerCharge(true, true, 80, 80, false));
        assertFalse(BatteryAlertManager.shouldTriggerCharge(true, true, 80, 80, true));
        assertFalse(BatteryAlertManager.shouldTriggerCharge(true, false, 90, 80, false));
        assertFalse(BatteryAlertManager.shouldRearmCharge(78, 80));
        assertTrue(BatteryAlertManager.shouldRearmCharge(76, 80));
        assertTrue(BatteryAlertManager.shouldTriggerLow(true, false, 15, 15, false));
        assertFalse(BatteryAlertManager.shouldTriggerLow(true, true, 10, 15, false));
        assertTrue(BatteryAlertManager.shouldRearmLow(true, 10, 15));
        assertTrue(BatteryAlertManager.shouldRearmLow(false, 18, 15));
    }

    @Test
    public void priceAlertEngine_activeAlertDetection_roundTrips() {
        java.util.List<NexaStore.AssetEntry> original = NexaStore.assets(context);
        try {
            java.util.List<NexaStore.AssetEntry> data = new java.util.ArrayList<>();
            NexaStore.AssetEntry x = new NexaStore.AssetEntry();
            x.name = "Regression Price Alert";
            x.type = "دلار";
            x.buyUnitPrice = 100000;
            x.currentUnitPrice = 110000;
            x.alertTarget = 120000;
            x.alertAtBuy = false;
            data.add(x);
            NexaStore.saveAssets(context, data);
            assertTrue(AssetMarketEngine.hasActiveAlerts(context));
            x.alertTarget = 0;
            x.alertAtBuy = false;
            NexaStore.saveAssets(context, data);
            assertFalse(AssetMarketEngine.hasActiveAlerts(context));
            x.alertAtBuy = true;
            NexaStore.saveAssets(context, data);
            assertTrue(AssetMarketEngine.hasActiveAlerts(context));
        } finally {
            NexaStore.saveAssets(context, original);
            PriceMonitorReceiver.cancel(context);
        }
    }

    @Test
    public void assetFinance_invalidOnlinePricesNeverCorruptTotals() {
        NexaStore.AssetEntry x=new NexaStore.AssetEntry();
        x.amount=2; x.buyUnitPrice=100; x.currentUnitPrice=Double.NaN;
        assertEquals(200d,AssetFinanceEngine.openCost(x),0.001);
        assertEquals(0d,AssetFinanceEngine.marketValue(x),0.001);
        x.currentUnitPrice=Double.POSITIVE_INFINITY;
        assertEquals(0d,AssetFinanceEngine.marketValue(x),0.001);
        assertFalse(AssetFinanceEngine.sell(x,Double.NaN,200,System.currentTimeMillis()));
        assertFalse(AssetFinanceEngine.sell(x,1,Double.POSITIVE_INFINITY,System.currentTimeMillis()));
        assertEquals(2d,x.amount,0.001);
    }

    @Test
    public void exactBigDecimalDisplay_preservesHugeIntegersAndFractionalScale() {
        assertEquals("۹٬۰۰۷٬۱۹۹٬۲۵۴٬۷۴۰٬۹۹۳٫۱۲۳۴۵۶۷۸۹۰۱۲۳۴۵۶۷۸۹",
                PersianFinancialDisplay.amount(new java.math.BigDecimal("9007199254740993.1234567890123456789")));
        assertEquals("-۱٬۲۳۴٫۰۰۵۰",
                PersianFinancialDisplay.amount(new java.math.BigDecimal("-1234.0050")));
        assertEquals("۰", PersianFinancialDisplay.amount(new java.math.BigDecimal("-0.000")));
        assertEquals("—", PersianFinancialDisplay.amount((java.math.BigDecimal) null));
        assertEquals("۰٫۰۰۰۰۰۰۰۰۰۱", PersianFinancialDisplay.amount(new java.math.BigDecimal("0.0000000001")));
    }

    @Test
    public void numberFormat_unicodeMinusNormalizesWithoutLosingPrecision() {
        assertEquals("-1,234,567", NumberFormatUtil.groupIntegerText("−۱۲۳۴۵۶۷"));
        assertEquals("-1,234.0500", NumberFormatUtil.groupDecimalText("−۱۲۳۴٫۰۵۰۰"));
        assertEquals("-1234.5", NumberFormatUtil.toLatin("−۱۲۳۴٫۵").replace("٫", "."));
        assertEquals("-", NumberFormatUtil.toLatin("−"));
    }

    @Test
    public void numberFormat_selectionEndpointsMapAcrossGrouping() {
        String before = "1234567.8900";
        String after = NumberFormatUtil.groupDecimalText(before);
        assertEquals("1,234,567.8900", after);
        assertEquals(1, NumberFormatUtil.mappedCaret(before, after, 1));
        assertEquals(9, NumberFormatUtil.mappedCaret(before, after, 7));
        assertEquals(14, NumberFormatUtil.mappedCaret(before, after, before.length()));
        assertEquals(0, NumberFormatUtil.mappedCaret(before, after, 0));
    }

    @Test
    public void medicineActions_rejectExpiredOrDisabledAndPreventOverflow() {
        NexaStore.Medicine m=new NexaStore.Medicine();
        m.id="regression-medicine";
        m.active=true;
        m.endMillis=1000L;
        assertTrue(MedicineScheduler.canAct(m,1000L));
        assertFalse(MedicineScheduler.canAct(m,1001L));
        m.active=false;
        assertFalse(MedicineScheduler.canAct(m,500L));
        m.active=true;
        m.endMillis=0;
        assertTrue(MedicineScheduler.canAct(m,Long.MAX_VALUE));
        assertEquals(-1L,MedicineScheduler.nextDoseAt(Long.MAX_VALUE-100L,24));
        assertEquals(-1L,MedicineScheduler.nextDoseAt(1000L,0));
        assertEquals(3601000L,MedicineScheduler.nextDoseAt(1000L,1));
        assertEquals(-1L,MedicineScheduler.nextDoseAt(0L,1));
    }

    @Test
    public void medicineScheduling_rejectsInvalidIdsAndRepeatOverflow() {
        NexaStore.Medicine m=new NexaStore.Medicine();
        m.active=true;
        m.nextDoseMillis=5000L;
        // Medicine generates a UUID by default; explicitly test an invalid ID.
        m.id=null;
        assertFalse(MedicineScheduler.validId(m.id));
        m.id="dose-1";
        assertTrue(MedicineScheduler.validId(m.id));
        assertTrue(MedicineScheduler.canSchedule(m,5000L));
        m.id="  ";
        assertFalse(MedicineScheduler.validId(m.id));
        assertEquals(Long.MAX_VALUE,MedicineScheduler.nextRepeatAt(Long.MAX_VALUE-100L,5));
        assertEquals(300000L,MedicineScheduler.nextRepeatAt(0L,5));
        assertEquals(360000L,MedicineScheduler.nextRepeatAt(60000L,5));
    }

    @Test
    public void numericFinalization_exactCurrencyAndGrouping() {
        assertEquals("123456789012345678901234567890.0500",
                NumberFormatUtil.decimalValue("۱۲۳٬۴۵۶٬۷۸۹٬۰۱۲٬۳۴۵٬۶۷۸٬۹۰۱٬۲۳۴٬۵۶۷٬۸۹۰٫۰۵۰۰").toPlainString());
        assertEquals(0,new java.math.BigDecimal("125").compareTo(NumberFormatUtil.tomanToRial("۱۲٫۵۰")));
        assertEquals(0,new java.math.BigDecimal("12.5").compareTo(NumberFormatUtil.rialToToman("۱۲۵")));
        assertEquals(Long.MAX_VALUE,NumberFormatUtil.clampedLong(
                NumberFormatUtil.decimalValue("999999999999999999999999")));
        assertEquals(Long.MIN_VALUE,NumberFormatUtil.clampedLong(
                NumberFormatUtil.decimalValue("-999999999999999999999999")));
        assertEquals("9,223,372,036,854,775,807",NumberFormatUtil.grouped(Long.MAX_VALUE));
        assertEquals("0",NumberFormatUtil.groupIntegerText("−۰۰۰"));
        assertEquals("-0.0001",NumberFormatUtil.groupDecimalText("−۰٫۰۰۰۱"));
    }

    @Test
    public void financeTotals_doNotPropagateNonFiniteInputs() {
        NexaStore.AssetEntry entry=new NexaStore.AssetEntry();
        entry.amount=Double.MAX_VALUE;
        entry.buyUnitPrice=Double.MAX_VALUE;
        entry.currentUnitPrice=Double.NaN;
        entry.fee=Double.POSITIVE_INFINITY;
        assertTrue(Double.isFinite(AssetFinanceEngine.openCost(entry)));
        assertTrue(Double.isFinite(AssetFinanceEngine.marketValue(entry)));
        assertTrue(Double.isFinite(AssetFinanceEngine.unrealizedProfit(entry)));
        assertTrue(Double.isFinite(AssetFinanceEngine.returnPercent(entry)));
    }

    @Test
    public void alarmSoundSelection_resetAllPreservesFallback() {
        android.net.Uri sound=android.net.Uri.parse("content://example.provider/audio/test");
        int[] profiles={NexaAudioController.SOUND_ALARM,NexaAudioController.SOUND_REMINDER,
                NexaAudioController.SOUND_BATTERY,NexaAudioController.SOUND_THEFT,
                NexaAudioController.SOUND_SILENT_EXIT};
        try {
            for(int profile:profiles)AlarmSoundSelection.save(context,profile,sound);
            AlarmSoundSelection.resetAll(context);
            for(int profile:profiles){
                assertNull(AlarmSoundSelection.chosen(context,profile));
                assertNotNull(AlarmSoundSelection.fallback(context,profile));
            }
        } finally {
            AlarmSoundSelection.resetAll(context);
        }
    }

    @Test
    public void alarmSoundPreferences_independentVolumeAndSecurityLimits() {
        int alarm=NexaAudioController.SOUND_ALARM;
        int reminder=NexaAudioController.SOUND_REMINDER;
        int battery=NexaAudioController.SOUND_BATTERY;
        int theft=NexaAudioController.SOUND_THEFT;
        int silentExit=NexaAudioController.SOUND_SILENT_EXIT;
        try {
            AlarmSoundSelection.resetAll(context);
            assertEquals(100,AlarmSoundSelection.volumePercent(context,alarm));
            assertEquals(100,AlarmSoundSelection.volumePercent(context,reminder));
            assertEquals(1f,AlarmSoundSelection.volumeGain(context,battery),0.00001f);
            AlarmSoundSelection.setVolumePercent(context,reminder,45);
            AlarmSoundSelection.setVolumePercent(context,battery,-10);
            AlarmSoundSelection.setVolumePercent(context,theft,0);
            AlarmSoundSelection.setVolumePercent(context,alarm,1000);
            AlarmSoundSelection.setVolumePercent(context,silentExit,0);
            assertEquals(45,AlarmSoundSelection.volumePercent(context,reminder));
            assertEquals(35,AlarmSoundSelection.volumePercent(context,battery));
            assertEquals(80,AlarmSoundSelection.volumePercent(context,theft));
            assertEquals(100,AlarmSoundSelection.volumePercent(context,alarm));
            assertEquals(0,AlarmSoundSelection.volumePercent(context,silentExit));
            assertEquals(0.45f,AlarmSoundSelection.volumeGain(context,reminder),0.00001f);
            assertEquals(100,AlarmSoundSelection.normalizedVolumePercent(999,8));
        } finally {
            AlarmSoundSelection.resetAll(context);
        }
    }

    @Test
    public void alarmSoundPreferences_vibrationAndResetDoNotEraseDeviceSettings() {
        int reminder=NexaAudioController.SOUND_REMINDER;
        int battery=NexaAudioController.SOUND_BATTERY;
        int theft=NexaAudioController.SOUND_THEFT;
        int exit=NexaAudioController.SOUND_SILENT_EXIT;
        android.net.Uri chosen=android.net.Uri.parse("content://example.provider/audio/selected");
        try {
            AlarmSoundSelection.resetAll(context);
            assertTrue(AlarmSoundSelection.vibrationEnabled(context,reminder));
            assertTrue(AlarmSoundSelection.vibrationEnabled(context,theft));
            assertFalse(AlarmSoundSelection.vibrationEnabled(context,exit));
            AlarmSoundSelection.save(context,reminder,chosen);
            AlarmSoundSelection.setVolumePercent(context,reminder,60);
            AlarmSoundSelection.setVibrationEnabled(context,reminder,false);
            AlarmSoundSelection.setVibrationEnabled(context,battery,false);
            AlarmSoundSelection.setVibrationEnabled(context,theft,false);
            AlarmSoundSelection.setVibrationEnabled(context,exit,true);
            assertEquals(chosen,AlarmSoundSelection.chosen(context,reminder));
            assertEquals(60,AlarmSoundSelection.volumePercent(context,reminder));
            assertFalse(AlarmSoundSelection.vibrationEnabled(context,reminder));
            assertFalse(AlarmSoundSelection.vibrationEnabled(context,battery));
            assertTrue(AlarmSoundSelection.vibrationEnabled(context,theft));
            assertFalse(AlarmSoundSelection.vibrationEnabled(context,exit));
            AlarmSoundSelection.resetAll(context);
            assertNull(AlarmSoundSelection.chosen(context,reminder));
            assertEquals(100,AlarmSoundSelection.volumePercent(context,reminder));
            assertTrue(AlarmSoundSelection.vibrationEnabled(context,reminder));
            assertTrue(AlarmSoundSelection.vibrationEnabled(context,battery));
            assertTrue(AlarmSoundSelection.vibrationEnabled(context,theft));
        } finally {
            AlarmSoundSelection.resetAll(context);
        }
    }


    @Test
    public void reminderOrganizer_searchAcrossFieldsHandlesPersianAndArabicVariants(){
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.title="پرداخت قبض";
        r.category="كارهاي مالی";
        r.note="قسط ۱۲۳";
        r.doctorName="دكتر رفيعي";
        r.doctorPhone="۰۹۱۲۱۲۳۴۵۶۷";
        assertTrue(ReminderOrganizer.matches(r,"پرداخت"));
        assertTrue(ReminderOrganizer.matches(r,"كارهای مالی"));
        assertTrue(ReminderOrganizer.matches(r,"قبض قسط"));
        assertTrue(ReminderOrganizer.matches(r,"دکتر رفیعی"));
        assertTrue(ReminderOrganizer.matches(r,"09121234567"));
        assertFalse(ReminderOrganizer.matches(r,"جلسه"));
        assertTrue(ReminderOrganizer.matches(r,""));
        assertFalse(ReminderOrganizer.matches(null,""));
    }

    @Test
    public void reminderOrganizer_filtersAndSmartOrderPreserveSource(){
        long now=1700000000000L;
        NexaStore.Reminder due=new NexaStore.Reminder();
        due.title="pending";due.whenMillis=now+1000L;
        NexaStore.Reminder late=new NexaStore.Reminder();
        late.title="overdue";late.whenMillis=now-1000L;
        NexaStore.Reminder paused=new NexaStore.Reminder();
        paused.title="paused";paused.active=false;paused.whenMillis=now-500L;
        NexaStore.Reminder done=new NexaStore.Reminder();
        done.title="done";done.done=true;done.active=false;done.whenMillis=now-2000L;
        java.util.List<NexaStore.Reminder> original=new java.util.ArrayList<>();
        original.add(done);original.add(due);original.add(paused);original.add(late);
        java.util.List<NexaStore.Reminder> smart=ReminderOrganizer.ordered(original,"smart",now);
        assertEquals("overdue",smart.get(0).title);
        assertEquals("pending",smart.get(1).title);
        assertEquals("paused",smart.get(2).title);
        assertEquals("done",smart.get(3).title);
        assertEquals("done",original.get(0).title); // No in-place sort of store data.
        assertTrue(ReminderOrganizer.visible(paused,"paused",now));
        assertFalse(ReminderOrganizer.visible(paused,"overdue",now));
        assertTrue(ReminderOrganizer.visible(late,"overdue",now));
        assertTrue(ReminderOrganizer.visible(due,"pending",now));
        assertFalse(ReminderOrganizer.visible(done,"pending",now));
        assertEquals("done",ReminderOrganizer.ordered(original,"due",now).get(0).title);
        assertEquals("pending",ReminderOrganizer.ordered(original,"recent",now).get(0).title);
    }

    @Test
    public void reminderOrganizer_quickPostponeAndCopyAlwaysFuture(){
        java.util.Calendar c=java.util.Calendar.getInstance();
        c.set(2026,java.util.Calendar.JUNE,12,14,35,0);c.set(java.util.Calendar.MILLISECOND,0);
        long now=c.getTimeInMillis();
        c.set(2026,java.util.Calendar.MARCH,4,9,20,0);
        long previous=c.getTimeInMillis();
        assertEquals(now+15L*60_000L,ReminderOrganizer.postponedUntil(previous,now,0));
        assertEquals(now+60L*60_000L,ReminderOrganizer.postponedUntil(previous,now,1));
        long tomorrow=ReminderOrganizer.postponedUntil(previous,now,2);
        assertTrue(tomorrow>now);
        c.setTimeInMillis(tomorrow);
        assertEquals(13,c.get(java.util.Calendar.DAY_OF_MONTH));
        assertEquals(9,c.get(java.util.Calendar.HOUR_OF_DAY));
        assertEquals(20,c.get(java.util.Calendar.MINUTE));
        assertEquals(tomorrow,ReminderOrganizer.copiedDue(previous,now));
        c.setTimeInMillis(now);c.add(java.util.Calendar.DAY_OF_YEAR,2);
        long future=c.getTimeInMillis();
        assertTrue(ReminderOrganizer.copiedDue(future,now)>future);
    }

    @Test
    public void reminderCustomSound_persistsAcrossJsonAndOldDataDefaultsToGlobal() throws Exception {
        NexaStore.Reminder r=new NexaStore.Reminder();
        assertEquals("",r.customSoundUri);
        assertEquals("",NexaStore.Reminder.from(new org.json.JSONObject()).customSoundUri);
        r.customSoundUri="content://media/external/audio/media/123";
        org.json.JSONObject saved=r.json();
        assertEquals(r.customSoundUri,NexaStore.Reminder.from(saved).customSoundUri);
        saved.put("customSoundUri","https://example.com/untrusted.mp3");
        assertEquals("",NexaStore.Reminder.from(saved).customSoundUri);
        assertEquals("",ReminderSoundSelection.normalize("file:///sdcard/ringtone.mp3"));
        assertEquals("",ReminderSoundSelection.normalize(null));
        assertEquals("",ReminderSoundSelection.normalize(""));
        assertEquals("content://media/external/audio/media/123",
            ReminderSoundSelection.normalize(" content://media/external/audio/media/123 "));
    }

    @Test
    public void reminderCustomSound_inheritsWithoutChangingGlobalAndHandlesUnmountedFiles(){
        int profile=NexaAudioController.SOUND_REMINDER;
        android.net.Uri old=AlarmSoundSelection.chosen(context,profile);
        try{
            AlarmSoundSelection.save(context,profile,null);
            assertNull(ReminderSoundSelection.selected(""));
            assertNull(ReminderSoundSelection.usable(context,""));
            assertEquals("صدای عمومی یادآورها",ReminderSoundSelection.displayName(context,""));
            assertNull(ReminderSoundSelection.usable(context,"file:///sdcard/private.mp3"));
            assertNull(ReminderSoundSelection.usable(context,"content://missing.nexa.provider/removed-file"));
            assertNull(AlarmSoundSelection.chosen(context,profile));
        }finally{
            AlarmSoundSelection.save(context,profile,old);
        }
    }

    @Test
    public void alarmSoundSelection_profilesAndPersistentChoice() {
        int profile=NexaAudioController.SOUND_REMINDER;
        assertTrue(AlarmSoundSelection.validProfile(profile));
        assertFalse(AlarmSoundSelection.validProfile(999));
        android.net.Uri sample=android.net.Uri.parse("content://example.provider/audio/123");
        AlarmSoundSelection.save(context,profile,sample);
        assertEquals(sample,AlarmSoundSelection.chosen(context,profile));
        assertEquals(sample,AlarmSoundSelection.resolve(context,profile));
        AlarmSoundSelection.save(context,profile,null);
        assertNull(AlarmSoundSelection.chosen(context,profile));
        assertNotNull(AlarmSoundSelection.fallback(context,NexaAudioController.SOUND_THEFT));
        assertEquals(Intent.ACTION_OPEN_DOCUMENT,AlarmSoundSelection.audioDocumentIntent().getAction());
    }

    @Test
    public void alarmSoundSelection_silentExitAndUntrustedUris() {
        int profile=NexaAudioController.SOUND_SILENT_EXIT;
        assertTrue(AlarmSoundSelection.validProfile(profile));
        assertNotNull(AlarmSoundSelection.fallback(context,profile));
        android.net.Uri good=android.net.Uri.parse("content://example.provider/audio/456");
        android.net.Uri bad=android.net.Uri.parse("file:///sdcard/private.mp3");
        assertTrue(AlarmSoundSelection.isSupportedUri(good));
        assertFalse(AlarmSoundSelection.isSupportedUri(bad));
        AlarmSoundSelection.save(context,profile,good);
        AlarmSoundSelection.save(context,profile,bad);
        assertEquals(good,AlarmSoundSelection.chosen(context,profile));
        AlarmSoundSelection.save(context,profile,null);
        assertNull(AlarmSoundSelection.chosen(context,profile));
        assertFalse(AlarmSoundSelection.isReadable(context,bad));
    }

    @Test
    public void alarmSoundSelection_previewSafetyAndChannelSettings() {
        assertTrue(AlarmSoundSelection.canPreview(0));
        assertFalse(AlarmSoundSelection.canPreview(NexaAudioController.PRIORITY_NORMAL));
        assertFalse(AlarmSoundSelection.canPreview(NexaAudioController.PRIORITY_THEFT));
        android.content.Intent settings=AlarmSoundSelection.notificationSettingsIntent(context);
        assertEquals(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS,settings.getAction());
        assertEquals(context.getPackageName(),
            settings.getStringExtra(android.provider.Settings.EXTRA_APP_PACKAGE));
        int profile=NexaAudioController.SOUND_SILENT_EXIT;
        android.net.Uri unreadable=android.net.Uri.parse("content://invalid.example/no-audio");
        AlarmSoundSelection.save(context,profile,unreadable);
        assertEquals(AlarmSoundSelection.fallback(context,profile),
            AlarmSoundSelection.readableOrFallback(context,profile));
        AlarmSoundSelection.save(context,profile,null);
    }

    @Test
    public void alarmAudioFocus_phoneCallPriorityPolicy() {
        assertTrue(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_NORMAL));
        assertTrue(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_REMINDER));
        assertTrue(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_MEDICINE));
        assertFalse(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_SECURITY));
        assertFalse(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_THEFT));
        assertFalse(NexaAudioController.isCallAudioMode(null));
    }

    @Test
    public void alarmAudioFocus_callDeferKeepsSecurityExceptions() {
        assertTrue(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_BATTERY));
        assertTrue(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_MEDICINE));
        assertFalse(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_SECURITY));
        assertFalse(NexaAudioController.shouldDeferDuringCall(NexaAudioController.PRIORITY_THEFT));
        NexaAudioController.stopAll();
        assertEquals(0,NexaAudioController.getActivePriority());
    }

    @Test
    public void reminderCallAudioRetry_isBoundedAndOnlyForOneShot() {
        assertTrue(ReminderAlarmReceiver.shouldRetryCallAudio(0, 1));
        assertTrue(ReminderAlarmReceiver.shouldRetryCallAudio(0, 4));
        assertFalse(ReminderAlarmReceiver.shouldRetryCallAudio(0, 5));
        assertFalse(ReminderAlarmReceiver.shouldRetryCallAudio(0, 0));
        assertFalse(ReminderAlarmReceiver.shouldRetryCallAudio(5, 1));
    }


    @org.junit.Test
    public void reminderSnooze_neverSchedulesImmediately() {
        assertEquals(5, ReminderActionReceiver.safeSnoozeMinutes(0));
        assertEquals(5, ReminderActionReceiver.safeSnoozeMinutes(-1));
        assertEquals(10, ReminderActionReceiver.safeSnoozeMinutes(10));
    }

    @Test
    public void reminderActions_rejectUnknownOrNullAction() {
        assertTrue(ReminderActionReceiver.isSupportedAction("DONE"));
        assertTrue(ReminderActionReceiver.isSupportedAction("DISMISS"));
        assertTrue(ReminderActionReceiver.isSupportedAction("SNOOZE"));
        assertFalse(ReminderActionReceiver.isSupportedAction(null));
        assertFalse(ReminderActionReceiver.isSupportedAction("UNEXPECTED"));
    }
    @Test
    public void recurringReminder_tokensAreScopedToOccurrence() {
        String first=ReminderScheduler.occurrenceToken("rem1","0",1000L);
        String next=ReminderScheduler.occurrenceToken("rem1","0",2000L);
        assertFalse(first.equals(next));
        assertEquals(first, ReminderScheduler.occurrenceToken("rem1","0",1000L));
        assertFalse(first.equals(ReminderScheduler.occurrenceToken("rem1","10",1000L)));
    }

    @Test
    public void reminderBatch_pauseResumeOnlyEligibleFutureReminders(){
        long now=1_700_000_000_000L;
        NexaStore.Reminder future=new NexaStore.Reminder();
        future.whenMillis=now+600_000L;
        future.active=true;future.done=false;
        assertTrue(ReminderBatchManager.eligible(future,ReminderBatchManager.PAUSE,now));
        assertTrue(ReminderBatchManager.apply(future,ReminderBatchManager.PAUSE,now));
        assertFalse(future.active);
        assertFalse(ReminderBatchManager.eligible(future,ReminderBatchManager.PAUSE,now));
        assertTrue(ReminderBatchManager.eligible(future,ReminderBatchManager.RESUME,now));
        assertTrue(ReminderBatchManager.apply(future,ReminderBatchManager.RESUME,now));
        assertTrue(future.active);
        assertFalse(ReminderBatchManager.eligible(future,ReminderBatchManager.RESUME,now));

        future.active=false;future.whenMillis=now-1;
        assertFalse(ReminderBatchManager.eligible(future,ReminderBatchManager.RESUME,now));
        assertFalse(ReminderBatchManager.apply(future,ReminderBatchManager.RESUME,now));
        assertFalse(future.active);
        future.whenMillis=now;
        assertFalse(ReminderBatchManager.eligible(future,ReminderBatchManager.RESUME,now));
        assertFalse(ReminderBatchManager.eligible(future,"delete",now));
        assertFalse(ReminderBatchManager.eligible(null,ReminderBatchManager.PAUSE,now));
    }

    @Test
    public void reminderBatch_doneAdvancesRecurringButCompletesOneShot(){
        long now=1_700_000_000_000L;
        NexaStore.Reminder once=new NexaStore.Reminder();
        once.whenMillis=now+10_000L; once.active=true;once.recurrence="none";
        assertTrue(ReminderBatchManager.apply(once,ReminderBatchManager.DONE,now));
        assertTrue(once.done); assertFalse(once.active);
        assertFalse(ReminderBatchManager.eligible(once,ReminderBatchManager.DONE,now));

        NexaStore.Reminder repeating=new NexaStore.Reminder();
        repeating.whenMillis=now-5*24*60*60_000L;
        repeating.recurrence="daily";repeating.active=false;
        assertTrue(ReminderBatchManager.apply(repeating,ReminderBatchManager.DONE,now));
        assertFalse(repeating.done);
        assertTrue(repeating.active);
        assertTrue(repeating.whenMillis>now);
    }

    @Test
    public void build215_reminderDirectoryShowsCurrentOccurrenceAndAccessibleSearch(){
        java.util.Calendar c=java.util.Calendar.getInstance();
        c.set(2026,java.util.Calendar.NOVEMBER,2,8,0,0);
        c.set(java.util.Calendar.MILLISECOND,0);
        long now=c.getTimeInMillis();
        long today=AgendaDuePolicy.startOfDay(now);
        NexaStore.Reminder repeating=new NexaStore.Reminder();
        repeating.title="بررسی ماهانه";
        repeating.recurrence="daily";
        repeating.whenMillis=AgendaDuePolicy.afterCalendarDays(today,-30)+9L*3600_000L;
        assertEquals(today+9L*3600_000L,ReminderOrganizer.effectiveDue(repeating,now));
        assertTrue(ReminderOrganizer.visible(repeating,"pending",now));
        assertFalse(ReminderOrganizer.visible(repeating,"overdue",now));
        assertTrue(ReminderOrganizer.matches(repeating,"بررسي"));
        repeating.active=false;
        assertTrue(ReminderOrganizer.visible(repeating,"paused",now));
        assertFalse(ReminderOrganizer.visible(repeating,"week",now));
        assertEquals(repeating.whenMillis,ReminderOrganizer.effectiveDue(repeating,now));
    }

    @Test
    public void reminderOrganizer_upcomingWeekIncludesOnlyFutureActive(){
        long now=1_700_000_000_000L;
        NexaStore.Reminder r=new NexaStore.Reminder();
        r.active=true; r.done=false;
        r.whenMillis=now+60_000L;
        assertTrue(ReminderOrganizer.visible(r,"week",now));
        r.whenMillis=now+7L*24*60*60_000L;
        assertTrue(ReminderOrganizer.visible(r,"week",now));
        r.whenMillis++;
        assertFalse(ReminderOrganizer.visible(r,"week",now));
        r.whenMillis=now-1;
        assertFalse(ReminderOrganizer.visible(r,"week",now));
        r.whenMillis=now+60_000L;r.active=false;
        assertFalse(ReminderOrganizer.visible(r,"week",now));
        r.active=true;r.done=true;
        assertFalse(ReminderOrganizer.visible(r,"week",now));
    }

    @Test
    public void billForecast_doesNotMixOverdueWithFutureAndExcludesPaid() {
        long now=PersianDateUtil.toMillis(1405,7,1,10,0);
        long future=BillForecast.horizon(now,3);
        BillForecast.Entry a=new BillForecast.Entry("a","قسط","قسط",200,future,"یک‌بار",false);
        BillForecast.Entry b=new BillForecast.Entry("b","قبض معوق","قبض",300,now-1000,"یک‌بار",false);
        BillForecast.Entry c=new BillForecast.Entry("c","پرداخت‌شده","قبض",500,future,"یک‌بار",true);
        BillForecast.Result r=BillForecast.calculate(java.util.Arrays.asList(a,b,c),now,30);
        assertEquals(1,r.upcoming.size());
        assertEquals(1,r.overdue.size());
        assertEquals(200L,r.upcomingTotal);
        assertEquals(300L,r.overdueTotal);
        assertEquals("a",r.upcoming.get(0).id);
        assertFalse(r.upcoming.get(0).projected);
    }

    @Test
    public void billForecast_monthlyAndYearlyRespectJalaliDates() {
        long now=PersianDateUtil.toMillis(1405,6,30,10,0);
        long monthlyDue=PersianDateUtil.toMillis(1405,6,31,10,0);
        long annualDue=PersianDateUtil.toMillis(1405,7,2,10,0);
        BillForecast.Result r=BillForecast.calculate(java.util.Arrays.asList(
                new BillForecast.Entry("monthly","اجاره","اجاره",100,monthlyDue,"ماهانه",false),
                new BillForecast.Entry("annual","بیمه","بیمه",200,annualDue,"سالانه",false)
        ),now,90);
        assertTrue(r.overdue.isEmpty());
        int monthly=0,annual=0;
        for(BillForecast.Occurrence o:r.upcoming){
            if("monthly".equals(o.id)){
                monthly++;
                if(monthly==1){
                    assertEquals(31,PersianDateUtil.fromMillis(o.at)[2]);
                    assertFalse(o.projected);
                } else {
                    assertEquals(30,PersianDateUtil.fromMillis(o.at)[2]);
                    assertTrue(o.projected);
                }
            }
            if("annual".equals(o.id)){
                annual++;
                assertEquals(2,PersianDateUtil.fromMillis(o.at)[2]);
                assertFalse(o.projected);
            }
        }
        assertTrue(monthly>=2);
        assertEquals(1,annual);
        assertTrue(r.upcomingTotal>=400L);
    }

    @Test
    public void billForecast_unpaidOverdueRecurringBillMustNotCreateFutureOccurrences(){
        long now=PersianDateUtil.toMillis(1405,7,1,10,0);
        BillForecast.Result r=BillForecast.calculate(java.util.Arrays.asList(
                new BillForecast.Entry("overdue","معوق ماهانه","قسط",500,
                        PersianDateUtil.toMillis(1405,6,29,10,0),"ماهانه",false)
        ),now,90);
        assertTrue(r.upcoming.isEmpty());
        assertEquals(1,r.overdue.size());
        assertEquals(500L,r.overdueTotal);
    }

    @Test
    public void billForecast_horizonExcludesBoundaryAndCannotOverflow() {
        long now=PersianDateUtil.toMillis(1405,7,1,10,0);
        long boundary=BillForecast.horizon(now,30);
        BillForecast.Result r=BillForecast.calculate(java.util.Arrays.asList(
                new BillForecast.Entry("inside","الف","قبض",Long.MAX_VALUE,now,"یک‌بار",false),
                new BillForecast.Entry("inside2","ب","قبض",Long.MAX_VALUE,now+1000,"یک‌بار",false),
                new BillForecast.Entry("boundary","ج","قبض",9,boundary,"یک‌بار",false),
                new BillForecast.Entry("negative","د","قبض",-8,now+2_000,"یک‌بار",false)
        ),now,30);
        assertEquals(3,r.upcoming.size());
        assertEquals(Long.MAX_VALUE,r.upcomingTotal);
        assertEquals(0L,r.overdueTotal);
        assertEquals(Long.MAX_VALUE,BillForecast.sumBefore(r.upcoming,BillForecast.horizon(now,7)));
        try{r.upcoming.clear();fail("Forecast list must be immutable");}
        catch(UnsupportedOperationException expected){}
    }

    @Test
    public void billForecast_skipsNullAndOldUnrecognizedAndRejectsInvalidHorizon(){
        long now=PersianDateUtil.toMillis(1405,7,1,10,0);
        BillForecast.Result r=BillForecast.calculate(java.util.Arrays.asList(
                null,
                new BillForecast.Entry("",null,null,5,0,null,false),
                new BillForecast.Entry("old","قدیمی","",50,now-1000,"نامعتبر",false)
        ),now,30);
        assertTrue(r.upcoming.isEmpty());
        assertEquals(1,r.overdue.size());
        assertEquals(50L,r.overdueTotal);
        try{BillForecast.calculate(null,now,91);fail("Invalid horizon allowed");}
        catch(IllegalArgumentException expected){}
    }


    @Test
    public void backgroundCompletion_isExactlyOnce() {
        OneShotGate gate = new OneShotGate();
        assertFalse(gate.isCompleted());
        assertTrue(gate.claim());
        assertTrue(gate.isCompleted());
        assertFalse("late network response must not finish the same broadcast twice", gate.claim());
    }

    @Test
    public void backgroundDiagnostics_areLocalAndReadable() {
        String old = BackgroundReliability.recent(context);
        assertNotNull(old);
        BackgroundReliability.run(context, "regression.test", () -> {
            throw new IllegalStateException("DO_NOT_PERSIST_SENSITIVE_CONTENT");
        });
        String report = BackgroundReliability.recent(context);
        assertTrue(report.contains("regression.test"));
        assertTrue(report.contains("IllegalStateException"));
        assertFalse("exception messages must not be stored", report.contains("DO_NOT_PERSIST_SENSITIVE_CONTENT"));
    }
    @Test
    public void build194_agendaPremiumSurfacesRetainTodayAndTimelineDestinations(){
        assertNotNull(new android.content.Intent(context, TodayActivity.class));
        assertNotNull(new android.content.Intent(context, TimelineActivity.class));
        android.widget.LinearLayout cards=NexaAgendaUi.stats(context,
                new String[]{"امروز","معوق","تکمیل"},new String[]{"1","2","3"},
                new int[]{UiKit.PURPLE,UiKit.RED,UiKit.GREEN});
        assertEquals("Every status metric must remain visible",3,cards.getChildCount());
        android.widget.LinearLayout clickable=NexaAgendaUi.event(context,"📅","آزمون","موعد امروز",
                "در انتظار",UiKit.PURPLE,true);
        assertTrue("Agenda item must retain an accessible touch target",
                clickable.getMinimumHeight()>=UiKit.dp(context,72));
        assertEquals(android.view.View.LAYOUT_DIRECTION_RTL,clickable.getLayoutDirection());
    }

}
