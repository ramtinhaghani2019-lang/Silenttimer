package com.example.silenttimer;

import static org.junit.Assert.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;
import android.content.Context;
import org.json.JSONObject;
import org.junit.Test;
import org.junit.runner.RunWith;

/** Contracts covering day-over-day change, source units and automatic refresh. */
@RunWith(AndroidJUnit4.class)
public class AssetMarket237RegressionTest {
    @Test public void marketCardsUseActualRialNumbersForTomanFeed(){
        assertEquals(PersianFinancialDisplay.amount2(2661100d),AssetRatesPanel.formattedRate(266110d,"دلار"));
        assertEquals(PersianFinancialDisplay.amount2(255940000d),AssetRatesPanel.formattedRate(25594000d,"طلای ۱۸ عیار"));
        assertEquals(PersianFinancialDisplay.amount2(4070.41d),AssetRatesPanel.formattedRate(4070.41d,"اونس جهانی"));
        assertEquals("—",AssetRatesPanel.formattedRate(0,"دلار"));
    }
    @Test public void sourceChangesMustExistToDisplayDirection() throws Exception {
        Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
        JSONObject d=new JSONObject().put("dollar",0.43).put("euro",-0.10).put("gold",0.76);
        MarketChangeStore.save(c,d,"1405/08/17","19:35");
        assertEquals(0.43,MarketChangeStore.percent(c,"دلار"),0.000001);
        assertEquals(-0.10,MarketChangeStore.percent(c,"یورو"),0.000001);
        assertTrue(Double.isNaN(MarketChangeStore.percent(c,"ربع‌سکه")));
        assertTrue(MarketChangeStore.sourceDate(c).contains("1405/08/17"));
        MarketChangeStore.save(c,null,"1405/08/18","");
        assertTrue(Double.isNaN(MarketChangeStore.percent(c,"دلار")));
    }
    @Test public void migrationKeepsOfflineAndEnablesAutomaticLegacyRequests(){
        Context c=InstrumentationRegistry.getInstrumentation().getTargetContext();
        android.content.SharedPreferences p=c.getSharedPreferences("nexa_store",Context.MODE_PRIVATE);
        p.edit().remove("market_auto_migration_237").putInt("market_refresh_mode",1).commit();
        NexaStore.migrateAutoMarketRefresh237(c);
        assertEquals(2,NexaStore.marketRefreshMode(c));
        p.edit().remove("market_auto_migration_237").putInt("market_refresh_mode",0).commit();
        NexaStore.migrateAutoMarketRefresh237(c);
        assertEquals(0,NexaStore.marketRefreshMode(c));
        // Restore the default so other tests are unaffected.
        p.edit().putInt("market_refresh_mode",2).commit();
    }
}
