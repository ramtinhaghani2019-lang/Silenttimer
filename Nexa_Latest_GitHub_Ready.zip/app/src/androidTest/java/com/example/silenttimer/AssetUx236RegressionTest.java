package com.example.silenttimer;

import static org.junit.Assert.*;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import org.junit.Test;
import org.junit.runner.RunWith;

/** UX design candidate: type categories, shared icons and legacy Rial conversion. */
@RunWith(AndroidJUnit4.class)
public class AssetUx236RegressionTest {
    @Test public void assetPickerCategorizesAndLabelsNativeTypes(){
        assertEquals("فلزات گران‌بها",AssetSelectionSheet.category("طلای ۱۸ عیار"));
        assertEquals("ارزها",AssetSelectionSheet.category("دلار"));
        assertEquals("سکه‌ها",AssetSelectionSheet.category("نیم‌سکه بهار آزادی"));
        assertEquals("صندوق‌ها و سهام",AssetSelectionSheet.category("سهام / بورس"));
        assertEquals("سایر",AssetSelectionSheet.category("زمین"));
        assertEquals("گرم",AssetSelectionSheet.unit("طلای ۲۴ عیار"));
        assertEquals("عدد",AssetSelectionSheet.unit("ربع‌سکه بهار آزادی"));
        assertEquals("سهم",AssetSelectionSheet.unit("سهام / بورس"));
        assertEquals("طلاعیار۱۸",AssetSelectionSheet.normalize("طلا عيار ۱۸"));
    }
    @Test public void sameIconRegistryPowersPickerPortfolioAndMarket(){
        assertEquals("usd",AssetVisualPolicy.iconFor("دلار"));
        assertEquals("eur",AssetVisualPolicy.iconFor("یورو"));
        assertEquals("gold",AssetVisualPolicy.iconFor("طلای ۱۸ عیار"));
        assertEquals("silver",AssetVisualPolicy.iconFor("نقره"));
        assertEquals("copper",AssetVisualPolicy.iconFor("مس"));
        assertEquals("coin",AssetVisualPolicy.iconFor("سکه امامی"));
        assertEquals("ounce",AssetVisualPolicy.iconFor("اونس جهانی"));
        assertEquals("stocks",AssetVisualPolicy.iconFor("سهام / بورس"));
    }
    @Test public void rialDisplayKeepsLegacyStorageUnchanged(){
        assertEquals(10_000_000d,AssetMoneyUnit.fromStored(1_000_000d,"ریال"),0.001d);
        assertEquals(1_000_000d,AssetMoneyUnit.toStored(10_000_000d,"ریال"),0.001d);
        assertEquals(100_000d,AssetMoneyUnit.fromStored(100_000d,"تومان"),0.001d);
        assertEquals("208.2559389",AssetPurchaseMath.quantityText(208.2559389d));
        assertTrue(AssetPurchaseMath.valid(1_005_000_035d,4_801_784d,5_000_000d));
    }
}
