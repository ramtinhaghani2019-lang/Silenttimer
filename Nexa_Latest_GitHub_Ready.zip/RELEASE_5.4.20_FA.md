# Nexa 5.4.20 — Build 42

بسته چنداصلاحی Today / Navigation:

1. ارتقای نسخه به 5.4.20 / Build 42.
2. افزودن پیش‌نمایش برنامه فردا در Nexa Today.
3. افزودن شمارنده موارد فردا به Summary امروز.
4. افزودن میانبر History/Timeline داخل Today.
5. افزودن میانبر Search داخل Today.
6. نمایش یادداشت Unlock ذخیره‌شده برای ویرایش، به‌جای فرم خالی.
7. امکان به‌روزرسانی همان یادداشت Unlock با بازخورد ذخیره موفق.
8. افزودن دکمه پاک‌کردن مستقیم Unlock Note.
9. قابل‌کلیک شدن کل کارت «امروز در Nexa» در Home، علاوه بر دکمه موجود.
10. به‌روزرسانی Regression identity guard به 5.4.20 / Build 42.

این بسته منطق Medicine، Silent Timer، Vault، Database، Alarm delivery و GitHub workflow را تغییر نمی‌دهد.
