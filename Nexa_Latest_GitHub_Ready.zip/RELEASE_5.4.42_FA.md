# Nexa 5.4.42 / Build 64

- حذف کامل Theme Engine و Theme Packs قابل دانلود/انتخاب
- حذف ThemeManager و کاتالوگ/دانلود/ذخیره تم‌ها
- حذف previewهای تم‌های جایگزین و مستند Theme Packs
- تثبیت رابط کاربری روی ظاهر اصلی Graphite Nexa
- حفظ پس‌زمینه اصلی Graphite Teal به‌عنوان ظاهر ثابت برنامه
- حذف تنظیم قدیمی theme از AppPrefs API
- AuraView و UiKit مستقل از ThemeManager شدند
- Regression نسخه به 5.4.42 / Build 64 به‌روزرسانی شد
