# Nexa 5.4.64 / Build 86

- Audit Battery / Charge / Theft Guard / Audio Controller before changes.
- Preserved existing 80/85/90/95/100 charge thresholds and 20/15/10/5 low-battery thresholds.
- Preserved 3% re-arm and latch behavior.
- Charger theft transition now also receives power connect/disconnect independently of Silent Timer monitoring.
- Theft alarm notification now has full-screen intent for lock-screen visibility.
- Boot/update clears only charger transition baseline to prevent false theft alarms after restart.
- Central priority contract preserved: Theft > Security > Battery > Medicine > Reminder > Normal.
- Added regression coverage for battery threshold crossing/re-arm and channel/priority contract.
- Version regression updated to 5.4.64 / Build 86.
