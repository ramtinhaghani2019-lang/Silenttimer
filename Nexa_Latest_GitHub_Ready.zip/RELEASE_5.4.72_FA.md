# Nexa 5.4.72 / Build 94

- ادامه Master UI روی قبوض، اسناد، پرونده حقوقی، کارت اضطراری، سایلنت/تمرکز، امروز و مرکز تست.
- فارسی‌سازی عنوان‌های باقی‌مانده و هماهنگی RTL با زبان طراحی مشکی/یشمی/طلایی.
- ارتقای Dialog/Form مشترک با پنل Accent و helperهای استاندارد label/form section برای مهاجرت فرم‌ها.
- حفظ منطق و قابلیت‌های Stable Build 93.
- Version/Regression به Build 94 بروزرسانی شد.

وضعیت: Candidate تا تأیید GitHub/Regression.
