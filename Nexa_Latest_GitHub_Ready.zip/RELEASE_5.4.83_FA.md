# Nexa 5.4.83 / Build 105

Pixel-layout migration from the user-approved per-screen references.

- Replaced generic emoji hero panels with artwork extracted from the approved screen references.
- Reworked Home and Battery focal panels to use their exact approved visual references.
- Added reference-driven hero panels to Medicine, Weather, Assets/Market, Ledger, Vehicle, Bills/Documents and Home Care.
- Existing business logic and stored data paths are preserved.
- Build/Regression must be confirmed by GitHub before Stable status.
