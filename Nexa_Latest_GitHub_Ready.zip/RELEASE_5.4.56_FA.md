# Nexa 5.4.56 / Build 78
- Assets market basis changed to Iranian free market.
- Online USD/IRR(Toman), EUR/Toman, 18K, 24K, global ounce, and Iranian coin fields.
- Last valid Iranian snapshot retained on network/source failure.
- Automatic refresh remains 5 minutes while Assets is open; manual refresh remains available.
- Per-asset target-price alert and return-to-last-buy-price alert.
- High-importance price alert notification with current/target price.
- Added Iranian coin asset types.
