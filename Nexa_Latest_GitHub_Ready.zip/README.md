# Nexa 5.4

Nexa Obsidian Personal Assistant. این نسخه روی 5.3.5 FIXED2 ساخته شده و اطلاعات/ساختار ماژول‌های قبلی را حفظ می‌کند.

قابلیت‌های اصلی 5.4: Recovery Code، Device Credential fallback، Auto-lock قابل تنظیم Vault، وضعیت Email Recovery، Backup رمزگذاری‌شده Vault و نسخه‌نمایی داینامیک.

## Update بدون پاک‌شدن داده
applicationId ثابت است: `com.example.silenttimer`. از نسخه 5.4 به بعد پروژه با keystore ثابت Nexa امضا می‌شود؛ بنابراین APKهای بعدی با versionCode بالاتر می‌توانند روی نسخه قبلی نصب شوند و SharedPreferences و فایل‌های داخلی حفظ می‌شوند. مهاجرت اولیه از debug build قدیمی 5.3.5 ممکن است یک بار نیازمند Backup/Restore باشد.
