# Nexa 5.4.140 / Build 162 — Candidate

برنامه Android با شناسه ثابت `com.example.silenttimer`، نصب ارتقایی بر نسخه‌های قبلی، امضای ثابت پروژه و حفاظت از داده‌های کاربر.

- `versionName`: `5.4.140`
- `versionCode`: `162`
- خروجی آماده بارگذاری GitHub: `Nexa_Latest_GitHub_Ready.zip`
- قابلیت تازه در این نسخه: خروجی استاندارد تقویم (`.ics`) از یادآورهای فعال آینده در نتایج فیلتر/جستجو و از موارد انتخابی، با کنترل حریم خصوصی و آزمون‌های رگرسیون.
- جزئیات و محدودیت‌ها: `RELEASE_5.4.140_FA.md`
- قوانین توسعه: `NEXA_DEVELOPMENT_RULES_FA.md`

برای Stable شدن باید **هر دو** Workflow شامل `Build Nexa APK` و `Nexa Android Regression Tests` روی یک commit در GitHub سبز شوند. ایجاد این فایل ZIP به معنی تأیید اجرای APK یا تست‌های دستگاه نیست.
