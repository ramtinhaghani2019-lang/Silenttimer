**ابتدا بخوانید / START HERE:** `NEXA_SOURCE_OF_TRUTH_FA.md` — قرارداد الزامی توسعه و انتقال بین چت‌ها.

**ممیزی همه صفحات:** `NEXA_ALL_SCREENS_UX_AUDIT_FA.md`

# Nexa 5.4.159 / Build 181 — Hotfix صفحه اصلی خالی

مبنا: سورس Build 180 / Nexa 5.4.158 در GitHub Commit `0ea74b659b724ebf77ec894f07370c1807f87329` و فایل ZIP دقیقاً منطبق با Git blob `a4faab4b5cd3c553a47eafd516de2b1286d94c12`.

**علت و اصلاح:** ScrollView صفحه اصلی در MainActivity ایجاد می‌شد ولی به نمای اصلی وصل نبود. در این نسخه ScrollView بالای نوار ناوبری اضافه شد و آزمون رگرسیون این وضعیت قرار گرفت. جزئیات در `RELEASE_5.4.159_FA.md`.

این ZIP فایل سورس است، نه APK. آن را در GitHub روی `main` جایگزین `Nexa_Latest_GitHub_Ready.zip` کنید تا Workflowهای ساخت و رگرسیون اجرا شوند. هیچ کلید خصوصی در ZIP وجود ندارد.

---

## سوابق قبلی

# Nexa 5.4.158 / Build 180 — کاندیدای آزمون

مبنا: نسخه سبز 5.4.157 / Build 179 در GitHub. تغییرات و محدودیت‌ها: `RELEASE_5.4.158_FA.md`.

این بسته **سورس** است و APK نیست؛ فقط فایل ZIP را در شاخه `main` جایگزین کن تا دو Workflow خودکار اجرا شوند. بدون کلید خصوصی امضا.

---

## تاریخچه قبلی

# Nexa 5.4.157 / Build 179 — کاندیدای آزمون

مبنا: نسخه سبز 5.4.156 / Build 178 در GitHub. توضیح تغییرات و محدودیت‌ها: `RELEASE_5.4.157_FA.md`.

این بسته شامل سورس Nexa است، نه APK. فقط فایل ZIP را جایگزین فایل همنام در شاخه main کنید تا Workflowهای GitHub اجرا شوند. اطلاعات تولیدی امضا در GitHub Secrets نگهداری می‌شوند؛ سورس نباید کلید خصوصی داشته باشد.

---

## تاریخچه قبلی

# Nexa — نسخهٔ آزمایشی 5.4.155 / Build 177

**مبنا:** Nexa 5.4.154 / Build 176 (تأییدشده توسط کاربر). این بسته برای آپلود یک‌باره در شاخه `main` مخزن GitHub تهیه شده و صرفاً کاندیدای آزمون است.

**اصلاحات این بیلد:**
- ورود گفتاری فارسی برای کارهای روزانه و نام لیست خرید؛ تنها فرم پیش‌پر می‌شود و ثبت نیازمند ذخیرهٔ صریح است.
- گزینه بررسی چند متن پیشنهادی تشخیص گفتار قبل از اجرا.
- تبدیل عبارت تکرار «هر دو هفته»، «هر ۳ ماه» و ... به انتخاب اولیهٔ تکرار در فرم یادآور.
- نمایش یک ردیف فشرده برای موعد بعدی هر یادآور تکراری، یک ردیف ملایم قرمز برای آخرین نوبت انجام‌شده و تقویم نوبت‌های بعدی با لمس ردیف. فقط نمایش داده‌های مجازی؛ هشدار یا تراکنش اضافه ساخته نمی‌شود.
- حذف بنرهای تکراری صفحه ثبت سریع و فهرست کارها/خریدها.

**شناسه و نسخه:** `com.example.silenttimer`، `versionName=5.4.155`، `versionCode=177`.

**امضا:** کلید خصوصی در سورس منتشر نمی‌شود. GitHub Actions کلید را از Secrets مخزن بازیابی می‌کند. تغییر شناسهٔ اپ یا ساختار امضای پایدار انجام نشده است. کلید تاریخی افشاشده همچنان نیازمند برنامهٔ مهاجرت امن است.

**روش ارتقا:** فقط `Nexa_Latest_GitHub_Ready.zip` را در شاخه `main` جایگزین کن؛ دو Workflow به طور خودکار اجرا می‌شوند. بدون حذف اپ نصب‌شده و پس از تهیهٔ نسخهٔ پشتیبان، APK جدید را روی گوشی آزمایش کن.

**وضعیت:** کاندیدا تا موفقیت هر دو Workflow روی Commit جدید و تأیید نصب و عملکرد. `RELEASE_5.4.155_FA.md` جزئیات را دارد. قابلیت صوتی هنوز همهٔ بخش‌ها را پوشش نمی‌دهد؛ توسعهٔ سراسری ادامه دارد.

---

## سوابق فنی پیشین (بخش تاریخی)

> **آخرین کاندیدا: Nexa 5.4.149 / Build 171.** جزئیات: `RELEASE_5.4.149_FA.md`.

# Nexa 5.4.148 / Build 170 — Ledger Search & Filtering Candidate

- مبنا: Build 169 / 5.4.147 (آخرین نسخه اعلام‌شدهٔ سبز).
- جستجو در گردش هر طرف‌حساب: شرح، مبلغ با اعداد فارسی/لاتین و نوع تراکنش.
- فیلتر نوع: همه، بدهی قرمز، طلب زرد، پرداخت سبز، دریافت بنفش.
- نمایش مرحله‌ای ۴۰ تراکنش برای کاهش کندی و امکان بارگذاری سایر ردیف‌ها.
- حفظ ماندهٔ تاریخی هر تراکنش مستقل از فیلتر، جستجو و ترتیب نمایش.
- امکان حذف موعد قبلی از فرم ویرایش تراکنش؛ نمایش نتیجهٔ خالی جستجو.
- منطق مالی، شناسه بسته، اطلاعات حساب، دیتابیس و امضای برنامه ثابت هستند.
- جزئیات و آزمون‌ها: `RELEASE_5.4.148_FA.md`.
- برای تأیید واقعی باید خروجی GitHub APK با نسخهٔ **5.4.148 / Build 170** و هر دو Workflow روی یک Commit سبز باشد؛ سبز شدن یک ZIP قدیمی ملاک نیست.

---

# Nexa 5.4.147 / Build 169 — Ledger Usability Candidate

- مبنا: نسخه سبز Nexa 5.4.146 / Build 168.
- چهار رنگ مجزا در ثبت/ویرایش و کارت تراکنش‌ها: بدهی قرمز، طلب زرد، پرداخت سبز، دریافت بنفش.
- چهار دکمهٔ انتخاب نوع تراکنش به‌جای Spinner قدیمی، نمایش شرح نوع و خطای مبلغ نامعتبر بدون بسته‌شدن پنجره.
- گردش حساب با مرتب‌سازی دوطرفهٔ جدیدترین/قدیمی‌ترین و حفظ مانده تاریخی هر ردیف.
- خوانایی و فاصله‌ها بهبود یافت؛ اعداد رابط حسابداری فارسی و عنوان گزارش بازه روشن‌تر شد.
- بانک اطلاعاتی، حساب‌ها، کدهای نوع تراکنش و CSV تغییری نکرده‌اند.
- جزئیات و آزمون‌های نسخه: `RELEASE_5.4.147_FA.md`.
- تا سبز شدن هم‌زمان Build APK و Android Regression روی یک Commit و تست روی گوشی، نسخه کاندیداست.

---

# Nexa 5.4.146 / Build 168 — Alarm Consistency Candidate

- مبنا: آخرین Build 167 / Nexa 5.4.145 تأییدشده.
- جلوگیری از زنگ‌خوردن یادآور قدیمی و تغییر نوبت جدید از طریق اعلانِ باقی‌مانده پس از ویرایش یا تکرار.
- بازتنظیم هشدارهای یادآور، دارو و برنامه هفتگی پس از تغییر ساعت و منطقهٔ زمانی گوشی.
- حفاظت BootReceiver در برابر اکشن ناشناس؛ حفظ تمام داده‌ها و امضای فعلی.
- جزییات و آزمون‌ها: `RELEASE_5.4.146_FA.md`.
- نسخه تا موفقیت هر دو Workflow روی یک Commit و تأیید عملکرد گوشی Candidate می‌ماند.

---

# Nexa 5.4.145 / Build 167 — Timer Safety & Diagnostics Candidate

- مبنا: Nexa 5.4.144 / Build 166 (تأیید سبز کاربر).
- اصلاح عدم بازگردانی صدای گوشی هنگام فشردن Stop بدون تایمر فعال.
- مرکز تست: گزارش فنی قابل کپی/اشتراک‌گذاری با اقدام خود کاربر و امکان حذف سوابق خطاها.
- پالایش داده‌های گزارش، محدود به ۸ ردیف و بدون اطلاعات شخصی یا پیام استثنا.
- رجوع به `RELEASE_5.4.145_FA.md` برای جزئیات و تست‌های مربوطه.
- برای Stable شدن: Build APK و Android Regression روی یک Commit در GitHub + بررسی واقعی روی دستگاه.

---

# Nexa 5.4.144 / Build 166 — Background Reliability Candidate

این بسته بر اساس سورس ارسالی Build 165 ساخته شده است. رفع کرش قطعی **بدون Logcat قابل تأیید نیست**.

- محافظت از رخدادهای سرویس سایلنت، تغییر زنگ، وضعیت باتری، Boot و پایان تایمر در برابر خطاهای قابل‌بازیابی.
- توقف صحیح سرویس در صورت ردشدن promotion به foreground به‌جای باقی‌ماندن سرویس راه‌نیفتاده.
- پایان قطعی broadcastهای آسنکرون بازار و آب‌وهوا ظرف ۸ ثانیه؛ callbackهای دیررس دیگر اعلان دیرهنگام صادر نمی‌کنند.
- ثبت محدود و محلی نوع خطا (بدون متن خطا، اطلاعات شخصی یا stack trace) و نمایش در مرکز تست Nexa.
- تست Android رگرسیون و تست JVM هم‌زمانی ۳۲ ریسه‌ای برای completion exactly-once.
- versionName=5.4.144 و versionCode=166؛ applicationId، signing، داده‌ها و مجوزها دست‌نخورده‌اند.

**وضعیت: Candidate، نه Stable.** تا دو workflow ساخت APK و Android Regression روی یک Commit سبز نشوند، این بیلد پایدار نیست.

---

# Nexa — نسخه 5.4.144 / Build 166

اپلیکیشن اندرویدی Nexa با رابط فارسی RTL، یادآورها، مدیریت مالی، امنیت و فهرست‌های روزانه.

- بسته: `com.example.silenttimer` (بدون تغییر)
- `versionName`: `5.4.143` — `versionCode`: `165`
- نسخه مبنا: **Nexa 5.4.142 / Build 164** پایدار، SHA `6044c8c6`.
- قابلیت جدید: **اشتراک‌گذاری متن فهرست خرید و کارهای روزانه** و **ذخیره CSV** از اقلام باقی‌مانده یا همه اقلام، با حذف داده‌های پرداخت و اطلاعات خصوصی.
- بدون تغییر ساختار داده‌ها، کلید امضا، مجوزها، هشدارها و قابلیت‌های قبلی.

## بارگذاری در GitHub
بسته `Nexa_Latest_GitHub_Ready.zip` را با نام ثابت در ریشه مخزن بارگذاری کنید. لازم است workflow فعلی سورس داخل ZIP را قبل از اجرای Gradle استخراج کند. مطمئن شوید APK از سورس با `versionCode=165` و `versionName=5.4.143` ساخته شده؛ موفقیت CI بر سورس نسخه قبلی به معنی تست این نسخه نیست.

نسخه پس از موفقیت هر دو workflow **Build Nexa Latest APK** و **Nexa Android Regression Tests** بر SHA مشترک، Stable می‌شود.

## تست محلی خروجی لیست‌ها
Java 17 یا بالاتر کافی است:

```sh
mkdir -p /tmp/nexa165
javac -encoding UTF-8 -d /tmp/nexa165 \
  app/src/main/java/com/example/silenttimer/ListShareExport.java \
  tools/tests/ListShareExportSmokeTest.java
java -cp /tmp/nexa165 ListShareExportSmokeTest
```

**امنیت:** فایل keystore و مشخصات امضای Nexa محرمانه هستند؛ مخزن کد و آرشیو را عمومی نکنید.

## اصلاح تست رگرسیون در Build 165 (بدون تغییر شماره نسخه)

- آزمون نسخه که اشتباهاً هنوز `5.4.142 / Build 164` را انتظار داشت اصلاح شد.
- آزمون اکنون نسخه و کد بسته نصب‌شده را با مقادیر تولیدشده از Gradle در `BuildConfig` مقایسه می‌کند و حداقل Build 165 را نیز کنترل می‌کند.
- تولید `BuildConfig` در Gradle صریحاً فعال شد (سازگار با Android Gradle Plugin 8.7.3).
- امکانات اشتراک‌گذاری خریدها و کارهای روزانه، داده‌ها و امضای برنامه بدون تغییر باقی مانده‌اند.
- برای تأیید نهایی، هر دو workflow روی یک commit جدید در GitHub باید موفق شوند.

### Build 170 candidate — historical transaction dates
Each debit/credit/payment/receipt list is chronologically ordered by the transaction's own editable Jalali date/time (`dateMillis`). The default view is newest first, with an oldest-first toggle. Sort is reapplied after filtering; historical running balances are calculated before filtering and are not rewritten. Equal timestamps use the immutable entry ID as a stable tie-breaker.


## Build 183 / 5.4.161

- Compact homepage with the nearest active reminder date, including virtual recurring dates.
- Attention card disappears when it has no actionable items.
- Persian voice command ``داروی جدید ...`` opens the medicine form with name prefilled; it never auto-saves a medicine or guesses dose/time.
- Android regression test for voice medicine drafts; no changes to private signing.


## 5.4.199 / Build 221 (CI candidate)
See `RELEASE_5.4.199_BUILD221_FA.md`; full-screen module directory (22 destinations), unified timeline navigation, streamlined activity history. Last verified GitHub green: Build 220.
