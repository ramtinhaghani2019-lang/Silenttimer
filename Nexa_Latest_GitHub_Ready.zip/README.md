# Nexa 5.4.1

نسخه توسعه‌ای بر پایه Nexa 5.4 با تمرکز بر Entityهای مشترک فروشنده/کارت و مدیریت مرکزی فایل‌ها و فاکتورها.

- versionName: 5.4.1
- versionCode: 22
- applicationId ثابت: com.example.silenttimer
- نصب مستقیم روی 5.4 برای حفظ داده‌ها طراحی شده است.
- OCR عمداً وجود ندارد.

برای GitHub Actions از فایل ثابت `Nexa_Latest_GitHub_Ready.zip` استفاده کنید.
