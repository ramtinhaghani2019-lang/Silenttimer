# Nexa — نسخه 5.4.143 / Build 165

اپلیکیشن اندرویدی Nexa با رابط فارسی RTL، یادآورها، مدیریت مالی، امنیت و فهرست‌های روزانه.

- بسته: `com.example.silenttimer` (بدون تغییر)
- `versionName`: `5.4.143` — `versionCode`: `165`
- نسخه مبنا: **Nexa 5.4.142 / Build 164** پایدار، SHA `6044c8c6`.
- قابلیت جدید: **اشتراک‌گذاری متن فهرست خرید و کارهای روزانه** و **ذخیره CSV** از اقلام باقی‌مانده یا همه اقلام، با حذف داده‌های پرداخت و اطلاعات خصوصی.
- بدون تغییر ساختار داده‌ها، کلید امضا، مجوزها، هشدارها و قابلیت‌های قبلی.

## بارگذاری در GitHub
بسته `Nexa_Latest_GitHub_Ready.zip` را با نام ثابت در ریشه مخزن بارگذاری کنید. لازم است workflow فعلی سورس داخل ZIP را قبل از اجرای Gradle استخراج کند. مطمئن شوید APK از سورس با `versionCode=165` و `versionName=5.4.143` ساخته شده؛ موفقیت CI بر سورس نسخه قبلی به معنی تست این نسخه نیست.

نسخه پس از موفقیت هر دو workflow **Build Nexa Latest APK** و **Nexa Android Regression Tests** بر SHA مشترک، Stable می‌شود.

## تست محلی خروجی لیست‌ها
Java 17 یا بالاتر کافی است:

```sh
mkdir -p /tmp/nexa165
javac -encoding UTF-8 -d /tmp/nexa165 \
  app/src/main/java/com/example/silenttimer/ListShareExport.java \
  tools/tests/ListShareExportSmokeTest.java
java -cp /tmp/nexa165 ListShareExportSmokeTest
```

**امنیت:** فایل keystore و مشخصات امضای Nexa محرمانه هستند؛ مخزن کد و آرشیو را عمومی نکنید.

## اصلاح تست رگرسیون در Build 165 (بدون تغییر شماره نسخه)

- آزمون نسخه که اشتباهاً هنوز `5.4.142 / Build 164` را انتظار داشت اصلاح شد.
- آزمون اکنون نسخه و کد بسته نصب‌شده را با مقادیر تولیدشده از Gradle در `BuildConfig` مقایسه می‌کند و حداقل Build 165 را نیز کنترل می‌کند.
- تولید `BuildConfig` در Gradle صریحاً فعال شد (سازگار با Android Gradle Plugin 8.7.3).
- امکانات اشتراک‌گذاری خریدها و کارهای روزانه، داده‌ها و امضای برنامه بدون تغییر باقی مانده‌اند.
- برای تأیید نهایی، هر دو workflow روی یک commit جدید در GitHub باید موفق شوند.
