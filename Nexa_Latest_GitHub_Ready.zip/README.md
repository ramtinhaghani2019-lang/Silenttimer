# Nexa — نسخه 5.4.142 / Build 164

اپلیکیشن اندرویدی Nexa با رابط فارسی RTL، یادآورها، هشدارهای امنیتی، مدیریت مالی، تقویم و امکانات جانبی.

- بسته اندروید: `com.example.silenttimer` (بدون تغییر)
- `versionName`: `5.4.142` — `versionCode`: `164`
- نسخه مبنا: `Nexa 5.4.141 / Build 163` تأییدشده در هر دو workflow روی Commit مشترک `7f9cdb8b`.
- قابلیت جدید: **پیش‌بینی سررسید قبوض و پرداخت‌ها برای ۳۰ یا ۹۰ روز آینده**، همراه جمع ۷روزه، تکرارهای شمسی، نمایش معوقات جداگانه و ویرایش سریع از روی ردیف‌های پیش‌بینی‌شده.
- بدون تغییر ساختار اطلاعات ذخیره‌شده، امضای برنامه، هویت بسته یا مجوزهای برنامه.

## بارگذاری در GitHub
فایل ثابت `Nexa_Latest_GitHub_Ready.zip` را مطابق روال فعلی در ریشه مخزن GitHub بارگذاری کنید. اطمینان پیدا کنید که workflow فعال محتویات ZIP را قبل از Gradle استخراج می‌کند؛ اگر workflow نسخه‌ای قدیمی از سورس را کامپایل کند، سبزشدن تست‌ها به معنای تست بیلد جدید نیست. `versionCode` بسته ساخته‌شده باید **164** باشد.

تأیید Stable فقط بعد از موفقیت هر دو workflow «Build Nexa Latest APK» و «Nexa Android Regression Tests» روی یک Commit امکان‌پذیر است. پیش از این تأیید، نسخه Candidate است.

## تست محلی منطق پیش‌بینی
با داشتن Java 17 می‌توانید از ریشه سورس اجرا کنید:

```sh
mkdir -p /tmp/nexa-forecast-check
javac -encoding UTF-8 -d /tmp/nexa-forecast-check \
 app/src/main/java/com/example/silenttimer/PersianDateUtil.java \
 app/src/main/java/com/example/silenttimer/BillForecast.java \
 tools/tests/BillForecastSmokeTest.java
java -ea -cp /tmp/nexa-forecast-check com.example.silenttimer.BillForecastSmokeTest
```

**نکته امنیتی:** کلید امضای برنامه جزو اطلاعات محرمانه است؛ مخزن و فایل‌های keystore را عمومی نکنید. کلید نسخه قبل را بدون برنامه‌ریزی جایگزین نکنید.
