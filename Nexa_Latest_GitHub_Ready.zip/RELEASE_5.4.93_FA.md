# Nexa 5.4.93 / Build 115

## Final stabilization candidate
- پایه: Build 114 که Build و Regression آن در GitHub سبز تأیید شد.
- افزایش نسخه به 5.4.93 / Build 115.
- همگام‌سازی تست Regression نسخه با Build 115.
- کنترل نهایی بسته برای نبودن mockup/reference screenshot در app/src/main.
- حفظ منطق و قابلیت‌های تأییدشده Build 114 بدون بازنویسی پرریسک در بیلد نهایی.
- این بسته تا قبل از سبز شدن GitHub، Candidate است و فقط پس از تأیید Build/Regression به Stable تبدیل می‌شود.
