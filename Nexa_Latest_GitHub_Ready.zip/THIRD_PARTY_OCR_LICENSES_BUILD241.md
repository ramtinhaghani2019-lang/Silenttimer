# Nexa OCR model inventory — 5.4.219

OCR runs locally; neither the source image nor its extracted text is transmitted.

- Tesseract4Android 4.9.0 (already present in baseline): `cz.adaptech.tesseract4android:tesseract4android:4.9.0`.
- Existing `fas.traineddata` and `eng.traineddata` remain unchanged.
- **Added** `Arabic.traineddata` (Tesseract `script/Arabic` model), packaged as a *conditional* secondary OCR candidate source after the default Persian/English pass. Sourced from the distribution of the Tesseract OCR models installed in the build environment, corresponding to the official `tesseract-ocr/tessdata` models. Model distributions follow the Tesseract OCR project's Apache-2.0 license. Attribution: https://github.com/tesseract-ocr/tessdata and https://github.com/tesseract-ocr/tesseract .
- The extra model adds approximately 9 MB to the uncompressed source; compressed APK size will differ. It is not a cloud OCR endpoint.

Known limitation: Tesseract script recognition is **not guaranteed** to identify every Persian glyph or decimal separator. No numeric OCR reading is allowed to save a transaction without user confirmation, and values are prefilled only after arithmetic validation. Device testing remains mandatory.
