# Nexa 5.4.32 / Build 54

## تغییرات
- انتقال ساخت و ارسال اعلان زنگ‌دار Reminder به `NexaNotificationEngine`.
- حفظ Full Screen Intent، دو Action فعلی Reminder، Lock Screen visibility، شناسه Notification و تکرار زمان‌بندی‌شده.
- اضافه شدن کنترل مرکزی تحویل تکراری کوتاه‌مدت در `NexaNotificationEngine` برای جلوگیری از اجرای دوباره ناخواسته Receiver.
- اعمال Duplicate Guard برای Reminder و Medicine؛ تکرارهای عادی چند دقیقه‌ای همچنان مجاز هستند.
- پاک‌سازی `ReminderAlarmReceiver` از مسئولیت مستقیم ساخت Notification و یکدست شدن معماری Medicine/Reminder.
- افزایش نسخه به `5.4.32 / Build 54` و به‌روزرسانی Regression identity guard.
- اضافه شدن Regression Test برای Duplicate Delivery Guard.

## وضعیت تست
- Candidate آماده اجرای GitHub Actions: Build APK و Android Regression Tests.
