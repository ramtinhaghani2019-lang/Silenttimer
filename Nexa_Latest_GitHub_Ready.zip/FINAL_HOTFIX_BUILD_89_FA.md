# Nexa 5.4.67 / Build 89 — Final Hotfix

- فایل موقت `NexaRegressionTest.java.tmp` از سورس Release حذف شد.
- `FLAG_KEEP_SCREEN_ON` از `MedicineRingActivity` حذف شد؛ نمایش روی قفل و روشن‌کردن اولیه صفحه حفظ شده است.
- `FLAG_KEEP_SCREEN_ON` از `ReminderRingActivity` حذف شد؛ نمایش روی قفل و روشن‌کردن اولیه صفحه حفظ شده است.
- شماره نسخه تغییر نکرد: 5.4.67 / Build 89.
- هیچ قابلیت جدیدی در این Hotfix اضافه نشده است.
