# Nexa 5.4.45 / Build 67

بسته Battery Health Dashboard:
- درصد شارژ زنده
- وضعیت شارژ/مصرف
- نوع اتصال AC/USB/Wireless
- سلامت گزارش‌شده باتری
- دمای باتری
- ولتاژ
- جریان لحظه‌ای در دستگاه‌های پشتیبان
- Charge Counter در دستگاه‌های پشتیبان
- فناوری باتری
- منبع داده شفاف Android BatteryManager
- عدم نمایش مقدار ساختگی برای داده‌های پشتیبانی‌نشده
- بدون WakeLock و بدون روشن نگه داشتن صفحه
- ثبت صفحه مستقل Nexa Battery در داشبورد و Manifest
- Regression نسخه 5.4.45 / Build 67
