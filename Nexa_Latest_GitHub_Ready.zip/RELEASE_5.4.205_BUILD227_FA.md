# Nexa 5.4.205 / Build 227 — Compact dashboard

Base: Nexa 5.4.204 / Build 226; does not change the timeline/medicine history aggregation logic.

- Dashboard 4 financial tiles remain semantically colored, live and clickable; minimum height 80dp, amount and currency are in a single compact row.
- Today's overview counts occupy one line and secondary previews remain available when populated.
- Attention excludes 0-count categories; empty attention panel is already hidden.
- Remove redundant All Modules CTA while preserving section header, module shortcut and bottom bar routes.
- Tighten vertical gutters; no list data or persistence modifications.
- New framework-independent smoke test: DashboardAttentionSummarySmokeTest.

Verification: Android GitHub Actions Build and Android Regression required after uploading canonical ZIP.
