# ممیزی Nexa 5.4

مبنای نسخه: Nexa 5.3.5 FIXED2. تمام اصلاحات نسخه‌های قبل حفظ شده‌اند.

## تکمیل‌شده در 5.4
- [x] Recovery Code مستقل: تولید یک‌باره، ذخیره فقط به‌صورت PBKDF2 hash، ورود با کد بازیابی.
- [x] Device Credential fallback: ورود با PIN/Pattern/Password خود گوشی.
- [x] Auto-lock قابل تنظیم برای بخش‌های حساس: 1/5/10/30 دقیقه.
- [x] قفل دوباره Vault هنگام رفتن به پس‌زمینه (قابل خاموش‌کردن).
- [x] Email recovery status: پیکربندی‌نشده/پیکربندی‌شده/تأییدشده.
- [x] Rate limit کلاینتی 60 ثانیه برای ارسال OTP و ثبت وضعیت ایمیل تأییدشده.
- [x] Backup مستقل Vault با PBKDF2 + AES-256-GCM و Restore با گذرواژه.
- [x] نسخه نمایشی از PackageInfo خوانده می‌شود و دیگر hard-code نیست.
- [x] versionName=5.4 / versionCode=21.
- [x] امضای ثابت Nexa برای Buildهای بعدی تا نصب نسخه جدید روی نسخه قبلی، داده‌ها را نگه دارد.

## نکته انتقال از 5.3.5 به 5.4
نسخه 5.3.5 قبلی با debug keystore موقت GitHub ساخته شده است. امضای خصوصی آن runner در دسترس نیست؛ بنابراین ممکن است برای اولین مهاجرت به امضای ثابت 5.4 یک بار Uninstall لازم شود. قبل از آن از Settings > Backup خروجی بگیر و بعد از نصب 5.4 Restore کن. از 5.4 به بعد، با حفظ همین keystore و applicationId، نصب Update روی نسخه قبلی اطلاعات را پاک نمی‌کند.

## امنیت امضا
فایل keystore این build برای سادگی workflow داخل سورس قرار گرفته و باید repository خصوصی بماند. برای انتشار عمومی/Play Store باید keystore به GitHub Secrets منتقل شود.
