# Nexa 5.4.75 / Build 97

بسته بزرگ Master UI:
- تم پایه Android با Master UI مشکی/یشمی/طلایی Nexa هماهنگ شد.
- Accent سیستمی از بنفش قدیمی به طلایی Nexa تغییر کرد.
- رنگ متن اصلی، متن فرعی و Hint در سطح Theme یکدست شد.
- Status Bar و Navigation Bar با پس‌زمینه Nexa هماهنگ شدند.
- Dialogهای سیستمی و AlertDialogها به پنل یشمی/طلایی گرد منتقل شدند.
- عنوان Dialogها طلایی و پررنگ شد.
- عرض Dialogها برای فرم‌های فارسی و RTL اصلاح شد.
- حالت‌های انتخاب/فشرده List و Single/Multi choice بازطراحی شد.
- پس‌زمینه انتخاب‌ها، Border و Radius با Master UI هماهنگ شد.
- Theme previewهای قدیمی و بلااستفاده حذف شدند تا Theme Pack برنگردد.
- Design System ثابت Nexa حفظ شد؛ قابلیت‌های Build 96 دست‌نخورده‌اند.
- Version/Regression به 5.4.75 / Build 97 بروزرسانی شد.

این نسخه Candidate است تا GitHub Build/Regression سبز شود.
