# Nexa 5.4.170 / Build 192 — Professional settings navigation (UI phase 2)

- Based on the confirmed GitHub-green Build 191.
- Rebuilt Settings screen navigation with compact native RTL cards, colorful original emoji, readable titles, descriptive captions, subtle chevrons and clearer spacing.
- Added search-first local-only settings filter (Persian/Arabic letter normalization, practical aliases), a visible result count, helpful empty state and four horizontal quick-access actions.
- Existing **13** settings groups and their original content views, live switches, alarm sounds, security and backup flows, and permission request actions are all preserved.
- No data migration, business logic, alarm, timer, battery, application ID or signing changes.
- Instrumentation search/row regression plus pure Java smoke added. Android CI and on-device usability inspection still required.
