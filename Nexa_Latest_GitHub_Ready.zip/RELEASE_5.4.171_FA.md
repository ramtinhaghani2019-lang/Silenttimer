# Nexa 5.4.171 — Build 193: Premium Aurora visual language

- Based on verified GitHub-green Build 192 source.
- A new global dark indigo / blue / violet gradient atmosphere, rendered with lightweight native Android shaders rather than screenshot artwork.
- Shared premium UI tokens: surfaces, cards, dialog colors, inputs, button gradients, icon holders, and pill-style selected bottom navigation.
- Home shell now inherits the consistent premium palette, with contrasting timer focus panel and polished shortcuts. Screens that use the shared UiKit inherit the same system.
- Financial module visual work: outstanding payments metric, status-first receipts, single-tap payment filters and debt (red)/credit (yellow) balance tiles, with original data calculations and actions preserved.
- Color semantics remain debt RED, credit YELLOW, payment GREEN, receipt PURPLE. Purple becomes the general UI accent, with yellow reserved for credit and contextual emphasis.
- All existing settings, storage, alarm, timer, security and recurrence code stays unchanged.
- Tests: prior source guards, new premium-style semantic guards, and Android regression test added. Android CI and real-device visual approval are still required after upload.
