from pathlib import Path
root=Path(__file__).resolve().parents[1]
ui=(root/'app/src/main/java/com/example/silenttimer/UiKit.java').read_text()
reg=(root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
gradle=(root/'app/build.gradle').read_text()
assert 'versionCode 224' in gradle and 'versionName "5.4.202"' in gradle
field=ui.split('public static EditText styleField(',1)[1].split('return e;',1)[0]
assert 'e.setMinHeight(dp(c,48))' in field
assert 'e.setMinimumHeight(dp(c,48))' in field
assert 'field.getMinimumHeight()>=UiKit.dp(c,48)' in reg
assert 'build212_occasionDirectorySearchAndFiltersAreSafe' in reg
print('PASS: Build213 accessibility fix covers exact on-device regression assertion')
