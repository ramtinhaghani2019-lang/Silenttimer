"""Build215: professional, searchable reminder directory; recurrence preview stays read-only."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
a=root/'app/src/main/java/com/example/silenttimer'
r=(a/'RemindersActivity.java').read_text(encoding='utf-8')
o=(a/'ReminderOrganizer.java').read_text(encoding='utf-8')
g=(root/'app/build.gradle').read_text(encoding='utf-8')
assert 'versionCode 215' in g and 'versionName "5.4.193"' in g
for token in ('inlineSearch.setText(searchText)','inlineSearch.addTextChangedListener','searchText=s.toString();render();',
              'clearSearchButton.setOnClickListener','HorizontalScrollView filterScroller',
              'chip.setMinimumWidth(UiKit.dp(this,91))','ReminderOrganizer.effectiveDue(r,now)',
              'PersianDateUtil.pretty(displayDue)','showFilterDialog()','chooseCalendarExport()','markDone(r)',
              'addOccurrenceRow(r,next,false)'):
    assert token in r,token
for token in ('public static long effectiveDue','AgendaDuePolicy.shownDue','long due=effectiveDue(r,now)',
              'effectiveDue(a,now)','effectiveDue(b,now)'):
    assert token in o,token
for token in ('NexaStore.addReminder','ReminderScheduler.scheduleReminder','OccasionScheduler.schedule'):
    # No write/scheduling side effects introduced in read-only reminder organizer.
    assert token not in o,token
assert 'ReminderDirectorySmokeTest.java' in [p.name for p in (root/'tools/tests').glob('*.java')]
assert 'build215_reminderDirectoryShowsCurrentOccurrenceAndAccessibleSearch' in (root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
print('PASS: Build215 read-only recurrence previews, responsive filters and inline search')
