"""Build197: visual-only garage refresh and lifecycle preservation."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
a=r/'app/src/main/java/com/example/silenttimer'
g=(a/'GarageActivity.java').read_text(encoding='utf8')
v=(a/'VehicleActivity.java').read_text(encoding='utf8')
u=(a/'NexaGarageUi.java').read_text(encoding='utf8')
assert 'NexaGarageUi.metrics(this,vs.size(),due,soon)' in g
assert 'NexaGarageUi.serviceMetrics(this,services.size(),overdue,soon)' in v
assert 'NexaGarageUi.vehicleCard(this,isOverdue,isSoon)' in g
assert 'isSoon?UiKit.GOLD:UiKit.TEAL' in g
assert 'NexaGarageUi.serviceGroup(this,distance<=0,distance>0&&distance<=500)' in v
assert 'NexaGarageUi.historyRecord(this)' in v
assert 'NexaGarageUi.sectionLabel(this,"مشخصات سوخت‌گیری")' in v
assert 'HomeUi.shouldStack(this)' in v
for s in ['NexaStore.addVehicle(this,v)', 'NexaStore.vehicles(this)',
          'new Intent(this,VehicleActivity.class)', 'v.currentKm=NumberFormatUtil.intValue(km.getText())']:
 assert s in g,s
for s in ['NexaStore.updateVehicle(this,vehicle)', 'NexaStore.addService(this,r)',
          'NexaStore.updateService(this,r)', 'NexaStore.removeService(this,r.id)',
          'NexaStore.addFuel(this,f)', 'NexaStore.updateFuel(this,f)',
          'NexaStore.removeFuel(this,f.id)', 'LinkedReminderHelper.upsert(this,',
          'LinkedReminderHelper.remove(this,', 'new AlertEditor(this,form,',
          'new RepeatIntervalPicker(this,form,','GarageNotifier.check(this,vehicle)',
          'PersianDatePickerHelper.pickDateTime(this,']:
 assert s in v,s
for s in ['static LinearLayout metrics(', 'HomeUi.shouldStack(c)',
          'setLayoutDirection(View.LAYOUT_DIRECTION_RTL)', 'static LinearLayout serviceGroup(',
          'static LinearLayout historyRecord(', 'static TextView state(']:
 assert s in u,s
assert 'NexaStore.' not in u and 'ReminderScheduler' not in u
assert 'versionCode 224' in (r/'app/build.gradle').read_text()
assert 'versionName "5.4.202"' in (r/'app/build.gradle').read_text()
print('PASS: Build197 garage presentation and original vehicle, fuel, service, reminder lifecycle')
