"""Static contracts for the 5.4.215 source candidate. Android CI remains authoritative."""
from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
j=r/'app/src/main/java/com/example/silenttimer'
a=(j/'AssetsActivity.java').read_text()
c=(j/'MarketDataHelper.java').read_text()
b=(j/'AssetRatesPanel.java').read_text()
m=(j/'MarketChangeStore.java').read_text()
s=(j/'NexaStore.java').read_text()
h=(j/'MarketHistoryView.java').read_text()
sched=(j/'MarketRefreshScheduler.java').read_text()
app=(j/'NexaApplication.java').read_text()
boot=(j/'BootReceiver.java').read_text()
gradle=(r/'app/build.gradle').read_text()
manifest=ET.parse(r/'app/src/main/AndroidManifest.xml').getroot()
ns='{http://schemas.android.com/apk/res/android}'
assert 'versionCode 237' in gradle and 'versionName "5.4.215"' in gradle
application=manifest.find('application')
assert application.attrib[ns+'name']=='.NexaApplication'
assert any(x.attrib.get(ns+'name')=='.MarketRefreshJobService' for x in application.findall('service'))
assert '6*60*60_000L' in sched and '5*60_000L' in sched and '.setPersisted(true)' in sched
assert 'MarketRefreshScheduler.sync(this)' in app and 'registerActivityLifecycleCallbacks(this)' in app
assert 'MarketRefreshScheduler.sync(context)' in boot
assert 'market_auto_migration_237' in s and 'if(old==1)' in s
assert 'new LinearLayout.LayoutParams(UiKit.dp(this,48),UiKit.dp(this,48))' in a
assert 'editForm(null,groupName,null)' in a
assert 'detailsSurface' in a and 'lotSurface' in a
assert 'هشدار قیمت • '+ '"+x.type' in a and 'قیمت همین خرید' in a
assert 'نمایش داده می‌شوند؛ واحد مبنا را' not in a
assert 'برای مشاهده موجودی و جزئیات وارد' not in a
assert 'قیمت ذخیره‌شده خریدها مستقل است' not in a
assert 'setRangeDays(' in h and 'drawDates(' in h and 'PersianDateUtil.fromMillis' in h
assert '48L*60*60*1000' in h
assert 'priceUnit' in h and 'ریال' in h
assert 'MarketChangeStore.percent' in b and 'UiKit.GREEN' in b and 'UiKit.RED' in b
assert 'AssetMoneyUnit.fromStored(value,"ریال")' in b
assert 'Nerkhsanj' in c and 'MarketChangeStore.save(' in c
assert '"coin","emami"' in c and '"gram","gerami"' in c
assert 'j.optJSONObject("change")' in c and 'sourceDate' in m
assert 'NexaStore.saveAssets(this,' in a and 'NexaStore.updateAsset(this,x)' in a
assert 'NexaStore.removeAsset(this,x.id)' in a
assert 'AssetMarket237RegressionTest' in (r/'app/src/androidTest/java/com/example/silenttimer/AssetMarket237RegressionTest.java').read_text()
print('PASS: Nexa 237 source contracts for market data units, cards, charts, alerts, schedulers, persistence and tests')
