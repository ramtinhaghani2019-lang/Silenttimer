"""Regression guard for Build 222: LinearLayout has setMinimumHeight, not setMinHeight."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
source=(root/'app/src/main/java/com/example/silenttimer/TodayActivity.java').read_text(encoding='utf-8')
assert 'versionCode 225' in (root/'app/build.gradle').read_text(encoding='utf-8')
assert 'heading.setMinimumHeight(UiKit.dp(this,50));' in source
assert 'heading.setMinHeight(' not in source
assert 'heading.setOrientation(LinearLayout.HORIZONTAL);' in source
# Prevent invalid ViewGroup method calls on local LinearLayout variables
for m in re.finditer(r'\bLinearLayout\s+(\w+)\s*=\s*new\s+LinearLayout\s*\(',source):
    name=m.group(1)
    assert not re.search(r'\b'+re.escape(name)+r'\s*\.\s*setMinHeight\s*\(',source),name
print('PASS Build222: ViewGroup min-height API and unchanged version')
