"""Compile and exercise the exact ModulesCatalog + FeatureSearch sources without Android SDK.
Android Activity dependencies are replaced ONLY by empty compile-time mocks in a temp dir.
"""
from pathlib import Path
import subprocess, tempfile, re
source=Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/silenttimer'
catalog=(source/'ModulesCatalog.java').read_text(encoding='utf-8')
classes=sorted(set(re.findall(r'\b(\w+Activity)\.class\b',catalog)))
with tempfile.TemporaryDirectory(prefix='nexa221_catalog_') as tmp:
    dest=Path(tmp); (dest/'android/app').mkdir(parents=True);(dest/'com/example/silenttimer').mkdir(parents=True)
    (dest/'android/app/Activity.java').write_text('package android.app;public class Activity {}',encoding='utf8')
    (dest/'com/example/silenttimer/Mocks.java').write_text('package com.example.silenttimer;\nimport android.app.Activity;\n'+''.join(f'class {c} extends Activity {{}}\n' for c in classes),encoding='utf8')
    (dest/'com/example/silenttimer/Test.java').write_text('''package com.example.silenttimer;
public class Test {
 private static void check(boolean b){if(!b)throw new AssertionError("catalog check failed");}
 public static void main(String[] args){
  check(ModulesCatalog.ALL.length==22);
  check(ModulesCatalog.filter("",0).size()==22);
  check(ModulesCatalog.filter("قسط",0).size()==1);
  check("قبوض و اقساط".equals(ModulesCatalog.filter("قسط",0).get(0).title));
  check(ModulesCatalog.filter("بانك",1).size()==1);
  check(ModulesCatalog.filter("دارو",1).isEmpty());
  check("یادآورها".equals(ModulesCatalog.filter("يادآورها",3).get(0).title));
  check(ModulesCatalog.filter("",4).size()>=5);
  java.util.Set<Class<?>> seen=new java.util.HashSet<>();
  for(ModulesCatalog.Item x:ModulesCatalog.ALL){check(x.group>=1&&x.group<=4);check(seen.add(x.destination));}
  System.out.println("PASS: Java catalog 22 unique destinations, Persian search and group filters");
 }
}''',encoding='utf8')
    subprocess.run(['javac','-encoding','UTF-8','-d',str(dest),str(dest/'android/app/Activity.java'),str(dest/'com/example/silenttimer/Mocks.java'),str(dest/'com/example/silenttimer/Test.java'),str(source/'FeatureSearch.java'),str(source/'ModulesCatalog.java')],check=True,capture_output=True,text=True)
    r=subprocess.run(['java','-cp',str(dest),'com.example.silenttimer.Test'],check=True,capture_output=True,text=True)
    print(r.stdout.strip())
