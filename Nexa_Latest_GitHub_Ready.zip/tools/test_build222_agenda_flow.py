"""Build222 - focused, non-emulator guards for two frequently used calendar screens.
Does not replace the GitHub Android emulator regression test.
"""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/example/silenttimer'
today=(java/'TodayActivity.java').read_text()
timeline=(java/'TimelineActivity.java').read_text()
shared=(java/'NexaAgendaUi.java').read_text()
policy=(java/'TodayPresentationPolicy.java').read_text()
instrument=(root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
version=(root/'app/build.gradle').read_text()
assert 'versionCode 223' in version and 'versionName "5.4.201"' in version
assert 'UiKit.bottomNav(this,1' in today and 'UiKit.bottomNav(this,3' in timeline
assert 'new Intent(this,ReminderEditActivity.class)' in today
assert 'new Intent(this,QuickAddActivity.class)' in today
assert 'new Intent(this,AnnualOccasionsActivity.class)' in today
assert 'new Intent(this,SearchActivity.class)' in today
for key in ('KEY_NOTE_DRAFT','KEY_SCROLL','KEY_COMPLETED','KEY_TOMORROW','KEY_WEEK','KEY_OVERDUE','KEY_CURRENT'):
    assert key in today, key
assert 'onSaveInstanceState(Bundle state)' in today
assert 'firstResume' in today and 'captureDraft()' in today
assert 'if(open&&displayed[0]==0)appendBatch' in today
assert 'TodayPresentationPolicy.nextVisibleCount' in today
for title in ['معوق و پیگیری‌نشده','انجام‌نشده امروز','انجام‌شده امروز','پیش‌نمایش فردا','روزهای ۲ تا ۷ آینده']:
    assert title in today, title
assert 'AgendaDuePolicy.shownDue(r.whenMillis,r.recurrence,todayStart)' in timeline
assert 'AgendaDuePolicy.startOfDay(now)' in timeline
assert 'AgendaDuePolicy.afterCalendarDays(start,"today".equals(window)?1:7)' in timeline
assert 'now-(now%DAY)' not in timeline
assert 'futureLimit+=40' in timeline and 'pastLimit+=40' in timeline
assert 'resetLimits();renderWindows();render();' in timeline
assert 'visibleFuture.isEmpty()&&visiblePast.isEmpty()' in timeline
assert 'if(!visiblePast.isEmpty())renderSection' in timeline
assert 'HomeUi.shouldStack(c)' in shared
assert 'fontScale>=1.30f' in shared
assert 'tile.setContentDescription(labels[k]+"، "+values[k])' in shared
assert 'PAGE_SIZE=8' in policy and 'Math.min((long)safeTotal' in policy
assert 'build222_todayAndTimelineUseTheSameAccessibleNavigationAndPagedLists' in instrument
assert 'build222_timelineCalendarWindowUsesRealLocalDayBoundary' in instrument
assert 'NexaStore.' not in policy and 'android.' not in policy
print('PASS 222 agenda: RTL bottom-nav, screen-state retention, high-density pagination, DST and recurrence, 2 emulator checks')
