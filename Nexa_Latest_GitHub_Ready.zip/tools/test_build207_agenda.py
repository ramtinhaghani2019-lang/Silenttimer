"""Build 207 static contract tests; Android CI remains required."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/example/silenttimer'
main=(java/'MainActivity.java').read_text()
today=(java/'TodayActivity.java').read_text()
policy=(java/'AgendaDuePolicy.java').read_text()
android=(root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
gradle=(root/'app/build.gradle').read_text()
assert 'versionCode 223' in gradle and 'versionName "5.4.201"' in gradle
assert 'AgendaDuePolicy.shownDue(r.whenMillis,r.recurrence,start)' in today
assert 'AgendaDuePolicy.includeReminder(r.active,r.done)' in today
assert 'AgendaDuePolicy.bucket(i.at,i.done,start,end,tomorrowEnd,next7End)' in today
assert 'AgendaDuePolicy.afterCalendarDays(start,8)' in today
assert 'r.done,RemindersActivity.class' in today
assert 'AgendaDuePolicy.overdueForAttention(' in main
assert 'build207_todayAndRecurringDeadlinesDoNotDuplicateOrMislabelPausedItems' in android
assert all(x in policy for x in ('Calendar.DAY_OF_YEAR','ReminderRecurrence.next','LATER_THIS_WEEK','COMPLETED','includeReminder'))
assert 'NexaStore' not in policy and 'android.' not in policy
assert 'r.whenMillis=' not in policy and 'NexaStore.updateReminder' not in today
assert 'addSection(root,"☀️ پیش‌نمایش فردا",tomorrow' in today
assert 'addSection(root,"📆 روزهای ۲ تا ۷ آینده",next7' in today
print('PASS: Build 207 version, recurrence, paused/completed, calendar boundaries, and navigation source gates')
