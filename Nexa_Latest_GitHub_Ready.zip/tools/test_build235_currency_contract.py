from pathlib import Path
r=Path(__file__).parents[1]
s=(r/'app/src/main/java/com/example/silenttimer/AssetsActivity.java').read_text()
unit=(r/'app/src/main/java/com/example/silenttimer/AssetMoneyUnit.java').read_text()
assert 'versionCode 235' in (r/'app/build.gradle').read_text()
assert 'versionName "5.4.213"' in (r/'app/build.gradle').read_text()
assert 'final String quoteUnit=groupMoneyUnit(groupName)' in s
assert 'moneyFormat.format(AssetMoneyUnit.fromStored(old,quoteUnit))' in s
assert 'AssetMoneyUnit.toStored(num(price.getText().toString()),quoteUnit)' in s
assert 'AssetGroupQuoteEngine.applyQuote(latest,groupName,newQuote,' in s
assert 'money(market,quoteUnit)' in s
assert 'money(gain,quoteUnit)' in s
assert 'money(market,displayUnit)' in s
assert 'money(cost(x),assetMoneyUnit(x))' in s
assert 'AssetMoneyUnit.toStored(num(price.getText().toString()),saleUnit)' in s
assert 'AssetMoneyUnit.toStored(num(target.getText().toString()),entryUnit)' in s
assert 'AssetMoneyUnit.toStored(num(alertTarget.getText().toString()),"ریال")' in s
assert 'AssetMoneyUnit.fromStored(current.buyUnitPrice,"ریال")' in s
assert 'AssetMoneyUnit.fromStored(current.fee,"ریال")' in s
assert 'AssetMoneyUnit.fromStored(current.currentUnitPrice,"ریال")' in s
assert 'for(NexaStore.AssetEntry x:NexaStore.assets(this))' in s
assert 'return isRial(displayUnit)?input/10d:input;' in unit
assert 'return isRial(displayUnit)?toman*10d:toman;' in unit
print('PASS: Build 235 rial pricing contract (18 checks)')
