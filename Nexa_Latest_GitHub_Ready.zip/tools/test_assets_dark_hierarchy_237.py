"""Contract-only audit of the approved dark parent/child asset UI.
Not a replacement for Android instrumentation or on-device screenshots.
"""
from pathlib import Path
s=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/silenttimer/AssetsActivity.java').read_text(encoding='utf8')
checks={
 'approved parent gradient':'new int[]{0xFF1A3450,0xFF10243A,0xFF0B1B2F}',
 'gold master outline':'masterSurface.setStroke(UiKit.dp(this,1),0xFFAB8B50)',
 'group summary clearly titled':'خلاصه کل دارایی',
 'group total value':'ارزش روز کل دارایی',
 'group cost metric':'darkMetricTile("بهای تمام‌شده"',
 'group net holding metric':'darkMetricTile("موجودی خالص"',
 'distinct sub-section':'new int[]{0xFF264360,0xFF1A3049}',
 'dark purchase section':'0xFF06182A',
 'gold subgroup header accent':'0xFFE5BD70',
 'purchase numbering':'position+1',
 'actual per-entry date':'PersianDateUtil.pretty(x.buyDate)',
 'per-entry cost remains independent':'money(cost(x),assetMoneyUnit(x))',
 'per-entry value remains independent':'money(value(x),assetMoneyUnit(x))',
 'per-entry profit':'AssetFinanceEngine.unrealizedProfit(x)',
 'per-entry details':'showAssetDetails(x)',
 'per-entry sell':'sellForm(x)',
 'per-asset new purchase':'editForm(null,groupName,null)',
 'purchases start compact except first':'final boolean defaultExpanded=position<=0;',
 'purchase visibility saved':'out.putStringArrayList(STATE_PURCHASE_OPEN,openLots)',
 'purchase visibility restored':'purchaseExpansion.put(id,true)',
 'purchase toggle persists':'purchaseExpansion.put(x.id,show)',
 'group visibility saved':'out.putStringArrayList(STATE_GROUPS',
 'group visibility restored':'expandedAssetGroups.addAll(open)',
 'scroll position preserved':'assetsScroll.scrollTo(0,scrollY)',
 'shared group rendering':'renderPortfolioGroups(visible)',
}
for name, marker in checks.items():
    assert marker in s, f'Missing: {name}'
print(f'PASS: {len(checks)} approved dark hierarchy and lifecycle source contracts')
