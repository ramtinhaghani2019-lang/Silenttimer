#!/usr/bin/env python3
"""Structural guard for the Build 219 emulator failure, carried into Build 220.
Tests on the Android emulator are still the final authority for View behavior.
"""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
ui=(root/'app/src/main/java/com/example/silenttimer/NexaAssetsUi.java').read_text()
t=(root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assets=(root/'app/src/main/java/com/example/silenttimer/AssetsActivity.java').read_text()
assert 'chip.setMinHeight(UiKit.dp(c,48))' in ui
assert 'chip.setMinimumHeight(UiKit.dp(c,48))' in ui
assert 'chip.setMinimumWidth(UiKit.dp(c,76))' in ui
assert 'chip.getMinimumHeight()>=UiKit.dp(c,48)' in t
assert 'inactive.getMinimumHeight()>=UiKit.dp(c,48)' in t
assert 'chip.setMinimumHeight(UiKit.dp(this,48))' in assets
print('PASS: interactive asset filters explicitly declare 48dp View minimum height and preserve accessibility labels')
