"""Static regression contract for loss of expanded purchase groups on Activity resume.
Does not replace an Android instrumentation or device test.
"""
from pathlib import Path
src=(Path(__file__).resolve().parents[1]/'app/src/main/java/com/example/silenttimer/AssetsActivity.java').read_text(encoding='utf-8')
checks = {
 'separate state for expanded groups': 'expandedAssetGroups=new java.util.LinkedHashSet<>()',
 'saved instance state': 'out.putStringArrayList(STATE_GROUPS',
 'restored instance state': 'expandedAssetGroups.addAll(open)',
 'maintain current page': 'out.putString(STATE_PAGE,assetPage)',
 'scroll position saved': 'out.putInt(STATE_SCROLL,assetsScroll==null?0:assetsScroll.getScrollY())',
 'restore scroll after rerender': 'assetsScroll.scrollTo(0,scrollY)',
 'restore opened details': 'details.setVisibility(expandedAssetGroups.contains(groupName)?View.VISIBLE:View.GONE)',
 'restore opened metrics': 'extras.setVisibility(expandedAssetGroups.contains(groupName)?View.VISIBLE:View.GONE)',
 'expand saves new state': 'expandedAssetGroups.add(groupName)',
 'collapse removes saved state': 'expandedAssetGroups.remove(groupName)',
 'restore saved page': 'openAssetsPage(restoredPage)',
}
for description,token in checks.items():
 assert token in src, description
print('PASS: 11 portfolio activity-resume state persistence contracts')
