"""Static candidate checks; do not substitute for Android CI/emulator validation."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'app/src/main/java/com/example/silenttimer/AssetsActivity.java').read_text()
picker=(r/'app/src/main/java/com/example/silenttimer/AssetSelectionSheet.java').read_text()
v=(r/'app/src/main/java/com/example/silenttimer/AssetVisualPolicy.java').read_text()
icon=(r/'app/src/main/java/com/example/silenttimer/NexaOutlineIcon.java').read_text()
assert 'versionCode 236' in (r/'app/build.gradle').read_text()
assert 'versionName "5.4.214"' in (r/'app/build.gradle').read_text()
for page in ('overview','holdings','history','market','reports','settings'):
    assert f'page("{page}")' in s,page
for required in ('openAssetsPage("settings")','private void renderAssetHistory()','private void setGroupedAssets(',
  'AssetSelectionSheet.show(this,types','formStage[0]','chosenEntryMode[0]','selectedType[0]',
  'moveTo(modePanel,settings','moveTo(report,reports','moveTo(market,prices',
  'moveTo(typeManager,settings','updateMarketText()',
  'AssetMoneyUnit.toStored(num(price.getText().toString()),saleUnit)',
  'PriceMonitorReceiver.schedule(this)','NexaStore.updateAsset(this,x)',
  'NexaStore.addAsset(this,x)','NexaStore.removeAsset(this,x.id)',
  'getSharedPreferences("nexa_assets_ui",MODE_PRIVATE)'):
    assert required in s,required
assert 'return "ریال";' in s
assert 'Spinner.MODE_DIALOG' in s
assert 'ScrollView scroll' in picker
assert 'onSelect.accept(item)' in picker
assert 'AssetVisualPolicy.iconFor(item)' in picker
assert 'AssetSelectionSheet.unit(type)' in s
for i in ('"usd"','"eur"','"coin"','"gold"','"silver"','"copper"','"stocks"','"ounce"'):
    assert f'case {i}:' in icon,i
assert '"copper"' in v and '"stocks"' in v
assert 'class AssetUx236RegressionTest' in (r/'app/src/androidTest/java/com/example/silenttimer/AssetUx236RegressionTest.java').read_text()
print('PASS: design 236 source contracts (pages, flows, icons, units, storage, regression hooks)')
