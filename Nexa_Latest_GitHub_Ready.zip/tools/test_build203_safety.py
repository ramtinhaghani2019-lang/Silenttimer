"""Build 203: visual guards for allowed calls and optional emergency card."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=r/'app/src/main/java/com/example/silenttimer'
a=(s/'AllowedCallsActivity.java').read_text()
e=(s/'EmergencyActivity.java').read_text()
u=(s/'NexaSafetyUi.java').read_text()
g=(r/'app/build.gradle').read_text()
t=(r/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'versionCode 205' in g and 'versionName "5.4.183"' in g
assert all(k in a for k in ['NexaSafetyUi.callMetrics(', 'NexaSafetyUi.contactCard(', 'NexaSafetyUi.empty(',
    'AppPrefs.addAllowedContact(', 'AppPrefs.removeAllowedContact(', 'AppPrefs.setAllowedCallsEnabled(',
    'AppPrefs.setMissedCallGuardEnabled(', 'requestCallScreeningRole()', 'openFullScreenPermission()',
    'ContactsContract.CommonDataKinds.Phone.CONTENT_URI', 'refreshOverview()'])
assert all(k in e for k in ['NexaSafetyUi.emergencyMetrics(', 'NexaSafetyUi.subheading(',
    'NexaStore.setEmergencyEnabled(', 'NexaStore.setEmergencyName(', 'NexaStore.setEmergencyPhone1(',
    'NexaStore.setEmergencyPhone2(', 'NexaStore.setEmergencyNote(', 'EmergencyCardManager.refresh(',
    'Intent.ACTION_DIAL', 'call1.setEnabled(', 'call2.setEnabled('])
assert all(k in u for k in ['setHorizontalScrollBarEnabled(false)', 'setContentDescription(',
    'setMinimumHeight(UiKit.dp(c,84))', 'setMinimumHeight(UiKit.dp(c,100))',
    'setLayoutDirection(View.LAYOUT_DIRECTION_RTL)', 'UiKit.financialMetric('])
assert 'build203_safetySummaryAndEmergencyControlsAreAccessible' in t
print('PASS Build 203 safety surfaces: UI, existing routes, privacy, accessible touches')
