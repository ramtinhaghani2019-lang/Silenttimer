"""Build 230: verify critical layout structure and preservation of financial actions.

The installed Android emulator remains authoritative for actual View measurement.
"""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/example/silenttimer'
a=(p/'AssetsActivity.java').read_text()
n=(p/'NexaAssetsUi.java').read_text()
m=(p/'AssetRatesPanel.java').read_text()
v=(p/'NexaOutlineIcon.java').read_text()
f=(p/'PersianFinancialDisplay.java').read_text()
assert 'private boolean groupedView=true' in a
assert 'renderPortfolioGroups(visible)' in a
assert 'details.setVisibility(show?View.VISIBLE:View.GONE)' in a
assert 'root.addView(reportSection,firstHolding' in a
assert 'root.addView(marketSection,firstHolding+1' in a
assert 'root.addView(list,UiKit.matchWrap(this,0,14))' in a
assert 'summary.setMaxLines(3)' in a
assert 'summary.setText("خریدها:' in a
assert 'PersianFinancialDisplay.amount2(value)' in a
for action in ('showAssetDetails(x)','sellForm(x)','editForm(x)',
               'NexaStore.removeAsset(this,x.id)','PriceMonitorReceiver.schedule(this)',
               'MarketDataHelper.refresh(this,', 'NexaStore.saveAssets(this,'):
    assert action in a,action
assert 'static LinearLayout metrics(' in n
assert 'amount.setMaxLines(3)' in n
assert 'int columns=width>=360' in m
assert 'for(int from=0;from<labels.length;from+=columns)' in m
assert 'NexaOutlineIcon icon=new NexaOutlineIcon' in m
for icon in ('case "usd"','case "eur"','case "gold"','case "coin"','case "ounce"'):
    assert icon in v,icon
assert '"#,##0.##"' in f
assert 'versionCode 230' in (r/'app/build.gradle').read_text()
print('PASS: Build 230 asset order, grouped purchases, amount readability, icons, actions')
