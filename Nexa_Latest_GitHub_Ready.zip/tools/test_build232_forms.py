from pathlib import Path
import xml.etree.ElementTree as ET
r=Path(__file__).resolve().parents[1]
p=r/'app/src/main/java/com/example/silenttimer'
a=(p/'AssetsActivity.java').read_text()
u=(p/'UiKit.java').read_text()
m=(p/'AssetPurchaseMath.java').read_text()
assert 'versionCode 232' in (r/'app/build.gradle').read_text()
assert 'versionName "5.4.210"' in (r/'app/build.gradle').read_text()
assert 'Spinner currency=' not in a
assert 'سوت اضافه' not in a
assert 'EditText soot=' not in a
assert 'مقدار خالص دریافتی (تا ۸ رقم اعشار)' in a
assert 'محاسبه مقدار از مبلغ پرداختی' in a
assert 'AssetPurchaseMath.netQuantity(' in a
assert 'AssetPurchaseMath.valid(' in a
assert 'originalAmountText' in a and 'originalBuyText' in a and 'originalQuoteText' in a
assert 'x.fee=f/divisor' in a
assert 'x.currency="ریال"' in a
assert 'x.buyUnitPrice=b/divisor' in a
assert 'NexaStore.addAsset(this,x)' in a and 'NexaStore.updateAsset(this,x)' in a
assert 'private EditText field(String hint){return UiKit.styleField' in a
for label in ('مشخصات خرید','مقدار و قیمت','قیمت روز و هشدارها','تاریخ و توضیحات'):
 assert label in a,label
assert 'public static LinearLayout formDisclosure(' in u
assert 'return formDisclosure(c,title,fields,initiallyOpen);' in u
assert 's.setBackgroundResource(R.drawable.nexa_spinner_selector);' in u
assert 'public static LinearLayout dialogPanel(' in u
assert 'public static LinearLayout collapsible(' in u
for n in ['HomeCareActivity','BillsActivity','VaultActivity','DocsActivity','CaseActivity','LedgerActivity','MedicineActivity']:
 s=(p/(n+'.java')).read_text()
 assert 'UiKit' in s,n
for f in ('drawable/nexa_spinner_selector.xml','drawable/nexa_spinner_chevron.xml','drawable/nexa_dialog_bg.xml','values/styles.xml'):
 ET.parse(r/'app/src/main/res'/f)
assert 'BigDecimal' in m and 'RoundingMode.HALF_UP' in m
print('PASS: Build232 global form, asset entry, precision, shared themes and resources')
