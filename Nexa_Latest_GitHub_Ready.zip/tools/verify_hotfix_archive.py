"""Verify release archive before user upload. Does not replace Android CI."""
from pathlib import Path
from zipfile import ZipFile
import sys, hashlib
from lxml import etree

p=Path(sys.argv[1]) if len(sys.argv)>1 else Path('Nexa_Latest_GitHub_Ready.zip')
assert p.is_file(),p
with ZipFile(p) as z:
    bad=z.testzip()
    assert bad is None, f'Corrupt ZIP entry: {bad}'
    files=set(z.namelist())
    assert len(files)==len(z.namelist()),'Duplicate paths'
    required={'app/build.gradle','app/src/main/AndroidManifest.xml','app/src/main/java/com/example/silenttimer/MainActivity.java','app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java','RELEASE_5.4.174_FA.md','tools/test_home_layout.py','app/src/main/java/com/example/silenttimer/HomeUi.java'}
    assert required<=files, required-files
    for fn in files:
        assert not fn.startswith('/') and '..' not in Path(fn).parts, f'Unsafe zip path: {fn}'
        if fn.endswith('.xml'):
            etree.fromstring(z.read(fn))
    gradle=z.read('app/build.gradle').decode()
    main=z.read('app/src/main/java/com/example/silenttimer/MainActivity.java').decode()
    reg=z.read('app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').decode()
    assert 'versionCode 196' in gradle and 'versionName "5.4.174"' in gradle
    assert 'attachHomeContent(screen,sc,bottom,bp);' in main
    assert 'mainHomeDashboard_isAttachedAndScrollableAboveBottomNavigation' in reg
    assert not any(fn.lower().endswith(('.jks','.keystore','.p12','.pfx','.key','.pem')) for fn in files)
    print('ZIP_OK',len(files),'entries, XML valid, Build196 consistent,',p.stat().st_size,'bytes')
    print('SHA256',hashlib.sha256(p.read_bytes()).hexdigest())
