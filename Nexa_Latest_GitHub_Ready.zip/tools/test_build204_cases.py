"""Build 204: static UI/compatibility guards, NOT a substitute for Android CI."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
case=(p/'app/src/main/java/com/example/silenttimer/CaseActivity.java').read_text()
policy=(p/'app/src/main/java/com/example/silenttimer/CaseOverviewPolicy.java').read_text()
ui=(p/'app/src/main/java/com/example/silenttimer/NexaCaseUi.java').read_text()
test=(p/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
gradle=(p/'app/build.gradle').read_text()
assert 'versionCode 226' in gradle and 'versionName "5.4.204"' in gradle
assert all(k in case for k in ('NexaCaseUi.metrics(', 'CaseOverviewPolicy.shownDate(', 'refreshFilterChips()',
    '"همه", "آینده", "گذشته"', 'formScroll.addView(box)',
    'setPositiveButton("ذخیره", null)', 'title.setError(', 'editor.dismiss()',
    'NexaStore.addCase(', 'NexaStore.updateCase(', 'NexaStore.removeCase(',
    'LinkedReminderHelper.upsert(', 'LinkedReminderHelper.remove(', 'NexaStore.addHistory(',
    'NexaStore.addCourt(', 'NexaStore.addLawyer(', 'RepeatIntervalPicker', 'AlertEditor'))
assert 'ReminderRecurrence.next(savedDate, recurrence, now)' in policy
assert not any(x in policy for x in ('updateCase(', 'addCase(', 'schedule(', 'upsert('))
assert all(x in ui for x in ('setContentDescription(', 'UiKit.financialMetric(', 'UiKit.dp(c, 48)', 'statusBadge('))
assert 'build204_caseOverviewDoesNotMutateSavedDatesAndControlsAreAccessible' in test
assert 'package com.example.silenttimer;' in case
print('PASS Build 204 case UI, editor, all original persistence/scheduling APIs, tests and version')
