"""Static compatibility/UX gates for Build 205, not an Android compile."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
main=(p/'app/src/main/java/com/example/silenttimer/BillsActivity.java').read_text()
policy=(p/'app/src/main/java/com/example/silenttimer/BillListPolicy.java').read_text()
ui=(p/'app/src/main/java/com/example/silenttimer/NexaBillsUi.java').read_text()
gradle=(p/'app/build.gradle').read_text()
reg=(p/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'versionCode 226' in gradle and 'versionName "5.4.204"' in gradle
assert all(k in main for k in ('BillListPolicy.compare(', 'BillListPolicy.matches(',
    'BillListPolicy.summarize(', 'NexaBillsUi.metrics(', 'NexaBillsUi.status(',
    'private void confirmPayment(', 'setPositiveButton("تأیید پرداخت"',
    'Button paidButton=UiKit.secondaryButton(', 'setContentDescription(',
    'NexaStore.addBill(', 'NexaStore.updateBill(', 'NexaStore.removeBill(',
    'LinkedReminderHelper.upsert(', 'LinkedReminderHelper.remove(',
    'PaymentCardSecrets.copy(', 'RepeatIntervalPicker', 'AlertEditor',
    'formScroll.addView(box)', 'NexaStore.addHistory('))
assert 'paidButton.setOnClickListener(v->confirmPayment(x))' in main
assert 'if("پرداخت شد".equals(choice))confirmPayment(x)' in main
assert all(k not in policy for k in ('updateBill(', 'addBill(', 'schedule(', 'setPrimaryClip('))
assert 'UiKit.financialMetric(' in ui and 'setContentDescription(' in ui
assert 'build205_billsSummaryFiltersAndPaymentStatusStayAccessible' in reg
print('PASS Build205 bills static and compatibility checks')
