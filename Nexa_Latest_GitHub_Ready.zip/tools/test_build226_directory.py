"""Build 226 UI structure test: adaptive filters and paged results, all original data flows preserved."""
from pathlib import Path
root = Path(__file__).resolve().parents[1]
src = root/'app/src/main/java/com/example/silenttimer'
r = (src/'RemindersActivity.java').read_text(encoding='utf-8')
s = (src/'SearchActivity.java').read_text(encoding='utf-8')
p = (src/'NexaDirectoryPolicy.java').read_text(encoding='utf-8')
g = (root/'app/build.gradle').read_text()
reg = (root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'versionCode 226' in g and 'versionName "5.4.204"' in g
assert 'HorizontalScrollView' not in s and 'HorizontalScrollView' not in r
assert 'quickFilters.setOrientation(LinearLayout.VERTICAL)' in r
assert 'filterBar.setOrientation(LinearLayout.VERTICAL)' in s
for x in (r,s):
    assert 'NexaDirectoryPolicy.filterColumns(' in x
    assert 'getResources().getConfiguration().fontScale' in x
    assert 'getResources().getConfiguration().screenWidthDp' in x
    assert 'chip.setMinimumHeight(UiKit.dp(this,48))' in x
    assert 'chip.setMaxLines(2)' in x
    assert 'NexaDirectoryPolicy.nextLimit(' in x
    assert 'NexaDirectoryPolicy.visibleCount(' in x
    assert 'NexaDirectoryPolicy.remaining(' in x
    assert 'visibleLimit=' in x
assert 'NexaDirectoryPolicy.REMINDER_PAGE_SIZE' in r and 'NexaDirectoryPolicy.SEARCH_PAGE_SIZE' in s
assert 'out.putInt("visibleLimit",visibleLimit)' in r
assert 'state.putInt("nexa.search.limit",visibleLimit)' in s
for token in ('chooseCalendarExport()', 'selectedIds.add(r.id)', 'showReminderMenu(r)',
              'ReminderOrganizer.ordered(all,order,now)', 'ReminderOrganizer.matches(r,searchText)',
              'ReminderRecurrence.isRecurring(r.recurrence)'):
    assert token in r, token
for token in ('NexaStore.reminders(this)', 'NexaStore.ledgerEntries(this)',
              'NexaStore.ledgerParties(this)', 'NexaStore.bills(this)',
              'NexaStore.documents(this)', 'NexaStore.vault(this)',
              'SearchQueryPolicy.matches(hay,x)', 'SearchDisplayPolicy.compare('):
    assert token in s,token
assert 'filterColumns(int widthDp, float fontScale)' in p
assert 'if (current >= Integer.MAX_VALUE - pageSize)' in p
assert 'build226_directoryFiltersStayVisibleAndPageWithoutDroppingRecords' in reg
assert 'NexaDirectoryPolicySmokeTest.java' in [q.name for q in (root/'tools/tests').glob('*.java')]
print('PASS Build226: adaptive non-clipped filters; paged views; unmodified data search and calendar actions')
