from pathlib import Path
import re,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/example/silenttimer'
a=list(j.glob('*Activity.java'))
assert len(a)>=40,len(a)
assert all('UiKit.applyWindow' in p.read_text() for p in a)
u=(j/'UiKit.java').read_text()
for key in ('NexaAuroraDrawable','appFace(Context c,boolean bold)','R.font.nexa_fa_regular',
            'R.font.nexa_fa_bold','return card(c);','symbolFor(String emoji)',
            'setMinimumHeight(dp(c,56))','public static LinearLayout collapsible(',
            'public static LinearLayout bottomNav('):
    assert key in u,key
for n in ('nexa_fa_regular.ttf','nexa_fa_bold.ttf'):
    assert (root/'app/src/main/res/font'/n).stat().st_size>100000
s=(root/'app/src/main/res/values/styles.xml').read_text()
ET.fromstring(s)
assert '@font/nexa_fa_regular' in s
assert 'versionCode 225' in (root/'app/build.gradle').read_text()
for name in ('NexaStore.java','NexaAudioController.java','ReminderScheduler.java','SilentTimerService.java','OccasionScheduler.java'):
    assert (j/name).exists(),name
assert (root/'NEXA_SOURCE_OF_TRUTH_FA.md').exists()
assert (root/'NEXA_ALL_SCREENS_UX_AUDIT_FA.md').exists()
print('PASS: all activities inherit global design; icons, colors, fonts, nav, disclosures, core classes')
