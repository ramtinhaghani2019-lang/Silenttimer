"""Build 194: visual-only Today/Timeline regression guard."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=root/'app/src/main/java/com/example/silenttimer'
t=(app/'TodayActivity.java').read_text(encoding='utf-8')
l=(app/'TimelineActivity.java').read_text(encoding='utf-8')
a=(app/'NexaAgendaUi.java').read_text(encoding='utf-8')
assert 'UiKit.header(this,"امروز"' in t and 'UiKit.header(this,"خط زمانی"' in l
assert 'NexaAgendaUi.stats(this' in t and 'NexaAgendaUi.stats(this' in l
assert 'NexaAgendaUi.event(this' in t and 'NexaAgendaUi.event(this' in l
assert 'NexaAgendaUi.chip(this' in l
assert 'HomeUi.shouldStack(c)' in a and 'setMinimumHeight(UiKit.dp(c,76))' in a
assert 'subtlePastCard' in a and 'touchFeedback(c,item' in a
assert 'NexaStore.setUnlockNote' in t
for x in ['BillsActivity.class','DocsActivity.class','MedicineActivity.class','GarageActivity.class']:
    assert x in t and x in l
assert 'RemindersActivity.class' in t and 'ReminderEditActivity.class' in l
assert 'put(new Event' in l and 'future.sort' in l and 'past.sort' in l
assert 'versionCode 196' in (root/'app/build.gradle').read_text()
print('PASS: premium agenda, retained destinations and note storage, adaptive status metrics, 194 version')
