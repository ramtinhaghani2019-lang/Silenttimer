"""Build 229: preserve asset actions while replacing monolithic market rates UI."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
s=(r/'app/src/main/java/com/example/silenttimer/AssetsActivity.java').read_text(encoding='utf8')
v=(r/'app/src/main/java/com/example/silenttimer/AssetRatesPanel.java').read_text(encoding='utf8')
f=(r/'app/src/main/java/com/example/silenttimer/AssetRateFormatter.java').read_text(encoding='utf8')
for label in ['ارزها','طلا و اونس جهانی','سکه‌ها','دلار','یورو','طلای ۱۸ عیار',
              'طلای ۲۴ عیار','اونس جهانی (USD)','امامی','بهار آزادی','نیم‌سکه','ربع‌سکه','سکه گرمی']:
    assert f'"{label}"' in s,label
assert 'marketStatus.setText("آخرین دریافت: "' in s
assert 'marketRateContainer.removeAllViews()' in s
assert 'AssetRatesPanel.addGroup(this,marketRateContainer' in s
assert 'new double[]{NexaStore.iranImami(this)' not in s
assert 'NexaStore.iranEmami(this)' in s and 'NexaStore.iranGerami(this)' in s
assert 'marketSource.setText("منبع: "' in s
assert 'marketFeedback.setText(msg)' in s and 'updateMarketText();' in s
assert 'UiKit.collapsible(this,"asset_market_mode_207"' in s
assert 'UiKit.collapsible(this,"market_controls_176"' in s
assert 'new LinearLayout.LayoutParams(0,UiKit.dp(this,48),1f)' in s
assert 'current!=null&&(current.alertTarget>0||current.alertAtBuy||current.autoPrice)' in s
for event in ['NexaStore.addAsset(this,x)','NexaStore.updateAsset(this,x)',
              'NexaStore.removeAsset(this,x.id)','AssetFinanceEngine.sell(x,q,p,System.currentTimeMillis())',
              'PriceMonitorReceiver.schedule(this)','showMarketHistory()','showPriceAlertManager()',
              'renderAssetFilters()','editGroupMarketPrice(vendor.getKey(),vendor.getValue())']:
    assert event in s,event
assert 'screenDp>=340&&fontScale<1.35f?2:1' in v
assert 'tile.setContentDescription(labels[i]+"، "+rate)' in v
assert 'return AssetRateFormatter.display(value);' in v
assert 'PersianFinancialDisplay.amount(rate)' in f
assert 'Double.isFinite(rate)' in f
assert 'versionCode 229' in (r/'app/build.gradle').read_text()
print('PASS: asset rate groupings, accessibility, real data binding, compact forms, actions preserved')
