"""Regression guard for Build 201 activity history and file center UX."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/example/silenttimer'
history=(src/'HistoryActivity.java').read_text()
files=(src/'FileCenterActivity.java').read_text()
ui=(src/'NexaArchiveUi.java').read_text()
policy=(src/'HistoryScopePolicy.java').read_text()
assert all(k in history for k in ['NexaArchiveUi.metrics(', 'HistoryScopePolicy.matches(', 'NexaArchiveUi.chip(', 'NexaArchiveUi.record(', 'NexaStore.clearHistory(this)', 'NexaStore.history(this)', 'setOnClickListener', 'PersianDateUtil.pretty'])
assert all(k in files for k in ['AttachmentStore.count(this)', 'AttachmentStore.totalBytes(this)', 'NexaStore.shoppingReceipts(this)', 'sellerFilter.setOnItemSelectedListener', 'NexaArchiveUi.record(', 'NexaStore.removeShoppingReceipt(this,receipt.id)', 'AttachmentStore.deletePath(receipt.localPath)', 'AttachmentStore.deleteExistingModule(this,m)', 'NexaStore.clearShoppingReceipts(this)', 'openReceipt(receipt)'])
assert 'setPositiveButton("ادامه"' in files and 'setTitle("تأیید نهایی")' in files
assert 'setMinHeight(UiKit.dp(c,46))' in ui and 'setContentDescription' in ui
assert 'timestamp<=now' in policy and 'timestamp>=now-window' in policy
assert 'versionCode 223' in (root/'app/build.gradle').read_text()
assert 'versionName "5.4.201"' in (root/'app/build.gradle').read_text()
print('PASS: Build201 archive screens, date scopes, deletion confirmations and visual contracts')
