"""Build 195: reminder design-only guard; preserve all scheduling/data actions."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
app=root/'app/src/main/java/com/example/silenttimer'
r=(app/'RemindersActivity.java').read_text(encoding='utf-8')
e=(app/'ReminderEditActivity.java').read_text(encoding='utf-8')
u=(app/'NexaReminderUi.java').read_text(encoding='utf-8')
assert 'NexaReminderUi.metrics(this,pending,overdue,completed)' in r
assert 'showQuickFilters()' in r and 'NexaReminderUi.filterChip(this' in r
assert 'NexaReminderUi.reminderCard(this,overdue,r.done)' in r
assert 'NexaReminderUi.state(this,state,tone)' in r
assert 'NexaReminderUi.formSection(this,' in e
assert 'new RepeatIntervalPicker(this,schedule' in e and 'new AlertEditor(this,schedule' in e
assert 'HomeUi.shouldStack(c)' in u and 'UiKit.dp(c,44)' in u
assert 'UiKit.RED' in u and 'UiKit.PURPLE' in u and 'UiKit.GREEN' in u
for s in ['markDone(r)','showReminderMenu(r)','showReminderDetails(r)','showFilterDialog()','showToolsDialog()',
          'confirmBatch(operation)','chooseCalendarExport()','ReminderRecurrence.after(','addOccurrenceRow(']:
    assert s in r,s
for s in ['NexaStore.saveReminders(this,current)','NexaStore.addReminder(this,r)','ReminderScheduler.scheduleReminder(this,r)',
          'doctorBox','doctorName','recurrence.rule()','alerts.rules()','alerts.repeatMinutes()','PersianDatePickerHelper.pickDateTime']:
    assert s in e,s
assert 'versionCode 203' in (root/'app/build.gradle').read_text()
print('PASS: premium reminders + edit UI, accessibility, adaptive stats, scheduling and storage unchanged')
