from pathlib import Path
r=Path(__file__).resolve().parents[1]
a=r/'app/src/main/java/com/example/silenttimer'
u=(a/'UiKit.java').read_text()
g=(r/'app/build.gradle').read_text()
assert 'versionCode 223' in g and 'versionName "5.4.201"' in g
assert 'new LinearLayout.LayoutParams(0,dp(c,60),1f)' in u
assert 'tab.setSelected(selected)' in u
assert 'tab.setContentDescription(label+(selected?' in u
assert 'new LinearLayout.LayoutParams(0,-2,1f)' in u
b=(a/'BatteryGuardActivity.java').read_text()
assert 'UiKit.bottomNav(this,-1' in b
for page in ('MainActivity','TodayActivity','QuickAddActivity','TimelineActivity'):
    assert 'new Intent(this,'+page+'.class)' in b
for page in ('AllowedCallsActivity.java','SmartSilentActivity.java'):
    p=(a/page).read_text()
    assert 'new Intent(this, TimelineActivity.class)' in p
    assert 'new Intent(this, HistoryActivity.class)' not in p
reg=(r/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'build214_navigationTargetsAndAccessibleSelectionRemainConsistent' in reg
print('PASS: navigation labels, click destinations, selection and 60dp touch height')
