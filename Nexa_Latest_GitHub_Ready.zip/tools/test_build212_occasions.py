from pathlib import Path
p=Path(__file__).resolve().parents[1]
java=p/'app/src/main/java/com/example/silenttimer'
gradle=(p/'app/build.gradle').read_text()
ui=(java/'AnnualOccasionsActivity.java').read_text()
policy=(java/'OccasionDirectoryPolicy.java').read_text()
android=(p/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'versionCode 226' in gradle and 'versionName "5.4.204"' in gradle
assert 'OccasionDirectoryPolicy.select(all,query,filter,now)' in ui
assert 'search.addTextChangedListener' in ui
assert 'state.putString("occasion_filter",filter)' in ui
assert 'state.putString("occasion_search"' in ui
assert 'HorizontalScrollView strip' in ui
assert 'setMinHeight(UiKit.dp(this,48))' in ui
assert 'manage.setOnClickListener(v->manage(e))' in ui
assert 'OccasionScheduler.cancel(this,e)' in ui
assert 'OccasionScheduler.schedule(this,e)' in ui
assert 'OccasionStore.delete(this,e.id)' in ui
assert 'build212_occasionDirectorySearchAndFiltersAreSafe' in android
assert 'Calendar.DAY_OF_MONTH,days' in policy and 'AnnualOccasionDates.next(e,now)' in policy
assert 'SearchQueryPolicy.matches(' in policy
assert 'SharedPreferences' not in policy and 'NexaStore' not in policy
print('PASS: Build212 version, UI search/filter, yearly dates, safe management and regression contract')
