from pathlib import Path
r=Path(__file__).resolve().parents[1]
ui=(r/'app/src/main/java/com/example/silenttimer/UiKit.java').read_text()
home=(r/'app/src/main/java/com/example/silenttimer/HomeUi.java').read_text()
draw=(r/'app/src/main/java/com/example/silenttimer/NexaAuroraDrawable.java').read_text()
assert 'new NexaAuroraDrawable()' in ui
assert 'RadialGradient' in draw and 'LinearGradient' in draw
assert 'PURPLE=0xFFB493EF' in ui and 'GOLD=0xFFF2C75C' in ui
assert 'RED=0xFFFA8091' in ui and 'GREEN=0xFF4FD1A3' in ui
assert 'return card(c);' in ui
assert 'bottomNavBackground(c)' in ui
assert 'CARD_FOCUS=0xFF213754' in home
assert 'versionCode 224' in (r/'app/build.gradle').read_text()
print('PASS: dark indigo-violet global theme, accents, financial semantic colors, navigation, version')
