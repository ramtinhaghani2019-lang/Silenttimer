from pathlib import Path
r=Path(__file__).resolve().parents[1]
ui=(r/'app/src/main/java/com/example/silenttimer/UiKit.java').read_text()
home=(r/'app/src/main/java/com/example/silenttimer/HomeUi.java').read_text()
draw=(r/'app/src/main/java/com/example/silenttimer/NexaAuroraDrawable.java').read_text()
assert 'new NexaAuroraDrawable()' in ui
assert 'RadialGradient' in draw and 'LinearGradient' in draw
assert 'PURPLE=0xFFAD6AF5' in ui and 'GOLD=0xFFF2C75C' in ui
assert 'RED=0xFFF06B83' in ui and 'GREEN=0xFF37D29C' in ui
assert 'new int[]{0xFF9139EA,0xFF6044D8}' in ui
assert 'CARD_FOCUS=0xFF28224A' in home
assert 'versionCode 193' in (r/'app/build.gradle').read_text()
print('PASS: dark indigo-violet global theme, accents, financial semantic colors, navigation, version')
