"""Build 224 architecture: no empty gimmick build, accessible compact primary flows."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/example/silenttimer'
r=lambda n:(j/n).read_text(encoding='utf8')
quick=r('QuickAddActivity.java');home=r('MainActivity.java')
action=r('NexaActionUi.java');ui=r('UiKit.java');art=r('NexaOutlineIcon.java');h=r('HomeUi.java')
assert 'versionCode 224' in (root/'app/build.gradle').read_text()
assert 'versionName "5.4.202"' in (root/'app/build.gradle').read_text()
for name in ('VoiceQuickAdd','OccasionEdit','ReminderEdit','Medicine','NexaList','Bills','Assets','Case','Docs','HomeCare','Garage','Search','Modules','Timeline'):
    assert name+'Activity.class' in quick,name
for attr in ('"shopping"','"todo"','"bool"','intent.putExtra("quick_add",quick)','intent.putExtra("quick_add",true)'):
    assert attr in quick,attr
assert 'private void pair(' in quick and 'LinearLayout group=UiKit.cardLayout(this);' in quick
assert 'NexaActionUi.compactTile(' in quick and 'NexaActionUi.tile(' in quick
assert 'fontScale>=1.55f' in quick
assert 'tile.setMinimumHeight(UiKit.dp(c,80))' in action
assert 'new NexaOutlineIcon(c,quickKind(label,emoji),color)' in action
assert 'line.setMinimumHeight(UiKit.dp(c,64))' in h
assert 'new NexaOutlineIcon(c,kind,tint)' in h
assert 'outlineIconAction(this,"voice"' in home
assert 'outlineIconAction(this,"search"' in home
assert 'outlineIconAction(this,"settings"' in home
assert 'UiKit.bottomNav(this,0' in home and 'attachHomeContent(screen,sc,bottom,bp)' in home
assert 'void confirmStopTimer()' in home and 'SilentTimerService.ACTION_START' in home
assert 'FrameLayout outlineIconAction(' in ui and 'touch.setMinimumHeight(dp(c,48))' in ui
for kind in ('voice','shopping','todo'):
    assert 'case "'+kind+'":' in art
assert 'assertTrue(compact.getMinimumHeight()>=UiKit.dp(c,80))' in (root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'build224_dailyEntryAndHomeUseCompactAccessiblePictograms' in (root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
for src in j.glob('*.java'):
    data=src.read_text(encoding='utf8')
    vars=re.findall(r'LinearLayout\s+(\w+)\s*=.*?;',data)
    for v in vars:
        assert not re.search(rf'\b{v}\.setMinHeight\(',data),(src.name,v)
print('PASS build224: semantic pictograms, grouped quick entry, accessible home, full routes and safe APIs')
