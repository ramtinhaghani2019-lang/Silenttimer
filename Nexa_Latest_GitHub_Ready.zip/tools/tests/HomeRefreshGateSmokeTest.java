package com.example.silenttimer;

public final class HomeRefreshGateSmokeTest {
    public static void main(String[] args) {
        long now=1_700_000_000_000L;
        int checks=0;
        for(long interval : new long[]{HomeRefreshGate.OVERVIEW_MS,HomeRefreshGate.FINANCE_MS}){
            test(HomeRefreshGate.due(now,0,interval));checks++;
            test(!HomeRefreshGate.due(now+1,now,interval));checks++;
            test(!HomeRefreshGate.due(now+interval-1,now,interval));checks++;
            test(HomeRefreshGate.due(now+interval,now,interval));checks++;
            test(HomeRefreshGate.due(now-1,now,interval));checks++;
        }
        try{HomeRefreshGate.due(now,now,0);throw new AssertionError("Expected exception");}
        catch(IllegalArgumentException expected){checks++;}
        System.out.println("PASS: "+checks+" HomeRefreshGate JVM checks");
    }
    private static void test(boolean good){if(!good)throw new AssertionError("Refresh gate regression");}
}
