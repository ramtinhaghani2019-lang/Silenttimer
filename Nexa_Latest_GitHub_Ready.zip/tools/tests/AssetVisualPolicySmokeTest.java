package com.example.silenttimer;
public final class AssetVisualPolicySmokeTest {
    private static void check(boolean ok){if(!ok)throw new AssertionError("Asset visual policy contract");}
    public static void main(String[] args){
        check("usd".equals(AssetVisualPolicy.iconFor("دلار")));
        check("eur".equals(AssetVisualPolicy.iconFor("یورو")));
        check("ounce".equals(AssetVisualPolicy.iconFor("اونس جهانی (USD)")));
        check("gold".equals(AssetVisualPolicy.iconFor("طلای ۱۸ عیار")));
        check("coin".equals(AssetVisualPolicy.iconFor("سکه امامی")));
        check("assets".equals(AssetVisualPolicy.iconFor("صندوق کاریزما")));
        check("assets".equals(AssetVisualPolicy.iconFor(null)));
        check("۱٬۲۳۴٬۵۶۷٫۸۹".equals(PersianFinancialDisplay.amount2(1234567.891d)));
        check("۱۰".equals(PersianFinancialDisplay.amount2(10.0d)));
        check("۰".equals(PersianFinancialDisplay.amount2(-0.0d)));
        check("—".equals(PersianFinancialDisplay.amount2(Double.NaN)));
        System.out.println("PASS: 11 semantic asset icons and 2-decimal display assertions");
    }
}
