package com.example.silenttimer;
/** Independent row OCR reconciliation tests; intentionally no Android SDK dependency. */
public final class AssetReceiptFieldFusionSmokeTest {
    private static int checks;
    static void check(boolean value){ checks++;if(!value)throw new AssertionError("test "+checks); }
    static AssetReceiptParser.Result date(){
        AssetReceiptParser.Result r=new AssetReceiptParser.Result();
        r.assetType="صندوق نقره کاریزما";r.hasDate=true;
        r.jalaliYear=1405;r.jalaliMonth=8;r.jalaliDay=5;
        return r;
    }
    static AssetReceiptFieldFusion.Candidates example(){
        AssetReceiptFieldFusion.Candidates c=new AssetReceiptFieldFusion.Candidates();
        c.add("amount","۱,۰۰۰,۰۰۰,۰۰۰ ریال");
        c.add("gross","۲۰۸/۲۵۵۹۳۸۹ گرم");
        c.add("price","۴,۸۰۱,۷۸۴ ریال");
        c.add("cashFee","۵,۰۰۰,۰۰۰ ریال");
        c.add("gramFee","۱/۰۴۱۲۷۹۷ گرم");
        return c;
    }
    public static void main(String[] args){
        AssetReceiptParser.Result r=AssetReceiptFieldFusion.fuse(date(),example());
        check(AssetReceiptParser.verifiedForAutomaticImport(r));
        check("207.2146592".equals(r.netQuantity));
        check("1000000000".equals(r.amountRial));
        check("4801784".equals(r.unitPriceRial));
        AssetReceiptFieldFusion.Candidates multiple=example();
        multiple.price.add(0,"4852684");
        multiple.gross.add(0,"9");
        AssetReceiptParser.Result recovered=AssetReceiptFieldFusion.fuse(date(),multiple);
        check(AssetReceiptParser.verifiedForAutomaticImport(recovered));
        check("4801784".equals(recovered.unitPriceRial));
        AssetReceiptFieldFusion.Candidates wrong=example();
        wrong.price.clear();wrong.price.add("4852684");
        check(!AssetReceiptParser.verifiedForAutomaticImport(AssetReceiptFieldFusion.fuse(date(),wrong)));
        AssetReceiptFieldFusion.Candidates subtotal=example();
        subtotal.gross.clear();subtotal.gross.add("221.56754");
        check(!AssetReceiptParser.verifiedForAutomaticImport(AssetReceiptFieldFusion.fuse(date(),subtotal)));
        check(!AssetReceiptParser.verifiedForAutomaticImport(AssetReceiptFieldFusion.fuse(new AssetReceiptParser.Result(),example())));
        AssetReceiptFieldFusion.Candidates missing=example();missing.gramFee.clear();
        check(!AssetReceiptParser.verifiedForAutomaticImport(AssetReceiptFieldFusion.fuse(date(),missing)));
        AssetReceiptFieldFusion.Candidates seventy=new AssetReceiptFieldFusion.Candidates();
        seventy.add("amount","۷۰٬۰۰۰٬۰۰۰ ریال");
        seventy.add("gross","۱۴/۴۲۵۰۰۶ گرم");
        seventy.add("price","۴,۸۵۲,۶۸۴ ریال");
        seventy.add("cashFee","۳۵۰,۰۰۰ ریال");
        seventy.add("gramFee","۰/۰۷۲۱۲۵ گرم");
        AssetReceiptParser.Result smaller=AssetReceiptFieldFusion.fuse(date(),seventy);
        check(AssetReceiptParser.verifiedForAutomaticImport(smaller));
        check("14.352881".equals(smaller.netQuantity));
        check("1000000000".equals(AssetReceiptParser.numericCandidate("1,e00,000,000 ریال","amount")));
        System.out.println("PASS: "+checks+" OCR row-reconciliation checks");
    }
}
