package com.example.silenttimer;
/** Pure-Java safeguards for partial OCR, including both real Karizma examples. */
public final class AssetReceiptImportPlanSmokeTest {
 private static int n;
 static void ok(boolean yes){n++;if(!yes)throw new AssertionError("receipt plan check #"+n);}
 static AssetReceiptParser.Result oneBillion(){
  AssetReceiptParser.Result r=new AssetReceiptParser.Result();
  r.assetType="صندوق نقره کاریزما";r.hasDate=true;r.jalaliYear=1405;r.jalaliMonth=8;r.jalaliDay=5;
  r.amountRial="1000000000";r.unitPriceRial="4801784";r.cashFeeRial="5000000";
  r.grossQuantity="208.2559389";r.gramFee="1.0412797";r.netQuantity="207.2146592";return r;
 }
 public static void main(String[] args){
  AssetReceiptParser.Result r=oneBillion();
  AssetReceiptImportPlan.Decision d=AssetReceiptImportPlan.evaluate(r,"صندوق نقره کاریزما");
  ok(d.complete);ok(d.verifiedNumericFields==4);ok("207.2146592".equals(d.trusted.netQuantity));
  // Missing date must not discard valid numbers; date remains user responsibility.
  r.hasDate=false;d=AssetReceiptImportPlan.evaluate(r,"صندوق نقره کاریزما");
  ok(!d.complete);ok(d.verifiedNumericFields==4);ok(!d.trusted.hasDate);
  // Missing cash fee: the other cross-confirmed fields can still populate safely.
  r=oneBillion();r.cashFeeRial="";
  d=AssetReceiptImportPlan.evaluate(r,r.assetType);
  ok(!d.complete);ok("1000000000".equals(d.trusted.amountRial));
  ok("207.2146592".equals(d.trusted.netQuantity));ok(d.trusted.cashFeeRial.isEmpty());
  // Unrelated rate from prior receipt MUST NOT generate even one trusted financial value.
  r=oneBillion();r.unitPriceRial="4852684";
  d=AssetReceiptImportPlan.evaluate(r,r.assetType);
  ok(d.verifiedNumericFields==0);ok(d.trusted.netQuantity.isEmpty());
  // Portfolio balance is not a purchase quantity; no amount or quantity is accepted.
  r=oneBillion();r.grossQuantity="221.56754";r.netQuantity="221.56754";
  d=AssetReceiptImportPlan.evaluate(r,r.assetType);
  ok(d.verifiedNumericFields==0);ok(d.trusted.amountRial.isEmpty());
  // Wrong asset selected: never silently import another product's values.
  r=oneBillion();d=AssetReceiptImportPlan.evaluate(r,"دلار");
  ok(d.verifiedNumericFields==0);ok(d.trusted.amountRial.isEmpty());
  r=oneBillion();r.assetType="";d=AssetReceiptImportPlan.evaluate(r,"صندوق نقره کاریزما");
  ok(d.verifiedNumericFields==4);ok("صندوق نقره کاریزما".equals(d.trusted.assetType));
  // A shorter real receipt uses its own cost / rate / gram fee.
  r=oneBillion();r.amountRial="70000000";r.unitPriceRial="4852684";
  r.grossQuantity="14.425006";r.cashFeeRial="350000";r.gramFee="0.072125";r.netQuantity="14.352881";
  d=AssetReceiptImportPlan.evaluate(r,r.assetType);
  ok(d.complete);ok("14.352881".equals(d.trusted.netQuantity));
  // Fee OCR wrong: never pass through the suspect fee as valid.
  r=oneBillion();r.cashFeeRial="9000000";
  d=AssetReceiptImportPlan.evaluate(r,r.assetType);
  ok(!d.complete);ok(d.trusted.cashFeeRial.isEmpty());
  System.out.println("PASS "+n+" import-plan financial safety checks");
 }
}
