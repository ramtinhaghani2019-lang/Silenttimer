package com.example.silenttimer;
import java.util.Arrays;

/** Run: javac -d /tmp/nexa-forecast-check app/src/main/java/com/example/silenttimer/PersianDateUtil.java app/src/main/java/com/example/silenttimer/BillForecast.java tools/tests/BillForecastSmokeTest.java
 *       java -ea -cp /tmp/nexa-forecast-check com.example.silenttimer.BillForecastSmokeTest */
public class BillForecastSmokeTest {
    private static int checks=0;
    private static void check(boolean good,String why){checks++;if(!good)throw new AssertionError(why);}
    public static void main(String[] args){
        long now=PersianDateUtil.toMillis(1405,7,1,10,0);
        long threeDays=BillForecast.horizon(now,3);
        BillForecast.Entry future=new BillForecast.Entry("f","قسط","قسط",100,threeDays,"یک‌بار",false);
        BillForecast.Entry past=new BillForecast.Entry("p","قبض","قبض",200,now-1000,"یک‌بار",false);
        BillForecast.Entry paid=new BillForecast.Entry("x","پرداخت‌شده","قبض",500,threeDays,"یک‌بار",true);
        BillForecast.Result r=BillForecast.calculate(Arrays.asList(future,past,paid),now,30);
        check(r.upcoming.size()==1,"one future");
        check(r.overdue.size()==1,"one overdue");
        check(r.upcomingTotal==100,"future amount");
        check(r.overdueTotal==200,"past amount");
        check(!r.upcoming.get(0).projected,"one-off is not projected");
        check(r.upcoming.get(0).at==threeDays,"future timestamp");
        check(r.upcoming.get(0).title.equals("قسط"),"title maintained");
        check(BillForecast.sumBefore(r.upcoming,threeDays)==0,"exclusive window cutoff");
        check(BillForecast.sumBefore(r.upcoming,threeDays+1)==100,"inclusive now cutoff");

        long before=PersianDateUtil.toMillis(1405,6,30,10,0);
        BillForecast.Entry m=new BillForecast.Entry("m","اجاره","اجاره",150,
            PersianDateUtil.toMillis(1405,6,31,10,0),"ماهانه",false);
        BillForecast.Entry y=new BillForecast.Entry("y","بیمه","بیمه",90,
            PersianDateUtil.toMillis(1405,7,2,10,0),"سالانه",false);
        BillForecast.Result forecast=BillForecast.calculate(Arrays.asList(m,y),before,90);
        int monthly=0,annual=0;
        for(BillForecast.Occurrence o:forecast.upcoming){
            check(o.at>=before,"not past");
            check(o.at<BillForecast.horizon(before,90),"within horizon");
            if(o.id.equals("m")){
                monthly++;
                check(o.projected==(monthly>1),"monthly projection flag");
                check(PersianDateUtil.fromMillis(o.at)[2]==(monthly==1?31:30),"jalali day clipping");
            } else if(o.id.equals("y")){
                annual++;
                check(!o.projected,"first yearly not projected");
                check(PersianDateUtil.fromMillis(o.at)[2]==2,"jalali annual day");
            }
        }
        check(monthly>=2,"monthly repetition exists");
        check(annual==1,"yearly repetition exists");
        check(forecast.overdue.isEmpty(),"no overdue");
        BillForecast.Result pastRepeat=BillForecast.calculate(Arrays.asList(
            new BillForecast.Entry("old","ماهانه معوق","",400,now-2000,"ماهانه",false)),now,90);
        check(pastRepeat.overdue.size()==1,"old recurring overdue");
        check(pastRepeat.upcoming.isEmpty(),"no invented obligations until overdue settled");
        check(forecast.upcoming.get(0).at<=forecast.upcoming.get(forecast.upcoming.size()-1).at,"sorted");

        BillForecast.Result overflow=BillForecast.calculate(Arrays.asList(
            new BillForecast.Entry("a","a","",Long.MAX_VALUE,now,"یک‌بار",false),
            new BillForecast.Entry("b","b","",Long.MAX_VALUE,now+1000,"یک‌بار",false),
            new BillForecast.Entry("c","c","",-55,now+2000,"یک‌بار",false),
            new BillForecast.Entry("d","d","",100,BillForecast.horizon(now,30),"یک‌بار",false)
        ),now,30);
        check(overflow.upcomingTotal==Long.MAX_VALUE,"no overflow");
        check(overflow.upcoming.size()==3,"boundary not included");
        check(overflow.upcoming.get(2).amount==0,"negative amount sanitized");
        check(BillForecast.calculate(null,now,30).upcoming.isEmpty(),"null list");
        check(BillForecast.calculate(Arrays.asList((BillForecast.Entry)null),now,30).overdue.isEmpty(),"null entry");
        try { BillForecast.calculate(null,now,0); throw new AssertionError("days 0 accepted"); }
        catch(IllegalArgumentException ok){checks++;}
        try { overflow.upcoming.clear(); throw new AssertionError("mutable list"); }
        catch(UnsupportedOperationException ok){checks++;}
        System.out.println("PASS BillForecast local JVM checks: "+checks);
    }
}
