package com.example.silenttimer;

public final class SearchQueryPolicySmokeTest {
    private static int assertions=0;
    private static void ok(boolean v,String why){assertions++;if(!v)throw new AssertionError(why);}
    public static void main(String[] args){
        ok("حسین رضایی".equals(SearchQueryPolicy.normalize("حسين\u200cرضايي")),"normalize Arabic letters + joiner");
        ok("قسط 123".equals(SearchQueryPolicy.normalize("قسط ۱۲٣")),"mixed digits");
        ok("احمدی".equals(SearchQueryPolicy.normalize("اَحمدي")),"diacritics");
        ok(SearchQueryPolicy.matches("احمدی 09123456789 تسویه سفارش","۰۹۱۲۳۴۵۶۷۸۹"),"phone Persian numerals");
        ok(SearchQueryPolicy.matches("احمدی قسط شهریور","شهریور احمدی"),"unordered words across fields");
        ok(SearchQueryPolicy.matches("حسين رضايي","حسین رضایی"),"Arabic+Persian normalization");
        ok(SearchQueryPolicy.matches("نکسا - پرونده 1405/07","پرونده ۱۴۰۵"),"punctuation");
        ok(!SearchQueryPolicy.matches("فاطمه رضایی","احمدی"),"no false positive");
        ok(!SearchQueryPolicy.matches("احمدی","    "),"blank query");
        ok(!SearchQueryPolicy.matches(null,"احمدی"),"null content");
        ok(SearchQueryPolicy.score("احمدی","احمدی")==4,"exact score");
        ok(SearchQueryPolicy.score("احمدی رضا","احمدی")==3,"prefix score");
        ok(SearchQueryPolicy.score("دفتر احمدی","احمدی")==2,"contains score");
        ok(SearchQueryPolicy.score("احمدی قسط شهریور","شهریور احمدی")==1,"unordered score");
        ok(SearchQueryPolicy.score("حسینی","احمدی")==0,"no match score");
        ok(SearchDisplayPolicy.matches(SearchDisplayPolicy.FINANCE,SearchDisplayPolicy.FINANCE),"finance filter");
        System.out.println("PASS Build206 universal search: "+assertions+" checks");
    }
}
