package com.example.silenttimer;
public final class BillFormRulesSmokeTest {
    public static void main(String[] args){
        if(BillFormRules.validAmount(0)||BillFormRules.validAmount(-1))throw new AssertionError("zero/negative amount accepted");
        if(!BillFormRules.validAmount(1)||!BillFormRules.validAmount(2700000))throw new AssertionError("positive amount rejected");
        System.out.println("PASS: payment amount validation");
    }
}
