package com.example.silenttimer;
public final class TimerExpiryPolicySmokeTest {
    public static void main(String[] args) {
        long[][] cases={{0,1000},{-1,1000},{1501,0},{1500,1},{1500,1500},{1500,3500}};
        boolean[] expected={false,false,false,true,true,true};
        for(int i=0;i<cases.length;i++)if(TimerExpiryPolicy.isDue(cases[i][0],cases[i][1])!=expected[i])
            throw new AssertionError("Expiry case "+i);
        if(TimerExpiryPolicy.mayClearSession(true,false)) throw new AssertionError("Do not clear failed restore");
        if(!TimerExpiryPolicy.mayClearSession(true,true)) throw new AssertionError("Successful restore may clear");
        if(!TimerExpiryPolicy.mayClearSession(false,false)) throw new AssertionError("Explicit no-restore stop may clear");
        System.out.println("PASS timer expiry and restore safety policy (9 cases)");
    }
}
