package com.example.silenttimer;
public final class SettingsDirectorySmokeTest {
  public static void main(String[] args) {
    assertTrue(SettingsDirectory.matches("🎵 انتخاب صدای هشدارها","باتری"));
    assertTrue(SettingsDirectory.matches("🔕 تشخیص خودکار Silent / Vibrate","سايلنت"));
    assertTrue(SettingsDirectory.matches("🛡 امنیت و پشتیبان‌گیری","بکاپ"));
    assertTrue(SettingsDirectory.matches("📋 وضعیت دسترسی‌ها","مجوز"));
    assertTrue(SettingsDirectory.matches("📱 سازگاری این دستگاه","سامسونگ"));
    assertTrue(!SettingsDirectory.matches("ℹ درباره Nexa","تعمیر خودرو"));
    assertTrue(SettingsDirectory.matches("📩 کد اضطراری پیامکی","sms"));
    System.out.println("PASS settings directory search");
  }
  private static void assertTrue(boolean ok) { if (!ok) throw new AssertionError(); }
}
