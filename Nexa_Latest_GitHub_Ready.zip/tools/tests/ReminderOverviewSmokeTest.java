package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.TimeZone;

/** Build 216: metric labels, counts and recurring due previews stay consistent. */
public final class ReminderOverviewSmokeTest {
    private static int checks;
    private static void ok(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    public static void main(String[] args){
        TimeZone old=TimeZone.getDefault();
        try{
            TimeZone.setDefault(TimeZone.getTimeZone("Europe/London"));
            Calendar cal=Calendar.getInstance();cal.set(2026,Calendar.NOVEMBER,2,8,0,0);
            cal.set(Calendar.MILLISECOND,0);
            long now=cal.getTimeInMillis();
            long day=AgendaDuePolicy.startOfDay(now);
            NexaStore.Reminder repeating=new NexaStore.Reminder();
            repeating.active=true;repeating.recurrence="daily";
            repeating.whenMillis=AgendaDuePolicy.afterCalendarDays(day,-80)+9L*3600_000L;
            NexaStore.Reminder missed=new NexaStore.Reminder();missed.active=true;missed.whenMillis=now-30_000L;
            NexaStore.Reminder stopped=new NexaStore.Reminder();stopped.active=false;stopped.whenMillis=now-1L;
            NexaStore.Reminder done=new NexaStore.Reminder();done.done=true;done.whenMillis=now-1L;
            ReminderOverviewPolicy.Counts c=ReminderOverviewPolicy.count(
                    Arrays.asList(repeating,missed,stopped,done,null),now);
            ok(c.pending==1,"recurrence counted at current date");
            ok(c.overdue==1,"missed one-time overdue");
            ok(c.paused==1,"paused counted separately");
            ok(c.completed==1,"completed counted separately");
            ok(ReminderOverviewPolicy.toggleLabel(c,false).contains("مشاهده آمار"),"collapsed label");
            ok(ReminderOverviewPolicy.toggleLabel(c,true).contains("بستن آمار"),"expanded label");
            ok(ReminderOverviewPolicy.toggleDescription(c,false).contains("1 متوقف"),"accessible paused count");
            ok(ReminderOverviewPolicy.toggleDescription(c,true).contains("1 انجام‌شده"),"accessible complete count");
            ReminderOverviewPolicy.Counts empty=ReminderOverviewPolicy.count(null,now);
            ok(empty.pending==0&&empty.overdue==0&&empty.paused==0&&empty.completed==0,"null safe");
            ok(ReminderOverviewPolicy.count(new ArrayList<NexaStore.Reminder>(),now).pending==0,"empty safe");
            ok(ReminderOverviewPolicy.toggleLabel(null,false).contains("0 در انتظار"),"null count label safe");
            ok(ReminderOverviewPolicy.toggleDescription(null,true).contains("0 معوق"),"null count description safe");
            ok(ReminderOrganizer.visible(stopped,"paused",now),"paused filter retained");
            ok(ReminderOrganizer.visible(done,"done",now),"done filter retained");
            ok(!ReminderOrganizer.visible(repeating,"overdue",now),"recurrence not mislabelled");
            ok(ReminderOrganizer.visible(repeating,"pending",now),"recurrence active");
            long later=day+10L*3600_000L;
            c=ReminderOverviewPolicy.count(Arrays.asList(repeating,missed),later);
            ok(c.overdue==2,"once passed today recurring is overdue");
            ok(c.pending==0,"no future due after 10am");
            System.out.println("PASS ReminderOverview: "+checks+" assertions");
        }finally{TimeZone.setDefault(old);}
    }
}
