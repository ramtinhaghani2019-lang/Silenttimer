package com.example.silenttimer;

import java.util.Arrays;
import java.util.List;

/** Pure JVM regression tests: filtering must not alter money or chronological running balances. */
public final class LedgerHistoryFilterSmokeTest {
    private static int checks;
    private static void check(boolean cond,String why){checks++;if(!cond)throw new AssertionError(why);}

    public static void main(String[] args) {
        NexaStore.LedgerParty party=new NexaStore.LedgerParty();
        party.id="p";party.name="کريمی";
        NexaStore.LedgerEntry debt=entry("a",10,"DEBT",2_000_000L,"اجاره");
        NexaStore.LedgerEntry payment=entry("b",20,"PAYMENT",500_000L,"قسط بانك");
        NexaStore.LedgerEntry receipt=entry("c",30,"RECEIPT",100_000L,"دريافت پول");
        NexaStore.LedgerEntry credit=entry("d",40,"CREDIT",600_000L,"بدهکار من");
        // Report generation sorts a copy. The source order and values must not change.
        List<NexaStore.LedgerEntry> unsorted=Arrays.asList(receipt,credit,debt,payment);
        LedgerReport.Result result=LedgerReport.generate(Arrays.asList(party),unsorted,"p",Long.MIN_VALUE,Long.MAX_VALUE);
        check(result.rows.size()==4,"four historical entries");
        check(result.rows.get(0).runningBalance==-2_000_000L,"initial debt");
        check(result.rows.get(1).runningBalance==-1_500_000L,"payment running balance");
        check(result.rows.get(2).runningBalance==-1_600_000L,"receipt running balance");
        check(result.rows.get(3).runningBalance==-1_000_000L,"credit running balance");
        String[] kinds={"DEBT","CREDIT","PAYMENT","RECEIPT"};
        String[] ids={"a","d","b","c"};
        for(int i=0;i<kinds.length;i++){
            List<LedgerReport.Row> filtered=LedgerHistoryFilter.select(result.rows,kinds[i],"");
            check(filtered.size()==1,"kind match "+kinds[i]);
            check(filtered.get(0).entry.id.equals(ids[i]),"matching transaction " + kinds[i]);
        }
        check(LedgerHistoryFilter.select(result.rows,"PAYMENT","۵۰۰٬۰۰۰").size()==1,"Persian amount");
        check(LedgerHistoryFilter.select(result.rows,"PAYMENT","500,000").size()==1,"Latin grouped amount");
        check(LedgerHistoryFilter.select(result.rows,"ALL","بانک").get(0).entry==payment,"Arabic Kaf in note");
        check(LedgerHistoryFilter.select(result.rows,"ALL","دریافت").get(0).entry==receipt,"Arabic Yeh in note");
        check(LedgerHistoryFilter.select(result.rows,"ALL","کريمی").size()==4,"party name spelling variants");
        check(LedgerHistoryFilter.select(result.rows,"CREDIT","قسط").isEmpty(),"query and kind both enforced");
        check(LedgerHistoryFilter.select(result.rows,"OTHER","").isEmpty(),"unknown kind does not return data");
        check(LedgerHistoryFilter.select(result.rows,"ALL","پیدا نمی‌شود").isEmpty(),"missing note");
        check(LedgerHistoryFilter.select(null,"ALL",null).isEmpty(),"null list");
        check(!LedgerHistoryFilter.matches(null,"ALL",null),"null row");
        check(LedgerHistoryFilter.normalize("٢٥٠٬٠٠٠").equals("250000"),"Arabic numeric normalized");
        check(LedgerHistoryFilter.normalize("۵۰۰٬۰۰۰").equals("500000"),"Persian numeric normalized");
        check(LedgerHistoryFilter.normalize("  پَرْداخت  ").contains("داخت"),"trim and Unicode safe");
        // Even a scrambled/filtered source must sort by the REAL date, not insertion order.
        java.util.List<LedgerReport.Row> scrambled=Arrays.asList(result.rows.get(2),result.rows.get(0),result.rows.get(3),result.rows.get(1));
        List<LedgerReport.Row> newest=LedgerReport.orderedRows(scrambled,true);
        List<LedgerReport.Row> oldest=LedgerReport.orderedRows(scrambled,false);
        check(newest.get(0).entry==credit && newest.get(3).entry==debt,"date order newest first");
        check(oldest.get(0).entry==debt && oldest.get(3).entry==credit,"date order oldest first");
        check(scrambled.get(0).entry==receipt,"input order preserved");
        check(newest.get(2).runningBalance==-1_500_000L,"historical balance unchanged in newest order");
        check(LedgerReport.orderedRows(LedgerHistoryFilter.select(scrambled,"PAYMENT",""),true).get(0).entry==payment,"payment date sorted");
        check(LedgerReport.orderedRows(LedgerHistoryFilter.select(scrambled,"CREDIT",""),true).get(0).entry==credit,"credit date sorted");
        check(LedgerReport.orderedRows(LedgerHistoryFilter.select(scrambled,"DEBT",""),true).get(0).entry==debt,"debt date sorted");
        check(LedgerReport.orderedRows(LedgerHistoryFilter.select(scrambled,"RECEIPT",""),true).get(0).entry==receipt,"receipt date sorted");
        check(LedgerReport.orderedRows(null,true).isEmpty(),"null history");
        NexaStore.LedgerEntry tieA=entry("idA",10,"DEBT",1L,"");
        NexaStore.LedgerEntry tieB=entry("idB",10,"CREDIT",1L,"");
        LedgerReport.Result ties=LedgerReport.generate(Arrays.asList(party),Arrays.asList(tieB,tieA),"p",Long.MIN_VALUE,Long.MAX_VALUE);
        check(LedgerReport.orderedRows(ties.rows,false).get(0).entry==tieA,"stable equal date oldest");
        check(LedgerReport.orderedRows(ties.rows,true).get(0).entry==tieB,"stable equal date newest");
        check(result.closingNet==-1_000_000L,"net balance unchanged");
        check(unsorted.get(0)==receipt,"source list unchanged");
        check(LedgerHistoryFilter.select(result.rows,"ALL","").get(1).runningBalance==-1_500_000L,"all filter keeps original running balance");
        check(LedgerHistoryFilter.select(result.rows,"PAYMENT","").get(0).runningBalance==-1_500_000L,"filtered running balance not recalculated");
        System.out.println("PASS LedgerHistoryFilterSmokeTest: "+checks+" checks");
    }
    private static NexaStore.LedgerEntry entry(String id,long date,String kind,long amount,String note) {
        NexaStore.LedgerEntry e=new NexaStore.LedgerEntry();
        e.id=id;e.partyId="p";e.dateMillis=date;e.kind=kind;e.amount=amount;e.note=note;
        return e;
    }
}
