package com.example.silenttimer;
public final class DashboardAttentionSummarySmokeTest {
  private static void ok(boolean value){if(!value)throw new AssertionError("compact dashboard summary");}
  public static void main(String[] args){
    ok("موردی نیازمند توجه نیست".equals(DashboardAttentionSummary.compact(0,0,0,0,0)));
    ok("۱ سرویس خانه".equals(DashboardAttentionSummary.compact(0,0,0,1,0)));
    String multi=DashboardAttentionSummary.compact(2,0,1,0,4);
    ok(multi.contains("۲ یادآور معوق") && multi.contains("۱ مدرک رو به انقضا") && multi.contains("۴ کار عقب‌افتاده"));
    ok(!multi.contains("پرداخت معوق")&&!multi.contains("سرویس خانه"));
    ok(!DashboardAttentionSummary.compact(0,-1,0,0,0).contains("پرداخت معوق"));
    ok(DashboardAttentionSummary.compact(19,0,0,0,0).startsWith("۱۹"));
    System.out.println("PASS DashboardAttentionSummarySmokeTest 6");
  }
}
