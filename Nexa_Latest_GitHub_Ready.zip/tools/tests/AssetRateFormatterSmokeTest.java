package com.example.silenttimer;
public final class AssetRateFormatterSmokeTest {
    private static void yes(boolean v){if(!v)throw new AssertionError("AssetRateFormatter contract failed");}
    public static void main(String[] args){
        yes("—".equals(AssetRateFormatter.display(0)));
        yes("—".equals(AssetRateFormatter.display(-20)));
        yes("—".equals(AssetRateFormatter.display(Double.NaN)));
        yes("—".equals(AssetRateFormatter.display(Double.POSITIVE_INFINITY)));
        yes("۲٬۶۶۹٬۰۰۰".equals(AssetRateFormatter.display(2669000d)));
        yes("۴٬۰۷۰٫۴۱".equals(AssetRateFormatter.display(4070.41d)));
        yes("به‌روز".equals(AssetRateFormatter.freshness(60000L)));
        yes("نیازمند تازه‌سازی".equals(AssetRateFormatter.freshness(3600000L)));
        yes("داده قدیمی".equals(AssetRateFormatter.freshness(90000000L)));
        System.out.println("PASS: 9 market rate formatting and freshness cases");
    }
}
