package com.example.silenttimer;

/** Local no-Android checks for transaction labels, colors and amount normalization. */
public final class LedgerPresentationSmokeTest {
    private static int tests=0;
    private static void check(boolean test,String why){tests++;if(!test)throw new AssertionError(why);}
    public static void main(String[] args){
        String[] expected={"DEBT","CREDIT","PAYMENT","RECEIPT"};
        int[] colors={0xFFFF646A,0xFFF5CD58,0xFF4DD998,0xFFC199FC};
        String[] labels={"بدهی جدید","طلب جدید","پرداخت کردم","دریافت کردم"};
        for(int i=0;i<expected.length;i++){
            String type=expected[i];
            check(type.equals(LedgerPresentation.KINDS[i]),"kind stable at "+i);
            check(colors[i]==LedgerPresentation.color(type),"color for "+type);
            check(labels[i].equals(LedgerPresentation.label(type)),"label for "+type);
            check(!LedgerPresentation.shortLabel(type).isEmpty(),"short label");
            check(!LedgerPresentation.help(type).isEmpty(),"explanation");
            for(int j=0;j<i;j++)check(colors[i]!=colors[j],"color independent");
        }
        check(LedgerPresentation.color("OTHER")==0xFFB8B8B0,"unknown color neutral");
        check(LedgerPresentation.label("OTHER").contains("نامشخص"),"unknown kind is visible");
        check("۱٬۲۳۴٬۵۶۷".equals(LedgerPresentation.persian("1,234,567")),"Persian digits and separator");
        check("۰۱۲۳۴۵۶۷۸۹".equals(LedgerPresentation.persian("0123456789")),"Persian digits");
        check("۱۲۳".equals(LedgerPresentation.persian("١٢٣")),"Arabic digits");
        check("".equals(LedgerPresentation.persian(null)),"null UI content");
        String[] valid={"1234567","۱٬۲۳۴٬۵۶۷","١,٢٣٤,٥٦٧","1 234 567"};
        for(String value:valid)check(LedgerPresentation.positiveAmount(value)==1234567L,"amount "+value);
        String[] invalid={"","۰","-100","+۱۰۰","۲٫۵","12x","999999999999999999999"};
        for(String value:invalid)check(LedgerPresentation.positiveAmount(value)==0L,"invalid "+value);
        check(LedgerPresentation.positiveAmount(null)==0,"null amount");
        check(LedgerPresentation.positiveAmount("۹٬۲۲۳٬۳۷۲٬۰۳۶٬۸۵۴٬۷۷۵٬۸۰۷")==Long.MAX_VALUE,"max long");
        System.out.println("PASS LedgerPresentationSmokeTest: "+tests+" checks");
    }
}
