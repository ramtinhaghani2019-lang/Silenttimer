package com.example.silenttimer;
import java.util.*;

/** Runnable without Android; verifies date-aware search, filters and sorting. */
public final class OccasionDirectoryPolicySmokeTest {
    private static int assertions=0;
    static void check(boolean ok,String message){assertions++;if(!ok)throw new AssertionError(message);}
    static OccasionStore.Occasion event(String title,String type,int month,int day,boolean active){
        OccasionStore.Occasion e=new OccasionStore.Occasion();
        e.title=title;e.type=type;e.calendar="gregorian";e.year=2020;e.month=month;e.day=day;
        e.hour=9;e.minute=0;e.active=active;return e;
    }
    static long date(int y,int m,int d){Calendar c=Calendar.getInstance();c.clear();c.set(y,m-1,d,0,0,0);return c.getTimeInMillis();}
    public static void main(String[] args){
        long now=date(2026,11,2);
        OccasionStore.Occasion b=event("تولد حسین","birthday",11,4,true);
        OccasionStore.Occasion m=event("سالگرد ازدواج","marriage",11,6,true);
        OccasionStore.Occasion p=event("یادبود علی","memorial",11,8,false);
        OccasionStore.Occasion other=event("مراسم شخصی","personal",12,5,true);
        List<OccasionStore.Occasion> items=Arrays.asList(p,other,m,b);
        check(OccasionDirectoryPolicy.select(items,"","all",now).size()==4,"all");
        check(OccasionDirectoryPolicy.select(items,"","all",now).get(0)==b,"next first");
        check(OccasionDirectoryPolicy.select(items,"","all",now).get(1)==m,"second");
        check(OccasionDirectoryPolicy.select(items,"","all",now).get(3)==p,"paused last");
        check(OccasionDirectoryPolicy.select(items,"","soon",now).size()==2,"30-day active");
        check(OccasionDirectoryPolicy.select(items,"","soon",now).get(0)==b,"soon sort");
        check(OccasionDirectoryPolicy.select(items,"","birthday",now).size()==1,"birthday");
        check(OccasionDirectoryPolicy.select(items,"","marriage",now).get(0)==m,"marriage");
        check(OccasionDirectoryPolicy.select(items,"","memorial",now).get(0)==p,"memorial");
        check(OccasionDirectoryPolicy.select(items,"","personal",now).get(0)==other,"personal");
        check(OccasionDirectoryPolicy.select(items,"","paused",now).size()==1,"paused count");
        check(OccasionDirectoryPolicy.select(items,"","paused",now).get(0)==p,"paused identity");
        check(OccasionDirectoryPolicy.select(items,"حسين","all",now).get(0)==b,"Arabic ye");
        check(OccasionDirectoryPolicy.select(items,"تولد حسين","all",now).size()==1,"multi-word Arabic");
        check(OccasionDirectoryPolicy.select(items,"ازدواج","all",now).get(0)==m,"type label search");
        check(OccasionDirectoryPolicy.select(items,"xyz","all",now).isEmpty(),"search missing");
        check(OccasionDirectoryPolicy.select(items,"تولد","marriage",now).isEmpty(),"filter and query");
        check(OccasionDirectoryPolicy.select(items,"",null,now).size()==4,"null filter");
        check(OccasionDirectoryPolicy.select(null,"","all",now).isEmpty(),"null input");
        check(!OccasionDirectoryPolicy.matches(null,"","all",now),"null event");
        check(OccasionDirectoryPolicy.matches(p,"","paused",now),"paused matching");
        check(!OccasionDirectoryPolicy.matches(p,"","soon",now),"paused not upcoming");
        check(OccasionDirectoryPolicy.afterDays(now,30)>now,"calendar days future");
        check(OccasionDirectoryPolicy.afterDays(now,30)<date(2026,12,5),"30 days excludes Dec 5");
        check(OccasionDirectoryPolicy.select(items,"۲۰۲۰","all",now).size()==4,"Persian year digits search");
        OccasionStore.Occasion leap=event("سال کبیسه","birthday",2,29,true);leap.year=2020;
        check(OccasionDirectoryPolicy.select(Collections.singletonList(leap),"","soon",date(2027,2,26)).size()==1,"Feb 29 fallback within range");
        check(OccasionDirectoryPolicy.select(Collections.singletonList(leap),"","soon",date(2028,2,26)).size()==1,"Feb 29 restored leap year");
        System.out.println("PASS: "+assertions+" OccasionDirectoryPolicy assertions");
    }
}
