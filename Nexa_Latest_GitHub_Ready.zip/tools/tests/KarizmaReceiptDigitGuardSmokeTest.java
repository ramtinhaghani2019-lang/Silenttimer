package com.example.silenttimer;
import java.io.FileInputStream;
/** No-private-data sanity checks; real receipt images are never committed to source. */
public final class KarizmaReceiptDigitGuardSmokeTest {
    private static void check(boolean ok){if(!ok)throw new AssertionError("Karizma digit scan safety");}
    public static void main(String[] args)throws Exception{
        if(args.length!=1)throw new IllegalArgumentException("Provide path to numeric-shape asset");
        int w=691,h=1536;int[] uniform=new int[w*h];
        java.util.Arrays.fill(uniform,0xFFFFFFFF);
        try(FileInputStream in=new FileInputStream(args[0])){
            KarizmaDigitReader.Scan blank=KarizmaDigitReader.scan(uniform,w,h,in);
            check(!blank.providerLayoutFound&&blank.recognizedFieldCount==0);
            check(blank.values.amount.isEmpty()&&blank.values.gross.isEmpty());
        }
        // Alternating gray bands without visible characters are not evidence of a purchase.
        for(int y=352;y<1310;y++){
            boolean gray=false;
            for(int n=0;n<7;n++)if(y>=352+n*147&&y<425+n*147)gray=true;
            if(gray)for(int x=70;x<620;x++)uniform[y*w+x]=0xFFF1F1F3;
        }
        try(FileInputStream in=new FileInputStream(args[0])){
            KarizmaDigitReader.Scan blank=KarizmaDigitReader.scan(uniform,w,h,in);
            check(blank.recognizedFieldCount==0);
            check(blank.values.amount.isEmpty()&&blank.values.gramFee.isEmpty());
        }
        System.out.println("PASS: 4 Karizma digit-import safety guards");
    }
}
