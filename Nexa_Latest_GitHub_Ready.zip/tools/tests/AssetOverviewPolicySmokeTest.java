package com.example.silenttimer;
public final class AssetOverviewPolicySmokeTest {
    public static void main(String[] args){
        int a=0;
        for(int f=0;f<4;f++){assertIt(AssetOverviewPolicy.matches(AssetOverviewPolicy.ALL,100,200,false));a++;}
        assertIt(AssetOverviewPolicy.matches(1,100,110,false));a++;
        assertIt(!AssetOverviewPolicy.matches(1,100,100,true));a++;
        assertIt(!AssetOverviewPolicy.matches(1,100,90,false));a++;
        assertIt(AssetOverviewPolicy.matches(2,100,90,false));a++;
        assertIt(!AssetOverviewPolicy.matches(2,100,100,false));a++;
        assertIt(AssetOverviewPolicy.matches(3,100,100,true));a++;
        assertIt(!AssetOverviewPolicy.matches(3,100,100,false));a++;
        assertIt(AssetOverviewPolicy.matches(0,0,0,false));a++;
        System.out.println("PASS: AssetOverviewPolicy " + a + " cases");
    }
    private static void assertIt(boolean result){if(!result)throw new AssertionError("Asset overview state mismatch");}
}
