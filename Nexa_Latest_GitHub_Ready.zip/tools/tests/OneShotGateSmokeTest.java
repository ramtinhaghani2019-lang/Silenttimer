package com.example.silenttimer;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

/** javac -d /tmp/nexa-gate app/src/main/java/com/example/silenttimer/OneShotGate.java tools/tests/OneShotGateSmokeTest.java
 *  java -ea -cp /tmp/nexa-gate com.example.silenttimer.OneShotGateSmokeTest */
public final class OneShotGateSmokeTest {
    public static void main(String[] args) throws InterruptedException {
        OneShotGate gate = new OneShotGate();
        if (gate.isCompleted()) throw new AssertionError("new gate must be open");
        int count = 32;
        CountDownLatch ready = new CountDownLatch(count);
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch finish = new CountDownLatch(count);
        AtomicInteger won = new AtomicInteger();
        List<Thread> threads = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            Thread t = new Thread(() -> {
                ready.countDown();
                try { start.await(); if (gate.claim()) won.incrementAndGet(); }
                catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                finally { finish.countDown(); }
            });
            threads.add(t);
            t.start();
        }
        ready.await();
        start.countDown();
        finish.await();
        if (won.get() != 1 || !gate.isCompleted() || gate.claim())
            throw new AssertionError("exactly one response/timeout may complete the broadcast");
        System.out.println("PASS OneShotGate: 32 competing callbacks, exactly one completion");
    }
}
