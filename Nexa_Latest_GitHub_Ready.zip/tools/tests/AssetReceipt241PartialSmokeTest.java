package com.example.silenttimer;
/** Numerical safety regression for partial OCR on the user's two receipt layouts. */
public final class AssetReceipt241PartialSmokeTest {
    private static int n;
    private static void ok(boolean value){n++;if(!value)throw new AssertionError("partial OCR #"+n);}
    private static AssetReceiptParser.Result source(){
        AssetReceiptParser.Result r=new AssetReceiptParser.Result();
        r.assetType="صندوق نقره کاریزما";
        return r;
    }
    public static void main(String[] args){
        // Receipt: amount+cash fee are legible; the rest may be redacted/blurred.
        AssetReceiptFieldFusion.Candidates fee=new AssetReceiptFieldFusion.Candidates();
        fee.add("amount","۱,۰۰۰,۰۰۰,۰۰۰");fee.add("cashFee","۵,۰۰۰,۰۰۰");
        AssetReceiptParser.Result f=AssetReceiptFieldFusion.fuse(source(),fee);
        AssetReceiptImportPlan.Decision d=AssetReceiptImportPlan.evaluate(f,f.assetType);
        ok(d.verifiedNumericFields==2);
        ok("1000000000".equals(d.trusted.amountRial));
        ok("5000000".equals(d.trusted.cashFeeRial));
        ok(d.trusted.unitPriceRial.isEmpty());
        ok(d.trusted.netQuantity.isEmpty());
        ok(!d.complete);
        // A missing cash fee does not discard the amount, rate, and gross quantity.
        AssetReceiptFieldFusion.Candidates trio=new AssetReceiptFieldFusion.Candidates();
        trio.add("amount","۷۰٬۰۰۰٬۰۰۰");trio.add("gross","۱۴/۴۲۵۰۰۶");
        trio.add("price","۴,۸۵۲,۶۸۴");
        f=AssetReceiptFieldFusion.fuse(source(),trio);
        d=AssetReceiptImportPlan.evaluate(f,f.assetType);
        ok("70000000".equals(d.trusted.amountRial));
        ok("4852684".equals(d.trusted.unitPriceRial));
        ok(d.trusted.netQuantity.isEmpty()); // Do not guess a net of 14.425006
        // A weight fee plus gross quantity proves net without inventing a rate.
        AssetReceiptFieldFusion.Candidates weights=new AssetReceiptFieldFusion.Candidates();
        weights.add("gross","۲۰۸/۲۵۵۹۳۸۹");weights.add("gramFee","۱/۰۴۱۲۷۹۷");
        f=AssetReceiptFieldFusion.fuse(source(),weights);
        d=AssetReceiptImportPlan.evaluate(f,f.assetType);
        ok("207.2146592".equals(d.trusted.netQuantity));
        ok(d.trusted.amountRial.isEmpty());
        ok(!d.complete);
        // A wrong neighboring purchase unit price cannot validate the trio.
        AssetReceiptFieldFusion.Candidates wrong=new AssetReceiptFieldFusion.Candidates();
        wrong.add("amount","۱,۰۰۰,۰۰۰,۰۰۰");wrong.add("gross","۲۰۸/۲۵۵۹۳۸۹");
        wrong.add("price","۴,۸۵۲,۶۸۴");
        f=AssetReceiptFieldFusion.fuse(source(),wrong);
        d=AssetReceiptImportPlan.evaluate(f,f.assetType);
        ok(d.verifiedNumericFields==0);
        // No fabricated receipt date or implicit action to save.
        ok(!d.trusted.hasDate);
        System.out.println("PASS: "+n+" partial-derivation protections");
    }
}
