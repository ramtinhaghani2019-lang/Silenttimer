import com.example.silenttimer.AlertRules;
import com.example.silenttimer.ReminderOccurrenceGuard;
import java.util.Calendar;
import java.util.TimeZone;

public final class ReminderOccurrenceGuardSmokeTest {
    private static int checks;
    private static void yes(boolean actual) { checks++; if (!actual) throw new AssertionError("check " + checks); }
    private static void no(boolean actual) { yes(!actual); }

    public static void main(String[] args) {
        final String id = "reminder-xyz";
        final long due = 1800000000000L;
        final String rules = "0, 30, D3@09:00";
        for (String rule : AlertRules.split(rules)) {
            yes(ReminderOccurrenceGuard.isCurrent(id, due, rules, true, false, id + ":" + rule + ":" + due));
        }
        no(ReminderOccurrenceGuard.isCurrent(id, due, rules, true, false, id + ":0:" + (due-1)));
        no(ReminderOccurrenceGuard.isCurrent(id, due, rules, true, false, "wrong:0:" + due));
        no(ReminderOccurrenceGuard.isCurrent(id, due, "0", true, false, id + ":30:" + due));
        no(ReminderOccurrenceGuard.isCurrent(id, due, rules, false, false, id + ":0:" + due));
        no(ReminderOccurrenceGuard.isCurrent(id, due, rules, true, true, id + ":0:" + due));
        no(ReminderOccurrenceGuard.isCurrent(id, due, rules, true, false, null));
        no(ReminderOccurrenceGuard.isCurrent(null, due, rules, true, false, id + ":0:" + due));
        no(ReminderOccurrenceGuard.isCurrent(id, 0L, rules, true, false, id + ":0:" + due));
        no(ReminderOccurrenceGuard.isCurrent(id, due, "", true, false, id + ":0:" + due));
        no(ReminderOccurrenceGuard.isCurrent(id, due, rules, true, false, id + ":999:" + due));

        // Calendar-day advance rules are recalculated for the active time zone.
        TimeZone original = TimeZone.getDefault();
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("UTC"));
            long utc = AlertRules.trigger(due, "D3@09:00");
            TimeZone.setDefault(TimeZone.getTimeZone("Asia/Tehran"));
            long tehran = AlertRules.trigger(due, "D3@09:00");
            yes(utc > 0 && tehran > 0);
            yes(utc != tehran);
            yes(AlertRules.trigger(due, "0") == due);
        } finally {
            TimeZone.setDefault(original);
        }
        System.out.println("Reminder occurrence/clock smoke checks passed: " + checks);
    }
}
