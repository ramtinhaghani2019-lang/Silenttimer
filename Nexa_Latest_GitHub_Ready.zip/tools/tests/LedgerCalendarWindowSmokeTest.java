package com.example.silenttimer;

import java.util.*;

/** No Android dependencies. Test local date window, mixed kinds, and unchanged balances. */
public final class LedgerCalendarWindowSmokeTest {
    private static int checks=0;
    private static void check(boolean b,String why){checks++;if(!b)throw new AssertionError(why);}
    private static long at(TimeZone zone,int y,int m,int d,int hh,int mm) {
        Calendar c=Calendar.getInstance(zone);
        c.clear();c.set(y,m-1,d,hh,mm,0);
        return c.getTimeInMillis();
    }
    private static NexaStore.LedgerEntry entry(String id,String kind,long timestamp,long amount) {
        NexaStore.LedgerEntry e=new NexaStore.LedgerEntry();
        e.id=id;e.partyId="p";e.kind=kind;e.dateMillis=timestamp;e.amount=amount;
        return e;
    }
    public static void main(String[] unused) {
        TimeZone helsinki=TimeZone.getTimeZone("Europe/Helsinki");
        // Europe/Helsinki moved clocks backwards on October 25, 2026.
        long now=at(helsinki,2026,10,25,19,0);
        check(LedgerHistoryFilter.recentStart(1,now,helsinki)==at(helsinki,2026,10,25,0,0),"today starts at midnight");
        check(LedgerHistoryFilter.recentStart(7,now,helsinki)==at(helsinki,2026,10,19,0,0),"7-day date range includes six previous dates");
        check(LedgerHistoryFilter.recentStart(30,now,helsinki)==at(helsinki,2026,9,26,0,0),"30 calendar dates including today");
        check(LedgerHistoryFilter.recentStart(90,now,helsinki)==at(helsinki,2026,7,28,0,0),"90 calendar dates including today");
        check(LedgerHistoryFilter.recentStart(0,now,helsinki)==Long.MIN_VALUE,"all-day filter unbounded");
        long epochBoundary=at(helsinki,2026,10,19,0,0);
        check(LedgerHistoryFilter.dayKey(epochBoundary,helsinki)==20261019,"local day key");
        check(LedgerHistoryFilter.dayKey(now,helsinki)==20261025,"after DST shift local day key");
        TimeZone losAngeles=TimeZone.getTimeZone("America/Los_Angeles");
        check(LedgerHistoryFilter.dayKey(now,helsinki)!=LedgerHistoryFilter.dayKey(now,losAngeles)||
              LedgerHistoryFilter.dayKey(at(helsinki,2026,10,25,1,0),helsinki)!=
              LedgerHistoryFilter.dayKey(at(helsinki,2026,10,25,1,0),losAngeles),"timezone-aware day keys");
        check(LedgerHistoryFilter.recentStart(1,now,null)!=Long.MAX_VALUE,"null timezone uses default");
        NexaStore.LedgerParty p=new NexaStore.LedgerParty();p.id="p";p.name="کریمی";
        long before=at(helsinki,2026,10,18,23,59);
        long boundary=at(helsinki,2026,10,19,0,0);
        long middle=at(helsinki,2026,10,21,12,0);
        long today=at(helsinki,2026,10,25,17,30);
        long future=at(helsinki,2026,11,1,12,0);
        List<NexaStore.LedgerEntry> source=Arrays.asList(
            entry("future","DEBT",future,99L),entry("middle","CREDIT",middle,500L),
            entry("old","DEBT",before,1000L),entry("today","PAYMENT",today,600L),
            entry("edge","RECEIPT",boundary,50L));
        LedgerReport.Result report=LedgerReport.generate(Collections.singletonList(p),source,"p",Long.MIN_VALUE,Long.MAX_VALUE);
        long historicalBalance=report.rows.get(report.rows.size()-2).runningBalance;
        List<LedgerReport.Row> week=LedgerHistoryFilter.selectBetween(report.rows,"ALL","",epochBoundary,now);
        check(week.size()==3,"date inclusive, excludes old and future");
        check(week.get(0).entry.id.equals("edge"),"boundary inclusive");
        check(week.get(2).entry.id.equals("today"),"latest within bound");
        check(LedgerHistoryFilter.selectBetween(report.rows,"PAYMENT","",epochBoundary,now).size()==1,"payment filter dates");
        check(LedgerHistoryFilter.selectBetween(report.rows,"DEBT","",epochBoundary,now).isEmpty(),"debt outside dates");
        check(LedgerHistoryFilter.selectBetween(report.rows,"CREDIT","",epochBoundary,now).size()==1,"credit filter dates");
        check(LedgerHistoryFilter.selectBetween(report.rows,"RECEIPT","",epochBoundary,now).size()==1,"receipt filter dates");
        check(LedgerHistoryFilter.selectBetween(report.rows,"PAYMENT","۶۰۰",epochBoundary,now).size()==1,"Persian amount and date filter together");
        check(LedgerHistoryFilter.selectBetween(report.rows,"ALL","",now,epochBoundary).isEmpty(),"inverted range empty");
        check(LedgerHistoryFilter.selectBetween(null,"ALL","",epochBoundary,now).isEmpty(),"null source empty");
        List<LedgerReport.Row> reversed=LedgerReport.orderedRows(week,true);
        check(reversed.get(0).entry.id.equals("today")&&reversed.get(2).entry.id.equals("edge"),"filtered chronological order");
        check(week.get(2).runningBalance==historicalBalance,"running balance kept independent of filters");
        check(source.get(0).id.equals("future"),"input untouched");
        check(LedgerHistoryFilter.selectBetween(report.rows,"ALL","",Long.MIN_VALUE,Long.MAX_VALUE).size()==5,"all history matches");
        System.out.println("PASS LedgerCalendarWindowSmokeTest: "+checks+" checks");
    }
}
