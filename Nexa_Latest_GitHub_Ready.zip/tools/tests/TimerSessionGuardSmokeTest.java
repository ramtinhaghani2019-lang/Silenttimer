package com.example.silenttimer;

public final class TimerSessionGuardSmokeTest {
    public static void main(String[] args) {
        long[][] cases = {{0,0},{-1,-1},{1000,0},{0,1000},{1,0},{0,Long.MAX_VALUE}};
        boolean[] expected = {false,false,true,true,true,true};
        for (int i=0;i<cases.length;i++) {
            boolean actual=TimerSessionGuard.hasSession(cases[i][0],cases[i][1]);
            if(actual != expected[i]) throw new AssertionError("Timer guard case " + i);
        }
        System.out.println("PASS TimerSessionGuard: 6 idle/active/persisted scenarios");
    }
}
