package com.example.silenttimer;

public final class SearchDisplayPolicySmokeTest {
    private static void ok(boolean value,String test){if(!value)throw new AssertionError(test);}
    public static void main(String[] args){
        for(int group=1;group<=5;group++){
            ok(SearchDisplayPolicy.matches(SearchDisplayPolicy.ALL,group),"all category "+group);
            ok(SearchDisplayPolicy.matches(group,group),"self category "+group);
            for(int other=1;other<=5;other++)if(other!=group)
                ok(!SearchDisplayPolicy.matches(group,other),"cross category "+group+":"+other);
        }
        ok(SearchDisplayPolicy.compare(4,8,3,0)<0,"relevance priority");
        ok(SearchDisplayPolicy.compare(2,1,2,3)<0,"stable earlier order");
        ok(SearchDisplayPolicy.compare(2,3,2,1)>0,"stable later order");
        ok(SearchDisplayPolicy.compare(2,2,2,2)==0,"equal order");
        ok(SearchDisplayPolicy.FILTERS.length==6,"all categories exist");
        ok(SearchDisplayPolicy.countLabel(8,10,0).contains("8"),"all count");
        ok(SearchDisplayPolicy.countLabel(3,10,2).contains("10"),"filtered total");
        System.out.println("PASS: Build200 search grouping, relevance and totals");
    }
}
