package com.example.silenttimer;
public final class ManualTimerRestorePolicySmokeTest {
    public static void main(String[] args) {
        int[][] cases = { {2,0,2}, {1,0,1}, {-1,0,2}, {0,0,2},
                {0,1,0}, {2,1,2}, {1,1,2}, {99,0,2} };
        for (int i=0;i<cases.length;i++) {
            int[] c=cases[i];
            int got=ManualTimerRestorePolicy.originalMode(c[0],c[1]);
            if(got!=c[2]) throw new AssertionError("Manual mute case "+i+": "+got);
        }
        System.out.println("PASS: manual Silent/Vibrate pre-transition restoration: "+cases.length+" cases");
    }
}
