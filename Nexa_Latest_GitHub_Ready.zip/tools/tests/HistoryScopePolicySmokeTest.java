package com.example.silenttimer;

public class HistoryScopePolicySmokeTest {
    private static int tests=0;
    private static void ok(boolean v){tests++;if(!v)throw new AssertionError("scope test "+tests);}
    public static void main(String[] args){
        long now=1_800_000_000_000L;
        ok(HistoryScopePolicy.inWindow("all",0,now));
        ok(HistoryScopePolicy.inWindow("today",now,now));
        ok(HistoryScopePolicy.inWindow("today",now-86_400_000L,now));
        ok(!HistoryScopePolicy.inWindow("today",now-86_400_001L,now));
        ok(HistoryScopePolicy.inWindow("week",now-604_800_000L,now));
        ok(!HistoryScopePolicy.inWindow("week",now-604_800_001L,now));
        ok(!HistoryScopePolicy.inWindow("today",now+1L,now));
        ok(!HistoryScopePolicy.inWindow("bad",now,now));
        ok(HistoryScopePolicy.matches("all",now,now,"تایمر","ثبت رویداد", "تایمر"));
        ok(HistoryScopePolicy.matches("all",now,now,null,"رویداد جدید", "جدید"));
        ok(!HistoryScopePolicy.matches("all",now,now,null,"رویداد جدید", "مخفی"));
        ok(HistoryScopePolicy.matches("week",now,now,"case","Record", "RECORD"));
        System.out.println("PASS HistoryScopePolicy "+tests);
    }
}
