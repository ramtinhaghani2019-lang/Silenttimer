package com.example.silenttimer;
public final class FeatureEmojiSmokeTest {
    private static void eq(String expected,String actual){
        if(!expected.equals(actual))throw new AssertionError("Expected "+expected+" but found "+actual);
    }
    public static void main(String[] args){
        String[] e=FeatureEmoji.directoryIcons();
        if(e.length!=18)throw new AssertionError("18 destinations must be preserved");
        String[] original={"⚖️","☁️","🔕","🔋","🔐","🆘","🔎","🕒"};
        int[] indices={6,7,8,9,10,11,13,14};
        for(int i=0;i<indices.length;i++)eq(original[i],e[indices[i]]);
        for(String item:e)if(item==null||item.isEmpty())throw new AssertionError("Empty emoji");
        e[9]="X";
        eq("🔋",FeatureEmoji.directoryIcons()[9]);
        System.out.println("PASS: all 18 emojis, original icon identity, immutable mapping");
    }
}
