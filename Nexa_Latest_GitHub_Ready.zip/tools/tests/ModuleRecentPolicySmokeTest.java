package com.example.silenttimer;
public final class ModuleRecentPolicySmokeTest {
    static void check(boolean result){if(!result)throw new AssertionError("module recents");}
    public static void main(String[] args){
        check(ModuleRecentPolicy.read(null).isEmpty());
        String history="";
        for(int i=0;i<6;i++)history=ModuleRecentPolicy.opened(history,"module"+i);
        check(ModuleRecentPolicy.read(history).size()==4);
        check(ModuleRecentPolicy.read(history).get(0).equals("module5"));
        check(ModuleRecentPolicy.read(history).get(3).equals("module2"));
        history=ModuleRecentPolicy.opened(history,"module3");
        check(ModuleRecentPolicy.read(history).get(0).equals("module3"));
        check(ModuleRecentPolicy.read(history).size()==4);
        check(ModuleRecentPolicy.opened(history,"").equals(history));
        check(ModuleRecentPolicy.read("a||b|a|c").size()==3);
        System.out.println("PASS ModuleRecentPolicySmokeTest 8");
    }
}
