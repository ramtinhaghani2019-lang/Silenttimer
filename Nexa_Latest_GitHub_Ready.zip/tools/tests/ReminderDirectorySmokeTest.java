package com.example.silenttimer;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.TimeZone;

/** Build 215: recurring due previews and list filtering are read-only. */
public final class ReminderDirectorySmokeTest {
    private static int checks;
    private static void check(boolean ok,String name){checks++;if(!ok)throw new AssertionError(name);}
    public static void main(String[] args){
        TimeZone prior=TimeZone.getDefault();
        try{
            TimeZone.setDefault(TimeZone.getTimeZone("Europe/London"));
            Calendar cal=Calendar.getInstance();cal.set(2026,Calendar.NOVEMBER,2,8,0,0);cal.set(Calendar.MILLISECOND,0);
            long now=cal.getTimeInMillis();long start=AgendaDuePolicy.startOfDay(now);
            NexaStore.Reminder daily=new NexaStore.Reminder();
            daily.title="تکراری";daily.active=true;daily.done=false;daily.recurrence="daily";
            daily.whenMillis=AgendaDuePolicy.afterCalendarDays(start,-40)+9*3600_000L;
            check(ReminderOrganizer.effectiveDue(daily,now)==start+9*3600_000L,"daily chooses today's occurrence");
            check(ReminderOrganizer.visible(daily,"pending",now),"daily pending this morning");
            check(!ReminderOrganizer.visible(daily,"overdue",now),"daily not permanently overdue");
            check(ReminderOrganizer.visible(daily,"week",now),"daily this week");
            long later=start+10*3600_000L;
            check(ReminderOrganizer.visible(daily,"overdue",later),"missed today becomes overdue");
            check(!ReminderOrganizer.visible(daily,"pending",later),"overdue today not pending");
            check(!ReminderOrganizer.visible(daily,"week",later),"missed today not upcoming week");
            NexaStore.Reminder once=new NexaStore.Reminder();once.whenMillis=start-3*3600_000L;
            check(ReminderOrganizer.effectiveDue(once,now)==once.whenMillis,"one-time unchanged");
            check(ReminderOrganizer.visible(once,"overdue",now),"old one-time overdue");
            NexaStore.Reminder paused=new NexaStore.Reminder();paused.whenMillis=daily.whenMillis;
            paused.recurrence="daily";paused.active=false;
            check(ReminderOrganizer.effectiveDue(paused,now)==paused.whenMillis,"paused unchanged");
            check(ReminderOrganizer.visible(paused,"paused",now),"paused stays paused");
            check(!ReminderOrganizer.visible(paused,"pending",now),"paused not pending");
            check(!ReminderOrganizer.visible(paused,"overdue",now),"paused not overdue");
            NexaStore.Reminder done=new NexaStore.Reminder();done.whenMillis=daily.whenMillis;
            done.recurrence="daily";done.done=true;done.active=false;
            check(ReminderOrganizer.effectiveDue(done,now)==done.whenMillis,"completed stored date unchanged");
            check(ReminderOrganizer.visible(done,"done",now),"completed stays completed");
            NexaStore.Reminder future=new NexaStore.Reminder();future.whenMillis=start+11*3600_000L;
            List<NexaStore.Reminder> original=new ArrayList<>();
            original.add(future);original.add(daily);original.add(once);
            List<NexaStore.Reminder> order=ReminderOrganizer.ordered(original,"smart",now);
            check(order.get(0)==once,"smart prioritizes overdue once");
            check(order.get(1)==daily,"smart sorts future current occurrences");
            check(original.get(0)==future,"sort does not mutate store order");
            check(ReminderOrganizer.matches(daily,"تكراري"),"Persian Arabic text search works");
            // Valid recurrence should preserve the current day's wall-clock slot at DST crossings.
            cal.set(2026,Calendar.MARCH,29,8,0,0);cal.set(Calendar.MILLISECOND,0);
            long dstNow=cal.getTimeInMillis();long dstStart=AgendaDuePolicy.startOfDay(dstNow);
            cal.setTimeInMillis(AgendaDuePolicy.afterCalendarDays(dstStart,-20));
            cal.set(Calendar.HOUR_OF_DAY,9);cal.set(Calendar.MINUTE,0);
            daily.whenMillis=cal.getTimeInMillis();
            cal.setTimeInMillis(dstStart);cal.set(Calendar.HOUR_OF_DAY,9);
            long dstExpected=cal.getTimeInMillis();
            check(ReminderOrganizer.effectiveDue(daily,dstNow)==dstExpected,"spring recurrence wall-clock");
            check(ReminderOrganizer.effectiveDue(null,now)==0,"null safe");
            System.out.println("PASS ReminderDirectory: "+checks+" assertions");
        }finally{TimeZone.setDefault(prior);}
    }
}
