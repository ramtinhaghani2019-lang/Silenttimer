package com.example.silenttimer;

public final class HomeTimerLayoutPolicySmokeTest {
    static int count=0;
    private static void check(boolean actual,boolean expected,String label){
        count++;
        if(actual!=expected) throw new AssertionError(label+": expected "+expected+" got "+actual);
    }
    public static void main(String[] args){
        check(HomeTimerLayoutPolicy.stackPresets(290f,1f),true,"narrow");
        check(HomeTimerLayoutPolicy.stackPresets(304.9f,1f),true,"below boundary");
        check(HomeTimerLayoutPolicy.stackPresets(305f,1f),false,"at boundary");
        check(HomeTimerLayoutPolicy.stackPresets(350f,1f),false,"normal mobile");
        check(HomeTimerLayoutPolicy.stackPresets(500f,1f),false,"tablet");
        check(HomeTimerLayoutPolicy.stackPresets(450f,1.17f),true,"large text");
        check(HomeTimerLayoutPolicy.stackPresets(450f,1.16f),false,"font boundary");
        check(HomeTimerLayoutPolicy.stackPresets(305f,1.3f),true,"large text boundary");
        System.out.println("PASS: "+count+" HomeTimerLayoutPolicy checks");
    }
}
