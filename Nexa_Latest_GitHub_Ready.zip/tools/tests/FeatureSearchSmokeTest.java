package com.example.silenttimer;
public final class FeatureSearchSmokeTest {
    private static void ok(boolean condition){if(!condition)throw new AssertionError("feature search");}
    public static void main(String[] args){
        ok(FeatureSearch.matches("قبوض و اقساط","قسط پرداخت بدهی","امور مالی","قسط"));
        ok(FeatureSearch.matches("قبوض و اقساط","پرداخت بدهی","امور مالی","پرداخت"));
        ok(FeatureSearch.matches("امنیت و حریم خصوصی","قفل","تنظیمات","حريم خصوصي"));
        ok(FeatureSearch.matches("دارو و سلامت","پزشکی","سلامت","  " ));
        ok(FeatureSearch.matches("قبوض و اقساط","پرداخت بدهی","مالی","مالی پرداخت"));
        ok(!FeatureSearch.matches("هواشناسی","آب و هوا","زندگی","پرداخت"));
        ok("کارت بانکی".equals(FeatureSearch.normalize("كارت\u200cبانكي")));
        System.out.println("PASS: searchable menu Persian normalization and matching");
    }
}
