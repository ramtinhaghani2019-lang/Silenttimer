package com.example.silenttimer;
import java.util.Calendar;
import java.util.TimeZone;
public final class AgendaDuePolicySmokeTest {
    private static void check(boolean ok,String why){if(!ok)throw new AssertionError(why);}
    public static void main(String[] args){
        TimeZone previous=TimeZone.getDefault();
        try {
            TimeZone.setDefault(TimeZone.getTimeZone("Europe/London"));
            Calendar c=Calendar.getInstance();c.set(2026,Calendar.NOVEMBER,2,16,15,0);c.set(Calendar.MILLISECOND,0);
            long now=c.getTimeInMillis();long day=AgendaDuePolicy.startOfDay(now);
            long tomorrow=AgendaDuePolicy.afterCalendarDays(day,1);
            long day2=AgendaDuePolicy.afterCalendarDays(day,2);
            long week=AgendaDuePolicy.afterCalendarDays(day,8);
            check(AgendaDuePolicy.bucket(day+1,false,day,tomorrow,day2,week)==AgendaDuePolicy.TODAY,"today");
            check(AgendaDuePolicy.bucket(tomorrow,false,day,tomorrow,day2,week)==AgendaDuePolicy.TOMORROW,"tomorrow");
            check(AgendaDuePolicy.bucket(day2,false,day,tomorrow,day2,week)==AgendaDuePolicy.LATER_THIS_WEEK,"day2");
            check(AgendaDuePolicy.bucket(week,false,day,tomorrow,day2,week)==AgendaDuePolicy.OUTSIDE,"week-exclusive");
            check(AgendaDuePolicy.bucket(day-1,false,day,tomorrow,day2,week)==AgendaDuePolicy.OVERDUE,"overdue");
            check(AgendaDuePolicy.bucket(day+1,true,day,tomorrow,day2,week)==AgendaDuePolicy.COMPLETED,"completed");
            check(AgendaDuePolicy.bucket(day2,true,day,tomorrow,day2,week)==AgendaDuePolicy.OUTSIDE,"not completed today");
            check(!AgendaDuePolicy.includeReminder(false,false),"paused hidden");
            check(AgendaDuePolicy.includeReminder(false,true),"done visible");
            check(AgendaDuePolicy.shownDue(day-100000,"none",day)==day-100000,"one time stays overdue");
            long old=AgendaDuePolicy.afterCalendarDays(day,-100)+9*3600_000L;
            long due=AgendaDuePolicy.shownDue(old,"daily",day);
            check(due==day+9*3600_000L,"today occurrence from old daily record");
            check(AgendaDuePolicy.overdueForAttention(old,"daily",now),"today expired occurrence overdue");
            check(!AgendaDuePolicy.overdueForAttention(old,"weekly",day+1L),"old weekly not permanently overdue");
            check(AgendaDuePolicy.shownDue(day+9*3600_000L,"none",day)==day+9*3600_000L,"one-time unchanged");
            check(AgendaDuePolicy.shownDue(0,"daily",day)==0,"missing date");
            // DST spring day in London has 23 hours. Calendar should retain midnight day boundaries.
            c.set(2026,Calendar.MARCH,29,12,0,0);c.set(Calendar.MILLISECOND,0);
            long dst=AgendaDuePolicy.startOfDay(c.getTimeInMillis());
            check(AgendaDuePolicy.afterCalendarDays(dst,1)-dst==23L*3600_000L,"DST spring 23h day");
            c.set(2026,Calendar.OCTOBER,25,12,0,0);
            long fall=AgendaDuePolicy.startOfDay(c.getTimeInMillis());
            check(AgendaDuePolicy.afterCalendarDays(fall,1)-fall==25L*3600_000L,"DST fall 25h day");
            System.out.println("PASS AgendaDuePolicy: 16 boundary/recurrence/pause/DST checks");
        } finally {TimeZone.setDefault(previous);}
    }
}
