import com.example.silenttimer.ListShareExport;
import java.util.*;

public class ListShareExportSmokeTest {
  static int checks=0;
  static void test(boolean condition,String label){checks++;if(!condition)throw new AssertionError(label);}
  public static void main(String[] args){
    List<ListShareExport.Entry> sample=Arrays.asList(
      new ListShareExport.Entry("برنج", "۲ کیلو", "خوراکی", false, true),
      new ListShareExport.Entry("شیر", "۳ عدد", "خوراکی", true, false),
      new ListShareExport.Entry("=BAD(1)", "۱ عدد", "+A1", false, false),
      new ListShareExport.Entry("هندوانه\nسنگین", "۱ کیلو", "\t@SUM(1)", false, false)
    );
    test(ListShareExport.select(sample,false).size()==3,"unfinished filtered");
    test(ListShareExport.select(sample,true).size()==4,"all kept");
    test(ListShareExport.select(null,true).isEmpty(),"null input");
    test(ListShareExport.select(Collections.singletonList((ListShareExport.Entry)null),true).isEmpty(),"null entry");
    String msg=ListShareExport.text("خرید منزل",sample,false,false);
    test(msg.contains("برنج"),"persian text");
    test(msg.contains("⭐"),"important flag");
    test(msg.contains("۳"),"visible count");
    test(!msg.contains("شیر"),"completed omitted");
    test(!msg.contains("هندوانه\nسنگین"),"newline normalized in text");
    String all=ListShareExport.text("خانه",sample,true,false);
    test(all.contains("شیر"),"explicit completed inclusion");
    test(all.contains("☑"),"completed marker");
    String csv=ListShareExport.csv("خانه",sample,false,false);
    test(csv.startsWith("\ufeff"),"csv UTF-8 BOM");
    test(csv.startsWith("\ufeffنوع,فهرست"),"csv header");
    test(csv.contains("'=BAD(1)"),"formula escaped");
    test(csv.contains("'+A1"),"plus formula escaped");
    test(!csv.contains("\"شیر\""),"completed excluded CSV");
    test(csv.split("\r\n",-1).length==5,"three rows and header");
    test(!csv.contains("\nسنگین"),"no multiline row injection");
    test(!csv.contains("\t@SUM(1)"),"no tab injection");
    String t=ListShareExport.csv("کارها",Collections.singletonList(new ListShareExport.Entry("تماس", "۱۴۰۵/۰۸/۰۱", "اداری", false, false)),false,true);
    test(t.contains("\"کار\""),"todo export type");
    test(t.contains("۱۴۰۵/۰۸/۰۱"),"todo date");
    test(t.contains("تماس"),"todo title");
    test(!t.contains("بانک")&&!t.contains("فاکتور"),"private fields absent");
    ListShareExport.Entry evil=new ListShareExport.Entry("=1,\"hey\"", "", "",false,false);
    String quoted=ListShareExport.csv("خانه",Collections.singletonList(evil),false,false);
    test(quoted.contains("\"'=1,\"\"hey\"\"\""),"RFC4180 quote escaping");
    test(ListShareExport.select(Collections.singletonList(new ListShareExport.Entry("  ", "", "",false,false)),true).isEmpty(),"no blank entries");
    test(ListShareExport.text("نام\nلیست",sample,false,false).contains("نام لیست"),"header normalized");
    test(ListShareExport.text("لیست",Collections.emptyList(),false,false).contains("تعداد: ۰"),"empty list stable");
    System.out.println("PASSED "+checks+" Java smoke assertions");
  }
}
