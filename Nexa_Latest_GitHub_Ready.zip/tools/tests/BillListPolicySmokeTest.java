package com.example.silenttimer;
import java.util.Arrays;

public final class BillListPolicySmokeTest {
    private static int count;
    private static void check(boolean v,String msg){count++;if(!v)throw new AssertionError(msg);}
    public static void main(String[]args){
        long now=2_000_000_000_000L;
        long week=BillListPolicy.horizon(now);
        check(BillListPolicy.overdue(false,now-1,now),"unpaid overdue");
        check(!BillListPolicy.overdue(true,now-1,now),"paid not overdue");
        check(!BillListPolicy.overdue(false,now,now),"due now not overdue");
        check(BillListPolicy.soon(false,now,now),"due now is soon");
        check(BillListPolicy.soon(false,week,now),"seven-day boundary inclusive");
        check(!BillListPolicy.soon(false,week+1,now),"after boundary not soon");
        check(!BillListPolicy.soon(true,now,now),"paid excluded from soon");
        check(BillListPolicy.matches("معوق",false,now-1,now),"overdue match");
        check(BillListPolicy.matches(BillListPolicy.SEVEN_DAY_FILTER,false,now+100,now),"soon match");
        check(!BillListPolicy.matches("آینده",false,now-1,now),"overdue not future");
        check(BillListPolicy.matches("پرداخت‌شده",true,now-1,now),"paid match");
        check(BillListPolicy.matches("همه",true,now-1,now),"all match");
        check(BillListPolicy.compare(false,now-1,false,now+1,now)<0,"overdue first");
        check(BillListPolicy.compare(false,now+1,false,week+10,now)<0,"soon before later");
        check(BillListPolicy.compare(false,now+1,true,now-10,now)<0,"unpaid before paid");
        check(BillListPolicy.compare(true,now+5,true,now-5,now)<0,"paid newest first");
        BillListPolicy.Summary s=BillListPolicy.summarize(Arrays.asList(
            new BillListPolicy.Entry(false,now-20,100),
            new BillListPolicy.Entry(false,now+20,300),
            new BillListPolicy.Entry(false,now+8L*86400000L,500),
            new BillListPolicy.Entry(true,now-10,700)),now);
        check(s.pendingAmount==900,"paid excluded from pending");
        check(s.overdueAmount==100 && s.overdueCount==1,"overdue totals");
        check(s.soonAmount==300 && s.soonCount==1,"seven-day totals");
        check(s.upcomingCount==2 && s.paidCount==1,"other counts");
        check(BillListPolicy.summarize(null,now).pendingAmount==0,"null list");
        check(BillListPolicy.horizon(Long.MAX_VALUE)==Long.MAX_VALUE,"safe horizon overflow");
        check(BillListPolicy.plusNonNegative(Long.MAX_VALUE-1,100)==Long.MAX_VALUE,"saturated currency addition");
        check(BillListPolicy.plusNonNegative(100,-5)==100,"negative amounts ignored");
        System.out.println("PASS Build205 BillListPolicy JVM checks: "+count);
    }
}
