package com.example.silenttimer;
public class MedicineOverviewPolicySmokeTest {
    static void check(boolean b){if(!b)throw new AssertionError("Medicine overview state mismatch");}
    public static void main(String[] args){
        long now=1_000_000_000L;
        check(MedicineOverviewPolicy.classify(false,now-1,now)==MedicineOverviewPolicy.FINISHED);
        check(MedicineOverviewPolicy.classify(true,now-1,now)==MedicineOverviewPolicy.OVERDUE);
        check(MedicineOverviewPolicy.classify(true,now,now)==MedicineOverviewPolicy.OVERDUE);
        check(MedicineOverviewPolicy.classify(true,now+1,now)==MedicineOverviewPolicy.SOON);
        check(MedicineOverviewPolicy.classify(true,now+24L*60*60*1000,now)==MedicineOverviewPolicy.SOON);
        check(MedicineOverviewPolicy.classify(true,now+24L*60*60*1000+1,now)==MedicineOverviewPolicy.PLANNED);
        check(MedicineOverviewPolicy.classify(true,0,now)==MedicineOverviewPolicy.PLANNED);
        check(MedicineOverviewPolicy.classify(true,-1,now)==MedicineOverviewPolicy.PLANNED);
        System.out.println("PASS 8 medication overview statuses");
    }
}
