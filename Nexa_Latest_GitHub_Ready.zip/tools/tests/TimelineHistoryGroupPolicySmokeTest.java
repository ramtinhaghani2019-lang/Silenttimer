package com.example.silenttimer;

public final class TimelineHistoryGroupPolicySmokeTest {
    private static int n;
    private static void ok(boolean condition){n++;if(!condition)throw new AssertionError("history grouping "+n);}
    public static void main(String[] args){
        String a=TimelineHistoryGroupPolicy.keyFor("history","دارو","آموکسی کلاو • الان خوردم");
        String b=TimelineHistoryGroupPolicy.keyFor("history","دارو","هشدار: آموکسی کلاو");
        String c=TimelineHistoryGroupPolicy.keyFor("history","دارو","آموكسي كلاو • سر وقت خوردم");
        ok(a!=null && a.equals(b));
        ok(a.equals(c));
        ok(!a.equals(TimelineHistoryGroupPolicy.keyFor("history","دارو","استامینوفن • الان خوردم")));
        ok(TimelineHistoryGroupPolicy.keyFor("history","خانه","ثبت سرویس: خاک گربه")==null);
        ok(TimelineHistoryGroupPolicy.keyFor("medicine","دارو","آموکسی کلاو • هشدار")==null);
        ok("هشدار دارو".equals(TimelineHistoryGroupPolicy.actionFor("هشدار: آموکسی کلاو")));
        ok("الان خوردم".equals(TimelineHistoryGroupPolicy.actionFor("آموکسی کلاو • الان خوردم")));
        ok("ثبت دارو".equals(TimelineHistoryGroupPolicy.actionFor("دارو اضافه شد: آموکسی کلاو")));
        ok("آموکسی کلاو".equals(TimelineHistoryGroupPolicy.medicineName("دارو","دارو ویرایش شد: آموکسی کلاو")));
        System.out.println("PASS TimelineHistoryGroupPolicySmokeTest "+n);
    }
}
