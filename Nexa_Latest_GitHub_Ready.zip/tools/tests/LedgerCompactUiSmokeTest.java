package com.example.silenttimer;

import java.util.*;

/** Build 172 compact accounting UI data presentation; no Android dependencies. */
public final class LedgerCompactUiSmokeTest {
    private static int checks;
    private static void check(boolean ok,String why){ checks++; if(!ok)throw new AssertionError(why); }
    private static NexaStore.LedgerEntry item(String id,String kind,long timestamp,long amount){
        NexaStore.LedgerEntry x=new NexaStore.LedgerEntry();
        x.id=id;x.partyId="p";x.kind=kind;x.amount=amount;x.dateMillis=timestamp;
        return x;
    }
    public static void main(String[] args){
        check(LedgerCompactUi.sortLabel(true).contains("جدیدترین"),"default newest label");
        check(LedgerCompactUi.sortLabel(false).contains("قدیمی‌ترین"),"oldest label");
        check(!LedgerCompactUi.hasActiveFilters("ALL",0,""),"empty filters closed summary");
        check(!LedgerCompactUi.hasActiveFilters(null,0,"   "),"null filters empty");
        check(LedgerCompactUi.hasActiveFilters("PAYMENT",0,""),"kind active");
        check(LedgerCompactUi.hasActiveFilters("ALL",7,""),"date active");
        check(LedgerCompactUi.hasActiveFilters("ALL",0,"  کریمی "),"search active");
        check(LedgerCompactUi.activeSummary("ALL",0,"").isEmpty(),"no false active chip");
        check(LedgerCompactUi.activeSummary("CREDIT",30,"  ۵۰۰  ").contains("طلب"),"kind correctly named");
        check(LedgerCompactUi.activeSummary("CREDIT",30,"  ۵۰۰  ").contains("30 روز"),"date displayed");
        check(LedgerCompactUi.activeSummary("CREDIT",30,"  ۵۰۰  ").contains("۵۰۰"),"query displayed");
        for(String kind:new String[]{"DEBT","CREDIT","PAYMENT","RECEIPT"}){
            check(LedgerCompactUi.hasActiveFilters(kind,0,null),"kind visible:"+kind);
            check(LedgerCompactUi.activeSummary(kind,0,null).contains(LedgerPresentation.shortLabel(kind)),"kind label:"+kind);
        }
        TimeZone old=TimeZone.getDefault();
        try{
            TimeZone.setDefault(TimeZone.getTimeZone("Asia/Tehran"));
            Calendar c=Calendar.getInstance();c.clear();c.set(2026,Calendar.OCTOBER,25,19,7);
            long date=c.getTimeInMillis();
            check(LedgerCompactUi.timeOnly(date).equals("19:07"),"time only without repeated date");
            check(!LedgerCompactUi.dayHeading(date).contains(" • "),"day heading excludes time");
            check(LedgerCompactUi.dayHeading(date).contains("آبان"),"Jalali date heading");
            NexaStore.LedgerParty p=new NexaStore.LedgerParty();p.id="p";p.name="مادر";
            List<NexaStore.LedgerEntry> entries=Arrays.asList(
                item("3","RECEIPT",300,25),item("1","DEBT",100,100),
                item("4","CREDIT",400,60),item("2","PAYMENT",200,35));
            LedgerReport.Result report=LedgerReport.generate(Collections.singletonList(p),entries,"p",Long.MIN_VALUE,Long.MAX_VALUE);
            List<LedgerReport.Row> filtered=LedgerHistoryFilter.selectBetween(report.rows,"ALL","",Long.MIN_VALUE,Long.MAX_VALUE);
            List<LedgerReport.Row> descending=LedgerReport.orderedRows(filtered,true);
            check(descending.get(0).entry.id.equals("4"),"UI row newest by transaction date");
            check(descending.get(3).entry.id.equals("1"),"UI row oldest at end");
            check(descending.get(0).runningBalance==report.rows.get(3).runningBalance,"balance not affected by ordering");
            check(LedgerReport.orderedRows(filtered,false).get(0).entry.id.equals("1"),"reverse order");
            check(LedgerHistoryFilter.selectBetween(report.rows,"PAYMENT","",Long.MIN_VALUE,Long.MAX_VALUE).get(0).runningBalance==-65,"payment balance historical");
            check(entries.get(0).id.equals("3"),"source unchanged");
        }finally {TimeZone.setDefault(old);}
        System.out.println("PASS LedgerCompactUiSmokeTest: "+checks+" checks");
    }
}
