package com.example.silenttimer;

public final class BackgroundDiagnosticSanitizerSmokeTest {
    public static void main(String[] args) {
        String valid = "1234567890000 | service.ticker | SecurityException";
        String raw = valid + "\n1234567890001 | service.ringer | IllegalStateException"
                + "\n1234567890002 | password=abc | Exception"
                + "\n1234567890003 | service.ringer | phone=1234"
                + "\ninvalid | service.ringer | RuntimeException";
        String report = BackgroundDiagnosticSanitizer.sanitize(raw);
        assertTrue(report.split("\n").length == 2, "only 2 valid rows");
        assertTrue(report.startsWith(valid), "valid entry preserved");
        assertTrue(!report.contains("password") && !report.contains("phone"), "no data leakage");
        assertTrue(BackgroundDiagnosticSanitizer.sanitize("").isEmpty(), "empty string");
        assertTrue(BackgroundDiagnosticSanitizer.sanitize(null).isEmpty(), "null input");
        StringBuilder nine = new StringBuilder();
        for (int i=0;i<10;i++) nine.append(i).append(" | service.timer | Error\n");
        assertTrue(BackgroundDiagnosticSanitizer.sanitize(nine.toString()).split("\n").length==8,
                "eight entry limit");
        System.out.println("PASS BackgroundDiagnosticSanitizer: format, privacy, limits");
    }

    private static void assertTrue(boolean assertion, String label) {
        if (!assertion) throw new AssertionError(label);
    }
}
