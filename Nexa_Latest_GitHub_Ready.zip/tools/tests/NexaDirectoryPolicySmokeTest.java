import com.example.silenttimer.NexaDirectoryPolicy;

public class NexaDirectoryPolicySmokeTest {
    private static void check(boolean value, String label) {
        if (!value) throw new AssertionError(label);
    }
    public static void main(String[] args) {
        check(NexaDirectoryPolicy.filterColumns(320,1f)==2,"320dp");
        check(NexaDirectoryPolicy.filterColumns(360,1f)==2,"360dp");
        check(NexaDirectoryPolicy.filterColumns(393,1f)==3,"393dp normal");
        check(NexaDirectoryPolicy.filterColumns(393,1.3f)==2,"393dp enlarged");
        check(NexaDirectoryPolicy.filterColumns(600,1.6f)==2,"enlarged tablet font");
        check(NexaDirectoryPolicy.visibleCount(0,12)==0,"empty");
        check(NexaDirectoryPolicy.visibleCount(5,12)==5,"small");
        check(NexaDirectoryPolicy.visibleCount(100,12)==12,"reminder first page");
        check(NexaDirectoryPolicy.remaining(100,12)==88,"reminder remaining");
        check(NexaDirectoryPolicy.visibleCount(100,20)==20,"search first page");
        check(NexaDirectoryPolicy.nextLimit(12,12)==24,"reminder next page");
        check(NexaDirectoryPolicy.nextLimit(20,20)==40,"search next page");
        check(NexaDirectoryPolicy.nextLimit(Integer.MAX_VALUE,20)==Integer.MAX_VALUE,"overflow guard");
        check(NexaDirectoryPolicy.remaining(11,24)==0,"complete");
        check(NexaDirectoryPolicy.visibleCount(-12,-5)==0,"negative guard");
        System.out.println("NexaDirectoryPolicy smoke: 15 checks passed");
    }
}
