package com.example.silenttimer;

public final class AssetMoneyUnitSmokeTest {
    private static int n;
    private static void near(double actual,double expected,double tolerance){n++;
        if(!Double.isFinite(actual)||Math.abs(actual-expected)>tolerance)throw new AssertionError("test "+n+": "+actual+" != "+expected);}
    private static void eq(Object actual,Object expected){n++;if(!expected.equals(actual))throw new AssertionError("test "+n+": "+actual+" != "+expected);}
    public static void main(String[] args){
        eq(AssetMoneyUnit.displayUnit("ریال"),"ریال");
        eq(AssetMoneyUnit.displayUnit("تومان"),"تومان");
        near(AssetMoneyUnit.toStored(4_517_930,"ریال"),451_793,0);
        near(AssetMoneyUnit.fromStored(451_793,"ریال"),4_517_930,0);
        near(AssetMoneyUnit.fromStored(480_178.4,"ریال"),4_801_784,0.00001);
        near(AssetMoneyUnit.toStored(4_801_784,"ریال"),480_178.4,0.00001);
        near(AssetMoneyUnit.fromStored(100_000_000,"ریال"),1_000_000_000,0);
        near(AssetMoneyUnit.toStored(1_000_000_000,"ریال"),100_000_000,0);
        near(AssetMoneyUnit.toStored(451_793,"تومان"),451_793,0);
        near(AssetMoneyUnit.fromStored(-5_000_000,"ریال"),-50_000_000,0);
        double quantity=207.2146592;
        double rialQuote=4_517_930;
        double storedQuote=AssetMoneyUnit.toStored(rialQuote,"ریال");
        near(AssetMoneyUnit.fromStored(quantity*storedQuote,"ریال"),quantity*rialQuote,0.001);
        System.out.println("PASS AssetMoneyUnit "+n+" assertions");
    }
}
