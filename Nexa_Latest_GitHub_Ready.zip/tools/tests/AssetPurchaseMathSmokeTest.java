package com.example.silenttimer;

public final class AssetPurchaseMathSmokeTest {
    private static int tests;
    private static void truth(boolean yes){tests++;if(!yes)throw new AssertionError("Expected true at test "+tests);}
    private static void near(double got,double want,double tolerance){tests++;
        if(Math.abs(got-want)>tolerance)throw new AssertionError("Expected "+want+" got "+got);}
    public static void main(String[] args){
        truth(AssetPurchaseMath.valid(1_000_000_000d,4_801_784d,5_000_000d));
        double q=AssetPurchaseMath.netQuantity(1_000_000_000d,4_801_784d,5_000_000d);
        near(q,207.21465189d,0.00000001d);
        near(q*4_801_784d+5_000_000d,1_000_000_000d,0.025d);
        truth("207.21465189".equals(AssetPurchaseMath.quantityText(q)));
        near(AssetPurchaseMath.netQuantity(1000d,10d,0d),100d,0d);
        near(AssetPurchaseMath.netQuantity(1000d,10d,250d),75d,0d);
        truth(!AssetPurchaseMath.valid(1000d,10d,1000d));
        truth(!AssetPurchaseMath.valid(1000d,10d,-5d));
        truth(!AssetPurchaseMath.valid(1000d,0d,0d));
        truth(!AssetPurchaseMath.valid(Double.NaN,10d,0d));
        truth(!AssetPurchaseMath.valid(Double.POSITIVE_INFINITY,10d,0d));
        truth(Double.isNaN(AssetPurchaseMath.netQuantity(1000d,0d,0d)));
        near(AssetPurchaseMath.netQuantity(1000d,3d,0d),333.33333333d,1e-10);
        truth(AssetPurchaseMath.quantityText(Double.NaN).equals("—"));
        System.out.println("PASS: AssetPurchaseMath "+tests+" cases");
    }
}
