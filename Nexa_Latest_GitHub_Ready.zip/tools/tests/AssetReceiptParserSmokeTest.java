package com.example.silenttimer;
/** Run with javac + java on the pure-Java parser, no Android SDK required. */
public final class AssetReceiptParserSmokeTest {
  private static int tested;
  private static void eq(String got,String expected){tested++;if(!expected.equals(got))throw new AssertionError(expected+" != "+got);}
  private static void truth(boolean ok){tested++;if(!ok)throw new AssertionError("failed test "+tested);}
  public static void main(String[] args){
    String receipt="نام ابزار حساب با پشتوانه نقره\nنوع تراکنش خرید\n"+
      "تاریخ تراکنش ۱۴۰۵/۰۸/۰۵ - ۱۳:۰۰\nمبلغ ۱,۰۰۰,۰۰۰,۰۰۰ ریال\n"+
      "مقدار ۲۰۸/۲۵۵۹۳۸۹ گرم\nقیمت هر گرم طرح نقره در لحظه ثبت ۴,۸۰۱,۷۸۴ ریال\n"+
      "کارمزد ریالی تراکنش ۵,۰۰۰,۰۰۰ ریال\nکارمزد گرمی تراکنش ۱/۰۴۱۲۷۹۷ گرم\n"+
      "مقدار دارایی بعد از تراکنش ۲۲۱/۵۶۷۵۴ گرم\nکد پیگیری ۷۱۲۴۵۰۵۴۹۶۰۵۷۰۸۸";
    AssetReceiptParser.Result r=AssetReceiptParser.parse(receipt);
    eq(r.assetType,"صندوق نقره کاریزما");eq(r.amountRial,"1000000000");
    eq(r.unitPriceRial,"4801784");eq(r.cashFeeRial,"5000000");
    eq(r.netQuantity,"207.2146592");eq(r.grossQuantity,"208.2559389");
    eq(r.tracking,"7124505496057088");truth(r.hasDate&&r.jalaliMonth==8&&r.jalaliDay==5);
    AssetReceiptParser.Result r2=AssetReceiptParser.parse("مبلغ\n۷۰٬۰۰۰٬۰۰۰ ریال\nمقدار\n۱۴٫۴۲۵۰۰۶ گرم\nکارمزد گرمی تراکنش\n۰٫۰۷۲۱۲۵ گرم");
    eq(r2.amountRial,"70000000");eq(r2.netQuantity,"14.352881");
    truth(AssetReceiptParser.parse("مقدار دارایی قبل از تراکنش ۱۴\nمقدار دارایی بعد از تراکنش ۱۸").netQuantity.isEmpty());
    truth(AssetReceiptParser.parse("نوع تراکنش فروش\nمبلغ ۵۰۰۰۰۰۰").isSale);
    AssetReceiptParser.Result invalid=AssetReceiptParser.parse("مبلغ ۱,۰۰۰,۰۰۰,۰۰۰\nقیمت هر گرم ۴,۸۰۱,۷۸۴\nمقدار ۹ گرم\nکارمزد گرمی ۲ گرم");
    truth(invalid.netQuantity.isEmpty());
    AssetReceiptParser.Result noTracking=AssetReceiptParser.parse("شماره بیمه نامه ۱۲۸۶۶۲۴۱\nمبلغ ۷۰٬۰۰۰٬۰۰۰");
    eq(noTracking.tracking,"");
    System.out.println("PASS: "+tested+" receipt-parser checks");
  }
}
