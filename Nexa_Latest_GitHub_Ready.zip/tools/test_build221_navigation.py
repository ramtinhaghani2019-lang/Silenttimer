"""Build 221: one-tap module directory + flat-first activity history.
Static guards complement real Android emulator regression, not replace it.
"""
from pathlib import Path
import xml.etree.ElementTree as ET
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/example/silenttimer'
source=lambda name:(j/name).read_text(encoding='utf-8')
modules=source('ModulesCatalog.java')
page=source('ModulesActivity.java')
history=source('HistoryActivity.java')
main=source('MainActivity.java')
quick=source('QuickAddActivity.java')
ui=source('UiKit.java')
assert modules.count('new Item(')==22
assert 'FeatureSearch.matches(item.title,item.aliases,GROUPS[item.group],query)' in modules
assert 'Collections.unmodifiableList(result)' in modules
assert 'settings' not in modules.lower() or 'SettingsActivity.class' in modules
assert 'ModulesActivity.class' in main
assert 'ModulesActivity.class' in quick
assert 'v->navigate(TimelineActivity.class)' in quick
assert 'String[] labels={"خانه", "امروز", "ثبت سریع", "خط زمانی"}' in ui
assert 'UiKit.bottomNav(this,-1' in page
assert 'setContentDescription("جست‌وجوی بخش‌های نکسا")' in page
assert 'onSaveInstanceState' in page
assert 'matched.sort((a,b)->Long.compare(b.time,a.time))' in history
assert 'if(!grouped)' in history
assert 'visibleLimit+=60' in history and 'Math.min(visibleLimit,matched.size())' in history
assert 'history_manage_221' in history and 'clearHistory' in history
assert 'history_metrics_221' in history
assert 'onSaveInstanceState(Bundle out)' in history
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
ET.fromstring(manifest)
assert '<activity android:name=".ModulesActivity" android:exported="false" />' in manifest
assert 'versionCode 223' in (root/'app/build.gradle').read_text()
assert 'versionName "5.4.201"' in (root/'app/build.gradle').read_text()
assert 'build221_moduleDirectoryProvidesAllRoutesAndUsefulPersianSearch' in (root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
print('PASS: directory, 22 routed modules, RTL/search, history, manifest, accessibility and regression hooks')
