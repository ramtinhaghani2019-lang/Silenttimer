#!/usr/bin/env python3
"""Source contracts for OCR safety and partial import in Build 240."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
main=ROOT/'app/src/main/java/com/example/silenttimer'
activity=(main/'AssetsActivity.java').read_text(encoding='utf-8')
ocr=(main/'AssetReceiptOcr.java').read_text(encoding='utf-8')
fusion=(main/'AssetReceiptFieldFusion.java').read_text(encoding='utf-8')
plan=(main/'AssetReceiptImportPlan.java').read_text(encoding='utf-8')
gradle=(ROOT/'app/build.gradle').read_text(encoding='utf-8')
checks={
 'real_version': 'versionCode 240' in gradle and 'versionName "5.4.218"' in gradle,
 'no_blanket_rejection': 'if(!AssetReceiptParser.verifiedForAutomaticImport(receipt))' not in activity,
 'trusted_numeric_fields_only': 'plan.trusted' in activity and 'AssetReceiptImportPlan.evaluate(receipt,receiptExpectedAssetType)' in activity,
 'per_field_proofs': 'amountPriceGross' in plan and 'weightedFee' in plan and 'rialFee' in plan,
 'no_fabricated_date': 'receiptDateNeedsReview[0]' in activity and 'date.performClick();return;' in activity,
 'no_reuse_draft_financial_data': 'amount.setText("");buy.setText("");fee.setText("");paid.setText("")' in activity,
 'do_not_scan_into_existing_purchase': 'if(current!=null)scanReceipt.setVisibility(View.GONE)' in activity,
 'multi_layout_rows': 'new int[]{0,2}' in ocr and 'new int[]{2,0}' in ocr,
 'localized_numeric_ocr': 'tessedit_char_whitelist' in ocr and 'thresholdForDigits' in ocr,
 'multi_pass_bounded': 'LIMIT=2048' in fusion,
 'no_external_receipt_upload': 'new Thread(' in ocr and 'http://' not in ocr and 'https://' not in ocr,
 'no_auto_save_from_image': 'NexaStore.addAsset' not in ocr and 'NexaStore.addAsset' not in plan,
}
for name,valid in checks.items():
    print(('PASS' if valid else 'FAIL')+': '+name)
if not all(checks.values()):raise SystemExit(1)
