"""Build 194 compatibility source guard; not a replacement for Android instrumentation."""
from pathlib import Path
base=Path(__file__).resolve().parents[1]
def source(name):return (base/'app/src/main/java/com/example/silenttimer'/name).read_text()
checks={
 'Build 199': 'versionCode 224' in (base/'app/build.gradle').read_text(),
 'Home main scroll': 'attachHomeContent(screen,sc,bottom,bp)' in source('MainActivity.java'),
 'All features directory': 'ModulesActivity.class' in source('MainActivity.java') and 'FeatureSearch.matches' in source('ModulesCatalog.java'),
 'All destinations available': 'String[] directoryIcons()' in source('FeatureEmoji.java') and 'NexaOutlineIcon icon=new NexaOutlineIcon(this,iconKind(item),color)' in source('ModulesActivity.java'),
 'Readable repeat': 'setSingleChoiceItems(OPTIONS' in source('RepeatIntervalPicker.java'),
 'Create recipient inline': 'DirectoryPicker.seller(this' in source('BillsActivity.java'),
 'Create card inline': 'DirectoryPicker.card(this' in source('BillsActivity.java'),
 'Card validates 16 digits': 'isValid(raw)' in source('PaymentCardEditor.java'),
 'Encrypted PAN': 'AES/GCM/NoPadding' in source('PaymentCardSecrets.java'),
 'No plain PAN in card JSON': 'o.put("number"' not in source('NexaStore.java').split('public static final class BankCard')[1].split('public static final class ShoppingReceipt')[0],
 'Copy action': 'PaymentCardSecrets.copy(this,x.bankCardId)' in source('BillsActivity.java'),
 'Editor scroll': 'setView(formScroll)' in source('BillsActivity.java'),
 'Forecast method defined': 'private void renderForecast(List<NexaStore.BillItem> bills)' in source('BillsActivity.java'),
 'Payment actions method defined': 'private void showBillActions(NexaStore.BillItem x)' in source('BillsActivity.java'),
 'Polish on first visit': 'boolean first=POLISHED.add(v);' in source('UiKit.java'),
}
for label,ok in checks.items():print(('PASS' if ok else 'FAIL')+': '+label)
assert all(checks.values())
