"""Local source-structure regression guard for the blank home screen (Build 180)."""
from pathlib import Path
import re

root=Path(__file__).resolve().parents[1]
source=(root/'app/src/main/java/com/example/silenttimer/MainActivity.java').read_text()
android_test=(root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
gradle=(root/'app/build.gradle').read_text()

checks={
    'Dashboard ScrollView attached in MainActivity.build':
        'attachHomeContent(screen,sc,bottom,bp);' in source,
    'Dashboard attaches before bottom navigation':
        bool(re.search(r'screen\.addView\(sc,\s*new LinearLayout\.LayoutParams\([\s\S]*?0,1f\)\);\s*screen\.addView\(bottom,bottomParams\);',source)),
    'Dashboard cannot be empty': 'sc.getChildCount()==0' in source,
    'Non-empty dashboard Android regression test included':
        'mainHomeDashboard_isAttachedAndScrollableAboveBottomNavigation' in android_test
        and 'assertSame("Dashboard must be first",content,screen.getChildAt(0))' in android_test,
    'Adaptive dashboard source is present': 'HomeUi.shouldStack(this)' in source and 'HomeUi.panel(this,true)' in source,
    'All four shortcuts remain': all(x in source for x in ['TodayActivity.class','RemindersActivity.class','LedgerActivity.class','NexaListActivity.class']),
    'Version bump present': 'versionCode 197' in gradle and 'versionName "5.4.175"' in gradle,
}
for desc,ok in checks.items():
    print(('PASS' if ok else 'FAIL')+': '+desc)
if not all(checks.values()):
    raise SystemExit('FAIL: home dashboard regression guard')
