"""Non-emulator regression contracts for timer restore and charger unplug."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'app/src/main/java/com/example/silenttimer'
read=lambda fn:(p/fn).read_text()
service=read('SilentTimerService.java')
battery=read('BatteryAlertManager.java')
recovery=read('TimerExpiryRecovery.java')
receiver=read('TimerEndReceiver.java')
audio=read('NexaAudioController.java')
checks={
 'deadline receiver attempts restore before starting service':receiver.index('TimerExpiryRecovery.restoreIfDue(context)')<receiver.index('context.startForegroundService(service)'),
 'expired timer keeps session if restoration fails':'TimerExpiryPolicy.mayClearSession(restorePreviousMode, modeRestored)' in service and 'TimerExpiryRecovery.scheduleRetry(this)' in service,
 'receiver confirms ringer before deleting timer':recovery.index('getRingerMode(context) != previous')<recovery.index('AppPrefs.clearTimer(context)'),
 'audio mode setter verifies applied state':'return audioManager.getRingerMode() == mode;' in audio,
 'service observes immediate charger unplug': 'filter.addAction(Intent.ACTION_POWER_DISCONNECTED)' in service,
 'unplug stops battery alarm only':'NexaAudioController.stopOwner(BatteryAlarmActionReceiver.OWNER_CHARGE)' in battery,
 'battery level missing does not prevent stopping charge alert': battery.index('if(!charging)onChargerDisconnected(c);')<battery.index('if(level<0){TheftGuardManager.onBatteryChanged(c,i);return;}'),
 'notifications for expired restore failure':'بازیابی صدای گوشی نیازمند بررسی است' in service,
 'retry timer has a wake-up pending intent':'am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP' in recovery,
 'timer rescheduled after boot or time change':'TimerExpiryRecovery.reschedulePending(context)' in read('BootReceiver.java'),
 'unplugged sticky state forced unplugged':'sticky.putExtra(android.os.BatteryManager.EXTRA_PLUGGED, 0)' in read('PowerConnectionReceiver.java'),
 'critical emulator regression tests added':'build189_expiryRecoveryOnlyOwnsRealDueTimer' in (root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text(),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
if not all(checks.values()):raise SystemExit('FAILED CRITICAL REGRESSION CONTRACT')
