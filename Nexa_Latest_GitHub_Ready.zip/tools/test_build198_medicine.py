"""Build198 UX contracts; guarantee original medication lifecycle and no writes in visual components."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
a=root/'app/src/main/java/com/example/silenttimer'
m=(a/'MedicineActivity.java').read_text(encoding='utf8')
u=(a/'NexaMedicineUi.java').read_text(encoding='utf8')
p=(a/'MedicineOverviewPolicy.java').read_text(encoding='utf8')
assert 'NexaMedicineUi.metrics(this,active,overdue,soon)' in m
assert 'String[] labels={"داروی فعال","عقب‌افتاده","در ۲۴ ساعت آینده"}' in u
assert 'showMedicineFilters();' in m and 'NexaMedicineUi.filter(this,filters[i],medicineFilter==i)' in m
assert all('"'+x+'"' in m for x in ['همه','فعال','عقب‌افتاده','پایان‌یافته'])
assert 'NexaMedicineUi.medicineCard(this,state)' in m and 'NexaMedicineUi.state(this,state)' in m
assert 'UiKit.subtlePastCard(c)' in u and 'HomeUi.shouldStack(this)' in m
assert 'HorizontalScrollView scroll=' in m and 'UiKit.dp(this,44)' in m
assert 'static HorizontalScrollView metrics(' in u and 'UiKit.dp(c,84)' in u
assert 'NexaMedicineUi.formHeading(this,"۳. زمان‌بندی و مدت مصرف")' in m
for fragment in [
    'NexaStore.medicines(this)','reconcileNextDose(m);',
    'MedicineScheduler.cancel(this,m.id)', 'MedicineScheduler.schedule(this,m)',
    'NexaStore.addMedicine(this,m)','NexaStore.updateMedicine(this,m)',
    'NexaStore.removeMedicine(this,m.id)', 'NexaStore.medicineDoseLogsFor(this,m.id)',
    'NexaStore.addMedicineDoseLog(this,log)', 'NexaStore.clearMedicineDoseLogs(this,m.id)',
    'showMedicineReport()', 'MedicineStats.summarize(m,logs,now,7)',
    'PersianDatePickerHelper.pickDateTime(this,', 'TodayNotificationManager.refresh(this)',
    'getBooleanExtra("quick_add",false)', 'showDoctorDirectory(d->',
    'if(baselineChanged){', 'latestEffectiveDoseBase(m.id, first)',
    'if(m.active)MedicineScheduler.schedule(this,m);']:
    assert fragment in m,fragment
for illegal in ['NexaStore','MedicineScheduler','AppPrefs','SharedPreferences','AlarmManager']:
    assert illegal not in u,illegal
assert 'if(!active)return FINISHED;' in p
assert 'if(nextDoseMillis<=now)return OVERDUE;' in p
assert 'nextDoseMillis-now<=DAY?SOON:PLANNED' in p
assert 'versionCode 222' in (root/'app/build.gradle').read_text()
print('PASS: medicine UI preview, filter and original dose scheduling/CRUD preserved')
