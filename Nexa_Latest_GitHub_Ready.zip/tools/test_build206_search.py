"""Build 206: static, read-only, navigation and version gates (not Android CI)."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
java=root/'app/src/main/java/com/example/silenttimer'
s=(java/'SearchActivity.java').read_text()
l=(java/'LedgerActivity.java').read_text()
p=(java/'SearchQueryPolicy.java').read_text()
b=(root/'app/build.gradle').read_text()
r=(root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'versionCode 225' in b and 'versionName "5.4.203"' in b
assert 'for(NexaStore.LedgerEntry entry:NexaStore.ledgerEntries(this))' in s
assert 'for(NexaStore.LedgerParty p:NexaStore.ledgerParties(this))' in s
assert 'target.putExtra(LedgerActivity.EXTRA_OPEN_PARTY_ID,p.id)' in s
assert 'SearchQueryPolicy.matches(' in s and 'SearchQueryPolicy.score(' in s
assert 'p.phone' in s and 'partyNotes' in s
assert 'String info=balance==0?' in s and 'p.phone' not in s[s.index('String info=balance==0?'):s.index('add("👤 "')]
assert 'EXTRA_OPEN_PARTY_ID' in l and 'showParty(p); // Navigational read only' in l
assert all(x not in p for x in ('NexaStore.', 'android.', 'SharedPreferences', 'upsert', 'remove'))
assert 'build206_universalSearchIncludesLedgerAndNormalizesPersianSafely' in r
print('PASS Build206 version/search/ledger navigation/privacy static checks')
