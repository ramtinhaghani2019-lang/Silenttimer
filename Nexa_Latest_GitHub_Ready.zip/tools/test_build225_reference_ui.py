"""Build 225 source-level visual contract; Android builds remain authoritative."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
main=(root/'app/src/main/java/com/example/silenttimer/MainActivity.java').read_text()
mod=(root/'app/src/main/java/com/example/silenttimer/ModulesActivity.java').read_text()
home=(root/'app/src/main/java/com/example/silenttimer/HomeUi.java').read_text()
aurora=(root/'app/src/main/java/com/example/silenttimer/NexaAuroraDrawable.java').read_text()
gradle=(root/'app/build.gradle').read_text()
assert 'versionCode 225' in gradle and 'versionName "5.4.203"' in gradle
for name in ['دریافت','پرداخت','طلب من','بدهی من']:
    assert 'HomeUi.balanceCard(this,"'+name+'"' in main
for kind in ['RECEIPT','PAYMENT']:
    assert '"'+kind+'".equals(entry.kind)' in main
for target in ['TodayActivity.class','RemindersActivity.class','QuickAddActivity.class','ModulesActivity.class','SilentTimerService.class']:
    assert target in main,target
assert main.index('root.addView(financeGrid')<main.index('root.addView(focus')
assert '((availableDp>=326f && fontScale<1.22f)?3:2)' in mod
assert 'if(columns!=3)tile.addView(details' in mod
assert 'Path ribbon=new Path();' in aurora
assert 'headerAction(Context c' in home
assert 'miniShortcut(Context c' in home
assert 'addFinancialPair(financeGrid,receiptCard,paymentCard);' in main
assert len(__import__('re').findall(r'new Item\(', (root/'app/src/main/java/com/example/silenttimer/ModulesCatalog.java').read_text()))==22
print('PASS: Build 225 references real records and preserves 22 destinations, adaptive grid and timer')
