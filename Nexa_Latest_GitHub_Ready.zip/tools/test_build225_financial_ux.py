"""Build225: UI navigation, search/filter and paging structure checks (not Android CI)."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'app/src/main/java/com/example/silenttimer'
b=(p/'BillsActivity.java').read_text()
l=(p/'LedgerActivity.java').read_text()
policy=(p/'BillListPolicy.java').read_text()
ledger_policy=(p/'LedgerPartyFilterPolicy.java').read_text()
gradle=(root/'app/build.gradle').read_text()
assert 'versionCode 226' in gradle and 'versionName "5.4.204"' in gradle
assert 'filterGrid.setOrientation(LinearLayout.VERTICAL)' in b
assert 'for(int rowIndex=0;rowIndex<2;rowIndex++)' in b
assert 'billSearch.addTextChangedListener' in b
assert 'BillListPolicy.matchesQuery(' in b
assert 'displayLimit+=12;render()' in b
assert 'out.putInt("bills.scroll"' in b
assert 'forecastExpanded=b.getBoolean(' in b
assert 'LedgerPartyFilterPolicy.matches(partyFilter,bal)' in l
assert 'LedgerPartyFilterPolicy.matchesQuery(' in l
assert 'partyDisplayLimit+=20;render()' in l
assert 'state.putString("ledger.partyFilter"' in l
assert 'String balanceText=formatUi("خالص حساب‌ها:' in l
assert 'static boolean matchesQuery' in policy and 'SearchQueryPolicy.matches' in policy
assert 'static boolean matchesQuery' in ledger_policy and 'balance>0' in ledger_policy and 'balance<0' in ledger_policy
for fn in ['NexaStore.java','AssetFinanceEngine.java','SilentTimerService.java','ReminderScheduler.java']:
    assert (p/fn).exists(),fn
reg=(root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
assert 'build225_financialSearchAndBalanceFiltersPreserveSemantics' in reg
print('PASS Build225: two finance screens, accessible fixed filters, Persian search, paging and state preservation')
