"""Build 202 visual guard: profiles, schedules, focus and emergency SMS routing."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
src=root/'app/src/main/java/com/example/silenttimer'
p=(src/'ProfilesActivity.java').read_text()
h=(src/'SilentHubActivity.java').read_text()
u=(src/'NexaFocusUi.java').read_text()
g=(root/'app/build.gradle').read_text()
assert 'versionCode 205' in g and 'versionName "5.4.183"' in g
assert all(k in p for k in ['NexaFocusUi.metrics(this,allProfiles.size(),active,allSchedules.size())',
    'NexaFocusUi.record(', 'NexaFocusUi.status(', 'NexaFocusUi.empty(',
    'profileDialog(p)', 'scheduleDialog(s)', 'NexaStore.addProfile(this,p)',
    'NexaStore.updateProfile(this,p)', 'NexaStore.removeProfile(this,p.id)',
    'NexaStore.addSchedule(this,s)', 'NexaStore.updateSchedule(this,s)',
    'NexaStore.removeSchedule(this,s.id)', 'WeeklyScheduler.cancel(this,s.id)',
    'WeeklyScheduler.scheduleNext(this,s)', 'AppPrefs.setAllowedCallsEnabled(this,p.allowedCalls)',
    'SilentTimerService.ACTION_START', 'AudioManager.RINGER_MODE_SILENT'])
assert all(k in h for k in ['SmartSilentActivity.class','AllowedCallsActivity.class','ProfilesActivity.class',
    'SettingsActivity.class', 'NexaStore.smsEnabled(this)', 'refreshOverview()'])
assert all(k in u for k in ['setHorizontalScrollBarEnabled(false)',
    'UiKit.financialMetric(', 'setMinimumHeight(UiKit.dp(c,116))',
    'setContentDescription(', 'setMinHeight(UiKit.dp(c,34))'])
print('PASS: Build 202 focus design, touch targets, timer and scheduler routes preserved')
