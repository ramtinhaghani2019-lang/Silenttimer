"""Build 196: docs/home UI only, preserving recurrence, alarms, data and filters."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
a=root/'app/src/main/java/com/example/silenttimer'
d=(a/'DocsActivity.java').read_text(encoding='utf8')
h=(a/'HomeCareActivity.java').read_text(encoding='utf8')
u=(a/'NexaCareUi.java').read_text(encoding='utf8')
assert 'NexaCareUi.metrics(this,' in d and 'NexaCareUi.metrics(this,' in h
assert 'NexaCareUi.record(this,' in d and 'NexaCareUi.record(this,' in h
assert 'NexaCareUi.state(this,' in d and 'NexaCareUi.state(this,' in h
assert 'NexaCareUi.filter(this,item,item.equals(filter))' in d
for item in ['"همه"','"منقضی"','"۳۰ روز"','"معتبر"']:assert item in d,item
for item in ['"همه سرویس‌ها"','"موعد گذشته"','"تا ۳۰ روز آینده"','"بعداً"']:assert item in h,item
for s in ['NexaStore.addDocument(this,x)','NexaStore.updateDocument(this,x)',
          'NexaStore.removeDocument(this,x.id)','LinkedReminderHelper.upsert(','LinkedReminderHelper.remove(',
          'new RepeatIntervalPicker(this,box','new AlertEditor(this,box','PersianDatePickerHelper.pickDateTime']:
 assert s in d,s
for s in ['NexaStore.addHomeItem(this,x)','NexaStore.updateHomeItem(this,x)',
          'NexaStore.removeHomeItem(this,x.id)','LinkedReminderHelper.upsert(','LinkedReminderHelper.remove(',
          'new RepeatIntervalPicker(this,box','new AlertEditor(this,box','PersianDatePickerHelper.pickDateTime']:
 assert s in h,s
assert 'HomeUi.shouldStack(c)' in u
assert 'UiKit.subtlePastCard(c)' in u
assert 'UiKit.dp(c,44)' in u
assert 'versionCode 221' in (root/'app/build.gradle').read_text()
print('PASS: docs and household lifecycle UI, all original filters, recurrence, alerts and CRUD preserved')
