"""Build200 keeps all existing destinations, data sources and private search boundaries."""
from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'app/src/main/java/com/example/silenttimer'
quick=(p/'QuickAddActivity.java').read_text(encoding='utf8')
search=(p/'SearchActivity.java').read_text(encoding='utf8')
ui=(p/'NexaActionUi.java').read_text(encoding='utf8')
policy=(p/'SearchDisplayPolicy.java').read_text(encoding='utf8')
for target in ['SearchActivity','TimelineActivity','ReminderEditActivity','MedicineActivity',
               'NexaListActivity','CaseActivity','AssetsActivity','DocsActivity','BillsActivity',
               'HomeCareActivity','GarageActivity']:
    assert target+'.class' in quick, target
for extra in ['"shopping"','"todo"','"bool"', 'intent.putExtra("quick_add",quick)', 'intent.putExtra("quick_add",true)']:
    assert extra in quick,extra
assert 'NexaActionUi.tile(' in quick and 'private void pair(' in quick
for dataset in ['NexaStore.reminders(this)','NexaStore.medicines(this)','NexaStore.services(this)',
 'NexaStore.vehicles(this)','NexaStore.shoppingItems(this)','NexaStore.todos(this)',
 'NexaStore.cases(this)','NexaStore.vault(this)','NexaStore.assets(this)',
 'NexaStore.documents(this)','NexaStore.bills(this)','NexaStore.homeItems(this)']:
    assert dataset in search,dataset
for key in ['i.putExtra("edit_id",r.id)', 'i.putExtra("id",v.id)',
 'جزئیات محرمانه در جستجو نمایش داده نمی‌شود','new Intent(this,VaultActivity.class)',
 'Collections.sort(hits,','SearchDisplayPolicy.countLabel',
 'NexaActionUi.categoryChip', 'NexaActionUi.result','filterBar.removeAllViews()']:
    assert key in search,key
for key in ['minHeight','build','group']:
    pass
assert 'setMinimumHeight(UiKit.dp(c,112))' in ui
assert 'setMinimumHeight(UiKit.dp(c,82))' in ui
assert 'setMinHeight(UiKit.dp(c,44))' in ui
assert 'compare(int score1,int order1,int score2,int order2)' in policy
assert 'versionCode 202' in (root/'app/build.gradle').read_text()
assert 'versionName "5.4.180"' in (root/'app/build.gradle').read_text()
print('PASS: Build200 action hub, 12 search sources, privacy and route preservation')
