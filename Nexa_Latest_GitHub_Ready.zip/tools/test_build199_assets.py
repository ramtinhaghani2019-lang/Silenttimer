"""Build 199 portfolio UI contract; all finance and market operations retained."""
from pathlib import Path
base=Path(__file__).resolve().parents[1]
p=base/'app/src/main/java/com/example/silenttimer'
a=(p/'AssetsActivity.java').read_text(encoding='utf8')
u=(p/'NexaAssetsUi.java').read_text(encoding='utf8')
r=(p/'AssetOverviewPolicy.java').read_text(encoding='utf8')
for fragment in ['NexaAssetsUi.hero(this)','NexaAssetsUi.metrics(this,',
  'NexaAssetsUi.filter(this,labels[i],assetFilter==i)',
  'AssetOverviewPolicy.matches(assetFilter,cost(x),value(x),x.alertTarget>0||x.alertAtBuy)',
  'NexaAssetsUi.purchaseCard(this,p)','NexaAssetsUi.profitBadge(this,',
  'NexaAssetsUi.formHeading(this,"۴. تاریخ و توضیحات")',
  'UiKit.collapsible(this,"asset_breakdown_199"',
  'NexaStore.assets(this)', 'AssetFinanceEngine.totalOpenCost(data)',
  'AssetFinanceEngine.totalMarketValue(data)', 'AssetFinanceEngine.totalRealized(data)',
  'NexaStore.updateAsset(this,x)', 'NexaStore.removeAsset(this,x.id)',
  'AssetFinanceEngine.sell(x,q,p,System.currentTimeMillis())',
  'PriceMonitorReceiver.schedule(this)', 'showMarketHistory()',
  'showPriceAlertManager()', 'editGroupMarketPrice(vendor.getKey(),vendor.getValue())',
  'NexaStore.marketRefreshMode(this)', 'PersianDatePickerHelper.pickDateTime(this,']:
    assert fragment in a,fragment
for txt in ['"همه","سودده","زیان‌ده","هشدار فعال"',
  '"۱. نوع دارایی و فروشنده"','"۲. مقدار و ارزش خرید"',
  '"۳. قیمت روز و هشدارها"','"۴. تاریخ و توضیحات"']:
    assert txt in a,txt
assert 'HorizontalScrollView' in u and 'UiKit.financialMetric' in u and 'UiKit.heroSurface' in u
assert 'new LinearLayout.LayoutParams(UiKit.dp(c,186),-2)' in u
for f in ['NexaStore','AssetFinanceEngine','MarketDataHelper','PriceMonitorReceiver','MedicineScheduler','SharedPreferences','AlarmManager']:
    assert f not in u,f
assert 'static boolean matches(' in r and 'if(filter==GAIN)' in r and 'if(filter==LOSS)' in r and 'if(filter==ALERT)' in r
assert 'versionCode 204' in (base/'app/build.gradle').read_text()
assert 'versionName "5.4.182"' in (base/'app/build.gradle').read_text()
print('PASS: Build199 portfolio visual flow, full finance CRUD and pricing lifecycle')
