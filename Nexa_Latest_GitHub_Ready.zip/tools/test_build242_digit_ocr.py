#!/usr/bin/env python3
"""Build 242 source contracts; no private user receipt images are stored."""
from pathlib import Path
import gzip,struct
base=Path(__file__).resolve().parents[1]
src=(base/'app/src/main/java/com/example/silenttimer/AssetReceiptOcr.java').read_text()
reader=(base/'app/src/main/java/com/example/silenttimer/KarizmaDigitReader.java').read_text()
gradle=(base/'app/build.gradle').read_text()
model=base/'app/src/main/assets/karizma_digits_v1.dat.gz'
blob=gzip.decompress(model.read_bytes())
count=struct.unpack('>H',blob[:2])[0]
checks={
 'version_242':'versionCode 242' in gradle and 'versionName "5.4.220"' in gradle,
 'provider_numeric_reader_called':'KarizmaDigitReader.scan(source,w,h,templates)' in src,
 'only_verified_import':'AssetReceiptImportPlan.evaluate(isolated,isolated.assetType)' in src,
 'no_generic_override_of_proven_values':'if(!AssetReceiptParser.financiallyConsistent(result)){' in src,
 'date_not_guessed':'scan.hasDate' in src and 'receiptDateNeedsReview[0]' in (base/'app/src/main/java/com/example/silenttimer/AssetsActivity.java').read_text(),
 'net_quantity_from_verified_balance':'scan.balanceDeltas' in src and 'new java.math.BigDecimal("0.000001")' in src,
 'recognizer_local_only':'http://' not in reader and 'https://' not in reader,
 'reasonable_glyph_bank':100<=count<=300 and len(blob)==2+count*(3+32*40),
 'private_images_not_embedded':not list((base/'app/src/main/assets').glob('*.jpg')) and not list((base/'app/src/main/assets').glob('*.png')),
}
for k,v in checks.items():print(('PASS' if v else 'FAIL')+': '+k)
if not all(checks.values()):raise SystemExit(1)
