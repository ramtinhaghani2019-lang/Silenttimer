from pathlib import Path
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/example/silenttimer'
o=(j/'AnnualOccasionsActivity.java').read_text()
m=(j/'MedicineActivity.java').read_text()
l=(j/'NexaListActivity.java').read_text()
s=(j/'SettingsActivity.java').read_text()
# New UI hierarchy must preserve the original persisted CRUD, navigation, and schedules.
for snippet in ('OccasionDirectoryPolicy.select(all,query,filter,now)', 'OccasionStore.save(this,e)',
                'OccasionScheduler.schedule(this,e)', 'OccasionStore.delete(this,e.id)',
                'HomeUi.panel(this,false)', 'Button manage=UiKit.iconButton(this,'):
    assert snippet in o,snippet
assert 'Button edit=UiKit.iconButton(this,' in o
assert 'card.setContentDescription("مناسبت "' in o
assert 'state.putString("occasion_filter",filter)' in o
for snippet in ('NexaMedicineUi.metrics(this,active,overdue,soon)', 'reconcileNextDose(m);',
                'MedicineScheduler.schedule(this,m)', 'out.putInt("medicine_display_filter",medicineFilter)',
                'HomeUi.compactGridNeedsStack(this)', 'showMedicineReport()'):
    assert snippet in m,snippet
assert 'UiKit.featureHero(this,"medicine"' not in m
for snippet in ('shoppingTabButton.setSelected(tab==0)', 'todoTabButton.setSelected(tab==1)',
                'NexaStore.shoppingLists(this)', 'NexaStore.todos(this)',
                'NexaStore.updateTodo(this,x)', 'HomeUi.panel(this,false)',
                'exportListDialog("کارهای روزانه",todoEntries(),true)'):
    assert snippet in l,snippet
assert 'settingsSearch.setOnEditorActionListener' in s
assert 'keyboard.hideSoftInputFromWindow(settingsSearch.getWindowToken(),0)' in s
print('PASS: premium multi-screen UX & existing data paths')
