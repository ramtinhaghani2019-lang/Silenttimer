"""Build 231 static behavioral contract; Android emulator remains authoritative for actual rendering."""
from pathlib import Path
r=Path(__file__).resolve().parents[1]
src=r/'app/src/main/java/com/example/silenttimer'
a=(src/'AssetsActivity.java').read_text()
f=(src/'AssetFinanceEngine.java').read_text()
e=(src/'AssetGroupQuoteEngine.java').read_text()
st=(src/'NexaStore.java').read_text()
c=(src/'MarketHistoryView.java').read_text()
t=(r/'app/src/androidTest/java/com/example/silenttimer/AssetGroupQuoteRegressionTest.java').read_text()
b=(r/'app/build.gradle').read_text()
assert 'versionCode 231' in b and 'versionName "5.4.209"' in b
for key in ('quoteUpdatedAt','o.put("quoteUpdatedAt",quoteUpdatedAt)','o.optLong("quoteUpdatedAt",0)'):
    assert key in st,key
for key in ('boolean belongs(', 'int applyQuote(', 'if(matched==0)return 0;',
            'x.currentUnitPrice=quote;', 'x.autoPrice=false;', 'x.quoteUpdatedAt=asOf;'):
    assert key in e,key
for key in ('editGroupMarketPrice(g.getKey(),members)', 'NexaStore.saveAssets(this,latest)',
           'AssetGroupQuoteEngine.applyQuote(latest,groupName,newQuote',
           'PriceMonitorReceiver.schedule(this)', 'سود/زیان باز:', 'جمع سود/زیان صندوق:',
           'میانگین بهای تمام‌شده هر واحد:', 'قیمت روز هر واحد:',
           'percent(p,cost(x))', 'totalReturnPercent(data)', 'totalInvestedCost(members)',
           'onPointSelectedListener', 'setSeries(vals,times)', 'renderChips[0].run()',
           'marketHeaderFreshness', 'compactRefresh.setOnClickListener'):
    # callback for chart uses chart.set... not raw on...
    if key=='onPointSelectedListener': key='chart.setOnPointSelectedListener'
    assert key in a,key
for key in ('totalInvestedCost(', 'totalReturnPercent(', 'x.saleProceeds-x.realizedProfit'):
    assert key in f,key
for key in ('class MarketHistoryView','setSeries(', 'new LinearGradient(', 'onTouchEvent(', 'getWidth()'):
    assert key in c,key
for key in ('sharedFundQuoteRevaluesEveryLotWithoutChangingPurchaseHistory',
            'soldLotsRetainRealizedProfitAndOnlyRemainingUnitsRevalue',
            'invalidQuoteNeverModifiesAnyLot'):
    assert key in t,key
assert '"#,##0.##"' in (src/'PersianFinancialDisplay.java').read_text()
print('PASS Build231 contract: persistent quote, atomic group updates, ROI, chart, refresh, existing actions')
