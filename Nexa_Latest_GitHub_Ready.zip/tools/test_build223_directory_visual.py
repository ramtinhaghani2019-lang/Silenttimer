"""Build 223 UX regressions: do not reintroduce clipped chips or meaningless pictograms.
Pure source checks complement, never replace, emulator/device screenshot review.
"""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1]
j=root/'app/src/main/java/com/example/silenttimer'
p=(j/'ModulesActivity.java').read_text()
u=(j/'UiKit.java').read_text()
icon=(j/'NexaOutlineIcon.java').read_text()
g=(root/'app/build.gradle').read_text()
assert 'versionCode 224' in g and 'versionName "5.4.202"' in g
assert 'HorizontalScrollView' not in p
assert 'int[][] indexes={{0,1,2},{3,4}}' in p
assert 'SHORT_GROUPS' in p and 'setText(SHORT_GROUPS[next])' in p
assert 'new LinearLayout.LayoutParams(0,UiKit.dp(this,42),1f)' in p
assert 'filters.addView(row,UiKit.matchWrap(this,0,6))' in p
assert 'section.addView(moduleRow(item)' in p
assert 'new NexaOutlineIcon(this,iconKind(item),color)' in p
assert 'line.setMinimumHeight(UiKit.dp(this,62))' in p
assert 'search.setTag("nexa_directory_search_field")' in p
assert '"nexa_directory_search_field".equals(e.getTag())' in u
assert 'String[] labels={"خانه", "امروز", "ثبت سریع", "خط زمانی"}' in u
assert 'NexaOutlineIcon picture=new NexaOutlineIcon(c,symbol' in u
assert 'tab.setSelected(selected)' in u and 'dp(c,60),1f' in u
assert 'setContentDescription("باز کردن "+item.title)' in p
assert 'startActivity(new Intent(this,item.destination))' in p
assert 'void onSaveInstanceState' in p
assert 'class NexaOutlineIcon extends View' in icon
assert icon.count('case "') >= 24
assert not re.search(r'\b(?:LinearLayout|ScrollView)\s+(\w+)\s*=.*\n.*?\1\.setMinHeight\(',p)
assert 'build223_directoryUsesRealIconsAndCompactSharedNavigation' in (root/'app/src/androidTest/java/com/example/silenttimer/NexaRegressionTest.java').read_text()
print('PASS Build223: five fully visible category filters, compact grouped rows, native icons, accessible nav and search')
