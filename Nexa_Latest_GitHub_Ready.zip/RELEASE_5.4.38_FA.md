# Nexa 5.4.38 — Build 60

مبنای توسعه: 5.4.37 / Build 59 Stable (Build و Regression سبز)

## بسته تغییرات
- ارتقای نسخه به 5.4.38 / Build 60 و هماهنگ‌سازی Regression نسخه.
- تثبیت Notification Engine مرکزی بدون تغییر رفتار سالم Medicine/Reminder.
- انتقال کانال Missed Call به NotificationChannelHelper مرکزی با حفظ شناسه قبلی و تنظیمات کاربر.
- تعریف کانال مستقل Reminder Core.
- تعریف کانال مستقل Battery Alarm برای Battery Guard.
- تعریف کانال مستقل Low Battery.
- تعریف کانال مستقل Theft Alarm.
- تعریف کانال مستقل Security.
- همه کانال‌های Core با Lock-screen visibility عمومی و Importance بالا ساخته می‌شوند.
- جلوگیری از بازسازی/بازنویسی کانال موجود؛ تنظیمات قبلی کاربر حفظ می‌شود.
- Regression جدید برای وجود، جدابودن، Priority و Lock-screen visibility کانال‌های Core.
- Regression چند Missed Call و رفتار Lock Screen نسخه 5.4.37 بدون حذف حفظ شده است.

## تست
محیط فعلی Gradle executable ندارد؛ Build/Instrumentation نهایی باید توسط دو Workflow موجود GitHub انجام شود.
