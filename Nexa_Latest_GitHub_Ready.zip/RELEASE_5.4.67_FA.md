# Nexa 5.4.67 / Build 89 — Final Release Candidate

این نسخه مرحله Final Regression / Stabilization است و قابلیت جدیدی به محصول اضافه نمی‌کند.

- نسخه نهایی کاندید: 5.4.67 / Build 89
- Regression نسخه با Build واقعی همگام شد.
- Regression نهایی Backup/Restore عمومی اضافه شد و حفظ Vault محلی هنگام Restore کنترل می‌شود.
- Regression ثبت BootReceiver برای BOOT_COMPLETED و MY_PACKAGE_REPLACED اضافه شد تا بازیابی زمان‌بندی‌ها پس از Restart/Upgrade پوشش داده شود.
- Regression اعلان Android 13+ برای declaration مجوز POST_NOTIFICATIONS اضافه شد.
- قابلیت‌های Stable قبلی بدون بازطراحی یا حذف حفظ شده‌اند.

وضعیت Build/Regression نهایی باید توسط GitHub CI تأیید شود.
