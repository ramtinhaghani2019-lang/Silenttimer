# Nexa 5.4.206 / Build 228 — Professional Compact Forms & Fast Navigation

This source archive is cumulative: it retains the delivered Build 226 grouped medicine history and candidate Build 227 compact dashboard, and adds the following **real source changes**.

## Changes

- `UiKit`: shared RTL form labels, expandable optional fields that remain mounted and preserve text; more restrained card/dialog padding and reduced internal list padding while keeping previous touch-target minimum heights.
- `MedicineActivity`: show essential name, dose, interval, course duration, and first dose before optional physician/prescription metadata. Existing doctor data automatically opens the optional panel. Empty drug name now shows inline validation **without closing the form**.
- `LedgerActivity`: essential party name remains visible; telephone and notes are optional. Entry form shows transaction type, amount in tomans and date first, with notes, settlement reminder and recurrence in optional details. Existing advanced values remain visible on edit. Phone input has the phone keyboard type.
- `ModulesActivity`: last four visited sections appear as compact direct-access chips when browsing all sections; recent routes are stored only as destination class names, not sensitive form data. Search/category view retains its uncluttered directory.
- `SettingsActivity`: search also considers short descriptions; the outdated internal UI revision/debug label was removed.
- `ModuleRecentPolicy`: deterministic, duplicate-free, four-item retention; eight JVM assertions and a new emulator regression scenario added.

## Quality checks in the preparation environment

- 174 Java source files syntactically parsed without error.
- Eight dedicated Java assertions for recent module navigation passed.
- Existing instrumentation test suite preserved, with one new regression checking form-collapse content retention and recent navigation.
- ZIP integrity and absence of common private signing secrets checked.

## Remaining release gate

This is **source only**. GitHub Actions must build this ZIP and the Android emulator regression workflow must pass on the same new commit before describing the APK as verified or recommending it as a stable version.

## High-density, professional layout standard for every screen

1. **Main dashboard:** real balances and priority actions in the first viewport; no duplicated information or decorative banners taller than essential content.
2. **Today / timeline / reminders:** one chronological list with concise state badges; overdue and upcoming states distinguished; expanded event details on demand.
3. **Accounting / loans / assets:** amounts and units always explicit; money direction sign/color stable; transaction form starts with type, amount, date; optional notes and recurrence below disclosure.
4. **Medicines / appointments:** one drug per group, dose status and next reminder clear; individual historical doses accessible inside grouped details, never discarded.
5. **Vehicle / house:** summary first (next service, critical cost) followed by compact records, a single Add action, and collapsible advanced metadata.
6. **Documents / cases / vault:** subject, status and expiration or case date first; sensitive data masked where necessary; advanced actions behind explicit choices.
7. **Lists / occasions / shared directory:** one-row items with status and one primary action; secondary actions via details; consistent list filtering/search.
8. **Settings / onboarding:** searchable groups, only necessary access requests at moment of use, clear error recovery and undo/back affordances.
9. **Responsive and accessible:** support 320, 360, 393 dp and enlarged fonts; 48dp or larger touch targets, Persian RTL, numeric data LTR when appropriate.
10. **No feature loss:** preserve stable storage IDs, reminders/receivers, money calculation, medical dose logs, signing identity, and established deep links during layout updates.

This document is an implementation standard, **not** a claim that all 41 screens have been individually rebuilt or visually validated. Real-device screenshots and GitHub CI are still required.
