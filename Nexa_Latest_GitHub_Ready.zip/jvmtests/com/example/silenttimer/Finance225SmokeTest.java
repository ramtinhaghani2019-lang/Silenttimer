package com.example.silenttimer;
public final class Finance225SmokeTest {
    private static void ok(boolean value, String error){if(!value)throw new AssertionError(error);}
    public static void main(String[] args){
        ok(BillListPolicy.matchesQuery("قسط وام", "قسط", "خودرو", "وام"),"bill title search");
        ok(BillListPolicy.matchesQuery("قسط وام", "قسط", "شماره ۱۲۳۴", "1234"),"Persian numbers");
        ok(BillListPolicy.matchesQuery("قبض برق", "قبض", "شهریور", "برق شهریور"),"multi-token search");
        ok(BillListPolicy.matchesQuery("قبض برق", "قبض", "", " "),"blank query");
        ok(!BillListPolicy.matchesQuery("قسط وام", "قسط", "", "اجاره"),"nonmatching query");
        ok(LedgerPartyFilterPolicy.matches("همه",0),"all zero");
        ok(LedgerPartyFilterPolicy.matches("طلبکار",100),"credit");
        ok(!LedgerPartyFilterPolicy.matches("طلبکار",-1),"credit excluding debtor");
        ok(LedgerPartyFilterPolicy.matches("بدهکار",-1),"debt");
        ok(!LedgerPartyFilterPolicy.matches("بدهکار",0),"debt exclude settled");
        ok(LedgerPartyFilterPolicy.matches("تسویه",0),"settled");
        ok(LedgerPartyFilterPolicy.matchesQuery("احمدی","۰۹۱۲۳۴۵۶۷۸۹","بدهی","09123456789 احمدی"),"phone search");
        ok(!LedgerPartyFilterPolicy.matchesQuery("رضایی","0912","","احمدی"),"exclude unrelated");
        ok(LedgerPartyFilterPolicy.matchesQuery("رضایی","","",""),"empty search");
        ok(BillListPolicy.overdue(false,10,11),"overdue unchanged");
        ok(BillListPolicy.soon(false,12,11),"upcoming unchanged");
        System.out.println("PASS Finance225 16 UI-policy cases");
    }
}
