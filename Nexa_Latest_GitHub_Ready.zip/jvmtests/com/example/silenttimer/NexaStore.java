package com.example.silenttimer;
public final class NexaStore { public static final class Reminder { public long whenMillis;public boolean done,active;public String recurrence="none",completedDueDates="";} }
