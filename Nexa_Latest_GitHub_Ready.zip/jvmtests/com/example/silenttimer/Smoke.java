package com.example.silenttimer;
public class Smoke {
 static int ok=0;
 static void check(boolean b,String message){if(!b)throw new RuntimeException(message);ok++;}
 public static void main(String[] args){
   VoiceCommandParser.Finance a=VoiceCommandParser.finance("۵۰ میلیون بدهی به احمدی ثبت کن");
   check(a!=null&&"احمدی".equals(a.party)&&"DEBT".equals(a.kind)&&a.amount==50_000_000L,"debt");
   check(VoiceCommandParser.finance("۵۰ میلیون ریال بدهی به احمدی ثبت کن")==null,"rial");
   String[][] validMoney={
     {"۵۰ میلیون و ۲۰۰ هزار بدهی به احمدی ثبت کن","DEBT","احمدی","50200000"},
     {"50 میلیون و دویست هزار بدهی به احمدی","DEBT","احمدی","50200000"},
     {"صد و پنجاه میلیون طلب از احمدی","CREDIT","احمدی","150000000"},
     {"پنجاه میلیون از احمدی طلب دارم","CREDIT","احمدی","50000000"},
     {"۲۵٬۰۰۰٬۰۰۰ تومان پرداخت به رضا","PAYMENT","رضا","25000000"},
     {"۲ میلیون و ۵۰۰ هزار دریافت از سارا","RECEIPT","سارا","2500000"},
     {"۷۵ هزار تومان بدهی به کریمی","DEBT","کریمی","75000"}
   };
   for(String[] x:validMoney){
     VoiceCommandParser.Finance f=VoiceCommandParser.finance(x[0]);
     check(f!=null && f.kind.equals(x[1]) && f.party.equals(x[2]) && f.amount==Long.parseLong(x[3]),"money "+x[0]);
   }
   for(String unsafe:new String[]{
     "۵۰ میلیون و ۲۰۰ بدهی به احمدی",
     "۵۰ هزار و ۲ میلیون بدهی به احمدی",
     "۵۰ میلیون و ۲۰ هزار و ۲ هزار بدهی به احمدی",
     "۵۰ بدهی به احمدی",
     "۵۰ میلیون ریال بدهی به احمدی",
     "۵۰.۵ میلیون بدهی به احمدی",
     "منفی ۵۰ میلیون بدهی به احمدی",
     "۵۰ میلیون بدهی به احمدی و طلب از رضا",
     "۵۰ میلیون احمدی به من بدهکار",
     "۵۰ میلیون تومان و ۲۰۰ هزار بدهی به احمدی",
     "۵۰/۲۰۰ میلیون بدهی به احمدی"
   })check(VoiceCommandParser.finance(unsafe)==null,"unsafe should be rejected: "+unsafe);
   check(VoiceCommandParser.amountToman("۵۰ میلیون و ۲۰۰ هزار")==50_200_000L,"composite amount");
   check(VoiceCommandParser.amountToman("صد و بیست و سه میلیون و چهارصد و پنجاه هزار تومان")==123_450_000L,"verbal amount");
   check(VoiceCommandParser.amountToman("۹۹۹۹۹۹۹۹۹۹۹۹۹۹۹ میلیارد")==0L,"overflow guard");

   String[][] tasks={{"کار جدید خرید کتاب ثبت کن","todo","خرید کتاب"},{"لیست خرید مهمانی درست کن","shopping","مهمانی"},{"به کارها اضافه کن تماس با دکتر","todo","تماس با دکتر"},{"یه لیست خرید هفتگی بساز","shopping","هفتگی"},
         {"دارایی جدید طلای جوادی ثبت کن","assets","طلای جوادی"},
         {"وسیله جدید پژو ۲۰۷ من","vehicle","پژو 207 من"}};
   for(String[] t:tasks){VoiceCommandParser.FormDraft f=VoiceCommandParser.nonFinancialForm(t[0]);check(f!=null&&t[1].equals(f.destination)&&t[2].equals(f.title),"form "+t[0]);}
   String[][] bills={
     {"قبض جدید برق خانه ثبت کن","قبض","برق خانه"},
     {"قسط جدید وام بانک ثبت کن","قسط","وام بانک"},
     {"اجاره جدید آپارتمان","اجاره","آپارتمان"},
     {"اشتراک جدید اینترنت","اشتراک","اینترنت"},
     {"بیمه جدید خودرو","بیمه","خودرو"},
     {"چک جدید خرید تجهیزات","چک","خرید تجهیزات"}
   };
   for(String[] b:bills){VoiceCommandParser.FormDraft draft=VoiceCommandParser.nonFinancialForm(b[0]);
     check(draft!=null&&"bills".equals(draft.destination)&&b[1].equals(draft.type)&&b[2].equals(draft.title),"bill form "+b[0]);}
   for(String unsafeBill:new String[]{"قبض جدید برق ۵۰۰ هزار تومان","قسط جدید ۲۰ میلیون", "قبض جدید برق 2", "قبض جدید برق ریال"})
     check(VoiceCommandParser.nonFinancialForm(unsafeBill)==null,"reject amount in bill draft "+unsafeBill);
   check(VoiceCommandParser.nonFinancialForm("۵۰ میلیون بدهی به احمدی ثبت کن")==null,"finance guard");
   String[][] repeats={{"هر دو هفته","every:2:week"},{"هر ۳ ماه","every:3:month"},{"هر سال","every:1:year"},{"هر چهار روز","every:4:day"},{"یکبار فردا","none"},{"هر 999 ماه","none"}};
   for(String[] t:repeats)check(t[1].equals(VoiceCommandParser.spokenRecurrence(t[0])),"recurrence "+t[0]);
   long base=PersianDateUtil.toMillis(1405,8,5,10,0);
   for(String rule:new String[]{"every:2:week","every:1:month","every:2:year","daily","monthly"}){
     long[] out=ReminderRecurrence.previewFollowing(base,rule,6);check(out.length==6,rule+" size");
     for(int i=0;i<out.length;i++){check(out[i]>(i==0?base:out[i-1]),rule+" order "+i);check(out[i]==ReminderRecurrence.oneStep(i==0?base:out[i-1],rule),rule+" step "+i);}
   }
   check(ReminderRecurrence.previewFollowing(base,"none",4).length==0,"none recurrence");
   NexaStore.Reminder r=new NexaStore.Reminder();r.recurrence="every:2:week";r.whenMillis=base;
   ReminderRecurrence.recordCompleted(r);check(ReminderRecurrence.lastCompletedDue(r)==base,"completed");check(ReminderRecurrence.advanceAfterDone(r,base+1),"advance");check(r.whenMillis>base,"future");
   System.out.println("PASS: "+ok+" pure JVM assertions");
 }
}
