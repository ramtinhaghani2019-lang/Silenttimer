# Nexa 5.4.121 / Build 143 — Candidate
پایه: Build 142 Stable.

بسته تجمیعی پایداری یادآور دارو:
- بررسی شناسه و داده‌های نامعتبر در زمان‌بندی، لغو و دریافت Alarm.
- یکسان‌سازی زمان ثبت هشدار با زمان اعتبارسنجی‌شده (رفع اختلاف زمان برنامه‌ریزی).
- جلوگیری از سرریز زمان تعویق و رد زمان نامعتبر.
- ثبت تاریخچه تعویق فقط در صورت ثبت معتبر؛ ثبت جداگانه تعویق خارج از دوره.
- لغو قطعی هشدار هنگام پایان دوره پس از ثبت نوبت.
- تست رگرسیون مرزها، شناسه خالی و سرریز زمان.
نیازمند تأیید GitHub Build و Regression.

Regression hotfix: preserve existing nextRepeatAt(0) and saturation semantics; keep ID validation at scheduling boundaries, not pure course eligibility.
