# Nexa 5.4.172 — Build 194 | Premium Aurora: Today & Timeline

- Built on GitHub-green Build 193 source ZIP with exact matching Git blob SHA.
- Today screen: premium RTL header, three clear compact status metrics (today, overdue, completed), clean next-occurrence overview; existing task data, navigation, lists, history and persistent unlock note unchanged.
- Timeline: premium RTL header, grouped status metrics, accessible 44dp period/category chips, date-stamped event rows with colored semantic badges and larger tap targets; original filters, event collection and navigation preserved.
- New shared presentation helper `NexaAgendaUi` is UI-only; no persistence, alarms, permissions, signing, sound or timer changes.
- Responsive metrics stack on smaller screens and with large Android font scaling.
- All prior source files preserved, only targeted presentation screens and release tests updated.
- Local source guards, XML/ZIP integrity and security checks pass. Android CI and real-device acceptance required after upload.
