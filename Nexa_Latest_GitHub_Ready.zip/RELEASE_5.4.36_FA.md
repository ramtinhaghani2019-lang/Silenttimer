# Nexa 5.4.36 / Build 58

## Fix & Polish Pass

- Medicine: اضافه شدن گزارش ۷ روز اخیر با ساعت دوزهای مصرف‌شده و دوزهای فراموش‌شده.
- Reminder: ثبت تاریخچه واقعی برای انجام، بازگشایی، ویرایش و حذف یادآورها.
- Vault: حذف Email از دسته‌های پیش‌فرض بدون حذف داده‌های قدیمی، اصلاح متن‌ها، و اضافه شدن نمایش/پنهان‌سازی کنترل‌شده رمز هنگام ثبت یا ویرایش.
- Regression: کنترل نسخه Build 58 و جلوگیری از بازگشت دسته Email در Vault.


## Hotfix candidate
- اصلاح Regression اعلان تماس از دست‌رفته با انتظار کنترل‌شده برای permission/notification در emulator.
- کانال جدید Missed Call v2 برای عبور از تنظیمات ذخیره‌شده کانال قدیمی Android/Samsung.
- کارت تمام‌صفحه اختصاصی روی Lock Screen با fallback به Notification عادی.
- تنظیم مستقیم Full-screen notifications در صفحه تماس‌های مجاز برای Android 14+.
