# Nexa 5.4.34 / Build 56

## Audio Controller — Exact Restore & Temporary Override

- ذخیره و بازیابی دقیق حالت صدای قبل از شروع Silent Timer (Normal / Vibrate / Silent).
- حفظ حالت قبلی حتی در بازسازی Service/Process تا پایان تایمر.
- جلوگیری از بازنویسی Snapshot اصلی هنگام تمدید یا شروع مجدد تایمر فعال.
- اضافه شدن API مرکزی Temporary Override در `NexaAudioController`.
- انتقال Allowed Call bypass به Temporary Override مرکزی و Restore امن پس از پایان تماس.
- مسیر SMS Emergency عمداً حالت Normal را حفظ می‌کند تا Exact Restore خروج اضطراری را خنثی نکند.
- Regression Guard برای Version 5.4.34 / Build 56 و ذخیره/پاک‌سازی حالت قبلی صدا اضافه شد.

وضعیت تحویل: Candidate برای Build و Regression در GitHub Actions.
