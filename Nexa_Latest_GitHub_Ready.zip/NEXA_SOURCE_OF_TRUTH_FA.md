# NEXA — SOURCE OF TRUTH / منشور اجرایی دائمی

> این فایل داخل سورس و فایل ZIP است؛ هنگام ادامه در گفت‌وگوی تازه، باید قبل از تغییر کد خوانده شود. هیچ وعده‌ای جای تست را نمی‌گیرد.

## هدف غیرقابل‌چانه‌زنی

تبدیل تمام برنامه Nexa به محصولی روان، خوش‌خوان، زیبا و یکپارچه، نه افزایش نمایشی شماره Build. اولویت: استفاده آسان، دسته‌بندی روشن، تایپوگرافی حرفه‌ای فارسی، رنگ سازمانی محدود و هدفمند، دسترس‌پذیری، و حذف ازدحام و توضیحات بی‌مورد از سطح اول صفحات.

## اصول بازطراحی

1. ساختار صفحه: عنوان کوتاه، یک اقدام اصلی، فهرست یا محتوای واقعی؛ تنظیمات و گزارش‌های تخصصی در لایه دوم.
2. اگر در صفحه بازگشت به فهرست یا ثبت اصلی بیش از ۲ لمس لازم باشد، جریان باید بازبینی شود.
3. فونت یکدست فارسی، راست‌به‌چپ استاندارد، حداقل اندازه لمس 48dp و کنترل بزرگ‌شدن فونت.
4. رنگ ثابت معنایی: بدهی قرمز؛ طلب زرد؛ پرداخت سبز؛ دریافت بنفش. رنگ‌های تزئینی نباید معنای مالی را عوض کنند.
5. اطلاعات مهم را حذف نکن؛ آن را به صفحه جزئیات یا بخش بازشونده با نام مشخص منتقل کن.
6. هیچ قابلیت ذخیره‌سازی، تایمر، بازگردانی Silent، آلارم شارژ، تکرار مناسبت، اقساط و CSV بدون تست عملکردی تغییر نکند.
7. هر بیلد باید یک خروجی معنادار در چند بخش مشترک یا یک جریان کامل، تست‌های مشخص، مقایسه فایل، و توضیح محدودیت‌های آزمون داشته باشد.
8. اولویت با مدرک است: screenshot/device test + GitHub APK + emulator regression + archive security.
9. تا تأیید دو Workflow روی یک commit و مشاهده عملی صفحات کلیدی، هیچ نسخه‌ای "پایدار" یا "جهانی" اعلام نشود.
10. حتی اگر چت عوض شد، ادامه باید از آخرین source و این سند صورت گیرد؛ نسخه‌سازی مجدد از صفر ممنوع.

## وضعیت واقعی در زمان تدوین

- آخرین نسخه سبز GitHub در شروع این مرحله: Build 217 / 5.4.195، commit 7e0ddd0595d4d54847d285fdca0741009718f01f.
- Build 218 و 219 قبلاً در فایل محلی آماده شده ولی تا این مرحله موفقیت Android CI آنها تأیید نشده است.
- این بسته Build 220 / 5.4.198 یک Candidate برای بازسازی سراسری لایه ظاهری است؛ نه تأیید نهایی.
- مرحله فعلی: یکپارچه‌سازی پایه طراحی در UiKit، HomeUi، ابزارهای action/reminder، فونت و theme اندروید؛ اصلاحات خرید دارایی از کد Build 219 حفظ شده‌اند.

## صورت مسئله گسترده (همه صفحات)

دامنه ممیزی شامل خانه/داشبورد، امروز، یادآور، فرم یادآور، ثبت سریع، مالی/دفتر حساب، قبوض و اقساط، دارایی‌ها، جستجو، خط زمانی، تاریخچه، مناسبت‌ها، دارو، خانه، خودرو، پرونده حقوقی، مدرک، امنیت، تماس‌ها، باتری، تایمرها، تنظیمات، فایل‌ها و سایر فعالیت‌هاست. هر بخش باید جداگانه در اندازه معمول، باریک و فونت بزرگ بازبینی شود.

## دستور تکراری برای چت بعدی

پیش از هر بیلد: (۱) این سند و Release آخر را بخوان؛ (۲) GitHub main، SHA فایل و هر دو Workflow را تطبیق بده؛ (۳) از آخرین سورس تأییدشده و تغییرات تست‌شده ادامه بده؛ (۴) از تغییرات کاربر نسخه پشتیبان بگیر و هیچ فیچر قبلی را حذف نکن؛ (۵) خروجی ZIP با نام Nexa_Latest_GitHub_Ready.zip بده؛ (۶) اگر تست emulator/عکس گوشی نداریم، صریحاً ذکر کن.

## باگ‌های باز و نیازمند تست دستگاه

- Force Stop در پس‌زمینه/پایداری هشدار.
- خروج از Silent در پایان تایمر.
- خاموش‌شدن آلارم شارژ هنگام قطع شارژر.
- وضعیت تکرار رخدادها، فرمت نمایش مالی و ثبت صوتی نیازمند Regression عملی است.

## معیار قبولی UI برای همه بخش‌ها

- بدون تراکم متن در یک viewport؛ بدون تکرار چندباره یک عدد یا CTA.
- اولویت بصری روشن: عنوان، داده اصلی، عمل اصلی، فهرست، جزئیات تکمیلی.
- سازگاری RTL و عددگذاری/شماره کارت/کپی؛ همه touch targets حداقل 48dp.
- رنگ‌ها فقط در معنا یا اقدام اصلی؛ آیکون‌های هم‌سبک؛ از کارت گرادیانی و رنگ‌پاشی پرهیز.
- بدون حذف داده یا منطق حتی اگر قابلیت از نمای اصلی به لایه دوم منتقل شود.

## مانع شناخته‌شده

در این محیط Android SDK و شبیه‌ساز محلی نصب نیست. تست‌های JVM/ساختار ZIP اجرا می‌شوند، اما CI و تست دیداری گوشی برای قبولی نهایی الزامی است.

## CI Regression update — Build 219
- GitHub main at investigation: `ffc65f67d9433d383353f8bd8e083c3dd20a3251`, Build 219. APK passed, Android Regression failed 1 / 180 tests.
- Root cause specifically `NexaRegressionTest.java:40` checking `getMinimumHeight` on portfolio filter; `setMinHeight` without `setMinimumHeight` did not satisfy View min height.
- Build 220 candidate updated to use both at 48dp for filter chips and strengthened instrumented tests. Do not treat as CI-success until GitHub confirms both workflows on the same newer commit.

## CI regression verification — 2026-11-03 / same Build 220
- GitHub commit `b1cd31c4a940af2400afe4ef1d8087cf56e39502` correctly uploaded Build 220 (source Git blob dd599397f0b322e83f78039bda43481be799163e; 1,236,748 bytes).
- APK workflow succeeded: https://github.com/ramtinhaghani2019-lang/Silenttimer/actions/runs/41552415513
- Android 14 emulator regression failed exactly 1/182 cases: `build193_globalPremiumDesignMaintainsFinancialSemanticColors`; expected `UiKit.GOLD==0xFFF2C75C`, actual `0xFFF1C65F`.
- Root cause: visual-system palette adjustment in UiKit unintentionally changed the established credit/yellow semantic token.
- Fix: restore `UiKit.GOLD=0xFFF2C75C` in the shared palette; retain the instrumentation assertion and all other implementation/tests. No build-number increment, data migration or alarm change.
- Status: static local checks passed; GitHub CI rerun still REQUIRED for this new ZIP. Do not claim green until APK and Android Regression both succeed on the same SHA.


## آخرین وضعیت تأییدشده و نسخه در دست ساخت — ۳ نوامبر ۲۰۲۶
- **آخرین نسخه کاملاً سبز:** Build 220 / 5.4.198، GitHub commit `09c0f516535662ffdfdc0b2e86bd7558919cb87c`، ZIP blob `d849845222b0c0ccf0909dfe281797457bd96722`، هر دو Workflow موفق.
- **کاندیدای بعدی:** Build 221 / 5.4.199. تغییرات اصلی صفحه مستقل ۲۲ مسیر با جست‌وجو، تاریخچه زمانی مستقیم و ناوبری یکپارچه است. **Android CI آن هنوز اجرا نشده؛ سبز نخوانید.**
- هر بار باید از آخرین فایل ZIP سبز و سند حاضر ادامه داد؛ نسخه 221 تنها در صورت موفقیت هر دو Workflow روی SHA یکسان قابل مبناشدن است.
- مهم‌ترین بدهی طراحی: بازبینی دیداری روی گوشیِ تمام ۴۱ Activity، اصلاح محتوای متراکم و فونت، کاهش لمس و متن اضافی؛ پیشرفت ۲۲۱ به‌معنای بسته‌شدن این بدهی نیست.

## وضعیت ۳ نوامبر ۲۰۲۶ — تأیید Build 221 و کاندیدای Build 222
- **آخرین نسخه تأییدشده کامل:** Build 221 / `5.4.199` روی commit `efa156f46fa3f347e4b5cf527d800a89d71a3d44`؛ فایل ZIP Git blob `9b1ebd71aeb6d91cdc3615f3dc6740a7ed20fffa`؛ هر دو Workflow GitHub (APK و Android Regression) موفق روی همین SHA.
- **Build 222 / 5.4.200 فقط کاندیدای جدید است** و تا زمان اجرای CI نمی‌توان آن را سبز خواند.
- تغییرات: بازطراحی جریان «امروز» (ثبت بالای صفحه، ناوبری ثابت، فهرست‌های بازشونده/صفحه‌بندی، نگهداری پیش‌نویس/اسکرول)، و اصلاح خط زمانی (روز محلی، تکرارها، صفحه‌بندی و فیلتر بی‌پرش)؛ سطوح آماری مشترک منسجم‌تر.
- محاسبه و ذخیره مالی، آلارم‌ها، Silent Timer، بانک اطلاعاتی و مجوزهای سیستم دست‌نخورده‌اند.
- بدهی بازِ اصلی: بازبینی عملی و دیداری تمامی ۴۱ صفحه، فرم‌های مالی حجیم، بازگشت به حالت صدای قبلی و قطع هشدار شارژ پس از جداکردن کابل.
- **قانون:** هیچ بهبود سراسری یا جهانی را صرفاً از موفقیت CI نتیجه نگیر؛ فقط تغییرات مذکور را اصلاح‌شده تلقی کن.

## خطای CI و Hotfix همان Build 222 — ۳ نوامبر ۲۰۲۶
- Commit ناموفق: `1d7d6de44c0aa1252c9db6144fffc8eb0ed3319e`، فایل ZIP blob `25b5851776e826804dea7b1f99bed0acc6e0e3bc`، اندازه 1,254,312 بایت.
- APK و Regression هر دو در javac بر اثر `heading.setMinHeight(...)` روی `LinearLayout` متوقف شدند، بنابراین هیچ‌یک تست اندروید را کامل نکردند.
- اصلاح: تنها حذف خط نادرست و حفظ `setMinimumHeight(50dp)`، به اضافه مستندات و گارد تست API. بدون افزایش شماره نسخه.
- Build 222 تا تأیید هر دو CI روی commit جدید **سبز نیست**؛ آخرین نسخه کامل تأییدشده Build 221 است.

## GitHub confirmed Build 222 and Build 223 visual UX candidate — November 3, 2026
- Build 222 / 5.4.200 is GREEN on main `8cfec83dcf14182272d9c6e9f0f298d6dde4a9d8`. ZIP Git blob `2a4e16fc83ae1ce4799799b8b4ef7edf6904ec43`, 1,255,643 bytes. APK run 41561234336 SUCCESS; Regression run 41561234299 SUCCESS.
- User sent a real screenshot of Build 221 module directory and rejected its appearance as unfinished. Main problems: horizontally clipped filter chip; repetitive low-information geometry for icons; giant individually bordered rows; oversized bottom nav, flat navy color.
- Build 223 candidate focuses on **actual visible changes**: `ModulesActivity` shows 5 complete category filters in 2 weighted rows (no horizontal scrolling), colored category pictograms, grouped list rows replacing 22 giant separate cards. `NexaOutlineIcon` draws 24 native vector-like outline pictograms; `UiKit.bottomNav` shares 4 real icons and balanced color across all screens using it. Accessibility labels, 22 destinations, group/search behavior preserved.
- UI validation is **not complete** until inspected on a physical device including narrow screen and large font. Local JVM and static source audits are supportive only, Android GitHub APK and Regression both must pass on the next HEAD. Do not claim Build 223 green before that.
- Financial color tokens and core alarm/timer/store files unchanged.


## Build 223 — خطای واقعی CI و اصلاح همان نسخه (۳ نوامبر ۲۰۲۶)
- GitHub main اولیه 223: `b35e3f78fbf9bbf964760f8ae38d0b0f15a5af0b`، ZIP اصلی 1,263,938 بایت، blob `8bae8b81052f50fba4485c57b8b22743356529dc`.
- ساخت APK موفق (run `41590684626`)؛ شبیه‌ساز Android 14 با ۱۸۷ آزمون و تنها ۱ شکست (run `41590684504`): `build214_navigationTargetsAndAccessibleSelectionRemainConsistent`، `NexaRegressionTest.java:259`.
- علت قطعی از گزارش XML: `tab.getMinimumHeight() >= UiKit.dp(c,56)` نقض شد. در `UiKit.navTab` فقط `LayoutParams` با ارتفاع ۶۰dp تعریف شده بود که `minimumHeight` ویو را تعیین نمی‌کند.
- اصلاح بدون تغییر شماره: `tab.setMinimumHeight(dp(c,56));` در سازنده مشترک همه تب‌ها؛ ارتفاع نمایشی ۶۰dp و چهار مقصد/برچسب دسترسی حفظ شدند. گارد `tools/test_build214_navigation.py` تقویت شد و تست دستگاه تغییر نکرد.
- **آخرین نسخه سبز قطعی تا این بررسی:** Build 222 / 5.4.200 روی SHA `8cfec83dcf14182272d9c6e9f0f298d6dde4a9d8`. Build 223 اصلاحی فقط پس از سبز شدن هر دو Workflow روی همان Commit و تطبیق blob قابل تأیید است.
- هنوز ارزیابی بصری واقعی ۴۱ صفحه و فرم‌های مالی حجیم انجام نشده است؛ CI آن را اثبات نمی‌کند.

## Build 223 تایید شد، Build 224 در دست توسعه — ۳ نوامبر ۲۰۲۶
- Build 223 / 5.4.201، GitHub main commit `344254c37e1e0c955c8b7f4ad6e67a7ab90c8f8b`، ZIP blob `394e942b05c0feda9fd463efaf82a1363ddfce07`، اندازه 1,267,005 بایت؛ APK و Regression هر دو success.
- Build 224 / 5.4.202 کاندیدای تازه است: فهرست‌های فشرده و گروه‌بندی‌شده ثبت سریع، میانبرهای گروهی خانه، آیکون خطی بومی در اکشن‌های اصلی و حفظ TalkBack/RTL، بدون تغییر داده و سرویس‌ها.
- نسخه 224 هنوز سبز GitHub/تأیید دیداری گوشی نیست. تا تست و آپلود، مبنا فقط 223 باقی می‌ماند.


## Build 224 CI hotfix — ۳ نوامبر ۲۰۲۶
- GitHub main در بررسی: `c5a2bd0b8b29e22e19b82d1aeda2fcd465f24f72` و ZIP 1,270,468 بایت. APK موفق `41596034455`، Regression ناموفق `41596034277`: یک شکست از 188 آزمون.
- علت طبق گزارش رسمی Android: `build217_quickAddAdaptiveLayoutAndEntryPointsAreAvailable`، خط 246، حداقل ارتفاع `NexaActionUi.compactTile` انتظار 80dp، پیاده‌سازی جدید 64dp.
- Hotfix روی **همان versionCode 224 / versionName 5.4.202**: حداقل ارتفاع به 80dp برگردانده شد. تست قدیمی حذف یا تضعیف نشد؛ ابزار گارد ساختاری هم الزام 80dp دارد.
- تا سبزشدن هر دو CI روی SHA جدید، Build 224 را موفق ننام. مبنای سبز همچنان Build 223 است. تمام بدهی‌های طراحی سایر بخش‌ها باز هستند.
