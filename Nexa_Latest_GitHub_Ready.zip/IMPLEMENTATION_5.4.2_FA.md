# Nexa 5.4.2

- 6-theme engine: Graphite Teal internal + 5 downloadable GitHub Release packs.
- max 2 downloaded themes; active theme cannot be auto-deleted.
- theme packs were retired; Nexa now uses one fixed built-in visual system.
- compact back icon.
- compact buttons + larger/readable typography.
- bottom navigation: Home / Today / Quick Add / History. Removed duplicate Silent / Calls navigation.
- removed duplicate Settings tile from dashboard; Settings remains in top action.
- collapsible sections with per-section “always open” preference; important summary stays visible.
- Assets: portfolio summary always visible; market and asset-type sections collapsible; online market source remains external reference with timestamp and manual FX fallback.
- Case: reusable court/lawyer directories, payment amount and document note fields, existing reminders preserved.
- biometric unlock: single-completion guard + cancellation cleanup to prevent repeated callbacks/navigation loops.
- OCR intentionally excluded.
- applicationId unchanged: com.example.silenttimer
- stable keystore retained.
