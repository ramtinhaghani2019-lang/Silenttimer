# Nexa 5.4.63 / Build 85

## Audit: Missed Call + Emergency + Lock Screen
قابلیت‌های موجود (لیست چند تماس، شمارنده، بستن خودکار کارت، تماس مجدد، دو مخاطب اضطراری، برچسب‌های مادر/پدر و ACTION_DIAL) حفظ شدند و دوباره‌سازی نشدند.

## تغییرات
- افزودن اکشن صریح «پاک کردن» به اعلان تماس از دست‌رفته روی Lock Screen؛ علاوه بر swipe/delete intent.
- حفظ اکشن تماس مجدد و Full-screen lock card موجود.
- جلوگیری از فعال‌شدن Emergency Card بدون حداقل یک شماره تماس.
- تازه‌سازی فوری صفحه Emergency بعد از ذخیره تا عنوان و شماره دکمه‌های تماس سریع همان لحظه به‌روز شوند.
- مقاوم‌سازی EmergencyCardManager در برابر Context/NotificationManager نامعتبر.
- Regression نسخه به 5.4.63 و بررسی وجود اکشن‌های Call/Clear در Missed Call.
- هیچ WakeLock یا KEEP_SCREEN_ON اضافه نشده است.
