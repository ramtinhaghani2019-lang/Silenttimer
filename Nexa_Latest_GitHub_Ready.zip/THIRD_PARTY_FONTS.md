# Embedded Persian/Arabic typeface

Noto Sans Arabic Regular and Bold are embedded only to render Persian UI consistently.
Copyright (c) Google LLC and contributors.
License: SIL Open Font License 1.1.
Source: https://github.com/notofonts/arabic

License notice and license details: https://openfontlicense.org/
