# Nexa 5.4.74 / Build 96

بسته بزرگ Master UI:
- یکدست‌سازی Spinner و منوی انتخاب در کل برنامه
- استایل مشترک CheckBox و RadioButton
- استایل طلایی/یشمی SeekBar و ProgressBar
- یکدست‌سازی AutoComplete و لیست‌های انتخاب
- بهبود ListView و جداکننده‌ها
- بهبود NumberPicker و کنترل‌های عددی
- بهبود RTL و Clip/Padding در ViewGroupهای قدیمی
- فارسی‌سازی کامل‌تر صفحه ثبت سریع
- حفظ حداقل Touch Target برای کنترل‌های تعاملی
- حفظ تمام قابلیت‌های Stable Build 95
- Version/Regression به Build 96 بروزرسانی شد.

GitHub Build/Regression برای Stable شدن الزامی است.
