# Nexa 5.4.198 / Build 220 — Visual System Reset Candidate

## Scope
Shared visual-system update, not a claim that 40 screens are fully redesigned or verified on a device.

- New embedded Arabic/Persian sans typeface, wired at the Android theme and native shared component layer.
- Uniform surface hierarchy; all colorfulCard(...) callers now render neutral cards, leaving meaning to text/badges.
- Quieter backdrop, restrained blue primary action, consistent field, bottom navigation and tap regions.
- Cleaner progressive disclosure for collapsible sections; explanatory text and pin action are kept inside an expanded section.
- Shared navigation/action glyph simplification without changing titles, click handlers, persistence or alarm logic.
- Semantic finance colors (debt RED, credit GOLD, payment GREEN, received PURPLE) retained.
- All source and workflows from local Build 219 retained; note that Build 219 was not CI-confirmed in this stage.

## Acceptance
Static/JVM checks are necessary but NOT sufficient. After upload, check APK workflow and Android Regression workflow on same SHA. Then validate screenshots and real tasks on an Android device (including small screens, fontScale 1.3, keyboard, voice, DND, billing, data persistence). Do not declare complete without those results.


## Verified GitHub Build 219 CI failure — addressed before this Build 220 upload
- Failure URL: https://github.com/ramtinhaghani2019-lang/Silenttimer/actions/runs/41535977466
- 180 Android emulator tests: 179 passed, 1 failed. `NexaRegressionTest.java:40` asserted `NexaAssetsUi.filter(...).getMinimumHeight()>=44dp`.
- Root cause: `TextView.setMinHeight(44dp)` configures text height but `View.getMinimumHeight()` was not set.
- Fix: add both `setMinHeight` and `setMinimumHeight` at 48dp (and minimum width 76dp) for both active/inactive asset filter chips; consistent asset-type labels also use 48dp. The instrumentation regression now checks the actual View minimum and accessible labels.
- Scope: no finance storage, pricing, calculations, timer, scheduling or permissions changed for this fix.
- **Status: local regression checks only. GitHub APK + emulator Regression for Build 220 pending.**

## CI regression verification — 2026-11-03 / same Build 220
- GitHub commit `b1cd31c4a940af2400afe4ef1d8087cf56e39502` correctly uploaded Build 220 (source Git blob dd599397f0b322e83f78039bda43481be799163e; 1,236,748 bytes).
- APK workflow succeeded: https://github.com/ramtinhaghani2019-lang/Silenttimer/actions/runs/41552415513
- Android 14 emulator regression failed exactly 1/182 cases: `build193_globalPremiumDesignMaintainsFinancialSemanticColors`; expected `UiKit.GOLD==0xFFF2C75C`, actual `0xFFF1C65F`.
- Root cause: visual-system palette adjustment in UiKit unintentionally changed the established credit/yellow semantic token.
- Fix: restore `UiKit.GOLD=0xFFF2C75C` in the shared palette; retain the instrumentation assertion and all other implementation/tests. No build-number increment, data migration or alarm change.
- Status: static local checks passed; GitHub CI rerun still REQUIRED for this new ZIP. Do not claim green until APK and Android Regression both succeed on the same SHA.
