# Nexa 5.4.216 / Build 238 — OCR reliability and gallery safety hotfix

Status: candidate source patch, NOT a confirmed green Android build.

## Observed problem
The user reported incorrect purchase field values after scanning an actual Persian Karizma receipt. A local OCR test using the bundled Persian/English models on a previously provided receipt screenshot also showed severe loss of numerical digits (e.g. gross quantity and gram-based fee). Therefore Android CI success alone did not prove financial OCR accuracy.

## Patch
- Replaced ACTION_OPEN_DOCUMENT file browser route with the Android 13+ system Image Photo Picker (MediaStore.ACTION_PICK_IMAGES), falling back to image-only ACTION_GET_CONTENT on older/unsupported devices.
- Added a mandatory conservative mathematical check before any image-derived financial fields may be placed into the existing form. This is NOT automated purchase saving.
- For Karizma silver receipts, require purchase amount, purchase unit price, gross quantity, fee in rials, fee in grams, net quantity, valid Persian date and recognized asset type. The following must reconcile: amount ≈ gross×unit price; net = gross−weight fee; rial fee ≈ weight fee×unit price.
- If any number is missing or inconsistent, Nexa does NOT auto-fill any receipt values. User must check and enter details manually; existing data remain unchanged.
- Added regression tests rejecting a previous-purchase price reused for a later receipt, portfolio total confused with purchase net quantity, or incomplete readings.
- Retained versionCode=238, versionName=5.4.216; no other app feature logic changed.

## Validation
- Existing 1-billion-rial Karizma receipt sample passed strict consistency check.
- Wrong unit price (4,852,684 instead of 4,801,784) rejected.
- Portfolio total entered as net receipt quantity rejected.
- Pure-Java parser compiled with Java 17.
- Archive CRC and changed files verified.
- NOT executed: actual APK build, Android emulator regression, device gallery/OCR checks.

## Critical limitation
This is a **safety hotfix**, not a claim that Tesseract now accurately reads every Persian receipt. Accurate OCR on complex screenshots needs targeted field/region detection or an improved Persian model and real-device validation. The right financial behavior on uncertain OCR is to refuse automatic filling rather than insert wrong numbers.
