# Nexa 5.4.203 / Build 225 — Reference UI alignment

Base: GitHub active Nexa 5.4.202 / Build 224, source blob `fd87bf0a4377d206f35e7c07918dd258adcb7c34`.

## Implemented
- Main screen reorganized around actual financial values rather than silent timer at the top; four semantic cards for receipt/payment/credit/debt, real ledger-backed amounts (no sample numbers).
- Header uses native outline icons, Persian date label and gold Nexa identity.
- Four short native tappable actions: Today, Reminders, Quick Add, Modules; timer still available below.
- Main Modules directory uses a native 3-column layout on suitable screens, 2 or 1 column at smaller widths / larger fonts.
- Midnight-gold background with unobtrusive canvas-drawn curves, consistent thin champagne borders and nav gradient.
- New reference five-tab navigation (Home, Today, Finance, Sections, More); More opens additional tools without losing Quick Add, Timeline, Settings, Search or History. Financial and assets pages also get bottom navigation.
- Existing 22 destinations and storage schemas unchanged; silent timer startup and stop semantics unchanged.

## Validation / limitation
Source ZIP integrity and source changes can be checked locally. Android APK compilation and emulator regression tests must run in GitHub Actions after replacing the root ZIP. Do not treat this as a green build until both workflows pass. Install an APK only from the matching successful workflow.
