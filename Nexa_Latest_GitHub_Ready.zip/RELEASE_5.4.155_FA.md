# Nexa 5.4.155 / Build 177 — Candidate

- Expansion of Persian spoken quick-add to todo tasks and shopping lists via prefilled edit dialogs (explicit save required).
- Alternative speech recognition transcripts can be reviewed before interpreting.
- Spoken recurrence `هر دو هفته/ماه/...` preselects repeat in the reminder form, no silent schedule registration.
- Reminder list now shows one next virtual occurrence and last completed occurrence as small separate rows; completed occurrence gets subtle red background. All additional projected dates are viewable on row tap; no extra alarms or financial records are generated.
- Reduced decorative content in quick-add and shopping/todo screen.
- Version 5.4.155 (177), existing application ID and secured signing arrangement preserved.

Local static/syntax and pure-Java logic tests are not equivalent to GitHub Android compilation and emulator regression. Do not mark GREEN without CI and device checks.
