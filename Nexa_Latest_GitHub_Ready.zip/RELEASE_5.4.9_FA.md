Nexa 5.4.9 — Build 31

Stability batch based on real 5.4.8 phone regression tests.
- Medicine: editing first consumed dose now resets/recalculates future schedule from the edited baseline and replaces old scheduled alarm.
- Alarm channels bumped so corrected high-priority/lock-screen settings are recreated on existing installs.
- Added USE_EXACT_ALARM capability alongside existing exact-alarm handling for alarm/reminder reliability on Android 14.
- Reminder category picker: selection now applies immediately and closes; redundant outer "انتخاب دسته" title removed while "دسته‌های یادآور" remains.
- Reminder time picker replaced with theme-safe hour/minute spinners so controls remain visible.
- Home: extra Nexa Search/global-search tile removed; search feature itself remains in source.
- Home timer: base/accent colors corrected to use active theme palette.
- Silent automatic exit: audible confirmation strengthened with notification ringtone + tone fallback.
- Emergency channel bumped for refreshed lock-screen visibility settings.

All phone-dependent alarm/full-screen behaviors require device testing after build/install.
