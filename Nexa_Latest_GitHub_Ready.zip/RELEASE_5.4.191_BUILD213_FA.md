# Nexa 5.4.191 — Build 213 / Regression Hotfix

## علت
در Build 212، تنها آزمون ناموفق از ۱۷۵ تست اندروید،
`build212_occasionDirectorySearchAndFiltersAreSafe` در خط ۲۸ بود.
گزارش واقعی XML تست روی Android 14، `AssertionError` در کنترل `EditText.getMinimumHeight()` را ثبت کرد.

## اصلاح
در `UiKit.styleField` علاوه بر `TextView.setMinHeight(48dp)`، مقدار مستقل `View.setMinimumHeight(48dp)` نیز ست می‌شود.
این کار تکیه بر ظاهر یا ارتفاع ضمنی ویو را حذف کرده و مشخصه دسترس‌پذیری برای تمام فیلدهای متنی استاندارد می‌شود.

- هیچ تغییری در قرارداد ذخیره‌سازی، آلارم‌ها، مناسبت‌ها، امور مالی، نام پکیج و مجوزها داده نشده است.
- آزمون قبلی Android Regression عیناً باقی مانده و برای عبور باید با همین اصلاح در شبیه‌ساز اجرا شود.
- آزمون ثابت جدید: `tools/test_build213_field_minimum.py`.
- این بسته قبل از آپلود تنها تست محلی/ساختاری را پشت سر گذاشته؛ تأیید نهایی نیازمند سبز شدن دو Workflow در GitHub است.
