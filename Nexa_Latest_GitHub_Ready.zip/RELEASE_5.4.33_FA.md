# Nexa 5.4.33 / Build 55

## تغییرات
- اضافه شدن `NexaAudioController` به‌عنوان هسته مرکزی مدیریت صدای هشدار و تغییر حالت صدای سیستم.
- اضافه شدن Priority System برای Reminder، Medicine، Battery، Security و Theft؛ هشدار کم‌اولویت دیگر هشدار بحرانی فعال را قطع نمی‌کند.
- انتقال پخش/توقف صدای Alarm و ویبره از `AlarmSoundPlayer` به Audio Controller با حفظ API قبلی برای جلوگیری از Regression.
- اتصال Medicine و Reminder (Receiver و Ring Activity) به اولویت‌های مستقل Audio Controller.
- یکپارچه شدن تغییر Ringer Mode در Silent Timer، Allowed Call bypass، بازگردانی تماس و Emergency با ورودی مرکزی Audio Controller.
- جلوگیری از توقف اشتباهی Alarm جدید هنگام بسته شدن Activity قدیمی با تشخیص Session فعال.
- Actionهای Medicine و Reminder فقط Session متعلق به خود را متوقف می‌کنند و دیگر Alarm بحرانی نامرتبط را خاموش نمی‌کنند.
- افزایش نسخه به `5.4.33 / Build 55` و اضافه شدن Regression Guard برای ترتیب Priority و Ringer Modeهای معتبر.

## وضعیت تست
- Candidate آماده اجرای GitHub Actions: Build APK و Android Regression Tests.
