# Nexa 5.4.173 — Build 195 | Premium Aurora: Reminders

- Based on exact GitHub-green Build 194 source ZIP; old source and signing configurations retained.
- Reminder list: three responsive and accessible status tiles, direct quick-filter chips, compact dark cards with readable colored status, clear due dates and native action buttons.
- Full search, sort, grouped selection, calendar export and every existing reminder action remain accessible.
- Reminder editor: distinct premium sections for content and scheduling, compact header and labeled fields. RepeatIntervalPicker and AlertEditor are retained intact and attached to the scheduling panel.
- New `NexaReminderUi` contains visual widgets only, no data writes, alarm scheduling or changes to permissions.
- Recurrence preview entries, doctors, voice-input, reminder audio settings, persistence, next occurrence and notifications preserved.
- Build checks: source security, XML, ZIP and local regression guards; Android CI and visual acceptance required after upload.
