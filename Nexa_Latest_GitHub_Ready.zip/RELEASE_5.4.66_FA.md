# Nexa 5.4.66 / Build 88 — Product Unification & Hardening

- بازآرایی خانه بر اساس خانواده‌های روز و برنامه، مالی و اسناد، زندگی و نگهداری، امنیت و سیستم، دسترسی و تاریخچه؛ هیچ ماژولی حذف نشده است.
- حفظ داشبورد «امروز» و «نیازمند توجه» به‌عنوان لایه اولویت‌محور خانه.
- تقویت Design System مرکزی UiKit؛ حداقل Touch Target دکمه‌ها/آیکن‌ها/Bottom Navigation و فیلدها 48dp شد.
- RTL در سطح Window استاندارد شد و فیلدهای مشترک رفتار RTL/ارتفاع یکسان گرفتند.
- Empty State و Status Badge مشترک به Design System افزوده شد تا صفحات در مرحله تثبیت نهایی یک الگوی واحد داشته باشند.
- Backup/Restore عمومی Nexa و Backup رمزگذاری‌شده Vault که از قبل وجود داشتند حفظ شدند؛ دوباره‌سازی نشدند.
- Offline/Cacheهای موجود Assets و Weather و Notification priorityهای موجود حفظ شدند؛ این Build آن‌ها را بازنویسی نمی‌کند.
- Regression نسخه به 5.4.66 / 88 ارتقا یافت و Regression حداقل اندازه Touch Target اضافه شد.

Build 89 فقط Final Regression/Stabilization است و قابلیت جدید اضافه نمی‌کند.
