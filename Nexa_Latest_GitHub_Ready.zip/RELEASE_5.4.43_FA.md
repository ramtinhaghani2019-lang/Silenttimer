# Nexa 5.4.43 / Build 65

بسته چنداصلاحی UI/Vault/Case:
- انتخاب سریع دادگاه از دفتر ذخیره‌شده با امکان تایپ مورد جدید
- انتخاب سریع وکیل از دفتر ذخیره‌شده با امکان تایپ مورد جدید
- جلوگیری از ثبت تکراری نام دادگاه در Regression
- Vault: آیکون چشم هم‌ردیف فیلد رمز
- Vault: نمایش/پنهان‌سازی کنترل‌شده رمز هنگام ثبت و ویرایش
- Vault: گروه‌ها با Accordion استاندارد Nexa
- حفظ قفل و FLAG_SECURE صندوق امن
- حذف فایل راهنمای Theme Packs باقی‌مانده
- اصلاح مستند قدیمی Theme و تثبیت ظاهر ثابت Nexa
- Regression عدم بازگشت ThemeManager
- Regression دفتر دادگاه/وکیل
- نسخه 5.4.43 و Build 65

## Hotfix Build 65
- حذف واقعی فایل باقیمانده ThemeManager.java از Runtime/production source.
- حذف مستند منسوخ THEME_PACKS_README_FA.md.
- نسخه و Build بدون تغییر: 5.4.43 / 65.
