Nexa 5.4.101 / Build 123 (Candidate)
- نمایش مبالغ سبد دارایی با PersianFinancialDisplay.amount.
- نمایش قیمت‌های بازار ایران با قالب‌بندی فارسی و جداکننده سه‌رقمی.
- نمایش مقادیر نامعتبر به‌صورت خط تیره به‌جای NaN/Infinity.
- افزودن تست‌های Regression و به‌روزرسانی تست نسخه.
- Android Build و Regression باید در GitHub تأیید شوند.
