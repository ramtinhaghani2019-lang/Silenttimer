# Nexa 5.4.52 / Build 74

- یکپارچه‌سازی قرارداد اولویت Notification Engine
- اولویت: ضدسرقت > امنیت > باتری > دارو > یادآور > عادی
- ایجاد مرکزی کانال‌های اعلان
- تفکیک صدای Reminder با Ringtone
- تفکیک صدای Battery با Notification
- صدای Theft/Security از نوع Alarm
- Theft channel با DND bypass در صورت دسترسی سیستم
- API مرکزی cancel اعلان
- post ایمن در برابر context/notification خالی
- حفظ dedupe اعلان‌ها
- حفظ Medicine control بی‌صدا
- Regression برای priority contract و ساخت کانال‌ها
