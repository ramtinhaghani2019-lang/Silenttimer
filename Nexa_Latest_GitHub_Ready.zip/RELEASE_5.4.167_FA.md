# Nexa 5.4.167 / Build 189 — Critical Reliability Hotfix

- End timer: attempt to restore pre-timer ringer state synchronously from the alarm broadcast, independently of foreground-service startup.
- Never delete an expired timer session until ringer restoration is confirmed; retry when DND permission or OEM policy interferes.
- Do not announce or persist an active timer when Silent/Vibrate could not be applied.
- Listen for charger disconnect directly in foreground service, battery screen and manifest receiver; immediately stop charge-limit audio and notification. Use an unplugged snapshot when a cached battery broadcast has stale plugged status.
- Re-arm pending timer deadlines on reboot, app update, exact-alarm permission changes and system clock changes.
- Anti-theft unplug alarm intentionally remains independent; its separate siren must still follow its own enable/authorization settings.
- Regression checks added for timer expiry guard and unplugged alarm shutdown.
- Based on last green Build 188. Verify the real behavior on a Samsung handset after GitHub CI; Android emulator cannot prove the physical cable unplug or OEM background audio behavior.
