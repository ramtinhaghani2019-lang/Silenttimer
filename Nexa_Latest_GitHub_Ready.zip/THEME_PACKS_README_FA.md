# پوسته‌های Nexa 5.4.2

این نسخه Theme Engine نسل دوم را دارد. هر بسته پوسته فقط داده و تصویر است و هیچ کد اجرایی از اینترنت دریافت نمی‌شود.

پوسته داخلی: Graphite Teal

پنج فایل قابل آپلود در GitHub Release با tag دقیق `nexa-themes-v1`:
- theme_pastel_coral.zip
- theme_ice_glass.zip
- theme_cosmic_neon.zip
- theme_holo_lilac.zip
- theme_copper_editorial.zip

هر بسته شامل `theme.json` + `preview.webp` + `background.webp` است. پیش‌نمایش‌ها از همان طرح‌های تأییدشده کاربر ساخته شده‌اند و پس‌زمینه‌های اجرایی از همان مرجع بصری مشتق و محو شده‌اند تا متن تکراری وارد رابط نشود.

Nexa حداکثر ۲ پوسته دانلودی را نگه می‌دارد و پوسته فعال خودکار حذف نمی‌شود.
