Nexa 5.4.18 / Build 40 — Multi-change Settings & Compatibility Batch

تغییرات این بسته:
1) کد اضطراری پیامکی به ساختار کشویی یکپارچه تنظیمات منتقل شد.
2) رفتار زنگ هشدار به ساختار کشویی منتقل شد.
3) همه بخش‌های اصلی تنظیمات اکنون به‌صورت فشرده و پیش‌فرض بسته نمایش داده می‌شوند.
4) بخش «سازگاری این دستگاه» اضافه شد و برند/مدل/نسخه Android/API را نمایش می‌دهد.
5) میانبر مستقیم «تنظیمات برنامه» برای مدیریت مجوزهای وابسته به سازنده اضافه شد.
6) میانبر مستقیم «تنظیمات اعلان‌ها» اضافه شد و fallback امن به App Settings دارد.
7) Theme Store قدیمی از Manifest و سورس حذف شد؛ ThemeManager نگه داشته شد تا Graphite Teal ثابت و زیرساخت رنگ فعلی خراب نشود.
8) versionName/versionCode و Regression identity guard به 5.4.18 / 40 ارتقا یافت.

بخش‌های حساس Medicine، Silent Timer، Vault، دیتابیس و Workflowهای GitHub دستکاری نشده‌اند.
نیازمند GitHub Build + Android Regression. تست واقعی برندهای مختلف در مرحله Compatibility Matrix نهایی انجام می‌شود.
