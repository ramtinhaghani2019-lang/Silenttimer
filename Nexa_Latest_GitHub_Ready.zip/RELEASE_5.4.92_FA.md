# Nexa 5.4.92 / Build 114 — Candidate

مرحله عیب‌یابی و Regression پیش از نسخه نهایی.

- اضافه شدن تست مرزی هشدار شارژ و منطق re-arm سه درصدی.
- اضافه شدن تست Regression برای فعال/غیرفعال شدن هشدار قیمت و حالت «قیمت خرید من».
- حفظ منطق و داده‌های Stable Build 113 بدون بازنویسی قابلیت‌های قبلی.
- Version/Regression روی Build 114 تنظیم شد.

این نسخه تا سبز شدن GitHub Build + Regression، Candidate است.
