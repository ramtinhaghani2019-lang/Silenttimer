# Nexa 5.4.77 / Build 99 — Final Master UI Visual Regression

- حذف کامل fallback تصویری تم قدیمی Graphite/Teal از پس‌زمینه و تثبیت گرادیان مشکی/یشمی/طلایی Master UI.
- جلوگیری از بازنویسی استایل دکمه‌های اختصاصی Master UI توسط polish سراسری صفحات قدیمی.
- حفظ تفاوت بصری دکمه‌های اصلی، ثانویه، آیکنی و بازگشت.
- یکدست‌سازی line spacing و حذف font padding اضافی متن‌ها برای RTL تمیزتر.
- حفظ Touch Target حداقل 48dp برای کنترل‌های قدیمی.
- حفظ رنگ‌بندی اختصاصی حذف/لغو، ثبت/ذخیره/تأیید در کنترل‌های Legacy.
- حفظ استایل طلایی/یشمی Switch، CheckBox، RadioButton، SeekBar و ProgressBar.
- حفظ Popup تیره Spinner/AutoComplete و Dividerهای Master UI.
- حفظ قابلیت‌های Stable Build 98 بدون تغییر منطق کسب‌وکار.
- Version/Regression به 5.4.77 / Build 99 منتقل شد.

این ZIP از نظر ساختار آرشیو بررسی شده است؛ تأیید Compile/Regression نهایی با GitHub CI انجام می‌شود.
