# Nexa 5.4.28 / Build 50

بسته چندتغییری Timeline Navigation:
- کارت‌های Timeline برای رویدادهای قابل اقدام قابل لمس شدند.
- یادآور از Timeline مستقیماً همان Reminder را برای ویرایش باز می‌کند.
- دارو از Timeline وارد بخش Medicine می‌شود.
- پرونده قضایی از Timeline وارد بخش Case می‌شود.
- پرداخت از Timeline وارد بخش Bills می‌شود.
- مدرک از Timeline وارد بخش Docs می‌شود.
- نگهداری خانه از Timeline وارد Home Care می‌شود.
- کار Todo از Timeline وارد Nexa List می‌شود.
- کارت رویداد برای لمس‌پذیری و خوانایی از ردیف متن ساده به کارت مستقل تبدیل شد.
- contentDescription برای رویدادهای قابل بازشدن اضافه شد.
- تاریخچه و سرویس‌های صرفاً تاریخی عمداً بدون اکشن باقی ماندند تا رفتار اشتباه ایجاد نشود.
- بدون تغییر database schema، Medicine alarm، Silent Timer یا Vault storage.
- Version/Regression: 5.4.28 / Build 50.
