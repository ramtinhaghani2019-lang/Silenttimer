# Nexa 5.4.111 / Build 133

- پشتیبانی از جداکننده‌های هزارگان NBSP و narrow NBSP در اعداد کپی‌شده.
- هماهنگی قالب‌بندی اعداد صحیح و اعشاری و تبدیل به long/int/double.
- حفظ متن نامعتبر بدون حذف فاصله معمولی.
- تست رگرسیون برای جداکننده‌ها و نسخه جدید.

وضعیت: Candidate تا سبزشدن GitHub Actions.

## Regression hotfix
- اصلاح longValue، intValue و doubleValue برای حذف جداکننده‌های NBSP و narrow NBSP مطابق تست کپی اعداد.
- شماره نسخه بدون تغییر؛ Build 133 همچنان Candidate است.
