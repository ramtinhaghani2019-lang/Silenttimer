# Nexa 5.4.31 / Build 53

## تغییرات
- ایجاد `NexaNotificationEngine` به‌عنوان نقطه مرکزی ساخت و ارسال اعلان‌ها.
- انتقال ساخت اعلان Medicine از `MedicineAlarmReceiver` به Notification Engine.
- انتقال تضمین ساخت Medicine Notification Channel به Engine.
- حفظ سه Action فعلی دارو، Full Screen Intent، Lock Screen visibility و شناسه اعلان قبلی.
- پاک‌سازی مسئولیت `MedicineAlarmReceiver`؛ Scheduler، History، AlarmSoundPlayer و MedicineActionReceiver بدون تغییر رفتاری باقی مانده‌اند.
- افزایش نسخه به `5.4.31 / Build 53` و به‌روزرسانی Regression identity guard.

## وضعیت تست
- نیازمند اجرای GitHub Actions: Build APK و Android Regression Tests.
