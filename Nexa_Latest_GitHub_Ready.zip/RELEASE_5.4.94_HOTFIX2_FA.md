# Nexa 5.4.94 / Build 116 Hotfix Candidate — revision 2
- Weather search field is a real free-text city/neighborhood input with explicit hint.
- Removed hard-coded Tajrish/Rahahan/Tehran/Karaj shortcuts.
- Added user-managed saved weather places with add/open/delete.
- Added hourly weather hazard panel for rain, snow, hail and strong wind with time and distinct colors.
- Open-Meteo hourly weather code, precipitation probability and wind gust data are used for the hazard panel.
- Emergency lock-screen notification moved to a fresh high-importance public channel to avoid stale channel behavior from earlier installs.
- Build remains 116 Candidate until GitHub Build/Regression and device tests pass.
