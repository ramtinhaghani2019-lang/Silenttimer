# Third-party OCR assets

- Engine: Tesseract4Android (`cz.adaptech.tesseract4android:tesseract4android:4.9.0`), https://github.com/adaptech-cz/Tesseract4Android . Review upstream dependency and third-party notices for distribution.
- Language model files: `app/src/main/assets/tessdata/fas.traineddata` and `eng.traineddata`, extracted from local Tesseract OCR language data packages (official Tesseract training ecosystem, Apache-2.0). Project: https://github.com/tesseract-ocr/tessdata and https://github.com/tesseract-ocr/tessdata_fast .
- No OCR cloud or account credentials are required; the original receipt image and OCR result stay on device.
